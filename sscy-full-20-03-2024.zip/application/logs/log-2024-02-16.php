<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-16 18:06:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:06:55 --> Config Class Initialized
INFO - 2024-02-16 18:06:55 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:06:55 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:06:55 --> Utf8 Class Initialized
INFO - 2024-02-16 18:06:55 --> URI Class Initialized
INFO - 2024-02-16 18:06:55 --> Router Class Initialized
INFO - 2024-02-16 18:06:55 --> Output Class Initialized
INFO - 2024-02-16 18:06:55 --> Security Class Initialized
DEBUG - 2024-02-16 18:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:06:55 --> Input Class Initialized
INFO - 2024-02-16 18:06:55 --> Language Class Initialized
INFO - 2024-02-16 18:06:55 --> Loader Class Initialized
INFO - 2024-02-16 18:06:55 --> Helper loaded: url_helper
INFO - 2024-02-16 18:06:55 --> Helper loaded: file_helper
INFO - 2024-02-16 18:06:55 --> Helper loaded: form_helper
INFO - 2024-02-16 18:06:55 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:06:55 --> Controller Class Initialized
INFO - 2024-02-16 18:06:55 --> Model "LoginModel" initialized
INFO - 2024-02-16 18:06:55 --> Form Validation Class Initialized
INFO - 2024-02-16 18:06:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-16 18:06:55 --> Final output sent to browser
DEBUG - 2024-02-16 18:06:55 --> Total execution time: 0.0332
ERROR - 2024-02-16 18:06:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:06:57 --> Config Class Initialized
INFO - 2024-02-16 18:06:57 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:06:57 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:06:57 --> Utf8 Class Initialized
INFO - 2024-02-16 18:06:57 --> URI Class Initialized
INFO - 2024-02-16 18:06:57 --> Router Class Initialized
INFO - 2024-02-16 18:06:57 --> Output Class Initialized
INFO - 2024-02-16 18:06:57 --> Security Class Initialized
DEBUG - 2024-02-16 18:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:06:57 --> Input Class Initialized
INFO - 2024-02-16 18:06:57 --> Language Class Initialized
INFO - 2024-02-16 18:06:57 --> Loader Class Initialized
INFO - 2024-02-16 18:06:57 --> Helper loaded: url_helper
INFO - 2024-02-16 18:06:57 --> Helper loaded: file_helper
INFO - 2024-02-16 18:06:57 --> Helper loaded: form_helper
INFO - 2024-02-16 18:06:57 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:06:57 --> Controller Class Initialized
INFO - 2024-02-16 18:06:57 --> Model "LoginModel" initialized
INFO - 2024-02-16 18:06:57 --> Form Validation Class Initialized
INFO - 2024-02-16 18:06:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-16 18:06:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:06:57 --> Config Class Initialized
INFO - 2024-02-16 18:06:57 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:06:57 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:06:57 --> Utf8 Class Initialized
INFO - 2024-02-16 18:06:57 --> URI Class Initialized
INFO - 2024-02-16 18:06:57 --> Router Class Initialized
INFO - 2024-02-16 18:06:57 --> Output Class Initialized
INFO - 2024-02-16 18:06:57 --> Security Class Initialized
DEBUG - 2024-02-16 18:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:06:57 --> Input Class Initialized
INFO - 2024-02-16 18:06:57 --> Language Class Initialized
INFO - 2024-02-16 18:06:57 --> Loader Class Initialized
INFO - 2024-02-16 18:06:57 --> Helper loaded: url_helper
INFO - 2024-02-16 18:06:57 --> Helper loaded: file_helper
INFO - 2024-02-16 18:06:57 --> Helper loaded: form_helper
INFO - 2024-02-16 18:06:57 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:06:57 --> Controller Class Initialized
INFO - 2024-02-16 18:06:57 --> Form Validation Class Initialized
INFO - 2024-02-16 18:06:57 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:06:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:06:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:06:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:06:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:06:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-16 18:06:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:06:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:06:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:06:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-16 18:06:57 --> Final output sent to browser
DEBUG - 2024-02-16 18:06:57 --> Total execution time: 0.0161
ERROR - 2024-02-16 18:06:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:06:58 --> Config Class Initialized
INFO - 2024-02-16 18:06:58 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:06:58 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:06:58 --> Utf8 Class Initialized
INFO - 2024-02-16 18:06:58 --> URI Class Initialized
INFO - 2024-02-16 18:06:58 --> Router Class Initialized
INFO - 2024-02-16 18:06:58 --> Output Class Initialized
INFO - 2024-02-16 18:06:58 --> Security Class Initialized
DEBUG - 2024-02-16 18:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:06:58 --> Input Class Initialized
INFO - 2024-02-16 18:06:58 --> Language Class Initialized
INFO - 2024-02-16 18:06:58 --> Loader Class Initialized
INFO - 2024-02-16 18:06:58 --> Helper loaded: url_helper
INFO - 2024-02-16 18:06:58 --> Helper loaded: file_helper
INFO - 2024-02-16 18:06:58 --> Helper loaded: form_helper
INFO - 2024-02-16 18:06:58 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:06:58 --> Controller Class Initialized
INFO - 2024-02-16 18:06:58 --> Form Validation Class Initialized
INFO - 2024-02-16 18:06:58 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:06:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:06:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:06:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:06:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:06:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-16 18:06:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:06:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:06:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:06:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-16 18:06:58 --> Final output sent to browser
DEBUG - 2024-02-16 18:06:58 --> Total execution time: 0.0172
ERROR - 2024-02-16 18:07:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:07:09 --> Config Class Initialized
INFO - 2024-02-16 18:07:09 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:07:09 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:07:09 --> Utf8 Class Initialized
INFO - 2024-02-16 18:07:09 --> URI Class Initialized
INFO - 2024-02-16 18:07:09 --> Router Class Initialized
INFO - 2024-02-16 18:07:09 --> Output Class Initialized
INFO - 2024-02-16 18:07:09 --> Security Class Initialized
DEBUG - 2024-02-16 18:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:07:09 --> Input Class Initialized
INFO - 2024-02-16 18:07:09 --> Language Class Initialized
INFO - 2024-02-16 18:07:09 --> Loader Class Initialized
INFO - 2024-02-16 18:07:09 --> Helper loaded: url_helper
INFO - 2024-02-16 18:07:09 --> Helper loaded: file_helper
INFO - 2024-02-16 18:07:09 --> Helper loaded: form_helper
INFO - 2024-02-16 18:07:09 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:07:09 --> Controller Class Initialized
INFO - 2024-02-16 18:07:09 --> Form Validation Class Initialized
INFO - 2024-02-16 18:07:09 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:07:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:07:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:07:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:07:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:07:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:07:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:07:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:07:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:07:09 --> Final output sent to browser
DEBUG - 2024-02-16 18:07:09 --> Total execution time: 0.0180
ERROR - 2024-02-16 18:07:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:07:09 --> Config Class Initialized
INFO - 2024-02-16 18:07:09 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:07:09 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:07:09 --> Utf8 Class Initialized
INFO - 2024-02-16 18:07:09 --> URI Class Initialized
INFO - 2024-02-16 18:07:09 --> Router Class Initialized
INFO - 2024-02-16 18:07:09 --> Output Class Initialized
INFO - 2024-02-16 18:07:09 --> Security Class Initialized
DEBUG - 2024-02-16 18:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:07:09 --> Input Class Initialized
INFO - 2024-02-16 18:07:09 --> Language Class Initialized
INFO - 2024-02-16 18:07:09 --> Loader Class Initialized
INFO - 2024-02-16 18:07:09 --> Helper loaded: url_helper
INFO - 2024-02-16 18:07:09 --> Helper loaded: file_helper
INFO - 2024-02-16 18:07:09 --> Helper loaded: form_helper
INFO - 2024-02-16 18:07:09 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:07:09 --> Controller Class Initialized
INFO - 2024-02-16 18:07:09 --> Form Validation Class Initialized
INFO - 2024-02-16 18:07:09 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:07:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:07:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:07:09 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:07:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:07:12 --> Config Class Initialized
INFO - 2024-02-16 18:07:12 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:07:12 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:07:12 --> Utf8 Class Initialized
INFO - 2024-02-16 18:07:12 --> URI Class Initialized
INFO - 2024-02-16 18:07:12 --> Router Class Initialized
INFO - 2024-02-16 18:07:12 --> Output Class Initialized
INFO - 2024-02-16 18:07:12 --> Security Class Initialized
DEBUG - 2024-02-16 18:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:07:12 --> Input Class Initialized
INFO - 2024-02-16 18:07:12 --> Language Class Initialized
INFO - 2024-02-16 18:07:12 --> Loader Class Initialized
INFO - 2024-02-16 18:07:12 --> Helper loaded: url_helper
INFO - 2024-02-16 18:07:12 --> Helper loaded: file_helper
INFO - 2024-02-16 18:07:12 --> Helper loaded: form_helper
INFO - 2024-02-16 18:07:12 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:07:12 --> Controller Class Initialized
INFO - 2024-02-16 18:07:12 --> Form Validation Class Initialized
INFO - 2024-02-16 18:07:12 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:07:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:07:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:07:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:07:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:07:12 --> Final output sent to browser
DEBUG - 2024-02-16 18:07:12 --> Total execution time: 0.0148
ERROR - 2024-02-16 18:08:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:08:23 --> Config Class Initialized
INFO - 2024-02-16 18:08:23 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:08:23 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:08:23 --> Utf8 Class Initialized
INFO - 2024-02-16 18:08:23 --> URI Class Initialized
INFO - 2024-02-16 18:08:23 --> Router Class Initialized
INFO - 2024-02-16 18:08:24 --> Output Class Initialized
INFO - 2024-02-16 18:08:24 --> Security Class Initialized
DEBUG - 2024-02-16 18:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:08:24 --> Input Class Initialized
INFO - 2024-02-16 18:08:24 --> Language Class Initialized
INFO - 2024-02-16 18:08:24 --> Loader Class Initialized
INFO - 2024-02-16 18:08:24 --> Helper loaded: url_helper
INFO - 2024-02-16 18:08:24 --> Helper loaded: file_helper
INFO - 2024-02-16 18:08:24 --> Helper loaded: form_helper
INFO - 2024-02-16 18:08:24 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:08:24 --> Controller Class Initialized
INFO - 2024-02-16 18:08:24 --> Form Validation Class Initialized
INFO - 2024-02-16 18:08:24 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:08:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:08:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:08:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:08:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:08:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:08:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:08:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:08:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:08:24 --> Final output sent to browser
DEBUG - 2024-02-16 18:08:24 --> Total execution time: 0.0295
ERROR - 2024-02-16 18:15:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:15:11 --> Config Class Initialized
INFO - 2024-02-16 18:15:11 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:15:11 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:15:11 --> Utf8 Class Initialized
INFO - 2024-02-16 18:15:11 --> URI Class Initialized
INFO - 2024-02-16 18:15:11 --> Router Class Initialized
INFO - 2024-02-16 18:15:11 --> Output Class Initialized
INFO - 2024-02-16 18:15:11 --> Security Class Initialized
DEBUG - 2024-02-16 18:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:15:11 --> Input Class Initialized
INFO - 2024-02-16 18:15:11 --> Language Class Initialized
INFO - 2024-02-16 18:15:11 --> Loader Class Initialized
INFO - 2024-02-16 18:15:11 --> Helper loaded: url_helper
INFO - 2024-02-16 18:15:11 --> Helper loaded: file_helper
INFO - 2024-02-16 18:15:11 --> Helper loaded: form_helper
INFO - 2024-02-16 18:15:11 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:15:11 --> Controller Class Initialized
INFO - 2024-02-16 18:15:11 --> Form Validation Class Initialized
INFO - 2024-02-16 18:15:11 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:15:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:15:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:15:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:15:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:15:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:15:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:15:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:15:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:15:11 --> Final output sent to browser
DEBUG - 2024-02-16 18:15:11 --> Total execution time: 0.0189
ERROR - 2024-02-16 18:15:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:15:12 --> Config Class Initialized
INFO - 2024-02-16 18:15:12 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:15:12 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:15:12 --> Utf8 Class Initialized
INFO - 2024-02-16 18:15:12 --> URI Class Initialized
INFO - 2024-02-16 18:15:12 --> Router Class Initialized
INFO - 2024-02-16 18:15:12 --> Output Class Initialized
INFO - 2024-02-16 18:15:12 --> Security Class Initialized
DEBUG - 2024-02-16 18:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:15:12 --> Input Class Initialized
INFO - 2024-02-16 18:15:12 --> Language Class Initialized
INFO - 2024-02-16 18:15:12 --> Loader Class Initialized
INFO - 2024-02-16 18:15:12 --> Helper loaded: url_helper
INFO - 2024-02-16 18:15:12 --> Helper loaded: file_helper
INFO - 2024-02-16 18:15:12 --> Helper loaded: form_helper
INFO - 2024-02-16 18:15:12 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:15:12 --> Controller Class Initialized
INFO - 2024-02-16 18:15:12 --> Form Validation Class Initialized
INFO - 2024-02-16 18:15:12 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:15:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:15:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:15:12 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:15:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:15:13 --> Config Class Initialized
INFO - 2024-02-16 18:15:13 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:15:13 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:15:13 --> Utf8 Class Initialized
INFO - 2024-02-16 18:15:13 --> URI Class Initialized
INFO - 2024-02-16 18:15:13 --> Router Class Initialized
INFO - 2024-02-16 18:15:13 --> Output Class Initialized
INFO - 2024-02-16 18:15:13 --> Security Class Initialized
DEBUG - 2024-02-16 18:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:15:13 --> Input Class Initialized
INFO - 2024-02-16 18:15:13 --> Language Class Initialized
INFO - 2024-02-16 18:15:13 --> Loader Class Initialized
INFO - 2024-02-16 18:15:13 --> Helper loaded: url_helper
INFO - 2024-02-16 18:15:13 --> Helper loaded: file_helper
INFO - 2024-02-16 18:15:13 --> Helper loaded: form_helper
INFO - 2024-02-16 18:15:13 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:15:13 --> Controller Class Initialized
INFO - 2024-02-16 18:15:13 --> Form Validation Class Initialized
INFO - 2024-02-16 18:15:13 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:15:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:15:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:15:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:15:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:15:13 --> Final output sent to browser
DEBUG - 2024-02-16 18:15:13 --> Total execution time: 0.0139
ERROR - 2024-02-16 18:19:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:19:19 --> Config Class Initialized
INFO - 2024-02-16 18:19:19 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:19:19 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:19:19 --> Utf8 Class Initialized
INFO - 2024-02-16 18:19:19 --> URI Class Initialized
INFO - 2024-02-16 18:19:19 --> Router Class Initialized
INFO - 2024-02-16 18:19:19 --> Output Class Initialized
INFO - 2024-02-16 18:19:19 --> Security Class Initialized
DEBUG - 2024-02-16 18:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:19:19 --> Input Class Initialized
INFO - 2024-02-16 18:19:19 --> Language Class Initialized
INFO - 2024-02-16 18:19:19 --> Loader Class Initialized
INFO - 2024-02-16 18:19:19 --> Helper loaded: url_helper
INFO - 2024-02-16 18:19:19 --> Helper loaded: file_helper
INFO - 2024-02-16 18:19:19 --> Helper loaded: form_helper
INFO - 2024-02-16 18:19:19 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:19:19 --> Controller Class Initialized
INFO - 2024-02-16 18:19:19 --> Form Validation Class Initialized
INFO - 2024-02-16 18:19:19 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:19:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:19:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:19:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:19:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:19:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:19:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:19:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:19:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:19:19 --> Final output sent to browser
DEBUG - 2024-02-16 18:19:19 --> Total execution time: 0.0247
ERROR - 2024-02-16 18:19:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:19:20 --> Config Class Initialized
INFO - 2024-02-16 18:19:20 --> Hooks Class Initialized
ERROR - 2024-02-16 18:19:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2024-02-16 18:19:20 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:19:20 --> Utf8 Class Initialized
INFO - 2024-02-16 18:19:20 --> Config Class Initialized
INFO - 2024-02-16 18:19:20 --> Hooks Class Initialized
INFO - 2024-02-16 18:19:20 --> URI Class Initialized
DEBUG - 2024-02-16 18:19:20 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:19:20 --> Utf8 Class Initialized
INFO - 2024-02-16 18:19:20 --> Router Class Initialized
INFO - 2024-02-16 18:19:20 --> URI Class Initialized
INFO - 2024-02-16 18:19:20 --> Output Class Initialized
INFO - 2024-02-16 18:19:20 --> Router Class Initialized
INFO - 2024-02-16 18:19:20 --> Security Class Initialized
DEBUG - 2024-02-16 18:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:19:20 --> Input Class Initialized
INFO - 2024-02-16 18:19:20 --> Language Class Initialized
INFO - 2024-02-16 18:19:20 --> Output Class Initialized
INFO - 2024-02-16 18:19:20 --> Loader Class Initialized
INFO - 2024-02-16 18:19:20 --> Helper loaded: url_helper
INFO - 2024-02-16 18:19:20 --> Helper loaded: file_helper
INFO - 2024-02-16 18:19:20 --> Security Class Initialized
INFO - 2024-02-16 18:19:20 --> Helper loaded: form_helper
DEBUG - 2024-02-16 18:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:19:20 --> Input Class Initialized
INFO - 2024-02-16 18:19:20 --> Language Class Initialized
INFO - 2024-02-16 18:19:20 --> Database Driver Class Initialized
INFO - 2024-02-16 18:19:20 --> Loader Class Initialized
INFO - 2024-02-16 18:19:20 --> Helper loaded: url_helper
INFO - 2024-02-16 18:19:20 --> Helper loaded: file_helper
DEBUG - 2024-02-16 18:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:19:20 --> Controller Class Initialized
INFO - 2024-02-16 18:19:20 --> Helper loaded: form_helper
INFO - 2024-02-16 18:19:20 --> Form Validation Class Initialized
INFO - 2024-02-16 18:19:20 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:19:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:19:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:19:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:19:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:19:20 --> Config Class Initialized
INFO - 2024-02-16 18:19:20 --> Hooks Class Initialized
INFO - 2024-02-16 18:19:20 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:19:20 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:19:20 --> Utf8 Class Initialized
INFO - 2024-02-16 18:19:20 --> URI Class Initialized
INFO - 2024-02-16 18:19:20 --> Router Class Initialized
DEBUG - 2024-02-16 18:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:19:20 --> Output Class Initialized
INFO - 2024-02-16 18:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:19:20 --> Controller Class Initialized
INFO - 2024-02-16 18:19:20 --> Security Class Initialized
INFO - 2024-02-16 18:19:20 --> Form Validation Class Initialized
DEBUG - 2024-02-16 18:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:19:20 --> Input Class Initialized
INFO - 2024-02-16 18:19:20 --> Language Class Initialized
INFO - 2024-02-16 18:19:20 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:19:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:19:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:19:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:19:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:19:20 --> Loader Class Initialized
INFO - 2024-02-16 18:19:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:19:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:19:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:19:20 --> Helper loaded: url_helper
INFO - 2024-02-16 18:19:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:19:20 --> Helper loaded: file_helper
INFO - 2024-02-16 18:19:20 --> Final output sent to browser
DEBUG - 2024-02-16 18:19:20 --> Total execution time: 0.0455
INFO - 2024-02-16 18:19:20 --> Helper loaded: form_helper
INFO - 2024-02-16 18:19:20 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:19:20 --> Controller Class Initialized
INFO - 2024-02-16 18:19:20 --> Form Validation Class Initialized
INFO - 2024-02-16 18:19:20 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:19:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:19:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:19:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:19:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:19:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:19:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:19:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:19:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:19:20 --> Final output sent to browser
DEBUG - 2024-02-16 18:19:20 --> Total execution time: 0.0500
ERROR - 2024-02-16 18:19:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:19:20 --> Config Class Initialized
INFO - 2024-02-16 18:19:20 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:19:20 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:19:20 --> Utf8 Class Initialized
INFO - 2024-02-16 18:19:20 --> URI Class Initialized
INFO - 2024-02-16 18:19:20 --> Router Class Initialized
INFO - 2024-02-16 18:19:20 --> Output Class Initialized
INFO - 2024-02-16 18:19:20 --> Security Class Initialized
DEBUG - 2024-02-16 18:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:19:20 --> Input Class Initialized
INFO - 2024-02-16 18:19:20 --> Language Class Initialized
INFO - 2024-02-16 18:19:20 --> Loader Class Initialized
INFO - 2024-02-16 18:19:20 --> Helper loaded: url_helper
INFO - 2024-02-16 18:19:20 --> Helper loaded: file_helper
INFO - 2024-02-16 18:19:20 --> Helper loaded: form_helper
INFO - 2024-02-16 18:19:20 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:19:20 --> Controller Class Initialized
INFO - 2024-02-16 18:19:20 --> Form Validation Class Initialized
INFO - 2024-02-16 18:19:20 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:19:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:19:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:19:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:19:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:19:22 --> Config Class Initialized
INFO - 2024-02-16 18:19:22 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:19:22 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:19:22 --> Utf8 Class Initialized
INFO - 2024-02-16 18:19:22 --> URI Class Initialized
INFO - 2024-02-16 18:19:22 --> Router Class Initialized
INFO - 2024-02-16 18:19:22 --> Output Class Initialized
INFO - 2024-02-16 18:19:22 --> Security Class Initialized
DEBUG - 2024-02-16 18:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:19:22 --> Input Class Initialized
INFO - 2024-02-16 18:19:22 --> Language Class Initialized
INFO - 2024-02-16 18:19:22 --> Loader Class Initialized
INFO - 2024-02-16 18:19:22 --> Helper loaded: url_helper
INFO - 2024-02-16 18:19:22 --> Helper loaded: file_helper
INFO - 2024-02-16 18:19:22 --> Helper loaded: form_helper
INFO - 2024-02-16 18:19:22 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:19:22 --> Controller Class Initialized
INFO - 2024-02-16 18:19:22 --> Form Validation Class Initialized
INFO - 2024-02-16 18:19:22 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:19:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:19:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:19:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:19:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:19:22 --> Final output sent to browser
DEBUG - 2024-02-16 18:19:22 --> Total execution time: 0.0165
ERROR - 2024-02-16 18:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:19:42 --> Config Class Initialized
INFO - 2024-02-16 18:19:42 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:19:42 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:19:42 --> Utf8 Class Initialized
INFO - 2024-02-16 18:19:42 --> URI Class Initialized
INFO - 2024-02-16 18:19:42 --> Router Class Initialized
INFO - 2024-02-16 18:19:42 --> Output Class Initialized
INFO - 2024-02-16 18:19:42 --> Security Class Initialized
DEBUG - 2024-02-16 18:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:19:42 --> Input Class Initialized
INFO - 2024-02-16 18:19:42 --> Language Class Initialized
INFO - 2024-02-16 18:19:42 --> Loader Class Initialized
INFO - 2024-02-16 18:19:42 --> Helper loaded: url_helper
INFO - 2024-02-16 18:19:42 --> Helper loaded: file_helper
INFO - 2024-02-16 18:19:42 --> Helper loaded: form_helper
INFO - 2024-02-16 18:19:42 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:19:42 --> Controller Class Initialized
INFO - 2024-02-16 18:19:42 --> Form Validation Class Initialized
INFO - 2024-02-16 18:19:42 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:19:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:19:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:19:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:19:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:19:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:19:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:19:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:19:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:19:42 --> Final output sent to browser
DEBUG - 2024-02-16 18:19:42 --> Total execution time: 0.0153
ERROR - 2024-02-16 18:19:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:19:43 --> Config Class Initialized
INFO - 2024-02-16 18:19:43 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:19:43 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:19:43 --> Utf8 Class Initialized
INFO - 2024-02-16 18:19:43 --> URI Class Initialized
INFO - 2024-02-16 18:19:43 --> Router Class Initialized
INFO - 2024-02-16 18:19:43 --> Output Class Initialized
INFO - 2024-02-16 18:19:43 --> Security Class Initialized
DEBUG - 2024-02-16 18:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:19:43 --> Input Class Initialized
INFO - 2024-02-16 18:19:43 --> Language Class Initialized
INFO - 2024-02-16 18:19:43 --> Loader Class Initialized
INFO - 2024-02-16 18:19:43 --> Helper loaded: url_helper
INFO - 2024-02-16 18:19:43 --> Helper loaded: file_helper
INFO - 2024-02-16 18:19:43 --> Helper loaded: form_helper
INFO - 2024-02-16 18:19:43 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:19:43 --> Controller Class Initialized
INFO - 2024-02-16 18:19:43 --> Form Validation Class Initialized
INFO - 2024-02-16 18:19:43 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:19:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:19:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:19:43 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:19:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:19:47 --> Config Class Initialized
INFO - 2024-02-16 18:19:47 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:19:47 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:19:47 --> Utf8 Class Initialized
INFO - 2024-02-16 18:19:47 --> URI Class Initialized
INFO - 2024-02-16 18:19:47 --> Router Class Initialized
INFO - 2024-02-16 18:19:47 --> Output Class Initialized
INFO - 2024-02-16 18:19:47 --> Security Class Initialized
DEBUG - 2024-02-16 18:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:19:47 --> Input Class Initialized
INFO - 2024-02-16 18:19:47 --> Language Class Initialized
INFO - 2024-02-16 18:19:47 --> Loader Class Initialized
INFO - 2024-02-16 18:19:47 --> Helper loaded: url_helper
INFO - 2024-02-16 18:19:47 --> Helper loaded: file_helper
INFO - 2024-02-16 18:19:47 --> Helper loaded: form_helper
INFO - 2024-02-16 18:19:47 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:19:47 --> Controller Class Initialized
INFO - 2024-02-16 18:19:47 --> Form Validation Class Initialized
INFO - 2024-02-16 18:19:47 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:19:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:19:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:19:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:19:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:19:47 --> Final output sent to browser
DEBUG - 2024-02-16 18:19:47 --> Total execution time: 0.0146
ERROR - 2024-02-16 18:20:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:20:18 --> Config Class Initialized
INFO - 2024-02-16 18:20:18 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:20:18 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:20:18 --> Utf8 Class Initialized
INFO - 2024-02-16 18:20:18 --> URI Class Initialized
INFO - 2024-02-16 18:20:18 --> Router Class Initialized
INFO - 2024-02-16 18:20:18 --> Output Class Initialized
INFO - 2024-02-16 18:20:18 --> Security Class Initialized
DEBUG - 2024-02-16 18:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:20:18 --> Input Class Initialized
INFO - 2024-02-16 18:20:18 --> Language Class Initialized
INFO - 2024-02-16 18:20:18 --> Loader Class Initialized
INFO - 2024-02-16 18:20:18 --> Helper loaded: url_helper
INFO - 2024-02-16 18:20:18 --> Helper loaded: file_helper
INFO - 2024-02-16 18:20:18 --> Helper loaded: form_helper
INFO - 2024-02-16 18:20:18 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:20:18 --> Controller Class Initialized
INFO - 2024-02-16 18:20:18 --> Form Validation Class Initialized
INFO - 2024-02-16 18:20:18 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:20:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:20:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:20:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:20:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:20:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:20:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:20:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:20:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:20:18 --> Final output sent to browser
DEBUG - 2024-02-16 18:20:18 --> Total execution time: 0.0153
ERROR - 2024-02-16 18:20:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:20:18 --> Config Class Initialized
INFO - 2024-02-16 18:20:18 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:20:18 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:20:18 --> Utf8 Class Initialized
INFO - 2024-02-16 18:20:18 --> URI Class Initialized
INFO - 2024-02-16 18:20:18 --> Router Class Initialized
INFO - 2024-02-16 18:20:18 --> Output Class Initialized
INFO - 2024-02-16 18:20:18 --> Security Class Initialized
DEBUG - 2024-02-16 18:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:20:18 --> Input Class Initialized
INFO - 2024-02-16 18:20:18 --> Language Class Initialized
INFO - 2024-02-16 18:20:18 --> Loader Class Initialized
INFO - 2024-02-16 18:20:18 --> Helper loaded: url_helper
INFO - 2024-02-16 18:20:18 --> Helper loaded: file_helper
INFO - 2024-02-16 18:20:18 --> Helper loaded: form_helper
INFO - 2024-02-16 18:20:18 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:20:18 --> Controller Class Initialized
INFO - 2024-02-16 18:20:18 --> Form Validation Class Initialized
INFO - 2024-02-16 18:20:18 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:20:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:20:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:20:18 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:20:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:20:20 --> Config Class Initialized
INFO - 2024-02-16 18:20:20 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:20:20 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:20:20 --> Utf8 Class Initialized
INFO - 2024-02-16 18:20:20 --> URI Class Initialized
INFO - 2024-02-16 18:20:20 --> Router Class Initialized
INFO - 2024-02-16 18:20:20 --> Output Class Initialized
INFO - 2024-02-16 18:20:20 --> Security Class Initialized
DEBUG - 2024-02-16 18:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:20:20 --> Input Class Initialized
INFO - 2024-02-16 18:20:20 --> Language Class Initialized
INFO - 2024-02-16 18:20:20 --> Loader Class Initialized
INFO - 2024-02-16 18:20:20 --> Helper loaded: url_helper
INFO - 2024-02-16 18:20:20 --> Helper loaded: file_helper
INFO - 2024-02-16 18:20:20 --> Helper loaded: form_helper
INFO - 2024-02-16 18:20:20 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:20:20 --> Controller Class Initialized
INFO - 2024-02-16 18:20:20 --> Form Validation Class Initialized
INFO - 2024-02-16 18:20:20 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:20:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:20:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:20:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:20:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:20:20 --> Final output sent to browser
DEBUG - 2024-02-16 18:20:20 --> Total execution time: 0.0150
ERROR - 2024-02-16 18:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:21:25 --> Config Class Initialized
INFO - 2024-02-16 18:21:25 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:21:25 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:21:25 --> Utf8 Class Initialized
INFO - 2024-02-16 18:21:25 --> URI Class Initialized
INFO - 2024-02-16 18:21:25 --> Router Class Initialized
INFO - 2024-02-16 18:21:25 --> Output Class Initialized
INFO - 2024-02-16 18:21:25 --> Security Class Initialized
DEBUG - 2024-02-16 18:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:21:25 --> Input Class Initialized
INFO - 2024-02-16 18:21:25 --> Language Class Initialized
INFO - 2024-02-16 18:21:25 --> Loader Class Initialized
INFO - 2024-02-16 18:21:25 --> Helper loaded: url_helper
INFO - 2024-02-16 18:21:25 --> Helper loaded: file_helper
INFO - 2024-02-16 18:21:25 --> Helper loaded: form_helper
INFO - 2024-02-16 18:21:25 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:21:25 --> Controller Class Initialized
INFO - 2024-02-16 18:21:25 --> Form Validation Class Initialized
INFO - 2024-02-16 18:21:25 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:21:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:21:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:21:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:21:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:21:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:21:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:21:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:21:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:21:25 --> Final output sent to browser
DEBUG - 2024-02-16 18:21:25 --> Total execution time: 0.0153
ERROR - 2024-02-16 18:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:21:25 --> Config Class Initialized
INFO - 2024-02-16 18:21:25 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:21:25 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:21:25 --> Utf8 Class Initialized
INFO - 2024-02-16 18:21:25 --> URI Class Initialized
INFO - 2024-02-16 18:21:25 --> Router Class Initialized
INFO - 2024-02-16 18:21:25 --> Output Class Initialized
INFO - 2024-02-16 18:21:25 --> Security Class Initialized
DEBUG - 2024-02-16 18:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:21:25 --> Input Class Initialized
INFO - 2024-02-16 18:21:25 --> Language Class Initialized
INFO - 2024-02-16 18:21:25 --> Loader Class Initialized
INFO - 2024-02-16 18:21:25 --> Helper loaded: url_helper
INFO - 2024-02-16 18:21:25 --> Helper loaded: file_helper
INFO - 2024-02-16 18:21:25 --> Helper loaded: form_helper
INFO - 2024-02-16 18:21:25 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:21:25 --> Controller Class Initialized
INFO - 2024-02-16 18:21:25 --> Form Validation Class Initialized
INFO - 2024-02-16 18:21:25 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:21:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:21:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:21:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:21:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:21:29 --> Config Class Initialized
INFO - 2024-02-16 18:21:29 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:21:29 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:21:29 --> Utf8 Class Initialized
INFO - 2024-02-16 18:21:29 --> URI Class Initialized
INFO - 2024-02-16 18:21:29 --> Router Class Initialized
INFO - 2024-02-16 18:21:29 --> Output Class Initialized
INFO - 2024-02-16 18:21:29 --> Security Class Initialized
DEBUG - 2024-02-16 18:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:21:29 --> Input Class Initialized
INFO - 2024-02-16 18:21:29 --> Language Class Initialized
INFO - 2024-02-16 18:21:29 --> Loader Class Initialized
INFO - 2024-02-16 18:21:29 --> Helper loaded: url_helper
INFO - 2024-02-16 18:21:29 --> Helper loaded: file_helper
INFO - 2024-02-16 18:21:29 --> Helper loaded: form_helper
INFO - 2024-02-16 18:21:29 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:21:29 --> Controller Class Initialized
INFO - 2024-02-16 18:21:29 --> Form Validation Class Initialized
INFO - 2024-02-16 18:21:29 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:21:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:21:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:21:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:21:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:21:29 --> Final output sent to browser
DEBUG - 2024-02-16 18:21:29 --> Total execution time: 0.0142
ERROR - 2024-02-16 18:25:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:25:36 --> Config Class Initialized
INFO - 2024-02-16 18:25:36 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:25:36 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:25:36 --> Utf8 Class Initialized
INFO - 2024-02-16 18:25:36 --> URI Class Initialized
INFO - 2024-02-16 18:25:36 --> Router Class Initialized
INFO - 2024-02-16 18:25:36 --> Output Class Initialized
INFO - 2024-02-16 18:25:36 --> Security Class Initialized
DEBUG - 2024-02-16 18:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:25:36 --> Input Class Initialized
INFO - 2024-02-16 18:25:36 --> Language Class Initialized
INFO - 2024-02-16 18:25:36 --> Loader Class Initialized
INFO - 2024-02-16 18:25:36 --> Helper loaded: url_helper
INFO - 2024-02-16 18:25:36 --> Helper loaded: file_helper
INFO - 2024-02-16 18:25:36 --> Helper loaded: form_helper
INFO - 2024-02-16 18:25:36 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:25:36 --> Controller Class Initialized
INFO - 2024-02-16 18:25:36 --> Form Validation Class Initialized
INFO - 2024-02-16 18:25:36 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:25:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:25:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:25:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:25:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:25:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:25:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:25:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:25:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:25:36 --> Final output sent to browser
DEBUG - 2024-02-16 18:25:36 --> Total execution time: 0.0162
ERROR - 2024-02-16 18:25:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:25:36 --> Config Class Initialized
INFO - 2024-02-16 18:25:36 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:25:36 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:25:36 --> Utf8 Class Initialized
INFO - 2024-02-16 18:25:36 --> URI Class Initialized
INFO - 2024-02-16 18:25:36 --> Router Class Initialized
INFO - 2024-02-16 18:25:36 --> Output Class Initialized
INFO - 2024-02-16 18:25:36 --> Security Class Initialized
DEBUG - 2024-02-16 18:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:25:36 --> Input Class Initialized
INFO - 2024-02-16 18:25:36 --> Language Class Initialized
INFO - 2024-02-16 18:25:36 --> Loader Class Initialized
INFO - 2024-02-16 18:25:36 --> Helper loaded: url_helper
INFO - 2024-02-16 18:25:36 --> Helper loaded: file_helper
INFO - 2024-02-16 18:25:36 --> Helper loaded: form_helper
INFO - 2024-02-16 18:25:36 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:25:36 --> Controller Class Initialized
INFO - 2024-02-16 18:25:36 --> Form Validation Class Initialized
INFO - 2024-02-16 18:25:36 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:25:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:25:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:25:36 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:25:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:25:39 --> Config Class Initialized
INFO - 2024-02-16 18:25:39 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:25:39 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:25:39 --> Utf8 Class Initialized
INFO - 2024-02-16 18:25:39 --> URI Class Initialized
INFO - 2024-02-16 18:25:39 --> Router Class Initialized
INFO - 2024-02-16 18:25:39 --> Output Class Initialized
INFO - 2024-02-16 18:25:39 --> Security Class Initialized
DEBUG - 2024-02-16 18:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:25:39 --> Input Class Initialized
INFO - 2024-02-16 18:25:39 --> Language Class Initialized
INFO - 2024-02-16 18:25:39 --> Loader Class Initialized
INFO - 2024-02-16 18:25:39 --> Helper loaded: url_helper
INFO - 2024-02-16 18:25:39 --> Helper loaded: file_helper
INFO - 2024-02-16 18:25:39 --> Helper loaded: form_helper
INFO - 2024-02-16 18:25:39 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:25:39 --> Controller Class Initialized
INFO - 2024-02-16 18:25:39 --> Form Validation Class Initialized
INFO - 2024-02-16 18:25:39 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:25:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:25:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:25:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:25:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:25:39 --> Final output sent to browser
DEBUG - 2024-02-16 18:25:39 --> Total execution time: 0.0147
ERROR - 2024-02-16 18:26:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:26:36 --> Config Class Initialized
INFO - 2024-02-16 18:26:36 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:26:36 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:26:36 --> Utf8 Class Initialized
INFO - 2024-02-16 18:26:36 --> URI Class Initialized
INFO - 2024-02-16 18:26:36 --> Router Class Initialized
INFO - 2024-02-16 18:26:36 --> Output Class Initialized
INFO - 2024-02-16 18:26:36 --> Security Class Initialized
DEBUG - 2024-02-16 18:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:26:36 --> Input Class Initialized
INFO - 2024-02-16 18:26:36 --> Language Class Initialized
INFO - 2024-02-16 18:26:36 --> Loader Class Initialized
INFO - 2024-02-16 18:26:36 --> Helper loaded: url_helper
INFO - 2024-02-16 18:26:36 --> Helper loaded: file_helper
INFO - 2024-02-16 18:26:36 --> Helper loaded: form_helper
INFO - 2024-02-16 18:26:36 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:26:36 --> Controller Class Initialized
INFO - 2024-02-16 18:26:36 --> Form Validation Class Initialized
INFO - 2024-02-16 18:26:36 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:26:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:26:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:26:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:26:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:26:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:26:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:26:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:26:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:26:36 --> Final output sent to browser
DEBUG - 2024-02-16 18:26:36 --> Total execution time: 0.0150
ERROR - 2024-02-16 18:26:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:26:37 --> Config Class Initialized
INFO - 2024-02-16 18:26:37 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:26:37 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:26:37 --> Utf8 Class Initialized
INFO - 2024-02-16 18:26:37 --> URI Class Initialized
INFO - 2024-02-16 18:26:37 --> Router Class Initialized
INFO - 2024-02-16 18:26:37 --> Output Class Initialized
INFO - 2024-02-16 18:26:37 --> Security Class Initialized
DEBUG - 2024-02-16 18:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:26:37 --> Input Class Initialized
INFO - 2024-02-16 18:26:37 --> Language Class Initialized
INFO - 2024-02-16 18:26:37 --> Loader Class Initialized
INFO - 2024-02-16 18:26:37 --> Helper loaded: url_helper
INFO - 2024-02-16 18:26:37 --> Helper loaded: file_helper
INFO - 2024-02-16 18:26:37 --> Helper loaded: form_helper
INFO - 2024-02-16 18:26:37 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:26:37 --> Controller Class Initialized
INFO - 2024-02-16 18:26:37 --> Form Validation Class Initialized
INFO - 2024-02-16 18:26:37 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:26:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:26:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:26:37 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:26:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:26:39 --> Config Class Initialized
INFO - 2024-02-16 18:26:39 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:26:39 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:26:39 --> Utf8 Class Initialized
INFO - 2024-02-16 18:26:39 --> URI Class Initialized
INFO - 2024-02-16 18:26:39 --> Router Class Initialized
INFO - 2024-02-16 18:26:39 --> Output Class Initialized
INFO - 2024-02-16 18:26:39 --> Security Class Initialized
DEBUG - 2024-02-16 18:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:26:39 --> Input Class Initialized
INFO - 2024-02-16 18:26:39 --> Language Class Initialized
INFO - 2024-02-16 18:26:39 --> Loader Class Initialized
INFO - 2024-02-16 18:26:39 --> Helper loaded: url_helper
INFO - 2024-02-16 18:26:39 --> Helper loaded: file_helper
INFO - 2024-02-16 18:26:39 --> Helper loaded: form_helper
INFO - 2024-02-16 18:26:39 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:26:39 --> Controller Class Initialized
INFO - 2024-02-16 18:26:39 --> Form Validation Class Initialized
INFO - 2024-02-16 18:26:39 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:26:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:26:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:26:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:26:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:26:39 --> Final output sent to browser
DEBUG - 2024-02-16 18:26:39 --> Total execution time: 0.0141
ERROR - 2024-02-16 18:29:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:29:31 --> Config Class Initialized
INFO - 2024-02-16 18:29:31 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:29:31 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:29:31 --> Utf8 Class Initialized
INFO - 2024-02-16 18:29:31 --> URI Class Initialized
INFO - 2024-02-16 18:29:31 --> Router Class Initialized
INFO - 2024-02-16 18:29:31 --> Output Class Initialized
INFO - 2024-02-16 18:29:31 --> Security Class Initialized
DEBUG - 2024-02-16 18:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:29:31 --> Input Class Initialized
INFO - 2024-02-16 18:29:31 --> Language Class Initialized
INFO - 2024-02-16 18:29:31 --> Loader Class Initialized
INFO - 2024-02-16 18:29:31 --> Helper loaded: url_helper
INFO - 2024-02-16 18:29:31 --> Helper loaded: file_helper
INFO - 2024-02-16 18:29:31 --> Helper loaded: form_helper
INFO - 2024-02-16 18:29:31 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:29:31 --> Controller Class Initialized
INFO - 2024-02-16 18:29:31 --> Form Validation Class Initialized
INFO - 2024-02-16 18:29:31 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:29:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:29:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:29:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:29:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:29:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:29:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:29:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:29:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:29:31 --> Final output sent to browser
DEBUG - 2024-02-16 18:29:31 --> Total execution time: 0.0163
ERROR - 2024-02-16 18:29:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:29:32 --> Config Class Initialized
INFO - 2024-02-16 18:29:32 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:29:32 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:29:32 --> Utf8 Class Initialized
INFO - 2024-02-16 18:29:32 --> URI Class Initialized
INFO - 2024-02-16 18:29:32 --> Router Class Initialized
INFO - 2024-02-16 18:29:32 --> Output Class Initialized
INFO - 2024-02-16 18:29:32 --> Security Class Initialized
DEBUG - 2024-02-16 18:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:29:32 --> Input Class Initialized
INFO - 2024-02-16 18:29:32 --> Language Class Initialized
INFO - 2024-02-16 18:29:32 --> Loader Class Initialized
INFO - 2024-02-16 18:29:32 --> Helper loaded: url_helper
INFO - 2024-02-16 18:29:32 --> Helper loaded: file_helper
INFO - 2024-02-16 18:29:32 --> Helper loaded: form_helper
INFO - 2024-02-16 18:29:32 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:29:32 --> Controller Class Initialized
INFO - 2024-02-16 18:29:32 --> Form Validation Class Initialized
INFO - 2024-02-16 18:29:32 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:29:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:29:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:29:32 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:29:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:29:34 --> Config Class Initialized
INFO - 2024-02-16 18:29:34 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:29:34 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:29:34 --> Utf8 Class Initialized
INFO - 2024-02-16 18:29:34 --> URI Class Initialized
INFO - 2024-02-16 18:29:34 --> Router Class Initialized
INFO - 2024-02-16 18:29:34 --> Output Class Initialized
INFO - 2024-02-16 18:29:34 --> Security Class Initialized
DEBUG - 2024-02-16 18:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:29:34 --> Input Class Initialized
INFO - 2024-02-16 18:29:34 --> Language Class Initialized
INFO - 2024-02-16 18:29:34 --> Loader Class Initialized
INFO - 2024-02-16 18:29:34 --> Helper loaded: url_helper
INFO - 2024-02-16 18:29:34 --> Helper loaded: file_helper
INFO - 2024-02-16 18:29:34 --> Helper loaded: form_helper
INFO - 2024-02-16 18:29:34 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:29:34 --> Controller Class Initialized
INFO - 2024-02-16 18:29:34 --> Form Validation Class Initialized
INFO - 2024-02-16 18:29:34 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:29:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:29:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:29:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:29:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:29:34 --> Final output sent to browser
DEBUG - 2024-02-16 18:29:34 --> Total execution time: 0.0150
ERROR - 2024-02-16 18:50:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:50:15 --> Config Class Initialized
INFO - 2024-02-16 18:50:15 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:50:15 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:50:15 --> Utf8 Class Initialized
INFO - 2024-02-16 18:50:15 --> URI Class Initialized
INFO - 2024-02-16 18:50:15 --> Router Class Initialized
INFO - 2024-02-16 18:50:15 --> Output Class Initialized
INFO - 2024-02-16 18:50:15 --> Security Class Initialized
DEBUG - 2024-02-16 18:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:50:15 --> Input Class Initialized
INFO - 2024-02-16 18:50:15 --> Language Class Initialized
INFO - 2024-02-16 18:50:15 --> Loader Class Initialized
INFO - 2024-02-16 18:50:15 --> Helper loaded: url_helper
INFO - 2024-02-16 18:50:15 --> Helper loaded: file_helper
INFO - 2024-02-16 18:50:15 --> Helper loaded: form_helper
INFO - 2024-02-16 18:50:15 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:50:15 --> Controller Class Initialized
INFO - 2024-02-16 18:50:15 --> Form Validation Class Initialized
INFO - 2024-02-16 18:50:15 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:50:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:50:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:50:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:50:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:50:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:50:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:50:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:50:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:50:15 --> Final output sent to browser
DEBUG - 2024-02-16 18:50:15 --> Total execution time: 0.0294
ERROR - 2024-02-16 18:50:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:50:16 --> Config Class Initialized
INFO - 2024-02-16 18:50:16 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:50:16 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:50:16 --> Utf8 Class Initialized
INFO - 2024-02-16 18:50:16 --> URI Class Initialized
INFO - 2024-02-16 18:50:16 --> Router Class Initialized
INFO - 2024-02-16 18:50:16 --> Output Class Initialized
INFO - 2024-02-16 18:50:16 --> Security Class Initialized
DEBUG - 2024-02-16 18:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:50:16 --> Input Class Initialized
INFO - 2024-02-16 18:50:16 --> Language Class Initialized
INFO - 2024-02-16 18:50:16 --> Loader Class Initialized
INFO - 2024-02-16 18:50:16 --> Helper loaded: url_helper
INFO - 2024-02-16 18:50:16 --> Helper loaded: file_helper
INFO - 2024-02-16 18:50:16 --> Helper loaded: form_helper
INFO - 2024-02-16 18:50:16 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:50:16 --> Controller Class Initialized
INFO - 2024-02-16 18:50:16 --> Form Validation Class Initialized
INFO - 2024-02-16 18:50:16 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:50:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:50:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:50:16 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:50:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:50:19 --> Config Class Initialized
INFO - 2024-02-16 18:50:19 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:50:19 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:50:19 --> Utf8 Class Initialized
INFO - 2024-02-16 18:50:19 --> URI Class Initialized
INFO - 2024-02-16 18:50:19 --> Router Class Initialized
INFO - 2024-02-16 18:50:19 --> Output Class Initialized
INFO - 2024-02-16 18:50:19 --> Security Class Initialized
DEBUG - 2024-02-16 18:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:50:19 --> Input Class Initialized
INFO - 2024-02-16 18:50:19 --> Language Class Initialized
INFO - 2024-02-16 18:50:19 --> Loader Class Initialized
INFO - 2024-02-16 18:50:19 --> Helper loaded: url_helper
INFO - 2024-02-16 18:50:19 --> Helper loaded: file_helper
INFO - 2024-02-16 18:50:19 --> Helper loaded: form_helper
INFO - 2024-02-16 18:50:19 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:50:19 --> Controller Class Initialized
INFO - 2024-02-16 18:50:19 --> Form Validation Class Initialized
INFO - 2024-02-16 18:50:19 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:50:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:50:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:50:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:50:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:50:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:50:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:50:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:50:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:50:19 --> Final output sent to browser
DEBUG - 2024-02-16 18:50:19 --> Total execution time: 0.0277
ERROR - 2024-02-16 18:50:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:50:19 --> Config Class Initialized
INFO - 2024-02-16 18:50:19 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:50:19 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:50:19 --> Utf8 Class Initialized
INFO - 2024-02-16 18:50:19 --> URI Class Initialized
INFO - 2024-02-16 18:50:19 --> Router Class Initialized
INFO - 2024-02-16 18:50:19 --> Output Class Initialized
INFO - 2024-02-16 18:50:19 --> Security Class Initialized
DEBUG - 2024-02-16 18:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:50:19 --> Input Class Initialized
INFO - 2024-02-16 18:50:19 --> Language Class Initialized
INFO - 2024-02-16 18:50:19 --> Loader Class Initialized
INFO - 2024-02-16 18:50:19 --> Helper loaded: url_helper
INFO - 2024-02-16 18:50:19 --> Helper loaded: file_helper
INFO - 2024-02-16 18:50:19 --> Helper loaded: form_helper
INFO - 2024-02-16 18:50:19 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:50:19 --> Controller Class Initialized
INFO - 2024-02-16 18:50:19 --> Form Validation Class Initialized
INFO - 2024-02-16 18:50:19 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:50:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:50:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:50:19 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:50:21 --> Config Class Initialized
INFO - 2024-02-16 18:50:21 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:50:21 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:50:21 --> Utf8 Class Initialized
INFO - 2024-02-16 18:50:21 --> URI Class Initialized
INFO - 2024-02-16 18:50:21 --> Router Class Initialized
INFO - 2024-02-16 18:50:21 --> Output Class Initialized
INFO - 2024-02-16 18:50:21 --> Security Class Initialized
DEBUG - 2024-02-16 18:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:50:21 --> Input Class Initialized
INFO - 2024-02-16 18:50:21 --> Language Class Initialized
INFO - 2024-02-16 18:50:21 --> Loader Class Initialized
INFO - 2024-02-16 18:50:21 --> Helper loaded: url_helper
INFO - 2024-02-16 18:50:21 --> Helper loaded: file_helper
INFO - 2024-02-16 18:50:21 --> Helper loaded: form_helper
INFO - 2024-02-16 18:50:21 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:50:21 --> Controller Class Initialized
INFO - 2024-02-16 18:50:21 --> Form Validation Class Initialized
INFO - 2024-02-16 18:50:21 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:50:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:50:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:50:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:50:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:50:21 --> Final output sent to browser
DEBUG - 2024-02-16 18:50:21 --> Total execution time: 0.0275
ERROR - 2024-02-16 18:53:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:53:26 --> Config Class Initialized
INFO - 2024-02-16 18:53:26 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:53:26 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:53:26 --> Utf8 Class Initialized
INFO - 2024-02-16 18:53:26 --> URI Class Initialized
INFO - 2024-02-16 18:53:26 --> Router Class Initialized
INFO - 2024-02-16 18:53:26 --> Output Class Initialized
INFO - 2024-02-16 18:53:26 --> Security Class Initialized
DEBUG - 2024-02-16 18:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:53:26 --> Input Class Initialized
INFO - 2024-02-16 18:53:26 --> Language Class Initialized
INFO - 2024-02-16 18:53:26 --> Loader Class Initialized
INFO - 2024-02-16 18:53:26 --> Helper loaded: url_helper
INFO - 2024-02-16 18:53:26 --> Helper loaded: file_helper
INFO - 2024-02-16 18:53:26 --> Helper loaded: form_helper
INFO - 2024-02-16 18:53:26 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:53:26 --> Controller Class Initialized
INFO - 2024-02-16 18:53:26 --> Form Validation Class Initialized
INFO - 2024-02-16 18:53:26 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:53:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:53:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:53:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:53:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:53:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:53:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:53:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:53:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:53:26 --> Final output sent to browser
DEBUG - 2024-02-16 18:53:26 --> Total execution time: 0.0336
ERROR - 2024-02-16 18:53:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:53:26 --> Config Class Initialized
INFO - 2024-02-16 18:53:26 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:53:26 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:53:26 --> Utf8 Class Initialized
INFO - 2024-02-16 18:53:26 --> URI Class Initialized
INFO - 2024-02-16 18:53:26 --> Router Class Initialized
INFO - 2024-02-16 18:53:26 --> Output Class Initialized
INFO - 2024-02-16 18:53:26 --> Security Class Initialized
DEBUG - 2024-02-16 18:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:53:26 --> Input Class Initialized
INFO - 2024-02-16 18:53:26 --> Language Class Initialized
INFO - 2024-02-16 18:53:26 --> Loader Class Initialized
INFO - 2024-02-16 18:53:26 --> Helper loaded: url_helper
INFO - 2024-02-16 18:53:26 --> Helper loaded: file_helper
INFO - 2024-02-16 18:53:26 --> Helper loaded: form_helper
INFO - 2024-02-16 18:53:26 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:53:26 --> Controller Class Initialized
INFO - 2024-02-16 18:53:26 --> Form Validation Class Initialized
INFO - 2024-02-16 18:53:26 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:53:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:53:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:53:26 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:53:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:53:28 --> Config Class Initialized
INFO - 2024-02-16 18:53:28 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:53:28 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:53:28 --> Utf8 Class Initialized
INFO - 2024-02-16 18:53:28 --> URI Class Initialized
INFO - 2024-02-16 18:53:28 --> Router Class Initialized
INFO - 2024-02-16 18:53:28 --> Output Class Initialized
INFO - 2024-02-16 18:53:28 --> Security Class Initialized
DEBUG - 2024-02-16 18:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:53:28 --> Input Class Initialized
INFO - 2024-02-16 18:53:28 --> Language Class Initialized
INFO - 2024-02-16 18:53:28 --> Loader Class Initialized
INFO - 2024-02-16 18:53:28 --> Helper loaded: url_helper
INFO - 2024-02-16 18:53:28 --> Helper loaded: file_helper
INFO - 2024-02-16 18:53:28 --> Helper loaded: form_helper
INFO - 2024-02-16 18:53:28 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:53:28 --> Controller Class Initialized
INFO - 2024-02-16 18:53:28 --> Form Validation Class Initialized
INFO - 2024-02-16 18:53:28 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:53:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:53:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:53:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:53:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:53:28 --> Final output sent to browser
DEBUG - 2024-02-16 18:53:28 --> Total execution time: 0.0302
ERROR - 2024-02-16 18:54:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:54:33 --> Config Class Initialized
INFO - 2024-02-16 18:54:33 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:54:33 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:54:33 --> Utf8 Class Initialized
INFO - 2024-02-16 18:54:33 --> URI Class Initialized
INFO - 2024-02-16 18:54:33 --> Router Class Initialized
INFO - 2024-02-16 18:54:33 --> Output Class Initialized
INFO - 2024-02-16 18:54:33 --> Security Class Initialized
DEBUG - 2024-02-16 18:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:54:33 --> Input Class Initialized
INFO - 2024-02-16 18:54:33 --> Language Class Initialized
INFO - 2024-02-16 18:54:33 --> Loader Class Initialized
INFO - 2024-02-16 18:54:33 --> Helper loaded: url_helper
INFO - 2024-02-16 18:54:33 --> Helper loaded: file_helper
INFO - 2024-02-16 18:54:33 --> Helper loaded: form_helper
INFO - 2024-02-16 18:54:33 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:54:33 --> Controller Class Initialized
INFO - 2024-02-16 18:54:33 --> Form Validation Class Initialized
INFO - 2024-02-16 18:54:33 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:54:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:54:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:54:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:54:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:54:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:54:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:54:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:54:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:54:33 --> Final output sent to browser
DEBUG - 2024-02-16 18:54:33 --> Total execution time: 0.0306
ERROR - 2024-02-16 18:54:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:54:34 --> Config Class Initialized
INFO - 2024-02-16 18:54:34 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:54:34 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:54:34 --> Utf8 Class Initialized
INFO - 2024-02-16 18:54:34 --> URI Class Initialized
INFO - 2024-02-16 18:54:34 --> Router Class Initialized
INFO - 2024-02-16 18:54:34 --> Output Class Initialized
INFO - 2024-02-16 18:54:34 --> Security Class Initialized
DEBUG - 2024-02-16 18:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:54:34 --> Input Class Initialized
INFO - 2024-02-16 18:54:34 --> Language Class Initialized
INFO - 2024-02-16 18:54:34 --> Loader Class Initialized
INFO - 2024-02-16 18:54:34 --> Helper loaded: url_helper
INFO - 2024-02-16 18:54:34 --> Helper loaded: file_helper
INFO - 2024-02-16 18:54:34 --> Helper loaded: form_helper
INFO - 2024-02-16 18:54:34 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:54:34 --> Controller Class Initialized
INFO - 2024-02-16 18:54:34 --> Form Validation Class Initialized
INFO - 2024-02-16 18:54:34 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:54:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:54:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:54:34 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:54:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:54:36 --> Config Class Initialized
INFO - 2024-02-16 18:54:36 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:54:36 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:54:36 --> Utf8 Class Initialized
INFO - 2024-02-16 18:54:36 --> URI Class Initialized
INFO - 2024-02-16 18:54:36 --> Router Class Initialized
INFO - 2024-02-16 18:54:36 --> Output Class Initialized
INFO - 2024-02-16 18:54:36 --> Security Class Initialized
DEBUG - 2024-02-16 18:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:54:36 --> Input Class Initialized
INFO - 2024-02-16 18:54:36 --> Language Class Initialized
INFO - 2024-02-16 18:54:36 --> Loader Class Initialized
INFO - 2024-02-16 18:54:36 --> Helper loaded: url_helper
INFO - 2024-02-16 18:54:36 --> Helper loaded: file_helper
INFO - 2024-02-16 18:54:36 --> Helper loaded: form_helper
INFO - 2024-02-16 18:54:36 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:54:36 --> Controller Class Initialized
INFO - 2024-02-16 18:54:36 --> Form Validation Class Initialized
INFO - 2024-02-16 18:54:36 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:54:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:54:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:54:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:54:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:54:36 --> Final output sent to browser
DEBUG - 2024-02-16 18:54:36 --> Total execution time: 0.0324
ERROR - 2024-02-16 18:56:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:56:05 --> Config Class Initialized
INFO - 2024-02-16 18:56:05 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:56:05 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:56:05 --> Utf8 Class Initialized
INFO - 2024-02-16 18:56:05 --> URI Class Initialized
INFO - 2024-02-16 18:56:05 --> Router Class Initialized
INFO - 2024-02-16 18:56:05 --> Output Class Initialized
INFO - 2024-02-16 18:56:05 --> Security Class Initialized
DEBUG - 2024-02-16 18:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:56:05 --> Input Class Initialized
INFO - 2024-02-16 18:56:05 --> Language Class Initialized
INFO - 2024-02-16 18:56:05 --> Loader Class Initialized
INFO - 2024-02-16 18:56:05 --> Helper loaded: url_helper
INFO - 2024-02-16 18:56:05 --> Helper loaded: file_helper
INFO - 2024-02-16 18:56:05 --> Helper loaded: form_helper
INFO - 2024-02-16 18:56:05 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:56:05 --> Controller Class Initialized
INFO - 2024-02-16 18:56:05 --> Form Validation Class Initialized
INFO - 2024-02-16 18:56:05 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:56:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:56:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:56:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:56:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:56:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:56:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:56:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:56:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:56:05 --> Final output sent to browser
DEBUG - 2024-02-16 18:56:05 --> Total execution time: 0.0407
ERROR - 2024-02-16 18:56:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:56:05 --> Config Class Initialized
INFO - 2024-02-16 18:56:05 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:56:05 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:56:05 --> Utf8 Class Initialized
INFO - 2024-02-16 18:56:05 --> URI Class Initialized
INFO - 2024-02-16 18:56:05 --> Router Class Initialized
INFO - 2024-02-16 18:56:05 --> Output Class Initialized
INFO - 2024-02-16 18:56:05 --> Security Class Initialized
DEBUG - 2024-02-16 18:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:56:05 --> Input Class Initialized
INFO - 2024-02-16 18:56:05 --> Language Class Initialized
INFO - 2024-02-16 18:56:05 --> Loader Class Initialized
INFO - 2024-02-16 18:56:05 --> Helper loaded: url_helper
INFO - 2024-02-16 18:56:05 --> Helper loaded: file_helper
INFO - 2024-02-16 18:56:05 --> Helper loaded: form_helper
INFO - 2024-02-16 18:56:05 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:56:05 --> Controller Class Initialized
INFO - 2024-02-16 18:56:05 --> Form Validation Class Initialized
INFO - 2024-02-16 18:56:05 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:56:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:56:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:56:05 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:56:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:56:07 --> Config Class Initialized
INFO - 2024-02-16 18:56:07 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:56:07 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:56:07 --> Utf8 Class Initialized
INFO - 2024-02-16 18:56:07 --> URI Class Initialized
INFO - 2024-02-16 18:56:07 --> Router Class Initialized
INFO - 2024-02-16 18:56:07 --> Output Class Initialized
INFO - 2024-02-16 18:56:07 --> Security Class Initialized
DEBUG - 2024-02-16 18:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:56:07 --> Input Class Initialized
INFO - 2024-02-16 18:56:07 --> Language Class Initialized
INFO - 2024-02-16 18:56:07 --> Loader Class Initialized
INFO - 2024-02-16 18:56:07 --> Helper loaded: url_helper
INFO - 2024-02-16 18:56:07 --> Helper loaded: file_helper
INFO - 2024-02-16 18:56:07 --> Helper loaded: form_helper
INFO - 2024-02-16 18:56:07 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:56:07 --> Controller Class Initialized
INFO - 2024-02-16 18:56:07 --> Form Validation Class Initialized
INFO - 2024-02-16 18:56:07 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:56:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:56:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:56:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:56:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:56:07 --> Final output sent to browser
DEBUG - 2024-02-16 18:56:07 --> Total execution time: 0.0326
ERROR - 2024-02-16 18:56:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:56:37 --> Config Class Initialized
INFO - 2024-02-16 18:56:37 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:56:37 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:56:37 --> Utf8 Class Initialized
INFO - 2024-02-16 18:56:37 --> URI Class Initialized
INFO - 2024-02-16 18:56:37 --> Router Class Initialized
INFO - 2024-02-16 18:56:37 --> Output Class Initialized
INFO - 2024-02-16 18:56:37 --> Security Class Initialized
DEBUG - 2024-02-16 18:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:56:37 --> Input Class Initialized
INFO - 2024-02-16 18:56:37 --> Language Class Initialized
INFO - 2024-02-16 18:56:37 --> Loader Class Initialized
INFO - 2024-02-16 18:56:37 --> Helper loaded: url_helper
INFO - 2024-02-16 18:56:37 --> Helper loaded: file_helper
INFO - 2024-02-16 18:56:37 --> Helper loaded: form_helper
INFO - 2024-02-16 18:56:37 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:56:37 --> Controller Class Initialized
INFO - 2024-02-16 18:56:37 --> Form Validation Class Initialized
INFO - 2024-02-16 18:56:37 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:56:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:56:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:56:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:56:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:56:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:56:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:56:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:56:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:56:37 --> Final output sent to browser
DEBUG - 2024-02-16 18:56:37 --> Total execution time: 0.0252
ERROR - 2024-02-16 18:56:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:56:37 --> Config Class Initialized
INFO - 2024-02-16 18:56:37 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:56:37 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:56:37 --> Utf8 Class Initialized
INFO - 2024-02-16 18:56:37 --> URI Class Initialized
INFO - 2024-02-16 18:56:37 --> Router Class Initialized
INFO - 2024-02-16 18:56:37 --> Output Class Initialized
INFO - 2024-02-16 18:56:37 --> Security Class Initialized
DEBUG - 2024-02-16 18:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:56:37 --> Input Class Initialized
INFO - 2024-02-16 18:56:37 --> Language Class Initialized
INFO - 2024-02-16 18:56:37 --> Loader Class Initialized
INFO - 2024-02-16 18:56:37 --> Helper loaded: url_helper
INFO - 2024-02-16 18:56:38 --> Helper loaded: file_helper
INFO - 2024-02-16 18:56:38 --> Helper loaded: form_helper
INFO - 2024-02-16 18:56:38 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:56:38 --> Controller Class Initialized
INFO - 2024-02-16 18:56:38 --> Form Validation Class Initialized
INFO - 2024-02-16 18:56:38 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:56:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:56:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:56:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:56:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:56:41 --> Config Class Initialized
INFO - 2024-02-16 18:56:41 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:56:41 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:56:41 --> Utf8 Class Initialized
INFO - 2024-02-16 18:56:41 --> URI Class Initialized
INFO - 2024-02-16 18:56:41 --> Router Class Initialized
INFO - 2024-02-16 18:56:41 --> Output Class Initialized
INFO - 2024-02-16 18:56:41 --> Security Class Initialized
DEBUG - 2024-02-16 18:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:56:41 --> Input Class Initialized
INFO - 2024-02-16 18:56:41 --> Language Class Initialized
INFO - 2024-02-16 18:56:41 --> Loader Class Initialized
INFO - 2024-02-16 18:56:41 --> Helper loaded: url_helper
INFO - 2024-02-16 18:56:41 --> Helper loaded: file_helper
INFO - 2024-02-16 18:56:41 --> Helper loaded: form_helper
INFO - 2024-02-16 18:56:41 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:56:41 --> Controller Class Initialized
INFO - 2024-02-16 18:56:41 --> Form Validation Class Initialized
INFO - 2024-02-16 18:56:41 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:56:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:56:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:56:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:56:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:56:41 --> Final output sent to browser
DEBUG - 2024-02-16 18:56:41 --> Total execution time: 0.0381
ERROR - 2024-02-16 18:58:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:58:11 --> Config Class Initialized
INFO - 2024-02-16 18:58:11 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:58:11 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:58:11 --> Utf8 Class Initialized
INFO - 2024-02-16 18:58:11 --> URI Class Initialized
INFO - 2024-02-16 18:58:11 --> Router Class Initialized
INFO - 2024-02-16 18:58:11 --> Output Class Initialized
INFO - 2024-02-16 18:58:11 --> Security Class Initialized
DEBUG - 2024-02-16 18:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:58:11 --> Input Class Initialized
INFO - 2024-02-16 18:58:11 --> Language Class Initialized
INFO - 2024-02-16 18:58:11 --> Loader Class Initialized
INFO - 2024-02-16 18:58:11 --> Helper loaded: url_helper
INFO - 2024-02-16 18:58:11 --> Helper loaded: file_helper
INFO - 2024-02-16 18:58:11 --> Helper loaded: form_helper
INFO - 2024-02-16 18:58:11 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:58:11 --> Controller Class Initialized
INFO - 2024-02-16 18:58:11 --> Form Validation Class Initialized
INFO - 2024-02-16 18:58:11 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:58:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:58:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:58:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:58:11 --> Final output sent to browser
DEBUG - 2024-02-16 18:58:11 --> Total execution time: 0.0306
ERROR - 2024-02-16 18:58:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:58:12 --> Config Class Initialized
INFO - 2024-02-16 18:58:12 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:58:12 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:58:12 --> Utf8 Class Initialized
INFO - 2024-02-16 18:58:12 --> URI Class Initialized
INFO - 2024-02-16 18:58:12 --> Router Class Initialized
INFO - 2024-02-16 18:58:12 --> Output Class Initialized
INFO - 2024-02-16 18:58:12 --> Security Class Initialized
DEBUG - 2024-02-16 18:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:58:12 --> Input Class Initialized
INFO - 2024-02-16 18:58:12 --> Language Class Initialized
INFO - 2024-02-16 18:58:12 --> Loader Class Initialized
INFO - 2024-02-16 18:58:12 --> Helper loaded: url_helper
INFO - 2024-02-16 18:58:12 --> Helper loaded: file_helper
INFO - 2024-02-16 18:58:12 --> Helper loaded: form_helper
INFO - 2024-02-16 18:58:12 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:58:12 --> Controller Class Initialized
INFO - 2024-02-16 18:58:12 --> Form Validation Class Initialized
INFO - 2024-02-16 18:58:12 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:58:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:58:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:58:12 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:58:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:58:14 --> Config Class Initialized
INFO - 2024-02-16 18:58:14 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:58:14 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:58:14 --> Utf8 Class Initialized
INFO - 2024-02-16 18:58:14 --> URI Class Initialized
INFO - 2024-02-16 18:58:14 --> Router Class Initialized
INFO - 2024-02-16 18:58:14 --> Output Class Initialized
INFO - 2024-02-16 18:58:14 --> Security Class Initialized
DEBUG - 2024-02-16 18:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:58:14 --> Input Class Initialized
INFO - 2024-02-16 18:58:14 --> Language Class Initialized
INFO - 2024-02-16 18:58:14 --> Loader Class Initialized
INFO - 2024-02-16 18:58:14 --> Helper loaded: url_helper
INFO - 2024-02-16 18:58:14 --> Helper loaded: file_helper
INFO - 2024-02-16 18:58:14 --> Helper loaded: form_helper
INFO - 2024-02-16 18:58:14 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:58:14 --> Controller Class Initialized
INFO - 2024-02-16 18:58:14 --> Form Validation Class Initialized
INFO - 2024-02-16 18:58:14 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:58:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:58:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:58:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:58:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:58:14 --> Final output sent to browser
DEBUG - 2024-02-16 18:58:14 --> Total execution time: 0.0356
ERROR - 2024-02-16 18:58:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:58:24 --> Config Class Initialized
INFO - 2024-02-16 18:58:24 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:58:24 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:58:24 --> Utf8 Class Initialized
INFO - 2024-02-16 18:58:24 --> URI Class Initialized
INFO - 2024-02-16 18:58:24 --> Router Class Initialized
INFO - 2024-02-16 18:58:24 --> Output Class Initialized
INFO - 2024-02-16 18:58:24 --> Security Class Initialized
DEBUG - 2024-02-16 18:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:58:24 --> Input Class Initialized
INFO - 2024-02-16 18:58:24 --> Language Class Initialized
INFO - 2024-02-16 18:58:24 --> Loader Class Initialized
INFO - 2024-02-16 18:58:24 --> Helper loaded: url_helper
INFO - 2024-02-16 18:58:24 --> Helper loaded: file_helper
INFO - 2024-02-16 18:58:24 --> Helper loaded: form_helper
INFO - 2024-02-16 18:58:24 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:58:24 --> Controller Class Initialized
INFO - 2024-02-16 18:58:24 --> Form Validation Class Initialized
INFO - 2024-02-16 18:58:24 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:58:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:58:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:58:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:58:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 18:58:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 18:58:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 18:58:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 18:58:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 18:58:24 --> Final output sent to browser
DEBUG - 2024-02-16 18:58:24 --> Total execution time: 0.0439
ERROR - 2024-02-16 18:58:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:58:24 --> Config Class Initialized
INFO - 2024-02-16 18:58:24 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:58:24 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:58:24 --> Utf8 Class Initialized
INFO - 2024-02-16 18:58:24 --> URI Class Initialized
INFO - 2024-02-16 18:58:24 --> Router Class Initialized
INFO - 2024-02-16 18:58:24 --> Output Class Initialized
INFO - 2024-02-16 18:58:24 --> Security Class Initialized
DEBUG - 2024-02-16 18:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:58:24 --> Input Class Initialized
INFO - 2024-02-16 18:58:24 --> Language Class Initialized
INFO - 2024-02-16 18:58:24 --> Loader Class Initialized
INFO - 2024-02-16 18:58:24 --> Helper loaded: url_helper
INFO - 2024-02-16 18:58:24 --> Helper loaded: file_helper
INFO - 2024-02-16 18:58:24 --> Helper loaded: form_helper
INFO - 2024-02-16 18:58:24 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:58:24 --> Controller Class Initialized
INFO - 2024-02-16 18:58:24 --> Form Validation Class Initialized
INFO - 2024-02-16 18:58:24 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:58:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:58:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:58:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 18:58:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 18:58:27 --> Config Class Initialized
INFO - 2024-02-16 18:58:27 --> Hooks Class Initialized
DEBUG - 2024-02-16 18:58:27 --> UTF-8 Support Enabled
INFO - 2024-02-16 18:58:27 --> Utf8 Class Initialized
INFO - 2024-02-16 18:58:27 --> URI Class Initialized
INFO - 2024-02-16 18:58:27 --> Router Class Initialized
INFO - 2024-02-16 18:58:27 --> Output Class Initialized
INFO - 2024-02-16 18:58:27 --> Security Class Initialized
DEBUG - 2024-02-16 18:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 18:58:27 --> Input Class Initialized
INFO - 2024-02-16 18:58:27 --> Language Class Initialized
INFO - 2024-02-16 18:58:27 --> Loader Class Initialized
INFO - 2024-02-16 18:58:27 --> Helper loaded: url_helper
INFO - 2024-02-16 18:58:27 --> Helper loaded: file_helper
INFO - 2024-02-16 18:58:27 --> Helper loaded: form_helper
INFO - 2024-02-16 18:58:27 --> Database Driver Class Initialized
DEBUG - 2024-02-16 18:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 18:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 18:58:27 --> Controller Class Initialized
INFO - 2024-02-16 18:58:27 --> Form Validation Class Initialized
INFO - 2024-02-16 18:58:27 --> Model "MasterModel" initialized
INFO - 2024-02-16 18:58:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 18:58:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 18:58:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 18:58:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 18:58:27 --> Final output sent to browser
DEBUG - 2024-02-16 18:58:27 --> Total execution time: 0.0327
ERROR - 2024-02-16 19:01:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:01:45 --> Config Class Initialized
INFO - 2024-02-16 19:01:45 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:01:45 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:01:45 --> Utf8 Class Initialized
INFO - 2024-02-16 19:01:45 --> URI Class Initialized
INFO - 2024-02-16 19:01:45 --> Router Class Initialized
INFO - 2024-02-16 19:01:45 --> Output Class Initialized
INFO - 2024-02-16 19:01:45 --> Security Class Initialized
DEBUG - 2024-02-16 19:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:01:45 --> Input Class Initialized
INFO - 2024-02-16 19:01:45 --> Language Class Initialized
INFO - 2024-02-16 19:01:45 --> Loader Class Initialized
INFO - 2024-02-16 19:01:45 --> Helper loaded: url_helper
INFO - 2024-02-16 19:01:45 --> Helper loaded: file_helper
INFO - 2024-02-16 19:01:45 --> Helper loaded: form_helper
INFO - 2024-02-16 19:01:45 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:01:45 --> Controller Class Initialized
INFO - 2024-02-16 19:01:45 --> Form Validation Class Initialized
INFO - 2024-02-16 19:01:45 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:01:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:01:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:01:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 19:01:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 19:01:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 19:01:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 19:01:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 19:01:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 19:01:45 --> Final output sent to browser
DEBUG - 2024-02-16 19:01:45 --> Total execution time: 0.0328
ERROR - 2024-02-16 19:01:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:01:46 --> Config Class Initialized
INFO - 2024-02-16 19:01:46 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:01:46 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:01:46 --> Utf8 Class Initialized
INFO - 2024-02-16 19:01:46 --> URI Class Initialized
INFO - 2024-02-16 19:01:46 --> Router Class Initialized
INFO - 2024-02-16 19:01:46 --> Output Class Initialized
INFO - 2024-02-16 19:01:46 --> Security Class Initialized
DEBUG - 2024-02-16 19:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:01:46 --> Input Class Initialized
INFO - 2024-02-16 19:01:46 --> Language Class Initialized
INFO - 2024-02-16 19:01:46 --> Loader Class Initialized
INFO - 2024-02-16 19:01:46 --> Helper loaded: url_helper
INFO - 2024-02-16 19:01:46 --> Helper loaded: file_helper
INFO - 2024-02-16 19:01:46 --> Helper loaded: form_helper
INFO - 2024-02-16 19:01:46 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:01:46 --> Controller Class Initialized
INFO - 2024-02-16 19:01:46 --> Form Validation Class Initialized
INFO - 2024-02-16 19:01:46 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:01:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:01:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:01:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 19:01:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:01:48 --> Config Class Initialized
INFO - 2024-02-16 19:01:48 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:01:48 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:01:48 --> Utf8 Class Initialized
INFO - 2024-02-16 19:01:48 --> URI Class Initialized
INFO - 2024-02-16 19:01:48 --> Router Class Initialized
INFO - 2024-02-16 19:01:48 --> Output Class Initialized
INFO - 2024-02-16 19:01:48 --> Security Class Initialized
DEBUG - 2024-02-16 19:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:01:48 --> Input Class Initialized
INFO - 2024-02-16 19:01:48 --> Language Class Initialized
INFO - 2024-02-16 19:01:48 --> Loader Class Initialized
INFO - 2024-02-16 19:01:48 --> Helper loaded: url_helper
INFO - 2024-02-16 19:01:48 --> Helper loaded: file_helper
INFO - 2024-02-16 19:01:48 --> Helper loaded: form_helper
INFO - 2024-02-16 19:01:48 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:01:48 --> Controller Class Initialized
INFO - 2024-02-16 19:01:48 --> Form Validation Class Initialized
INFO - 2024-02-16 19:01:48 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:01:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:01:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:01:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 19:01:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 19:01:48 --> Final output sent to browser
DEBUG - 2024-02-16 19:01:48 --> Total execution time: 0.0403
ERROR - 2024-02-16 19:01:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:01:59 --> Config Class Initialized
INFO - 2024-02-16 19:01:59 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:01:59 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:01:59 --> Utf8 Class Initialized
INFO - 2024-02-16 19:01:59 --> URI Class Initialized
INFO - 2024-02-16 19:01:59 --> Router Class Initialized
INFO - 2024-02-16 19:01:59 --> Output Class Initialized
INFO - 2024-02-16 19:01:59 --> Security Class Initialized
DEBUG - 2024-02-16 19:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:01:59 --> Input Class Initialized
INFO - 2024-02-16 19:01:59 --> Language Class Initialized
INFO - 2024-02-16 19:01:59 --> Loader Class Initialized
INFO - 2024-02-16 19:01:59 --> Helper loaded: url_helper
INFO - 2024-02-16 19:01:59 --> Helper loaded: file_helper
INFO - 2024-02-16 19:01:59 --> Helper loaded: form_helper
INFO - 2024-02-16 19:01:59 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:01:59 --> Controller Class Initialized
INFO - 2024-02-16 19:01:59 --> Form Validation Class Initialized
INFO - 2024-02-16 19:01:59 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:01:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:01:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:01:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 19:01:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 19:01:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 19:01:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 19:01:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 19:01:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 19:01:59 --> Final output sent to browser
DEBUG - 2024-02-16 19:01:59 --> Total execution time: 0.0316
ERROR - 2024-02-16 19:01:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:01:59 --> Config Class Initialized
INFO - 2024-02-16 19:01:59 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:01:59 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:01:59 --> Utf8 Class Initialized
INFO - 2024-02-16 19:01:59 --> URI Class Initialized
INFO - 2024-02-16 19:01:59 --> Router Class Initialized
INFO - 2024-02-16 19:01:59 --> Output Class Initialized
INFO - 2024-02-16 19:01:59 --> Security Class Initialized
DEBUG - 2024-02-16 19:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:01:59 --> Input Class Initialized
INFO - 2024-02-16 19:01:59 --> Language Class Initialized
INFO - 2024-02-16 19:01:59 --> Loader Class Initialized
INFO - 2024-02-16 19:01:59 --> Helper loaded: url_helper
INFO - 2024-02-16 19:01:59 --> Helper loaded: file_helper
INFO - 2024-02-16 19:01:59 --> Helper loaded: form_helper
INFO - 2024-02-16 19:01:59 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:01:59 --> Controller Class Initialized
INFO - 2024-02-16 19:01:59 --> Form Validation Class Initialized
INFO - 2024-02-16 19:01:59 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:01:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:01:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:01:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 19:02:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:02:01 --> Config Class Initialized
INFO - 2024-02-16 19:02:01 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:02:01 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:02:01 --> Utf8 Class Initialized
INFO - 2024-02-16 19:02:01 --> URI Class Initialized
INFO - 2024-02-16 19:02:01 --> Router Class Initialized
INFO - 2024-02-16 19:02:01 --> Output Class Initialized
INFO - 2024-02-16 19:02:01 --> Security Class Initialized
DEBUG - 2024-02-16 19:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:02:01 --> Input Class Initialized
INFO - 2024-02-16 19:02:01 --> Language Class Initialized
INFO - 2024-02-16 19:02:01 --> Loader Class Initialized
INFO - 2024-02-16 19:02:01 --> Helper loaded: url_helper
INFO - 2024-02-16 19:02:01 --> Helper loaded: file_helper
INFO - 2024-02-16 19:02:01 --> Helper loaded: form_helper
INFO - 2024-02-16 19:02:01 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:02:01 --> Controller Class Initialized
INFO - 2024-02-16 19:02:01 --> Form Validation Class Initialized
INFO - 2024-02-16 19:02:01 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:02:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:02:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:02:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 19:02:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 19:02:01 --> Final output sent to browser
DEBUG - 2024-02-16 19:02:01 --> Total execution time: 0.0252
ERROR - 2024-02-16 19:02:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:02:22 --> Config Class Initialized
INFO - 2024-02-16 19:02:22 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:02:22 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:02:22 --> Utf8 Class Initialized
INFO - 2024-02-16 19:02:22 --> URI Class Initialized
INFO - 2024-02-16 19:02:22 --> Router Class Initialized
INFO - 2024-02-16 19:02:22 --> Output Class Initialized
INFO - 2024-02-16 19:02:22 --> Security Class Initialized
DEBUG - 2024-02-16 19:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:02:22 --> Input Class Initialized
INFO - 2024-02-16 19:02:22 --> Language Class Initialized
INFO - 2024-02-16 19:02:22 --> Loader Class Initialized
INFO - 2024-02-16 19:02:22 --> Helper loaded: url_helper
INFO - 2024-02-16 19:02:22 --> Helper loaded: file_helper
INFO - 2024-02-16 19:02:22 --> Helper loaded: form_helper
INFO - 2024-02-16 19:02:22 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:02:22 --> Controller Class Initialized
INFO - 2024-02-16 19:02:22 --> Form Validation Class Initialized
INFO - 2024-02-16 19:02:22 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:02:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:02:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:02:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 19:02:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 19:02:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 19:02:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 19:02:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 19:02:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 19:02:22 --> Final output sent to browser
DEBUG - 2024-02-16 19:02:22 --> Total execution time: 0.0386
ERROR - 2024-02-16 19:02:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:02:23 --> Config Class Initialized
INFO - 2024-02-16 19:02:23 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:02:23 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:02:23 --> Utf8 Class Initialized
INFO - 2024-02-16 19:02:23 --> URI Class Initialized
INFO - 2024-02-16 19:02:23 --> Router Class Initialized
INFO - 2024-02-16 19:02:23 --> Output Class Initialized
INFO - 2024-02-16 19:02:23 --> Security Class Initialized
DEBUG - 2024-02-16 19:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:02:23 --> Input Class Initialized
INFO - 2024-02-16 19:02:23 --> Language Class Initialized
INFO - 2024-02-16 19:02:23 --> Loader Class Initialized
INFO - 2024-02-16 19:02:23 --> Helper loaded: url_helper
INFO - 2024-02-16 19:02:23 --> Helper loaded: file_helper
INFO - 2024-02-16 19:02:23 --> Helper loaded: form_helper
INFO - 2024-02-16 19:02:23 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:02:23 --> Controller Class Initialized
INFO - 2024-02-16 19:02:23 --> Form Validation Class Initialized
INFO - 2024-02-16 19:02:23 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:02:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:02:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:02:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 19:02:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:02:25 --> Config Class Initialized
INFO - 2024-02-16 19:02:25 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:02:25 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:02:25 --> Utf8 Class Initialized
INFO - 2024-02-16 19:02:25 --> URI Class Initialized
INFO - 2024-02-16 19:02:25 --> Router Class Initialized
INFO - 2024-02-16 19:02:25 --> Output Class Initialized
INFO - 2024-02-16 19:02:25 --> Security Class Initialized
DEBUG - 2024-02-16 19:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:02:25 --> Input Class Initialized
INFO - 2024-02-16 19:02:25 --> Language Class Initialized
INFO - 2024-02-16 19:02:25 --> Loader Class Initialized
INFO - 2024-02-16 19:02:25 --> Helper loaded: url_helper
INFO - 2024-02-16 19:02:25 --> Helper loaded: file_helper
INFO - 2024-02-16 19:02:25 --> Helper loaded: form_helper
INFO - 2024-02-16 19:02:25 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:02:25 --> Controller Class Initialized
INFO - 2024-02-16 19:02:25 --> Form Validation Class Initialized
INFO - 2024-02-16 19:02:25 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:02:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:02:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:02:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 19:02:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 19:02:25 --> Final output sent to browser
DEBUG - 2024-02-16 19:02:25 --> Total execution time: 0.0397
ERROR - 2024-02-16 19:03:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:03:40 --> Config Class Initialized
INFO - 2024-02-16 19:03:40 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:03:40 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:03:40 --> Utf8 Class Initialized
INFO - 2024-02-16 19:03:40 --> URI Class Initialized
INFO - 2024-02-16 19:03:40 --> Router Class Initialized
INFO - 2024-02-16 19:03:40 --> Output Class Initialized
INFO - 2024-02-16 19:03:40 --> Security Class Initialized
DEBUG - 2024-02-16 19:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:03:40 --> Input Class Initialized
INFO - 2024-02-16 19:03:40 --> Language Class Initialized
INFO - 2024-02-16 19:03:40 --> Loader Class Initialized
INFO - 2024-02-16 19:03:40 --> Helper loaded: url_helper
INFO - 2024-02-16 19:03:40 --> Helper loaded: file_helper
INFO - 2024-02-16 19:03:40 --> Helper loaded: form_helper
INFO - 2024-02-16 19:03:40 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:03:40 --> Controller Class Initialized
INFO - 2024-02-16 19:03:40 --> Form Validation Class Initialized
INFO - 2024-02-16 19:03:40 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:03:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:03:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:03:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 19:03:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 19:03:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 19:03:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 19:03:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 19:03:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 19:03:40 --> Final output sent to browser
DEBUG - 2024-02-16 19:03:40 --> Total execution time: 0.0331
ERROR - 2024-02-16 19:03:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:03:41 --> Config Class Initialized
INFO - 2024-02-16 19:03:41 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:03:41 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:03:41 --> Utf8 Class Initialized
INFO - 2024-02-16 19:03:41 --> URI Class Initialized
INFO - 2024-02-16 19:03:41 --> Router Class Initialized
INFO - 2024-02-16 19:03:41 --> Output Class Initialized
INFO - 2024-02-16 19:03:41 --> Security Class Initialized
DEBUG - 2024-02-16 19:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:03:41 --> Input Class Initialized
INFO - 2024-02-16 19:03:41 --> Language Class Initialized
INFO - 2024-02-16 19:03:41 --> Loader Class Initialized
INFO - 2024-02-16 19:03:41 --> Helper loaded: url_helper
INFO - 2024-02-16 19:03:41 --> Helper loaded: file_helper
INFO - 2024-02-16 19:03:41 --> Helper loaded: form_helper
INFO - 2024-02-16 19:03:41 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:03:41 --> Controller Class Initialized
INFO - 2024-02-16 19:03:41 --> Form Validation Class Initialized
INFO - 2024-02-16 19:03:41 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:03:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:03:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:03:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 19:03:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:03:43 --> Config Class Initialized
INFO - 2024-02-16 19:03:43 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:03:43 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:03:43 --> Utf8 Class Initialized
INFO - 2024-02-16 19:03:43 --> URI Class Initialized
INFO - 2024-02-16 19:03:43 --> Router Class Initialized
INFO - 2024-02-16 19:03:43 --> Output Class Initialized
INFO - 2024-02-16 19:03:43 --> Security Class Initialized
DEBUG - 2024-02-16 19:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:03:43 --> Input Class Initialized
INFO - 2024-02-16 19:03:43 --> Language Class Initialized
INFO - 2024-02-16 19:03:43 --> Loader Class Initialized
INFO - 2024-02-16 19:03:43 --> Helper loaded: url_helper
INFO - 2024-02-16 19:03:43 --> Helper loaded: file_helper
INFO - 2024-02-16 19:03:43 --> Helper loaded: form_helper
INFO - 2024-02-16 19:03:43 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:03:43 --> Controller Class Initialized
INFO - 2024-02-16 19:03:43 --> Form Validation Class Initialized
INFO - 2024-02-16 19:03:43 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:03:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:03:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:03:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 19:03:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 19:03:43 --> Final output sent to browser
DEBUG - 2024-02-16 19:03:43 --> Total execution time: 0.0226
ERROR - 2024-02-16 19:03:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:03:57 --> Config Class Initialized
INFO - 2024-02-16 19:03:57 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:03:57 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:03:57 --> Utf8 Class Initialized
INFO - 2024-02-16 19:03:57 --> URI Class Initialized
INFO - 2024-02-16 19:03:57 --> Router Class Initialized
INFO - 2024-02-16 19:03:57 --> Output Class Initialized
INFO - 2024-02-16 19:03:57 --> Security Class Initialized
DEBUG - 2024-02-16 19:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:03:57 --> Input Class Initialized
INFO - 2024-02-16 19:03:57 --> Language Class Initialized
INFO - 2024-02-16 19:03:57 --> Loader Class Initialized
INFO - 2024-02-16 19:03:57 --> Helper loaded: url_helper
INFO - 2024-02-16 19:03:57 --> Helper loaded: file_helper
INFO - 2024-02-16 19:03:57 --> Helper loaded: form_helper
INFO - 2024-02-16 19:03:57 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:03:57 --> Controller Class Initialized
INFO - 2024-02-16 19:03:57 --> Form Validation Class Initialized
INFO - 2024-02-16 19:03:57 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:03:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:03:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:03:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 19:03:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-16 19:03:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-16 19:03:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-16 19:03:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-16 19:03:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-16 19:03:57 --> Final output sent to browser
DEBUG - 2024-02-16 19:03:57 --> Total execution time: 0.0291
ERROR - 2024-02-16 19:03:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:03:58 --> Config Class Initialized
INFO - 2024-02-16 19:03:58 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:03:58 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:03:58 --> Utf8 Class Initialized
INFO - 2024-02-16 19:03:58 --> URI Class Initialized
INFO - 2024-02-16 19:03:58 --> Router Class Initialized
INFO - 2024-02-16 19:03:58 --> Output Class Initialized
INFO - 2024-02-16 19:03:58 --> Security Class Initialized
DEBUG - 2024-02-16 19:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:03:58 --> Input Class Initialized
INFO - 2024-02-16 19:03:58 --> Language Class Initialized
INFO - 2024-02-16 19:03:58 --> Loader Class Initialized
INFO - 2024-02-16 19:03:58 --> Helper loaded: url_helper
INFO - 2024-02-16 19:03:58 --> Helper loaded: file_helper
INFO - 2024-02-16 19:03:58 --> Helper loaded: form_helper
INFO - 2024-02-16 19:03:58 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:03:58 --> Controller Class Initialized
INFO - 2024-02-16 19:03:58 --> Form Validation Class Initialized
INFO - 2024-02-16 19:03:58 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:03:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:03:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:03:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-16 19:04:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-16 19:04:00 --> Config Class Initialized
INFO - 2024-02-16 19:04:00 --> Hooks Class Initialized
DEBUG - 2024-02-16 19:04:00 --> UTF-8 Support Enabled
INFO - 2024-02-16 19:04:00 --> Utf8 Class Initialized
INFO - 2024-02-16 19:04:00 --> URI Class Initialized
INFO - 2024-02-16 19:04:00 --> Router Class Initialized
INFO - 2024-02-16 19:04:00 --> Output Class Initialized
INFO - 2024-02-16 19:04:00 --> Security Class Initialized
DEBUG - 2024-02-16 19:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-16 19:04:00 --> Input Class Initialized
INFO - 2024-02-16 19:04:00 --> Language Class Initialized
INFO - 2024-02-16 19:04:00 --> Loader Class Initialized
INFO - 2024-02-16 19:04:00 --> Helper loaded: url_helper
INFO - 2024-02-16 19:04:00 --> Helper loaded: file_helper
INFO - 2024-02-16 19:04:00 --> Helper loaded: form_helper
INFO - 2024-02-16 19:04:00 --> Database Driver Class Initialized
DEBUG - 2024-02-16 19:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-16 19:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-16 19:04:00 --> Controller Class Initialized
INFO - 2024-02-16 19:04:00 --> Form Validation Class Initialized
INFO - 2024-02-16 19:04:00 --> Model "MasterModel" initialized
INFO - 2024-02-16 19:04:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-16 19:04:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-16 19:04:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-16 19:04:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-16 19:04:00 --> Final output sent to browser
DEBUG - 2024-02-16 19:04:00 --> Total execution time: 0.0288
