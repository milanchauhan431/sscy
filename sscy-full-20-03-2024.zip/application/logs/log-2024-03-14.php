<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-14 17:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:37:46 --> Config Class Initialized
INFO - 2024-03-14 17:37:46 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:37:46 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:37:46 --> Utf8 Class Initialized
INFO - 2024-03-14 17:37:46 --> URI Class Initialized
INFO - 2024-03-14 17:37:46 --> Router Class Initialized
INFO - 2024-03-14 17:37:46 --> Output Class Initialized
INFO - 2024-03-14 17:37:46 --> Security Class Initialized
DEBUG - 2024-03-14 17:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:37:46 --> Input Class Initialized
INFO - 2024-03-14 17:37:46 --> Language Class Initialized
INFO - 2024-03-14 17:37:46 --> Loader Class Initialized
INFO - 2024-03-14 17:37:46 --> Helper loaded: url_helper
INFO - 2024-03-14 17:37:46 --> Helper loaded: file_helper
INFO - 2024-03-14 17:37:46 --> Helper loaded: form_helper
INFO - 2024-03-14 17:37:46 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:37:46 --> Controller Class Initialized
INFO - 2024-03-14 17:37:46 --> Model "LoginModel" initialized
INFO - 2024-03-14 17:37:46 --> Form Validation Class Initialized
INFO - 2024-03-14 17:37:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-14 17:37:46 --> Final output sent to browser
DEBUG - 2024-03-14 17:37:46 --> Total execution time: 0.0497
ERROR - 2024-03-14 17:37:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:37:58 --> Config Class Initialized
INFO - 2024-03-14 17:37:58 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:37:58 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:37:58 --> Utf8 Class Initialized
INFO - 2024-03-14 17:37:58 --> URI Class Initialized
INFO - 2024-03-14 17:37:58 --> Router Class Initialized
INFO - 2024-03-14 17:37:58 --> Output Class Initialized
INFO - 2024-03-14 17:37:58 --> Security Class Initialized
DEBUG - 2024-03-14 17:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:37:58 --> Input Class Initialized
INFO - 2024-03-14 17:37:58 --> Language Class Initialized
INFO - 2024-03-14 17:37:58 --> Loader Class Initialized
INFO - 2024-03-14 17:37:58 --> Helper loaded: url_helper
INFO - 2024-03-14 17:37:58 --> Helper loaded: file_helper
INFO - 2024-03-14 17:37:58 --> Helper loaded: form_helper
INFO - 2024-03-14 17:37:58 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:37:58 --> Controller Class Initialized
INFO - 2024-03-14 17:37:58 --> Model "LoginModel" initialized
INFO - 2024-03-14 17:37:58 --> Form Validation Class Initialized
INFO - 2024-03-14 17:37:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-14 17:37:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:37:58 --> Config Class Initialized
INFO - 2024-03-14 17:37:58 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:37:58 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:37:58 --> Utf8 Class Initialized
INFO - 2024-03-14 17:37:58 --> URI Class Initialized
INFO - 2024-03-14 17:37:58 --> Router Class Initialized
INFO - 2024-03-14 17:37:58 --> Output Class Initialized
INFO - 2024-03-14 17:37:58 --> Security Class Initialized
DEBUG - 2024-03-14 17:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:37:58 --> Input Class Initialized
INFO - 2024-03-14 17:37:58 --> Language Class Initialized
INFO - 2024-03-14 17:37:58 --> Loader Class Initialized
INFO - 2024-03-14 17:37:58 --> Helper loaded: url_helper
INFO - 2024-03-14 17:37:58 --> Helper loaded: file_helper
INFO - 2024-03-14 17:37:58 --> Helper loaded: form_helper
INFO - 2024-03-14 17:37:58 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:37:58 --> Controller Class Initialized
INFO - 2024-03-14 17:37:58 --> Form Validation Class Initialized
INFO - 2024-03-14 17:37:58 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:37:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:37:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-14 17:37:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:37:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:37:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:37:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:37:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-14 17:37:58 --> Final output sent to browser
DEBUG - 2024-03-14 17:37:58 --> Total execution time: 0.0449
ERROR - 2024-03-14 17:37:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:37:58 --> Config Class Initialized
INFO - 2024-03-14 17:37:58 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:37:58 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:37:58 --> Utf8 Class Initialized
INFO - 2024-03-14 17:37:58 --> URI Class Initialized
INFO - 2024-03-14 17:37:58 --> Router Class Initialized
INFO - 2024-03-14 17:37:58 --> Output Class Initialized
INFO - 2024-03-14 17:37:58 --> Security Class Initialized
DEBUG - 2024-03-14 17:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:37:58 --> Input Class Initialized
INFO - 2024-03-14 17:37:58 --> Language Class Initialized
INFO - 2024-03-14 17:37:58 --> Loader Class Initialized
INFO - 2024-03-14 17:37:58 --> Helper loaded: url_helper
INFO - 2024-03-14 17:37:58 --> Helper loaded: file_helper
INFO - 2024-03-14 17:37:58 --> Helper loaded: form_helper
INFO - 2024-03-14 17:37:58 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:37:58 --> Controller Class Initialized
INFO - 2024-03-14 17:37:58 --> Form Validation Class Initialized
INFO - 2024-03-14 17:37:58 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:37:58 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:38:03 --> Config Class Initialized
INFO - 2024-03-14 17:38:03 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:38:03 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:38:03 --> Utf8 Class Initialized
INFO - 2024-03-14 17:38:03 --> URI Class Initialized
INFO - 2024-03-14 17:38:03 --> Router Class Initialized
INFO - 2024-03-14 17:38:03 --> Output Class Initialized
INFO - 2024-03-14 17:38:03 --> Security Class Initialized
DEBUG - 2024-03-14 17:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:38:03 --> Input Class Initialized
INFO - 2024-03-14 17:38:03 --> Language Class Initialized
INFO - 2024-03-14 17:38:03 --> Loader Class Initialized
INFO - 2024-03-14 17:38:03 --> Helper loaded: url_helper
INFO - 2024-03-14 17:38:03 --> Helper loaded: file_helper
INFO - 2024-03-14 17:38:03 --> Helper loaded: form_helper
INFO - 2024-03-14 17:38:03 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:38:03 --> Controller Class Initialized
INFO - 2024-03-14 17:38:03 --> Form Validation Class Initialized
INFO - 2024-03-14 17:38:03 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:38:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:38:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:38:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:38:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:38:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:38:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-14 17:38:03 --> Final output sent to browser
DEBUG - 2024-03-14 17:38:03 --> Total execution time: 0.0352
ERROR - 2024-03-14 17:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:38:03 --> Config Class Initialized
INFO - 2024-03-14 17:38:03 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:38:03 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:38:03 --> Utf8 Class Initialized
INFO - 2024-03-14 17:38:03 --> URI Class Initialized
INFO - 2024-03-14 17:38:03 --> Router Class Initialized
INFO - 2024-03-14 17:38:03 --> Output Class Initialized
INFO - 2024-03-14 17:38:03 --> Security Class Initialized
DEBUG - 2024-03-14 17:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:38:03 --> Input Class Initialized
INFO - 2024-03-14 17:38:03 --> Language Class Initialized
INFO - 2024-03-14 17:38:03 --> Loader Class Initialized
INFO - 2024-03-14 17:38:03 --> Helper loaded: url_helper
INFO - 2024-03-14 17:38:03 --> Helper loaded: file_helper
INFO - 2024-03-14 17:38:03 --> Helper loaded: form_helper
INFO - 2024-03-14 17:38:03 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:38:03 --> Controller Class Initialized
INFO - 2024-03-14 17:38:03 --> Form Validation Class Initialized
INFO - 2024-03-14 17:38:03 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:38:03 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:38:24 --> Config Class Initialized
INFO - 2024-03-14 17:38:24 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:38:24 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:38:24 --> Utf8 Class Initialized
INFO - 2024-03-14 17:38:24 --> URI Class Initialized
INFO - 2024-03-14 17:38:24 --> Router Class Initialized
INFO - 2024-03-14 17:38:24 --> Output Class Initialized
INFO - 2024-03-14 17:38:24 --> Security Class Initialized
DEBUG - 2024-03-14 17:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:38:24 --> Input Class Initialized
INFO - 2024-03-14 17:38:24 --> Language Class Initialized
INFO - 2024-03-14 17:38:24 --> Loader Class Initialized
INFO - 2024-03-14 17:38:24 --> Helper loaded: url_helper
INFO - 2024-03-14 17:38:24 --> Helper loaded: file_helper
INFO - 2024-03-14 17:38:24 --> Helper loaded: form_helper
INFO - 2024-03-14 17:38:24 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:38:24 --> Controller Class Initialized
INFO - 2024-03-14 17:38:24 --> Form Validation Class Initialized
INFO - 2024-03-14 17:38:24 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:38:24 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:38:24 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:38:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:38:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:38:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:38:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:38:24 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:38:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:38:24 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:38:27 --> Config Class Initialized
INFO - 2024-03-14 17:38:27 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:38:27 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:38:27 --> Utf8 Class Initialized
INFO - 2024-03-14 17:38:27 --> URI Class Initialized
INFO - 2024-03-14 17:38:27 --> Router Class Initialized
INFO - 2024-03-14 17:38:27 --> Output Class Initialized
INFO - 2024-03-14 17:38:27 --> Security Class Initialized
DEBUG - 2024-03-14 17:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:38:27 --> Input Class Initialized
INFO - 2024-03-14 17:38:27 --> Language Class Initialized
INFO - 2024-03-14 17:38:27 --> Loader Class Initialized
INFO - 2024-03-14 17:38:27 --> Helper loaded: url_helper
INFO - 2024-03-14 17:38:27 --> Helper loaded: file_helper
INFO - 2024-03-14 17:38:27 --> Helper loaded: form_helper
INFO - 2024-03-14 17:38:27 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:38:27 --> Controller Class Initialized
INFO - 2024-03-14 17:38:27 --> Form Validation Class Initialized
INFO - 2024-03-14 17:38:27 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:38:27 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:38:27 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:38:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:38:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:38:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:38:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:38:27 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:38:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:38:27 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:38:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:38:29 --> Config Class Initialized
INFO - 2024-03-14 17:38:29 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:38:29 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:38:29 --> Utf8 Class Initialized
INFO - 2024-03-14 17:38:29 --> URI Class Initialized
INFO - 2024-03-14 17:38:29 --> Router Class Initialized
INFO - 2024-03-14 17:38:29 --> Output Class Initialized
INFO - 2024-03-14 17:38:29 --> Security Class Initialized
DEBUG - 2024-03-14 17:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:38:29 --> Input Class Initialized
INFO - 2024-03-14 17:38:29 --> Language Class Initialized
INFO - 2024-03-14 17:38:29 --> Loader Class Initialized
INFO - 2024-03-14 17:38:29 --> Helper loaded: url_helper
INFO - 2024-03-14 17:38:29 --> Helper loaded: file_helper
INFO - 2024-03-14 17:38:29 --> Helper loaded: form_helper
INFO - 2024-03-14 17:38:29 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:38:29 --> Controller Class Initialized
INFO - 2024-03-14 17:38:29 --> Form Validation Class Initialized
INFO - 2024-03-14 17:38:29 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:38:29 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:38:29 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:38:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:38:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:38:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:38:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:38:29 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:38:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:38:29 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:38:33 --> Config Class Initialized
INFO - 2024-03-14 17:38:33 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:38:33 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:38:33 --> Utf8 Class Initialized
INFO - 2024-03-14 17:38:33 --> URI Class Initialized
INFO - 2024-03-14 17:38:33 --> Router Class Initialized
INFO - 2024-03-14 17:38:33 --> Output Class Initialized
INFO - 2024-03-14 17:38:33 --> Security Class Initialized
DEBUG - 2024-03-14 17:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:38:33 --> Input Class Initialized
INFO - 2024-03-14 17:38:33 --> Language Class Initialized
INFO - 2024-03-14 17:38:33 --> Loader Class Initialized
INFO - 2024-03-14 17:38:33 --> Helper loaded: url_helper
INFO - 2024-03-14 17:38:33 --> Helper loaded: file_helper
INFO - 2024-03-14 17:38:33 --> Helper loaded: form_helper
INFO - 2024-03-14 17:38:33 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:38:33 --> Controller Class Initialized
INFO - 2024-03-14 17:38:33 --> Form Validation Class Initialized
INFO - 2024-03-14 17:38:33 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:38:33 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:38:33 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:38:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:38:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:38:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:38:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:38:33 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:38:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:38:33 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:38:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:38:37 --> Config Class Initialized
INFO - 2024-03-14 17:38:37 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:38:37 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:38:37 --> Utf8 Class Initialized
INFO - 2024-03-14 17:38:37 --> URI Class Initialized
INFO - 2024-03-14 17:38:37 --> Router Class Initialized
INFO - 2024-03-14 17:38:37 --> Output Class Initialized
INFO - 2024-03-14 17:38:37 --> Security Class Initialized
DEBUG - 2024-03-14 17:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:38:37 --> Input Class Initialized
INFO - 2024-03-14 17:38:37 --> Language Class Initialized
INFO - 2024-03-14 17:38:37 --> Loader Class Initialized
INFO - 2024-03-14 17:38:37 --> Helper loaded: url_helper
INFO - 2024-03-14 17:38:37 --> Helper loaded: file_helper
INFO - 2024-03-14 17:38:37 --> Helper loaded: form_helper
INFO - 2024-03-14 17:38:37 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:38:37 --> Controller Class Initialized
INFO - 2024-03-14 17:38:37 --> Form Validation Class Initialized
INFO - 2024-03-14 17:38:37 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:38:37 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:38:37 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:38:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:38:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:38:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:38:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:38:37 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:38:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:38:37 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:38:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:38:40 --> Config Class Initialized
INFO - 2024-03-14 17:38:40 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:38:41 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:38:41 --> Utf8 Class Initialized
INFO - 2024-03-14 17:38:41 --> URI Class Initialized
INFO - 2024-03-14 17:38:41 --> Router Class Initialized
INFO - 2024-03-14 17:38:41 --> Output Class Initialized
INFO - 2024-03-14 17:38:41 --> Security Class Initialized
DEBUG - 2024-03-14 17:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:38:41 --> Input Class Initialized
INFO - 2024-03-14 17:38:41 --> Language Class Initialized
INFO - 2024-03-14 17:38:41 --> Loader Class Initialized
INFO - 2024-03-14 17:38:41 --> Helper loaded: url_helper
INFO - 2024-03-14 17:38:41 --> Helper loaded: file_helper
INFO - 2024-03-14 17:38:41 --> Helper loaded: form_helper
INFO - 2024-03-14 17:38:41 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:38:41 --> Controller Class Initialized
INFO - 2024-03-14 17:38:41 --> Form Validation Class Initialized
INFO - 2024-03-14 17:38:41 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-14 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-14 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-14 17:38:41 --> Final output sent to browser
DEBUG - 2024-03-14 17:38:41 --> Total execution time: 0.0420
ERROR - 2024-03-14 17:38:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:38:41 --> Config Class Initialized
INFO - 2024-03-14 17:38:41 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:38:41 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:38:41 --> Utf8 Class Initialized
INFO - 2024-03-14 17:38:41 --> URI Class Initialized
INFO - 2024-03-14 17:38:41 --> Router Class Initialized
INFO - 2024-03-14 17:38:41 --> Output Class Initialized
INFO - 2024-03-14 17:38:41 --> Security Class Initialized
DEBUG - 2024-03-14 17:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:38:41 --> Input Class Initialized
INFO - 2024-03-14 17:38:41 --> Language Class Initialized
INFO - 2024-03-14 17:38:41 --> Loader Class Initialized
INFO - 2024-03-14 17:38:41 --> Helper loaded: url_helper
INFO - 2024-03-14 17:38:41 --> Helper loaded: file_helper
INFO - 2024-03-14 17:38:41 --> Helper loaded: form_helper
INFO - 2024-03-14 17:38:41 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:38:41 --> Controller Class Initialized
INFO - 2024-03-14 17:38:41 --> Form Validation Class Initialized
INFO - 2024-03-14 17:38:41 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:38:41 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:38:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:38:52 --> Config Class Initialized
INFO - 2024-03-14 17:38:52 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:38:52 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:38:52 --> Utf8 Class Initialized
INFO - 2024-03-14 17:38:52 --> URI Class Initialized
INFO - 2024-03-14 17:38:52 --> Router Class Initialized
INFO - 2024-03-14 17:38:52 --> Output Class Initialized
INFO - 2024-03-14 17:38:52 --> Security Class Initialized
DEBUG - 2024-03-14 17:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:38:52 --> Input Class Initialized
INFO - 2024-03-14 17:38:52 --> Language Class Initialized
INFO - 2024-03-14 17:38:52 --> Loader Class Initialized
INFO - 2024-03-14 17:38:52 --> Helper loaded: url_helper
INFO - 2024-03-14 17:38:52 --> Helper loaded: file_helper
INFO - 2024-03-14 17:38:52 --> Helper loaded: form_helper
INFO - 2024-03-14 17:38:52 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:38:52 --> Controller Class Initialized
INFO - 2024-03-14 17:38:52 --> Form Validation Class Initialized
INFO - 2024-03-14 17:38:52 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:38:52 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:38:52 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:38:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:38:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:38:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:38:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:38:52 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:38:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:38:52 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:05 --> Config Class Initialized
INFO - 2024-03-14 17:39:05 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:05 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:05 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:05 --> URI Class Initialized
INFO - 2024-03-14 17:39:05 --> Router Class Initialized
INFO - 2024-03-14 17:39:05 --> Output Class Initialized
INFO - 2024-03-14 17:39:05 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:05 --> Input Class Initialized
INFO - 2024-03-14 17:39:05 --> Language Class Initialized
INFO - 2024-03-14 17:39:05 --> Loader Class Initialized
INFO - 2024-03-14 17:39:05 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:05 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:05 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:05 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:05 --> Controller Class Initialized
INFO - 2024-03-14 17:39:05 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:05 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:05 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:05 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:05 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:05 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:06 --> Config Class Initialized
INFO - 2024-03-14 17:39:06 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:06 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:06 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:06 --> URI Class Initialized
INFO - 2024-03-14 17:39:06 --> Router Class Initialized
INFO - 2024-03-14 17:39:06 --> Output Class Initialized
INFO - 2024-03-14 17:39:06 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:06 --> Input Class Initialized
INFO - 2024-03-14 17:39:06 --> Language Class Initialized
INFO - 2024-03-14 17:39:06 --> Loader Class Initialized
INFO - 2024-03-14 17:39:06 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:06 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:06 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:06 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:06 --> Controller Class Initialized
INFO - 2024-03-14 17:39:06 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:06 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:06 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:06 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:06 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:06 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:09 --> Config Class Initialized
INFO - 2024-03-14 17:39:09 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:09 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:09 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:09 --> URI Class Initialized
INFO - 2024-03-14 17:39:09 --> Router Class Initialized
INFO - 2024-03-14 17:39:09 --> Output Class Initialized
INFO - 2024-03-14 17:39:09 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:09 --> Input Class Initialized
INFO - 2024-03-14 17:39:09 --> Language Class Initialized
INFO - 2024-03-14 17:39:09 --> Loader Class Initialized
INFO - 2024-03-14 17:39:09 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:09 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:09 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:09 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:09 --> Controller Class Initialized
INFO - 2024-03-14 17:39:09 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:09 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:09 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:09 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:09 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:09 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:15 --> Config Class Initialized
INFO - 2024-03-14 17:39:15 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:15 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:15 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:15 --> URI Class Initialized
INFO - 2024-03-14 17:39:15 --> Router Class Initialized
INFO - 2024-03-14 17:39:15 --> Output Class Initialized
INFO - 2024-03-14 17:39:15 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:15 --> Input Class Initialized
INFO - 2024-03-14 17:39:15 --> Language Class Initialized
INFO - 2024-03-14 17:39:15 --> Loader Class Initialized
INFO - 2024-03-14 17:39:15 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:15 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:15 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:15 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:15 --> Controller Class Initialized
INFO - 2024-03-14 17:39:15 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:15 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:15 --> Config Class Initialized
INFO - 2024-03-14 17:39:15 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:15 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:15 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:15 --> URI Class Initialized
INFO - 2024-03-14 17:39:15 --> Router Class Initialized
INFO - 2024-03-14 17:39:15 --> Output Class Initialized
INFO - 2024-03-14 17:39:15 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:15 --> Input Class Initialized
INFO - 2024-03-14 17:39:15 --> Language Class Initialized
INFO - 2024-03-14 17:39:15 --> Loader Class Initialized
INFO - 2024-03-14 17:39:15 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:15 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:15 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:15 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:15 --> Controller Class Initialized
INFO - 2024-03-14 17:39:15 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:15 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:15 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:18 --> Config Class Initialized
INFO - 2024-03-14 17:39:18 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:18 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:18 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:18 --> URI Class Initialized
INFO - 2024-03-14 17:39:18 --> Router Class Initialized
INFO - 2024-03-14 17:39:18 --> Output Class Initialized
INFO - 2024-03-14 17:39:18 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:18 --> Input Class Initialized
INFO - 2024-03-14 17:39:18 --> Language Class Initialized
INFO - 2024-03-14 17:39:18 --> Loader Class Initialized
INFO - 2024-03-14 17:39:18 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:18 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:18 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:18 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:18 --> Controller Class Initialized
INFO - 2024-03-14 17:39:18 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:18 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:18 --> Config Class Initialized
INFO - 2024-03-14 17:39:18 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:18 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:18 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:18 --> URI Class Initialized
INFO - 2024-03-14 17:39:18 --> Router Class Initialized
INFO - 2024-03-14 17:39:18 --> Output Class Initialized
INFO - 2024-03-14 17:39:18 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:18 --> Input Class Initialized
INFO - 2024-03-14 17:39:18 --> Language Class Initialized
INFO - 2024-03-14 17:39:18 --> Loader Class Initialized
INFO - 2024-03-14 17:39:18 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:18 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:18 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:18 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:18 --> Controller Class Initialized
INFO - 2024-03-14 17:39:18 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:18 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:18 --> Config Class Initialized
INFO - 2024-03-14 17:39:18 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:18 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:18 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:18 --> URI Class Initialized
INFO - 2024-03-14 17:39:18 --> Router Class Initialized
INFO - 2024-03-14 17:39:18 --> Output Class Initialized
INFO - 2024-03-14 17:39:18 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:18 --> Input Class Initialized
INFO - 2024-03-14 17:39:18 --> Language Class Initialized
INFO - 2024-03-14 17:39:18 --> Loader Class Initialized
INFO - 2024-03-14 17:39:18 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:18 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:18 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:18 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:18 --> Controller Class Initialized
INFO - 2024-03-14 17:39:18 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:18 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:18 --> Config Class Initialized
INFO - 2024-03-14 17:39:18 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:18 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:18 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:18 --> URI Class Initialized
INFO - 2024-03-14 17:39:18 --> Router Class Initialized
INFO - 2024-03-14 17:39:18 --> Output Class Initialized
INFO - 2024-03-14 17:39:18 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:18 --> Input Class Initialized
INFO - 2024-03-14 17:39:18 --> Language Class Initialized
INFO - 2024-03-14 17:39:18 --> Loader Class Initialized
INFO - 2024-03-14 17:39:18 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:18 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:18 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:18 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:18 --> Controller Class Initialized
INFO - 2024-03-14 17:39:18 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:18 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:18 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:20 --> Config Class Initialized
INFO - 2024-03-14 17:39:20 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:20 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:20 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:20 --> URI Class Initialized
INFO - 2024-03-14 17:39:20 --> Router Class Initialized
INFO - 2024-03-14 17:39:20 --> Output Class Initialized
INFO - 2024-03-14 17:39:20 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:20 --> Input Class Initialized
INFO - 2024-03-14 17:39:20 --> Language Class Initialized
INFO - 2024-03-14 17:39:20 --> Loader Class Initialized
INFO - 2024-03-14 17:39:20 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:20 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:20 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:20 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:20 --> Controller Class Initialized
INFO - 2024-03-14 17:39:20 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:20 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:20 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:20 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:20 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:20 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:28 --> Config Class Initialized
INFO - 2024-03-14 17:39:28 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:28 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:28 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:28 --> URI Class Initialized
INFO - 2024-03-14 17:39:28 --> Router Class Initialized
INFO - 2024-03-14 17:39:28 --> Output Class Initialized
INFO - 2024-03-14 17:39:28 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:28 --> Input Class Initialized
INFO - 2024-03-14 17:39:28 --> Language Class Initialized
INFO - 2024-03-14 17:39:28 --> Loader Class Initialized
INFO - 2024-03-14 17:39:28 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:28 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:28 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:28 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:28 --> Controller Class Initialized
INFO - 2024-03-14 17:39:28 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:28 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:28 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:28 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:28 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:28 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:33 --> Config Class Initialized
INFO - 2024-03-14 17:39:33 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:33 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:33 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:33 --> URI Class Initialized
INFO - 2024-03-14 17:39:33 --> Router Class Initialized
INFO - 2024-03-14 17:39:33 --> Output Class Initialized
INFO - 2024-03-14 17:39:33 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:33 --> Input Class Initialized
INFO - 2024-03-14 17:39:33 --> Language Class Initialized
INFO - 2024-03-14 17:39:33 --> Loader Class Initialized
INFO - 2024-03-14 17:39:33 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:33 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:33 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:33 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:33 --> Controller Class Initialized
INFO - 2024-03-14 17:39:33 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:33 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:33 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:33 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:33 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:33 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:39:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:39:41 --> Config Class Initialized
INFO - 2024-03-14 17:39:41 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:39:41 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:39:41 --> Utf8 Class Initialized
INFO - 2024-03-14 17:39:41 --> URI Class Initialized
INFO - 2024-03-14 17:39:41 --> Router Class Initialized
INFO - 2024-03-14 17:39:41 --> Output Class Initialized
INFO - 2024-03-14 17:39:41 --> Security Class Initialized
DEBUG - 2024-03-14 17:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:39:41 --> Input Class Initialized
INFO - 2024-03-14 17:39:41 --> Language Class Initialized
INFO - 2024-03-14 17:39:41 --> Loader Class Initialized
INFO - 2024-03-14 17:39:41 --> Helper loaded: url_helper
INFO - 2024-03-14 17:39:41 --> Helper loaded: file_helper
INFO - 2024-03-14 17:39:41 --> Helper loaded: form_helper
INFO - 2024-03-14 17:39:41 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:39:41 --> Controller Class Initialized
INFO - 2024-03-14 17:39:41 --> Form Validation Class Initialized
INFO - 2024-03-14 17:39:41 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:39:41 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:39:41 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:39:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:39:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:39:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:39:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:39:41 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:39:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:39:41 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:40:00 --> Config Class Initialized
INFO - 2024-03-14 17:40:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:40:00 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:40:00 --> Utf8 Class Initialized
INFO - 2024-03-14 17:40:00 --> URI Class Initialized
INFO - 2024-03-14 17:40:00 --> Router Class Initialized
INFO - 2024-03-14 17:40:00 --> Output Class Initialized
INFO - 2024-03-14 17:40:00 --> Security Class Initialized
DEBUG - 2024-03-14 17:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:40:00 --> Input Class Initialized
INFO - 2024-03-14 17:40:00 --> Language Class Initialized
INFO - 2024-03-14 17:40:00 --> Loader Class Initialized
INFO - 2024-03-14 17:40:00 --> Helper loaded: url_helper
INFO - 2024-03-14 17:40:00 --> Helper loaded: file_helper
INFO - 2024-03-14 17:40:00 --> Helper loaded: form_helper
INFO - 2024-03-14 17:40:00 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:40:00 --> Controller Class Initialized
INFO - 2024-03-14 17:40:00 --> Form Validation Class Initialized
INFO - 2024-03-14 17:40:00 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:40:00 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:40:00 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:40:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:40:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:40:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:40:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:40:00 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:40:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:40:00 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:40:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-14 17:40:00 --> Final output sent to browser
DEBUG - 2024-03-14 17:40:00 --> Total execution time: 0.0375
ERROR - 2024-03-14 17:40:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:40:06 --> Config Class Initialized
INFO - 2024-03-14 17:40:06 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:40:06 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:40:06 --> Utf8 Class Initialized
INFO - 2024-03-14 17:40:06 --> URI Class Initialized
INFO - 2024-03-14 17:40:06 --> Router Class Initialized
INFO - 2024-03-14 17:40:06 --> Output Class Initialized
INFO - 2024-03-14 17:40:06 --> Security Class Initialized
DEBUG - 2024-03-14 17:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:40:06 --> Input Class Initialized
INFO - 2024-03-14 17:40:06 --> Language Class Initialized
INFO - 2024-03-14 17:40:06 --> Loader Class Initialized
INFO - 2024-03-14 17:40:06 --> Helper loaded: url_helper
INFO - 2024-03-14 17:40:06 --> Helper loaded: file_helper
INFO - 2024-03-14 17:40:06 --> Helper loaded: form_helper
INFO - 2024-03-14 17:40:06 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:40:06 --> Controller Class Initialized
INFO - 2024-03-14 17:40:06 --> Form Validation Class Initialized
INFO - 2024-03-14 17:40:06 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:40:06 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:40:06 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:40:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:40:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:40:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:40:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:40:06 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:40:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:40:06 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:40:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:40:33 --> Config Class Initialized
INFO - 2024-03-14 17:40:33 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:40:33 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:40:33 --> Utf8 Class Initialized
INFO - 2024-03-14 17:40:33 --> URI Class Initialized
INFO - 2024-03-14 17:40:33 --> Router Class Initialized
INFO - 2024-03-14 17:40:33 --> Output Class Initialized
INFO - 2024-03-14 17:40:33 --> Security Class Initialized
DEBUG - 2024-03-14 17:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:40:33 --> Input Class Initialized
INFO - 2024-03-14 17:40:33 --> Language Class Initialized
INFO - 2024-03-14 17:40:33 --> Loader Class Initialized
INFO - 2024-03-14 17:40:33 --> Helper loaded: url_helper
INFO - 2024-03-14 17:40:33 --> Helper loaded: file_helper
INFO - 2024-03-14 17:40:33 --> Helper loaded: form_helper
INFO - 2024-03-14 17:40:33 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:40:33 --> Controller Class Initialized
INFO - 2024-03-14 17:40:33 --> Form Validation Class Initialized
INFO - 2024-03-14 17:40:33 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:40:33 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:40:33 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:40:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:40:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:40:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:40:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:40:33 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:40:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:40:33 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:40:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:40:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:40:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:40:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:40:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:40:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-14 17:40:33 --> Final output sent to browser
DEBUG - 2024-03-14 17:40:33 --> Total execution time: 0.0425
ERROR - 2024-03-14 17:40:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:40:34 --> Config Class Initialized
INFO - 2024-03-14 17:40:34 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:40:34 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:40:34 --> Utf8 Class Initialized
INFO - 2024-03-14 17:40:34 --> URI Class Initialized
INFO - 2024-03-14 17:40:34 --> Router Class Initialized
INFO - 2024-03-14 17:40:34 --> Output Class Initialized
INFO - 2024-03-14 17:40:34 --> Security Class Initialized
DEBUG - 2024-03-14 17:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:40:34 --> Input Class Initialized
INFO - 2024-03-14 17:40:34 --> Language Class Initialized
INFO - 2024-03-14 17:40:34 --> Loader Class Initialized
INFO - 2024-03-14 17:40:34 --> Helper loaded: url_helper
INFO - 2024-03-14 17:40:34 --> Helper loaded: file_helper
INFO - 2024-03-14 17:40:34 --> Helper loaded: form_helper
INFO - 2024-03-14 17:40:34 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:40:34 --> Controller Class Initialized
INFO - 2024-03-14 17:40:34 --> Form Validation Class Initialized
INFO - 2024-03-14 17:40:34 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:40:34 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:40:34 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:40:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:40:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:40:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:40:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:40:34 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:40:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:40:34 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:40:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:40:36 --> Config Class Initialized
INFO - 2024-03-14 17:40:36 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:40:36 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:40:36 --> Utf8 Class Initialized
INFO - 2024-03-14 17:40:36 --> URI Class Initialized
INFO - 2024-03-14 17:40:36 --> Router Class Initialized
INFO - 2024-03-14 17:40:36 --> Output Class Initialized
INFO - 2024-03-14 17:40:36 --> Security Class Initialized
DEBUG - 2024-03-14 17:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:40:36 --> Input Class Initialized
INFO - 2024-03-14 17:40:36 --> Language Class Initialized
INFO - 2024-03-14 17:40:36 --> Loader Class Initialized
INFO - 2024-03-14 17:40:36 --> Helper loaded: url_helper
INFO - 2024-03-14 17:40:36 --> Helper loaded: file_helper
INFO - 2024-03-14 17:40:36 --> Helper loaded: form_helper
INFO - 2024-03-14 17:40:36 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:40:36 --> Controller Class Initialized
INFO - 2024-03-14 17:40:36 --> Form Validation Class Initialized
INFO - 2024-03-14 17:40:36 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:40:36 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:40:36 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:40:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:40:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:40:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:40:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:40:36 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:40:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:40:36 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:40:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:40:37 --> Config Class Initialized
INFO - 2024-03-14 17:40:37 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:40:37 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:40:37 --> Utf8 Class Initialized
INFO - 2024-03-14 17:40:37 --> URI Class Initialized
INFO - 2024-03-14 17:40:37 --> Router Class Initialized
INFO - 2024-03-14 17:40:37 --> Output Class Initialized
INFO - 2024-03-14 17:40:37 --> Security Class Initialized
DEBUG - 2024-03-14 17:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:40:37 --> Input Class Initialized
INFO - 2024-03-14 17:40:37 --> Language Class Initialized
INFO - 2024-03-14 17:40:37 --> Loader Class Initialized
INFO - 2024-03-14 17:40:37 --> Helper loaded: url_helper
INFO - 2024-03-14 17:40:37 --> Helper loaded: file_helper
INFO - 2024-03-14 17:40:37 --> Helper loaded: form_helper
INFO - 2024-03-14 17:40:37 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:40:37 --> Controller Class Initialized
INFO - 2024-03-14 17:40:37 --> Form Validation Class Initialized
INFO - 2024-03-14 17:40:37 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:40:37 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:40:37 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:40:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:40:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:40:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:40:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:40:37 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:40:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:40:37 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:40:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:40:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:40:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:40:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:40:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:40:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-14 17:40:37 --> Final output sent to browser
DEBUG - 2024-03-14 17:40:37 --> Total execution time: 0.0422
ERROR - 2024-03-14 17:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:40:39 --> Config Class Initialized
INFO - 2024-03-14 17:40:39 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:40:39 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:40:39 --> Utf8 Class Initialized
INFO - 2024-03-14 17:40:39 --> URI Class Initialized
INFO - 2024-03-14 17:40:39 --> Router Class Initialized
INFO - 2024-03-14 17:40:39 --> Output Class Initialized
INFO - 2024-03-14 17:40:39 --> Security Class Initialized
DEBUG - 2024-03-14 17:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:40:39 --> Input Class Initialized
INFO - 2024-03-14 17:40:39 --> Language Class Initialized
INFO - 2024-03-14 17:40:39 --> Loader Class Initialized
INFO - 2024-03-14 17:40:39 --> Helper loaded: url_helper
INFO - 2024-03-14 17:40:39 --> Helper loaded: file_helper
INFO - 2024-03-14 17:40:39 --> Helper loaded: form_helper
INFO - 2024-03-14 17:40:39 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:40:39 --> Controller Class Initialized
INFO - 2024-03-14 17:40:39 --> Form Validation Class Initialized
INFO - 2024-03-14 17:40:39 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:40:39 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:40:39 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:40:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:40:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:40:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:40:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:40:39 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:40:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:40:39 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:40:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:40:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:40:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:40:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:40:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:40:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-14 17:40:39 --> Final output sent to browser
DEBUG - 2024-03-14 17:40:39 --> Total execution time: 0.0367
ERROR - 2024-03-14 17:40:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:40:52 --> Config Class Initialized
INFO - 2024-03-14 17:40:52 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:40:52 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:40:52 --> Utf8 Class Initialized
INFO - 2024-03-14 17:40:52 --> URI Class Initialized
INFO - 2024-03-14 17:40:52 --> Router Class Initialized
INFO - 2024-03-14 17:40:52 --> Output Class Initialized
INFO - 2024-03-14 17:40:52 --> Security Class Initialized
DEBUG - 2024-03-14 17:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:40:52 --> Input Class Initialized
INFO - 2024-03-14 17:40:52 --> Language Class Initialized
INFO - 2024-03-14 17:40:52 --> Loader Class Initialized
INFO - 2024-03-14 17:40:52 --> Helper loaded: url_helper
INFO - 2024-03-14 17:40:52 --> Helper loaded: file_helper
INFO - 2024-03-14 17:40:52 --> Helper loaded: form_helper
INFO - 2024-03-14 17:40:52 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:40:52 --> Controller Class Initialized
INFO - 2024-03-14 17:40:52 --> Form Validation Class Initialized
INFO - 2024-03-14 17:40:52 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:40:52 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:40:52 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:40:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:40:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:40:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:40:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:40:52 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:40:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:40:52 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:40:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:40:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-14 17:40:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:40:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:40:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:40:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:40:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-14 17:40:52 --> Final output sent to browser
DEBUG - 2024-03-14 17:40:52 --> Total execution time: 0.0373
ERROR - 2024-03-14 17:40:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:40:53 --> Config Class Initialized
INFO - 2024-03-14 17:40:53 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:40:53 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:40:53 --> Utf8 Class Initialized
INFO - 2024-03-14 17:40:53 --> URI Class Initialized
INFO - 2024-03-14 17:40:53 --> Router Class Initialized
INFO - 2024-03-14 17:40:53 --> Output Class Initialized
INFO - 2024-03-14 17:40:53 --> Security Class Initialized
DEBUG - 2024-03-14 17:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:40:53 --> Input Class Initialized
INFO - 2024-03-14 17:40:53 --> Language Class Initialized
INFO - 2024-03-14 17:40:53 --> Loader Class Initialized
INFO - 2024-03-14 17:40:53 --> Helper loaded: url_helper
INFO - 2024-03-14 17:40:53 --> Helper loaded: file_helper
INFO - 2024-03-14 17:40:53 --> Helper loaded: form_helper
INFO - 2024-03-14 17:40:53 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:40:53 --> Controller Class Initialized
INFO - 2024-03-14 17:40:53 --> Form Validation Class Initialized
INFO - 2024-03-14 17:40:53 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:40:53 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:40:53 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:40:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:40:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:40:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:40:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:40:53 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:40:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:40:53 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:40:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:40:57 --> Config Class Initialized
INFO - 2024-03-14 17:40:57 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:40:57 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:40:57 --> Utf8 Class Initialized
INFO - 2024-03-14 17:40:57 --> URI Class Initialized
INFO - 2024-03-14 17:40:57 --> Router Class Initialized
INFO - 2024-03-14 17:40:57 --> Output Class Initialized
INFO - 2024-03-14 17:40:57 --> Security Class Initialized
DEBUG - 2024-03-14 17:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:40:57 --> Input Class Initialized
INFO - 2024-03-14 17:40:57 --> Language Class Initialized
INFO - 2024-03-14 17:40:57 --> Loader Class Initialized
INFO - 2024-03-14 17:40:57 --> Helper loaded: url_helper
INFO - 2024-03-14 17:40:57 --> Helper loaded: file_helper
INFO - 2024-03-14 17:40:57 --> Helper loaded: form_helper
INFO - 2024-03-14 17:40:57 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:40:57 --> Controller Class Initialized
INFO - 2024-03-14 17:40:57 --> Form Validation Class Initialized
INFO - 2024-03-14 17:40:57 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:40:57 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:40:57 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:40:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:40:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:40:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:40:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:40:57 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:40:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:40:57 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:40:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:40:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:40:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:40:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:40:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:40:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-14 17:40:57 --> Final output sent to browser
DEBUG - 2024-03-14 17:40:57 --> Total execution time: 0.0424
ERROR - 2024-03-14 17:40:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:40:58 --> Config Class Initialized
INFO - 2024-03-14 17:40:58 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:40:58 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:40:58 --> Utf8 Class Initialized
INFO - 2024-03-14 17:40:58 --> URI Class Initialized
INFO - 2024-03-14 17:40:58 --> Router Class Initialized
INFO - 2024-03-14 17:40:58 --> Output Class Initialized
INFO - 2024-03-14 17:40:58 --> Security Class Initialized
DEBUG - 2024-03-14 17:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:40:58 --> Input Class Initialized
INFO - 2024-03-14 17:40:58 --> Language Class Initialized
INFO - 2024-03-14 17:40:58 --> Loader Class Initialized
INFO - 2024-03-14 17:40:58 --> Helper loaded: url_helper
INFO - 2024-03-14 17:40:58 --> Helper loaded: file_helper
INFO - 2024-03-14 17:40:58 --> Helper loaded: form_helper
INFO - 2024-03-14 17:40:58 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:40:58 --> Controller Class Initialized
INFO - 2024-03-14 17:40:58 --> Form Validation Class Initialized
INFO - 2024-03-14 17:40:58 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:40:58 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:40:58 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:40:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:40:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:40:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:40:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:40:58 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:40:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:40:58 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:41:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:41:41 --> Config Class Initialized
INFO - 2024-03-14 17:41:41 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:41:41 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:41:41 --> Utf8 Class Initialized
INFO - 2024-03-14 17:41:41 --> URI Class Initialized
INFO - 2024-03-14 17:41:41 --> Router Class Initialized
INFO - 2024-03-14 17:41:41 --> Output Class Initialized
INFO - 2024-03-14 17:41:41 --> Security Class Initialized
DEBUG - 2024-03-14 17:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:41:41 --> Input Class Initialized
INFO - 2024-03-14 17:41:41 --> Language Class Initialized
INFO - 2024-03-14 17:41:41 --> Loader Class Initialized
INFO - 2024-03-14 17:41:41 --> Helper loaded: url_helper
INFO - 2024-03-14 17:41:41 --> Helper loaded: file_helper
INFO - 2024-03-14 17:41:41 --> Helper loaded: form_helper
INFO - 2024-03-14 17:41:41 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:41:41 --> Controller Class Initialized
INFO - 2024-03-14 17:41:41 --> Form Validation Class Initialized
INFO - 2024-03-14 17:41:41 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:41:41 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:41:41 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:41:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:41:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:41:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:41:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:41:41 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:41:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:41:41 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:42:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:42:24 --> Config Class Initialized
INFO - 2024-03-14 17:42:24 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:42:24 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:42:24 --> Utf8 Class Initialized
INFO - 2024-03-14 17:42:24 --> URI Class Initialized
INFO - 2024-03-14 17:42:24 --> Router Class Initialized
INFO - 2024-03-14 17:42:24 --> Output Class Initialized
INFO - 2024-03-14 17:42:24 --> Security Class Initialized
DEBUG - 2024-03-14 17:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:42:24 --> Input Class Initialized
INFO - 2024-03-14 17:42:24 --> Language Class Initialized
INFO - 2024-03-14 17:42:24 --> Loader Class Initialized
INFO - 2024-03-14 17:42:24 --> Helper loaded: url_helper
INFO - 2024-03-14 17:42:24 --> Helper loaded: file_helper
INFO - 2024-03-14 17:42:24 --> Helper loaded: form_helper
INFO - 2024-03-14 17:42:24 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:42:24 --> Controller Class Initialized
INFO - 2024-03-14 17:42:24 --> Form Validation Class Initialized
INFO - 2024-03-14 17:42:24 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:42:24 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:42:24 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:42:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:42:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:42:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:42:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:42:24 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:42:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:42:24 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:42:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:42:29 --> Config Class Initialized
INFO - 2024-03-14 17:42:29 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:42:29 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:42:29 --> Utf8 Class Initialized
INFO - 2024-03-14 17:42:29 --> URI Class Initialized
INFO - 2024-03-14 17:42:29 --> Router Class Initialized
INFO - 2024-03-14 17:42:29 --> Output Class Initialized
INFO - 2024-03-14 17:42:29 --> Security Class Initialized
DEBUG - 2024-03-14 17:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:42:29 --> Input Class Initialized
INFO - 2024-03-14 17:42:29 --> Language Class Initialized
INFO - 2024-03-14 17:42:29 --> Loader Class Initialized
INFO - 2024-03-14 17:42:29 --> Helper loaded: url_helper
INFO - 2024-03-14 17:42:29 --> Helper loaded: file_helper
INFO - 2024-03-14 17:42:29 --> Helper loaded: form_helper
INFO - 2024-03-14 17:42:29 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:42:29 --> Controller Class Initialized
INFO - 2024-03-14 17:42:29 --> Form Validation Class Initialized
INFO - 2024-03-14 17:42:29 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:42:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:42:29 --> Config Class Initialized
INFO - 2024-03-14 17:42:29 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:42:29 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:42:29 --> Utf8 Class Initialized
INFO - 2024-03-14 17:42:29 --> URI Class Initialized
INFO - 2024-03-14 17:42:29 --> Router Class Initialized
INFO - 2024-03-14 17:42:29 --> Output Class Initialized
INFO - 2024-03-14 17:42:29 --> Security Class Initialized
DEBUG - 2024-03-14 17:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:42:29 --> Input Class Initialized
INFO - 2024-03-14 17:42:29 --> Language Class Initialized
INFO - 2024-03-14 17:42:29 --> Loader Class Initialized
INFO - 2024-03-14 17:42:29 --> Helper loaded: url_helper
INFO - 2024-03-14 17:42:29 --> Helper loaded: file_helper
INFO - 2024-03-14 17:42:29 --> Helper loaded: form_helper
INFO - 2024-03-14 17:42:29 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:42:29 --> Controller Class Initialized
INFO - 2024-03-14 17:42:29 --> Form Validation Class Initialized
INFO - 2024-03-14 17:42:29 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:42:29 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:42:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:42:34 --> Config Class Initialized
INFO - 2024-03-14 17:42:34 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:42:34 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:42:34 --> Utf8 Class Initialized
INFO - 2024-03-14 17:42:34 --> URI Class Initialized
INFO - 2024-03-14 17:42:34 --> Router Class Initialized
INFO - 2024-03-14 17:42:34 --> Output Class Initialized
INFO - 2024-03-14 17:42:34 --> Security Class Initialized
DEBUG - 2024-03-14 17:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:42:34 --> Input Class Initialized
INFO - 2024-03-14 17:42:34 --> Language Class Initialized
INFO - 2024-03-14 17:42:34 --> Loader Class Initialized
INFO - 2024-03-14 17:42:34 --> Helper loaded: url_helper
INFO - 2024-03-14 17:42:34 --> Helper loaded: file_helper
INFO - 2024-03-14 17:42:34 --> Helper loaded: form_helper
INFO - 2024-03-14 17:42:34 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:42:34 --> Controller Class Initialized
INFO - 2024-03-14 17:42:34 --> Form Validation Class Initialized
INFO - 2024-03-14 17:42:34 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:42:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:42:34 --> Config Class Initialized
INFO - 2024-03-14 17:42:34 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:42:34 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:42:34 --> Utf8 Class Initialized
INFO - 2024-03-14 17:42:34 --> URI Class Initialized
INFO - 2024-03-14 17:42:34 --> Router Class Initialized
INFO - 2024-03-14 17:42:34 --> Output Class Initialized
INFO - 2024-03-14 17:42:34 --> Security Class Initialized
DEBUG - 2024-03-14 17:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:42:34 --> Input Class Initialized
INFO - 2024-03-14 17:42:34 --> Language Class Initialized
INFO - 2024-03-14 17:42:34 --> Loader Class Initialized
INFO - 2024-03-14 17:42:34 --> Helper loaded: url_helper
INFO - 2024-03-14 17:42:34 --> Helper loaded: file_helper
INFO - 2024-03-14 17:42:34 --> Helper loaded: form_helper
INFO - 2024-03-14 17:42:34 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:42:34 --> Controller Class Initialized
INFO - 2024-03-14 17:42:34 --> Form Validation Class Initialized
INFO - 2024-03-14 17:42:34 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:42:34 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:42:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:42:36 --> Config Class Initialized
INFO - 2024-03-14 17:42:36 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:42:36 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:42:36 --> Utf8 Class Initialized
INFO - 2024-03-14 17:42:36 --> URI Class Initialized
INFO - 2024-03-14 17:42:36 --> Router Class Initialized
INFO - 2024-03-14 17:42:36 --> Output Class Initialized
INFO - 2024-03-14 17:42:36 --> Security Class Initialized
DEBUG - 2024-03-14 17:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:42:36 --> Input Class Initialized
INFO - 2024-03-14 17:42:36 --> Language Class Initialized
INFO - 2024-03-14 17:42:36 --> Loader Class Initialized
INFO - 2024-03-14 17:42:36 --> Helper loaded: url_helper
INFO - 2024-03-14 17:42:36 --> Helper loaded: file_helper
INFO - 2024-03-14 17:42:36 --> Helper loaded: form_helper
INFO - 2024-03-14 17:42:36 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:42:36 --> Controller Class Initialized
INFO - 2024-03-14 17:42:36 --> Form Validation Class Initialized
INFO - 2024-03-14 17:42:36 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:42:36 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:42:36 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:42:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:42:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:42:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:42:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:42:36 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:42:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:42:36 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:42:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:42:51 --> Config Class Initialized
INFO - 2024-03-14 17:42:51 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:42:51 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:42:51 --> Utf8 Class Initialized
INFO - 2024-03-14 17:42:51 --> URI Class Initialized
INFO - 2024-03-14 17:42:51 --> Router Class Initialized
INFO - 2024-03-14 17:42:51 --> Output Class Initialized
INFO - 2024-03-14 17:42:51 --> Security Class Initialized
DEBUG - 2024-03-14 17:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:42:51 --> Input Class Initialized
INFO - 2024-03-14 17:42:51 --> Language Class Initialized
INFO - 2024-03-14 17:42:51 --> Loader Class Initialized
INFO - 2024-03-14 17:42:51 --> Helper loaded: url_helper
INFO - 2024-03-14 17:42:51 --> Helper loaded: file_helper
INFO - 2024-03-14 17:42:51 --> Helper loaded: form_helper
INFO - 2024-03-14 17:42:51 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:42:51 --> Controller Class Initialized
INFO - 2024-03-14 17:42:51 --> Form Validation Class Initialized
INFO - 2024-03-14 17:42:51 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-14 17:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-14 17:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-14 17:42:51 --> Final output sent to browser
DEBUG - 2024-03-14 17:42:51 --> Total execution time: 0.0382
ERROR - 2024-03-14 17:42:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:42:51 --> Config Class Initialized
INFO - 2024-03-14 17:42:51 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:42:51 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:42:51 --> Utf8 Class Initialized
INFO - 2024-03-14 17:42:51 --> URI Class Initialized
INFO - 2024-03-14 17:42:51 --> Router Class Initialized
INFO - 2024-03-14 17:42:51 --> Output Class Initialized
INFO - 2024-03-14 17:42:51 --> Security Class Initialized
DEBUG - 2024-03-14 17:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:42:51 --> Input Class Initialized
INFO - 2024-03-14 17:42:51 --> Language Class Initialized
INFO - 2024-03-14 17:42:51 --> Loader Class Initialized
INFO - 2024-03-14 17:42:51 --> Helper loaded: url_helper
INFO - 2024-03-14 17:42:51 --> Helper loaded: file_helper
INFO - 2024-03-14 17:42:51 --> Helper loaded: form_helper
INFO - 2024-03-14 17:42:51 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:42:51 --> Controller Class Initialized
INFO - 2024-03-14 17:42:51 --> Form Validation Class Initialized
INFO - 2024-03-14 17:42:51 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:42:51 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:42:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:42:57 --> Config Class Initialized
INFO - 2024-03-14 17:42:57 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:42:57 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:42:57 --> Utf8 Class Initialized
INFO - 2024-03-14 17:42:57 --> URI Class Initialized
INFO - 2024-03-14 17:42:57 --> Router Class Initialized
INFO - 2024-03-14 17:42:57 --> Output Class Initialized
INFO - 2024-03-14 17:42:57 --> Security Class Initialized
DEBUG - 2024-03-14 17:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:42:57 --> Input Class Initialized
INFO - 2024-03-14 17:42:57 --> Language Class Initialized
INFO - 2024-03-14 17:42:57 --> Loader Class Initialized
INFO - 2024-03-14 17:42:57 --> Helper loaded: url_helper
INFO - 2024-03-14 17:42:57 --> Helper loaded: file_helper
INFO - 2024-03-14 17:42:57 --> Helper loaded: form_helper
INFO - 2024-03-14 17:42:57 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:42:57 --> Controller Class Initialized
INFO - 2024-03-14 17:42:57 --> Form Validation Class Initialized
INFO - 2024-03-14 17:42:57 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:42:57 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:42:57 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:42:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:42:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:42:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:42:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:42:57 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:42:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:42:57 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:43:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:00 --> Config Class Initialized
INFO - 2024-03-14 17:43:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:00 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:00 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:00 --> URI Class Initialized
INFO - 2024-03-14 17:43:00 --> Router Class Initialized
INFO - 2024-03-14 17:43:00 --> Output Class Initialized
INFO - 2024-03-14 17:43:00 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:00 --> Input Class Initialized
INFO - 2024-03-14 17:43:00 --> Language Class Initialized
INFO - 2024-03-14 17:43:00 --> Loader Class Initialized
INFO - 2024-03-14 17:43:00 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:00 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:00 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:00 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:00 --> Controller Class Initialized
INFO - 2024-03-14 17:43:00 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:00 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:00 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:00 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:00 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:00 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:43:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-14 17:43:00 --> Final output sent to browser
DEBUG - 2024-03-14 17:43:00 --> Total execution time: 0.0466
ERROR - 2024-03-14 17:43:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:08 --> Config Class Initialized
INFO - 2024-03-14 17:43:08 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:08 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:08 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:08 --> URI Class Initialized
INFO - 2024-03-14 17:43:08 --> Router Class Initialized
INFO - 2024-03-14 17:43:08 --> Output Class Initialized
INFO - 2024-03-14 17:43:08 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:08 --> Input Class Initialized
INFO - 2024-03-14 17:43:08 --> Language Class Initialized
INFO - 2024-03-14 17:43:08 --> Loader Class Initialized
INFO - 2024-03-14 17:43:08 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:08 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:08 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:08 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:08 --> Controller Class Initialized
INFO - 2024-03-14 17:43:08 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:08 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:08 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:08 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:08 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:08 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:43:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:10 --> Config Class Initialized
INFO - 2024-03-14 17:43:10 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:10 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:10 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:10 --> URI Class Initialized
INFO - 2024-03-14 17:43:10 --> Router Class Initialized
INFO - 2024-03-14 17:43:10 --> Output Class Initialized
INFO - 2024-03-14 17:43:10 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:10 --> Input Class Initialized
INFO - 2024-03-14 17:43:10 --> Language Class Initialized
INFO - 2024-03-14 17:43:10 --> Loader Class Initialized
INFO - 2024-03-14 17:43:10 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:10 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:10 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:10 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:10 --> Controller Class Initialized
INFO - 2024-03-14 17:43:10 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:10 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:10 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:10 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:10 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:10 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:43:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-14 17:43:10 --> Final output sent to browser
DEBUG - 2024-03-14 17:43:10 --> Total execution time: 0.0630
ERROR - 2024-03-14 17:43:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:13 --> Config Class Initialized
INFO - 2024-03-14 17:43:13 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:13 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:13 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:13 --> URI Class Initialized
INFO - 2024-03-14 17:43:13 --> Router Class Initialized
INFO - 2024-03-14 17:43:13 --> Output Class Initialized
INFO - 2024-03-14 17:43:13 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:13 --> Input Class Initialized
INFO - 2024-03-14 17:43:13 --> Language Class Initialized
INFO - 2024-03-14 17:43:13 --> Loader Class Initialized
INFO - 2024-03-14 17:43:13 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:13 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:13 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:13 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:13 --> Controller Class Initialized
INFO - 2024-03-14 17:43:13 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:13 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:13 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:13 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:13 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:13 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:43:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:20 --> Config Class Initialized
INFO - 2024-03-14 17:43:20 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:20 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:20 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:20 --> URI Class Initialized
INFO - 2024-03-14 17:43:20 --> Router Class Initialized
INFO - 2024-03-14 17:43:20 --> Output Class Initialized
INFO - 2024-03-14 17:43:20 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:20 --> Input Class Initialized
INFO - 2024-03-14 17:43:20 --> Language Class Initialized
INFO - 2024-03-14 17:43:20 --> Loader Class Initialized
INFO - 2024-03-14 17:43:20 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:20 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:20 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:20 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:20 --> Controller Class Initialized
INFO - 2024-03-14 17:43:20 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:20 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:20 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:20 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:20 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:20 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:43:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:43:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-14 17:43:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:43:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:43:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:43:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:43:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-14 17:43:20 --> Final output sent to browser
DEBUG - 2024-03-14 17:43:20 --> Total execution time: 0.0310
ERROR - 2024-03-14 17:43:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:21 --> Config Class Initialized
INFO - 2024-03-14 17:43:21 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:21 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:21 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:21 --> URI Class Initialized
INFO - 2024-03-14 17:43:21 --> Router Class Initialized
INFO - 2024-03-14 17:43:21 --> Output Class Initialized
INFO - 2024-03-14 17:43:21 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:21 --> Input Class Initialized
INFO - 2024-03-14 17:43:21 --> Language Class Initialized
INFO - 2024-03-14 17:43:21 --> Loader Class Initialized
INFO - 2024-03-14 17:43:21 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:21 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:21 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:21 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:21 --> Controller Class Initialized
INFO - 2024-03-14 17:43:21 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:21 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:21 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:21 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:21 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:21 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:43:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:22 --> Config Class Initialized
INFO - 2024-03-14 17:43:22 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:22 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:22 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:22 --> URI Class Initialized
INFO - 2024-03-14 17:43:22 --> Router Class Initialized
INFO - 2024-03-14 17:43:22 --> Output Class Initialized
INFO - 2024-03-14 17:43:22 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:22 --> Input Class Initialized
INFO - 2024-03-14 17:43:22 --> Language Class Initialized
INFO - 2024-03-14 17:43:22 --> Loader Class Initialized
INFO - 2024-03-14 17:43:22 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:22 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:22 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:22 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:22 --> Controller Class Initialized
INFO - 2024-03-14 17:43:22 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:22 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:22 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:22 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:22 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:22 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-14 17:43:22 --> Final output sent to browser
DEBUG - 2024-03-14 17:43:22 --> Total execution time: 0.0385
ERROR - 2024-03-14 17:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:25 --> Config Class Initialized
INFO - 2024-03-14 17:43:25 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:25 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:25 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:25 --> URI Class Initialized
INFO - 2024-03-14 17:43:25 --> Router Class Initialized
INFO - 2024-03-14 17:43:25 --> Output Class Initialized
INFO - 2024-03-14 17:43:25 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:25 --> Input Class Initialized
INFO - 2024-03-14 17:43:25 --> Language Class Initialized
INFO - 2024-03-14 17:43:25 --> Loader Class Initialized
INFO - 2024-03-14 17:43:25 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:25 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:25 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:25 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:25 --> Controller Class Initialized
INFO - 2024-03-14 17:43:25 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:25 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:25 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:25 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:25 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:25 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-14 17:43:25 --> Final output sent to browser
DEBUG - 2024-03-14 17:43:25 --> Total execution time: 0.0390
ERROR - 2024-03-14 17:43:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:30 --> Config Class Initialized
INFO - 2024-03-14 17:43:30 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:30 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:30 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:30 --> URI Class Initialized
INFO - 2024-03-14 17:43:30 --> Router Class Initialized
INFO - 2024-03-14 17:43:30 --> Output Class Initialized
INFO - 2024-03-14 17:43:30 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:30 --> Input Class Initialized
INFO - 2024-03-14 17:43:30 --> Language Class Initialized
INFO - 2024-03-14 17:43:30 --> Loader Class Initialized
INFO - 2024-03-14 17:43:30 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:30 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:30 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:30 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:30 --> Controller Class Initialized
INFO - 2024-03-14 17:43:30 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:30 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:30 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:30 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:30 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:30 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:43:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/change_password.php
INFO - 2024-03-14 17:43:30 --> Final output sent to browser
DEBUG - 2024-03-14 17:43:30 --> Total execution time: 0.0458
ERROR - 2024-03-14 17:43:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:33 --> Config Class Initialized
INFO - 2024-03-14 17:43:33 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:33 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:33 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:33 --> URI Class Initialized
INFO - 2024-03-14 17:43:33 --> Router Class Initialized
INFO - 2024-03-14 17:43:33 --> Output Class Initialized
INFO - 2024-03-14 17:43:33 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:33 --> Input Class Initialized
INFO - 2024-03-14 17:43:33 --> Language Class Initialized
INFO - 2024-03-14 17:43:33 --> Loader Class Initialized
INFO - 2024-03-14 17:43:33 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:33 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:33 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:33 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:33 --> Controller Class Initialized
INFO - 2024-03-14 17:43:33 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:33 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:43:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:43:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-14 17:43:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:43:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:43:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:43:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:43:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-14 17:43:33 --> Final output sent to browser
DEBUG - 2024-03-14 17:43:33 --> Total execution time: 0.0345
ERROR - 2024-03-14 17:43:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:33 --> Config Class Initialized
INFO - 2024-03-14 17:43:33 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:33 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:33 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:33 --> URI Class Initialized
INFO - 2024-03-14 17:43:33 --> Router Class Initialized
INFO - 2024-03-14 17:43:33 --> Output Class Initialized
INFO - 2024-03-14 17:43:33 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:33 --> Input Class Initialized
INFO - 2024-03-14 17:43:33 --> Language Class Initialized
INFO - 2024-03-14 17:43:33 --> Loader Class Initialized
INFO - 2024-03-14 17:43:33 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:33 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:33 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:33 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:33 --> Controller Class Initialized
INFO - 2024-03-14 17:43:33 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:33 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:33 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:43:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:36 --> Config Class Initialized
INFO - 2024-03-14 17:43:36 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:36 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:36 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:36 --> URI Class Initialized
INFO - 2024-03-14 17:43:36 --> Router Class Initialized
INFO - 2024-03-14 17:43:36 --> Output Class Initialized
INFO - 2024-03-14 17:43:36 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:36 --> Input Class Initialized
INFO - 2024-03-14 17:43:36 --> Language Class Initialized
INFO - 2024-03-14 17:43:36 --> Loader Class Initialized
INFO - 2024-03-14 17:43:36 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:36 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:36 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:36 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:36 --> Controller Class Initialized
INFO - 2024-03-14 17:43:36 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:36 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:36 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:36 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:36 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:36 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-14 17:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-14 17:43:36 --> Final output sent to browser
DEBUG - 2024-03-14 17:43:36 --> Total execution time: 0.0418
ERROR - 2024-03-14 17:43:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:48 --> Config Class Initialized
INFO - 2024-03-14 17:43:48 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:48 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:48 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:48 --> URI Class Initialized
INFO - 2024-03-14 17:43:48 --> Router Class Initialized
INFO - 2024-03-14 17:43:48 --> Output Class Initialized
INFO - 2024-03-14 17:43:48 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:48 --> Input Class Initialized
INFO - 2024-03-14 17:43:48 --> Language Class Initialized
INFO - 2024-03-14 17:43:48 --> Loader Class Initialized
INFO - 2024-03-14 17:43:48 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:48 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:48 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:48 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:48 --> Controller Class Initialized
INFO - 2024-03-14 17:43:48 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:48 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:48 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:48 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:48 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:48 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:43:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:43:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:43:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:43:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:43:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:43:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-14 17:43:48 --> Final output sent to browser
DEBUG - 2024-03-14 17:43:48 --> Total execution time: 0.0535
ERROR - 2024-03-14 17:43:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:50 --> Config Class Initialized
INFO - 2024-03-14 17:43:50 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:50 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:50 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:50 --> URI Class Initialized
INFO - 2024-03-14 17:43:50 --> Router Class Initialized
INFO - 2024-03-14 17:43:50 --> Output Class Initialized
INFO - 2024-03-14 17:43:50 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:50 --> Input Class Initialized
INFO - 2024-03-14 17:43:50 --> Language Class Initialized
INFO - 2024-03-14 17:43:50 --> Loader Class Initialized
INFO - 2024-03-14 17:43:50 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:50 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:50 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:50 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:50 --> Controller Class Initialized
INFO - 2024-03-14 17:43:50 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:50 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:50 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:50 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:50 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:50 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:43:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:43:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-14 17:43:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:43:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:43:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:43:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:43:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-14 17:43:50 --> Final output sent to browser
DEBUG - 2024-03-14 17:43:50 --> Total execution time: 0.0304
ERROR - 2024-03-14 17:43:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:51 --> Config Class Initialized
INFO - 2024-03-14 17:43:51 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:51 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:51 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:51 --> URI Class Initialized
INFO - 2024-03-14 17:43:51 --> Router Class Initialized
INFO - 2024-03-14 17:43:51 --> Output Class Initialized
INFO - 2024-03-14 17:43:51 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:51 --> Input Class Initialized
INFO - 2024-03-14 17:43:51 --> Language Class Initialized
INFO - 2024-03-14 17:43:51 --> Loader Class Initialized
INFO - 2024-03-14 17:43:51 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:51 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:51 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:51 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:51 --> Controller Class Initialized
INFO - 2024-03-14 17:43:51 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:51 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:51 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:51 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:51 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:51 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:43:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:56 --> Config Class Initialized
INFO - 2024-03-14 17:43:56 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:56 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:56 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:56 --> URI Class Initialized
INFO - 2024-03-14 17:43:56 --> Router Class Initialized
INFO - 2024-03-14 17:43:56 --> Output Class Initialized
INFO - 2024-03-14 17:43:56 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:56 --> Input Class Initialized
INFO - 2024-03-14 17:43:56 --> Language Class Initialized
INFO - 2024-03-14 17:43:56 --> Loader Class Initialized
INFO - 2024-03-14 17:43:56 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:56 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:56 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:56 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:56 --> Controller Class Initialized
INFO - 2024-03-14 17:43:56 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:56 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/index.php
INFO - 2024-03-14 17:43:56 --> Final output sent to browser
DEBUG - 2024-03-14 17:43:56 --> Total execution time: 0.0410
ERROR - 2024-03-14 17:43:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:43:56 --> Config Class Initialized
INFO - 2024-03-14 17:43:56 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:43:56 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:43:56 --> Utf8 Class Initialized
INFO - 2024-03-14 17:43:56 --> URI Class Initialized
INFO - 2024-03-14 17:43:56 --> Router Class Initialized
INFO - 2024-03-14 17:43:56 --> Output Class Initialized
INFO - 2024-03-14 17:43:56 --> Security Class Initialized
DEBUG - 2024-03-14 17:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:43:56 --> Input Class Initialized
INFO - 2024-03-14 17:43:56 --> Language Class Initialized
INFO - 2024-03-14 17:43:56 --> Loader Class Initialized
INFO - 2024-03-14 17:43:56 --> Helper loaded: url_helper
INFO - 2024-03-14 17:43:56 --> Helper loaded: file_helper
INFO - 2024-03-14 17:43:56 --> Helper loaded: form_helper
INFO - 2024-03-14 17:43:56 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:43:56 --> Controller Class Initialized
INFO - 2024-03-14 17:43:56 --> Form Validation Class Initialized
INFO - 2024-03-14 17:43:56 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:43:56 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:44:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:44:02 --> Config Class Initialized
INFO - 2024-03-14 17:44:02 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:44:02 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:44:02 --> Utf8 Class Initialized
INFO - 2024-03-14 17:44:02 --> URI Class Initialized
INFO - 2024-03-14 17:44:02 --> Router Class Initialized
INFO - 2024-03-14 17:44:02 --> Output Class Initialized
INFO - 2024-03-14 17:44:02 --> Security Class Initialized
DEBUG - 2024-03-14 17:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:44:02 --> Input Class Initialized
INFO - 2024-03-14 17:44:02 --> Language Class Initialized
INFO - 2024-03-14 17:44:02 --> Loader Class Initialized
INFO - 2024-03-14 17:44:02 --> Helper loaded: url_helper
INFO - 2024-03-14 17:44:02 --> Helper loaded: file_helper
INFO - 2024-03-14 17:44:02 --> Helper loaded: form_helper
INFO - 2024-03-14 17:44:02 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:44:02 --> Controller Class Initialized
INFO - 2024-03-14 17:44:02 --> Form Validation Class Initialized
INFO - 2024-03-14 17:44:02 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:44:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:44:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-14 17:44:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:44:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:44:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:44:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:44:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-14 17:44:02 --> Final output sent to browser
DEBUG - 2024-03-14 17:44:02 --> Total execution time: 0.0331
ERROR - 2024-03-14 17:44:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:44:02 --> Config Class Initialized
INFO - 2024-03-14 17:44:02 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:44:02 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:44:02 --> Utf8 Class Initialized
INFO - 2024-03-14 17:44:02 --> URI Class Initialized
INFO - 2024-03-14 17:44:02 --> Router Class Initialized
INFO - 2024-03-14 17:44:02 --> Output Class Initialized
INFO - 2024-03-14 17:44:02 --> Security Class Initialized
DEBUG - 2024-03-14 17:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:44:02 --> Input Class Initialized
INFO - 2024-03-14 17:44:02 --> Language Class Initialized
INFO - 2024-03-14 17:44:02 --> Loader Class Initialized
INFO - 2024-03-14 17:44:02 --> Helper loaded: url_helper
INFO - 2024-03-14 17:44:02 --> Helper loaded: file_helper
INFO - 2024-03-14 17:44:02 --> Helper loaded: form_helper
INFO - 2024-03-14 17:44:02 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:44:02 --> Controller Class Initialized
INFO - 2024-03-14 17:44:02 --> Form Validation Class Initialized
INFO - 2024-03-14 17:44:02 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:44:02 --> Model "ReportModel" initialized
ERROR - 2024-03-14 17:44:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-14 17:44:04 --> Config Class Initialized
INFO - 2024-03-14 17:44:04 --> Hooks Class Initialized
DEBUG - 2024-03-14 17:44:04 --> UTF-8 Support Enabled
INFO - 2024-03-14 17:44:04 --> Utf8 Class Initialized
INFO - 2024-03-14 17:44:04 --> URI Class Initialized
INFO - 2024-03-14 17:44:04 --> Router Class Initialized
INFO - 2024-03-14 17:44:04 --> Output Class Initialized
INFO - 2024-03-14 17:44:04 --> Security Class Initialized
DEBUG - 2024-03-14 17:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 17:44:04 --> Input Class Initialized
INFO - 2024-03-14 17:44:04 --> Language Class Initialized
INFO - 2024-03-14 17:44:04 --> Loader Class Initialized
INFO - 2024-03-14 17:44:04 --> Helper loaded: url_helper
INFO - 2024-03-14 17:44:04 --> Helper loaded: file_helper
INFO - 2024-03-14 17:44:04 --> Helper loaded: form_helper
INFO - 2024-03-14 17:44:04 --> Database Driver Class Initialized
DEBUG - 2024-03-14 17:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-14 17:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 17:44:04 --> Controller Class Initialized
INFO - 2024-03-14 17:44:04 --> Form Validation Class Initialized
INFO - 2024-03-14 17:44:04 --> Model "MasterModel" initialized
INFO - 2024-03-14 17:44:04 --> Model "NotificationModel" initialized
INFO - 2024-03-14 17:44:04 --> Model "DashboardModel" initialized
INFO - 2024-03-14 17:44:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-14 17:44:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-14 17:44:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-14 17:44:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-14 17:44:04 --> Model "OrderModel" initialized
INFO - 2024-03-14 17:44:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-14 17:44:04 --> Model "ReportModel" initialized
INFO - 2024-03-14 17:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-14 17:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-14 17:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-14 17:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-14 17:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-14 17:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-14 17:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-14 17:44:04 --> Final output sent to browser
DEBUG - 2024-03-14 17:44:04 --> Total execution time: 0.0378
