<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-08 19:35:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:35:46 --> Config Class Initialized
INFO - 2024-03-08 19:35:46 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:35:46 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:35:46 --> Utf8 Class Initialized
INFO - 2024-03-08 19:35:46 --> URI Class Initialized
INFO - 2024-03-08 19:35:46 --> Router Class Initialized
INFO - 2024-03-08 19:35:46 --> Output Class Initialized
INFO - 2024-03-08 19:35:46 --> Security Class Initialized
DEBUG - 2024-03-08 19:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:35:46 --> Input Class Initialized
INFO - 2024-03-08 19:35:46 --> Language Class Initialized
INFO - 2024-03-08 19:35:46 --> Loader Class Initialized
INFO - 2024-03-08 19:35:46 --> Helper loaded: url_helper
INFO - 2024-03-08 19:35:46 --> Helper loaded: file_helper
INFO - 2024-03-08 19:35:46 --> Helper loaded: form_helper
INFO - 2024-03-08 19:35:46 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:35:46 --> Controller Class Initialized
INFO - 2024-03-08 19:35:46 --> Form Validation Class Initialized
INFO - 2024-03-08 19:35:46 --> Model "MasterModel" initialized
INFO - 2024-03-08 19:35:46 --> Model "NotificationModel" initialized
INFO - 2024-03-08 19:35:46 --> Model "DashboardModel" initialized
INFO - 2024-03-08 19:35:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 19:35:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 19:35:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 19:35:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 19:35:46 --> Model "OrderModel" initialized
INFO - 2024-03-08 19:35:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 19:35:46 --> Model "ReportModel" initialized
INFO - 2024-03-08 19:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 19:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-08 19:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 19:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 19:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 19:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 19:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-08 19:35:46 --> Final output sent to browser
DEBUG - 2024-03-08 19:35:46 --> Total execution time: 0.0363
ERROR - 2024-03-08 19:35:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:35:47 --> Config Class Initialized
INFO - 2024-03-08 19:35:47 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:35:47 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:35:47 --> Utf8 Class Initialized
INFO - 2024-03-08 19:35:47 --> URI Class Initialized
INFO - 2024-03-08 19:35:47 --> Router Class Initialized
INFO - 2024-03-08 19:35:47 --> Output Class Initialized
INFO - 2024-03-08 19:35:47 --> Security Class Initialized
DEBUG - 2024-03-08 19:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:35:47 --> Input Class Initialized
INFO - 2024-03-08 19:35:47 --> Language Class Initialized
INFO - 2024-03-08 19:35:47 --> Loader Class Initialized
INFO - 2024-03-08 19:35:47 --> Helper loaded: url_helper
INFO - 2024-03-08 19:35:47 --> Helper loaded: file_helper
INFO - 2024-03-08 19:35:47 --> Helper loaded: form_helper
INFO - 2024-03-08 19:35:47 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:35:47 --> Controller Class Initialized
INFO - 2024-03-08 19:35:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-03-08 19:35:47 --> Final output sent to browser
DEBUG - 2024-03-08 19:35:47 --> Total execution time: 0.0337
ERROR - 2024-03-08 19:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:35:49 --> Config Class Initialized
INFO - 2024-03-08 19:35:49 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:35:49 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:35:49 --> Utf8 Class Initialized
INFO - 2024-03-08 19:35:49 --> URI Class Initialized
DEBUG - 2024-03-08 19:35:49 --> No URI present. Default controller set.
INFO - 2024-03-08 19:35:49 --> Router Class Initialized
INFO - 2024-03-08 19:35:49 --> Output Class Initialized
INFO - 2024-03-08 19:35:49 --> Security Class Initialized
DEBUG - 2024-03-08 19:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:35:49 --> Input Class Initialized
INFO - 2024-03-08 19:35:49 --> Language Class Initialized
INFO - 2024-03-08 19:35:49 --> Loader Class Initialized
INFO - 2024-03-08 19:35:49 --> Helper loaded: url_helper
INFO - 2024-03-08 19:35:49 --> Helper loaded: file_helper
INFO - 2024-03-08 19:35:49 --> Helper loaded: form_helper
INFO - 2024-03-08 19:35:49 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:35:49 --> Controller Class Initialized
INFO - 2024-03-08 19:35:49 --> Model "LoginModel" initialized
INFO - 2024-03-08 19:35:49 --> Form Validation Class Initialized
INFO - 2024-03-08 19:35:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 19:35:49 --> Final output sent to browser
DEBUG - 2024-03-08 19:35:49 --> Total execution time: 0.0266
ERROR - 2024-03-08 19:36:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:36:28 --> Config Class Initialized
INFO - 2024-03-08 19:36:28 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:36:28 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:36:28 --> Utf8 Class Initialized
INFO - 2024-03-08 19:36:28 --> URI Class Initialized
DEBUG - 2024-03-08 19:36:28 --> No URI present. Default controller set.
INFO - 2024-03-08 19:36:28 --> Router Class Initialized
INFO - 2024-03-08 19:36:28 --> Output Class Initialized
INFO - 2024-03-08 19:36:28 --> Security Class Initialized
DEBUG - 2024-03-08 19:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:36:28 --> Input Class Initialized
INFO - 2024-03-08 19:36:28 --> Language Class Initialized
INFO - 2024-03-08 19:36:28 --> Loader Class Initialized
INFO - 2024-03-08 19:36:28 --> Helper loaded: url_helper
INFO - 2024-03-08 19:36:28 --> Helper loaded: file_helper
INFO - 2024-03-08 19:36:28 --> Helper loaded: form_helper
INFO - 2024-03-08 19:36:28 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:36:28 --> Controller Class Initialized
INFO - 2024-03-08 19:36:28 --> Model "LoginModel" initialized
INFO - 2024-03-08 19:36:28 --> Form Validation Class Initialized
INFO - 2024-03-08 19:36:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 19:36:28 --> Final output sent to browser
DEBUG - 2024-03-08 19:36:28 --> Total execution time: 0.0268
ERROR - 2024-03-08 19:36:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:36:29 --> Config Class Initialized
INFO - 2024-03-08 19:36:29 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:36:29 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:36:29 --> Utf8 Class Initialized
INFO - 2024-03-08 19:36:29 --> URI Class Initialized
INFO - 2024-03-08 19:36:29 --> Router Class Initialized
INFO - 2024-03-08 19:36:29 --> Output Class Initialized
INFO - 2024-03-08 19:36:29 --> Security Class Initialized
DEBUG - 2024-03-08 19:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:36:29 --> Input Class Initialized
INFO - 2024-03-08 19:36:29 --> Language Class Initialized
INFO - 2024-03-08 19:36:29 --> Loader Class Initialized
INFO - 2024-03-08 19:36:29 --> Helper loaded: url_helper
INFO - 2024-03-08 19:36:29 --> Helper loaded: file_helper
INFO - 2024-03-08 19:36:29 --> Helper loaded: form_helper
INFO - 2024-03-08 19:36:29 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:36:29 --> Controller Class Initialized
INFO - 2024-03-08 19:36:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-08 19:36:29 --> Final output sent to browser
DEBUG - 2024-03-08 19:36:29 --> Total execution time: 0.0334
ERROR - 2024-03-08 19:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:37:37 --> Config Class Initialized
INFO - 2024-03-08 19:37:37 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:37:37 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:37:37 --> Utf8 Class Initialized
INFO - 2024-03-08 19:37:37 --> URI Class Initialized
DEBUG - 2024-03-08 19:37:37 --> No URI present. Default controller set.
INFO - 2024-03-08 19:37:37 --> Router Class Initialized
INFO - 2024-03-08 19:37:37 --> Output Class Initialized
INFO - 2024-03-08 19:37:37 --> Security Class Initialized
DEBUG - 2024-03-08 19:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:37:37 --> Input Class Initialized
INFO - 2024-03-08 19:37:37 --> Language Class Initialized
INFO - 2024-03-08 19:37:37 --> Loader Class Initialized
INFO - 2024-03-08 19:37:37 --> Helper loaded: url_helper
INFO - 2024-03-08 19:37:37 --> Helper loaded: file_helper
INFO - 2024-03-08 19:37:37 --> Helper loaded: form_helper
INFO - 2024-03-08 19:37:38 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:37:38 --> Controller Class Initialized
INFO - 2024-03-08 19:37:38 --> Model "LoginModel" initialized
INFO - 2024-03-08 19:37:38 --> Form Validation Class Initialized
INFO - 2024-03-08 19:37:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 19:37:38 --> Final output sent to browser
DEBUG - 2024-03-08 19:37:38 --> Total execution time: 0.0320
ERROR - 2024-03-08 19:37:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:37:38 --> Config Class Initialized
INFO - 2024-03-08 19:37:38 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:37:38 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:37:38 --> Utf8 Class Initialized
INFO - 2024-03-08 19:37:38 --> URI Class Initialized
DEBUG - 2024-03-08 19:37:38 --> No URI present. Default controller set.
INFO - 2024-03-08 19:37:38 --> Router Class Initialized
INFO - 2024-03-08 19:37:38 --> Output Class Initialized
INFO - 2024-03-08 19:37:38 --> Security Class Initialized
DEBUG - 2024-03-08 19:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:37:38 --> Input Class Initialized
INFO - 2024-03-08 19:37:38 --> Language Class Initialized
INFO - 2024-03-08 19:37:38 --> Loader Class Initialized
INFO - 2024-03-08 19:37:38 --> Helper loaded: url_helper
INFO - 2024-03-08 19:37:38 --> Helper loaded: file_helper
INFO - 2024-03-08 19:37:38 --> Helper loaded: form_helper
INFO - 2024-03-08 19:37:38 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:37:38 --> Controller Class Initialized
INFO - 2024-03-08 19:37:38 --> Model "LoginModel" initialized
INFO - 2024-03-08 19:37:38 --> Form Validation Class Initialized
INFO - 2024-03-08 19:37:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 19:37:38 --> Final output sent to browser
DEBUG - 2024-03-08 19:37:38 --> Total execution time: 0.0392
ERROR - 2024-03-08 19:37:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:37:38 --> Config Class Initialized
INFO - 2024-03-08 19:37:38 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:37:38 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:37:38 --> Utf8 Class Initialized
INFO - 2024-03-08 19:37:38 --> URI Class Initialized
INFO - 2024-03-08 19:37:38 --> Router Class Initialized
INFO - 2024-03-08 19:37:38 --> Output Class Initialized
INFO - 2024-03-08 19:37:38 --> Security Class Initialized
DEBUG - 2024-03-08 19:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:37:39 --> Input Class Initialized
INFO - 2024-03-08 19:37:39 --> Language Class Initialized
INFO - 2024-03-08 19:37:39 --> Loader Class Initialized
INFO - 2024-03-08 19:37:39 --> Helper loaded: url_helper
INFO - 2024-03-08 19:37:39 --> Helper loaded: file_helper
INFO - 2024-03-08 19:37:39 --> Helper loaded: form_helper
INFO - 2024-03-08 19:37:39 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:37:39 --> Controller Class Initialized
INFO - 2024-03-08 19:37:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-08 19:37:39 --> Final output sent to browser
DEBUG - 2024-03-08 19:37:39 --> Total execution time: 0.0225
ERROR - 2024-03-08 19:38:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:38:59 --> Config Class Initialized
INFO - 2024-03-08 19:38:59 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:38:59 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:38:59 --> Utf8 Class Initialized
INFO - 2024-03-08 19:38:59 --> URI Class Initialized
DEBUG - 2024-03-08 19:38:59 --> No URI present. Default controller set.
INFO - 2024-03-08 19:38:59 --> Router Class Initialized
INFO - 2024-03-08 19:38:59 --> Output Class Initialized
INFO - 2024-03-08 19:38:59 --> Security Class Initialized
DEBUG - 2024-03-08 19:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:38:59 --> Input Class Initialized
INFO - 2024-03-08 19:38:59 --> Language Class Initialized
INFO - 2024-03-08 19:38:59 --> Loader Class Initialized
INFO - 2024-03-08 19:38:59 --> Helper loaded: url_helper
INFO - 2024-03-08 19:38:59 --> Helper loaded: file_helper
INFO - 2024-03-08 19:38:59 --> Helper loaded: form_helper
INFO - 2024-03-08 19:38:59 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:38:59 --> Controller Class Initialized
INFO - 2024-03-08 19:38:59 --> Model "LoginModel" initialized
INFO - 2024-03-08 19:38:59 --> Form Validation Class Initialized
INFO - 2024-03-08 19:38:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 19:38:59 --> Final output sent to browser
DEBUG - 2024-03-08 19:38:59 --> Total execution time: 0.0258
ERROR - 2024-03-08 19:39:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:39:00 --> Config Class Initialized
INFO - 2024-03-08 19:39:00 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:39:00 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:39:00 --> Utf8 Class Initialized
INFO - 2024-03-08 19:39:00 --> URI Class Initialized
INFO - 2024-03-08 19:39:00 --> Router Class Initialized
INFO - 2024-03-08 19:39:00 --> Output Class Initialized
INFO - 2024-03-08 19:39:00 --> Security Class Initialized
DEBUG - 2024-03-08 19:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:39:00 --> Input Class Initialized
INFO - 2024-03-08 19:39:00 --> Language Class Initialized
INFO - 2024-03-08 19:39:00 --> Loader Class Initialized
INFO - 2024-03-08 19:39:00 --> Helper loaded: url_helper
INFO - 2024-03-08 19:39:00 --> Helper loaded: file_helper
INFO - 2024-03-08 19:39:00 --> Helper loaded: form_helper
INFO - 2024-03-08 19:39:00 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:39:00 --> Controller Class Initialized
INFO - 2024-03-08 19:39:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-08 19:39:00 --> Final output sent to browser
DEBUG - 2024-03-08 19:39:00 --> Total execution time: 0.0312
ERROR - 2024-03-08 19:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:41:34 --> Config Class Initialized
INFO - 2024-03-08 19:41:34 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:41:34 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:41:34 --> Utf8 Class Initialized
INFO - 2024-03-08 19:41:34 --> URI Class Initialized
DEBUG - 2024-03-08 19:41:34 --> No URI present. Default controller set.
INFO - 2024-03-08 19:41:34 --> Router Class Initialized
INFO - 2024-03-08 19:41:34 --> Output Class Initialized
INFO - 2024-03-08 19:41:34 --> Security Class Initialized
DEBUG - 2024-03-08 19:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:41:34 --> Input Class Initialized
INFO - 2024-03-08 19:41:34 --> Language Class Initialized
INFO - 2024-03-08 19:41:34 --> Loader Class Initialized
INFO - 2024-03-08 19:41:34 --> Helper loaded: url_helper
INFO - 2024-03-08 19:41:34 --> Helper loaded: file_helper
INFO - 2024-03-08 19:41:34 --> Helper loaded: form_helper
INFO - 2024-03-08 19:41:34 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:41:34 --> Controller Class Initialized
INFO - 2024-03-08 19:41:34 --> Model "LoginModel" initialized
INFO - 2024-03-08 19:41:34 --> Form Validation Class Initialized
INFO - 2024-03-08 19:41:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 19:41:34 --> Final output sent to browser
DEBUG - 2024-03-08 19:41:34 --> Total execution time: 0.0271
ERROR - 2024-03-08 19:41:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:41:35 --> Config Class Initialized
INFO - 2024-03-08 19:41:35 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:41:35 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:41:35 --> Utf8 Class Initialized
INFO - 2024-03-08 19:41:35 --> URI Class Initialized
DEBUG - 2024-03-08 19:41:35 --> No URI present. Default controller set.
INFO - 2024-03-08 19:41:35 --> Router Class Initialized
INFO - 2024-03-08 19:41:35 --> Output Class Initialized
INFO - 2024-03-08 19:41:35 --> Security Class Initialized
DEBUG - 2024-03-08 19:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:41:35 --> Input Class Initialized
INFO - 2024-03-08 19:41:35 --> Language Class Initialized
INFO - 2024-03-08 19:41:35 --> Loader Class Initialized
INFO - 2024-03-08 19:41:35 --> Helper loaded: url_helper
INFO - 2024-03-08 19:41:35 --> Helper loaded: file_helper
INFO - 2024-03-08 19:41:35 --> Helper loaded: form_helper
INFO - 2024-03-08 19:41:35 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:41:35 --> Controller Class Initialized
INFO - 2024-03-08 19:41:35 --> Model "LoginModel" initialized
INFO - 2024-03-08 19:41:35 --> Form Validation Class Initialized
INFO - 2024-03-08 19:41:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 19:41:35 --> Final output sent to browser
DEBUG - 2024-03-08 19:41:35 --> Total execution time: 0.0372
ERROR - 2024-03-08 19:41:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:41:35 --> Config Class Initialized
INFO - 2024-03-08 19:41:35 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:41:35 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:41:35 --> Utf8 Class Initialized
INFO - 2024-03-08 19:41:35 --> URI Class Initialized
INFO - 2024-03-08 19:41:35 --> Router Class Initialized
INFO - 2024-03-08 19:41:35 --> Output Class Initialized
INFO - 2024-03-08 19:41:35 --> Security Class Initialized
DEBUG - 2024-03-08 19:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:41:35 --> Input Class Initialized
INFO - 2024-03-08 19:41:35 --> Language Class Initialized
INFO - 2024-03-08 19:41:35 --> Loader Class Initialized
INFO - 2024-03-08 19:41:35 --> Helper loaded: url_helper
INFO - 2024-03-08 19:41:35 --> Helper loaded: file_helper
INFO - 2024-03-08 19:41:35 --> Helper loaded: form_helper
INFO - 2024-03-08 19:41:35 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:41:35 --> Controller Class Initialized
INFO - 2024-03-08 19:41:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-08 19:41:35 --> Final output sent to browser
DEBUG - 2024-03-08 19:41:35 --> Total execution time: 0.0468
ERROR - 2024-03-08 19:41:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:41:35 --> Config Class Initialized
INFO - 2024-03-08 19:41:35 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:41:35 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:41:35 --> Utf8 Class Initialized
INFO - 2024-03-08 19:41:35 --> URI Class Initialized
INFO - 2024-03-08 19:41:35 --> Router Class Initialized
INFO - 2024-03-08 19:41:35 --> Output Class Initialized
INFO - 2024-03-08 19:41:35 --> Security Class Initialized
DEBUG - 2024-03-08 19:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:41:35 --> Input Class Initialized
INFO - 2024-03-08 19:41:35 --> Language Class Initialized
INFO - 2024-03-08 19:41:35 --> Loader Class Initialized
INFO - 2024-03-08 19:41:35 --> Helper loaded: url_helper
INFO - 2024-03-08 19:41:35 --> Helper loaded: file_helper
INFO - 2024-03-08 19:41:35 --> Helper loaded: form_helper
INFO - 2024-03-08 19:41:35 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:41:35 --> Controller Class Initialized
INFO - 2024-03-08 19:41:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-08 19:41:35 --> Final output sent to browser
DEBUG - 2024-03-08 19:41:35 --> Total execution time: 0.0290
ERROR - 2024-03-08 19:41:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:41:49 --> Config Class Initialized
INFO - 2024-03-08 19:41:49 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:41:49 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:41:49 --> Utf8 Class Initialized
INFO - 2024-03-08 19:41:49 --> URI Class Initialized
INFO - 2024-03-08 19:41:49 --> Router Class Initialized
INFO - 2024-03-08 19:41:49 --> Output Class Initialized
INFO - 2024-03-08 19:41:49 --> Security Class Initialized
DEBUG - 2024-03-08 19:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:41:49 --> Input Class Initialized
INFO - 2024-03-08 19:41:49 --> Language Class Initialized
INFO - 2024-03-08 19:41:49 --> Loader Class Initialized
INFO - 2024-03-08 19:41:49 --> Helper loaded: url_helper
INFO - 2024-03-08 19:41:49 --> Helper loaded: file_helper
INFO - 2024-03-08 19:41:49 --> Helper loaded: form_helper
INFO - 2024-03-08 19:41:49 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:41:49 --> Controller Class Initialized
INFO - 2024-03-08 19:41:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-08 19:41:49 --> Final output sent to browser
DEBUG - 2024-03-08 19:41:49 --> Total execution time: 0.0205
ERROR - 2024-03-08 19:41:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:41:49 --> Config Class Initialized
INFO - 2024-03-08 19:41:49 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:41:49 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:41:49 --> Utf8 Class Initialized
INFO - 2024-03-08 19:41:49 --> URI Class Initialized
INFO - 2024-03-08 19:41:49 --> Router Class Initialized
INFO - 2024-03-08 19:41:49 --> Output Class Initialized
INFO - 2024-03-08 19:41:49 --> Security Class Initialized
DEBUG - 2024-03-08 19:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:41:49 --> Input Class Initialized
INFO - 2024-03-08 19:41:49 --> Language Class Initialized
INFO - 2024-03-08 19:41:49 --> Loader Class Initialized
INFO - 2024-03-08 19:41:49 --> Helper loaded: url_helper
INFO - 2024-03-08 19:41:49 --> Helper loaded: file_helper
INFO - 2024-03-08 19:41:49 --> Helper loaded: form_helper
INFO - 2024-03-08 19:41:49 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:41:49 --> Controller Class Initialized
INFO - 2024-03-08 19:41:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-08 19:41:49 --> Final output sent to browser
DEBUG - 2024-03-08 19:41:49 --> Total execution time: 0.0410
ERROR - 2024-03-08 19:42:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:42:18 --> Config Class Initialized
INFO - 2024-03-08 19:42:18 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:42:18 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:42:18 --> Utf8 Class Initialized
INFO - 2024-03-08 19:42:18 --> URI Class Initialized
DEBUG - 2024-03-08 19:42:18 --> No URI present. Default controller set.
INFO - 2024-03-08 19:42:18 --> Router Class Initialized
INFO - 2024-03-08 19:42:18 --> Output Class Initialized
INFO - 2024-03-08 19:42:18 --> Security Class Initialized
DEBUG - 2024-03-08 19:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:42:18 --> Input Class Initialized
INFO - 2024-03-08 19:42:18 --> Language Class Initialized
INFO - 2024-03-08 19:42:18 --> Loader Class Initialized
INFO - 2024-03-08 19:42:18 --> Helper loaded: url_helper
INFO - 2024-03-08 19:42:18 --> Helper loaded: file_helper
INFO - 2024-03-08 19:42:18 --> Helper loaded: form_helper
INFO - 2024-03-08 19:42:18 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:42:18 --> Controller Class Initialized
INFO - 2024-03-08 19:42:18 --> Model "LoginModel" initialized
INFO - 2024-03-08 19:42:18 --> Form Validation Class Initialized
INFO - 2024-03-08 19:42:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 19:42:18 --> Final output sent to browser
DEBUG - 2024-03-08 19:42:18 --> Total execution time: 0.0357
ERROR - 2024-03-08 19:42:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:42:18 --> Config Class Initialized
INFO - 2024-03-08 19:42:18 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:42:18 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:42:18 --> Utf8 Class Initialized
INFO - 2024-03-08 19:42:18 --> URI Class Initialized
INFO - 2024-03-08 19:42:18 --> Router Class Initialized
INFO - 2024-03-08 19:42:18 --> Output Class Initialized
INFO - 2024-03-08 19:42:18 --> Security Class Initialized
DEBUG - 2024-03-08 19:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:42:18 --> Input Class Initialized
INFO - 2024-03-08 19:42:18 --> Language Class Initialized
INFO - 2024-03-08 19:42:18 --> Loader Class Initialized
INFO - 2024-03-08 19:42:18 --> Helper loaded: url_helper
INFO - 2024-03-08 19:42:18 --> Helper loaded: file_helper
INFO - 2024-03-08 19:42:18 --> Helper loaded: form_helper
INFO - 2024-03-08 19:42:18 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:42:18 --> Controller Class Initialized
INFO - 2024-03-08 19:42:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-08 19:42:18 --> Final output sent to browser
DEBUG - 2024-03-08 19:42:18 --> Total execution time: 0.0317
ERROR - 2024-03-08 19:52:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:52:52 --> Config Class Initialized
INFO - 2024-03-08 19:52:52 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:52:52 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:52:52 --> Utf8 Class Initialized
INFO - 2024-03-08 19:52:52 --> URI Class Initialized
DEBUG - 2024-03-08 19:52:52 --> No URI present. Default controller set.
INFO - 2024-03-08 19:52:52 --> Router Class Initialized
INFO - 2024-03-08 19:52:52 --> Output Class Initialized
INFO - 2024-03-08 19:52:52 --> Security Class Initialized
DEBUG - 2024-03-08 19:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:52:52 --> Input Class Initialized
INFO - 2024-03-08 19:52:52 --> Language Class Initialized
INFO - 2024-03-08 19:52:52 --> Loader Class Initialized
INFO - 2024-03-08 19:52:52 --> Helper loaded: url_helper
INFO - 2024-03-08 19:52:52 --> Helper loaded: file_helper
INFO - 2024-03-08 19:52:52 --> Helper loaded: form_helper
INFO - 2024-03-08 19:52:52 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:52:52 --> Controller Class Initialized
INFO - 2024-03-08 19:52:52 --> Model "LoginModel" initialized
INFO - 2024-03-08 19:52:52 --> Form Validation Class Initialized
INFO - 2024-03-08 19:52:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 19:52:52 --> Final output sent to browser
DEBUG - 2024-03-08 19:52:52 --> Total execution time: 0.0267
ERROR - 2024-03-08 19:53:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:53:09 --> Config Class Initialized
INFO - 2024-03-08 19:53:09 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:53:09 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:53:09 --> Utf8 Class Initialized
INFO - 2024-03-08 19:53:09 --> URI Class Initialized
DEBUG - 2024-03-08 19:53:09 --> No URI present. Default controller set.
INFO - 2024-03-08 19:53:09 --> Router Class Initialized
INFO - 2024-03-08 19:53:09 --> Output Class Initialized
INFO - 2024-03-08 19:53:09 --> Security Class Initialized
DEBUG - 2024-03-08 19:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:53:09 --> Input Class Initialized
INFO - 2024-03-08 19:53:09 --> Language Class Initialized
INFO - 2024-03-08 19:53:09 --> Loader Class Initialized
INFO - 2024-03-08 19:53:09 --> Helper loaded: url_helper
INFO - 2024-03-08 19:53:09 --> Helper loaded: file_helper
INFO - 2024-03-08 19:53:09 --> Helper loaded: form_helper
INFO - 2024-03-08 19:53:09 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:53:09 --> Controller Class Initialized
INFO - 2024-03-08 19:53:09 --> Model "LoginModel" initialized
INFO - 2024-03-08 19:53:09 --> Form Validation Class Initialized
INFO - 2024-03-08 19:53:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 19:53:09 --> Final output sent to browser
DEBUG - 2024-03-08 19:53:09 --> Total execution time: 0.0270
ERROR - 2024-03-08 19:53:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:53:10 --> Config Class Initialized
INFO - 2024-03-08 19:53:10 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:53:10 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:53:10 --> Utf8 Class Initialized
INFO - 2024-03-08 19:53:10 --> URI Class Initialized
DEBUG - 2024-03-08 19:53:10 --> No URI present. Default controller set.
INFO - 2024-03-08 19:53:10 --> Router Class Initialized
INFO - 2024-03-08 19:53:10 --> Output Class Initialized
INFO - 2024-03-08 19:53:10 --> Security Class Initialized
DEBUG - 2024-03-08 19:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:53:10 --> Input Class Initialized
INFO - 2024-03-08 19:53:10 --> Language Class Initialized
INFO - 2024-03-08 19:53:10 --> Loader Class Initialized
INFO - 2024-03-08 19:53:10 --> Helper loaded: url_helper
INFO - 2024-03-08 19:53:10 --> Helper loaded: file_helper
INFO - 2024-03-08 19:53:10 --> Helper loaded: form_helper
INFO - 2024-03-08 19:53:10 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:53:10 --> Controller Class Initialized
INFO - 2024-03-08 19:53:10 --> Model "LoginModel" initialized
INFO - 2024-03-08 19:53:10 --> Form Validation Class Initialized
INFO - 2024-03-08 19:53:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 19:53:10 --> Final output sent to browser
DEBUG - 2024-03-08 19:53:10 --> Total execution time: 0.0267
ERROR - 2024-03-08 19:53:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 19:53:13 --> Config Class Initialized
INFO - 2024-03-08 19:53:13 --> Hooks Class Initialized
DEBUG - 2024-03-08 19:53:13 --> UTF-8 Support Enabled
INFO - 2024-03-08 19:53:13 --> Utf8 Class Initialized
INFO - 2024-03-08 19:53:13 --> URI Class Initialized
DEBUG - 2024-03-08 19:53:13 --> No URI present. Default controller set.
INFO - 2024-03-08 19:53:13 --> Router Class Initialized
INFO - 2024-03-08 19:53:13 --> Output Class Initialized
INFO - 2024-03-08 19:53:13 --> Security Class Initialized
DEBUG - 2024-03-08 19:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 19:53:13 --> Input Class Initialized
INFO - 2024-03-08 19:53:13 --> Language Class Initialized
INFO - 2024-03-08 19:53:13 --> Loader Class Initialized
INFO - 2024-03-08 19:53:13 --> Helper loaded: url_helper
INFO - 2024-03-08 19:53:13 --> Helper loaded: file_helper
INFO - 2024-03-08 19:53:13 --> Helper loaded: form_helper
INFO - 2024-03-08 19:53:13 --> Database Driver Class Initialized
DEBUG - 2024-03-08 19:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 19:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 19:53:13 --> Controller Class Initialized
INFO - 2024-03-08 19:53:13 --> Model "LoginModel" initialized
INFO - 2024-03-08 19:53:13 --> Form Validation Class Initialized
INFO - 2024-03-08 19:53:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 19:53:13 --> Final output sent to browser
DEBUG - 2024-03-08 19:53:13 --> Total execution time: 0.0219
ERROR - 2024-03-08 20:28:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:28:09 --> Config Class Initialized
INFO - 2024-03-08 20:28:09 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:28:09 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:28:09 --> Utf8 Class Initialized
INFO - 2024-03-08 20:28:09 --> URI Class Initialized
DEBUG - 2024-03-08 20:28:09 --> No URI present. Default controller set.
INFO - 2024-03-08 20:28:09 --> Router Class Initialized
INFO - 2024-03-08 20:28:09 --> Output Class Initialized
INFO - 2024-03-08 20:28:09 --> Security Class Initialized
DEBUG - 2024-03-08 20:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:28:09 --> Input Class Initialized
INFO - 2024-03-08 20:28:09 --> Language Class Initialized
INFO - 2024-03-08 20:28:09 --> Loader Class Initialized
INFO - 2024-03-08 20:28:09 --> Helper loaded: url_helper
INFO - 2024-03-08 20:28:09 --> Helper loaded: file_helper
INFO - 2024-03-08 20:28:09 --> Helper loaded: form_helper
INFO - 2024-03-08 20:28:09 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:28:09 --> Controller Class Initialized
INFO - 2024-03-08 20:28:09 --> Model "LoginModel" initialized
INFO - 2024-03-08 20:28:09 --> Form Validation Class Initialized
INFO - 2024-03-08 20:28:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 20:28:09 --> Final output sent to browser
DEBUG - 2024-03-08 20:28:09 --> Total execution time: 0.0293
ERROR - 2024-03-08 20:28:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:28:22 --> Config Class Initialized
INFO - 2024-03-08 20:28:22 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:28:22 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:28:22 --> Utf8 Class Initialized
INFO - 2024-03-08 20:28:22 --> URI Class Initialized
INFO - 2024-03-08 20:28:22 --> Router Class Initialized
INFO - 2024-03-08 20:28:22 --> Output Class Initialized
INFO - 2024-03-08 20:28:22 --> Security Class Initialized
DEBUG - 2024-03-08 20:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:28:22 --> Input Class Initialized
INFO - 2024-03-08 20:28:22 --> Language Class Initialized
INFO - 2024-03-08 20:28:22 --> Loader Class Initialized
INFO - 2024-03-08 20:28:22 --> Helper loaded: url_helper
INFO - 2024-03-08 20:28:22 --> Helper loaded: file_helper
INFO - 2024-03-08 20:28:22 --> Helper loaded: form_helper
INFO - 2024-03-08 20:28:22 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:28:22 --> Controller Class Initialized
INFO - 2024-03-08 20:28:22 --> Model "LoginModel" initialized
INFO - 2024-03-08 20:28:22 --> Form Validation Class Initialized
INFO - 2024-03-08 20:28:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-08 20:28:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:28:22 --> Config Class Initialized
INFO - 2024-03-08 20:28:22 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:28:22 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:28:22 --> Utf8 Class Initialized
INFO - 2024-03-08 20:28:22 --> URI Class Initialized
INFO - 2024-03-08 20:28:22 --> Router Class Initialized
INFO - 2024-03-08 20:28:22 --> Output Class Initialized
INFO - 2024-03-08 20:28:22 --> Security Class Initialized
DEBUG - 2024-03-08 20:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:28:22 --> Input Class Initialized
INFO - 2024-03-08 20:28:22 --> Language Class Initialized
INFO - 2024-03-08 20:28:22 --> Loader Class Initialized
INFO - 2024-03-08 20:28:22 --> Helper loaded: url_helper
INFO - 2024-03-08 20:28:22 --> Helper loaded: file_helper
INFO - 2024-03-08 20:28:22 --> Helper loaded: form_helper
INFO - 2024-03-08 20:28:22 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:28:22 --> Controller Class Initialized
INFO - 2024-03-08 20:28:22 --> Form Validation Class Initialized
INFO - 2024-03-08 20:28:22 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:28:22 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:28:22 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:28:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:28:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:28:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:28:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:28:22 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:28:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:28:22 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:28:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:28:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-08 20:28:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:28:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:28:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:28:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:28:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-08 20:28:22 --> Final output sent to browser
DEBUG - 2024-03-08 20:28:22 --> Total execution time: 0.0273
ERROR - 2024-03-08 20:28:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:28:23 --> Config Class Initialized
INFO - 2024-03-08 20:28:23 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:28:23 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:28:23 --> Utf8 Class Initialized
INFO - 2024-03-08 20:28:23 --> URI Class Initialized
INFO - 2024-03-08 20:28:23 --> Router Class Initialized
INFO - 2024-03-08 20:28:23 --> Output Class Initialized
INFO - 2024-03-08 20:28:23 --> Security Class Initialized
DEBUG - 2024-03-08 20:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:28:23 --> Input Class Initialized
INFO - 2024-03-08 20:28:23 --> Language Class Initialized
INFO - 2024-03-08 20:28:23 --> Loader Class Initialized
INFO - 2024-03-08 20:28:23 --> Helper loaded: url_helper
INFO - 2024-03-08 20:28:23 --> Helper loaded: file_helper
INFO - 2024-03-08 20:28:23 --> Helper loaded: form_helper
INFO - 2024-03-08 20:28:23 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:28:23 --> Controller Class Initialized
INFO - 2024-03-08 20:28:23 --> Form Validation Class Initialized
INFO - 2024-03-08 20:28:23 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:28:23 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:28:23 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:28:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:28:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:28:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:28:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:28:23 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:28:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:28:23 --> Model "ReportModel" initialized
ERROR - 2024-03-08 20:28:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:28:45 --> Config Class Initialized
INFO - 2024-03-08 20:28:45 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:28:45 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:28:45 --> Utf8 Class Initialized
INFO - 2024-03-08 20:28:45 --> URI Class Initialized
INFO - 2024-03-08 20:28:45 --> Router Class Initialized
INFO - 2024-03-08 20:28:45 --> Output Class Initialized
INFO - 2024-03-08 20:28:45 --> Security Class Initialized
DEBUG - 2024-03-08 20:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:28:45 --> Input Class Initialized
INFO - 2024-03-08 20:28:45 --> Language Class Initialized
INFO - 2024-03-08 20:28:45 --> Loader Class Initialized
INFO - 2024-03-08 20:28:45 --> Helper loaded: url_helper
INFO - 2024-03-08 20:28:45 --> Helper loaded: file_helper
INFO - 2024-03-08 20:28:45 --> Helper loaded: form_helper
INFO - 2024-03-08 20:28:45 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:28:45 --> Controller Class Initialized
INFO - 2024-03-08 20:28:45 --> Form Validation Class Initialized
INFO - 2024-03-08 20:28:45 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:28:45 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:28:45 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:28:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:28:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:28:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:28:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:28:45 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:28:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:28:45 --> Model "ReportModel" initialized
DEBUG - 2024-03-08 20:28:45 --> Config file loaded: D:\xampp\htdocs\sscy\application\config/androidfcm.php
ERROR - 2024-03-08 20:28:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:28:46 --> Config Class Initialized
INFO - 2024-03-08 20:28:46 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:28:46 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:28:46 --> Utf8 Class Initialized
INFO - 2024-03-08 20:28:46 --> URI Class Initialized
INFO - 2024-03-08 20:28:46 --> Router Class Initialized
INFO - 2024-03-08 20:28:46 --> Output Class Initialized
INFO - 2024-03-08 20:28:46 --> Security Class Initialized
DEBUG - 2024-03-08 20:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:28:46 --> Input Class Initialized
INFO - 2024-03-08 20:28:46 --> Language Class Initialized
INFO - 2024-03-08 20:28:46 --> Loader Class Initialized
INFO - 2024-03-08 20:28:46 --> Helper loaded: url_helper
INFO - 2024-03-08 20:28:46 --> Helper loaded: file_helper
INFO - 2024-03-08 20:28:46 --> Helper loaded: form_helper
INFO - 2024-03-08 20:28:46 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:28:46 --> Controller Class Initialized
INFO - 2024-03-08 20:28:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-08 20:28:46 --> Final output sent to browser
DEBUG - 2024-03-08 20:28:46 --> Total execution time: 0.0240
ERROR - 2024-03-08 20:30:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:30:07 --> Config Class Initialized
INFO - 2024-03-08 20:30:07 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:30:07 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:30:07 --> Utf8 Class Initialized
INFO - 2024-03-08 20:30:07 --> URI Class Initialized
INFO - 2024-03-08 20:30:07 --> Router Class Initialized
INFO - 2024-03-08 20:30:07 --> Output Class Initialized
INFO - 2024-03-08 20:30:07 --> Security Class Initialized
DEBUG - 2024-03-08 20:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:30:07 --> Input Class Initialized
INFO - 2024-03-08 20:30:07 --> Language Class Initialized
INFO - 2024-03-08 20:30:07 --> Loader Class Initialized
INFO - 2024-03-08 20:30:07 --> Helper loaded: url_helper
INFO - 2024-03-08 20:30:07 --> Helper loaded: file_helper
INFO - 2024-03-08 20:30:07 --> Helper loaded: form_helper
INFO - 2024-03-08 20:30:07 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:30:07 --> Controller Class Initialized
INFO - 2024-03-08 20:30:07 --> Form Validation Class Initialized
INFO - 2024-03-08 20:30:07 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:30:07 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:30:07 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:30:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:30:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:30:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:30:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:30:07 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:30:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:30:07 --> Model "ReportModel" initialized
DEBUG - 2024-03-08 20:30:07 --> Config file loaded: D:\xampp\htdocs\sscy\application\config/androidfcm.php
ERROR - 2024-03-08 20:30:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:30:25 --> Config Class Initialized
INFO - 2024-03-08 20:30:25 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:30:25 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:30:25 --> Utf8 Class Initialized
INFO - 2024-03-08 20:30:25 --> URI Class Initialized
INFO - 2024-03-08 20:30:25 --> Router Class Initialized
INFO - 2024-03-08 20:30:25 --> Output Class Initialized
INFO - 2024-03-08 20:30:25 --> Security Class Initialized
DEBUG - 2024-03-08 20:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:30:25 --> Input Class Initialized
INFO - 2024-03-08 20:30:25 --> Language Class Initialized
INFO - 2024-03-08 20:30:25 --> Loader Class Initialized
INFO - 2024-03-08 20:30:25 --> Helper loaded: url_helper
INFO - 2024-03-08 20:30:25 --> Helper loaded: file_helper
INFO - 2024-03-08 20:30:25 --> Helper loaded: form_helper
INFO - 2024-03-08 20:30:25 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:30:25 --> Controller Class Initialized
INFO - 2024-03-08 20:30:25 --> Form Validation Class Initialized
INFO - 2024-03-08 20:30:25 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:30:25 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:30:25 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:30:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:30:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:30:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:30:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:30:25 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:30:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:30:25 --> Model "ReportModel" initialized
DEBUG - 2024-03-08 20:30:25 --> Config file loaded: D:\xampp\htdocs\sscy\application\config/androidfcm.php
ERROR - 2024-03-08 20:34:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:34:13 --> Config Class Initialized
INFO - 2024-03-08 20:34:13 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:34:13 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:34:13 --> Utf8 Class Initialized
INFO - 2024-03-08 20:34:13 --> URI Class Initialized
DEBUG - 2024-03-08 20:34:13 --> No URI present. Default controller set.
INFO - 2024-03-08 20:34:13 --> Router Class Initialized
INFO - 2024-03-08 20:34:13 --> Output Class Initialized
INFO - 2024-03-08 20:34:13 --> Security Class Initialized
DEBUG - 2024-03-08 20:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:34:13 --> Input Class Initialized
INFO - 2024-03-08 20:34:13 --> Language Class Initialized
INFO - 2024-03-08 20:34:13 --> Loader Class Initialized
INFO - 2024-03-08 20:34:13 --> Helper loaded: url_helper
INFO - 2024-03-08 20:34:13 --> Helper loaded: file_helper
INFO - 2024-03-08 20:34:13 --> Helper loaded: form_helper
INFO - 2024-03-08 20:34:13 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:34:13 --> Controller Class Initialized
INFO - 2024-03-08 20:34:13 --> Model "LoginModel" initialized
INFO - 2024-03-08 20:34:13 --> Form Validation Class Initialized
INFO - 2024-03-08 20:34:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 20:34:13 --> Final output sent to browser
DEBUG - 2024-03-08 20:34:13 --> Total execution time: 0.0294
ERROR - 2024-03-08 20:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:34:29 --> Config Class Initialized
INFO - 2024-03-08 20:34:29 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:34:29 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:34:29 --> Utf8 Class Initialized
INFO - 2024-03-08 20:34:29 --> URI Class Initialized
DEBUG - 2024-03-08 20:34:29 --> No URI present. Default controller set.
INFO - 2024-03-08 20:34:29 --> Router Class Initialized
INFO - 2024-03-08 20:34:29 --> Output Class Initialized
INFO - 2024-03-08 20:34:29 --> Security Class Initialized
DEBUG - 2024-03-08 20:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:34:29 --> Input Class Initialized
INFO - 2024-03-08 20:34:29 --> Language Class Initialized
INFO - 2024-03-08 20:34:29 --> Loader Class Initialized
INFO - 2024-03-08 20:34:29 --> Helper loaded: url_helper
INFO - 2024-03-08 20:34:29 --> Helper loaded: file_helper
INFO - 2024-03-08 20:34:29 --> Helper loaded: form_helper
INFO - 2024-03-08 20:34:29 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:34:29 --> Controller Class Initialized
INFO - 2024-03-08 20:34:29 --> Model "LoginModel" initialized
INFO - 2024-03-08 20:34:29 --> Form Validation Class Initialized
INFO - 2024-03-08 20:34:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 20:34:29 --> Final output sent to browser
DEBUG - 2024-03-08 20:34:29 --> Total execution time: 0.0237
ERROR - 2024-03-08 20:34:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:34:53 --> Config Class Initialized
INFO - 2024-03-08 20:34:53 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:34:53 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:34:53 --> Utf8 Class Initialized
INFO - 2024-03-08 20:34:53 --> URI Class Initialized
INFO - 2024-03-08 20:34:53 --> Router Class Initialized
INFO - 2024-03-08 20:34:53 --> Output Class Initialized
INFO - 2024-03-08 20:34:53 --> Security Class Initialized
DEBUG - 2024-03-08 20:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:34:53 --> Input Class Initialized
INFO - 2024-03-08 20:34:53 --> Language Class Initialized
INFO - 2024-03-08 20:34:53 --> Loader Class Initialized
INFO - 2024-03-08 20:34:53 --> Helper loaded: url_helper
INFO - 2024-03-08 20:34:53 --> Helper loaded: file_helper
INFO - 2024-03-08 20:34:53 --> Helper loaded: form_helper
INFO - 2024-03-08 20:34:53 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:34:53 --> Controller Class Initialized
INFO - 2024-03-08 20:34:53 --> Model "LoginModel" initialized
INFO - 2024-03-08 20:34:53 --> Form Validation Class Initialized
INFO - 2024-03-08 20:34:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-08 20:34:53 --> Final output sent to browser
DEBUG - 2024-03-08 20:34:53 --> Total execution time: 0.0293
ERROR - 2024-03-08 20:35:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:35:09 --> Config Class Initialized
INFO - 2024-03-08 20:35:09 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:35:09 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:35:09 --> Utf8 Class Initialized
INFO - 2024-03-08 20:35:09 --> URI Class Initialized
INFO - 2024-03-08 20:35:09 --> Router Class Initialized
INFO - 2024-03-08 20:35:09 --> Output Class Initialized
INFO - 2024-03-08 20:35:09 --> Security Class Initialized
DEBUG - 2024-03-08 20:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:35:09 --> Input Class Initialized
INFO - 2024-03-08 20:35:09 --> Language Class Initialized
INFO - 2024-03-08 20:35:09 --> Loader Class Initialized
INFO - 2024-03-08 20:35:09 --> Helper loaded: url_helper
INFO - 2024-03-08 20:35:09 --> Helper loaded: file_helper
INFO - 2024-03-08 20:35:09 --> Helper loaded: form_helper
INFO - 2024-03-08 20:35:09 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:35:09 --> Controller Class Initialized
INFO - 2024-03-08 20:35:09 --> Model "LoginModel" initialized
INFO - 2024-03-08 20:35:09 --> Form Validation Class Initialized
INFO - 2024-03-08 20:35:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-08 20:35:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:35:09 --> Config Class Initialized
INFO - 2024-03-08 20:35:09 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:35:09 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:35:09 --> Utf8 Class Initialized
INFO - 2024-03-08 20:35:09 --> URI Class Initialized
INFO - 2024-03-08 20:35:09 --> Router Class Initialized
INFO - 2024-03-08 20:35:09 --> Output Class Initialized
INFO - 2024-03-08 20:35:09 --> Security Class Initialized
DEBUG - 2024-03-08 20:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:35:09 --> Input Class Initialized
INFO - 2024-03-08 20:35:09 --> Language Class Initialized
INFO - 2024-03-08 20:35:09 --> Loader Class Initialized
INFO - 2024-03-08 20:35:09 --> Helper loaded: url_helper
INFO - 2024-03-08 20:35:09 --> Helper loaded: file_helper
INFO - 2024-03-08 20:35:09 --> Helper loaded: form_helper
INFO - 2024-03-08 20:35:09 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:35:09 --> Controller Class Initialized
INFO - 2024-03-08 20:35:09 --> Form Validation Class Initialized
INFO - 2024-03-08 20:35:09 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:35:09 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:35:09 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:35:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:35:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:35:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:35:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:35:09 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:35:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:35:09 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:35:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:35:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-08 20:35:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:35:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:35:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:35:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:35:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-08 20:35:09 --> Final output sent to browser
DEBUG - 2024-03-08 20:35:09 --> Total execution time: 0.0523
ERROR - 2024-03-08 20:35:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:35:10 --> Config Class Initialized
INFO - 2024-03-08 20:35:10 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:35:10 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:35:10 --> Utf8 Class Initialized
INFO - 2024-03-08 20:35:10 --> URI Class Initialized
INFO - 2024-03-08 20:35:10 --> Router Class Initialized
INFO - 2024-03-08 20:35:10 --> Output Class Initialized
INFO - 2024-03-08 20:35:10 --> Security Class Initialized
DEBUG - 2024-03-08 20:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:35:10 --> Input Class Initialized
INFO - 2024-03-08 20:35:10 --> Language Class Initialized
INFO - 2024-03-08 20:35:10 --> Loader Class Initialized
INFO - 2024-03-08 20:35:10 --> Helper loaded: url_helper
INFO - 2024-03-08 20:35:10 --> Helper loaded: file_helper
INFO - 2024-03-08 20:35:10 --> Helper loaded: form_helper
INFO - 2024-03-08 20:35:10 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:35:10 --> Controller Class Initialized
INFO - 2024-03-08 20:35:10 --> Form Validation Class Initialized
INFO - 2024-03-08 20:35:10 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:35:10 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:35:10 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:35:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:35:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:35:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:35:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:35:10 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:35:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:35:10 --> Model "ReportModel" initialized
ERROR - 2024-03-08 20:35:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:35:46 --> Config Class Initialized
INFO - 2024-03-08 20:35:46 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:35:46 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:35:46 --> Utf8 Class Initialized
INFO - 2024-03-08 20:35:46 --> URI Class Initialized
INFO - 2024-03-08 20:35:46 --> Router Class Initialized
INFO - 2024-03-08 20:35:46 --> Output Class Initialized
INFO - 2024-03-08 20:35:46 --> Security Class Initialized
DEBUG - 2024-03-08 20:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:35:46 --> Input Class Initialized
INFO - 2024-03-08 20:35:46 --> Language Class Initialized
INFO - 2024-03-08 20:35:46 --> Loader Class Initialized
INFO - 2024-03-08 20:35:46 --> Helper loaded: url_helper
INFO - 2024-03-08 20:35:46 --> Helper loaded: file_helper
INFO - 2024-03-08 20:35:46 --> Helper loaded: form_helper
INFO - 2024-03-08 20:35:46 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:35:46 --> Controller Class Initialized
INFO - 2024-03-08 20:35:46 --> Form Validation Class Initialized
INFO - 2024-03-08 20:35:46 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-08 20:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:35:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-08 20:35:46 --> Final output sent to browser
DEBUG - 2024-03-08 20:35:46 --> Total execution time: 0.0344
ERROR - 2024-03-08 20:35:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:35:46 --> Config Class Initialized
INFO - 2024-03-08 20:35:46 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:35:46 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:35:46 --> Utf8 Class Initialized
INFO - 2024-03-08 20:35:46 --> URI Class Initialized
INFO - 2024-03-08 20:35:46 --> Router Class Initialized
INFO - 2024-03-08 20:35:46 --> Output Class Initialized
INFO - 2024-03-08 20:35:46 --> Security Class Initialized
DEBUG - 2024-03-08 20:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:35:46 --> Input Class Initialized
INFO - 2024-03-08 20:35:46 --> Language Class Initialized
INFO - 2024-03-08 20:35:46 --> Loader Class Initialized
INFO - 2024-03-08 20:35:46 --> Helper loaded: url_helper
INFO - 2024-03-08 20:35:46 --> Helper loaded: file_helper
INFO - 2024-03-08 20:35:46 --> Helper loaded: form_helper
INFO - 2024-03-08 20:35:46 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:35:46 --> Controller Class Initialized
INFO - 2024-03-08 20:35:46 --> Form Validation Class Initialized
INFO - 2024-03-08 20:35:46 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:35:46 --> Model "ReportModel" initialized
ERROR - 2024-03-08 20:35:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:35:50 --> Config Class Initialized
INFO - 2024-03-08 20:35:50 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:35:50 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:35:50 --> Utf8 Class Initialized
INFO - 2024-03-08 20:35:50 --> URI Class Initialized
INFO - 2024-03-08 20:35:50 --> Router Class Initialized
INFO - 2024-03-08 20:35:50 --> Output Class Initialized
INFO - 2024-03-08 20:35:50 --> Security Class Initialized
DEBUG - 2024-03-08 20:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:35:50 --> Input Class Initialized
INFO - 2024-03-08 20:35:50 --> Language Class Initialized
INFO - 2024-03-08 20:35:50 --> Loader Class Initialized
INFO - 2024-03-08 20:35:50 --> Helper loaded: url_helper
INFO - 2024-03-08 20:35:50 --> Helper loaded: file_helper
INFO - 2024-03-08 20:35:50 --> Helper loaded: form_helper
INFO - 2024-03-08 20:35:50 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:35:50 --> Controller Class Initialized
INFO - 2024-03-08 20:35:50 --> Form Validation Class Initialized
INFO - 2024-03-08 20:35:50 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:35:50 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:35:50 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:35:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:35:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:35:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:35:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:35:50 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:35:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:35:50 --> Model "ReportModel" initialized
ERROR - 2024-03-08 20:35:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:35:54 --> Config Class Initialized
INFO - 2024-03-08 20:35:54 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:35:54 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:35:54 --> Utf8 Class Initialized
INFO - 2024-03-08 20:35:54 --> URI Class Initialized
INFO - 2024-03-08 20:35:54 --> Router Class Initialized
INFO - 2024-03-08 20:35:54 --> Output Class Initialized
INFO - 2024-03-08 20:35:54 --> Security Class Initialized
DEBUG - 2024-03-08 20:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:35:54 --> Input Class Initialized
INFO - 2024-03-08 20:35:54 --> Language Class Initialized
INFO - 2024-03-08 20:35:54 --> Loader Class Initialized
INFO - 2024-03-08 20:35:54 --> Helper loaded: url_helper
INFO - 2024-03-08 20:35:54 --> Helper loaded: file_helper
INFO - 2024-03-08 20:35:54 --> Helper loaded: form_helper
INFO - 2024-03-08 20:35:54 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:35:54 --> Controller Class Initialized
INFO - 2024-03-08 20:35:54 --> Form Validation Class Initialized
INFO - 2024-03-08 20:35:54 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:35:54 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:35:54 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:35:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:35:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:35:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:35:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:35:54 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:35:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:35:54 --> Model "ReportModel" initialized
ERROR - 2024-03-08 20:36:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:36:06 --> Config Class Initialized
INFO - 2024-03-08 20:36:06 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:36:06 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:36:06 --> Utf8 Class Initialized
INFO - 2024-03-08 20:36:06 --> URI Class Initialized
INFO - 2024-03-08 20:36:06 --> Router Class Initialized
INFO - 2024-03-08 20:36:06 --> Output Class Initialized
INFO - 2024-03-08 20:36:06 --> Security Class Initialized
DEBUG - 2024-03-08 20:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:36:06 --> Input Class Initialized
INFO - 2024-03-08 20:36:06 --> Language Class Initialized
INFO - 2024-03-08 20:36:06 --> Loader Class Initialized
INFO - 2024-03-08 20:36:06 --> Helper loaded: url_helper
INFO - 2024-03-08 20:36:06 --> Helper loaded: file_helper
INFO - 2024-03-08 20:36:06 --> Helper loaded: form_helper
INFO - 2024-03-08 20:36:06 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:36:06 --> Controller Class Initialized
INFO - 2024-03-08 20:36:06 --> Form Validation Class Initialized
INFO - 2024-03-08 20:36:06 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:36:06 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:36:06 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:36:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:36:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:36:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:36:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:36:06 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:36:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:36:06 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:36:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:36:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:36:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:36:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:36:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:36:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:36:06 --> Final output sent to browser
DEBUG - 2024-03-08 20:36:06 --> Total execution time: 0.0240
ERROR - 2024-03-08 20:36:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:36:36 --> Config Class Initialized
INFO - 2024-03-08 20:36:36 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:36:36 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:36:36 --> Utf8 Class Initialized
INFO - 2024-03-08 20:36:36 --> URI Class Initialized
INFO - 2024-03-08 20:36:36 --> Router Class Initialized
INFO - 2024-03-08 20:36:36 --> Output Class Initialized
INFO - 2024-03-08 20:36:36 --> Security Class Initialized
DEBUG - 2024-03-08 20:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:36:36 --> Input Class Initialized
INFO - 2024-03-08 20:36:36 --> Language Class Initialized
INFO - 2024-03-08 20:36:36 --> Loader Class Initialized
INFO - 2024-03-08 20:36:36 --> Helper loaded: url_helper
INFO - 2024-03-08 20:36:36 --> Helper loaded: file_helper
INFO - 2024-03-08 20:36:36 --> Helper loaded: form_helper
INFO - 2024-03-08 20:36:36 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:36:36 --> Controller Class Initialized
INFO - 2024-03-08 20:36:36 --> Form Validation Class Initialized
INFO - 2024-03-08 20:36:36 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:36:36 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:36:36 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:36:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:36:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:36:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:36:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:36:36 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:36:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:36:36 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:36:36 --> Upload Class Initialized
ERROR - 2024-03-08 20:36:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:36:40 --> Config Class Initialized
INFO - 2024-03-08 20:36:40 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:36:40 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:36:40 --> Utf8 Class Initialized
INFO - 2024-03-08 20:36:40 --> URI Class Initialized
INFO - 2024-03-08 20:36:40 --> Router Class Initialized
INFO - 2024-03-08 20:36:40 --> Output Class Initialized
INFO - 2024-03-08 20:36:40 --> Security Class Initialized
DEBUG - 2024-03-08 20:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:36:40 --> Input Class Initialized
INFO - 2024-03-08 20:36:40 --> Language Class Initialized
INFO - 2024-03-08 20:36:40 --> Loader Class Initialized
INFO - 2024-03-08 20:36:40 --> Helper loaded: url_helper
INFO - 2024-03-08 20:36:40 --> Helper loaded: file_helper
INFO - 2024-03-08 20:36:40 --> Helper loaded: form_helper
INFO - 2024-03-08 20:36:40 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:36:40 --> Controller Class Initialized
INFO - 2024-03-08 20:36:40 --> Form Validation Class Initialized
INFO - 2024-03-08 20:36:40 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:36:40 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:36:40 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:36:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:36:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:36:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:36:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:36:40 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:36:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:36:40 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:36:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:36:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:36:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:36:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:36:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:36:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:36:40 --> Final output sent to browser
DEBUG - 2024-03-08 20:36:40 --> Total execution time: 0.0398
ERROR - 2024-03-08 20:36:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:36:42 --> Config Class Initialized
INFO - 2024-03-08 20:36:42 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:36:42 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:36:42 --> Utf8 Class Initialized
INFO - 2024-03-08 20:36:42 --> URI Class Initialized
INFO - 2024-03-08 20:36:42 --> Router Class Initialized
INFO - 2024-03-08 20:36:42 --> Output Class Initialized
INFO - 2024-03-08 20:36:42 --> Security Class Initialized
DEBUG - 2024-03-08 20:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:36:42 --> Input Class Initialized
INFO - 2024-03-08 20:36:42 --> Language Class Initialized
INFO - 2024-03-08 20:36:42 --> Loader Class Initialized
INFO - 2024-03-08 20:36:42 --> Helper loaded: url_helper
INFO - 2024-03-08 20:36:42 --> Helper loaded: file_helper
INFO - 2024-03-08 20:36:42 --> Helper loaded: form_helper
INFO - 2024-03-08 20:36:42 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:36:42 --> Controller Class Initialized
INFO - 2024-03-08 20:36:42 --> Form Validation Class Initialized
INFO - 2024-03-08 20:36:42 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:36:42 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:36:42 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:36:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:36:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:36:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:36:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:36:42 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:36:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:36:42 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:36:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:36:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-08 20:36:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:36:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:36:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:36:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:36:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-08 20:36:42 --> Final output sent to browser
DEBUG - 2024-03-08 20:36:42 --> Total execution time: 0.0360
ERROR - 2024-03-08 20:36:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:36:43 --> Config Class Initialized
INFO - 2024-03-08 20:36:43 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:36:43 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:36:43 --> Utf8 Class Initialized
INFO - 2024-03-08 20:36:43 --> URI Class Initialized
INFO - 2024-03-08 20:36:43 --> Router Class Initialized
INFO - 2024-03-08 20:36:43 --> Output Class Initialized
INFO - 2024-03-08 20:36:43 --> Security Class Initialized
DEBUG - 2024-03-08 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:36:43 --> Input Class Initialized
INFO - 2024-03-08 20:36:43 --> Language Class Initialized
INFO - 2024-03-08 20:36:43 --> Loader Class Initialized
INFO - 2024-03-08 20:36:43 --> Helper loaded: url_helper
INFO - 2024-03-08 20:36:43 --> Helper loaded: file_helper
INFO - 2024-03-08 20:36:43 --> Helper loaded: form_helper
INFO - 2024-03-08 20:36:43 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:36:43 --> Controller Class Initialized
INFO - 2024-03-08 20:36:43 --> Form Validation Class Initialized
INFO - 2024-03-08 20:36:43 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:36:43 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:36:43 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:36:43 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:36:43 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:36:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:36:43 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:36:43 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:36:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:36:43 --> Model "ReportModel" initialized
ERROR - 2024-03-08 20:36:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:36:52 --> Config Class Initialized
INFO - 2024-03-08 20:36:52 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:36:52 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:36:52 --> Utf8 Class Initialized
INFO - 2024-03-08 20:36:52 --> URI Class Initialized
INFO - 2024-03-08 20:36:52 --> Router Class Initialized
INFO - 2024-03-08 20:36:52 --> Output Class Initialized
INFO - 2024-03-08 20:36:52 --> Security Class Initialized
DEBUG - 2024-03-08 20:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:36:52 --> Input Class Initialized
INFO - 2024-03-08 20:36:52 --> Language Class Initialized
INFO - 2024-03-08 20:36:52 --> Loader Class Initialized
INFO - 2024-03-08 20:36:52 --> Helper loaded: url_helper
INFO - 2024-03-08 20:36:52 --> Helper loaded: file_helper
INFO - 2024-03-08 20:36:52 --> Helper loaded: form_helper
INFO - 2024-03-08 20:36:52 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:36:52 --> Controller Class Initialized
INFO - 2024-03-08 20:36:52 --> Form Validation Class Initialized
INFO - 2024-03-08 20:36:52 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:36:52 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:36:52 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:36:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:36:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:36:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:36:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:36:52 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:36:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:36:52 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:36:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:36:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:36:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:36:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:36:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:36:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:36:52 --> Final output sent to browser
DEBUG - 2024-03-08 20:36:52 --> Total execution time: 0.0328
ERROR - 2024-03-08 20:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:37:47 --> Config Class Initialized
INFO - 2024-03-08 20:37:47 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:37:47 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:37:47 --> Utf8 Class Initialized
INFO - 2024-03-08 20:37:47 --> URI Class Initialized
INFO - 2024-03-08 20:37:47 --> Router Class Initialized
INFO - 2024-03-08 20:37:47 --> Output Class Initialized
INFO - 2024-03-08 20:37:47 --> Security Class Initialized
DEBUG - 2024-03-08 20:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:37:47 --> Input Class Initialized
INFO - 2024-03-08 20:37:47 --> Language Class Initialized
INFO - 2024-03-08 20:37:47 --> Loader Class Initialized
INFO - 2024-03-08 20:37:47 --> Helper loaded: url_helper
INFO - 2024-03-08 20:37:47 --> Helper loaded: file_helper
INFO - 2024-03-08 20:37:47 --> Helper loaded: form_helper
INFO - 2024-03-08 20:37:47 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:37:47 --> Controller Class Initialized
INFO - 2024-03-08 20:37:47 --> Form Validation Class Initialized
INFO - 2024-03-08 20:37:47 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:37:47 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:37:47 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:37:47 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:37:47 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:37:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:37:47 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:37:47 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:37:47 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:37:47 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:37:47 --> Upload Class Initialized
ERROR - 2024-03-08 20:37:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:37:50 --> Config Class Initialized
INFO - 2024-03-08 20:37:50 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:37:50 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:37:50 --> Utf8 Class Initialized
INFO - 2024-03-08 20:37:50 --> URI Class Initialized
INFO - 2024-03-08 20:37:50 --> Router Class Initialized
INFO - 2024-03-08 20:37:50 --> Output Class Initialized
INFO - 2024-03-08 20:37:50 --> Security Class Initialized
DEBUG - 2024-03-08 20:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:37:50 --> Input Class Initialized
INFO - 2024-03-08 20:37:50 --> Language Class Initialized
INFO - 2024-03-08 20:37:50 --> Loader Class Initialized
INFO - 2024-03-08 20:37:50 --> Helper loaded: url_helper
INFO - 2024-03-08 20:37:50 --> Helper loaded: file_helper
INFO - 2024-03-08 20:37:50 --> Helper loaded: form_helper
INFO - 2024-03-08 20:37:50 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:37:50 --> Controller Class Initialized
INFO - 2024-03-08 20:37:50 --> Form Validation Class Initialized
INFO - 2024-03-08 20:37:50 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:37:50 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:37:50 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:37:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:37:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:37:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:37:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:37:50 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:37:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:37:50 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:37:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:37:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:37:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:37:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:37:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:37:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:37:50 --> Final output sent to browser
DEBUG - 2024-03-08 20:37:50 --> Total execution time: 0.0378
ERROR - 2024-03-08 20:37:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:37:54 --> Config Class Initialized
INFO - 2024-03-08 20:37:54 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:37:54 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:37:54 --> Utf8 Class Initialized
INFO - 2024-03-08 20:37:54 --> URI Class Initialized
INFO - 2024-03-08 20:37:54 --> Router Class Initialized
INFO - 2024-03-08 20:37:54 --> Output Class Initialized
INFO - 2024-03-08 20:37:54 --> Security Class Initialized
DEBUG - 2024-03-08 20:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:37:54 --> Input Class Initialized
INFO - 2024-03-08 20:37:54 --> Language Class Initialized
INFO - 2024-03-08 20:37:54 --> Loader Class Initialized
INFO - 2024-03-08 20:37:54 --> Helper loaded: url_helper
INFO - 2024-03-08 20:37:54 --> Helper loaded: file_helper
INFO - 2024-03-08 20:37:54 --> Helper loaded: form_helper
INFO - 2024-03-08 20:37:54 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:37:54 --> Controller Class Initialized
INFO - 2024-03-08 20:37:54 --> Form Validation Class Initialized
INFO - 2024-03-08 20:37:54 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:37:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:37:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-08 20:37:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:37:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:37:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:37:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:37:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-08 20:37:54 --> Final output sent to browser
DEBUG - 2024-03-08 20:37:54 --> Total execution time: 0.0358
ERROR - 2024-03-08 20:37:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:37:54 --> Config Class Initialized
INFO - 2024-03-08 20:37:54 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:37:54 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:37:54 --> Utf8 Class Initialized
INFO - 2024-03-08 20:37:54 --> URI Class Initialized
INFO - 2024-03-08 20:37:54 --> Router Class Initialized
INFO - 2024-03-08 20:37:54 --> Output Class Initialized
INFO - 2024-03-08 20:37:54 --> Security Class Initialized
DEBUG - 2024-03-08 20:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:37:54 --> Input Class Initialized
INFO - 2024-03-08 20:37:54 --> Language Class Initialized
INFO - 2024-03-08 20:37:54 --> Loader Class Initialized
INFO - 2024-03-08 20:37:54 --> Helper loaded: url_helper
INFO - 2024-03-08 20:37:54 --> Helper loaded: file_helper
INFO - 2024-03-08 20:37:54 --> Helper loaded: form_helper
INFO - 2024-03-08 20:37:54 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:37:54 --> Controller Class Initialized
INFO - 2024-03-08 20:37:54 --> Form Validation Class Initialized
INFO - 2024-03-08 20:37:54 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:37:54 --> Model "ReportModel" initialized
ERROR - 2024-03-08 20:37:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:37:57 --> Config Class Initialized
INFO - 2024-03-08 20:37:57 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:37:57 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:37:57 --> Utf8 Class Initialized
INFO - 2024-03-08 20:37:57 --> URI Class Initialized
INFO - 2024-03-08 20:37:57 --> Router Class Initialized
INFO - 2024-03-08 20:37:57 --> Output Class Initialized
INFO - 2024-03-08 20:37:57 --> Security Class Initialized
DEBUG - 2024-03-08 20:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:37:57 --> Input Class Initialized
INFO - 2024-03-08 20:37:57 --> Language Class Initialized
INFO - 2024-03-08 20:37:57 --> Loader Class Initialized
INFO - 2024-03-08 20:37:57 --> Helper loaded: url_helper
INFO - 2024-03-08 20:37:57 --> Helper loaded: file_helper
INFO - 2024-03-08 20:37:57 --> Helper loaded: form_helper
INFO - 2024-03-08 20:37:57 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:37:57 --> Controller Class Initialized
INFO - 2024-03-08 20:37:57 --> Form Validation Class Initialized
INFO - 2024-03-08 20:37:57 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:37:57 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:37:57 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:37:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:37:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:37:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:37:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:37:57 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:37:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:37:57 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:37:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:37:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:37:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:37:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:37:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:37:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:37:57 --> Final output sent to browser
DEBUG - 2024-03-08 20:37:57 --> Total execution time: 0.0386
ERROR - 2024-03-08 20:38:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:38:11 --> Config Class Initialized
INFO - 2024-03-08 20:38:11 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:38:11 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:38:11 --> Utf8 Class Initialized
INFO - 2024-03-08 20:38:11 --> URI Class Initialized
INFO - 2024-03-08 20:38:11 --> Router Class Initialized
INFO - 2024-03-08 20:38:11 --> Output Class Initialized
INFO - 2024-03-08 20:38:11 --> Security Class Initialized
DEBUG - 2024-03-08 20:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:38:11 --> Input Class Initialized
INFO - 2024-03-08 20:38:11 --> Language Class Initialized
INFO - 2024-03-08 20:38:11 --> Loader Class Initialized
INFO - 2024-03-08 20:38:11 --> Helper loaded: url_helper
INFO - 2024-03-08 20:38:11 --> Helper loaded: file_helper
INFO - 2024-03-08 20:38:11 --> Helper loaded: form_helper
INFO - 2024-03-08 20:38:11 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:38:11 --> Controller Class Initialized
INFO - 2024-03-08 20:38:11 --> Form Validation Class Initialized
INFO - 2024-03-08 20:38:11 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:38:11 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:38:11 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:38:11 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:38:11 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:38:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:38:11 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:38:11 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:38:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:38:11 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:38:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:38:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-08 20:38:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:38:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:38:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:38:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:38:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-08 20:38:11 --> Final output sent to browser
DEBUG - 2024-03-08 20:38:11 --> Total execution time: 0.0363
ERROR - 2024-03-08 20:38:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:38:12 --> Config Class Initialized
INFO - 2024-03-08 20:38:12 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:38:12 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:38:12 --> Utf8 Class Initialized
INFO - 2024-03-08 20:38:12 --> URI Class Initialized
INFO - 2024-03-08 20:38:12 --> Router Class Initialized
INFO - 2024-03-08 20:38:12 --> Output Class Initialized
INFO - 2024-03-08 20:38:12 --> Security Class Initialized
DEBUG - 2024-03-08 20:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:38:12 --> Input Class Initialized
INFO - 2024-03-08 20:38:12 --> Language Class Initialized
INFO - 2024-03-08 20:38:12 --> Loader Class Initialized
INFO - 2024-03-08 20:38:12 --> Helper loaded: url_helper
INFO - 2024-03-08 20:38:12 --> Helper loaded: file_helper
INFO - 2024-03-08 20:38:12 --> Helper loaded: form_helper
INFO - 2024-03-08 20:38:12 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:38:12 --> Controller Class Initialized
INFO - 2024-03-08 20:38:12 --> Form Validation Class Initialized
INFO - 2024-03-08 20:38:12 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:38:12 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:38:12 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:38:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:38:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:38:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:38:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:38:12 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:38:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:38:12 --> Model "ReportModel" initialized
ERROR - 2024-03-08 20:38:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:38:16 --> Config Class Initialized
INFO - 2024-03-08 20:38:16 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:38:16 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:38:16 --> Utf8 Class Initialized
INFO - 2024-03-08 20:38:16 --> URI Class Initialized
INFO - 2024-03-08 20:38:16 --> Router Class Initialized
INFO - 2024-03-08 20:38:16 --> Output Class Initialized
INFO - 2024-03-08 20:38:16 --> Security Class Initialized
DEBUG - 2024-03-08 20:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:38:16 --> Input Class Initialized
INFO - 2024-03-08 20:38:16 --> Language Class Initialized
INFO - 2024-03-08 20:38:16 --> Loader Class Initialized
INFO - 2024-03-08 20:38:16 --> Helper loaded: url_helper
INFO - 2024-03-08 20:38:16 --> Helper loaded: file_helper
INFO - 2024-03-08 20:38:16 --> Helper loaded: form_helper
INFO - 2024-03-08 20:38:16 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:38:16 --> Controller Class Initialized
INFO - 2024-03-08 20:38:16 --> Form Validation Class Initialized
INFO - 2024-03-08 20:38:16 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:38:16 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:38:16 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:38:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:38:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:38:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:38:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:38:16 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:38:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:38:16 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:38:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:38:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:38:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:38:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:38:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:38:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:38:16 --> Final output sent to browser
DEBUG - 2024-03-08 20:38:16 --> Total execution time: 0.0361
ERROR - 2024-03-08 20:38:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:38:19 --> Config Class Initialized
INFO - 2024-03-08 20:38:19 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:38:19 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:38:19 --> Utf8 Class Initialized
INFO - 2024-03-08 20:38:19 --> URI Class Initialized
INFO - 2024-03-08 20:38:19 --> Router Class Initialized
INFO - 2024-03-08 20:38:19 --> Output Class Initialized
INFO - 2024-03-08 20:38:19 --> Security Class Initialized
DEBUG - 2024-03-08 20:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:38:19 --> Input Class Initialized
INFO - 2024-03-08 20:38:19 --> Language Class Initialized
INFO - 2024-03-08 20:38:19 --> Loader Class Initialized
INFO - 2024-03-08 20:38:19 --> Helper loaded: url_helper
INFO - 2024-03-08 20:38:19 --> Helper loaded: file_helper
INFO - 2024-03-08 20:38:19 --> Helper loaded: form_helper
INFO - 2024-03-08 20:38:19 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:38:19 --> Controller Class Initialized
INFO - 2024-03-08 20:38:19 --> Form Validation Class Initialized
INFO - 2024-03-08 20:38:19 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:38:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:38:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-08 20:38:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:38:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:38:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:38:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:38:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-08 20:38:19 --> Final output sent to browser
DEBUG - 2024-03-08 20:38:19 --> Total execution time: 0.0340
ERROR - 2024-03-08 20:38:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:38:19 --> Config Class Initialized
INFO - 2024-03-08 20:38:19 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:38:19 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:38:19 --> Utf8 Class Initialized
INFO - 2024-03-08 20:38:19 --> URI Class Initialized
INFO - 2024-03-08 20:38:19 --> Router Class Initialized
INFO - 2024-03-08 20:38:19 --> Output Class Initialized
INFO - 2024-03-08 20:38:19 --> Security Class Initialized
DEBUG - 2024-03-08 20:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:38:19 --> Input Class Initialized
INFO - 2024-03-08 20:38:19 --> Language Class Initialized
INFO - 2024-03-08 20:38:19 --> Loader Class Initialized
INFO - 2024-03-08 20:38:19 --> Helper loaded: url_helper
INFO - 2024-03-08 20:38:19 --> Helper loaded: file_helper
INFO - 2024-03-08 20:38:19 --> Helper loaded: form_helper
INFO - 2024-03-08 20:38:19 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:38:19 --> Controller Class Initialized
INFO - 2024-03-08 20:38:19 --> Form Validation Class Initialized
INFO - 2024-03-08 20:38:19 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:38:19 --> Model "ReportModel" initialized
ERROR - 2024-03-08 20:38:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:38:22 --> Config Class Initialized
INFO - 2024-03-08 20:38:22 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:38:22 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:38:22 --> Utf8 Class Initialized
INFO - 2024-03-08 20:38:22 --> URI Class Initialized
INFO - 2024-03-08 20:38:22 --> Router Class Initialized
INFO - 2024-03-08 20:38:23 --> Output Class Initialized
INFO - 2024-03-08 20:38:23 --> Security Class Initialized
DEBUG - 2024-03-08 20:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:38:23 --> Input Class Initialized
INFO - 2024-03-08 20:38:23 --> Language Class Initialized
INFO - 2024-03-08 20:38:23 --> Loader Class Initialized
INFO - 2024-03-08 20:38:23 --> Helper loaded: url_helper
INFO - 2024-03-08 20:38:23 --> Helper loaded: file_helper
INFO - 2024-03-08 20:38:23 --> Helper loaded: form_helper
INFO - 2024-03-08 20:38:23 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:38:23 --> Controller Class Initialized
INFO - 2024-03-08 20:38:23 --> Form Validation Class Initialized
INFO - 2024-03-08 20:38:23 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:38:23 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:38:23 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:38:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:38:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:38:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:38:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:38:23 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:38:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:38:23 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:38:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:38:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:38:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:38:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:38:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:38:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:38:23 --> Final output sent to browser
DEBUG - 2024-03-08 20:38:23 --> Total execution time: 0.0440
ERROR - 2024-03-08 20:38:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:38:50 --> Config Class Initialized
INFO - 2024-03-08 20:38:50 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:38:50 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:38:50 --> Utf8 Class Initialized
INFO - 2024-03-08 20:38:50 --> URI Class Initialized
INFO - 2024-03-08 20:38:50 --> Router Class Initialized
INFO - 2024-03-08 20:38:50 --> Output Class Initialized
INFO - 2024-03-08 20:38:50 --> Security Class Initialized
DEBUG - 2024-03-08 20:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:38:50 --> Input Class Initialized
INFO - 2024-03-08 20:38:50 --> Language Class Initialized
INFO - 2024-03-08 20:38:50 --> Loader Class Initialized
INFO - 2024-03-08 20:38:50 --> Helper loaded: url_helper
INFO - 2024-03-08 20:38:50 --> Helper loaded: file_helper
INFO - 2024-03-08 20:38:50 --> Helper loaded: form_helper
INFO - 2024-03-08 20:38:50 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:38:50 --> Controller Class Initialized
INFO - 2024-03-08 20:38:50 --> Form Validation Class Initialized
INFO - 2024-03-08 20:38:50 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:38:50 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:38:50 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:38:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:38:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:38:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:38:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:38:50 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:38:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:38:50 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:38:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:38:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:38:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:38:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:38:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:38:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:38:50 --> Final output sent to browser
DEBUG - 2024-03-08 20:38:50 --> Total execution time: 0.0388
ERROR - 2024-03-08 20:42:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:42:32 --> Config Class Initialized
INFO - 2024-03-08 20:42:32 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:42:32 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:42:32 --> Utf8 Class Initialized
INFO - 2024-03-08 20:42:32 --> URI Class Initialized
INFO - 2024-03-08 20:42:32 --> Router Class Initialized
INFO - 2024-03-08 20:42:32 --> Output Class Initialized
INFO - 2024-03-08 20:42:32 --> Security Class Initialized
DEBUG - 2024-03-08 20:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:42:32 --> Input Class Initialized
INFO - 2024-03-08 20:42:32 --> Language Class Initialized
INFO - 2024-03-08 20:42:32 --> Loader Class Initialized
INFO - 2024-03-08 20:42:32 --> Helper loaded: url_helper
INFO - 2024-03-08 20:42:32 --> Helper loaded: file_helper
INFO - 2024-03-08 20:42:32 --> Helper loaded: form_helper
INFO - 2024-03-08 20:42:32 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:42:32 --> Controller Class Initialized
INFO - 2024-03-08 20:42:32 --> Form Validation Class Initialized
INFO - 2024-03-08 20:42:32 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:42:32 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:42:32 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:42:32 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:42:32 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:42:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:42:32 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:42:32 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:42:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:42:32 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:42:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:42:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:42:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:42:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:42:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:42:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:42:32 --> Final output sent to browser
DEBUG - 2024-03-08 20:42:32 --> Total execution time: 0.0351
ERROR - 2024-03-08 20:42:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:42:37 --> Config Class Initialized
INFO - 2024-03-08 20:42:37 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:42:37 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:42:37 --> Utf8 Class Initialized
INFO - 2024-03-08 20:42:37 --> URI Class Initialized
INFO - 2024-03-08 20:42:37 --> Router Class Initialized
INFO - 2024-03-08 20:42:37 --> Output Class Initialized
INFO - 2024-03-08 20:42:37 --> Security Class Initialized
DEBUG - 2024-03-08 20:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:42:37 --> Input Class Initialized
INFO - 2024-03-08 20:42:37 --> Language Class Initialized
INFO - 2024-03-08 20:42:37 --> Loader Class Initialized
INFO - 2024-03-08 20:42:37 --> Helper loaded: url_helper
INFO - 2024-03-08 20:42:37 --> Helper loaded: file_helper
INFO - 2024-03-08 20:42:37 --> Helper loaded: form_helper
INFO - 2024-03-08 20:42:37 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:42:37 --> Controller Class Initialized
INFO - 2024-03-08 20:42:37 --> Form Validation Class Initialized
INFO - 2024-03-08 20:42:37 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:42:37 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:42:37 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:42:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:42:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:42:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:42:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:42:37 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:42:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:42:37 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:42:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:42:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:42:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:42:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:42:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:42:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:42:37 --> Final output sent to browser
DEBUG - 2024-03-08 20:42:37 --> Total execution time: 0.0380
ERROR - 2024-03-08 20:42:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:42:59 --> Config Class Initialized
INFO - 2024-03-08 20:42:59 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:42:59 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:42:59 --> Utf8 Class Initialized
INFO - 2024-03-08 20:42:59 --> URI Class Initialized
INFO - 2024-03-08 20:42:59 --> Router Class Initialized
INFO - 2024-03-08 20:42:59 --> Output Class Initialized
INFO - 2024-03-08 20:42:59 --> Security Class Initialized
DEBUG - 2024-03-08 20:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:42:59 --> Input Class Initialized
INFO - 2024-03-08 20:42:59 --> Language Class Initialized
INFO - 2024-03-08 20:42:59 --> Loader Class Initialized
INFO - 2024-03-08 20:42:59 --> Helper loaded: url_helper
INFO - 2024-03-08 20:42:59 --> Helper loaded: file_helper
INFO - 2024-03-08 20:42:59 --> Helper loaded: form_helper
INFO - 2024-03-08 20:42:59 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:42:59 --> Controller Class Initialized
INFO - 2024-03-08 20:42:59 --> Form Validation Class Initialized
INFO - 2024-03-08 20:42:59 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:42:59 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:42:59 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:42:59 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:42:59 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:42:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:42:59 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:42:59 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:42:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:42:59 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:42:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:42:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:42:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:42:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:42:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:42:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:42:59 --> Final output sent to browser
DEBUG - 2024-03-08 20:42:59 --> Total execution time: 0.0311
ERROR - 2024-03-08 20:43:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:43:15 --> Config Class Initialized
INFO - 2024-03-08 20:43:15 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:43:15 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:43:15 --> Utf8 Class Initialized
INFO - 2024-03-08 20:43:15 --> URI Class Initialized
INFO - 2024-03-08 20:43:15 --> Router Class Initialized
INFO - 2024-03-08 20:43:15 --> Output Class Initialized
INFO - 2024-03-08 20:43:15 --> Security Class Initialized
DEBUG - 2024-03-08 20:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:43:15 --> Input Class Initialized
INFO - 2024-03-08 20:43:15 --> Language Class Initialized
INFO - 2024-03-08 20:43:15 --> Loader Class Initialized
INFO - 2024-03-08 20:43:15 --> Helper loaded: url_helper
INFO - 2024-03-08 20:43:15 --> Helper loaded: file_helper
INFO - 2024-03-08 20:43:15 --> Helper loaded: form_helper
INFO - 2024-03-08 20:43:15 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:43:15 --> Controller Class Initialized
INFO - 2024-03-08 20:43:15 --> Form Validation Class Initialized
INFO - 2024-03-08 20:43:15 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:43:15 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:43:15 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:43:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:43:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:43:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:43:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:43:15 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:43:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:43:15 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:43:15 --> Upload Class Initialized
ERROR - 2024-03-08 20:43:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:43:18 --> Config Class Initialized
INFO - 2024-03-08 20:43:18 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:43:18 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:43:18 --> Utf8 Class Initialized
INFO - 2024-03-08 20:43:18 --> URI Class Initialized
INFO - 2024-03-08 20:43:18 --> Router Class Initialized
INFO - 2024-03-08 20:43:18 --> Output Class Initialized
INFO - 2024-03-08 20:43:18 --> Security Class Initialized
DEBUG - 2024-03-08 20:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:43:18 --> Input Class Initialized
INFO - 2024-03-08 20:43:18 --> Language Class Initialized
INFO - 2024-03-08 20:43:18 --> Loader Class Initialized
INFO - 2024-03-08 20:43:18 --> Helper loaded: url_helper
INFO - 2024-03-08 20:43:18 --> Helper loaded: file_helper
INFO - 2024-03-08 20:43:18 --> Helper loaded: form_helper
INFO - 2024-03-08 20:43:18 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:43:18 --> Controller Class Initialized
INFO - 2024-03-08 20:43:18 --> Form Validation Class Initialized
INFO - 2024-03-08 20:43:18 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:43:18 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:43:18 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:43:18 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:43:18 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:43:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:43:18 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:43:18 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:43:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:43:18 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:43:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:43:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:43:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:43:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:43:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:43:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:43:18 --> Final output sent to browser
DEBUG - 2024-03-08 20:43:18 --> Total execution time: 0.0506
ERROR - 2024-03-08 20:44:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:44:43 --> Config Class Initialized
INFO - 2024-03-08 20:44:43 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:44:43 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:44:43 --> Utf8 Class Initialized
INFO - 2024-03-08 20:44:43 --> URI Class Initialized
INFO - 2024-03-08 20:44:43 --> Router Class Initialized
INFO - 2024-03-08 20:44:43 --> Output Class Initialized
INFO - 2024-03-08 20:44:43 --> Security Class Initialized
DEBUG - 2024-03-08 20:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:44:43 --> Input Class Initialized
INFO - 2024-03-08 20:44:43 --> Language Class Initialized
INFO - 2024-03-08 20:44:43 --> Loader Class Initialized
INFO - 2024-03-08 20:44:43 --> Helper loaded: url_helper
INFO - 2024-03-08 20:44:43 --> Helper loaded: file_helper
INFO - 2024-03-08 20:44:43 --> Helper loaded: form_helper
INFO - 2024-03-08 20:44:43 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:44:43 --> Controller Class Initialized
INFO - 2024-03-08 20:44:43 --> Form Validation Class Initialized
INFO - 2024-03-08 20:44:43 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:44:43 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:44:43 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:44:43 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:44:43 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:44:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:44:43 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:44:43 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:44:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:44:43 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:44:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:44:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:44:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:44:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:44:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:44:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:44:43 --> Final output sent to browser
DEBUG - 2024-03-08 20:44:43 --> Total execution time: 0.0384
ERROR - 2024-03-08 20:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:45:28 --> Config Class Initialized
INFO - 2024-03-08 20:45:28 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:45:28 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:45:28 --> Utf8 Class Initialized
INFO - 2024-03-08 20:45:28 --> URI Class Initialized
INFO - 2024-03-08 20:45:28 --> Router Class Initialized
INFO - 2024-03-08 20:45:28 --> Output Class Initialized
INFO - 2024-03-08 20:45:28 --> Security Class Initialized
DEBUG - 2024-03-08 20:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:45:28 --> Input Class Initialized
INFO - 2024-03-08 20:45:28 --> Language Class Initialized
INFO - 2024-03-08 20:45:28 --> Loader Class Initialized
INFO - 2024-03-08 20:45:28 --> Helper loaded: url_helper
INFO - 2024-03-08 20:45:28 --> Helper loaded: file_helper
INFO - 2024-03-08 20:45:28 --> Helper loaded: form_helper
INFO - 2024-03-08 20:45:28 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:45:28 --> Controller Class Initialized
INFO - 2024-03-08 20:45:28 --> Form Validation Class Initialized
INFO - 2024-03-08 20:45:28 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:45:28 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:45:28 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:45:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:45:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:45:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:45:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:45:28 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:45:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:45:28 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:45:28 --> Upload Class Initialized
ERROR - 2024-03-08 20:45:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:45:33 --> Config Class Initialized
INFO - 2024-03-08 20:45:33 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:45:33 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:45:33 --> Utf8 Class Initialized
INFO - 2024-03-08 20:45:33 --> URI Class Initialized
INFO - 2024-03-08 20:45:33 --> Router Class Initialized
INFO - 2024-03-08 20:45:33 --> Output Class Initialized
INFO - 2024-03-08 20:45:33 --> Security Class Initialized
DEBUG - 2024-03-08 20:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:45:33 --> Input Class Initialized
INFO - 2024-03-08 20:45:33 --> Language Class Initialized
INFO - 2024-03-08 20:45:33 --> Loader Class Initialized
INFO - 2024-03-08 20:45:33 --> Helper loaded: url_helper
INFO - 2024-03-08 20:45:33 --> Helper loaded: file_helper
INFO - 2024-03-08 20:45:33 --> Helper loaded: form_helper
INFO - 2024-03-08 20:45:33 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:45:33 --> Controller Class Initialized
INFO - 2024-03-08 20:45:33 --> Form Validation Class Initialized
INFO - 2024-03-08 20:45:33 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:45:33 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:45:33 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:45:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:45:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:45:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:45:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:45:33 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:45:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:45:33 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:45:33 --> Final output sent to browser
DEBUG - 2024-03-08 20:45:33 --> Total execution time: 0.0333
ERROR - 2024-03-08 20:45:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:45:40 --> Config Class Initialized
INFO - 2024-03-08 20:45:40 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:45:40 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:45:40 --> Utf8 Class Initialized
INFO - 2024-03-08 20:45:40 --> URI Class Initialized
INFO - 2024-03-08 20:45:40 --> Router Class Initialized
INFO - 2024-03-08 20:45:40 --> Output Class Initialized
INFO - 2024-03-08 20:45:40 --> Security Class Initialized
DEBUG - 2024-03-08 20:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:45:40 --> Input Class Initialized
INFO - 2024-03-08 20:45:40 --> Language Class Initialized
INFO - 2024-03-08 20:45:40 --> Loader Class Initialized
INFO - 2024-03-08 20:45:40 --> Helper loaded: url_helper
INFO - 2024-03-08 20:45:40 --> Helper loaded: file_helper
INFO - 2024-03-08 20:45:40 --> Helper loaded: form_helper
INFO - 2024-03-08 20:45:40 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:45:40 --> Controller Class Initialized
INFO - 2024-03-08 20:45:40 --> Form Validation Class Initialized
INFO - 2024-03-08 20:45:40 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:45:40 --> Upload Class Initialized
ERROR - 2024-03-08 20:45:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:45:40 --> Config Class Initialized
INFO - 2024-03-08 20:45:40 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:45:40 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:45:40 --> Utf8 Class Initialized
INFO - 2024-03-08 20:45:40 --> URI Class Initialized
INFO - 2024-03-08 20:45:40 --> Router Class Initialized
INFO - 2024-03-08 20:45:40 --> Output Class Initialized
INFO - 2024-03-08 20:45:40 --> Security Class Initialized
DEBUG - 2024-03-08 20:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:45:40 --> Input Class Initialized
INFO - 2024-03-08 20:45:40 --> Language Class Initialized
INFO - 2024-03-08 20:45:40 --> Loader Class Initialized
INFO - 2024-03-08 20:45:40 --> Helper loaded: url_helper
INFO - 2024-03-08 20:45:40 --> Helper loaded: file_helper
INFO - 2024-03-08 20:45:40 --> Helper loaded: form_helper
INFO - 2024-03-08 20:45:40 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:45:40 --> Controller Class Initialized
INFO - 2024-03-08 20:45:40 --> Form Validation Class Initialized
INFO - 2024-03-08 20:45:40 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:45:40 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:45:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:45:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:45:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:45:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:45:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:45:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:45:40 --> Final output sent to browser
DEBUG - 2024-03-08 20:45:40 --> Total execution time: 0.0204
ERROR - 2024-03-08 20:45:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:45:44 --> Config Class Initialized
INFO - 2024-03-08 20:45:44 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:45:44 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:45:44 --> Utf8 Class Initialized
INFO - 2024-03-08 20:45:44 --> URI Class Initialized
INFO - 2024-03-08 20:45:44 --> Router Class Initialized
INFO - 2024-03-08 20:45:44 --> Output Class Initialized
INFO - 2024-03-08 20:45:44 --> Security Class Initialized
DEBUG - 2024-03-08 20:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:45:44 --> Input Class Initialized
INFO - 2024-03-08 20:45:44 --> Language Class Initialized
INFO - 2024-03-08 20:45:44 --> Loader Class Initialized
INFO - 2024-03-08 20:45:44 --> Helper loaded: url_helper
INFO - 2024-03-08 20:45:44 --> Helper loaded: file_helper
INFO - 2024-03-08 20:45:44 --> Helper loaded: form_helper
INFO - 2024-03-08 20:45:44 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:45:44 --> Controller Class Initialized
INFO - 2024-03-08 20:45:44 --> Form Validation Class Initialized
INFO - 2024-03-08 20:45:44 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:45:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:45:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-08 20:45:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:45:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:45:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:45:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:45:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-08 20:45:44 --> Final output sent to browser
DEBUG - 2024-03-08 20:45:44 --> Total execution time: 0.0368
ERROR - 2024-03-08 20:45:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:45:44 --> Config Class Initialized
INFO - 2024-03-08 20:45:44 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:45:44 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:45:44 --> Utf8 Class Initialized
INFO - 2024-03-08 20:45:44 --> URI Class Initialized
INFO - 2024-03-08 20:45:44 --> Router Class Initialized
INFO - 2024-03-08 20:45:44 --> Output Class Initialized
INFO - 2024-03-08 20:45:44 --> Security Class Initialized
DEBUG - 2024-03-08 20:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:45:44 --> Input Class Initialized
INFO - 2024-03-08 20:45:44 --> Language Class Initialized
INFO - 2024-03-08 20:45:44 --> Loader Class Initialized
INFO - 2024-03-08 20:45:44 --> Helper loaded: url_helper
INFO - 2024-03-08 20:45:44 --> Helper loaded: file_helper
INFO - 2024-03-08 20:45:44 --> Helper loaded: form_helper
INFO - 2024-03-08 20:45:44 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:45:44 --> Controller Class Initialized
INFO - 2024-03-08 20:45:44 --> Form Validation Class Initialized
INFO - 2024-03-08 20:45:44 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:45:44 --> Model "ReportModel" initialized
ERROR - 2024-03-08 20:45:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:45:46 --> Config Class Initialized
INFO - 2024-03-08 20:45:46 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:45:46 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:45:46 --> Utf8 Class Initialized
INFO - 2024-03-08 20:45:46 --> URI Class Initialized
INFO - 2024-03-08 20:45:46 --> Router Class Initialized
INFO - 2024-03-08 20:45:46 --> Output Class Initialized
INFO - 2024-03-08 20:45:46 --> Security Class Initialized
DEBUG - 2024-03-08 20:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:45:46 --> Input Class Initialized
INFO - 2024-03-08 20:45:46 --> Language Class Initialized
INFO - 2024-03-08 20:45:46 --> Loader Class Initialized
INFO - 2024-03-08 20:45:46 --> Helper loaded: url_helper
INFO - 2024-03-08 20:45:46 --> Helper loaded: file_helper
INFO - 2024-03-08 20:45:46 --> Helper loaded: form_helper
INFO - 2024-03-08 20:45:46 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:45:46 --> Controller Class Initialized
INFO - 2024-03-08 20:45:46 --> Form Validation Class Initialized
INFO - 2024-03-08 20:45:46 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:45:46 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:45:46 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:45:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:45:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:45:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:45:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:45:46 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:45:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:45:46 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:45:46 --> Final output sent to browser
DEBUG - 2024-03-08 20:45:46 --> Total execution time: 0.0358
ERROR - 2024-03-08 20:45:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:45:50 --> Config Class Initialized
INFO - 2024-03-08 20:45:50 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:45:50 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:45:50 --> Utf8 Class Initialized
INFO - 2024-03-08 20:45:50 --> URI Class Initialized
INFO - 2024-03-08 20:45:50 --> Router Class Initialized
INFO - 2024-03-08 20:45:50 --> Output Class Initialized
INFO - 2024-03-08 20:45:50 --> Security Class Initialized
DEBUG - 2024-03-08 20:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:45:50 --> Input Class Initialized
INFO - 2024-03-08 20:45:50 --> Language Class Initialized
INFO - 2024-03-08 20:45:50 --> Loader Class Initialized
INFO - 2024-03-08 20:45:50 --> Helper loaded: url_helper
INFO - 2024-03-08 20:45:50 --> Helper loaded: file_helper
INFO - 2024-03-08 20:45:50 --> Helper loaded: form_helper
INFO - 2024-03-08 20:45:50 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:45:50 --> Controller Class Initialized
INFO - 2024-03-08 20:45:50 --> Form Validation Class Initialized
INFO - 2024-03-08 20:45:50 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:45:50 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:45:50 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:45:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:45:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:45:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:45:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:45:50 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:45:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:45:50 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:45:50 --> Final output sent to browser
DEBUG - 2024-03-08 20:45:50 --> Total execution time: 0.0441
ERROR - 2024-03-08 20:46:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:46:15 --> Config Class Initialized
INFO - 2024-03-08 20:46:15 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:46:15 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:46:15 --> Utf8 Class Initialized
INFO - 2024-03-08 20:46:15 --> URI Class Initialized
INFO - 2024-03-08 20:46:15 --> Router Class Initialized
INFO - 2024-03-08 20:46:15 --> Output Class Initialized
INFO - 2024-03-08 20:46:15 --> Security Class Initialized
DEBUG - 2024-03-08 20:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:46:15 --> Input Class Initialized
INFO - 2024-03-08 20:46:15 --> Language Class Initialized
INFO - 2024-03-08 20:46:15 --> Loader Class Initialized
INFO - 2024-03-08 20:46:15 --> Helper loaded: url_helper
INFO - 2024-03-08 20:46:15 --> Helper loaded: file_helper
INFO - 2024-03-08 20:46:15 --> Helper loaded: form_helper
INFO - 2024-03-08 20:46:15 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:46:15 --> Controller Class Initialized
INFO - 2024-03-08 20:46:15 --> Form Validation Class Initialized
INFO - 2024-03-08 20:46:15 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:46:15 --> Upload Class Initialized
ERROR - 2024-03-08 20:46:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:46:15 --> Config Class Initialized
INFO - 2024-03-08 20:46:15 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:46:15 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:46:15 --> Utf8 Class Initialized
INFO - 2024-03-08 20:46:15 --> URI Class Initialized
INFO - 2024-03-08 20:46:15 --> Router Class Initialized
INFO - 2024-03-08 20:46:15 --> Output Class Initialized
INFO - 2024-03-08 20:46:15 --> Security Class Initialized
DEBUG - 2024-03-08 20:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:46:15 --> Input Class Initialized
INFO - 2024-03-08 20:46:15 --> Language Class Initialized
INFO - 2024-03-08 20:46:15 --> Loader Class Initialized
INFO - 2024-03-08 20:46:15 --> Helper loaded: url_helper
INFO - 2024-03-08 20:46:15 --> Helper loaded: file_helper
INFO - 2024-03-08 20:46:15 --> Helper loaded: form_helper
INFO - 2024-03-08 20:46:15 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:46:15 --> Controller Class Initialized
INFO - 2024-03-08 20:46:15 --> Form Validation Class Initialized
INFO - 2024-03-08 20:46:15 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:46:15 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:46:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:46:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:46:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:46:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:46:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:46:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:46:15 --> Final output sent to browser
DEBUG - 2024-03-08 20:46:15 --> Total execution time: 0.0363
ERROR - 2024-03-08 20:46:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:46:24 --> Config Class Initialized
INFO - 2024-03-08 20:46:24 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:46:24 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:46:24 --> Utf8 Class Initialized
INFO - 2024-03-08 20:46:24 --> URI Class Initialized
INFO - 2024-03-08 20:46:24 --> Router Class Initialized
INFO - 2024-03-08 20:46:24 --> Output Class Initialized
INFO - 2024-03-08 20:46:24 --> Security Class Initialized
DEBUG - 2024-03-08 20:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:46:24 --> Input Class Initialized
INFO - 2024-03-08 20:46:24 --> Language Class Initialized
INFO - 2024-03-08 20:46:24 --> Loader Class Initialized
INFO - 2024-03-08 20:46:24 --> Helper loaded: url_helper
INFO - 2024-03-08 20:46:24 --> Helper loaded: file_helper
INFO - 2024-03-08 20:46:24 --> Helper loaded: form_helper
INFO - 2024-03-08 20:46:24 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:46:24 --> Controller Class Initialized
INFO - 2024-03-08 20:46:24 --> Form Validation Class Initialized
INFO - 2024-03-08 20:46:24 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:46:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:46:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-08 20:46:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:46:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:46:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:46:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:46:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-08 20:46:24 --> Final output sent to browser
DEBUG - 2024-03-08 20:46:24 --> Total execution time: 0.0459
ERROR - 2024-03-08 20:46:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:46:24 --> Config Class Initialized
INFO - 2024-03-08 20:46:24 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:46:24 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:46:24 --> Utf8 Class Initialized
INFO - 2024-03-08 20:46:24 --> URI Class Initialized
INFO - 2024-03-08 20:46:24 --> Router Class Initialized
INFO - 2024-03-08 20:46:24 --> Output Class Initialized
INFO - 2024-03-08 20:46:24 --> Security Class Initialized
DEBUG - 2024-03-08 20:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:46:24 --> Input Class Initialized
INFO - 2024-03-08 20:46:24 --> Language Class Initialized
INFO - 2024-03-08 20:46:24 --> Loader Class Initialized
INFO - 2024-03-08 20:46:24 --> Helper loaded: url_helper
INFO - 2024-03-08 20:46:24 --> Helper loaded: file_helper
INFO - 2024-03-08 20:46:24 --> Helper loaded: form_helper
INFO - 2024-03-08 20:46:24 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:46:24 --> Controller Class Initialized
INFO - 2024-03-08 20:46:24 --> Form Validation Class Initialized
INFO - 2024-03-08 20:46:24 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:46:24 --> Model "ReportModel" initialized
ERROR - 2024-03-08 20:46:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:46:26 --> Config Class Initialized
INFO - 2024-03-08 20:46:26 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:46:26 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:46:26 --> Utf8 Class Initialized
INFO - 2024-03-08 20:46:26 --> URI Class Initialized
INFO - 2024-03-08 20:46:26 --> Router Class Initialized
INFO - 2024-03-08 20:46:26 --> Output Class Initialized
INFO - 2024-03-08 20:46:26 --> Security Class Initialized
DEBUG - 2024-03-08 20:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:46:26 --> Input Class Initialized
INFO - 2024-03-08 20:46:26 --> Language Class Initialized
INFO - 2024-03-08 20:46:26 --> Loader Class Initialized
INFO - 2024-03-08 20:46:26 --> Helper loaded: url_helper
INFO - 2024-03-08 20:46:26 --> Helper loaded: file_helper
INFO - 2024-03-08 20:46:26 --> Helper loaded: form_helper
INFO - 2024-03-08 20:46:26 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:46:26 --> Controller Class Initialized
INFO - 2024-03-08 20:46:26 --> Form Validation Class Initialized
INFO - 2024-03-08 20:46:26 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:46:26 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:46:26 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:46:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:46:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:46:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:46:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:46:26 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:46:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:46:26 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:46:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:46:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:46:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:46:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:46:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:46:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-08 20:46:26 --> Final output sent to browser
DEBUG - 2024-03-08 20:46:26 --> Total execution time: 0.0395
ERROR - 2024-03-08 20:46:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:46:30 --> Config Class Initialized
INFO - 2024-03-08 20:46:30 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:46:30 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:46:30 --> Utf8 Class Initialized
INFO - 2024-03-08 20:46:30 --> URI Class Initialized
INFO - 2024-03-08 20:46:30 --> Router Class Initialized
INFO - 2024-03-08 20:46:30 --> Output Class Initialized
INFO - 2024-03-08 20:46:30 --> Security Class Initialized
DEBUG - 2024-03-08 20:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:46:30 --> Input Class Initialized
INFO - 2024-03-08 20:46:30 --> Language Class Initialized
INFO - 2024-03-08 20:46:30 --> Loader Class Initialized
INFO - 2024-03-08 20:46:30 --> Helper loaded: url_helper
INFO - 2024-03-08 20:46:30 --> Helper loaded: file_helper
INFO - 2024-03-08 20:46:30 --> Helper loaded: form_helper
INFO - 2024-03-08 20:46:30 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:46:30 --> Controller Class Initialized
INFO - 2024-03-08 20:46:30 --> Form Validation Class Initialized
INFO - 2024-03-08 20:46:30 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-08 20:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-08 20:46:30 --> Final output sent to browser
DEBUG - 2024-03-08 20:46:30 --> Total execution time: 0.0369
ERROR - 2024-03-08 20:46:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:46:30 --> Config Class Initialized
INFO - 2024-03-08 20:46:30 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:46:30 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:46:30 --> Utf8 Class Initialized
INFO - 2024-03-08 20:46:30 --> URI Class Initialized
INFO - 2024-03-08 20:46:30 --> Router Class Initialized
INFO - 2024-03-08 20:46:30 --> Output Class Initialized
INFO - 2024-03-08 20:46:30 --> Security Class Initialized
DEBUG - 2024-03-08 20:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:46:30 --> Input Class Initialized
INFO - 2024-03-08 20:46:30 --> Language Class Initialized
INFO - 2024-03-08 20:46:30 --> Loader Class Initialized
INFO - 2024-03-08 20:46:30 --> Helper loaded: url_helper
INFO - 2024-03-08 20:46:30 --> Helper loaded: file_helper
INFO - 2024-03-08 20:46:30 --> Helper loaded: form_helper
INFO - 2024-03-08 20:46:30 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:46:30 --> Controller Class Initialized
INFO - 2024-03-08 20:46:30 --> Form Validation Class Initialized
INFO - 2024-03-08 20:46:30 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:46:30 --> Model "ReportModel" initialized
ERROR - 2024-03-08 20:46:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:46:35 --> Config Class Initialized
INFO - 2024-03-08 20:46:35 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:46:35 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:46:35 --> Utf8 Class Initialized
INFO - 2024-03-08 20:46:35 --> URI Class Initialized
INFO - 2024-03-08 20:46:35 --> Router Class Initialized
INFO - 2024-03-08 20:46:35 --> Output Class Initialized
INFO - 2024-03-08 20:46:35 --> Security Class Initialized
DEBUG - 2024-03-08 20:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:46:35 --> Input Class Initialized
INFO - 2024-03-08 20:46:35 --> Language Class Initialized
INFO - 2024-03-08 20:46:35 --> Loader Class Initialized
INFO - 2024-03-08 20:46:35 --> Helper loaded: url_helper
INFO - 2024-03-08 20:46:35 --> Helper loaded: file_helper
INFO - 2024-03-08 20:46:35 --> Helper loaded: form_helper
INFO - 2024-03-08 20:46:35 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:46:35 --> Controller Class Initialized
INFO - 2024-03-08 20:46:35 --> Form Validation Class Initialized
INFO - 2024-03-08 20:46:35 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:46:35 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:46:35 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:46:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:46:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:46:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:46:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:46:35 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:46:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:46:35 --> Model "ReportModel" initialized
INFO - 2024-03-08 20:46:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-08 20:46:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-08 20:46:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-08 20:46:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-08 20:46:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-08 20:46:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-08 20:46:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-08 20:46:35 --> Final output sent to browser
DEBUG - 2024-03-08 20:46:35 --> Total execution time: 0.0345
ERROR - 2024-03-08 20:46:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-08 20:46:36 --> Config Class Initialized
INFO - 2024-03-08 20:46:36 --> Hooks Class Initialized
DEBUG - 2024-03-08 20:46:36 --> UTF-8 Support Enabled
INFO - 2024-03-08 20:46:36 --> Utf8 Class Initialized
INFO - 2024-03-08 20:46:36 --> URI Class Initialized
INFO - 2024-03-08 20:46:36 --> Router Class Initialized
INFO - 2024-03-08 20:46:36 --> Output Class Initialized
INFO - 2024-03-08 20:46:36 --> Security Class Initialized
DEBUG - 2024-03-08 20:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 20:46:36 --> Input Class Initialized
INFO - 2024-03-08 20:46:36 --> Language Class Initialized
INFO - 2024-03-08 20:46:36 --> Loader Class Initialized
INFO - 2024-03-08 20:46:36 --> Helper loaded: url_helper
INFO - 2024-03-08 20:46:36 --> Helper loaded: file_helper
INFO - 2024-03-08 20:46:36 --> Helper loaded: form_helper
INFO - 2024-03-08 20:46:36 --> Database Driver Class Initialized
DEBUG - 2024-03-08 20:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-08 20:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 20:46:36 --> Controller Class Initialized
INFO - 2024-03-08 20:46:36 --> Form Validation Class Initialized
INFO - 2024-03-08 20:46:36 --> Model "MasterModel" initialized
INFO - 2024-03-08 20:46:36 --> Model "NotificationModel" initialized
INFO - 2024-03-08 20:46:36 --> Model "DashboardModel" initialized
INFO - 2024-03-08 20:46:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-08 20:46:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-08 20:46:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-08 20:46:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-08 20:46:36 --> Model "OrderModel" initialized
INFO - 2024-03-08 20:46:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-08 20:46:36 --> Model "ReportModel" initialized
