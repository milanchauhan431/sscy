<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-10 11:44:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 11:44:04 --> Config Class Initialized
INFO - 2024-03-10 11:44:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 11:44:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 11:44:04 --> Utf8 Class Initialized
INFO - 2024-03-10 11:44:04 --> URI Class Initialized
INFO - 2024-03-10 11:44:04 --> Router Class Initialized
INFO - 2024-03-10 11:44:04 --> Output Class Initialized
INFO - 2024-03-10 11:44:04 --> Security Class Initialized
DEBUG - 2024-03-10 11:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 11:44:04 --> Input Class Initialized
INFO - 2024-03-10 11:44:04 --> Language Class Initialized
INFO - 2024-03-10 11:44:04 --> Loader Class Initialized
INFO - 2024-03-10 11:44:04 --> Helper loaded: url_helper
INFO - 2024-03-10 11:44:04 --> Helper loaded: file_helper
INFO - 2024-03-10 11:44:04 --> Helper loaded: form_helper
INFO - 2024-03-10 11:44:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 11:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 11:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 11:44:04 --> Controller Class Initialized
INFO - 2024-03-10 11:44:04 --> Form Validation Class Initialized
INFO - 2024-03-10 11:44:04 --> Model "MasterModel" initialized
INFO - 2024-03-10 11:44:04 --> Model "NotificationModel" initialized
INFO - 2024-03-10 11:44:04 --> Model "DashboardModel" initialized
INFO - 2024-03-10 11:44:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 11:44:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 11:44:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 11:44:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 11:44:04 --> Model "OrderModel" initialized
INFO - 2024-03-10 11:44:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 11:44:04 --> Model "ReportModel" initialized
INFO - 2024-03-10 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 11:44:04 --> Final output sent to browser
DEBUG - 2024-03-10 11:44:04 --> Total execution time: 0.0574
ERROR - 2024-03-10 11:44:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 11:44:04 --> Config Class Initialized
INFO - 2024-03-10 11:44:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 11:44:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 11:44:04 --> Utf8 Class Initialized
INFO - 2024-03-10 11:44:04 --> URI Class Initialized
INFO - 2024-03-10 11:44:04 --> Router Class Initialized
INFO - 2024-03-10 11:44:04 --> Output Class Initialized
INFO - 2024-03-10 11:44:04 --> Security Class Initialized
DEBUG - 2024-03-10 11:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 11:44:04 --> Input Class Initialized
INFO - 2024-03-10 11:44:04 --> Language Class Initialized
INFO - 2024-03-10 11:44:04 --> Loader Class Initialized
INFO - 2024-03-10 11:44:04 --> Helper loaded: url_helper
INFO - 2024-03-10 11:44:04 --> Helper loaded: file_helper
INFO - 2024-03-10 11:44:04 --> Helper loaded: form_helper
INFO - 2024-03-10 11:44:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 11:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 11:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 11:44:04 --> Controller Class Initialized
INFO - 2024-03-10 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-03-10 11:44:04 --> Final output sent to browser
DEBUG - 2024-03-10 11:44:04 --> Total execution time: 0.0301
ERROR - 2024-03-10 11:44:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 11:44:05 --> Config Class Initialized
INFO - 2024-03-10 11:44:05 --> Hooks Class Initialized
DEBUG - 2024-03-10 11:44:05 --> UTF-8 Support Enabled
INFO - 2024-03-10 11:44:05 --> Utf8 Class Initialized
INFO - 2024-03-10 11:44:05 --> URI Class Initialized
INFO - 2024-03-10 11:44:05 --> Router Class Initialized
INFO - 2024-03-10 11:44:05 --> Output Class Initialized
INFO - 2024-03-10 11:44:05 --> Security Class Initialized
DEBUG - 2024-03-10 11:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 11:44:05 --> Input Class Initialized
INFO - 2024-03-10 11:44:05 --> Language Class Initialized
INFO - 2024-03-10 11:44:05 --> Loader Class Initialized
INFO - 2024-03-10 11:44:05 --> Helper loaded: url_helper
INFO - 2024-03-10 11:44:06 --> Helper loaded: file_helper
INFO - 2024-03-10 11:44:06 --> Helper loaded: form_helper
INFO - 2024-03-10 11:44:06 --> Database Driver Class Initialized
DEBUG - 2024-03-10 11:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 11:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 11:44:06 --> Controller Class Initialized
INFO - 2024-03-10 11:44:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-03-10 11:44:06 --> Final output sent to browser
DEBUG - 2024-03-10 11:44:06 --> Total execution time: 0.0234
ERROR - 2024-03-10 11:44:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 11:44:06 --> Config Class Initialized
INFO - 2024-03-10 11:44:06 --> Hooks Class Initialized
DEBUG - 2024-03-10 11:44:06 --> UTF-8 Support Enabled
INFO - 2024-03-10 11:44:06 --> Utf8 Class Initialized
INFO - 2024-03-10 11:44:06 --> URI Class Initialized
DEBUG - 2024-03-10 11:44:06 --> No URI present. Default controller set.
INFO - 2024-03-10 11:44:06 --> Router Class Initialized
INFO - 2024-03-10 11:44:06 --> Output Class Initialized
INFO - 2024-03-10 11:44:06 --> Security Class Initialized
DEBUG - 2024-03-10 11:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 11:44:06 --> Input Class Initialized
INFO - 2024-03-10 11:44:06 --> Language Class Initialized
INFO - 2024-03-10 11:44:06 --> Loader Class Initialized
INFO - 2024-03-10 11:44:06 --> Helper loaded: url_helper
INFO - 2024-03-10 11:44:06 --> Helper loaded: file_helper
INFO - 2024-03-10 11:44:06 --> Helper loaded: form_helper
INFO - 2024-03-10 11:44:06 --> Database Driver Class Initialized
DEBUG - 2024-03-10 11:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 11:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 11:44:06 --> Controller Class Initialized
INFO - 2024-03-10 11:44:06 --> Model "LoginModel" initialized
INFO - 2024-03-10 11:44:06 --> Form Validation Class Initialized
INFO - 2024-03-10 11:44:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-10 11:44:06 --> Final output sent to browser
DEBUG - 2024-03-10 11:44:06 --> Total execution time: 0.0271
ERROR - 2024-03-10 11:44:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 11:44:08 --> Config Class Initialized
INFO - 2024-03-10 11:44:08 --> Hooks Class Initialized
DEBUG - 2024-03-10 11:44:08 --> UTF-8 Support Enabled
INFO - 2024-03-10 11:44:08 --> Utf8 Class Initialized
INFO - 2024-03-10 11:44:08 --> URI Class Initialized
INFO - 2024-03-10 11:44:08 --> Router Class Initialized
INFO - 2024-03-10 11:44:08 --> Output Class Initialized
INFO - 2024-03-10 11:44:08 --> Security Class Initialized
DEBUG - 2024-03-10 11:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 11:44:08 --> Input Class Initialized
INFO - 2024-03-10 11:44:08 --> Language Class Initialized
INFO - 2024-03-10 11:44:08 --> Loader Class Initialized
INFO - 2024-03-10 11:44:08 --> Helper loaded: url_helper
INFO - 2024-03-10 11:44:08 --> Helper loaded: file_helper
INFO - 2024-03-10 11:44:08 --> Helper loaded: form_helper
INFO - 2024-03-10 11:44:08 --> Database Driver Class Initialized
DEBUG - 2024-03-10 11:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 11:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 11:44:08 --> Controller Class Initialized
INFO - 2024-03-10 11:44:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 11:44:08 --> Final output sent to browser
DEBUG - 2024-03-10 11:44:08 --> Total execution time: 0.0236
ERROR - 2024-03-10 11:44:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 11:44:21 --> Config Class Initialized
INFO - 2024-03-10 11:44:21 --> Hooks Class Initialized
DEBUG - 2024-03-10 11:44:21 --> UTF-8 Support Enabled
INFO - 2024-03-10 11:44:21 --> Utf8 Class Initialized
INFO - 2024-03-10 11:44:21 --> URI Class Initialized
INFO - 2024-03-10 11:44:21 --> Router Class Initialized
INFO - 2024-03-10 11:44:21 --> Output Class Initialized
INFO - 2024-03-10 11:44:21 --> Security Class Initialized
DEBUG - 2024-03-10 11:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 11:44:21 --> Input Class Initialized
INFO - 2024-03-10 11:44:21 --> Language Class Initialized
INFO - 2024-03-10 11:44:21 --> Loader Class Initialized
INFO - 2024-03-10 11:44:21 --> Helper loaded: url_helper
INFO - 2024-03-10 11:44:21 --> Helper loaded: file_helper
INFO - 2024-03-10 11:44:21 --> Helper loaded: form_helper
INFO - 2024-03-10 11:44:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 11:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 11:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 11:44:21 --> Controller Class Initialized
INFO - 2024-03-10 11:44:21 --> Model "LoginModel" initialized
INFO - 2024-03-10 11:44:21 --> Form Validation Class Initialized
INFO - 2024-03-10 11:44:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-10 11:44:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 11:44:21 --> Config Class Initialized
INFO - 2024-03-10 11:44:21 --> Hooks Class Initialized
DEBUG - 2024-03-10 11:44:21 --> UTF-8 Support Enabled
INFO - 2024-03-10 11:44:21 --> Utf8 Class Initialized
INFO - 2024-03-10 11:44:21 --> URI Class Initialized
INFO - 2024-03-10 11:44:21 --> Router Class Initialized
INFO - 2024-03-10 11:44:21 --> Output Class Initialized
INFO - 2024-03-10 11:44:21 --> Security Class Initialized
DEBUG - 2024-03-10 11:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 11:44:21 --> Input Class Initialized
INFO - 2024-03-10 11:44:21 --> Language Class Initialized
INFO - 2024-03-10 11:44:21 --> Loader Class Initialized
INFO - 2024-03-10 11:44:21 --> Helper loaded: url_helper
INFO - 2024-03-10 11:44:21 --> Helper loaded: file_helper
INFO - 2024-03-10 11:44:21 --> Helper loaded: form_helper
INFO - 2024-03-10 11:44:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 11:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 11:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 11:44:21 --> Controller Class Initialized
INFO - 2024-03-10 11:44:21 --> Form Validation Class Initialized
INFO - 2024-03-10 11:44:21 --> Model "MasterModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "NotificationModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "DashboardModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "OrderModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "ReportModel" initialized
INFO - 2024-03-10 11:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 11:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 11:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 11:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 11:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 11:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 11:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 11:44:21 --> Final output sent to browser
DEBUG - 2024-03-10 11:44:21 --> Total execution time: 0.0282
ERROR - 2024-03-10 11:44:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 11:44:21 --> Config Class Initialized
INFO - 2024-03-10 11:44:21 --> Hooks Class Initialized
DEBUG - 2024-03-10 11:44:21 --> UTF-8 Support Enabled
INFO - 2024-03-10 11:44:21 --> Utf8 Class Initialized
INFO - 2024-03-10 11:44:21 --> URI Class Initialized
INFO - 2024-03-10 11:44:21 --> Router Class Initialized
INFO - 2024-03-10 11:44:21 --> Output Class Initialized
INFO - 2024-03-10 11:44:21 --> Security Class Initialized
DEBUG - 2024-03-10 11:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 11:44:21 --> Input Class Initialized
INFO - 2024-03-10 11:44:21 --> Language Class Initialized
INFO - 2024-03-10 11:44:21 --> Loader Class Initialized
INFO - 2024-03-10 11:44:21 --> Helper loaded: url_helper
INFO - 2024-03-10 11:44:21 --> Helper loaded: file_helper
INFO - 2024-03-10 11:44:21 --> Helper loaded: form_helper
INFO - 2024-03-10 11:44:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 11:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 11:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 11:44:21 --> Controller Class Initialized
INFO - 2024-03-10 11:44:21 --> Form Validation Class Initialized
INFO - 2024-03-10 11:44:21 --> Model "MasterModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "NotificationModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "DashboardModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "OrderModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 11:44:21 --> Model "ReportModel" initialized
ERROR - 2024-03-10 11:44:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 11:44:23 --> Config Class Initialized
INFO - 2024-03-10 11:44:23 --> Hooks Class Initialized
DEBUG - 2024-03-10 11:44:23 --> UTF-8 Support Enabled
INFO - 2024-03-10 11:44:23 --> Utf8 Class Initialized
INFO - 2024-03-10 11:44:23 --> URI Class Initialized
INFO - 2024-03-10 11:44:23 --> Router Class Initialized
INFO - 2024-03-10 11:44:23 --> Output Class Initialized
INFO - 2024-03-10 11:44:23 --> Security Class Initialized
DEBUG - 2024-03-10 11:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 11:44:23 --> Input Class Initialized
INFO - 2024-03-10 11:44:23 --> Language Class Initialized
INFO - 2024-03-10 11:44:23 --> Loader Class Initialized
INFO - 2024-03-10 11:44:23 --> Helper loaded: url_helper
INFO - 2024-03-10 11:44:23 --> Helper loaded: file_helper
INFO - 2024-03-10 11:44:23 --> Helper loaded: form_helper
INFO - 2024-03-10 11:44:23 --> Database Driver Class Initialized
DEBUG - 2024-03-10 11:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 11:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 11:44:23 --> Controller Class Initialized
INFO - 2024-03-10 11:44:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 11:44:23 --> Final output sent to browser
DEBUG - 2024-03-10 11:44:23 --> Total execution time: 0.0193
ERROR - 2024-03-10 11:44:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 11:44:25 --> Config Class Initialized
INFO - 2024-03-10 11:44:25 --> Hooks Class Initialized
DEBUG - 2024-03-10 11:44:25 --> UTF-8 Support Enabled
INFO - 2024-03-10 11:44:25 --> Utf8 Class Initialized
INFO - 2024-03-10 11:44:25 --> URI Class Initialized
INFO - 2024-03-10 11:44:25 --> Router Class Initialized
INFO - 2024-03-10 11:44:25 --> Output Class Initialized
INFO - 2024-03-10 11:44:25 --> Security Class Initialized
DEBUG - 2024-03-10 11:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 11:44:25 --> Input Class Initialized
INFO - 2024-03-10 11:44:25 --> Language Class Initialized
INFO - 2024-03-10 11:44:25 --> Loader Class Initialized
INFO - 2024-03-10 11:44:25 --> Helper loaded: url_helper
INFO - 2024-03-10 11:44:25 --> Helper loaded: file_helper
INFO - 2024-03-10 11:44:25 --> Helper loaded: form_helper
INFO - 2024-03-10 11:44:25 --> Database Driver Class Initialized
DEBUG - 2024-03-10 11:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 11:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 11:44:25 --> Controller Class Initialized
INFO - 2024-03-10 11:44:25 --> Form Validation Class Initialized
INFO - 2024-03-10 11:44:25 --> Model "MasterModel" initialized
INFO - 2024-03-10 11:44:25 --> Model "NotificationModel" initialized
INFO - 2024-03-10 11:44:25 --> Model "DashboardModel" initialized
INFO - 2024-03-10 11:44:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 11:44:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 11:44:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 11:44:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 11:44:25 --> Model "OrderModel" initialized
INFO - 2024-03-10 11:44:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 11:44:25 --> Model "ReportModel" initialized
INFO - 2024-03-10 11:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 11:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 11:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 11:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 11:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 11:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 11:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 11:44:25 --> Final output sent to browser
DEBUG - 2024-03-10 11:44:25 --> Total execution time: 0.0459
ERROR - 2024-03-10 11:44:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 11:44:53 --> Config Class Initialized
INFO - 2024-03-10 11:44:53 --> Hooks Class Initialized
DEBUG - 2024-03-10 11:44:53 --> UTF-8 Support Enabled
INFO - 2024-03-10 11:44:53 --> Utf8 Class Initialized
INFO - 2024-03-10 11:44:53 --> URI Class Initialized
INFO - 2024-03-10 11:44:53 --> Router Class Initialized
INFO - 2024-03-10 11:44:53 --> Output Class Initialized
INFO - 2024-03-10 11:44:53 --> Security Class Initialized
DEBUG - 2024-03-10 11:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 11:44:53 --> Input Class Initialized
INFO - 2024-03-10 11:44:53 --> Language Class Initialized
INFO - 2024-03-10 11:44:53 --> Loader Class Initialized
INFO - 2024-03-10 11:44:53 --> Helper loaded: url_helper
INFO - 2024-03-10 11:44:53 --> Helper loaded: file_helper
INFO - 2024-03-10 11:44:53 --> Helper loaded: form_helper
INFO - 2024-03-10 11:44:53 --> Database Driver Class Initialized
DEBUG - 2024-03-10 11:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 11:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 11:44:53 --> Controller Class Initialized
INFO - 2024-03-10 11:44:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 11:44:53 --> Final output sent to browser
DEBUG - 2024-03-10 11:44:53 --> Total execution time: 0.0212
ERROR - 2024-03-10 12:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:29:57 --> Config Class Initialized
INFO - 2024-03-10 12:29:57 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:29:57 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:29:57 --> Utf8 Class Initialized
INFO - 2024-03-10 12:29:57 --> URI Class Initialized
INFO - 2024-03-10 12:29:57 --> Router Class Initialized
INFO - 2024-03-10 12:29:57 --> Output Class Initialized
INFO - 2024-03-10 12:29:57 --> Security Class Initialized
DEBUG - 2024-03-10 12:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:29:57 --> Input Class Initialized
INFO - 2024-03-10 12:29:57 --> Language Class Initialized
INFO - 2024-03-10 12:29:57 --> Loader Class Initialized
INFO - 2024-03-10 12:29:57 --> Helper loaded: url_helper
INFO - 2024-03-10 12:29:57 --> Helper loaded: file_helper
INFO - 2024-03-10 12:29:57 --> Helper loaded: form_helper
INFO - 2024-03-10 12:29:57 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:29:57 --> Controller Class Initialized
INFO - 2024-03-10 12:29:57 --> Form Validation Class Initialized
INFO - 2024-03-10 12:29:57 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:29:57 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:29:57 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:29:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:29:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:29:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:29:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:29:57 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:29:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:29:57 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:29:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:29:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:29:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:29:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:29:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:29:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 12:29:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 12:29:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 12:29:57 --> Final output sent to browser
DEBUG - 2024-03-10 12:29:57 --> Total execution time: 0.0437
ERROR - 2024-03-10 12:29:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:29:58 --> Config Class Initialized
INFO - 2024-03-10 12:29:58 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:29:58 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:29:58 --> Utf8 Class Initialized
INFO - 2024-03-10 12:29:58 --> URI Class Initialized
INFO - 2024-03-10 12:29:58 --> Router Class Initialized
INFO - 2024-03-10 12:29:58 --> Output Class Initialized
INFO - 2024-03-10 12:29:58 --> Security Class Initialized
DEBUG - 2024-03-10 12:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:29:58 --> Input Class Initialized
INFO - 2024-03-10 12:29:58 --> Language Class Initialized
INFO - 2024-03-10 12:29:58 --> Loader Class Initialized
INFO - 2024-03-10 12:29:58 --> Helper loaded: url_helper
INFO - 2024-03-10 12:29:58 --> Helper loaded: file_helper
INFO - 2024-03-10 12:29:58 --> Helper loaded: form_helper
INFO - 2024-03-10 12:29:58 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:29:58 --> Controller Class Initialized
INFO - 2024-03-10 12:29:58 --> Form Validation Class Initialized
INFO - 2024-03-10 12:29:58 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:29:58 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:29:58 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:29:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:29:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:29:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:29:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:29:58 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:29:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:29:58 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:30:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:30:00 --> Config Class Initialized
INFO - 2024-03-10 12:30:00 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:30:00 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:30:00 --> Utf8 Class Initialized
INFO - 2024-03-10 12:30:00 --> URI Class Initialized
INFO - 2024-03-10 12:30:00 --> Router Class Initialized
INFO - 2024-03-10 12:30:00 --> Output Class Initialized
INFO - 2024-03-10 12:30:00 --> Security Class Initialized
DEBUG - 2024-03-10 12:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:30:00 --> Input Class Initialized
INFO - 2024-03-10 12:30:00 --> Language Class Initialized
INFO - 2024-03-10 12:30:00 --> Loader Class Initialized
INFO - 2024-03-10 12:30:00 --> Helper loaded: url_helper
INFO - 2024-03-10 12:30:00 --> Helper loaded: file_helper
INFO - 2024-03-10 12:30:00 --> Helper loaded: form_helper
INFO - 2024-03-10 12:30:00 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:30:00 --> Controller Class Initialized
INFO - 2024-03-10 12:30:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 12:30:00 --> Final output sent to browser
DEBUG - 2024-03-10 12:30:00 --> Total execution time: 0.0274
ERROR - 2024-03-10 12:34:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:34:15 --> Config Class Initialized
INFO - 2024-03-10 12:34:15 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:34:15 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:34:15 --> Utf8 Class Initialized
INFO - 2024-03-10 12:34:15 --> URI Class Initialized
INFO - 2024-03-10 12:34:15 --> Router Class Initialized
INFO - 2024-03-10 12:34:15 --> Output Class Initialized
INFO - 2024-03-10 12:34:15 --> Security Class Initialized
DEBUG - 2024-03-10 12:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:34:15 --> Input Class Initialized
INFO - 2024-03-10 12:34:15 --> Language Class Initialized
INFO - 2024-03-10 12:34:15 --> Loader Class Initialized
INFO - 2024-03-10 12:34:15 --> Helper loaded: url_helper
INFO - 2024-03-10 12:34:15 --> Helper loaded: file_helper
INFO - 2024-03-10 12:34:15 --> Helper loaded: form_helper
INFO - 2024-03-10 12:34:15 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:34:15 --> Controller Class Initialized
INFO - 2024-03-10 12:34:15 --> Form Validation Class Initialized
INFO - 2024-03-10 12:34:15 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 12:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 12:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 12:34:15 --> Final output sent to browser
DEBUG - 2024-03-10 12:34:15 --> Total execution time: 0.0418
ERROR - 2024-03-10 12:34:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:34:15 --> Config Class Initialized
INFO - 2024-03-10 12:34:15 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:34:15 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:34:15 --> Utf8 Class Initialized
INFO - 2024-03-10 12:34:15 --> URI Class Initialized
INFO - 2024-03-10 12:34:15 --> Router Class Initialized
INFO - 2024-03-10 12:34:15 --> Output Class Initialized
INFO - 2024-03-10 12:34:15 --> Security Class Initialized
DEBUG - 2024-03-10 12:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:34:15 --> Input Class Initialized
INFO - 2024-03-10 12:34:15 --> Language Class Initialized
INFO - 2024-03-10 12:34:15 --> Loader Class Initialized
INFO - 2024-03-10 12:34:15 --> Helper loaded: url_helper
INFO - 2024-03-10 12:34:15 --> Helper loaded: file_helper
INFO - 2024-03-10 12:34:15 --> Helper loaded: form_helper
INFO - 2024-03-10 12:34:15 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:34:15 --> Controller Class Initialized
INFO - 2024-03-10 12:34:15 --> Form Validation Class Initialized
INFO - 2024-03-10 12:34:15 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:34:15 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:34:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:34:17 --> Config Class Initialized
INFO - 2024-03-10 12:34:17 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:34:17 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:34:17 --> Utf8 Class Initialized
INFO - 2024-03-10 12:34:17 --> URI Class Initialized
INFO - 2024-03-10 12:34:17 --> Router Class Initialized
INFO - 2024-03-10 12:34:17 --> Output Class Initialized
INFO - 2024-03-10 12:34:17 --> Security Class Initialized
DEBUG - 2024-03-10 12:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:34:17 --> Input Class Initialized
INFO - 2024-03-10 12:34:17 --> Language Class Initialized
INFO - 2024-03-10 12:34:17 --> Loader Class Initialized
INFO - 2024-03-10 12:34:17 --> Helper loaded: url_helper
INFO - 2024-03-10 12:34:17 --> Helper loaded: file_helper
INFO - 2024-03-10 12:34:17 --> Helper loaded: form_helper
INFO - 2024-03-10 12:34:17 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:34:17 --> Controller Class Initialized
INFO - 2024-03-10 12:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 12:34:17 --> Final output sent to browser
DEBUG - 2024-03-10 12:34:17 --> Total execution time: 0.0200
ERROR - 2024-03-10 12:34:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:34:18 --> Config Class Initialized
INFO - 2024-03-10 12:34:18 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:34:18 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:34:18 --> Utf8 Class Initialized
INFO - 2024-03-10 12:34:18 --> URI Class Initialized
INFO - 2024-03-10 12:34:18 --> Router Class Initialized
INFO - 2024-03-10 12:34:18 --> Output Class Initialized
INFO - 2024-03-10 12:34:18 --> Security Class Initialized
DEBUG - 2024-03-10 12:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:34:18 --> Input Class Initialized
INFO - 2024-03-10 12:34:18 --> Language Class Initialized
INFO - 2024-03-10 12:34:18 --> Loader Class Initialized
INFO - 2024-03-10 12:34:18 --> Helper loaded: url_helper
INFO - 2024-03-10 12:34:18 --> Helper loaded: file_helper
INFO - 2024-03-10 12:34:18 --> Helper loaded: form_helper
INFO - 2024-03-10 12:34:18 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:34:18 --> Controller Class Initialized
INFO - 2024-03-10 12:34:18 --> Form Validation Class Initialized
INFO - 2024-03-10 12:34:18 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:34:18 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:34:18 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:34:18 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:34:18 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:34:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:34:18 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:34:18 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:34:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:34:18 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:34:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:34:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:34:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:34:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:34:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:34:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 12:34:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 12:34:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 12:34:18 --> Final output sent to browser
DEBUG - 2024-03-10 12:34:18 --> Total execution time: 0.0541
ERROR - 2024-03-10 12:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:34:29 --> Config Class Initialized
INFO - 2024-03-10 12:34:29 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:34:29 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:34:29 --> Utf8 Class Initialized
INFO - 2024-03-10 12:34:29 --> URI Class Initialized
INFO - 2024-03-10 12:34:29 --> Router Class Initialized
INFO - 2024-03-10 12:34:29 --> Output Class Initialized
INFO - 2024-03-10 12:34:29 --> Security Class Initialized
DEBUG - 2024-03-10 12:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:34:29 --> Input Class Initialized
INFO - 2024-03-10 12:34:29 --> Language Class Initialized
INFO - 2024-03-10 12:34:29 --> Loader Class Initialized
INFO - 2024-03-10 12:34:29 --> Helper loaded: url_helper
INFO - 2024-03-10 12:34:29 --> Helper loaded: file_helper
INFO - 2024-03-10 12:34:29 --> Helper loaded: form_helper
INFO - 2024-03-10 12:34:29 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:34:29 --> Controller Class Initialized
INFO - 2024-03-10 12:34:29 --> Form Validation Class Initialized
INFO - 2024-03-10 12:34:29 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:34:29 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:34:29 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:34:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:34:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:34:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:34:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:34:29 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:34:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:34:29 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:34:29 --> Query error: Invalid use of group function - Invalid query: SELECT `item_master`.*, IF(item_master.item_image != '', CONCAT('http://localhost/sscy/assets/uploads/products/', item_master.item_image), 'http://localhost/sscy/assets/dist/img/app-img/sample/brand/1.jpg') as item_image, `item_group`.`group_name`, GROUP_CONCAT(category_master.category_name) as category_name
FROM `item_master`
LEFT JOIN `item_group` ON `item_group`.`id` = `item_master`.`group_id`
LEFT JOIN `category_master` ON FIND_IN_SET(category_master.id,item_master.category_id) > 0
WHERE `item_master`.`is_delete` = 0
AND   (
 item_master.item_code  LIKE '%c%'
OR  item_master.item_name  LIKE '%c%'
OR  item_master.price  LIKE '%c%'
OR  item_group.group_name  LIKE '%c%'
OR  GROUP_CONCAT(category_master.category_name)  LIKE '%c%'
 )
GROUP BY `item_master`.`id`
INFO - 2024-03-10 12:34:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-03-10 12:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:34:30 --> Config Class Initialized
INFO - 2024-03-10 12:34:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:34:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:34:30 --> Utf8 Class Initialized
INFO - 2024-03-10 12:34:30 --> URI Class Initialized
INFO - 2024-03-10 12:34:30 --> Router Class Initialized
INFO - 2024-03-10 12:34:30 --> Output Class Initialized
INFO - 2024-03-10 12:34:30 --> Security Class Initialized
DEBUG - 2024-03-10 12:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:34:30 --> Input Class Initialized
INFO - 2024-03-10 12:34:30 --> Language Class Initialized
INFO - 2024-03-10 12:34:30 --> Loader Class Initialized
INFO - 2024-03-10 12:34:30 --> Helper loaded: url_helper
INFO - 2024-03-10 12:34:30 --> Helper loaded: file_helper
INFO - 2024-03-10 12:34:30 --> Helper loaded: form_helper
INFO - 2024-03-10 12:34:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:34:30 --> Controller Class Initialized
INFO - 2024-03-10 12:34:30 --> Form Validation Class Initialized
INFO - 2024-03-10 12:34:30 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:34:30 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:34:30 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:34:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:34:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:34:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:34:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:34:30 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:34:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:34:30 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:34:30 --> Query error: Invalid use of group function - Invalid query: SELECT `item_master`.*, IF(item_master.item_image != '', CONCAT('http://localhost/sscy/assets/uploads/products/', item_master.item_image), 'http://localhost/sscy/assets/dist/img/app-img/sample/brand/1.jpg') as item_image, `item_group`.`group_name`, GROUP_CONCAT(category_master.category_name) as category_name
FROM `item_master`
LEFT JOIN `item_group` ON `item_group`.`id` = `item_master`.`group_id`
LEFT JOIN `category_master` ON FIND_IN_SET(category_master.id,item_master.category_id) > 0
WHERE `item_master`.`is_delete` = 0
AND   (
 item_master.item_code  LIKE '%ca%'
OR  item_master.item_name  LIKE '%ca%'
OR  item_master.price  LIKE '%ca%'
OR  item_group.group_name  LIKE '%ca%'
OR  GROUP_CONCAT(category_master.category_name)  LIKE '%ca%'
 )
GROUP BY `item_master`.`id`
INFO - 2024-03-10 12:34:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-03-10 12:35:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:35:40 --> Config Class Initialized
INFO - 2024-03-10 12:35:40 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:35:40 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:35:40 --> Utf8 Class Initialized
INFO - 2024-03-10 12:35:40 --> URI Class Initialized
INFO - 2024-03-10 12:35:40 --> Router Class Initialized
INFO - 2024-03-10 12:35:40 --> Output Class Initialized
INFO - 2024-03-10 12:35:40 --> Security Class Initialized
DEBUG - 2024-03-10 12:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:35:40 --> Input Class Initialized
INFO - 2024-03-10 12:35:40 --> Language Class Initialized
INFO - 2024-03-10 12:35:40 --> Loader Class Initialized
INFO - 2024-03-10 12:35:40 --> Helper loaded: url_helper
INFO - 2024-03-10 12:35:40 --> Helper loaded: file_helper
INFO - 2024-03-10 12:35:40 --> Helper loaded: form_helper
INFO - 2024-03-10 12:35:40 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:35:40 --> Controller Class Initialized
INFO - 2024-03-10 12:35:40 --> Form Validation Class Initialized
INFO - 2024-03-10 12:35:40 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:35:40 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:35:40 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:35:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:35:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:35:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:35:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:35:40 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:35:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:35:40 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:35:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:35:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:35:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:35:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:35:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:35:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 12:35:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 12:35:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 12:35:40 --> Final output sent to browser
DEBUG - 2024-03-10 12:35:40 --> Total execution time: 0.0422
ERROR - 2024-03-10 12:35:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:35:41 --> Config Class Initialized
INFO - 2024-03-10 12:35:41 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:35:41 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:35:41 --> Utf8 Class Initialized
INFO - 2024-03-10 12:35:41 --> URI Class Initialized
INFO - 2024-03-10 12:35:41 --> Router Class Initialized
INFO - 2024-03-10 12:35:41 --> Output Class Initialized
INFO - 2024-03-10 12:35:41 --> Security Class Initialized
DEBUG - 2024-03-10 12:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:35:41 --> Input Class Initialized
INFO - 2024-03-10 12:35:41 --> Language Class Initialized
INFO - 2024-03-10 12:35:41 --> Loader Class Initialized
INFO - 2024-03-10 12:35:41 --> Helper loaded: url_helper
INFO - 2024-03-10 12:35:41 --> Helper loaded: file_helper
INFO - 2024-03-10 12:35:41 --> Helper loaded: form_helper
INFO - 2024-03-10 12:35:41 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:35:41 --> Controller Class Initialized
INFO - 2024-03-10 12:35:41 --> Form Validation Class Initialized
INFO - 2024-03-10 12:35:41 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:35:41 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:35:41 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:35:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:35:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:35:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:35:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:35:41 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:35:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:35:41 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:35:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:35:43 --> Config Class Initialized
INFO - 2024-03-10 12:35:43 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:35:43 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:35:43 --> Utf8 Class Initialized
INFO - 2024-03-10 12:35:43 --> URI Class Initialized
INFO - 2024-03-10 12:35:43 --> Router Class Initialized
INFO - 2024-03-10 12:35:43 --> Output Class Initialized
INFO - 2024-03-10 12:35:43 --> Security Class Initialized
DEBUG - 2024-03-10 12:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:35:43 --> Input Class Initialized
INFO - 2024-03-10 12:35:43 --> Language Class Initialized
INFO - 2024-03-10 12:35:43 --> Loader Class Initialized
INFO - 2024-03-10 12:35:43 --> Helper loaded: url_helper
INFO - 2024-03-10 12:35:43 --> Helper loaded: file_helper
INFO - 2024-03-10 12:35:43 --> Helper loaded: form_helper
INFO - 2024-03-10 12:35:43 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:35:43 --> Controller Class Initialized
INFO - 2024-03-10 12:35:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 12:35:43 --> Final output sent to browser
DEBUG - 2024-03-10 12:35:43 --> Total execution time: 0.0275
ERROR - 2024-03-10 12:35:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:35:48 --> Config Class Initialized
INFO - 2024-03-10 12:35:48 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:35:48 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:35:48 --> Utf8 Class Initialized
INFO - 2024-03-10 12:35:48 --> URI Class Initialized
INFO - 2024-03-10 12:35:48 --> Router Class Initialized
INFO - 2024-03-10 12:35:48 --> Output Class Initialized
INFO - 2024-03-10 12:35:48 --> Security Class Initialized
DEBUG - 2024-03-10 12:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:35:48 --> Input Class Initialized
INFO - 2024-03-10 12:35:48 --> Language Class Initialized
INFO - 2024-03-10 12:35:48 --> Loader Class Initialized
INFO - 2024-03-10 12:35:48 --> Helper loaded: url_helper
INFO - 2024-03-10 12:35:48 --> Helper loaded: file_helper
INFO - 2024-03-10 12:35:48 --> Helper loaded: form_helper
INFO - 2024-03-10 12:35:48 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:35:48 --> Controller Class Initialized
INFO - 2024-03-10 12:35:48 --> Form Validation Class Initialized
INFO - 2024-03-10 12:35:48 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:35:48 --> Query error: Invalid use of group function - Invalid query: SELECT `item_master`.*, IF(item_master.item_image != '', CONCAT('http://localhost/sscy/assets/uploads/products/', item_master.item_image), 'http://localhost/sscy/assets/dist/img/app-img/sample/brand/1.jpg') as item_image, `item_group`.`group_name`, GROUP_CONCAT(category_master.category_name) as category_name
FROM `item_master`
LEFT JOIN `item_group` ON `item_group`.`id` = `item_master`.`group_id`
LEFT JOIN `category_master` ON FIND_IN_SET(category_master.id,item_master.category_id) > 0
WHERE `item_master`.`is_delete` = 0
AND   (
 item_master.item_code  LIKE '%g%'
OR  item_master.item_name  LIKE '%g%'
OR  item_master.price  LIKE '%g%'
OR  item_group.group_name  LIKE '%g%'
OR  GROUP_CONCAT(category_master.category_name)  LIKE '%g%'
 )
GROUP BY `item_master`.`id`
INFO - 2024-03-10 12:35:48 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-03-10 12:35:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:35:48 --> Config Class Initialized
INFO - 2024-03-10 12:35:48 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:35:48 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:35:48 --> Utf8 Class Initialized
INFO - 2024-03-10 12:35:48 --> URI Class Initialized
INFO - 2024-03-10 12:35:48 --> Router Class Initialized
INFO - 2024-03-10 12:35:48 --> Output Class Initialized
INFO - 2024-03-10 12:35:48 --> Security Class Initialized
DEBUG - 2024-03-10 12:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:35:48 --> Input Class Initialized
INFO - 2024-03-10 12:35:48 --> Language Class Initialized
INFO - 2024-03-10 12:35:48 --> Loader Class Initialized
INFO - 2024-03-10 12:35:48 --> Helper loaded: url_helper
INFO - 2024-03-10 12:35:48 --> Helper loaded: file_helper
INFO - 2024-03-10 12:35:48 --> Helper loaded: form_helper
INFO - 2024-03-10 12:35:48 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:35:48 --> Controller Class Initialized
INFO - 2024-03-10 12:35:48 --> Form Validation Class Initialized
INFO - 2024-03-10 12:35:48 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:35:48 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:35:48 --> Query error: Invalid use of group function - Invalid query: SELECT `item_master`.*, IF(item_master.item_image != '', CONCAT('http://localhost/sscy/assets/uploads/products/', item_master.item_image), 'http://localhost/sscy/assets/dist/img/app-img/sample/brand/1.jpg') as item_image, `item_group`.`group_name`, GROUP_CONCAT(category_master.category_name) as category_name
FROM `item_master`
LEFT JOIN `item_group` ON `item_group`.`id` = `item_master`.`group_id`
LEFT JOIN `category_master` ON FIND_IN_SET(category_master.id,item_master.category_id) > 0
WHERE `item_master`.`is_delete` = 0
AND   (
 item_master.item_code  LIKE '%gr%'
OR  item_master.item_name  LIKE '%gr%'
OR  item_master.price  LIKE '%gr%'
OR  item_group.group_name  LIKE '%gr%'
OR  GROUP_CONCAT(category_master.category_name)  LIKE '%gr%'
 )
GROUP BY `item_master`.`id`
INFO - 2024-03-10 12:35:48 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-03-10 12:35:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:35:48 --> Config Class Initialized
INFO - 2024-03-10 12:35:48 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:35:48 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:35:48 --> Utf8 Class Initialized
INFO - 2024-03-10 12:35:48 --> URI Class Initialized
INFO - 2024-03-10 12:35:48 --> Router Class Initialized
INFO - 2024-03-10 12:35:49 --> Output Class Initialized
INFO - 2024-03-10 12:35:49 --> Security Class Initialized
DEBUG - 2024-03-10 12:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:35:49 --> Input Class Initialized
INFO - 2024-03-10 12:35:49 --> Language Class Initialized
INFO - 2024-03-10 12:35:49 --> Loader Class Initialized
INFO - 2024-03-10 12:35:49 --> Helper loaded: url_helper
INFO - 2024-03-10 12:35:49 --> Helper loaded: file_helper
INFO - 2024-03-10 12:35:49 --> Helper loaded: form_helper
INFO - 2024-03-10 12:35:49 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:35:49 --> Controller Class Initialized
INFO - 2024-03-10 12:35:49 --> Form Validation Class Initialized
INFO - 2024-03-10 12:35:49 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:35:49 --> Query error: Invalid use of group function - Invalid query: SELECT `item_master`.*, IF(item_master.item_image != '', CONCAT('http://localhost/sscy/assets/uploads/products/', item_master.item_image), 'http://localhost/sscy/assets/dist/img/app-img/sample/brand/1.jpg') as item_image, `item_group`.`group_name`, GROUP_CONCAT(category_master.category_name) as category_name
FROM `item_master`
LEFT JOIN `item_group` ON `item_group`.`id` = `item_master`.`group_id`
LEFT JOIN `category_master` ON FIND_IN_SET(category_master.id,item_master.category_id) > 0
WHERE `item_master`.`is_delete` = 0
AND   (
 item_master.item_code  LIKE '%gro%'
OR  item_master.item_name  LIKE '%gro%'
OR  item_master.price  LIKE '%gro%'
OR  item_group.group_name  LIKE '%gro%'
OR  GROUP_CONCAT(category_master.category_name)  LIKE '%gro%'
 )
GROUP BY `item_master`.`id`
INFO - 2024-03-10 12:35:49 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-03-10 12:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:35:49 --> Config Class Initialized
INFO - 2024-03-10 12:35:49 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:35:49 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:35:49 --> Utf8 Class Initialized
INFO - 2024-03-10 12:35:49 --> URI Class Initialized
INFO - 2024-03-10 12:35:49 --> Router Class Initialized
INFO - 2024-03-10 12:35:49 --> Output Class Initialized
INFO - 2024-03-10 12:35:49 --> Security Class Initialized
DEBUG - 2024-03-10 12:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:35:49 --> Input Class Initialized
INFO - 2024-03-10 12:35:49 --> Language Class Initialized
INFO - 2024-03-10 12:35:49 --> Loader Class Initialized
INFO - 2024-03-10 12:35:49 --> Helper loaded: url_helper
INFO - 2024-03-10 12:35:49 --> Helper loaded: file_helper
INFO - 2024-03-10 12:35:49 --> Helper loaded: form_helper
INFO - 2024-03-10 12:35:49 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:35:49 --> Controller Class Initialized
INFO - 2024-03-10 12:35:49 --> Form Validation Class Initialized
INFO - 2024-03-10 12:35:49 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:35:49 --> Query error: Invalid use of group function - Invalid query: SELECT `item_master`.*, IF(item_master.item_image != '', CONCAT('http://localhost/sscy/assets/uploads/products/', item_master.item_image), 'http://localhost/sscy/assets/dist/img/app-img/sample/brand/1.jpg') as item_image, `item_group`.`group_name`, GROUP_CONCAT(category_master.category_name) as category_name
FROM `item_master`
LEFT JOIN `item_group` ON `item_group`.`id` = `item_master`.`group_id`
LEFT JOIN `category_master` ON FIND_IN_SET(category_master.id,item_master.category_id) > 0
WHERE `item_master`.`is_delete` = 0
AND   (
 item_master.item_code  LIKE '%grou%'
OR  item_master.item_name  LIKE '%grou%'
OR  item_master.price  LIKE '%grou%'
OR  item_group.group_name  LIKE '%grou%'
OR  GROUP_CONCAT(category_master.category_name)  LIKE '%grou%'
 )
GROUP BY `item_master`.`id`
INFO - 2024-03-10 12:35:49 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-03-10 12:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:35:49 --> Config Class Initialized
INFO - 2024-03-10 12:35:49 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:35:49 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:35:49 --> Utf8 Class Initialized
INFO - 2024-03-10 12:35:49 --> URI Class Initialized
INFO - 2024-03-10 12:35:49 --> Router Class Initialized
INFO - 2024-03-10 12:35:49 --> Output Class Initialized
INFO - 2024-03-10 12:35:49 --> Security Class Initialized
DEBUG - 2024-03-10 12:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:35:49 --> Input Class Initialized
INFO - 2024-03-10 12:35:49 --> Language Class Initialized
INFO - 2024-03-10 12:35:49 --> Loader Class Initialized
INFO - 2024-03-10 12:35:49 --> Helper loaded: url_helper
INFO - 2024-03-10 12:35:49 --> Helper loaded: file_helper
INFO - 2024-03-10 12:35:49 --> Helper loaded: form_helper
INFO - 2024-03-10 12:35:49 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:35:49 --> Controller Class Initialized
INFO - 2024-03-10 12:35:49 --> Form Validation Class Initialized
INFO - 2024-03-10 12:35:49 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:35:49 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:35:49 --> Query error: Invalid use of group function - Invalid query: SELECT `item_master`.*, IF(item_master.item_image != '', CONCAT('http://localhost/sscy/assets/uploads/products/', item_master.item_image), 'http://localhost/sscy/assets/dist/img/app-img/sample/brand/1.jpg') as item_image, `item_group`.`group_name`, GROUP_CONCAT(category_master.category_name) as category_name
FROM `item_master`
LEFT JOIN `item_group` ON `item_group`.`id` = `item_master`.`group_id`
LEFT JOIN `category_master` ON FIND_IN_SET(category_master.id,item_master.category_id) > 0
WHERE `item_master`.`is_delete` = 0
AND   (
 item_master.item_code  LIKE '%group%'
OR  item_master.item_name  LIKE '%group%'
OR  item_master.price  LIKE '%group%'
OR  item_group.group_name  LIKE '%group%'
OR  GROUP_CONCAT(category_master.category_name)  LIKE '%group%'
 )
GROUP BY `item_master`.`id`
INFO - 2024-03-10 12:35:49 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-03-10 12:36:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:14 --> Config Class Initialized
INFO - 2024-03-10 12:36:14 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:14 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:14 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:14 --> URI Class Initialized
INFO - 2024-03-10 12:36:14 --> Router Class Initialized
INFO - 2024-03-10 12:36:14 --> Output Class Initialized
INFO - 2024-03-10 12:36:14 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:14 --> Input Class Initialized
INFO - 2024-03-10 12:36:14 --> Language Class Initialized
INFO - 2024-03-10 12:36:14 --> Loader Class Initialized
INFO - 2024-03-10 12:36:14 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:14 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:14 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:14 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:14 --> Controller Class Initialized
INFO - 2024-03-10 12:36:14 --> Form Validation Class Initialized
INFO - 2024-03-10 12:36:14 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 12:36:14 --> Final output sent to browser
DEBUG - 2024-03-10 12:36:14 --> Total execution time: 0.0379
ERROR - 2024-03-10 12:36:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:14 --> Config Class Initialized
INFO - 2024-03-10 12:36:14 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:14 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:14 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:14 --> URI Class Initialized
INFO - 2024-03-10 12:36:14 --> Router Class Initialized
INFO - 2024-03-10 12:36:14 --> Output Class Initialized
INFO - 2024-03-10 12:36:14 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:14 --> Input Class Initialized
INFO - 2024-03-10 12:36:14 --> Language Class Initialized
INFO - 2024-03-10 12:36:14 --> Loader Class Initialized
INFO - 2024-03-10 12:36:14 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:14 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:14 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:14 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:14 --> Controller Class Initialized
INFO - 2024-03-10 12:36:14 --> Form Validation Class Initialized
INFO - 2024-03-10 12:36:14 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:36:14 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:36:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:16 --> Config Class Initialized
INFO - 2024-03-10 12:36:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:16 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:16 --> URI Class Initialized
INFO - 2024-03-10 12:36:16 --> Router Class Initialized
INFO - 2024-03-10 12:36:16 --> Output Class Initialized
INFO - 2024-03-10 12:36:16 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:16 --> Input Class Initialized
INFO - 2024-03-10 12:36:16 --> Language Class Initialized
INFO - 2024-03-10 12:36:16 --> Loader Class Initialized
INFO - 2024-03-10 12:36:16 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:16 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:16 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:16 --> Controller Class Initialized
INFO - 2024-03-10 12:36:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 12:36:16 --> Final output sent to browser
DEBUG - 2024-03-10 12:36:16 --> Total execution time: 0.0221
ERROR - 2024-03-10 12:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:20 --> Config Class Initialized
INFO - 2024-03-10 12:36:20 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:20 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:20 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:20 --> URI Class Initialized
INFO - 2024-03-10 12:36:20 --> Router Class Initialized
INFO - 2024-03-10 12:36:20 --> Output Class Initialized
INFO - 2024-03-10 12:36:20 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:20 --> Input Class Initialized
INFO - 2024-03-10 12:36:20 --> Language Class Initialized
INFO - 2024-03-10 12:36:20 --> Loader Class Initialized
INFO - 2024-03-10 12:36:20 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:20 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:20 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:20 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:20 --> Controller Class Initialized
INFO - 2024-03-10 12:36:20 --> Form Validation Class Initialized
INFO - 2024-03-10 12:36:20 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:36:20 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:36:20 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:36:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:36:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:36:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:36:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:36:20 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:36:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:36:20 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:36:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-10 12:36:20 --> Final output sent to browser
DEBUG - 2024-03-10 12:36:20 --> Total execution time: 0.0283
ERROR - 2024-03-10 12:36:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:30 --> Config Class Initialized
INFO - 2024-03-10 12:36:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:30 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:30 --> URI Class Initialized
INFO - 2024-03-10 12:36:30 --> Router Class Initialized
INFO - 2024-03-10 12:36:30 --> Output Class Initialized
INFO - 2024-03-10 12:36:30 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:30 --> Input Class Initialized
INFO - 2024-03-10 12:36:30 --> Language Class Initialized
INFO - 2024-03-10 12:36:30 --> Loader Class Initialized
INFO - 2024-03-10 12:36:30 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:30 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:30 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:30 --> Controller Class Initialized
INFO - 2024-03-10 12:36:30 --> Form Validation Class Initialized
INFO - 2024-03-10 12:36:30 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:36:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:30 --> Config Class Initialized
INFO - 2024-03-10 12:36:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:30 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:30 --> URI Class Initialized
INFO - 2024-03-10 12:36:30 --> Router Class Initialized
INFO - 2024-03-10 12:36:30 --> Output Class Initialized
INFO - 2024-03-10 12:36:30 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:30 --> Input Class Initialized
INFO - 2024-03-10 12:36:30 --> Language Class Initialized
INFO - 2024-03-10 12:36:30 --> Loader Class Initialized
INFO - 2024-03-10 12:36:30 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:30 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:30 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:30 --> Controller Class Initialized
INFO - 2024-03-10 12:36:30 --> Form Validation Class Initialized
INFO - 2024-03-10 12:36:30 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:36:30 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:36:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:40 --> Config Class Initialized
INFO - 2024-03-10 12:36:40 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:40 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:40 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:40 --> URI Class Initialized
INFO - 2024-03-10 12:36:40 --> Router Class Initialized
INFO - 2024-03-10 12:36:40 --> Output Class Initialized
INFO - 2024-03-10 12:36:40 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:40 --> Input Class Initialized
INFO - 2024-03-10 12:36:40 --> Language Class Initialized
INFO - 2024-03-10 12:36:40 --> Loader Class Initialized
INFO - 2024-03-10 12:36:40 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:40 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:40 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:40 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:40 --> Controller Class Initialized
INFO - 2024-03-10 12:36:40 --> Form Validation Class Initialized
INFO - 2024-03-10 12:36:40 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:36:40 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:36:40 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:36:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:36:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:36:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:36:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:36:40 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:36:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:36:40 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:36:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:41 --> Config Class Initialized
INFO - 2024-03-10 12:36:41 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:41 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:41 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:41 --> URI Class Initialized
INFO - 2024-03-10 12:36:41 --> Router Class Initialized
INFO - 2024-03-10 12:36:41 --> Output Class Initialized
INFO - 2024-03-10 12:36:41 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:41 --> Input Class Initialized
INFO - 2024-03-10 12:36:41 --> Language Class Initialized
INFO - 2024-03-10 12:36:41 --> Loader Class Initialized
INFO - 2024-03-10 12:36:42 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:42 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:42 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:42 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:42 --> Controller Class Initialized
INFO - 2024-03-10 12:36:42 --> Form Validation Class Initialized
INFO - 2024-03-10 12:36:42 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:36:42 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:36:42 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:36:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:36:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:36:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:36:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:36:42 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:36:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:36:42 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:36:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:49 --> Config Class Initialized
INFO - 2024-03-10 12:36:49 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:49 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:49 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:49 --> URI Class Initialized
INFO - 2024-03-10 12:36:49 --> Router Class Initialized
INFO - 2024-03-10 12:36:49 --> Output Class Initialized
INFO - 2024-03-10 12:36:49 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:49 --> Input Class Initialized
INFO - 2024-03-10 12:36:49 --> Language Class Initialized
INFO - 2024-03-10 12:36:49 --> Loader Class Initialized
INFO - 2024-03-10 12:36:49 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:49 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:49 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:49 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:49 --> Controller Class Initialized
INFO - 2024-03-10 12:36:49 --> Form Validation Class Initialized
INFO - 2024-03-10 12:36:49 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:36:49 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:36:49 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:36:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:36:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:36:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:36:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:36:49 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:36:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:36:49 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:36:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:51 --> Config Class Initialized
INFO - 2024-03-10 12:36:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:51 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:51 --> URI Class Initialized
INFO - 2024-03-10 12:36:51 --> Router Class Initialized
INFO - 2024-03-10 12:36:51 --> Output Class Initialized
INFO - 2024-03-10 12:36:51 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:51 --> Input Class Initialized
INFO - 2024-03-10 12:36:51 --> Language Class Initialized
INFO - 2024-03-10 12:36:51 --> Loader Class Initialized
INFO - 2024-03-10 12:36:51 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:51 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:51 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:51 --> Controller Class Initialized
INFO - 2024-03-10 12:36:51 --> Form Validation Class Initialized
INFO - 2024-03-10 12:36:51 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:36:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:51 --> Config Class Initialized
INFO - 2024-03-10 12:36:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:51 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:51 --> URI Class Initialized
INFO - 2024-03-10 12:36:51 --> Router Class Initialized
INFO - 2024-03-10 12:36:51 --> Output Class Initialized
INFO - 2024-03-10 12:36:51 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:51 --> Input Class Initialized
INFO - 2024-03-10 12:36:51 --> Language Class Initialized
INFO - 2024-03-10 12:36:51 --> Loader Class Initialized
INFO - 2024-03-10 12:36:51 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:51 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:51 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:51 --> Controller Class Initialized
INFO - 2024-03-10 12:36:51 --> Form Validation Class Initialized
INFO - 2024-03-10 12:36:51 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:36:51 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 12:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 12:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 12:36:51 --> Final output sent to browser
DEBUG - 2024-03-10 12:36:51 --> Total execution time: 0.0431
ERROR - 2024-03-10 12:36:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:54 --> Config Class Initialized
INFO - 2024-03-10 12:36:54 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:54 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:54 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:54 --> URI Class Initialized
INFO - 2024-03-10 12:36:54 --> Router Class Initialized
INFO - 2024-03-10 12:36:54 --> Output Class Initialized
INFO - 2024-03-10 12:36:54 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:54 --> Input Class Initialized
INFO - 2024-03-10 12:36:54 --> Language Class Initialized
INFO - 2024-03-10 12:36:54 --> Loader Class Initialized
INFO - 2024-03-10 12:36:54 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:54 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:54 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:54 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:54 --> Controller Class Initialized
INFO - 2024-03-10 12:36:54 --> Form Validation Class Initialized
INFO - 2024-03-10 12:36:54 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:36:54 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:36:54 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:36:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:36:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:36:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:36:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:36:54 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:36:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:36:54 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:36:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:36:57 --> Config Class Initialized
INFO - 2024-03-10 12:36:57 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:36:57 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:36:57 --> Utf8 Class Initialized
INFO - 2024-03-10 12:36:57 --> URI Class Initialized
INFO - 2024-03-10 12:36:57 --> Router Class Initialized
INFO - 2024-03-10 12:36:57 --> Output Class Initialized
INFO - 2024-03-10 12:36:57 --> Security Class Initialized
DEBUG - 2024-03-10 12:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:36:57 --> Input Class Initialized
INFO - 2024-03-10 12:36:57 --> Language Class Initialized
INFO - 2024-03-10 12:36:57 --> Loader Class Initialized
INFO - 2024-03-10 12:36:57 --> Helper loaded: url_helper
INFO - 2024-03-10 12:36:57 --> Helper loaded: file_helper
INFO - 2024-03-10 12:36:57 --> Helper loaded: form_helper
INFO - 2024-03-10 12:36:57 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:36:57 --> Controller Class Initialized
INFO - 2024-03-10 12:36:57 --> Form Validation Class Initialized
INFO - 2024-03-10 12:36:57 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:36:57 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:36:57 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:36:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:36:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:36:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:36:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:36:57 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:36:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:36:57 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:37:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:37:43 --> Config Class Initialized
INFO - 2024-03-10 12:37:43 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:37:43 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:37:43 --> Utf8 Class Initialized
INFO - 2024-03-10 12:37:43 --> URI Class Initialized
INFO - 2024-03-10 12:37:43 --> Router Class Initialized
INFO - 2024-03-10 12:37:43 --> Output Class Initialized
INFO - 2024-03-10 12:37:43 --> Security Class Initialized
DEBUG - 2024-03-10 12:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:37:43 --> Input Class Initialized
INFO - 2024-03-10 12:37:43 --> Language Class Initialized
INFO - 2024-03-10 12:37:43 --> Loader Class Initialized
INFO - 2024-03-10 12:37:43 --> Helper loaded: url_helper
INFO - 2024-03-10 12:37:43 --> Helper loaded: file_helper
INFO - 2024-03-10 12:37:43 --> Helper loaded: form_helper
INFO - 2024-03-10 12:37:43 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:37:43 --> Controller Class Initialized
INFO - 2024-03-10 12:37:43 --> Form Validation Class Initialized
INFO - 2024-03-10 12:37:43 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:37:43 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:37:43 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:37:43 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:37:43 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:37:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:37:43 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:37:43 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:37:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:37:43 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:37:45 --> Config Class Initialized
INFO - 2024-03-10 12:37:45 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:37:45 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:37:45 --> Utf8 Class Initialized
INFO - 2024-03-10 12:37:45 --> URI Class Initialized
INFO - 2024-03-10 12:37:45 --> Router Class Initialized
INFO - 2024-03-10 12:37:45 --> Output Class Initialized
INFO - 2024-03-10 12:37:45 --> Security Class Initialized
DEBUG - 2024-03-10 12:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:37:45 --> Input Class Initialized
INFO - 2024-03-10 12:37:45 --> Language Class Initialized
INFO - 2024-03-10 12:37:45 --> Loader Class Initialized
INFO - 2024-03-10 12:37:45 --> Helper loaded: url_helper
INFO - 2024-03-10 12:37:45 --> Helper loaded: file_helper
INFO - 2024-03-10 12:37:45 --> Helper loaded: form_helper
INFO - 2024-03-10 12:37:45 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:37:45 --> Controller Class Initialized
INFO - 2024-03-10 12:37:45 --> Form Validation Class Initialized
INFO - 2024-03-10 12:37:45 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:37:45 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:37:45 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:37:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:37:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:37:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:37:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:37:45 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:37:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:37:45 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:37:46 --> Config Class Initialized
INFO - 2024-03-10 12:37:46 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:37:47 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:37:47 --> Utf8 Class Initialized
INFO - 2024-03-10 12:37:47 --> URI Class Initialized
INFO - 2024-03-10 12:37:47 --> Router Class Initialized
INFO - 2024-03-10 12:37:47 --> Output Class Initialized
INFO - 2024-03-10 12:37:47 --> Security Class Initialized
DEBUG - 2024-03-10 12:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:37:47 --> Input Class Initialized
INFO - 2024-03-10 12:37:47 --> Language Class Initialized
INFO - 2024-03-10 12:37:47 --> Loader Class Initialized
INFO - 2024-03-10 12:37:47 --> Helper loaded: url_helper
INFO - 2024-03-10 12:37:47 --> Helper loaded: file_helper
INFO - 2024-03-10 12:37:47 --> Helper loaded: form_helper
INFO - 2024-03-10 12:37:47 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:37:47 --> Controller Class Initialized
INFO - 2024-03-10 12:37:47 --> Form Validation Class Initialized
INFO - 2024-03-10 12:37:47 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:37:47 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:37:47 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:37:47 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:37:47 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:37:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:37:47 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:37:47 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:37:47 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:37:47 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:37:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-10 12:37:47 --> Final output sent to browser
DEBUG - 2024-03-10 12:37:47 --> Total execution time: 0.0484
ERROR - 2024-03-10 12:37:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:37:51 --> Config Class Initialized
INFO - 2024-03-10 12:37:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:37:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:37:51 --> Utf8 Class Initialized
INFO - 2024-03-10 12:37:51 --> URI Class Initialized
INFO - 2024-03-10 12:37:51 --> Router Class Initialized
INFO - 2024-03-10 12:37:51 --> Output Class Initialized
INFO - 2024-03-10 12:37:51 --> Security Class Initialized
DEBUG - 2024-03-10 12:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:37:51 --> Input Class Initialized
INFO - 2024-03-10 12:37:51 --> Language Class Initialized
INFO - 2024-03-10 12:37:51 --> Loader Class Initialized
INFO - 2024-03-10 12:37:51 --> Helper loaded: url_helper
INFO - 2024-03-10 12:37:51 --> Helper loaded: file_helper
INFO - 2024-03-10 12:37:51 --> Helper loaded: form_helper
INFO - 2024-03-10 12:37:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:37:51 --> Controller Class Initialized
INFO - 2024-03-10 12:37:51 --> Form Validation Class Initialized
INFO - 2024-03-10 12:37:51 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:37:51 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:37:51 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:37:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:37:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:37:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:37:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:37:51 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:37:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:37:51 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:37:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-10 12:37:51 --> Final output sent to browser
DEBUG - 2024-03-10 12:37:51 --> Total execution time: 0.0360
ERROR - 2024-03-10 12:38:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:38:02 --> Config Class Initialized
INFO - 2024-03-10 12:38:02 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:38:02 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:38:02 --> Utf8 Class Initialized
INFO - 2024-03-10 12:38:02 --> URI Class Initialized
INFO - 2024-03-10 12:38:02 --> Router Class Initialized
INFO - 2024-03-10 12:38:02 --> Output Class Initialized
INFO - 2024-03-10 12:38:02 --> Security Class Initialized
DEBUG - 2024-03-10 12:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:38:02 --> Input Class Initialized
INFO - 2024-03-10 12:38:02 --> Language Class Initialized
INFO - 2024-03-10 12:38:02 --> Loader Class Initialized
INFO - 2024-03-10 12:38:02 --> Helper loaded: url_helper
INFO - 2024-03-10 12:38:02 --> Helper loaded: file_helper
INFO - 2024-03-10 12:38:02 --> Helper loaded: form_helper
INFO - 2024-03-10 12:38:02 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:38:02 --> Controller Class Initialized
INFO - 2024-03-10 12:38:02 --> Form Validation Class Initialized
INFO - 2024-03-10 12:38:02 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:38:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:38:02 --> Config Class Initialized
INFO - 2024-03-10 12:38:02 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:38:02 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:38:02 --> Utf8 Class Initialized
INFO - 2024-03-10 12:38:02 --> URI Class Initialized
INFO - 2024-03-10 12:38:02 --> Router Class Initialized
INFO - 2024-03-10 12:38:02 --> Output Class Initialized
INFO - 2024-03-10 12:38:02 --> Security Class Initialized
DEBUG - 2024-03-10 12:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:38:02 --> Input Class Initialized
INFO - 2024-03-10 12:38:02 --> Language Class Initialized
INFO - 2024-03-10 12:38:02 --> Loader Class Initialized
INFO - 2024-03-10 12:38:02 --> Helper loaded: url_helper
INFO - 2024-03-10 12:38:02 --> Helper loaded: file_helper
INFO - 2024-03-10 12:38:02 --> Helper loaded: form_helper
INFO - 2024-03-10 12:38:02 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:38:02 --> Controller Class Initialized
INFO - 2024-03-10 12:38:02 --> Form Validation Class Initialized
INFO - 2024-03-10 12:38:02 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:38:02 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:38:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:38:04 --> Config Class Initialized
INFO - 2024-03-10 12:38:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:38:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:38:04 --> Utf8 Class Initialized
INFO - 2024-03-10 12:38:04 --> URI Class Initialized
INFO - 2024-03-10 12:38:04 --> Router Class Initialized
INFO - 2024-03-10 12:38:04 --> Output Class Initialized
INFO - 2024-03-10 12:38:04 --> Security Class Initialized
DEBUG - 2024-03-10 12:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:38:04 --> Input Class Initialized
INFO - 2024-03-10 12:38:04 --> Language Class Initialized
INFO - 2024-03-10 12:38:04 --> Loader Class Initialized
INFO - 2024-03-10 12:38:04 --> Helper loaded: url_helper
INFO - 2024-03-10 12:38:04 --> Helper loaded: file_helper
INFO - 2024-03-10 12:38:04 --> Helper loaded: form_helper
INFO - 2024-03-10 12:38:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:38:04 --> Controller Class Initialized
INFO - 2024-03-10 12:38:04 --> Form Validation Class Initialized
INFO - 2024-03-10 12:38:04 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:38:04 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:38:04 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:38:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:38:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:38:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:38:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:38:04 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:38:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:38:04 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:38:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-10 12:38:04 --> Final output sent to browser
DEBUG - 2024-03-10 12:38:04 --> Total execution time: 0.0347
ERROR - 2024-03-10 12:38:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:38:11 --> Config Class Initialized
INFO - 2024-03-10 12:38:11 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:38:11 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:38:11 --> Utf8 Class Initialized
INFO - 2024-03-10 12:38:11 --> URI Class Initialized
INFO - 2024-03-10 12:38:11 --> Router Class Initialized
INFO - 2024-03-10 12:38:11 --> Output Class Initialized
INFO - 2024-03-10 12:38:11 --> Security Class Initialized
DEBUG - 2024-03-10 12:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:38:11 --> Input Class Initialized
INFO - 2024-03-10 12:38:11 --> Language Class Initialized
INFO - 2024-03-10 12:38:11 --> Loader Class Initialized
INFO - 2024-03-10 12:38:11 --> Helper loaded: url_helper
INFO - 2024-03-10 12:38:11 --> Helper loaded: file_helper
INFO - 2024-03-10 12:38:11 --> Helper loaded: form_helper
INFO - 2024-03-10 12:38:11 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:38:11 --> Controller Class Initialized
INFO - 2024-03-10 12:38:11 --> Form Validation Class Initialized
INFO - 2024-03-10 12:38:11 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:38:11 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:38:11 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:38:11 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:38:11 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:38:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:38:11 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:38:11 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:38:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:38:11 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:38:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:38:13 --> Config Class Initialized
INFO - 2024-03-10 12:38:13 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:38:13 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:38:13 --> Utf8 Class Initialized
INFO - 2024-03-10 12:38:13 --> URI Class Initialized
INFO - 2024-03-10 12:38:13 --> Router Class Initialized
INFO - 2024-03-10 12:38:13 --> Output Class Initialized
INFO - 2024-03-10 12:38:13 --> Security Class Initialized
DEBUG - 2024-03-10 12:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:38:13 --> Input Class Initialized
INFO - 2024-03-10 12:38:13 --> Language Class Initialized
INFO - 2024-03-10 12:38:13 --> Loader Class Initialized
INFO - 2024-03-10 12:38:13 --> Helper loaded: url_helper
INFO - 2024-03-10 12:38:13 --> Helper loaded: file_helper
INFO - 2024-03-10 12:38:13 --> Helper loaded: form_helper
INFO - 2024-03-10 12:38:13 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:38:13 --> Controller Class Initialized
INFO - 2024-03-10 12:38:13 --> Form Validation Class Initialized
INFO - 2024-03-10 12:38:13 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:38:13 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:38:13 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:38:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:38:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:38:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:38:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:38:13 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:38:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:38:13 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:38:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:38:16 --> Config Class Initialized
INFO - 2024-03-10 12:38:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:38:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:38:16 --> Utf8 Class Initialized
INFO - 2024-03-10 12:38:16 --> URI Class Initialized
INFO - 2024-03-10 12:38:16 --> Router Class Initialized
INFO - 2024-03-10 12:38:16 --> Output Class Initialized
INFO - 2024-03-10 12:38:16 --> Security Class Initialized
DEBUG - 2024-03-10 12:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:38:16 --> Input Class Initialized
INFO - 2024-03-10 12:38:16 --> Language Class Initialized
INFO - 2024-03-10 12:38:16 --> Loader Class Initialized
INFO - 2024-03-10 12:38:16 --> Helper loaded: url_helper
INFO - 2024-03-10 12:38:16 --> Helper loaded: file_helper
INFO - 2024-03-10 12:38:16 --> Helper loaded: form_helper
INFO - 2024-03-10 12:38:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:38:16 --> Controller Class Initialized
INFO - 2024-03-10 12:38:16 --> Form Validation Class Initialized
INFO - 2024-03-10 12:38:16 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:38:16 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:38:16 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:38:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:38:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:38:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:38:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:38:16 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:38:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:38:16 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:40:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:40:58 --> Config Class Initialized
INFO - 2024-03-10 12:40:58 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:40:58 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:40:58 --> Utf8 Class Initialized
INFO - 2024-03-10 12:40:58 --> URI Class Initialized
INFO - 2024-03-10 12:40:58 --> Router Class Initialized
INFO - 2024-03-10 12:40:58 --> Output Class Initialized
INFO - 2024-03-10 12:40:58 --> Security Class Initialized
DEBUG - 2024-03-10 12:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:40:58 --> Input Class Initialized
INFO - 2024-03-10 12:40:58 --> Language Class Initialized
INFO - 2024-03-10 12:40:58 --> Loader Class Initialized
INFO - 2024-03-10 12:40:58 --> Helper loaded: url_helper
INFO - 2024-03-10 12:40:58 --> Helper loaded: file_helper
INFO - 2024-03-10 12:40:58 --> Helper loaded: form_helper
INFO - 2024-03-10 12:40:58 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:40:58 --> Controller Class Initialized
INFO - 2024-03-10 12:40:58 --> Form Validation Class Initialized
INFO - 2024-03-10 12:40:58 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:40:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:40:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:40:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:40:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:40:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:40:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:40:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:40:58 --> Final output sent to browser
DEBUG - 2024-03-10 12:40:58 --> Total execution time: 0.0364
ERROR - 2024-03-10 12:40:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:40:58 --> Config Class Initialized
INFO - 2024-03-10 12:40:58 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:40:58 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:40:58 --> Utf8 Class Initialized
INFO - 2024-03-10 12:40:58 --> URI Class Initialized
INFO - 2024-03-10 12:40:58 --> Router Class Initialized
INFO - 2024-03-10 12:40:58 --> Output Class Initialized
INFO - 2024-03-10 12:40:58 --> Security Class Initialized
DEBUG - 2024-03-10 12:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:40:58 --> Input Class Initialized
INFO - 2024-03-10 12:40:58 --> Language Class Initialized
INFO - 2024-03-10 12:40:58 --> Loader Class Initialized
INFO - 2024-03-10 12:40:58 --> Helper loaded: url_helper
INFO - 2024-03-10 12:40:58 --> Helper loaded: file_helper
INFO - 2024-03-10 12:40:58 --> Helper loaded: form_helper
INFO - 2024-03-10 12:40:58 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:40:58 --> Controller Class Initialized
INFO - 2024-03-10 12:40:58 --> Form Validation Class Initialized
INFO - 2024-03-10 12:40:58 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:40:58 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:41:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:41:00 --> Config Class Initialized
INFO - 2024-03-10 12:41:00 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:41:00 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:41:00 --> Utf8 Class Initialized
INFO - 2024-03-10 12:41:00 --> URI Class Initialized
INFO - 2024-03-10 12:41:00 --> Router Class Initialized
INFO - 2024-03-10 12:41:00 --> Output Class Initialized
INFO - 2024-03-10 12:41:00 --> Security Class Initialized
DEBUG - 2024-03-10 12:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:41:00 --> Input Class Initialized
INFO - 2024-03-10 12:41:00 --> Language Class Initialized
INFO - 2024-03-10 12:41:00 --> Loader Class Initialized
INFO - 2024-03-10 12:41:00 --> Helper loaded: url_helper
INFO - 2024-03-10 12:41:00 --> Helper loaded: file_helper
INFO - 2024-03-10 12:41:00 --> Helper loaded: form_helper
INFO - 2024-03-10 12:41:00 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:41:00 --> Controller Class Initialized
INFO - 2024-03-10 12:41:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 12:41:00 --> Final output sent to browser
DEBUG - 2024-03-10 12:41:00 --> Total execution time: 0.0193
ERROR - 2024-03-10 12:41:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:41:02 --> Config Class Initialized
INFO - 2024-03-10 12:41:02 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:41:02 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:41:02 --> Utf8 Class Initialized
INFO - 2024-03-10 12:41:02 --> URI Class Initialized
INFO - 2024-03-10 12:41:02 --> Router Class Initialized
INFO - 2024-03-10 12:41:02 --> Output Class Initialized
INFO - 2024-03-10 12:41:02 --> Security Class Initialized
DEBUG - 2024-03-10 12:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:41:02 --> Input Class Initialized
INFO - 2024-03-10 12:41:02 --> Language Class Initialized
INFO - 2024-03-10 12:41:02 --> Loader Class Initialized
INFO - 2024-03-10 12:41:02 --> Helper loaded: url_helper
INFO - 2024-03-10 12:41:02 --> Helper loaded: file_helper
INFO - 2024-03-10 12:41:02 --> Helper loaded: form_helper
INFO - 2024-03-10 12:41:02 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:41:02 --> Controller Class Initialized
INFO - 2024-03-10 12:41:02 --> Form Validation Class Initialized
INFO - 2024-03-10 12:41:02 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:41:02 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:41:02 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:41:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:41:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:41:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:41:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:41:02 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:41:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:41:02 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:41:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:41:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:41:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:41:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:41:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:41:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:41:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:41:02 --> Final output sent to browser
DEBUG - 2024-03-10 12:41:02 --> Total execution time: 0.0317
ERROR - 2024-03-10 12:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:41:28 --> Config Class Initialized
INFO - 2024-03-10 12:41:28 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:41:28 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:41:28 --> Utf8 Class Initialized
INFO - 2024-03-10 12:41:28 --> URI Class Initialized
INFO - 2024-03-10 12:41:28 --> Router Class Initialized
INFO - 2024-03-10 12:41:28 --> Output Class Initialized
INFO - 2024-03-10 12:41:28 --> Security Class Initialized
DEBUG - 2024-03-10 12:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:41:28 --> Input Class Initialized
INFO - 2024-03-10 12:41:28 --> Language Class Initialized
INFO - 2024-03-10 12:41:28 --> Loader Class Initialized
INFO - 2024-03-10 12:41:28 --> Helper loaded: url_helper
INFO - 2024-03-10 12:41:28 --> Helper loaded: file_helper
INFO - 2024-03-10 12:41:28 --> Helper loaded: form_helper
INFO - 2024-03-10 12:41:28 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:41:28 --> Controller Class Initialized
INFO - 2024-03-10 12:41:28 --> Form Validation Class Initialized
INFO - 2024-03-10 12:41:28 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:41:28 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:41:28 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:41:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:41:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:41:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:41:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:41:28 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:41:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:41:28 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:41:28 --> Final output sent to browser
DEBUG - 2024-03-10 12:41:28 --> Total execution time: 0.0376
ERROR - 2024-03-10 12:41:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:41:29 --> Config Class Initialized
INFO - 2024-03-10 12:41:29 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:41:29 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:41:29 --> Utf8 Class Initialized
INFO - 2024-03-10 12:41:29 --> URI Class Initialized
INFO - 2024-03-10 12:41:29 --> Router Class Initialized
INFO - 2024-03-10 12:41:29 --> Output Class Initialized
INFO - 2024-03-10 12:41:29 --> Security Class Initialized
DEBUG - 2024-03-10 12:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:41:29 --> Input Class Initialized
INFO - 2024-03-10 12:41:29 --> Language Class Initialized
INFO - 2024-03-10 12:41:29 --> Loader Class Initialized
INFO - 2024-03-10 12:41:29 --> Helper loaded: url_helper
INFO - 2024-03-10 12:41:29 --> Helper loaded: file_helper
INFO - 2024-03-10 12:41:29 --> Helper loaded: form_helper
INFO - 2024-03-10 12:41:29 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:41:29 --> Controller Class Initialized
INFO - 2024-03-10 12:41:29 --> Form Validation Class Initialized
INFO - 2024-03-10 12:41:29 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:41:29 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:41:29 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:41:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:41:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:41:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:41:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:41:29 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:41:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:41:29 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:41:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:41:30 --> Config Class Initialized
INFO - 2024-03-10 12:41:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:41:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:41:30 --> Utf8 Class Initialized
INFO - 2024-03-10 12:41:30 --> URI Class Initialized
INFO - 2024-03-10 12:41:30 --> Router Class Initialized
INFO - 2024-03-10 12:41:30 --> Output Class Initialized
INFO - 2024-03-10 12:41:30 --> Security Class Initialized
DEBUG - 2024-03-10 12:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:41:30 --> Input Class Initialized
INFO - 2024-03-10 12:41:30 --> Language Class Initialized
INFO - 2024-03-10 12:41:30 --> Loader Class Initialized
INFO - 2024-03-10 12:41:30 --> Helper loaded: url_helper
INFO - 2024-03-10 12:41:30 --> Helper loaded: file_helper
INFO - 2024-03-10 12:41:30 --> Helper loaded: form_helper
INFO - 2024-03-10 12:41:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:41:30 --> Controller Class Initialized
INFO - 2024-03-10 12:41:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 12:41:30 --> Final output sent to browser
DEBUG - 2024-03-10 12:41:30 --> Total execution time: 0.0144
ERROR - 2024-03-10 12:42:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:42:12 --> Config Class Initialized
INFO - 2024-03-10 12:42:12 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:42:12 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:42:12 --> Utf8 Class Initialized
INFO - 2024-03-10 12:42:12 --> URI Class Initialized
INFO - 2024-03-10 12:42:12 --> Router Class Initialized
INFO - 2024-03-10 12:42:12 --> Output Class Initialized
INFO - 2024-03-10 12:42:12 --> Security Class Initialized
DEBUG - 2024-03-10 12:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:42:12 --> Input Class Initialized
INFO - 2024-03-10 12:42:12 --> Language Class Initialized
INFO - 2024-03-10 12:42:12 --> Loader Class Initialized
INFO - 2024-03-10 12:42:12 --> Helper loaded: url_helper
INFO - 2024-03-10 12:42:12 --> Helper loaded: file_helper
INFO - 2024-03-10 12:42:12 --> Helper loaded: form_helper
INFO - 2024-03-10 12:42:12 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:42:12 --> Controller Class Initialized
INFO - 2024-03-10 12:42:12 --> Form Validation Class Initialized
INFO - 2024-03-10 12:42:12 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:42:12 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:42:12 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:42:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:42:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:42:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:42:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:42:12 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:42:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:42:12 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:42:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:42:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:42:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:42:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:42:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:42:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:42:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:42:12 --> Final output sent to browser
DEBUG - 2024-03-10 12:42:12 --> Total execution time: 0.0383
ERROR - 2024-03-10 12:42:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:42:12 --> Config Class Initialized
INFO - 2024-03-10 12:42:12 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:42:12 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:42:13 --> Utf8 Class Initialized
INFO - 2024-03-10 12:42:13 --> URI Class Initialized
INFO - 2024-03-10 12:42:13 --> Router Class Initialized
INFO - 2024-03-10 12:42:13 --> Output Class Initialized
INFO - 2024-03-10 12:42:13 --> Security Class Initialized
DEBUG - 2024-03-10 12:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:42:13 --> Input Class Initialized
INFO - 2024-03-10 12:42:13 --> Language Class Initialized
INFO - 2024-03-10 12:42:13 --> Loader Class Initialized
INFO - 2024-03-10 12:42:13 --> Helper loaded: url_helper
INFO - 2024-03-10 12:42:13 --> Helper loaded: file_helper
INFO - 2024-03-10 12:42:13 --> Helper loaded: form_helper
INFO - 2024-03-10 12:42:13 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:42:13 --> Controller Class Initialized
INFO - 2024-03-10 12:42:13 --> Form Validation Class Initialized
INFO - 2024-03-10 12:42:13 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:42:13 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:42:13 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:42:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:42:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:42:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:42:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:42:13 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:42:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:42:13 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:43:25 --> Config Class Initialized
INFO - 2024-03-10 12:43:25 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:43:25 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:43:25 --> Utf8 Class Initialized
INFO - 2024-03-10 12:43:25 --> URI Class Initialized
INFO - 2024-03-10 12:43:25 --> Router Class Initialized
INFO - 2024-03-10 12:43:25 --> Output Class Initialized
INFO - 2024-03-10 12:43:25 --> Security Class Initialized
DEBUG - 2024-03-10 12:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:43:25 --> Input Class Initialized
INFO - 2024-03-10 12:43:25 --> Language Class Initialized
INFO - 2024-03-10 12:43:25 --> Loader Class Initialized
INFO - 2024-03-10 12:43:25 --> Helper loaded: url_helper
INFO - 2024-03-10 12:43:25 --> Helper loaded: file_helper
INFO - 2024-03-10 12:43:25 --> Helper loaded: form_helper
INFO - 2024-03-10 12:43:25 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:43:25 --> Controller Class Initialized
INFO - 2024-03-10 12:43:25 --> Form Validation Class Initialized
INFO - 2024-03-10 12:43:25 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:43:25 --> Final output sent to browser
DEBUG - 2024-03-10 12:43:25 --> Total execution time: 0.0322
ERROR - 2024-03-10 12:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:43:25 --> Config Class Initialized
INFO - 2024-03-10 12:43:25 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:43:25 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:43:25 --> Utf8 Class Initialized
INFO - 2024-03-10 12:43:25 --> URI Class Initialized
INFO - 2024-03-10 12:43:25 --> Router Class Initialized
INFO - 2024-03-10 12:43:25 --> Output Class Initialized
INFO - 2024-03-10 12:43:25 --> Security Class Initialized
DEBUG - 2024-03-10 12:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:43:25 --> Input Class Initialized
INFO - 2024-03-10 12:43:25 --> Language Class Initialized
INFO - 2024-03-10 12:43:25 --> Loader Class Initialized
INFO - 2024-03-10 12:43:25 --> Helper loaded: url_helper
INFO - 2024-03-10 12:43:25 --> Helper loaded: file_helper
INFO - 2024-03-10 12:43:25 --> Helper loaded: form_helper
INFO - 2024-03-10 12:43:25 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:43:25 --> Controller Class Initialized
INFO - 2024-03-10 12:43:25 --> Form Validation Class Initialized
INFO - 2024-03-10 12:43:25 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:43:25 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:44:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:44:45 --> Config Class Initialized
INFO - 2024-03-10 12:44:45 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:44:45 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:44:45 --> Utf8 Class Initialized
INFO - 2024-03-10 12:44:45 --> URI Class Initialized
INFO - 2024-03-10 12:44:45 --> Router Class Initialized
INFO - 2024-03-10 12:44:45 --> Output Class Initialized
INFO - 2024-03-10 12:44:45 --> Security Class Initialized
DEBUG - 2024-03-10 12:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:44:45 --> Input Class Initialized
INFO - 2024-03-10 12:44:45 --> Language Class Initialized
INFO - 2024-03-10 12:44:45 --> Loader Class Initialized
INFO - 2024-03-10 12:44:45 --> Helper loaded: url_helper
INFO - 2024-03-10 12:44:45 --> Helper loaded: file_helper
INFO - 2024-03-10 12:44:45 --> Helper loaded: form_helper
INFO - 2024-03-10 12:44:45 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:44:45 --> Controller Class Initialized
INFO - 2024-03-10 12:44:45 --> Form Validation Class Initialized
INFO - 2024-03-10 12:44:45 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:44:45 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:44:45 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:44:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:44:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:44:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:44:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:44:45 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:44:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:44:45 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:44:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:44:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:44:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:44:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:44:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:44:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:44:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:44:45 --> Final output sent to browser
DEBUG - 2024-03-10 12:44:45 --> Total execution time: 0.0457
ERROR - 2024-03-10 12:44:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:44:46 --> Config Class Initialized
INFO - 2024-03-10 12:44:46 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:44:46 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:44:46 --> Utf8 Class Initialized
INFO - 2024-03-10 12:44:46 --> URI Class Initialized
INFO - 2024-03-10 12:44:46 --> Router Class Initialized
INFO - 2024-03-10 12:44:46 --> Output Class Initialized
INFO - 2024-03-10 12:44:46 --> Security Class Initialized
DEBUG - 2024-03-10 12:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:44:46 --> Input Class Initialized
INFO - 2024-03-10 12:44:46 --> Language Class Initialized
INFO - 2024-03-10 12:44:46 --> Loader Class Initialized
INFO - 2024-03-10 12:44:46 --> Helper loaded: url_helper
INFO - 2024-03-10 12:44:46 --> Helper loaded: file_helper
INFO - 2024-03-10 12:44:46 --> Helper loaded: form_helper
INFO - 2024-03-10 12:44:46 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:44:46 --> Controller Class Initialized
INFO - 2024-03-10 12:44:46 --> Form Validation Class Initialized
INFO - 2024-03-10 12:44:46 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:44:46 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:44:46 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:44:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:44:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:44:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:44:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:44:46 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:44:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:44:46 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:45:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:45:24 --> Config Class Initialized
INFO - 2024-03-10 12:45:24 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:45:24 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:45:24 --> Utf8 Class Initialized
INFO - 2024-03-10 12:45:24 --> URI Class Initialized
INFO - 2024-03-10 12:45:24 --> Router Class Initialized
INFO - 2024-03-10 12:45:24 --> Output Class Initialized
INFO - 2024-03-10 12:45:24 --> Security Class Initialized
DEBUG - 2024-03-10 12:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:45:24 --> Input Class Initialized
INFO - 2024-03-10 12:45:24 --> Language Class Initialized
INFO - 2024-03-10 12:45:24 --> Loader Class Initialized
INFO - 2024-03-10 12:45:24 --> Helper loaded: url_helper
INFO - 2024-03-10 12:45:24 --> Helper loaded: file_helper
INFO - 2024-03-10 12:45:24 --> Helper loaded: form_helper
INFO - 2024-03-10 12:45:24 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:45:24 --> Controller Class Initialized
INFO - 2024-03-10 12:45:24 --> Form Validation Class Initialized
INFO - 2024-03-10 12:45:24 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:45:24 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:45:24 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:45:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:45:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:45:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:45:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:45:24 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:45:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:45:24 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:45:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:45:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:45:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:45:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:45:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:45:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:45:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:45:24 --> Final output sent to browser
DEBUG - 2024-03-10 12:45:24 --> Total execution time: 0.0316
ERROR - 2024-03-10 12:45:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:45:25 --> Config Class Initialized
INFO - 2024-03-10 12:45:25 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:45:25 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:45:25 --> Utf8 Class Initialized
INFO - 2024-03-10 12:45:25 --> URI Class Initialized
INFO - 2024-03-10 12:45:25 --> Router Class Initialized
INFO - 2024-03-10 12:45:25 --> Output Class Initialized
INFO - 2024-03-10 12:45:25 --> Security Class Initialized
DEBUG - 2024-03-10 12:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:45:25 --> Input Class Initialized
INFO - 2024-03-10 12:45:25 --> Language Class Initialized
INFO - 2024-03-10 12:45:25 --> Loader Class Initialized
INFO - 2024-03-10 12:45:25 --> Helper loaded: url_helper
INFO - 2024-03-10 12:45:25 --> Helper loaded: file_helper
INFO - 2024-03-10 12:45:25 --> Helper loaded: form_helper
INFO - 2024-03-10 12:45:25 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:45:25 --> Controller Class Initialized
INFO - 2024-03-10 12:45:25 --> Form Validation Class Initialized
INFO - 2024-03-10 12:45:25 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:45:25 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:45:25 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:45:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:45:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:45:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:45:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:45:25 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:45:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:45:25 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:45:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:45:50 --> Config Class Initialized
INFO - 2024-03-10 12:45:50 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:45:50 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:45:50 --> Utf8 Class Initialized
INFO - 2024-03-10 12:45:50 --> URI Class Initialized
INFO - 2024-03-10 12:45:50 --> Router Class Initialized
INFO - 2024-03-10 12:45:50 --> Output Class Initialized
INFO - 2024-03-10 12:45:50 --> Security Class Initialized
DEBUG - 2024-03-10 12:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:45:50 --> Input Class Initialized
INFO - 2024-03-10 12:45:50 --> Language Class Initialized
INFO - 2024-03-10 12:45:50 --> Loader Class Initialized
INFO - 2024-03-10 12:45:50 --> Helper loaded: url_helper
INFO - 2024-03-10 12:45:50 --> Helper loaded: file_helper
INFO - 2024-03-10 12:45:50 --> Helper loaded: form_helper
INFO - 2024-03-10 12:45:50 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:45:50 --> Controller Class Initialized
INFO - 2024-03-10 12:45:50 --> Form Validation Class Initialized
INFO - 2024-03-10 12:45:50 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:45:50 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:45:50 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:45:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:45:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:45:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:45:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:45:50 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:45:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:45:50 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:45:50 --> Final output sent to browser
DEBUG - 2024-03-10 12:45:50 --> Total execution time: 0.0404
ERROR - 2024-03-10 12:45:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:45:51 --> Config Class Initialized
INFO - 2024-03-10 12:45:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:45:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:45:51 --> Utf8 Class Initialized
INFO - 2024-03-10 12:45:51 --> URI Class Initialized
INFO - 2024-03-10 12:45:51 --> Router Class Initialized
INFO - 2024-03-10 12:45:51 --> Output Class Initialized
INFO - 2024-03-10 12:45:51 --> Security Class Initialized
DEBUG - 2024-03-10 12:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:45:51 --> Input Class Initialized
INFO - 2024-03-10 12:45:51 --> Language Class Initialized
INFO - 2024-03-10 12:45:51 --> Loader Class Initialized
INFO - 2024-03-10 12:45:51 --> Helper loaded: url_helper
INFO - 2024-03-10 12:45:51 --> Helper loaded: file_helper
INFO - 2024-03-10 12:45:51 --> Helper loaded: form_helper
INFO - 2024-03-10 12:45:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:45:51 --> Controller Class Initialized
INFO - 2024-03-10 12:45:51 --> Form Validation Class Initialized
INFO - 2024-03-10 12:45:51 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:45:51 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:45:51 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:45:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:45:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:45:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:45:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:45:51 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:45:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:45:51 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:45:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:45:53 --> Config Class Initialized
INFO - 2024-03-10 12:45:53 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:45:53 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:45:53 --> Utf8 Class Initialized
INFO - 2024-03-10 12:45:53 --> URI Class Initialized
INFO - 2024-03-10 12:45:53 --> Router Class Initialized
INFO - 2024-03-10 12:45:53 --> Output Class Initialized
INFO - 2024-03-10 12:45:53 --> Security Class Initialized
DEBUG - 2024-03-10 12:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:45:53 --> Input Class Initialized
INFO - 2024-03-10 12:45:53 --> Language Class Initialized
INFO - 2024-03-10 12:45:53 --> Loader Class Initialized
INFO - 2024-03-10 12:45:53 --> Helper loaded: url_helper
INFO - 2024-03-10 12:45:53 --> Helper loaded: file_helper
INFO - 2024-03-10 12:45:53 --> Helper loaded: form_helper
INFO - 2024-03-10 12:45:53 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:45:53 --> Controller Class Initialized
INFO - 2024-03-10 12:45:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 12:45:53 --> Final output sent to browser
DEBUG - 2024-03-10 12:45:53 --> Total execution time: 0.0200
ERROR - 2024-03-10 12:46:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:46:57 --> Config Class Initialized
INFO - 2024-03-10 12:46:57 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:46:57 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:46:57 --> Utf8 Class Initialized
INFO - 2024-03-10 12:46:57 --> URI Class Initialized
INFO - 2024-03-10 12:46:57 --> Router Class Initialized
INFO - 2024-03-10 12:46:57 --> Output Class Initialized
INFO - 2024-03-10 12:46:57 --> Security Class Initialized
DEBUG - 2024-03-10 12:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:46:57 --> Input Class Initialized
INFO - 2024-03-10 12:46:57 --> Language Class Initialized
INFO - 2024-03-10 12:46:57 --> Loader Class Initialized
INFO - 2024-03-10 12:46:57 --> Helper loaded: url_helper
INFO - 2024-03-10 12:46:57 --> Helper loaded: file_helper
INFO - 2024-03-10 12:46:57 --> Helper loaded: form_helper
INFO - 2024-03-10 12:46:57 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:46:57 --> Controller Class Initialized
INFO - 2024-03-10 12:46:57 --> Form Validation Class Initialized
INFO - 2024-03-10 12:46:57 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:46:57 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:46:57 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:46:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:46:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:46:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:46:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:46:57 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:46:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:46:57 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:46:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:46:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:46:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:46:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:46:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:46:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:46:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:46:57 --> Final output sent to browser
DEBUG - 2024-03-10 12:46:57 --> Total execution time: 0.0311
ERROR - 2024-03-10 12:46:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:46:58 --> Config Class Initialized
INFO - 2024-03-10 12:46:58 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:46:58 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:46:58 --> Utf8 Class Initialized
INFO - 2024-03-10 12:46:58 --> URI Class Initialized
INFO - 2024-03-10 12:46:58 --> Router Class Initialized
INFO - 2024-03-10 12:46:58 --> Output Class Initialized
INFO - 2024-03-10 12:46:58 --> Security Class Initialized
DEBUG - 2024-03-10 12:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:46:58 --> Input Class Initialized
INFO - 2024-03-10 12:46:58 --> Language Class Initialized
INFO - 2024-03-10 12:46:58 --> Loader Class Initialized
INFO - 2024-03-10 12:46:58 --> Helper loaded: url_helper
INFO - 2024-03-10 12:46:58 --> Helper loaded: file_helper
INFO - 2024-03-10 12:46:58 --> Helper loaded: form_helper
INFO - 2024-03-10 12:46:58 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:46:58 --> Controller Class Initialized
INFO - 2024-03-10 12:46:58 --> Form Validation Class Initialized
INFO - 2024-03-10 12:46:58 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:46:58 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:46:58 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:46:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:46:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:46:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:46:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:46:58 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:46:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:46:58 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:47:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:47:07 --> Config Class Initialized
INFO - 2024-03-10 12:47:07 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:47:07 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:47:07 --> Utf8 Class Initialized
INFO - 2024-03-10 12:47:07 --> URI Class Initialized
INFO - 2024-03-10 12:47:07 --> Router Class Initialized
INFO - 2024-03-10 12:47:07 --> Output Class Initialized
INFO - 2024-03-10 12:47:07 --> Security Class Initialized
DEBUG - 2024-03-10 12:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:47:07 --> Input Class Initialized
INFO - 2024-03-10 12:47:07 --> Language Class Initialized
INFO - 2024-03-10 12:47:07 --> Loader Class Initialized
INFO - 2024-03-10 12:47:07 --> Helper loaded: url_helper
INFO - 2024-03-10 12:47:07 --> Helper loaded: file_helper
INFO - 2024-03-10 12:47:07 --> Helper loaded: form_helper
INFO - 2024-03-10 12:47:07 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:47:07 --> Controller Class Initialized
INFO - 2024-03-10 12:47:07 --> Form Validation Class Initialized
INFO - 2024-03-10 12:47:07 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:47:07 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:47:07 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:47:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:47:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:47:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:47:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:47:07 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:47:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:47:07 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:47:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:47:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:47:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:47:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:47:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:47:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:47:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:47:07 --> Final output sent to browser
DEBUG - 2024-03-10 12:47:07 --> Total execution time: 0.0272
ERROR - 2024-03-10 12:47:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:47:08 --> Config Class Initialized
INFO - 2024-03-10 12:47:08 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:47:08 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:47:08 --> Utf8 Class Initialized
INFO - 2024-03-10 12:47:08 --> URI Class Initialized
INFO - 2024-03-10 12:47:08 --> Router Class Initialized
INFO - 2024-03-10 12:47:08 --> Output Class Initialized
INFO - 2024-03-10 12:47:08 --> Security Class Initialized
DEBUG - 2024-03-10 12:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:47:08 --> Input Class Initialized
INFO - 2024-03-10 12:47:08 --> Language Class Initialized
INFO - 2024-03-10 12:47:08 --> Loader Class Initialized
INFO - 2024-03-10 12:47:08 --> Helper loaded: url_helper
INFO - 2024-03-10 12:47:08 --> Helper loaded: file_helper
INFO - 2024-03-10 12:47:08 --> Helper loaded: form_helper
INFO - 2024-03-10 12:47:08 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:47:08 --> Controller Class Initialized
INFO - 2024-03-10 12:47:08 --> Form Validation Class Initialized
INFO - 2024-03-10 12:47:08 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:47:08 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:47:08 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:47:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:47:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:47:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:47:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:47:08 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:47:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:47:08 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:48:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:48:32 --> Config Class Initialized
INFO - 2024-03-10 12:48:32 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:48:32 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:48:32 --> Utf8 Class Initialized
INFO - 2024-03-10 12:48:32 --> URI Class Initialized
INFO - 2024-03-10 12:48:32 --> Router Class Initialized
INFO - 2024-03-10 12:48:32 --> Output Class Initialized
INFO - 2024-03-10 12:48:32 --> Security Class Initialized
DEBUG - 2024-03-10 12:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:48:32 --> Input Class Initialized
INFO - 2024-03-10 12:48:32 --> Language Class Initialized
INFO - 2024-03-10 12:48:32 --> Loader Class Initialized
INFO - 2024-03-10 12:48:32 --> Helper loaded: url_helper
INFO - 2024-03-10 12:48:33 --> Helper loaded: file_helper
INFO - 2024-03-10 12:48:33 --> Helper loaded: form_helper
INFO - 2024-03-10 12:48:33 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:48:33 --> Controller Class Initialized
INFO - 2024-03-10 12:48:33 --> Form Validation Class Initialized
INFO - 2024-03-10 12:48:33 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:48:33 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:48:33 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:48:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:48:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:48:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:48:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:48:33 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:48:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:48:33 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:48:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:48:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:48:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:48:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:48:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:48:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:48:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:48:33 --> Final output sent to browser
DEBUG - 2024-03-10 12:48:33 --> Total execution time: 0.0458
ERROR - 2024-03-10 12:48:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:48:35 --> Config Class Initialized
INFO - 2024-03-10 12:48:35 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:48:35 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:48:35 --> Utf8 Class Initialized
INFO - 2024-03-10 12:48:35 --> URI Class Initialized
INFO - 2024-03-10 12:48:35 --> Router Class Initialized
INFO - 2024-03-10 12:48:35 --> Output Class Initialized
INFO - 2024-03-10 12:48:35 --> Security Class Initialized
DEBUG - 2024-03-10 12:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:48:35 --> Input Class Initialized
INFO - 2024-03-10 12:48:35 --> Language Class Initialized
INFO - 2024-03-10 12:48:35 --> Loader Class Initialized
INFO - 2024-03-10 12:48:35 --> Helper loaded: url_helper
INFO - 2024-03-10 12:48:35 --> Helper loaded: file_helper
INFO - 2024-03-10 12:48:35 --> Helper loaded: form_helper
INFO - 2024-03-10 12:48:35 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:48:35 --> Controller Class Initialized
INFO - 2024-03-10 12:48:35 --> Form Validation Class Initialized
INFO - 2024-03-10 12:48:35 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:48:35 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:48:35 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:48:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:48:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:48:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:48:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:48:35 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:48:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:48:35 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:51:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:51:15 --> Config Class Initialized
INFO - 2024-03-10 12:51:15 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:51:15 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:51:15 --> Utf8 Class Initialized
INFO - 2024-03-10 12:51:15 --> URI Class Initialized
INFO - 2024-03-10 12:51:15 --> Router Class Initialized
INFO - 2024-03-10 12:51:15 --> Output Class Initialized
INFO - 2024-03-10 12:51:15 --> Security Class Initialized
DEBUG - 2024-03-10 12:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:51:15 --> Input Class Initialized
INFO - 2024-03-10 12:51:15 --> Language Class Initialized
INFO - 2024-03-10 12:51:15 --> Loader Class Initialized
INFO - 2024-03-10 12:51:15 --> Helper loaded: url_helper
INFO - 2024-03-10 12:51:15 --> Helper loaded: file_helper
INFO - 2024-03-10 12:51:15 --> Helper loaded: form_helper
INFO - 2024-03-10 12:51:15 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:51:15 --> Controller Class Initialized
INFO - 2024-03-10 12:51:15 --> Form Validation Class Initialized
INFO - 2024-03-10 12:51:15 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:51:15 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:51:15 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:51:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:51:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:51:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:51:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:51:15 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:51:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:51:15 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:51:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:51:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:51:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:51:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:51:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:51:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:51:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:51:15 --> Final output sent to browser
DEBUG - 2024-03-10 12:51:15 --> Total execution time: 0.0328
ERROR - 2024-03-10 12:53:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:53:37 --> Config Class Initialized
INFO - 2024-03-10 12:53:37 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:53:37 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:53:37 --> Utf8 Class Initialized
INFO - 2024-03-10 12:53:37 --> URI Class Initialized
INFO - 2024-03-10 12:53:37 --> Router Class Initialized
INFO - 2024-03-10 12:53:37 --> Output Class Initialized
INFO - 2024-03-10 12:53:37 --> Security Class Initialized
DEBUG - 2024-03-10 12:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:53:37 --> Input Class Initialized
INFO - 2024-03-10 12:53:37 --> Language Class Initialized
INFO - 2024-03-10 12:53:37 --> Loader Class Initialized
INFO - 2024-03-10 12:53:37 --> Helper loaded: url_helper
INFO - 2024-03-10 12:53:37 --> Helper loaded: file_helper
INFO - 2024-03-10 12:53:37 --> Helper loaded: form_helper
INFO - 2024-03-10 12:53:37 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:53:37 --> Controller Class Initialized
INFO - 2024-03-10 12:53:37 --> Form Validation Class Initialized
INFO - 2024-03-10 12:53:37 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:53:37 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:53:37 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:53:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:53:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:53:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:53:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:53:37 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:53:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:53:37 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:53:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:53:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:53:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:53:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:53:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:53:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:53:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:53:37 --> Final output sent to browser
DEBUG - 2024-03-10 12:53:37 --> Total execution time: 0.0345
ERROR - 2024-03-10 12:53:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:53:38 --> Config Class Initialized
INFO - 2024-03-10 12:53:38 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:53:38 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:53:38 --> Utf8 Class Initialized
INFO - 2024-03-10 12:53:38 --> URI Class Initialized
INFO - 2024-03-10 12:53:38 --> Router Class Initialized
INFO - 2024-03-10 12:53:38 --> Output Class Initialized
INFO - 2024-03-10 12:53:38 --> Security Class Initialized
DEBUG - 2024-03-10 12:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:53:38 --> Input Class Initialized
INFO - 2024-03-10 12:53:38 --> Language Class Initialized
INFO - 2024-03-10 12:53:38 --> Loader Class Initialized
INFO - 2024-03-10 12:53:38 --> Helper loaded: url_helper
INFO - 2024-03-10 12:53:38 --> Helper loaded: file_helper
INFO - 2024-03-10 12:53:38 --> Helper loaded: form_helper
INFO - 2024-03-10 12:53:38 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:53:38 --> Controller Class Initialized
INFO - 2024-03-10 12:53:39 --> Form Validation Class Initialized
INFO - 2024-03-10 12:53:39 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:53:39 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:53:39 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:53:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:53:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:53:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:53:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:53:39 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:53:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:53:39 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:54:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:54:00 --> Config Class Initialized
INFO - 2024-03-10 12:54:00 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:54:00 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:54:00 --> Utf8 Class Initialized
INFO - 2024-03-10 12:54:00 --> URI Class Initialized
INFO - 2024-03-10 12:54:00 --> Router Class Initialized
INFO - 2024-03-10 12:54:00 --> Output Class Initialized
INFO - 2024-03-10 12:54:00 --> Security Class Initialized
DEBUG - 2024-03-10 12:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:54:00 --> Input Class Initialized
INFO - 2024-03-10 12:54:00 --> Language Class Initialized
INFO - 2024-03-10 12:54:00 --> Loader Class Initialized
INFO - 2024-03-10 12:54:00 --> Helper loaded: url_helper
INFO - 2024-03-10 12:54:00 --> Helper loaded: file_helper
INFO - 2024-03-10 12:54:00 --> Helper loaded: form_helper
INFO - 2024-03-10 12:54:00 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:54:00 --> Controller Class Initialized
INFO - 2024-03-10 12:54:00 --> Form Validation Class Initialized
INFO - 2024-03-10 12:54:00 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:54:00 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:54:00 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:54:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:54:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:54:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:54:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:54:00 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:54:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:54:00 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:54:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:54:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:54:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:54:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:54:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:54:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:54:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:54:00 --> Final output sent to browser
DEBUG - 2024-03-10 12:54:00 --> Total execution time: 0.0333
ERROR - 2024-03-10 12:55:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:55:01 --> Config Class Initialized
INFO - 2024-03-10 12:55:01 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:55:01 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:55:01 --> Utf8 Class Initialized
INFO - 2024-03-10 12:55:01 --> URI Class Initialized
INFO - 2024-03-10 12:55:01 --> Router Class Initialized
INFO - 2024-03-10 12:55:01 --> Output Class Initialized
INFO - 2024-03-10 12:55:01 --> Security Class Initialized
DEBUG - 2024-03-10 12:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:55:01 --> Input Class Initialized
INFO - 2024-03-10 12:55:01 --> Language Class Initialized
INFO - 2024-03-10 12:55:01 --> Loader Class Initialized
INFO - 2024-03-10 12:55:01 --> Helper loaded: url_helper
INFO - 2024-03-10 12:55:01 --> Helper loaded: file_helper
INFO - 2024-03-10 12:55:01 --> Helper loaded: form_helper
INFO - 2024-03-10 12:55:01 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:55:01 --> Controller Class Initialized
INFO - 2024-03-10 12:55:01 --> Form Validation Class Initialized
INFO - 2024-03-10 12:55:01 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:55:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:55:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:55:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:55:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:55:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:55:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:55:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:55:01 --> Final output sent to browser
DEBUG - 2024-03-10 12:55:01 --> Total execution time: 0.0321
ERROR - 2024-03-10 12:55:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:55:01 --> Config Class Initialized
INFO - 2024-03-10 12:55:01 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:55:01 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:55:01 --> Utf8 Class Initialized
INFO - 2024-03-10 12:55:01 --> URI Class Initialized
INFO - 2024-03-10 12:55:01 --> Router Class Initialized
INFO - 2024-03-10 12:55:01 --> Output Class Initialized
INFO - 2024-03-10 12:55:01 --> Security Class Initialized
DEBUG - 2024-03-10 12:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:55:01 --> Input Class Initialized
INFO - 2024-03-10 12:55:01 --> Language Class Initialized
INFO - 2024-03-10 12:55:01 --> Loader Class Initialized
INFO - 2024-03-10 12:55:01 --> Helper loaded: url_helper
INFO - 2024-03-10 12:55:01 --> Helper loaded: file_helper
INFO - 2024-03-10 12:55:01 --> Helper loaded: form_helper
INFO - 2024-03-10 12:55:01 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:55:01 --> Controller Class Initialized
INFO - 2024-03-10 12:55:01 --> Form Validation Class Initialized
INFO - 2024-03-10 12:55:01 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:55:01 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:56:50 --> Config Class Initialized
INFO - 2024-03-10 12:56:50 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:56:50 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:56:50 --> Utf8 Class Initialized
INFO - 2024-03-10 12:56:50 --> URI Class Initialized
INFO - 2024-03-10 12:56:50 --> Router Class Initialized
INFO - 2024-03-10 12:56:50 --> Output Class Initialized
INFO - 2024-03-10 12:56:50 --> Security Class Initialized
DEBUG - 2024-03-10 12:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:56:50 --> Input Class Initialized
INFO - 2024-03-10 12:56:50 --> Language Class Initialized
INFO - 2024-03-10 12:56:50 --> Loader Class Initialized
INFO - 2024-03-10 12:56:50 --> Helper loaded: url_helper
INFO - 2024-03-10 12:56:50 --> Helper loaded: file_helper
INFO - 2024-03-10 12:56:50 --> Helper loaded: form_helper
INFO - 2024-03-10 12:56:50 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:56:50 --> Controller Class Initialized
INFO - 2024-03-10 12:56:50 --> Form Validation Class Initialized
INFO - 2024-03-10 12:56:50 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:56:50 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:56:50 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:56:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:56:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:56:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:56:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:56:50 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:56:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:56:50 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:56:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:56:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:56:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:56:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:56:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:56:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:56:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:56:50 --> Final output sent to browser
DEBUG - 2024-03-10 12:56:50 --> Total execution time: 0.0374
ERROR - 2024-03-10 12:56:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:56:53 --> Config Class Initialized
INFO - 2024-03-10 12:56:53 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:56:53 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:56:53 --> Utf8 Class Initialized
INFO - 2024-03-10 12:56:53 --> URI Class Initialized
INFO - 2024-03-10 12:56:53 --> Router Class Initialized
INFO - 2024-03-10 12:56:53 --> Output Class Initialized
INFO - 2024-03-10 12:56:53 --> Security Class Initialized
DEBUG - 2024-03-10 12:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:56:53 --> Input Class Initialized
INFO - 2024-03-10 12:56:53 --> Language Class Initialized
INFO - 2024-03-10 12:56:53 --> Loader Class Initialized
INFO - 2024-03-10 12:56:53 --> Helper loaded: url_helper
INFO - 2024-03-10 12:56:53 --> Helper loaded: file_helper
INFO - 2024-03-10 12:56:53 --> Helper loaded: form_helper
INFO - 2024-03-10 12:56:53 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:56:53 --> Controller Class Initialized
INFO - 2024-03-10 12:56:53 --> Form Validation Class Initialized
INFO - 2024-03-10 12:56:53 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:56:53 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:56:53 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:56:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:56:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:56:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:56:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:56:53 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:56:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:56:53 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:56:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:56:59 --> Config Class Initialized
INFO - 2024-03-10 12:56:59 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:56:59 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:56:59 --> Utf8 Class Initialized
INFO - 2024-03-10 12:56:59 --> URI Class Initialized
INFO - 2024-03-10 12:56:59 --> Router Class Initialized
INFO - 2024-03-10 12:56:59 --> Output Class Initialized
INFO - 2024-03-10 12:56:59 --> Security Class Initialized
DEBUG - 2024-03-10 12:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:56:59 --> Input Class Initialized
INFO - 2024-03-10 12:56:59 --> Language Class Initialized
INFO - 2024-03-10 12:56:59 --> Loader Class Initialized
INFO - 2024-03-10 12:56:59 --> Helper loaded: url_helper
INFO - 2024-03-10 12:56:59 --> Helper loaded: file_helper
INFO - 2024-03-10 12:56:59 --> Helper loaded: form_helper
INFO - 2024-03-10 12:56:59 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:56:59 --> Controller Class Initialized
INFO - 2024-03-10 12:56:59 --> Form Validation Class Initialized
INFO - 2024-03-10 12:56:59 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:56:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:56:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:56:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:56:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:56:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:56:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 12:56:59 --> Final output sent to browser
DEBUG - 2024-03-10 12:56:59 --> Total execution time: 0.0387
ERROR - 2024-03-10 12:56:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:56:59 --> Config Class Initialized
INFO - 2024-03-10 12:56:59 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:56:59 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:56:59 --> Utf8 Class Initialized
INFO - 2024-03-10 12:56:59 --> URI Class Initialized
INFO - 2024-03-10 12:56:59 --> Router Class Initialized
INFO - 2024-03-10 12:56:59 --> Output Class Initialized
INFO - 2024-03-10 12:56:59 --> Security Class Initialized
DEBUG - 2024-03-10 12:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:56:59 --> Input Class Initialized
INFO - 2024-03-10 12:56:59 --> Language Class Initialized
INFO - 2024-03-10 12:56:59 --> Loader Class Initialized
INFO - 2024-03-10 12:56:59 --> Helper loaded: url_helper
INFO - 2024-03-10 12:56:59 --> Helper loaded: file_helper
INFO - 2024-03-10 12:56:59 --> Helper loaded: form_helper
INFO - 2024-03-10 12:56:59 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:56:59 --> Controller Class Initialized
INFO - 2024-03-10 12:56:59 --> Form Validation Class Initialized
INFO - 2024-03-10 12:56:59 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:56:59 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:57:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:57:01 --> Config Class Initialized
INFO - 2024-03-10 12:57:01 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:57:01 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:57:01 --> Utf8 Class Initialized
INFO - 2024-03-10 12:57:01 --> URI Class Initialized
INFO - 2024-03-10 12:57:01 --> Router Class Initialized
INFO - 2024-03-10 12:57:01 --> Output Class Initialized
INFO - 2024-03-10 12:57:01 --> Security Class Initialized
DEBUG - 2024-03-10 12:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:57:01 --> Input Class Initialized
INFO - 2024-03-10 12:57:01 --> Language Class Initialized
INFO - 2024-03-10 12:57:01 --> Loader Class Initialized
INFO - 2024-03-10 12:57:01 --> Helper loaded: url_helper
INFO - 2024-03-10 12:57:01 --> Helper loaded: file_helper
INFO - 2024-03-10 12:57:01 --> Helper loaded: form_helper
INFO - 2024-03-10 12:57:01 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:57:01 --> Controller Class Initialized
INFO - 2024-03-10 12:57:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 12:57:01 --> Final output sent to browser
DEBUG - 2024-03-10 12:57:01 --> Total execution time: 0.0277
ERROR - 2024-03-10 12:57:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:57:03 --> Config Class Initialized
INFO - 2024-03-10 12:57:03 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:57:03 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:57:03 --> Utf8 Class Initialized
INFO - 2024-03-10 12:57:03 --> URI Class Initialized
INFO - 2024-03-10 12:57:03 --> Router Class Initialized
INFO - 2024-03-10 12:57:03 --> Output Class Initialized
INFO - 2024-03-10 12:57:03 --> Security Class Initialized
DEBUG - 2024-03-10 12:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:57:03 --> Input Class Initialized
INFO - 2024-03-10 12:57:03 --> Language Class Initialized
INFO - 2024-03-10 12:57:03 --> Loader Class Initialized
INFO - 2024-03-10 12:57:03 --> Helper loaded: url_helper
INFO - 2024-03-10 12:57:03 --> Helper loaded: file_helper
INFO - 2024-03-10 12:57:03 --> Helper loaded: form_helper
INFO - 2024-03-10 12:57:03 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:57:03 --> Controller Class Initialized
INFO - 2024-03-10 12:57:03 --> Form Validation Class Initialized
INFO - 2024-03-10 12:57:03 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:57:03 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:57:03 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:57:03 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:57:03 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:57:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:57:03 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:57:03 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:57:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:57:03 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:57:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:57:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:57:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:57:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:57:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:57:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:57:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:57:03 --> Final output sent to browser
DEBUG - 2024-03-10 12:57:03 --> Total execution time: 0.0294
ERROR - 2024-03-10 12:57:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:57:03 --> Config Class Initialized
INFO - 2024-03-10 12:57:03 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:57:03 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:57:03 --> Utf8 Class Initialized
INFO - 2024-03-10 12:57:03 --> URI Class Initialized
INFO - 2024-03-10 12:57:03 --> Router Class Initialized
INFO - 2024-03-10 12:57:03 --> Output Class Initialized
INFO - 2024-03-10 12:57:03 --> Security Class Initialized
DEBUG - 2024-03-10 12:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:57:03 --> Input Class Initialized
INFO - 2024-03-10 12:57:03 --> Language Class Initialized
INFO - 2024-03-10 12:57:03 --> Loader Class Initialized
INFO - 2024-03-10 12:57:03 --> Helper loaded: url_helper
INFO - 2024-03-10 12:57:03 --> Helper loaded: file_helper
INFO - 2024-03-10 12:57:03 --> Helper loaded: form_helper
INFO - 2024-03-10 12:57:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:57:04 --> Controller Class Initialized
INFO - 2024-03-10 12:57:04 --> Form Validation Class Initialized
INFO - 2024-03-10 12:57:04 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:57:04 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:57:04 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:57:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:57:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:57:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:57:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:57:04 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:57:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:57:04 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:57:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:57:05 --> Config Class Initialized
INFO - 2024-03-10 12:57:05 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:57:05 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:57:05 --> Utf8 Class Initialized
INFO - 2024-03-10 12:57:05 --> URI Class Initialized
INFO - 2024-03-10 12:57:05 --> Router Class Initialized
INFO - 2024-03-10 12:57:05 --> Output Class Initialized
INFO - 2024-03-10 12:57:05 --> Security Class Initialized
DEBUG - 2024-03-10 12:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:57:05 --> Input Class Initialized
INFO - 2024-03-10 12:57:05 --> Language Class Initialized
INFO - 2024-03-10 12:57:05 --> Loader Class Initialized
INFO - 2024-03-10 12:57:05 --> Helper loaded: url_helper
INFO - 2024-03-10 12:57:05 --> Helper loaded: file_helper
INFO - 2024-03-10 12:57:05 --> Helper loaded: form_helper
INFO - 2024-03-10 12:57:05 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:57:05 --> Controller Class Initialized
INFO - 2024-03-10 12:57:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 12:57:05 --> Final output sent to browser
DEBUG - 2024-03-10 12:57:05 --> Total execution time: 0.0182
ERROR - 2024-03-10 12:57:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:57:21 --> Config Class Initialized
INFO - 2024-03-10 12:57:21 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:57:21 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:57:21 --> Utf8 Class Initialized
INFO - 2024-03-10 12:57:21 --> URI Class Initialized
INFO - 2024-03-10 12:57:21 --> Router Class Initialized
INFO - 2024-03-10 12:57:21 --> Output Class Initialized
INFO - 2024-03-10 12:57:21 --> Security Class Initialized
DEBUG - 2024-03-10 12:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:57:21 --> Input Class Initialized
INFO - 2024-03-10 12:57:21 --> Language Class Initialized
INFO - 2024-03-10 12:57:21 --> Loader Class Initialized
INFO - 2024-03-10 12:57:21 --> Helper loaded: url_helper
INFO - 2024-03-10 12:57:21 --> Helper loaded: file_helper
INFO - 2024-03-10 12:57:21 --> Helper loaded: form_helper
INFO - 2024-03-10 12:57:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:57:21 --> Controller Class Initialized
INFO - 2024-03-10 12:57:21 --> Form Validation Class Initialized
INFO - 2024-03-10 12:57:21 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:57:21 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:57:21 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:57:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:57:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:57:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:57:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:57:21 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:57:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:57:21 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:57:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:57:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:57:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:57:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:57:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:57:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:57:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:57:21 --> Final output sent to browser
DEBUG - 2024-03-10 12:57:21 --> Total execution time: 0.0363
ERROR - 2024-03-10 12:59:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:59:45 --> Config Class Initialized
INFO - 2024-03-10 12:59:45 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:59:45 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:59:45 --> Utf8 Class Initialized
INFO - 2024-03-10 12:59:45 --> URI Class Initialized
INFO - 2024-03-10 12:59:45 --> Router Class Initialized
INFO - 2024-03-10 12:59:45 --> Output Class Initialized
INFO - 2024-03-10 12:59:45 --> Security Class Initialized
DEBUG - 2024-03-10 12:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:59:45 --> Input Class Initialized
INFO - 2024-03-10 12:59:45 --> Language Class Initialized
INFO - 2024-03-10 12:59:45 --> Loader Class Initialized
INFO - 2024-03-10 12:59:45 --> Helper loaded: url_helper
INFO - 2024-03-10 12:59:45 --> Helper loaded: file_helper
INFO - 2024-03-10 12:59:45 --> Helper loaded: form_helper
INFO - 2024-03-10 12:59:45 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:59:45 --> Controller Class Initialized
INFO - 2024-03-10 12:59:45 --> Form Validation Class Initialized
INFO - 2024-03-10 12:59:45 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:59:45 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:59:45 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:59:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:59:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:59:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:59:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:59:45 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:59:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:59:45 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:59:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:59:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:59:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:59:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:59:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:59:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:59:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:59:45 --> Final output sent to browser
DEBUG - 2024-03-10 12:59:45 --> Total execution time: 0.0323
ERROR - 2024-03-10 12:59:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:59:46 --> Config Class Initialized
INFO - 2024-03-10 12:59:46 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:59:46 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:59:46 --> Utf8 Class Initialized
INFO - 2024-03-10 12:59:46 --> URI Class Initialized
INFO - 2024-03-10 12:59:46 --> Router Class Initialized
INFO - 2024-03-10 12:59:46 --> Output Class Initialized
INFO - 2024-03-10 12:59:46 --> Security Class Initialized
DEBUG - 2024-03-10 12:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:59:46 --> Input Class Initialized
INFO - 2024-03-10 12:59:46 --> Language Class Initialized
INFO - 2024-03-10 12:59:46 --> Loader Class Initialized
INFO - 2024-03-10 12:59:46 --> Helper loaded: url_helper
INFO - 2024-03-10 12:59:46 --> Helper loaded: file_helper
INFO - 2024-03-10 12:59:46 --> Helper loaded: form_helper
INFO - 2024-03-10 12:59:46 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:59:46 --> Controller Class Initialized
INFO - 2024-03-10 12:59:46 --> Form Validation Class Initialized
INFO - 2024-03-10 12:59:46 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:59:46 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:59:46 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:59:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:59:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:59:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:59:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:59:46 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:59:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:59:46 --> Model "ReportModel" initialized
ERROR - 2024-03-10 12:59:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 12:59:50 --> Config Class Initialized
INFO - 2024-03-10 12:59:50 --> Hooks Class Initialized
DEBUG - 2024-03-10 12:59:50 --> UTF-8 Support Enabled
INFO - 2024-03-10 12:59:50 --> Utf8 Class Initialized
INFO - 2024-03-10 12:59:50 --> URI Class Initialized
INFO - 2024-03-10 12:59:50 --> Router Class Initialized
INFO - 2024-03-10 12:59:50 --> Output Class Initialized
INFO - 2024-03-10 12:59:50 --> Security Class Initialized
DEBUG - 2024-03-10 12:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 12:59:50 --> Input Class Initialized
INFO - 2024-03-10 12:59:50 --> Language Class Initialized
INFO - 2024-03-10 12:59:50 --> Loader Class Initialized
INFO - 2024-03-10 12:59:50 --> Helper loaded: url_helper
INFO - 2024-03-10 12:59:50 --> Helper loaded: file_helper
INFO - 2024-03-10 12:59:50 --> Helper loaded: form_helper
INFO - 2024-03-10 12:59:50 --> Database Driver Class Initialized
DEBUG - 2024-03-10 12:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 12:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 12:59:50 --> Controller Class Initialized
INFO - 2024-03-10 12:59:50 --> Form Validation Class Initialized
INFO - 2024-03-10 12:59:50 --> Model "MasterModel" initialized
INFO - 2024-03-10 12:59:50 --> Model "NotificationModel" initialized
INFO - 2024-03-10 12:59:50 --> Model "DashboardModel" initialized
INFO - 2024-03-10 12:59:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 12:59:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 12:59:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 12:59:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 12:59:50 --> Model "OrderModel" initialized
INFO - 2024-03-10 12:59:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 12:59:50 --> Model "ReportModel" initialized
INFO - 2024-03-10 12:59:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 12:59:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 12:59:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 12:59:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 12:59:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 12:59:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 12:59:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 12:59:50 --> Final output sent to browser
DEBUG - 2024-03-10 12:59:50 --> Total execution time: 0.0360
ERROR - 2024-03-10 13:00:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:20 --> Config Class Initialized
INFO - 2024-03-10 13:00:20 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:20 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:20 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:20 --> URI Class Initialized
INFO - 2024-03-10 13:00:20 --> Router Class Initialized
INFO - 2024-03-10 13:00:20 --> Output Class Initialized
INFO - 2024-03-10 13:00:20 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:20 --> Input Class Initialized
INFO - 2024-03-10 13:00:20 --> Language Class Initialized
INFO - 2024-03-10 13:00:20 --> Loader Class Initialized
INFO - 2024-03-10 13:00:20 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:20 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:20 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:20 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:20 --> Controller Class Initialized
INFO - 2024-03-10 13:00:20 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:20 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:00:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:00:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 13:00:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:00:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:00:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:00:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:00:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 13:00:20 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:20 --> Total execution time: 0.0436
ERROR - 2024-03-10 13:00:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:20 --> Config Class Initialized
INFO - 2024-03-10 13:00:20 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:20 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:20 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:20 --> URI Class Initialized
INFO - 2024-03-10 13:00:20 --> Router Class Initialized
INFO - 2024-03-10 13:00:20 --> Output Class Initialized
INFO - 2024-03-10 13:00:20 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:20 --> Input Class Initialized
INFO - 2024-03-10 13:00:20 --> Language Class Initialized
INFO - 2024-03-10 13:00:20 --> Loader Class Initialized
INFO - 2024-03-10 13:00:20 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:20 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:20 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:20 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:20 --> Controller Class Initialized
INFO - 2024-03-10 13:00:20 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:20 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:20 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:00:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:20 --> Config Class Initialized
INFO - 2024-03-10 13:00:20 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:20 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:20 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:20 --> URI Class Initialized
INFO - 2024-03-10 13:00:20 --> Router Class Initialized
INFO - 2024-03-10 13:00:20 --> Output Class Initialized
INFO - 2024-03-10 13:00:20 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:20 --> Input Class Initialized
INFO - 2024-03-10 13:00:20 --> Language Class Initialized
INFO - 2024-03-10 13:00:20 --> Loader Class Initialized
INFO - 2024-03-10 13:00:20 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:21 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:21 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:21 --> Controller Class Initialized
INFO - 2024-03-10 13:00:21 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:21 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:21 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:21 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:21 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:21 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:00:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:00:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 13:00:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:00:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:00:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:00:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:00:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 13:00:21 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:21 --> Total execution time: 0.0704
ERROR - 2024-03-10 13:00:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:38 --> Config Class Initialized
INFO - 2024-03-10 13:00:38 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:38 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:38 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:38 --> URI Class Initialized
INFO - 2024-03-10 13:00:38 --> Router Class Initialized
INFO - 2024-03-10 13:00:38 --> Output Class Initialized
INFO - 2024-03-10 13:00:38 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:38 --> Input Class Initialized
INFO - 2024-03-10 13:00:38 --> Language Class Initialized
INFO - 2024-03-10 13:00:38 --> Loader Class Initialized
INFO - 2024-03-10 13:00:38 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:38 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:38 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:38 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:38 --> Controller Class Initialized
INFO - 2024-03-10 13:00:38 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:38 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:00:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:00:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 13:00:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:00:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:00:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:00:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:00:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 13:00:38 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:38 --> Total execution time: 0.0276
ERROR - 2024-03-10 13:00:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:38 --> Config Class Initialized
INFO - 2024-03-10 13:00:38 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:38 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:38 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:38 --> URI Class Initialized
INFO - 2024-03-10 13:00:38 --> Router Class Initialized
INFO - 2024-03-10 13:00:38 --> Output Class Initialized
INFO - 2024-03-10 13:00:38 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:38 --> Input Class Initialized
INFO - 2024-03-10 13:00:38 --> Language Class Initialized
INFO - 2024-03-10 13:00:38 --> Loader Class Initialized
INFO - 2024-03-10 13:00:38 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:38 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:38 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:38 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:38 --> Controller Class Initialized
INFO - 2024-03-10 13:00:38 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:38 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:38 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:00:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:39 --> Config Class Initialized
INFO - 2024-03-10 13:00:39 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:39 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:39 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:39 --> URI Class Initialized
INFO - 2024-03-10 13:00:39 --> Router Class Initialized
INFO - 2024-03-10 13:00:39 --> Output Class Initialized
INFO - 2024-03-10 13:00:39 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:39 --> Input Class Initialized
INFO - 2024-03-10 13:00:39 --> Language Class Initialized
INFO - 2024-03-10 13:00:39 --> Loader Class Initialized
INFO - 2024-03-10 13:00:39 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:39 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:39 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:39 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:39 --> Controller Class Initialized
INFO - 2024-03-10 13:00:39 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:39 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:39 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:39 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:39 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:39 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:00:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:00:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 13:00:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:00:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:00:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:00:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:00:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 13:00:39 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:39 --> Total execution time: 0.0429
ERROR - 2024-03-10 13:00:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:40 --> Config Class Initialized
INFO - 2024-03-10 13:00:40 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:40 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:40 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:40 --> URI Class Initialized
INFO - 2024-03-10 13:00:40 --> Router Class Initialized
INFO - 2024-03-10 13:00:40 --> Output Class Initialized
INFO - 2024-03-10 13:00:40 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:40 --> Input Class Initialized
INFO - 2024-03-10 13:00:40 --> Language Class Initialized
INFO - 2024-03-10 13:00:40 --> Loader Class Initialized
INFO - 2024-03-10 13:00:40 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:40 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:40 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:40 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:40 --> Controller Class Initialized
INFO - 2024-03-10 13:00:40 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:40 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:40 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:40 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:40 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:40 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:00:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:00:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:00:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:00:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:00:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:00:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 13:00:40 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:40 --> Total execution time: 0.0198
ERROR - 2024-03-10 13:00:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:41 --> Config Class Initialized
INFO - 2024-03-10 13:00:41 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:41 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:41 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:41 --> URI Class Initialized
INFO - 2024-03-10 13:00:41 --> Router Class Initialized
INFO - 2024-03-10 13:00:41 --> Output Class Initialized
INFO - 2024-03-10 13:00:41 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:41 --> Input Class Initialized
INFO - 2024-03-10 13:00:41 --> Language Class Initialized
INFO - 2024-03-10 13:00:41 --> Loader Class Initialized
INFO - 2024-03-10 13:00:41 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:41 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:41 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:41 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:41 --> Controller Class Initialized
INFO - 2024-03-10 13:00:41 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:41 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:41 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:41 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:41 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:41 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:00:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:42 --> Config Class Initialized
INFO - 2024-03-10 13:00:42 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:42 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:42 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:42 --> URI Class Initialized
INFO - 2024-03-10 13:00:42 --> Router Class Initialized
INFO - 2024-03-10 13:00:42 --> Output Class Initialized
INFO - 2024-03-10 13:00:42 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:42 --> Input Class Initialized
INFO - 2024-03-10 13:00:42 --> Language Class Initialized
INFO - 2024-03-10 13:00:42 --> Loader Class Initialized
INFO - 2024-03-10 13:00:42 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:42 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:42 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:42 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:42 --> Controller Class Initialized
INFO - 2024-03-10 13:00:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 13:00:42 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:42 --> Total execution time: 0.0203
ERROR - 2024-03-10 13:00:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:44 --> Config Class Initialized
INFO - 2024-03-10 13:00:44 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:44 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:44 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:44 --> URI Class Initialized
INFO - 2024-03-10 13:00:44 --> Router Class Initialized
INFO - 2024-03-10 13:00:44 --> Output Class Initialized
INFO - 2024-03-10 13:00:44 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:44 --> Input Class Initialized
INFO - 2024-03-10 13:00:44 --> Language Class Initialized
INFO - 2024-03-10 13:00:44 --> Loader Class Initialized
INFO - 2024-03-10 13:00:44 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:44 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:44 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:44 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:44 --> Controller Class Initialized
INFO - 2024-03-10 13:00:44 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:44 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:44 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:44 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:44 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:44 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:44 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:44 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:44 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:44 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:00:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:00:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:00:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:00:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:00:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:00:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 13:00:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 13:00:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 13:00:44 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:44 --> Total execution time: 0.0321
ERROR - 2024-03-10 13:00:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:45 --> Config Class Initialized
INFO - 2024-03-10 13:00:45 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:45 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:45 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:45 --> URI Class Initialized
INFO - 2024-03-10 13:00:45 --> Router Class Initialized
INFO - 2024-03-10 13:00:45 --> Output Class Initialized
INFO - 2024-03-10 13:00:45 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:45 --> Input Class Initialized
INFO - 2024-03-10 13:00:45 --> Language Class Initialized
INFO - 2024-03-10 13:00:45 --> Loader Class Initialized
INFO - 2024-03-10 13:00:45 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:45 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:45 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:45 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:45 --> Controller Class Initialized
INFO - 2024-03-10 13:00:45 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:45 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:45 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:45 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:45 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:45 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:00:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:46 --> Config Class Initialized
INFO - 2024-03-10 13:00:46 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:46 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:46 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:46 --> URI Class Initialized
INFO - 2024-03-10 13:00:46 --> Router Class Initialized
INFO - 2024-03-10 13:00:46 --> Output Class Initialized
INFO - 2024-03-10 13:00:46 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:46 --> Input Class Initialized
INFO - 2024-03-10 13:00:46 --> Language Class Initialized
INFO - 2024-03-10 13:00:46 --> Loader Class Initialized
INFO - 2024-03-10 13:00:46 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:46 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:46 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:46 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:46 --> Controller Class Initialized
INFO - 2024-03-10 13:00:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 13:00:46 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:46 --> Total execution time: 0.0199
ERROR - 2024-03-10 13:00:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:46 --> Config Class Initialized
INFO - 2024-03-10 13:00:46 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:46 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:46 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:46 --> URI Class Initialized
INFO - 2024-03-10 13:00:46 --> Router Class Initialized
INFO - 2024-03-10 13:00:46 --> Output Class Initialized
INFO - 2024-03-10 13:00:46 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:46 --> Input Class Initialized
INFO - 2024-03-10 13:00:46 --> Language Class Initialized
INFO - 2024-03-10 13:00:46 --> Loader Class Initialized
INFO - 2024-03-10 13:00:46 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:46 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:46 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:46 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:46 --> Controller Class Initialized
INFO - 2024-03-10 13:00:46 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:46 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:46 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:46 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:46 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:46 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:00:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:00:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:00:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:00:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:00:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:00:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-10 13:00:46 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:46 --> Total execution time: 0.0327
ERROR - 2024-03-10 13:00:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:47 --> Config Class Initialized
INFO - 2024-03-10 13:00:47 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:47 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:47 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:47 --> URI Class Initialized
INFO - 2024-03-10 13:00:47 --> Router Class Initialized
INFO - 2024-03-10 13:00:47 --> Output Class Initialized
INFO - 2024-03-10 13:00:47 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:47 --> Input Class Initialized
INFO - 2024-03-10 13:00:47 --> Language Class Initialized
INFO - 2024-03-10 13:00:47 --> Loader Class Initialized
INFO - 2024-03-10 13:00:47 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:47 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:47 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:47 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:47 --> Controller Class Initialized
INFO - 2024-03-10 13:00:47 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:47 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:47 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:47 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:47 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:47 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:47 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:47 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:47 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:47 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:00:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:49 --> Config Class Initialized
INFO - 2024-03-10 13:00:49 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:49 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:49 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:49 --> URI Class Initialized
INFO - 2024-03-10 13:00:49 --> Router Class Initialized
INFO - 2024-03-10 13:00:49 --> Output Class Initialized
INFO - 2024-03-10 13:00:49 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:49 --> Input Class Initialized
INFO - 2024-03-10 13:00:49 --> Language Class Initialized
INFO - 2024-03-10 13:00:49 --> Loader Class Initialized
INFO - 2024-03-10 13:00:49 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:49 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:49 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:49 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:49 --> Controller Class Initialized
INFO - 2024-03-10 13:00:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 13:00:49 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:49 --> Total execution time: 0.0205
ERROR - 2024-03-10 13:00:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:49 --> Config Class Initialized
INFO - 2024-03-10 13:00:49 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:49 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:49 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:49 --> URI Class Initialized
INFO - 2024-03-10 13:00:49 --> Router Class Initialized
INFO - 2024-03-10 13:00:49 --> Output Class Initialized
INFO - 2024-03-10 13:00:49 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:49 --> Input Class Initialized
INFO - 2024-03-10 13:00:49 --> Language Class Initialized
INFO - 2024-03-10 13:00:49 --> Loader Class Initialized
INFO - 2024-03-10 13:00:49 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:49 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:49 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:49 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:49 --> Controller Class Initialized
INFO - 2024-03-10 13:00:49 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:49 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:49 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:49 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:49 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:49 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:00:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:00:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:00:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:00:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:00:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:00:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-10 13:00:49 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:49 --> Total execution time: 0.0339
ERROR - 2024-03-10 13:00:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:51 --> Config Class Initialized
INFO - 2024-03-10 13:00:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:51 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:51 --> URI Class Initialized
INFO - 2024-03-10 13:00:51 --> Router Class Initialized
INFO - 2024-03-10 13:00:51 --> Output Class Initialized
INFO - 2024-03-10 13:00:51 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:51 --> Input Class Initialized
INFO - 2024-03-10 13:00:51 --> Language Class Initialized
INFO - 2024-03-10 13:00:51 --> Loader Class Initialized
INFO - 2024-03-10 13:00:51 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:51 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:51 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:51 --> Controller Class Initialized
INFO - 2024-03-10 13:00:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 13:00:51 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:51 --> Total execution time: 0.0214
ERROR - 2024-03-10 13:00:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:52 --> Config Class Initialized
INFO - 2024-03-10 13:00:52 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:52 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:52 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:52 --> URI Class Initialized
INFO - 2024-03-10 13:00:52 --> Router Class Initialized
INFO - 2024-03-10 13:00:52 --> Output Class Initialized
INFO - 2024-03-10 13:00:52 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:52 --> Input Class Initialized
INFO - 2024-03-10 13:00:52 --> Language Class Initialized
INFO - 2024-03-10 13:00:52 --> Loader Class Initialized
INFO - 2024-03-10 13:00:52 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:52 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:52 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:52 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:52 --> Controller Class Initialized
INFO - 2024-03-10 13:00:52 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:52 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:52 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:52 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:52 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:52 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:00:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:00:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:00:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:00:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:00:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:00:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-10 13:00:52 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:52 --> Total execution time: 0.0302
ERROR - 2024-03-10 13:00:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:53 --> Config Class Initialized
INFO - 2024-03-10 13:00:53 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:53 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:53 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:53 --> URI Class Initialized
INFO - 2024-03-10 13:00:53 --> Router Class Initialized
INFO - 2024-03-10 13:00:53 --> Output Class Initialized
INFO - 2024-03-10 13:00:53 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:53 --> Input Class Initialized
INFO - 2024-03-10 13:00:53 --> Language Class Initialized
INFO - 2024-03-10 13:00:53 --> Loader Class Initialized
INFO - 2024-03-10 13:00:53 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:53 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:53 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:53 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:53 --> Controller Class Initialized
INFO - 2024-03-10 13:00:53 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:53 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:53 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:53 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:53 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:53 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:00:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:00:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 13:00:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:00:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:00:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:00:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:00:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 13:00:53 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:53 --> Total execution time: 0.0323
ERROR - 2024-03-10 13:00:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:53 --> Config Class Initialized
INFO - 2024-03-10 13:00:53 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:53 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:53 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:53 --> URI Class Initialized
INFO - 2024-03-10 13:00:53 --> Router Class Initialized
INFO - 2024-03-10 13:00:53 --> Output Class Initialized
INFO - 2024-03-10 13:00:53 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:53 --> Input Class Initialized
INFO - 2024-03-10 13:00:53 --> Language Class Initialized
INFO - 2024-03-10 13:00:53 --> Loader Class Initialized
INFO - 2024-03-10 13:00:53 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:53 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:53 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:53 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:54 --> Controller Class Initialized
INFO - 2024-03-10 13:00:54 --> Form Validation Class Initialized
INFO - 2024-03-10 13:00:54 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:00:54 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:00:54 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:00:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:00:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:00:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:00:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:00:54 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:00:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:00:54 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:00:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:00:55 --> Config Class Initialized
INFO - 2024-03-10 13:00:55 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:00:55 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:00:55 --> Utf8 Class Initialized
INFO - 2024-03-10 13:00:55 --> URI Class Initialized
INFO - 2024-03-10 13:00:55 --> Router Class Initialized
INFO - 2024-03-10 13:00:55 --> Output Class Initialized
INFO - 2024-03-10 13:00:55 --> Security Class Initialized
DEBUG - 2024-03-10 13:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:00:55 --> Input Class Initialized
INFO - 2024-03-10 13:00:55 --> Language Class Initialized
INFO - 2024-03-10 13:00:55 --> Loader Class Initialized
INFO - 2024-03-10 13:00:55 --> Helper loaded: url_helper
INFO - 2024-03-10 13:00:55 --> Helper loaded: file_helper
INFO - 2024-03-10 13:00:55 --> Helper loaded: form_helper
INFO - 2024-03-10 13:00:55 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:00:55 --> Controller Class Initialized
INFO - 2024-03-10 13:00:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 13:00:55 --> Final output sent to browser
DEBUG - 2024-03-10 13:00:55 --> Total execution time: 0.0199
ERROR - 2024-03-10 13:01:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:01:12 --> Config Class Initialized
INFO - 2024-03-10 13:01:12 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:01:12 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:01:12 --> Utf8 Class Initialized
INFO - 2024-03-10 13:01:12 --> URI Class Initialized
INFO - 2024-03-10 13:01:12 --> Router Class Initialized
INFO - 2024-03-10 13:01:12 --> Output Class Initialized
INFO - 2024-03-10 13:01:12 --> Security Class Initialized
DEBUG - 2024-03-10 13:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:01:12 --> Input Class Initialized
INFO - 2024-03-10 13:01:12 --> Language Class Initialized
INFO - 2024-03-10 13:01:12 --> Loader Class Initialized
INFO - 2024-03-10 13:01:12 --> Helper loaded: url_helper
INFO - 2024-03-10 13:01:12 --> Helper loaded: file_helper
INFO - 2024-03-10 13:01:12 --> Helper loaded: form_helper
INFO - 2024-03-10 13:01:12 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:01:12 --> Controller Class Initialized
INFO - 2024-03-10 13:01:12 --> Form Validation Class Initialized
INFO - 2024-03-10 13:01:12 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:01:12 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:01:12 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:01:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:01:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:01:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:01:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:01:12 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:01:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:01:12 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:01:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:01:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:01:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:01:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:01:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:01:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 13:01:12 --> Final output sent to browser
DEBUG - 2024-03-10 13:01:12 --> Total execution time: 0.0353
ERROR - 2024-03-10 13:01:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:01:13 --> Config Class Initialized
INFO - 2024-03-10 13:01:13 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:01:13 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:01:13 --> Utf8 Class Initialized
INFO - 2024-03-10 13:01:13 --> URI Class Initialized
INFO - 2024-03-10 13:01:13 --> Router Class Initialized
INFO - 2024-03-10 13:01:13 --> Output Class Initialized
INFO - 2024-03-10 13:01:13 --> Security Class Initialized
DEBUG - 2024-03-10 13:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:01:13 --> Input Class Initialized
INFO - 2024-03-10 13:01:13 --> Language Class Initialized
INFO - 2024-03-10 13:01:13 --> Loader Class Initialized
INFO - 2024-03-10 13:01:13 --> Helper loaded: url_helper
INFO - 2024-03-10 13:01:13 --> Helper loaded: file_helper
INFO - 2024-03-10 13:01:13 --> Helper loaded: form_helper
INFO - 2024-03-10 13:01:13 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:01:13 --> Controller Class Initialized
INFO - 2024-03-10 13:01:13 --> Form Validation Class Initialized
INFO - 2024-03-10 13:01:13 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:01:13 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:01:13 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:01:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:01:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:01:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:01:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:01:13 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:01:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:01:13 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:01:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:01:14 --> Config Class Initialized
INFO - 2024-03-10 13:01:14 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:01:14 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:01:14 --> Utf8 Class Initialized
INFO - 2024-03-10 13:01:14 --> URI Class Initialized
INFO - 2024-03-10 13:01:14 --> Router Class Initialized
INFO - 2024-03-10 13:01:14 --> Output Class Initialized
INFO - 2024-03-10 13:01:14 --> Security Class Initialized
DEBUG - 2024-03-10 13:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:01:14 --> Input Class Initialized
INFO - 2024-03-10 13:01:14 --> Language Class Initialized
INFO - 2024-03-10 13:01:14 --> Loader Class Initialized
INFO - 2024-03-10 13:01:14 --> Helper loaded: url_helper
INFO - 2024-03-10 13:01:14 --> Helper loaded: file_helper
INFO - 2024-03-10 13:01:14 --> Helper loaded: form_helper
INFO - 2024-03-10 13:01:14 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:01:14 --> Controller Class Initialized
INFO - 2024-03-10 13:01:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 13:01:14 --> Final output sent to browser
DEBUG - 2024-03-10 13:01:14 --> Total execution time: 0.0233
ERROR - 2024-03-10 13:01:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:01:25 --> Config Class Initialized
INFO - 2024-03-10 13:01:25 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:01:25 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:01:25 --> Utf8 Class Initialized
INFO - 2024-03-10 13:01:25 --> URI Class Initialized
INFO - 2024-03-10 13:01:25 --> Router Class Initialized
INFO - 2024-03-10 13:01:25 --> Output Class Initialized
INFO - 2024-03-10 13:01:25 --> Security Class Initialized
DEBUG - 2024-03-10 13:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:01:25 --> Input Class Initialized
INFO - 2024-03-10 13:01:25 --> Language Class Initialized
INFO - 2024-03-10 13:01:25 --> Loader Class Initialized
INFO - 2024-03-10 13:01:25 --> Helper loaded: url_helper
INFO - 2024-03-10 13:01:25 --> Helper loaded: file_helper
INFO - 2024-03-10 13:01:25 --> Helper loaded: form_helper
INFO - 2024-03-10 13:01:25 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:01:25 --> Controller Class Initialized
INFO - 2024-03-10 13:01:25 --> Form Validation Class Initialized
INFO - 2024-03-10 13:01:25 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:01:25 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:01:25 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:01:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:01:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:01:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:01:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:01:25 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:01:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:01:25 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:01:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:01:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:01:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:01:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:01:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:01:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 13:01:25 --> Final output sent to browser
DEBUG - 2024-03-10 13:01:25 --> Total execution time: 0.0299
ERROR - 2024-03-10 13:02:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:02:10 --> Config Class Initialized
INFO - 2024-03-10 13:02:10 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:02:10 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:02:10 --> Utf8 Class Initialized
INFO - 2024-03-10 13:02:10 --> URI Class Initialized
INFO - 2024-03-10 13:02:10 --> Router Class Initialized
INFO - 2024-03-10 13:02:10 --> Output Class Initialized
INFO - 2024-03-10 13:02:10 --> Security Class Initialized
DEBUG - 2024-03-10 13:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:02:10 --> Input Class Initialized
INFO - 2024-03-10 13:02:10 --> Language Class Initialized
INFO - 2024-03-10 13:02:10 --> Loader Class Initialized
INFO - 2024-03-10 13:02:10 --> Helper loaded: url_helper
INFO - 2024-03-10 13:02:10 --> Helper loaded: file_helper
INFO - 2024-03-10 13:02:10 --> Helper loaded: form_helper
INFO - 2024-03-10 13:02:10 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:02:10 --> Controller Class Initialized
INFO - 2024-03-10 13:02:10 --> Form Validation Class Initialized
INFO - 2024-03-10 13:02:10 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:02:10 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:02:10 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:02:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:02:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:02:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:02:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:02:10 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:02:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:02:10 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:02:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:02:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:02:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:02:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:02:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:02:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 13:02:10 --> Final output sent to browser
DEBUG - 2024-03-10 13:02:10 --> Total execution time: 0.0329
ERROR - 2024-03-10 13:02:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:02:11 --> Config Class Initialized
INFO - 2024-03-10 13:02:11 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:02:11 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:02:11 --> Utf8 Class Initialized
INFO - 2024-03-10 13:02:11 --> URI Class Initialized
INFO - 2024-03-10 13:02:11 --> Router Class Initialized
INFO - 2024-03-10 13:02:11 --> Output Class Initialized
INFO - 2024-03-10 13:02:11 --> Security Class Initialized
DEBUG - 2024-03-10 13:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:02:11 --> Input Class Initialized
INFO - 2024-03-10 13:02:11 --> Language Class Initialized
INFO - 2024-03-10 13:02:11 --> Loader Class Initialized
INFO - 2024-03-10 13:02:11 --> Helper loaded: url_helper
INFO - 2024-03-10 13:02:11 --> Helper loaded: file_helper
INFO - 2024-03-10 13:02:11 --> Helper loaded: form_helper
INFO - 2024-03-10 13:02:11 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:02:11 --> Controller Class Initialized
INFO - 2024-03-10 13:02:11 --> Form Validation Class Initialized
INFO - 2024-03-10 13:02:11 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:02:11 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:02:11 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:02:11 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:02:11 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:02:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:02:11 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:02:11 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:02:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:02:11 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:03:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:03:24 --> Config Class Initialized
INFO - 2024-03-10 13:03:24 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:03:24 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:03:24 --> Utf8 Class Initialized
INFO - 2024-03-10 13:03:24 --> URI Class Initialized
INFO - 2024-03-10 13:03:24 --> Router Class Initialized
INFO - 2024-03-10 13:03:24 --> Output Class Initialized
INFO - 2024-03-10 13:03:24 --> Security Class Initialized
DEBUG - 2024-03-10 13:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:03:24 --> Input Class Initialized
INFO - 2024-03-10 13:03:24 --> Language Class Initialized
INFO - 2024-03-10 13:03:24 --> Loader Class Initialized
INFO - 2024-03-10 13:03:24 --> Helper loaded: url_helper
INFO - 2024-03-10 13:03:24 --> Helper loaded: file_helper
INFO - 2024-03-10 13:03:24 --> Helper loaded: form_helper
INFO - 2024-03-10 13:03:24 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:03:24 --> Controller Class Initialized
INFO - 2024-03-10 13:03:24 --> Form Validation Class Initialized
INFO - 2024-03-10 13:03:24 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:03:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:03:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 13:03:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:03:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:03:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:03:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:03:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 13:03:24 --> Final output sent to browser
DEBUG - 2024-03-10 13:03:24 --> Total execution time: 0.0276
ERROR - 2024-03-10 13:03:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:03:24 --> Config Class Initialized
INFO - 2024-03-10 13:03:24 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:03:24 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:03:24 --> Utf8 Class Initialized
INFO - 2024-03-10 13:03:24 --> URI Class Initialized
INFO - 2024-03-10 13:03:24 --> Router Class Initialized
INFO - 2024-03-10 13:03:24 --> Output Class Initialized
INFO - 2024-03-10 13:03:24 --> Security Class Initialized
DEBUG - 2024-03-10 13:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:03:24 --> Input Class Initialized
INFO - 2024-03-10 13:03:24 --> Language Class Initialized
INFO - 2024-03-10 13:03:24 --> Loader Class Initialized
INFO - 2024-03-10 13:03:24 --> Helper loaded: url_helper
INFO - 2024-03-10 13:03:24 --> Helper loaded: file_helper
INFO - 2024-03-10 13:03:24 --> Helper loaded: form_helper
INFO - 2024-03-10 13:03:24 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:03:24 --> Controller Class Initialized
INFO - 2024-03-10 13:03:24 --> Form Validation Class Initialized
INFO - 2024-03-10 13:03:24 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:03:24 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:03:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:03:26 --> Config Class Initialized
INFO - 2024-03-10 13:03:26 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:03:26 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:03:26 --> Utf8 Class Initialized
INFO - 2024-03-10 13:03:26 --> URI Class Initialized
INFO - 2024-03-10 13:03:26 --> Router Class Initialized
INFO - 2024-03-10 13:03:26 --> Output Class Initialized
INFO - 2024-03-10 13:03:26 --> Security Class Initialized
DEBUG - 2024-03-10 13:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:03:26 --> Input Class Initialized
INFO - 2024-03-10 13:03:26 --> Language Class Initialized
INFO - 2024-03-10 13:03:26 --> Loader Class Initialized
INFO - 2024-03-10 13:03:26 --> Helper loaded: url_helper
INFO - 2024-03-10 13:03:26 --> Helper loaded: file_helper
INFO - 2024-03-10 13:03:26 --> Helper loaded: form_helper
INFO - 2024-03-10 13:03:26 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:03:26 --> Controller Class Initialized
INFO - 2024-03-10 13:03:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 13:03:26 --> Final output sent to browser
DEBUG - 2024-03-10 13:03:26 --> Total execution time: 0.0206
ERROR - 2024-03-10 13:03:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:03:26 --> Config Class Initialized
INFO - 2024-03-10 13:03:26 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:03:26 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:03:26 --> Utf8 Class Initialized
INFO - 2024-03-10 13:03:26 --> URI Class Initialized
INFO - 2024-03-10 13:03:26 --> Router Class Initialized
INFO - 2024-03-10 13:03:26 --> Output Class Initialized
INFO - 2024-03-10 13:03:26 --> Security Class Initialized
DEBUG - 2024-03-10 13:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:03:26 --> Input Class Initialized
INFO - 2024-03-10 13:03:26 --> Language Class Initialized
INFO - 2024-03-10 13:03:26 --> Loader Class Initialized
INFO - 2024-03-10 13:03:26 --> Helper loaded: url_helper
INFO - 2024-03-10 13:03:26 --> Helper loaded: file_helper
INFO - 2024-03-10 13:03:26 --> Helper loaded: form_helper
INFO - 2024-03-10 13:03:26 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:03:26 --> Controller Class Initialized
INFO - 2024-03-10 13:03:26 --> Form Validation Class Initialized
INFO - 2024-03-10 13:03:26 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:03:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:03:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 13:03:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:03:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:03:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:03:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:03:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 13:03:26 --> Final output sent to browser
DEBUG - 2024-03-10 13:03:26 --> Total execution time: 0.0332
ERROR - 2024-03-10 13:03:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:03:26 --> Config Class Initialized
INFO - 2024-03-10 13:03:26 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:03:26 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:03:26 --> Utf8 Class Initialized
INFO - 2024-03-10 13:03:26 --> URI Class Initialized
INFO - 2024-03-10 13:03:26 --> Router Class Initialized
INFO - 2024-03-10 13:03:26 --> Output Class Initialized
INFO - 2024-03-10 13:03:26 --> Security Class Initialized
DEBUG - 2024-03-10 13:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:03:26 --> Input Class Initialized
INFO - 2024-03-10 13:03:26 --> Language Class Initialized
INFO - 2024-03-10 13:03:26 --> Loader Class Initialized
INFO - 2024-03-10 13:03:26 --> Helper loaded: url_helper
INFO - 2024-03-10 13:03:26 --> Helper loaded: file_helper
INFO - 2024-03-10 13:03:26 --> Helper loaded: form_helper
INFO - 2024-03-10 13:03:26 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:03:26 --> Controller Class Initialized
INFO - 2024-03-10 13:03:26 --> Form Validation Class Initialized
INFO - 2024-03-10 13:03:26 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:03:26 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:05:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:05:02 --> Config Class Initialized
INFO - 2024-03-10 13:05:02 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:05:02 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:05:02 --> Utf8 Class Initialized
INFO - 2024-03-10 13:05:02 --> URI Class Initialized
INFO - 2024-03-10 13:05:02 --> Router Class Initialized
INFO - 2024-03-10 13:05:02 --> Output Class Initialized
INFO - 2024-03-10 13:05:02 --> Security Class Initialized
DEBUG - 2024-03-10 13:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:05:02 --> Input Class Initialized
INFO - 2024-03-10 13:05:02 --> Language Class Initialized
INFO - 2024-03-10 13:05:02 --> Loader Class Initialized
INFO - 2024-03-10 13:05:02 --> Helper loaded: url_helper
INFO - 2024-03-10 13:05:02 --> Helper loaded: file_helper
INFO - 2024-03-10 13:05:02 --> Helper loaded: form_helper
INFO - 2024-03-10 13:05:02 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:05:02 --> Controller Class Initialized
INFO - 2024-03-10 13:05:02 --> Form Validation Class Initialized
INFO - 2024-03-10 13:05:02 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:05:02 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:05:02 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:05:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:05:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:05:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:05:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:05:02 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:05:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:05:02 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:05:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:05:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:05:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:05:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:05:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:05:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 13:05:02 --> Final output sent to browser
DEBUG - 2024-03-10 13:05:02 --> Total execution time: 0.0312
ERROR - 2024-03-10 13:05:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:05:04 --> Config Class Initialized
INFO - 2024-03-10 13:05:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:05:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:05:04 --> Utf8 Class Initialized
INFO - 2024-03-10 13:05:04 --> URI Class Initialized
INFO - 2024-03-10 13:05:04 --> Router Class Initialized
INFO - 2024-03-10 13:05:04 --> Output Class Initialized
INFO - 2024-03-10 13:05:04 --> Security Class Initialized
DEBUG - 2024-03-10 13:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:05:04 --> Input Class Initialized
INFO - 2024-03-10 13:05:04 --> Language Class Initialized
INFO - 2024-03-10 13:05:04 --> Loader Class Initialized
INFO - 2024-03-10 13:05:04 --> Helper loaded: url_helper
INFO - 2024-03-10 13:05:04 --> Helper loaded: file_helper
INFO - 2024-03-10 13:05:04 --> Helper loaded: form_helper
INFO - 2024-03-10 13:05:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:05:04 --> Controller Class Initialized
INFO - 2024-03-10 13:05:04 --> Form Validation Class Initialized
INFO - 2024-03-10 13:05:04 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:05:04 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:05:04 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:05:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:05:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:05:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:05:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:05:04 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:05:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:05:04 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:05:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:05:06 --> Config Class Initialized
INFO - 2024-03-10 13:05:06 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:05:06 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:05:06 --> Utf8 Class Initialized
INFO - 2024-03-10 13:05:06 --> URI Class Initialized
INFO - 2024-03-10 13:05:06 --> Router Class Initialized
INFO - 2024-03-10 13:05:06 --> Output Class Initialized
INFO - 2024-03-10 13:05:06 --> Security Class Initialized
DEBUG - 2024-03-10 13:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:05:06 --> Input Class Initialized
INFO - 2024-03-10 13:05:06 --> Language Class Initialized
INFO - 2024-03-10 13:05:06 --> Loader Class Initialized
INFO - 2024-03-10 13:05:06 --> Helper loaded: url_helper
INFO - 2024-03-10 13:05:06 --> Helper loaded: file_helper
INFO - 2024-03-10 13:05:06 --> Helper loaded: form_helper
INFO - 2024-03-10 13:05:06 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:05:06 --> Controller Class Initialized
INFO - 2024-03-10 13:05:06 --> Form Validation Class Initialized
INFO - 2024-03-10 13:05:06 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:05:06 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:05:06 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:05:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:05:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:05:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:05:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:05:06 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:05:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:05:06 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:05:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:05:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:05:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:05:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:05:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:05:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 13:05:06 --> Final output sent to browser
DEBUG - 2024-03-10 13:05:06 --> Total execution time: 0.0314
ERROR - 2024-03-10 13:05:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:05:06 --> Config Class Initialized
INFO - 2024-03-10 13:05:06 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:05:06 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:05:06 --> Utf8 Class Initialized
INFO - 2024-03-10 13:05:06 --> URI Class Initialized
INFO - 2024-03-10 13:05:06 --> Router Class Initialized
INFO - 2024-03-10 13:05:06 --> Output Class Initialized
INFO - 2024-03-10 13:05:06 --> Security Class Initialized
DEBUG - 2024-03-10 13:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:05:06 --> Input Class Initialized
INFO - 2024-03-10 13:05:06 --> Language Class Initialized
INFO - 2024-03-10 13:05:06 --> Loader Class Initialized
INFO - 2024-03-10 13:05:06 --> Helper loaded: url_helper
INFO - 2024-03-10 13:05:06 --> Helper loaded: file_helper
INFO - 2024-03-10 13:05:06 --> Helper loaded: form_helper
INFO - 2024-03-10 13:05:06 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:05:06 --> Controller Class Initialized
INFO - 2024-03-10 13:05:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 13:05:06 --> Final output sent to browser
DEBUG - 2024-03-10 13:05:06 --> Total execution time: 0.0331
ERROR - 2024-03-10 13:05:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:05:07 --> Config Class Initialized
INFO - 2024-03-10 13:05:07 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:05:07 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:05:07 --> Utf8 Class Initialized
INFO - 2024-03-10 13:05:07 --> URI Class Initialized
INFO - 2024-03-10 13:05:07 --> Router Class Initialized
INFO - 2024-03-10 13:05:07 --> Output Class Initialized
INFO - 2024-03-10 13:05:07 --> Security Class Initialized
DEBUG - 2024-03-10 13:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:05:07 --> Input Class Initialized
INFO - 2024-03-10 13:05:07 --> Language Class Initialized
INFO - 2024-03-10 13:05:07 --> Loader Class Initialized
INFO - 2024-03-10 13:05:07 --> Helper loaded: url_helper
INFO - 2024-03-10 13:05:07 --> Helper loaded: file_helper
INFO - 2024-03-10 13:05:07 --> Helper loaded: form_helper
INFO - 2024-03-10 13:05:07 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:05:07 --> Controller Class Initialized
INFO - 2024-03-10 13:05:07 --> Form Validation Class Initialized
INFO - 2024-03-10 13:05:07 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:05:07 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:05:07 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:05:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:05:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:05:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:05:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:05:07 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:05:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:05:07 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:05:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:05:16 --> Config Class Initialized
INFO - 2024-03-10 13:05:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:05:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:05:16 --> Utf8 Class Initialized
INFO - 2024-03-10 13:05:16 --> URI Class Initialized
INFO - 2024-03-10 13:05:16 --> Router Class Initialized
INFO - 2024-03-10 13:05:16 --> Output Class Initialized
INFO - 2024-03-10 13:05:16 --> Security Class Initialized
DEBUG - 2024-03-10 13:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:05:16 --> Input Class Initialized
INFO - 2024-03-10 13:05:16 --> Language Class Initialized
INFO - 2024-03-10 13:05:16 --> Loader Class Initialized
INFO - 2024-03-10 13:05:16 --> Helper loaded: url_helper
INFO - 2024-03-10 13:05:16 --> Helper loaded: file_helper
INFO - 2024-03-10 13:05:16 --> Helper loaded: form_helper
INFO - 2024-03-10 13:05:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:05:16 --> Controller Class Initialized
INFO - 2024-03-10 13:05:16 --> Form Validation Class Initialized
INFO - 2024-03-10 13:05:16 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:05:16 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:05:16 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:05:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:05:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:05:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:05:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:05:16 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:05:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:05:16 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 13:05:16 --> Final output sent to browser
DEBUG - 2024-03-10 13:05:16 --> Total execution time: 0.0242
ERROR - 2024-03-10 13:05:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:05:17 --> Config Class Initialized
INFO - 2024-03-10 13:05:17 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:05:17 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:05:17 --> Utf8 Class Initialized
INFO - 2024-03-10 13:05:17 --> URI Class Initialized
INFO - 2024-03-10 13:05:17 --> Router Class Initialized
INFO - 2024-03-10 13:05:17 --> Output Class Initialized
INFO - 2024-03-10 13:05:17 --> Security Class Initialized
DEBUG - 2024-03-10 13:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:05:17 --> Input Class Initialized
INFO - 2024-03-10 13:05:17 --> Language Class Initialized
INFO - 2024-03-10 13:05:17 --> Loader Class Initialized
INFO - 2024-03-10 13:05:17 --> Helper loaded: url_helper
INFO - 2024-03-10 13:05:17 --> Helper loaded: file_helper
INFO - 2024-03-10 13:05:17 --> Helper loaded: form_helper
INFO - 2024-03-10 13:05:17 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:05:17 --> Controller Class Initialized
INFO - 2024-03-10 13:05:17 --> Form Validation Class Initialized
INFO - 2024-03-10 13:05:17 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:05:17 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:05:17 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:05:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:05:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:05:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:05:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:05:17 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:05:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:05:17 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:07:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:07:39 --> Config Class Initialized
INFO - 2024-03-10 13:07:39 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:07:39 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:07:39 --> Utf8 Class Initialized
INFO - 2024-03-10 13:07:39 --> URI Class Initialized
INFO - 2024-03-10 13:07:39 --> Router Class Initialized
INFO - 2024-03-10 13:07:39 --> Output Class Initialized
INFO - 2024-03-10 13:07:39 --> Security Class Initialized
DEBUG - 2024-03-10 13:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:07:39 --> Input Class Initialized
INFO - 2024-03-10 13:07:39 --> Language Class Initialized
INFO - 2024-03-10 13:07:39 --> Loader Class Initialized
INFO - 2024-03-10 13:07:39 --> Helper loaded: url_helper
INFO - 2024-03-10 13:07:39 --> Helper loaded: file_helper
INFO - 2024-03-10 13:07:39 --> Helper loaded: form_helper
INFO - 2024-03-10 13:07:39 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:07:39 --> Controller Class Initialized
INFO - 2024-03-10 13:07:39 --> Form Validation Class Initialized
INFO - 2024-03-10 13:07:39 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:07:39 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:07:39 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:07:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:07:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:07:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:07:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:07:39 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:07:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:07:39 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:07:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:07:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:07:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:07:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:07:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:07:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 13:07:39 --> Final output sent to browser
DEBUG - 2024-03-10 13:07:39 --> Total execution time: 0.0367
ERROR - 2024-03-10 13:07:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:07:40 --> Config Class Initialized
INFO - 2024-03-10 13:07:40 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:07:40 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:07:40 --> Utf8 Class Initialized
INFO - 2024-03-10 13:07:40 --> URI Class Initialized
INFO - 2024-03-10 13:07:40 --> Router Class Initialized
INFO - 2024-03-10 13:07:40 --> Output Class Initialized
INFO - 2024-03-10 13:07:40 --> Security Class Initialized
DEBUG - 2024-03-10 13:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:07:40 --> Input Class Initialized
INFO - 2024-03-10 13:07:40 --> Language Class Initialized
INFO - 2024-03-10 13:07:40 --> Loader Class Initialized
INFO - 2024-03-10 13:07:40 --> Helper loaded: url_helper
INFO - 2024-03-10 13:07:40 --> Helper loaded: file_helper
INFO - 2024-03-10 13:07:40 --> Helper loaded: form_helper
INFO - 2024-03-10 13:07:40 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:07:40 --> Controller Class Initialized
INFO - 2024-03-10 13:07:40 --> Form Validation Class Initialized
INFO - 2024-03-10 13:07:40 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:07:40 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:07:40 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:07:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:07:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:07:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:07:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:07:40 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:07:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:07:40 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:07:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:07:52 --> Config Class Initialized
INFO - 2024-03-10 13:07:52 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:07:52 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:07:52 --> Utf8 Class Initialized
INFO - 2024-03-10 13:07:52 --> URI Class Initialized
INFO - 2024-03-10 13:07:52 --> Router Class Initialized
INFO - 2024-03-10 13:07:52 --> Output Class Initialized
INFO - 2024-03-10 13:07:52 --> Security Class Initialized
DEBUG - 2024-03-10 13:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:07:52 --> Input Class Initialized
INFO - 2024-03-10 13:07:52 --> Language Class Initialized
INFO - 2024-03-10 13:07:52 --> Loader Class Initialized
INFO - 2024-03-10 13:07:52 --> Helper loaded: url_helper
INFO - 2024-03-10 13:07:52 --> Helper loaded: file_helper
INFO - 2024-03-10 13:07:52 --> Helper loaded: form_helper
INFO - 2024-03-10 13:07:52 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:07:52 --> Controller Class Initialized
INFO - 2024-03-10 13:07:52 --> Form Validation Class Initialized
INFO - 2024-03-10 13:07:52 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:07:52 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:07:52 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:07:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:07:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:07:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:07:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:07:52 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:07:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:07:52 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:07:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:07:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:07:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:07:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:07:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:07:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 13:07:52 --> Final output sent to browser
DEBUG - 2024-03-10 13:07:52 --> Total execution time: 0.0278
ERROR - 2024-03-10 13:07:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:07:53 --> Config Class Initialized
INFO - 2024-03-10 13:07:53 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:07:53 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:07:53 --> Utf8 Class Initialized
INFO - 2024-03-10 13:07:53 --> URI Class Initialized
INFO - 2024-03-10 13:07:53 --> Router Class Initialized
INFO - 2024-03-10 13:07:53 --> Output Class Initialized
INFO - 2024-03-10 13:07:53 --> Security Class Initialized
DEBUG - 2024-03-10 13:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:07:53 --> Input Class Initialized
INFO - 2024-03-10 13:07:53 --> Language Class Initialized
INFO - 2024-03-10 13:07:53 --> Loader Class Initialized
INFO - 2024-03-10 13:07:53 --> Helper loaded: url_helper
INFO - 2024-03-10 13:07:53 --> Helper loaded: file_helper
INFO - 2024-03-10 13:07:53 --> Helper loaded: form_helper
INFO - 2024-03-10 13:07:53 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:07:53 --> Controller Class Initialized
INFO - 2024-03-10 13:07:53 --> Form Validation Class Initialized
INFO - 2024-03-10 13:07:53 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:07:53 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:07:53 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:07:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:07:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:07:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:07:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:07:53 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:07:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:07:53 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:08:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:08:49 --> Config Class Initialized
INFO - 2024-03-10 13:08:49 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:08:49 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:08:49 --> Utf8 Class Initialized
INFO - 2024-03-10 13:08:49 --> URI Class Initialized
INFO - 2024-03-10 13:08:49 --> Router Class Initialized
INFO - 2024-03-10 13:08:49 --> Output Class Initialized
INFO - 2024-03-10 13:08:49 --> Security Class Initialized
DEBUG - 2024-03-10 13:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:08:49 --> Input Class Initialized
INFO - 2024-03-10 13:08:49 --> Language Class Initialized
INFO - 2024-03-10 13:08:49 --> Loader Class Initialized
INFO - 2024-03-10 13:08:49 --> Helper loaded: url_helper
INFO - 2024-03-10 13:08:49 --> Helper loaded: file_helper
INFO - 2024-03-10 13:08:49 --> Helper loaded: form_helper
INFO - 2024-03-10 13:08:49 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:08:49 --> Controller Class Initialized
INFO - 2024-03-10 13:08:49 --> Form Validation Class Initialized
INFO - 2024-03-10 13:08:49 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:08:49 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:08:49 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:08:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:08:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:08:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:08:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:08:49 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:08:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:08:49 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:08:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:08:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:08:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:08:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:08:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:08:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 13:08:49 --> Final output sent to browser
DEBUG - 2024-03-10 13:08:49 --> Total execution time: 0.0354
ERROR - 2024-03-10 13:08:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:08:50 --> Config Class Initialized
INFO - 2024-03-10 13:08:50 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:08:50 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:08:50 --> Utf8 Class Initialized
INFO - 2024-03-10 13:08:50 --> URI Class Initialized
INFO - 2024-03-10 13:08:50 --> Router Class Initialized
INFO - 2024-03-10 13:08:50 --> Output Class Initialized
INFO - 2024-03-10 13:08:50 --> Security Class Initialized
DEBUG - 2024-03-10 13:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:08:50 --> Input Class Initialized
INFO - 2024-03-10 13:08:50 --> Language Class Initialized
INFO - 2024-03-10 13:08:50 --> Loader Class Initialized
INFO - 2024-03-10 13:08:50 --> Helper loaded: url_helper
INFO - 2024-03-10 13:08:50 --> Helper loaded: file_helper
INFO - 2024-03-10 13:08:50 --> Helper loaded: form_helper
INFO - 2024-03-10 13:08:50 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:08:50 --> Controller Class Initialized
INFO - 2024-03-10 13:08:50 --> Form Validation Class Initialized
INFO - 2024-03-10 13:08:50 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:08:50 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:08:50 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:08:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:08:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:08:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:08:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:08:50 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:08:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:08:50 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:09:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:09:03 --> Config Class Initialized
INFO - 2024-03-10 13:09:03 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:09:03 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:09:03 --> Utf8 Class Initialized
INFO - 2024-03-10 13:09:03 --> URI Class Initialized
INFO - 2024-03-10 13:09:03 --> Router Class Initialized
INFO - 2024-03-10 13:09:03 --> Output Class Initialized
INFO - 2024-03-10 13:09:03 --> Security Class Initialized
DEBUG - 2024-03-10 13:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:09:03 --> Input Class Initialized
INFO - 2024-03-10 13:09:03 --> Language Class Initialized
INFO - 2024-03-10 13:09:03 --> Loader Class Initialized
INFO - 2024-03-10 13:09:03 --> Helper loaded: url_helper
INFO - 2024-03-10 13:09:03 --> Helper loaded: file_helper
INFO - 2024-03-10 13:09:03 --> Helper loaded: form_helper
INFO - 2024-03-10 13:09:03 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:09:03 --> Controller Class Initialized
INFO - 2024-03-10 13:09:03 --> Form Validation Class Initialized
INFO - 2024-03-10 13:09:03 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:09:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:09:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:09:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:09:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:09:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:09:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 13:09:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 13:09:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 13:09:03 --> Final output sent to browser
DEBUG - 2024-03-10 13:09:03 --> Total execution time: 0.0389
ERROR - 2024-03-10 13:09:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:09:03 --> Config Class Initialized
INFO - 2024-03-10 13:09:03 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:09:03 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:09:03 --> Utf8 Class Initialized
INFO - 2024-03-10 13:09:03 --> URI Class Initialized
INFO - 2024-03-10 13:09:03 --> Router Class Initialized
INFO - 2024-03-10 13:09:03 --> Output Class Initialized
INFO - 2024-03-10 13:09:03 --> Security Class Initialized
DEBUG - 2024-03-10 13:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:09:03 --> Input Class Initialized
INFO - 2024-03-10 13:09:03 --> Language Class Initialized
INFO - 2024-03-10 13:09:03 --> Loader Class Initialized
INFO - 2024-03-10 13:09:03 --> Helper loaded: url_helper
INFO - 2024-03-10 13:09:03 --> Helper loaded: file_helper
INFO - 2024-03-10 13:09:03 --> Helper loaded: form_helper
INFO - 2024-03-10 13:09:03 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:09:03 --> Controller Class Initialized
INFO - 2024-03-10 13:09:03 --> Form Validation Class Initialized
INFO - 2024-03-10 13:09:03 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:09:03 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:09:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:09:05 --> Config Class Initialized
INFO - 2024-03-10 13:09:05 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:09:05 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:09:05 --> Utf8 Class Initialized
INFO - 2024-03-10 13:09:05 --> URI Class Initialized
INFO - 2024-03-10 13:09:05 --> Router Class Initialized
INFO - 2024-03-10 13:09:05 --> Output Class Initialized
INFO - 2024-03-10 13:09:05 --> Security Class Initialized
DEBUG - 2024-03-10 13:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:09:05 --> Input Class Initialized
INFO - 2024-03-10 13:09:05 --> Language Class Initialized
INFO - 2024-03-10 13:09:05 --> Loader Class Initialized
INFO - 2024-03-10 13:09:05 --> Helper loaded: url_helper
INFO - 2024-03-10 13:09:05 --> Helper loaded: file_helper
INFO - 2024-03-10 13:09:05 --> Helper loaded: form_helper
INFO - 2024-03-10 13:09:05 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:09:05 --> Controller Class Initialized
INFO - 2024-03-10 13:09:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 13:09:05 --> Final output sent to browser
DEBUG - 2024-03-10 13:09:05 --> Total execution time: 0.0211
ERROR - 2024-03-10 13:09:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:09:14 --> Config Class Initialized
INFO - 2024-03-10 13:09:14 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:09:14 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:09:14 --> Utf8 Class Initialized
INFO - 2024-03-10 13:09:14 --> URI Class Initialized
INFO - 2024-03-10 13:09:14 --> Router Class Initialized
INFO - 2024-03-10 13:09:14 --> Output Class Initialized
INFO - 2024-03-10 13:09:14 --> Security Class Initialized
DEBUG - 2024-03-10 13:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:09:14 --> Input Class Initialized
INFO - 2024-03-10 13:09:14 --> Language Class Initialized
INFO - 2024-03-10 13:09:14 --> Loader Class Initialized
INFO - 2024-03-10 13:09:14 --> Helper loaded: url_helper
INFO - 2024-03-10 13:09:14 --> Helper loaded: file_helper
INFO - 2024-03-10 13:09:14 --> Helper loaded: form_helper
INFO - 2024-03-10 13:09:14 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:09:14 --> Controller Class Initialized
INFO - 2024-03-10 13:09:14 --> Form Validation Class Initialized
INFO - 2024-03-10 13:09:14 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:09:14 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:09:14 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:09:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:09:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:09:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:09:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:09:14 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:09:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:09:14 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:10:32 --> Config Class Initialized
INFO - 2024-03-10 13:10:32 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:10:32 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:10:32 --> Utf8 Class Initialized
INFO - 2024-03-10 13:10:32 --> URI Class Initialized
INFO - 2024-03-10 13:10:32 --> Router Class Initialized
INFO - 2024-03-10 13:10:32 --> Output Class Initialized
INFO - 2024-03-10 13:10:32 --> Security Class Initialized
DEBUG - 2024-03-10 13:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:10:32 --> Input Class Initialized
INFO - 2024-03-10 13:10:32 --> Language Class Initialized
INFO - 2024-03-10 13:10:32 --> Loader Class Initialized
INFO - 2024-03-10 13:10:32 --> Helper loaded: url_helper
INFO - 2024-03-10 13:10:32 --> Helper loaded: file_helper
INFO - 2024-03-10 13:10:32 --> Helper loaded: form_helper
INFO - 2024-03-10 13:10:32 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:10:32 --> Controller Class Initialized
INFO - 2024-03-10 13:10:32 --> Form Validation Class Initialized
INFO - 2024-03-10 13:10:32 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 13:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 13:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 13:10:32 --> Final output sent to browser
DEBUG - 2024-03-10 13:10:32 --> Total execution time: 0.0332
ERROR - 2024-03-10 13:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:10:32 --> Config Class Initialized
INFO - 2024-03-10 13:10:32 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:10:32 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:10:32 --> Utf8 Class Initialized
INFO - 2024-03-10 13:10:32 --> URI Class Initialized
INFO - 2024-03-10 13:10:32 --> Router Class Initialized
INFO - 2024-03-10 13:10:32 --> Output Class Initialized
INFO - 2024-03-10 13:10:32 --> Security Class Initialized
DEBUG - 2024-03-10 13:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:10:32 --> Input Class Initialized
INFO - 2024-03-10 13:10:32 --> Language Class Initialized
INFO - 2024-03-10 13:10:32 --> Loader Class Initialized
INFO - 2024-03-10 13:10:32 --> Helper loaded: url_helper
INFO - 2024-03-10 13:10:32 --> Helper loaded: file_helper
INFO - 2024-03-10 13:10:32 --> Helper loaded: form_helper
INFO - 2024-03-10 13:10:32 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:10:32 --> Controller Class Initialized
INFO - 2024-03-10 13:10:32 --> Form Validation Class Initialized
INFO - 2024-03-10 13:10:32 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:10:32 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:10:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:10:38 --> Config Class Initialized
INFO - 2024-03-10 13:10:38 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:10:38 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:10:38 --> Utf8 Class Initialized
INFO - 2024-03-10 13:10:38 --> URI Class Initialized
INFO - 2024-03-10 13:10:38 --> Router Class Initialized
INFO - 2024-03-10 13:10:38 --> Output Class Initialized
INFO - 2024-03-10 13:10:38 --> Security Class Initialized
DEBUG - 2024-03-10 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:10:38 --> Input Class Initialized
INFO - 2024-03-10 13:10:38 --> Language Class Initialized
INFO - 2024-03-10 13:10:38 --> Loader Class Initialized
INFO - 2024-03-10 13:10:38 --> Helper loaded: url_helper
INFO - 2024-03-10 13:10:38 --> Helper loaded: file_helper
INFO - 2024-03-10 13:10:38 --> Helper loaded: form_helper
INFO - 2024-03-10 13:10:38 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:10:38 --> Controller Class Initialized
INFO - 2024-03-10 13:10:38 --> Form Validation Class Initialized
INFO - 2024-03-10 13:10:38 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:10:38 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:10:38 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:10:38 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:10:38 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:10:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:10:38 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:10:38 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:10:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:10:38 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:10:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:10:42 --> Config Class Initialized
INFO - 2024-03-10 13:10:42 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:10:42 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:10:42 --> Utf8 Class Initialized
INFO - 2024-03-10 13:10:42 --> URI Class Initialized
INFO - 2024-03-10 13:10:42 --> Router Class Initialized
INFO - 2024-03-10 13:10:42 --> Output Class Initialized
INFO - 2024-03-10 13:10:42 --> Security Class Initialized
DEBUG - 2024-03-10 13:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:10:42 --> Input Class Initialized
INFO - 2024-03-10 13:10:42 --> Language Class Initialized
INFO - 2024-03-10 13:10:42 --> Loader Class Initialized
INFO - 2024-03-10 13:10:42 --> Helper loaded: url_helper
INFO - 2024-03-10 13:10:42 --> Helper loaded: file_helper
INFO - 2024-03-10 13:10:42 --> Helper loaded: form_helper
INFO - 2024-03-10 13:10:42 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:10:42 --> Controller Class Initialized
INFO - 2024-03-10 13:10:42 --> Form Validation Class Initialized
INFO - 2024-03-10 13:10:42 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:10:42 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:10:42 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:10:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:10:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:10:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:10:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:10:42 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:10:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:10:42 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:11:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:11:31 --> Config Class Initialized
INFO - 2024-03-10 13:11:31 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:11:31 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:11:31 --> Utf8 Class Initialized
INFO - 2024-03-10 13:11:31 --> URI Class Initialized
INFO - 2024-03-10 13:11:31 --> Router Class Initialized
INFO - 2024-03-10 13:11:31 --> Output Class Initialized
INFO - 2024-03-10 13:11:31 --> Security Class Initialized
DEBUG - 2024-03-10 13:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:11:31 --> Input Class Initialized
INFO - 2024-03-10 13:11:31 --> Language Class Initialized
INFO - 2024-03-10 13:11:31 --> Loader Class Initialized
INFO - 2024-03-10 13:11:31 --> Helper loaded: url_helper
INFO - 2024-03-10 13:11:31 --> Helper loaded: file_helper
INFO - 2024-03-10 13:11:31 --> Helper loaded: form_helper
INFO - 2024-03-10 13:11:31 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:11:31 --> Controller Class Initialized
INFO - 2024-03-10 13:11:31 --> Form Validation Class Initialized
INFO - 2024-03-10 13:11:31 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 13:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 13:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 13:11:31 --> Final output sent to browser
DEBUG - 2024-03-10 13:11:31 --> Total execution time: 0.0380
ERROR - 2024-03-10 13:11:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:11:31 --> Config Class Initialized
INFO - 2024-03-10 13:11:31 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:11:31 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:11:31 --> Utf8 Class Initialized
INFO - 2024-03-10 13:11:31 --> URI Class Initialized
INFO - 2024-03-10 13:11:31 --> Router Class Initialized
INFO - 2024-03-10 13:11:31 --> Output Class Initialized
INFO - 2024-03-10 13:11:31 --> Security Class Initialized
DEBUG - 2024-03-10 13:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:11:31 --> Input Class Initialized
INFO - 2024-03-10 13:11:31 --> Language Class Initialized
INFO - 2024-03-10 13:11:31 --> Loader Class Initialized
INFO - 2024-03-10 13:11:31 --> Helper loaded: url_helper
INFO - 2024-03-10 13:11:31 --> Helper loaded: file_helper
INFO - 2024-03-10 13:11:31 --> Helper loaded: form_helper
INFO - 2024-03-10 13:11:31 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:11:31 --> Controller Class Initialized
INFO - 2024-03-10 13:11:31 --> Form Validation Class Initialized
INFO - 2024-03-10 13:11:31 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:11:31 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:11:37 --> Config Class Initialized
INFO - 2024-03-10 13:11:37 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:11:37 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:11:37 --> Utf8 Class Initialized
INFO - 2024-03-10 13:11:37 --> URI Class Initialized
INFO - 2024-03-10 13:11:37 --> Router Class Initialized
INFO - 2024-03-10 13:11:37 --> Output Class Initialized
INFO - 2024-03-10 13:11:37 --> Security Class Initialized
DEBUG - 2024-03-10 13:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:11:37 --> Input Class Initialized
INFO - 2024-03-10 13:11:37 --> Language Class Initialized
INFO - 2024-03-10 13:11:37 --> Loader Class Initialized
INFO - 2024-03-10 13:11:37 --> Helper loaded: url_helper
INFO - 2024-03-10 13:11:37 --> Helper loaded: file_helper
INFO - 2024-03-10 13:11:37 --> Helper loaded: form_helper
INFO - 2024-03-10 13:11:37 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:11:37 --> Controller Class Initialized
INFO - 2024-03-10 13:11:37 --> Form Validation Class Initialized
INFO - 2024-03-10 13:11:37 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:11:37 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:11:37 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:11:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:11:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:11:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:11:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:11:37 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:11:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:11:37 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:11:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:11:41 --> Config Class Initialized
INFO - 2024-03-10 13:11:41 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:11:41 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:11:41 --> Utf8 Class Initialized
INFO - 2024-03-10 13:11:41 --> URI Class Initialized
INFO - 2024-03-10 13:11:41 --> Router Class Initialized
INFO - 2024-03-10 13:11:41 --> Output Class Initialized
INFO - 2024-03-10 13:11:41 --> Security Class Initialized
DEBUG - 2024-03-10 13:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:11:41 --> Input Class Initialized
INFO - 2024-03-10 13:11:41 --> Language Class Initialized
INFO - 2024-03-10 13:11:41 --> Loader Class Initialized
INFO - 2024-03-10 13:11:41 --> Helper loaded: url_helper
INFO - 2024-03-10 13:11:41 --> Helper loaded: file_helper
INFO - 2024-03-10 13:11:41 --> Helper loaded: form_helper
INFO - 2024-03-10 13:11:41 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:11:41 --> Controller Class Initialized
INFO - 2024-03-10 13:11:41 --> Form Validation Class Initialized
INFO - 2024-03-10 13:11:41 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:11:41 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:11:41 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:11:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:11:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:11:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:11:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:11:41 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:11:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:11:41 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:11:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:11:43 --> Config Class Initialized
INFO - 2024-03-10 13:11:43 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:11:43 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:11:43 --> Utf8 Class Initialized
INFO - 2024-03-10 13:11:43 --> URI Class Initialized
INFO - 2024-03-10 13:11:43 --> Router Class Initialized
INFO - 2024-03-10 13:11:43 --> Output Class Initialized
INFO - 2024-03-10 13:11:43 --> Security Class Initialized
DEBUG - 2024-03-10 13:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:11:43 --> Input Class Initialized
INFO - 2024-03-10 13:11:43 --> Language Class Initialized
INFO - 2024-03-10 13:11:43 --> Loader Class Initialized
INFO - 2024-03-10 13:11:43 --> Helper loaded: url_helper
INFO - 2024-03-10 13:11:43 --> Helper loaded: file_helper
INFO - 2024-03-10 13:11:43 --> Helper loaded: form_helper
INFO - 2024-03-10 13:11:43 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:11:43 --> Controller Class Initialized
INFO - 2024-03-10 13:11:43 --> Form Validation Class Initialized
INFO - 2024-03-10 13:11:43 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:11:43 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:11:43 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:11:43 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:11:43 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:11:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:11:43 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:11:43 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:11:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:11:43 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:11:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-10 13:11:43 --> Final output sent to browser
DEBUG - 2024-03-10 13:11:43 --> Total execution time: 0.0430
ERROR - 2024-03-10 13:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:11:47 --> Config Class Initialized
INFO - 2024-03-10 13:11:47 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:11:47 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:11:47 --> Utf8 Class Initialized
INFO - 2024-03-10 13:11:47 --> URI Class Initialized
INFO - 2024-03-10 13:11:47 --> Router Class Initialized
INFO - 2024-03-10 13:11:47 --> Output Class Initialized
INFO - 2024-03-10 13:11:47 --> Security Class Initialized
DEBUG - 2024-03-10 13:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:11:47 --> Input Class Initialized
INFO - 2024-03-10 13:11:47 --> Language Class Initialized
INFO - 2024-03-10 13:11:47 --> Loader Class Initialized
INFO - 2024-03-10 13:11:47 --> Helper loaded: url_helper
INFO - 2024-03-10 13:11:47 --> Helper loaded: file_helper
INFO - 2024-03-10 13:11:47 --> Helper loaded: form_helper
INFO - 2024-03-10 13:11:47 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:11:47 --> Controller Class Initialized
INFO - 2024-03-10 13:11:47 --> Form Validation Class Initialized
INFO - 2024-03-10 13:11:47 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:11:47 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:11:47 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:11:47 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:11:47 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:11:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:11:47 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:11:47 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:11:47 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:11:47 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:13:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:13:55 --> Config Class Initialized
INFO - 2024-03-10 13:13:55 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:13:55 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:13:55 --> Utf8 Class Initialized
INFO - 2024-03-10 13:13:55 --> URI Class Initialized
INFO - 2024-03-10 13:13:55 --> Router Class Initialized
INFO - 2024-03-10 13:13:55 --> Output Class Initialized
INFO - 2024-03-10 13:13:55 --> Security Class Initialized
DEBUG - 2024-03-10 13:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:13:55 --> Input Class Initialized
INFO - 2024-03-10 13:13:55 --> Language Class Initialized
INFO - 2024-03-10 13:13:55 --> Loader Class Initialized
INFO - 2024-03-10 13:13:55 --> Helper loaded: url_helper
INFO - 2024-03-10 13:13:55 --> Helper loaded: file_helper
INFO - 2024-03-10 13:13:55 --> Helper loaded: form_helper
INFO - 2024-03-10 13:13:55 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:13:55 --> Controller Class Initialized
INFO - 2024-03-10 13:13:55 --> Form Validation Class Initialized
INFO - 2024-03-10 13:13:55 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:13:55 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:13:55 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:13:55 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:13:55 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:13:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:13:55 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:13:55 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:13:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:13:55 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:13:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:13:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:13:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:13:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:13:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:13:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 13:13:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 13:13:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 13:13:55 --> Final output sent to browser
DEBUG - 2024-03-10 13:13:55 --> Total execution time: 0.0420
ERROR - 2024-03-10 13:13:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:13:56 --> Config Class Initialized
INFO - 2024-03-10 13:13:56 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:13:56 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:13:56 --> Utf8 Class Initialized
INFO - 2024-03-10 13:13:56 --> URI Class Initialized
INFO - 2024-03-10 13:13:56 --> Router Class Initialized
INFO - 2024-03-10 13:13:56 --> Output Class Initialized
INFO - 2024-03-10 13:13:56 --> Security Class Initialized
DEBUG - 2024-03-10 13:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:13:56 --> Input Class Initialized
INFO - 2024-03-10 13:13:56 --> Language Class Initialized
INFO - 2024-03-10 13:13:56 --> Loader Class Initialized
INFO - 2024-03-10 13:13:56 --> Helper loaded: url_helper
INFO - 2024-03-10 13:13:56 --> Helper loaded: file_helper
INFO - 2024-03-10 13:13:56 --> Helper loaded: form_helper
INFO - 2024-03-10 13:13:56 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:13:56 --> Controller Class Initialized
INFO - 2024-03-10 13:13:56 --> Form Validation Class Initialized
INFO - 2024-03-10 13:13:56 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:13:56 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:13:56 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:13:56 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:13:56 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:13:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:13:56 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:13:56 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:13:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:13:56 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:14:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:14:16 --> Config Class Initialized
INFO - 2024-03-10 13:14:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:14:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:14:16 --> Utf8 Class Initialized
INFO - 2024-03-10 13:14:16 --> URI Class Initialized
INFO - 2024-03-10 13:14:16 --> Router Class Initialized
INFO - 2024-03-10 13:14:16 --> Output Class Initialized
INFO - 2024-03-10 13:14:16 --> Security Class Initialized
DEBUG - 2024-03-10 13:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:14:16 --> Input Class Initialized
INFO - 2024-03-10 13:14:16 --> Language Class Initialized
INFO - 2024-03-10 13:14:16 --> Loader Class Initialized
INFO - 2024-03-10 13:14:16 --> Helper loaded: url_helper
INFO - 2024-03-10 13:14:16 --> Helper loaded: file_helper
INFO - 2024-03-10 13:14:16 --> Helper loaded: form_helper
INFO - 2024-03-10 13:14:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:14:16 --> Controller Class Initialized
INFO - 2024-03-10 13:14:16 --> Form Validation Class Initialized
INFO - 2024-03-10 13:14:16 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:14:16 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:14:16 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:14:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:14:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:14:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:14:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:14:16 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:14:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:14:16 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:14:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 13:14:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 13:14:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 13:14:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 13:14:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 13:14:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 13:14:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 13:14:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 13:14:16 --> Final output sent to browser
DEBUG - 2024-03-10 13:14:16 --> Total execution time: 0.0238
ERROR - 2024-03-10 13:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:14:18 --> Config Class Initialized
INFO - 2024-03-10 13:14:18 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:14:18 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:14:18 --> Utf8 Class Initialized
INFO - 2024-03-10 13:14:18 --> URI Class Initialized
INFO - 2024-03-10 13:14:18 --> Router Class Initialized
INFO - 2024-03-10 13:14:18 --> Output Class Initialized
INFO - 2024-03-10 13:14:18 --> Security Class Initialized
DEBUG - 2024-03-10 13:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:14:18 --> Input Class Initialized
INFO - 2024-03-10 13:14:18 --> Language Class Initialized
INFO - 2024-03-10 13:14:18 --> Loader Class Initialized
INFO - 2024-03-10 13:14:18 --> Helper loaded: url_helper
INFO - 2024-03-10 13:14:18 --> Helper loaded: file_helper
INFO - 2024-03-10 13:14:18 --> Helper loaded: form_helper
INFO - 2024-03-10 13:14:18 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:14:18 --> Controller Class Initialized
INFO - 2024-03-10 13:14:18 --> Form Validation Class Initialized
INFO - 2024-03-10 13:14:18 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:14:18 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:14:18 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:14:18 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:14:18 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:14:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:14:18 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:14:18 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:14:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:14:18 --> Model "ReportModel" initialized
ERROR - 2024-03-10 13:14:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:14:39 --> Config Class Initialized
INFO - 2024-03-10 13:14:39 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:14:39 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:14:39 --> Utf8 Class Initialized
INFO - 2024-03-10 13:14:39 --> URI Class Initialized
INFO - 2024-03-10 13:14:39 --> Router Class Initialized
INFO - 2024-03-10 13:14:39 --> Output Class Initialized
INFO - 2024-03-10 13:14:39 --> Security Class Initialized
DEBUG - 2024-03-10 13:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:14:39 --> Input Class Initialized
INFO - 2024-03-10 13:14:39 --> Language Class Initialized
INFO - 2024-03-10 13:14:39 --> Loader Class Initialized
INFO - 2024-03-10 13:14:39 --> Helper loaded: url_helper
INFO - 2024-03-10 13:14:39 --> Helper loaded: file_helper
INFO - 2024-03-10 13:14:39 --> Helper loaded: form_helper
INFO - 2024-03-10 13:14:39 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:14:39 --> Controller Class Initialized
INFO - 2024-03-10 13:14:39 --> Form Validation Class Initialized
INFO - 2024-03-10 13:14:39 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:14:39 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:14:39 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:14:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:14:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:14:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:14:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:14:39 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:14:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:14:39 --> Model "ReportModel" initialized
INFO - 2024-03-10 13:14:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-10 13:14:39 --> Final output sent to browser
DEBUG - 2024-03-10 13:14:39 --> Total execution time: 0.0457
ERROR - 2024-03-10 13:14:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 13:14:45 --> Config Class Initialized
INFO - 2024-03-10 13:14:45 --> Hooks Class Initialized
DEBUG - 2024-03-10 13:14:45 --> UTF-8 Support Enabled
INFO - 2024-03-10 13:14:45 --> Utf8 Class Initialized
INFO - 2024-03-10 13:14:45 --> URI Class Initialized
INFO - 2024-03-10 13:14:45 --> Router Class Initialized
INFO - 2024-03-10 13:14:45 --> Output Class Initialized
INFO - 2024-03-10 13:14:45 --> Security Class Initialized
DEBUG - 2024-03-10 13:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 13:14:45 --> Input Class Initialized
INFO - 2024-03-10 13:14:45 --> Language Class Initialized
INFO - 2024-03-10 13:14:45 --> Loader Class Initialized
INFO - 2024-03-10 13:14:45 --> Helper loaded: url_helper
INFO - 2024-03-10 13:14:45 --> Helper loaded: file_helper
INFO - 2024-03-10 13:14:45 --> Helper loaded: form_helper
INFO - 2024-03-10 13:14:45 --> Database Driver Class Initialized
DEBUG - 2024-03-10 13:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 13:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 13:14:45 --> Controller Class Initialized
INFO - 2024-03-10 13:14:45 --> Form Validation Class Initialized
INFO - 2024-03-10 13:14:45 --> Model "MasterModel" initialized
INFO - 2024-03-10 13:14:45 --> Model "NotificationModel" initialized
INFO - 2024-03-10 13:14:45 --> Model "DashboardModel" initialized
INFO - 2024-03-10 13:14:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 13:14:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 13:14:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 13:14:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 13:14:45 --> Model "OrderModel" initialized
INFO - 2024-03-10 13:14:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 13:14:45 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:19:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:03 --> Config Class Initialized
INFO - 2024-03-10 15:19:03 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:03 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:03 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:03 --> URI Class Initialized
INFO - 2024-03-10 15:19:03 --> Router Class Initialized
INFO - 2024-03-10 15:19:03 --> Output Class Initialized
INFO - 2024-03-10 15:19:03 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:03 --> Input Class Initialized
INFO - 2024-03-10 15:19:03 --> Language Class Initialized
INFO - 2024-03-10 15:19:03 --> Loader Class Initialized
INFO - 2024-03-10 15:19:03 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:03 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:03 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:03 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:03 --> Controller Class Initialized
INFO - 2024-03-10 15:19:03 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:03 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:03 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:03 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:03 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:03 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:03 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:03 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:03 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:19:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:19:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:19:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:19:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:19:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:19:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:19:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:19:03 --> Final output sent to browser
DEBUG - 2024-03-10 15:19:03 --> Total execution time: 0.0429
ERROR - 2024-03-10 15:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:04 --> Config Class Initialized
INFO - 2024-03-10 15:19:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:04 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:04 --> URI Class Initialized
INFO - 2024-03-10 15:19:04 --> Router Class Initialized
INFO - 2024-03-10 15:19:04 --> Output Class Initialized
INFO - 2024-03-10 15:19:04 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:04 --> Input Class Initialized
INFO - 2024-03-10 15:19:04 --> Language Class Initialized
INFO - 2024-03-10 15:19:04 --> Loader Class Initialized
INFO - 2024-03-10 15:19:04 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:04 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:04 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:04 --> Controller Class Initialized
INFO - 2024-03-10 15:19:04 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:04 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:04 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:04 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:04 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:04 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:19:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:05 --> Config Class Initialized
INFO - 2024-03-10 15:19:05 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:05 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:05 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:05 --> URI Class Initialized
INFO - 2024-03-10 15:19:05 --> Router Class Initialized
INFO - 2024-03-10 15:19:05 --> Output Class Initialized
INFO - 2024-03-10 15:19:05 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:05 --> Input Class Initialized
INFO - 2024-03-10 15:19:05 --> Language Class Initialized
INFO - 2024-03-10 15:19:05 --> Loader Class Initialized
INFO - 2024-03-10 15:19:05 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:05 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:05 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:05 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:05 --> Controller Class Initialized
INFO - 2024-03-10 15:19:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:19:05 --> Final output sent to browser
DEBUG - 2024-03-10 15:19:05 --> Total execution time: 0.0137
ERROR - 2024-03-10 15:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:06 --> Config Class Initialized
INFO - 2024-03-10 15:19:06 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:06 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:06 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:06 --> URI Class Initialized
INFO - 2024-03-10 15:19:06 --> Router Class Initialized
INFO - 2024-03-10 15:19:06 --> Output Class Initialized
INFO - 2024-03-10 15:19:06 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:06 --> Input Class Initialized
INFO - 2024-03-10 15:19:06 --> Language Class Initialized
INFO - 2024-03-10 15:19:06 --> Loader Class Initialized
INFO - 2024-03-10 15:19:06 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:06 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:06 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:06 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:06 --> Controller Class Initialized
INFO - 2024-03-10 15:19:06 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:06 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:19:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:19:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:19:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:19:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:19:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:19:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 15:19:06 --> Final output sent to browser
DEBUG - 2024-03-10 15:19:06 --> Total execution time: 0.0193
ERROR - 2024-03-10 15:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:06 --> Config Class Initialized
INFO - 2024-03-10 15:19:06 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:06 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:06 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:06 --> URI Class Initialized
INFO - 2024-03-10 15:19:06 --> Router Class Initialized
INFO - 2024-03-10 15:19:06 --> Output Class Initialized
INFO - 2024-03-10 15:19:06 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:06 --> Input Class Initialized
INFO - 2024-03-10 15:19:06 --> Language Class Initialized
INFO - 2024-03-10 15:19:06 --> Loader Class Initialized
INFO - 2024-03-10 15:19:06 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:06 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:06 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:06 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:06 --> Controller Class Initialized
INFO - 2024-03-10 15:19:06 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:06 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:06 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:19:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:08 --> Config Class Initialized
INFO - 2024-03-10 15:19:08 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:08 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:08 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:08 --> URI Class Initialized
INFO - 2024-03-10 15:19:08 --> Router Class Initialized
INFO - 2024-03-10 15:19:08 --> Output Class Initialized
INFO - 2024-03-10 15:19:08 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:08 --> Input Class Initialized
INFO - 2024-03-10 15:19:08 --> Language Class Initialized
INFO - 2024-03-10 15:19:08 --> Loader Class Initialized
INFO - 2024-03-10 15:19:08 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:08 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:08 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:08 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:08 --> Controller Class Initialized
INFO - 2024-03-10 15:19:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:19:08 --> Final output sent to browser
DEBUG - 2024-03-10 15:19:08 --> Total execution time: 0.0106
ERROR - 2024-03-10 15:19:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:08 --> Config Class Initialized
INFO - 2024-03-10 15:19:08 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:08 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:08 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:08 --> URI Class Initialized
INFO - 2024-03-10 15:19:08 --> Router Class Initialized
INFO - 2024-03-10 15:19:08 --> Output Class Initialized
INFO - 2024-03-10 15:19:08 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:08 --> Input Class Initialized
INFO - 2024-03-10 15:19:08 --> Language Class Initialized
INFO - 2024-03-10 15:19:08 --> Loader Class Initialized
INFO - 2024-03-10 15:19:08 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:08 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:08 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:08 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:08 --> Controller Class Initialized
INFO - 2024-03-10 15:19:08 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:08 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:08 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:08 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:08 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:08 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:19:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:11 --> Config Class Initialized
INFO - 2024-03-10 15:19:11 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:11 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:11 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:11 --> URI Class Initialized
INFO - 2024-03-10 15:19:11 --> Router Class Initialized
INFO - 2024-03-10 15:19:11 --> Output Class Initialized
INFO - 2024-03-10 15:19:11 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:11 --> Input Class Initialized
INFO - 2024-03-10 15:19:11 --> Language Class Initialized
INFO - 2024-03-10 15:19:11 --> Loader Class Initialized
INFO - 2024-03-10 15:19:11 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:11 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:11 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:11 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:11 --> Controller Class Initialized
INFO - 2024-03-10 15:19:11 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:11 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:11 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:11 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:11 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:11 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:11 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:11 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:11 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:19:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:13 --> Config Class Initialized
INFO - 2024-03-10 15:19:13 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:13 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:13 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:13 --> URI Class Initialized
INFO - 2024-03-10 15:19:13 --> Router Class Initialized
INFO - 2024-03-10 15:19:13 --> Output Class Initialized
INFO - 2024-03-10 15:19:13 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:13 --> Input Class Initialized
INFO - 2024-03-10 15:19:13 --> Language Class Initialized
INFO - 2024-03-10 15:19:13 --> Loader Class Initialized
INFO - 2024-03-10 15:19:13 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:13 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:13 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:13 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:13 --> Controller Class Initialized
INFO - 2024-03-10 15:19:13 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:13 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:13 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:13 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:13 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:13 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:19:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:16 --> Config Class Initialized
INFO - 2024-03-10 15:19:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:16 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:16 --> URI Class Initialized
INFO - 2024-03-10 15:19:16 --> Router Class Initialized
INFO - 2024-03-10 15:19:16 --> Output Class Initialized
INFO - 2024-03-10 15:19:16 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:16 --> Input Class Initialized
INFO - 2024-03-10 15:19:16 --> Language Class Initialized
INFO - 2024-03-10 15:19:16 --> Loader Class Initialized
INFO - 2024-03-10 15:19:16 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:16 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:16 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:16 --> Controller Class Initialized
INFO - 2024-03-10 15:19:16 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:16 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 15:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 15:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 15:19:16 --> Final output sent to browser
DEBUG - 2024-03-10 15:19:16 --> Total execution time: 0.0201
ERROR - 2024-03-10 15:19:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:16 --> Config Class Initialized
INFO - 2024-03-10 15:19:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:16 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:16 --> URI Class Initialized
INFO - 2024-03-10 15:19:16 --> Router Class Initialized
INFO - 2024-03-10 15:19:16 --> Output Class Initialized
INFO - 2024-03-10 15:19:16 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:16 --> Input Class Initialized
INFO - 2024-03-10 15:19:16 --> Language Class Initialized
INFO - 2024-03-10 15:19:16 --> Loader Class Initialized
INFO - 2024-03-10 15:19:16 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:16 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:16 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:16 --> Controller Class Initialized
INFO - 2024-03-10 15:19:16 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:16 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:16 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:19:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:18 --> Config Class Initialized
INFO - 2024-03-10 15:19:18 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:18 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:18 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:18 --> URI Class Initialized
INFO - 2024-03-10 15:19:18 --> Router Class Initialized
INFO - 2024-03-10 15:19:18 --> Output Class Initialized
INFO - 2024-03-10 15:19:18 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:18 --> Input Class Initialized
INFO - 2024-03-10 15:19:18 --> Language Class Initialized
INFO - 2024-03-10 15:19:18 --> Loader Class Initialized
INFO - 2024-03-10 15:19:18 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:18 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:18 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:18 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:18 --> Controller Class Initialized
INFO - 2024-03-10 15:19:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:19:18 --> Final output sent to browser
DEBUG - 2024-03-10 15:19:18 --> Total execution time: 0.0110
ERROR - 2024-03-10 15:19:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:27 --> Config Class Initialized
INFO - 2024-03-10 15:19:27 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:27 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:27 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:27 --> URI Class Initialized
INFO - 2024-03-10 15:19:27 --> Router Class Initialized
INFO - 2024-03-10 15:19:27 --> Output Class Initialized
INFO - 2024-03-10 15:19:27 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:27 --> Input Class Initialized
INFO - 2024-03-10 15:19:27 --> Language Class Initialized
INFO - 2024-03-10 15:19:27 --> Loader Class Initialized
INFO - 2024-03-10 15:19:27 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:27 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:27 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:27 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:27 --> Controller Class Initialized
INFO - 2024-03-10 15:19:27 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:27 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:19:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:19:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:19:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:19:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:19:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:19:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 15:19:27 --> Final output sent to browser
DEBUG - 2024-03-10 15:19:27 --> Total execution time: 0.0160
ERROR - 2024-03-10 15:19:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:27 --> Config Class Initialized
INFO - 2024-03-10 15:19:27 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:27 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:27 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:27 --> URI Class Initialized
INFO - 2024-03-10 15:19:27 --> Router Class Initialized
INFO - 2024-03-10 15:19:27 --> Output Class Initialized
INFO - 2024-03-10 15:19:27 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:27 --> Input Class Initialized
INFO - 2024-03-10 15:19:27 --> Language Class Initialized
INFO - 2024-03-10 15:19:27 --> Loader Class Initialized
INFO - 2024-03-10 15:19:27 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:27 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:27 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:27 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:27 --> Controller Class Initialized
INFO - 2024-03-10 15:19:27 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:27 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:27 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:19:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:29 --> Config Class Initialized
INFO - 2024-03-10 15:19:29 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:29 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:29 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:29 --> URI Class Initialized
INFO - 2024-03-10 15:19:29 --> Router Class Initialized
INFO - 2024-03-10 15:19:29 --> Output Class Initialized
INFO - 2024-03-10 15:19:29 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:29 --> Input Class Initialized
INFO - 2024-03-10 15:19:29 --> Language Class Initialized
INFO - 2024-03-10 15:19:29 --> Loader Class Initialized
INFO - 2024-03-10 15:19:29 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:29 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:29 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:29 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:29 --> Controller Class Initialized
INFO - 2024-03-10 15:19:29 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:29 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:29 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:29 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:29 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:29 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:19:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-03-10 15:19:29 --> Final output sent to browser
DEBUG - 2024-03-10 15:19:29 --> Total execution time: 0.0154
ERROR - 2024-03-10 15:19:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:29 --> Config Class Initialized
INFO - 2024-03-10 15:19:29 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:29 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:29 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:29 --> URI Class Initialized
INFO - 2024-03-10 15:19:29 --> Router Class Initialized
INFO - 2024-03-10 15:19:29 --> Output Class Initialized
INFO - 2024-03-10 15:19:29 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:29 --> Input Class Initialized
INFO - 2024-03-10 15:19:29 --> Language Class Initialized
INFO - 2024-03-10 15:19:29 --> Loader Class Initialized
INFO - 2024-03-10 15:19:29 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:29 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:29 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:29 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:29 --> Controller Class Initialized
INFO - 2024-03-10 15:19:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:19:29 --> Final output sent to browser
DEBUG - 2024-03-10 15:19:29 --> Total execution time: 0.0108
ERROR - 2024-03-10 15:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:42 --> Config Class Initialized
INFO - 2024-03-10 15:19:42 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:42 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:42 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:42 --> URI Class Initialized
INFO - 2024-03-10 15:19:42 --> Router Class Initialized
INFO - 2024-03-10 15:19:42 --> Output Class Initialized
INFO - 2024-03-10 15:19:42 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:42 --> Input Class Initialized
INFO - 2024-03-10 15:19:42 --> Language Class Initialized
INFO - 2024-03-10 15:19:42 --> Loader Class Initialized
INFO - 2024-03-10 15:19:42 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:42 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:42 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:42 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:42 --> Controller Class Initialized
INFO - 2024-03-10 15:19:42 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:42 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:19:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:19:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:19:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:19:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:19:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:19:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-10 15:19:42 --> Final output sent to browser
DEBUG - 2024-03-10 15:19:42 --> Total execution time: 0.0162
ERROR - 2024-03-10 15:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:42 --> Config Class Initialized
INFO - 2024-03-10 15:19:42 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:42 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:42 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:42 --> URI Class Initialized
INFO - 2024-03-10 15:19:42 --> Router Class Initialized
INFO - 2024-03-10 15:19:42 --> Output Class Initialized
INFO - 2024-03-10 15:19:42 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:42 --> Input Class Initialized
INFO - 2024-03-10 15:19:42 --> Language Class Initialized
INFO - 2024-03-10 15:19:42 --> Loader Class Initialized
INFO - 2024-03-10 15:19:42 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:42 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:42 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:42 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:42 --> Controller Class Initialized
INFO - 2024-03-10 15:19:42 --> Form Validation Class Initialized
INFO - 2024-03-10 15:19:42 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:19:42 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:19:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:19:44 --> Config Class Initialized
INFO - 2024-03-10 15:19:44 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:19:44 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:19:44 --> Utf8 Class Initialized
INFO - 2024-03-10 15:19:44 --> URI Class Initialized
INFO - 2024-03-10 15:19:44 --> Router Class Initialized
INFO - 2024-03-10 15:19:44 --> Output Class Initialized
INFO - 2024-03-10 15:19:44 --> Security Class Initialized
DEBUG - 2024-03-10 15:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:19:44 --> Input Class Initialized
INFO - 2024-03-10 15:19:44 --> Language Class Initialized
INFO - 2024-03-10 15:19:44 --> Loader Class Initialized
INFO - 2024-03-10 15:19:44 --> Helper loaded: url_helper
INFO - 2024-03-10 15:19:44 --> Helper loaded: file_helper
INFO - 2024-03-10 15:19:44 --> Helper loaded: form_helper
INFO - 2024-03-10 15:19:44 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:19:44 --> Controller Class Initialized
INFO - 2024-03-10 15:19:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:19:44 --> Final output sent to browser
DEBUG - 2024-03-10 15:19:44 --> Total execution time: 0.0100
ERROR - 2024-03-10 15:20:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:16 --> Config Class Initialized
INFO - 2024-03-10 15:20:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:16 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:16 --> URI Class Initialized
INFO - 2024-03-10 15:20:16 --> Router Class Initialized
INFO - 2024-03-10 15:20:16 --> Output Class Initialized
INFO - 2024-03-10 15:20:16 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:16 --> Input Class Initialized
INFO - 2024-03-10 15:20:16 --> Language Class Initialized
INFO - 2024-03-10 15:20:16 --> Loader Class Initialized
INFO - 2024-03-10 15:20:16 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:16 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:16 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:16 --> Controller Class Initialized
INFO - 2024-03-10 15:20:16 --> Form Validation Class Initialized
INFO - 2024-03-10 15:20:16 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:20:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:20:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:20:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:20:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:20:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:20:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-10 15:20:16 --> Final output sent to browser
DEBUG - 2024-03-10 15:20:16 --> Total execution time: 0.0161
ERROR - 2024-03-10 15:20:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:16 --> Config Class Initialized
INFO - 2024-03-10 15:20:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:16 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:16 --> URI Class Initialized
INFO - 2024-03-10 15:20:16 --> Router Class Initialized
INFO - 2024-03-10 15:20:16 --> Output Class Initialized
INFO - 2024-03-10 15:20:16 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:16 --> Input Class Initialized
INFO - 2024-03-10 15:20:16 --> Language Class Initialized
INFO - 2024-03-10 15:20:16 --> Loader Class Initialized
INFO - 2024-03-10 15:20:16 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:16 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:16 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:16 --> Controller Class Initialized
INFO - 2024-03-10 15:20:16 --> Form Validation Class Initialized
INFO - 2024-03-10 15:20:16 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:20:16 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:20:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:20 --> Config Class Initialized
INFO - 2024-03-10 15:20:20 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:20 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:20 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:20 --> URI Class Initialized
INFO - 2024-03-10 15:20:20 --> Router Class Initialized
INFO - 2024-03-10 15:20:20 --> Output Class Initialized
INFO - 2024-03-10 15:20:20 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:20 --> Input Class Initialized
INFO - 2024-03-10 15:20:20 --> Language Class Initialized
INFO - 2024-03-10 15:20:20 --> Loader Class Initialized
INFO - 2024-03-10 15:20:20 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:20 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:20 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:20 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:20 --> Controller Class Initialized
INFO - 2024-03-10 15:20:20 --> Form Validation Class Initialized
INFO - 2024-03-10 15:20:20 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:20:20 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:20:20 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:20:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:20:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:20:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:20:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:20:20 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:20:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:20:20 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:20:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:20:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:20:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:20:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:20:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:20:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-10 15:20:20 --> Final output sent to browser
DEBUG - 2024-03-10 15:20:20 --> Total execution time: 0.0174
ERROR - 2024-03-10 15:20:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:22 --> Config Class Initialized
INFO - 2024-03-10 15:20:22 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:22 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:22 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:22 --> URI Class Initialized
INFO - 2024-03-10 15:20:22 --> Router Class Initialized
INFO - 2024-03-10 15:20:22 --> Output Class Initialized
INFO - 2024-03-10 15:20:22 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:22 --> Input Class Initialized
INFO - 2024-03-10 15:20:22 --> Language Class Initialized
INFO - 2024-03-10 15:20:22 --> Loader Class Initialized
INFO - 2024-03-10 15:20:22 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:22 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:22 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:22 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:22 --> Controller Class Initialized
INFO - 2024-03-10 15:20:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:20:22 --> Final output sent to browser
DEBUG - 2024-03-10 15:20:22 --> Total execution time: 0.0120
ERROR - 2024-03-10 15:20:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:22 --> Config Class Initialized
INFO - 2024-03-10 15:20:22 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:22 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:22 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:22 --> URI Class Initialized
INFO - 2024-03-10 15:20:22 --> Router Class Initialized
INFO - 2024-03-10 15:20:22 --> Output Class Initialized
INFO - 2024-03-10 15:20:22 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:22 --> Input Class Initialized
INFO - 2024-03-10 15:20:22 --> Language Class Initialized
INFO - 2024-03-10 15:20:22 --> Loader Class Initialized
INFO - 2024-03-10 15:20:22 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:22 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:22 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:22 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:22 --> Controller Class Initialized
INFO - 2024-03-10 15:20:22 --> Form Validation Class Initialized
INFO - 2024-03-10 15:20:22 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:20:22 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:20:22 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:20:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:20:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:20:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:20:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:20:22 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:20:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:20:22 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:20:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:20:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:20:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:20:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:20:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:20:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-10 15:20:22 --> Final output sent to browser
DEBUG - 2024-03-10 15:20:22 --> Total execution time: 0.0169
ERROR - 2024-03-10 15:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:26 --> Config Class Initialized
INFO - 2024-03-10 15:20:26 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:26 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:26 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:26 --> URI Class Initialized
INFO - 2024-03-10 15:20:26 --> Router Class Initialized
INFO - 2024-03-10 15:20:26 --> Output Class Initialized
INFO - 2024-03-10 15:20:26 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:26 --> Input Class Initialized
INFO - 2024-03-10 15:20:26 --> Language Class Initialized
INFO - 2024-03-10 15:20:26 --> Loader Class Initialized
INFO - 2024-03-10 15:20:26 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:26 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:26 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:26 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:26 --> Controller Class Initialized
INFO - 2024-03-10 15:20:26 --> Form Validation Class Initialized
INFO - 2024-03-10 15:20:26 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:20:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:20:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:20:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:20:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:20:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:20:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:20:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:20:26 --> Final output sent to browser
DEBUG - 2024-03-10 15:20:26 --> Total execution time: 0.0163
ERROR - 2024-03-10 15:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:26 --> Config Class Initialized
INFO - 2024-03-10 15:20:26 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:26 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:26 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:26 --> URI Class Initialized
INFO - 2024-03-10 15:20:26 --> Router Class Initialized
INFO - 2024-03-10 15:20:26 --> Output Class Initialized
INFO - 2024-03-10 15:20:26 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:26 --> Input Class Initialized
INFO - 2024-03-10 15:20:26 --> Language Class Initialized
INFO - 2024-03-10 15:20:26 --> Loader Class Initialized
INFO - 2024-03-10 15:20:26 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:26 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:26 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:26 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:26 --> Controller Class Initialized
INFO - 2024-03-10 15:20:26 --> Form Validation Class Initialized
INFO - 2024-03-10 15:20:26 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:20:26 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:28 --> Config Class Initialized
INFO - 2024-03-10 15:20:28 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:28 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:28 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:28 --> URI Class Initialized
INFO - 2024-03-10 15:20:28 --> Router Class Initialized
INFO - 2024-03-10 15:20:28 --> Output Class Initialized
INFO - 2024-03-10 15:20:28 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:28 --> Input Class Initialized
INFO - 2024-03-10 15:20:28 --> Language Class Initialized
INFO - 2024-03-10 15:20:28 --> Loader Class Initialized
INFO - 2024-03-10 15:20:28 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:28 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:28 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:28 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:28 --> Controller Class Initialized
INFO - 2024-03-10 15:20:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:20:28 --> Final output sent to browser
DEBUG - 2024-03-10 15:20:28 --> Total execution time: 0.0131
ERROR - 2024-03-10 15:20:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:30 --> Config Class Initialized
INFO - 2024-03-10 15:20:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:30 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:30 --> URI Class Initialized
INFO - 2024-03-10 15:20:30 --> Router Class Initialized
INFO - 2024-03-10 15:20:30 --> Output Class Initialized
INFO - 2024-03-10 15:20:30 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:30 --> Input Class Initialized
INFO - 2024-03-10 15:20:30 --> Language Class Initialized
INFO - 2024-03-10 15:20:30 --> Loader Class Initialized
INFO - 2024-03-10 15:20:30 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:30 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:30 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:30 --> Controller Class Initialized
INFO - 2024-03-10 15:20:30 --> Form Validation Class Initialized
INFO - 2024-03-10 15:20:30 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:20:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:20:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:20:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:20:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:20:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:20:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/index.php
INFO - 2024-03-10 15:20:30 --> Final output sent to browser
DEBUG - 2024-03-10 15:20:30 --> Total execution time: 0.0179
ERROR - 2024-03-10 15:20:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:30 --> Config Class Initialized
INFO - 2024-03-10 15:20:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:30 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:30 --> URI Class Initialized
INFO - 2024-03-10 15:20:30 --> Router Class Initialized
INFO - 2024-03-10 15:20:30 --> Output Class Initialized
INFO - 2024-03-10 15:20:30 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:30 --> Input Class Initialized
INFO - 2024-03-10 15:20:30 --> Language Class Initialized
INFO - 2024-03-10 15:20:30 --> Loader Class Initialized
INFO - 2024-03-10 15:20:30 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:30 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:30 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:30 --> Controller Class Initialized
INFO - 2024-03-10 15:20:30 --> Form Validation Class Initialized
INFO - 2024-03-10 15:20:30 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:20:30 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:20:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:31 --> Config Class Initialized
INFO - 2024-03-10 15:20:31 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:31 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:31 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:31 --> URI Class Initialized
INFO - 2024-03-10 15:20:31 --> Router Class Initialized
INFO - 2024-03-10 15:20:31 --> Output Class Initialized
INFO - 2024-03-10 15:20:31 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:31 --> Input Class Initialized
INFO - 2024-03-10 15:20:31 --> Language Class Initialized
INFO - 2024-03-10 15:20:31 --> Loader Class Initialized
INFO - 2024-03-10 15:20:31 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:31 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:31 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:31 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:31 --> Controller Class Initialized
INFO - 2024-03-10 15:20:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:20:31 --> Final output sent to browser
DEBUG - 2024-03-10 15:20:31 --> Total execution time: 0.0164
ERROR - 2024-03-10 15:20:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:50 --> Config Class Initialized
INFO - 2024-03-10 15:20:50 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:50 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:50 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:50 --> URI Class Initialized
INFO - 2024-03-10 15:20:50 --> Router Class Initialized
INFO - 2024-03-10 15:20:50 --> Output Class Initialized
INFO - 2024-03-10 15:20:50 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:50 --> Input Class Initialized
INFO - 2024-03-10 15:20:50 --> Language Class Initialized
INFO - 2024-03-10 15:20:50 --> Loader Class Initialized
INFO - 2024-03-10 15:20:50 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:50 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:50 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:50 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:50 --> Controller Class Initialized
INFO - 2024-03-10 15:20:50 --> Form Validation Class Initialized
INFO - 2024-03-10 15:20:50 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:20:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:20:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:20:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:20:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:20:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:20:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/index.php
INFO - 2024-03-10 15:20:50 --> Final output sent to browser
DEBUG - 2024-03-10 15:20:50 --> Total execution time: 0.0176
ERROR - 2024-03-10 15:20:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:50 --> Config Class Initialized
INFO - 2024-03-10 15:20:50 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:50 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:50 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:50 --> URI Class Initialized
INFO - 2024-03-10 15:20:50 --> Router Class Initialized
INFO - 2024-03-10 15:20:50 --> Output Class Initialized
INFO - 2024-03-10 15:20:50 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:50 --> Input Class Initialized
INFO - 2024-03-10 15:20:50 --> Language Class Initialized
INFO - 2024-03-10 15:20:50 --> Loader Class Initialized
INFO - 2024-03-10 15:20:50 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:50 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:50 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:50 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:50 --> Controller Class Initialized
INFO - 2024-03-10 15:20:50 --> Form Validation Class Initialized
INFO - 2024-03-10 15:20:50 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:20:50 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:20:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:20:51 --> Config Class Initialized
INFO - 2024-03-10 15:20:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:20:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:20:51 --> Utf8 Class Initialized
INFO - 2024-03-10 15:20:51 --> URI Class Initialized
INFO - 2024-03-10 15:20:51 --> Router Class Initialized
INFO - 2024-03-10 15:20:51 --> Output Class Initialized
INFO - 2024-03-10 15:20:51 --> Security Class Initialized
DEBUG - 2024-03-10 15:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:20:51 --> Input Class Initialized
INFO - 2024-03-10 15:20:51 --> Language Class Initialized
INFO - 2024-03-10 15:20:51 --> Loader Class Initialized
INFO - 2024-03-10 15:20:51 --> Helper loaded: url_helper
INFO - 2024-03-10 15:20:51 --> Helper loaded: file_helper
INFO - 2024-03-10 15:20:51 --> Helper loaded: form_helper
INFO - 2024-03-10 15:20:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:20:51 --> Controller Class Initialized
INFO - 2024-03-10 15:20:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:20:51 --> Final output sent to browser
DEBUG - 2024-03-10 15:20:51 --> Total execution time: 0.0107
ERROR - 2024-03-10 15:21:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:02 --> Config Class Initialized
INFO - 2024-03-10 15:21:02 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:02 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:02 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:02 --> URI Class Initialized
INFO - 2024-03-10 15:21:02 --> Router Class Initialized
INFO - 2024-03-10 15:21:02 --> Output Class Initialized
INFO - 2024-03-10 15:21:02 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:02 --> Input Class Initialized
INFO - 2024-03-10 15:21:02 --> Language Class Initialized
INFO - 2024-03-10 15:21:02 --> Loader Class Initialized
INFO - 2024-03-10 15:21:02 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:02 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:02 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:02 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:02 --> Controller Class Initialized
INFO - 2024-03-10 15:21:02 --> Form Validation Class Initialized
INFO - 2024-03-10 15:21:02 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:21:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:21:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:21:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:21:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:21:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:21:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:21:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:21:02 --> Final output sent to browser
DEBUG - 2024-03-10 15:21:02 --> Total execution time: 0.0184
ERROR - 2024-03-10 15:21:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:02 --> Config Class Initialized
INFO - 2024-03-10 15:21:02 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:02 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:02 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:02 --> URI Class Initialized
INFO - 2024-03-10 15:21:02 --> Router Class Initialized
INFO - 2024-03-10 15:21:02 --> Output Class Initialized
INFO - 2024-03-10 15:21:02 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:02 --> Input Class Initialized
INFO - 2024-03-10 15:21:02 --> Language Class Initialized
INFO - 2024-03-10 15:21:02 --> Loader Class Initialized
INFO - 2024-03-10 15:21:02 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:02 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:02 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:02 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:02 --> Controller Class Initialized
INFO - 2024-03-10 15:21:02 --> Form Validation Class Initialized
INFO - 2024-03-10 15:21:02 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:21:02 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:21:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:04 --> Config Class Initialized
INFO - 2024-03-10 15:21:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:04 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:04 --> URI Class Initialized
INFO - 2024-03-10 15:21:04 --> Router Class Initialized
INFO - 2024-03-10 15:21:04 --> Output Class Initialized
INFO - 2024-03-10 15:21:04 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:04 --> Input Class Initialized
INFO - 2024-03-10 15:21:04 --> Language Class Initialized
INFO - 2024-03-10 15:21:04 --> Loader Class Initialized
INFO - 2024-03-10 15:21:04 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:04 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:04 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:04 --> Controller Class Initialized
INFO - 2024-03-10 15:21:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:21:04 --> Final output sent to browser
DEBUG - 2024-03-10 15:21:04 --> Total execution time: 0.0112
ERROR - 2024-03-10 15:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:08 --> Config Class Initialized
INFO - 2024-03-10 15:21:08 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:08 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:08 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:08 --> URI Class Initialized
INFO - 2024-03-10 15:21:08 --> Router Class Initialized
INFO - 2024-03-10 15:21:08 --> Output Class Initialized
INFO - 2024-03-10 15:21:08 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:08 --> Input Class Initialized
INFO - 2024-03-10 15:21:08 --> Language Class Initialized
INFO - 2024-03-10 15:21:08 --> Loader Class Initialized
INFO - 2024-03-10 15:21:08 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:08 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:08 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:08 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:08 --> Controller Class Initialized
INFO - 2024-03-10 15:21:08 --> Form Validation Class Initialized
INFO - 2024-03-10 15:21:08 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:21:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:21:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:21:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:21:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:21:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:21:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-10 15:21:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-10 15:21:08 --> Final output sent to browser
DEBUG - 2024-03-10 15:21:08 --> Total execution time: 0.0193
ERROR - 2024-03-10 15:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:08 --> Config Class Initialized
INFO - 2024-03-10 15:21:08 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:08 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:08 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:08 --> URI Class Initialized
INFO - 2024-03-10 15:21:08 --> Router Class Initialized
INFO - 2024-03-10 15:21:08 --> Output Class Initialized
INFO - 2024-03-10 15:21:08 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:08 --> Input Class Initialized
INFO - 2024-03-10 15:21:08 --> Language Class Initialized
INFO - 2024-03-10 15:21:08 --> Loader Class Initialized
INFO - 2024-03-10 15:21:08 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:08 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:08 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:08 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:08 --> Controller Class Initialized
INFO - 2024-03-10 15:21:08 --> Form Validation Class Initialized
INFO - 2024-03-10 15:21:08 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:21:08 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:10 --> Config Class Initialized
INFO - 2024-03-10 15:21:10 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:10 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:10 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:10 --> URI Class Initialized
INFO - 2024-03-10 15:21:10 --> Router Class Initialized
INFO - 2024-03-10 15:21:10 --> Output Class Initialized
INFO - 2024-03-10 15:21:10 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:10 --> Input Class Initialized
INFO - 2024-03-10 15:21:10 --> Language Class Initialized
INFO - 2024-03-10 15:21:10 --> Loader Class Initialized
INFO - 2024-03-10 15:21:10 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:10 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:10 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:10 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:10 --> Controller Class Initialized
INFO - 2024-03-10 15:21:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:21:10 --> Final output sent to browser
DEBUG - 2024-03-10 15:21:10 --> Total execution time: 0.0110
ERROR - 2024-03-10 15:21:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:28 --> Config Class Initialized
INFO - 2024-03-10 15:21:28 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:28 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:28 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:28 --> URI Class Initialized
INFO - 2024-03-10 15:21:28 --> Router Class Initialized
INFO - 2024-03-10 15:21:28 --> Output Class Initialized
INFO - 2024-03-10 15:21:28 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:28 --> Input Class Initialized
INFO - 2024-03-10 15:21:28 --> Language Class Initialized
INFO - 2024-03-10 15:21:28 --> Loader Class Initialized
INFO - 2024-03-10 15:21:28 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:28 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:28 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:28 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:28 --> Controller Class Initialized
INFO - 2024-03-10 15:21:28 --> Form Validation Class Initialized
INFO - 2024-03-10 15:21:28 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-10 15:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-10 15:21:28 --> Final output sent to browser
DEBUG - 2024-03-10 15:21:28 --> Total execution time: 0.0168
ERROR - 2024-03-10 15:21:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:28 --> Config Class Initialized
INFO - 2024-03-10 15:21:28 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:28 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:28 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:28 --> URI Class Initialized
INFO - 2024-03-10 15:21:28 --> Router Class Initialized
INFO - 2024-03-10 15:21:28 --> Output Class Initialized
INFO - 2024-03-10 15:21:28 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:28 --> Input Class Initialized
INFO - 2024-03-10 15:21:28 --> Language Class Initialized
INFO - 2024-03-10 15:21:28 --> Loader Class Initialized
INFO - 2024-03-10 15:21:28 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:28 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:28 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:28 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:28 --> Controller Class Initialized
INFO - 2024-03-10 15:21:28 --> Form Validation Class Initialized
INFO - 2024-03-10 15:21:28 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:21:28 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:21:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:30 --> Config Class Initialized
INFO - 2024-03-10 15:21:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:30 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:30 --> URI Class Initialized
INFO - 2024-03-10 15:21:30 --> Router Class Initialized
INFO - 2024-03-10 15:21:30 --> Output Class Initialized
INFO - 2024-03-10 15:21:30 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:30 --> Input Class Initialized
INFO - 2024-03-10 15:21:30 --> Language Class Initialized
INFO - 2024-03-10 15:21:30 --> Loader Class Initialized
INFO - 2024-03-10 15:21:30 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:30 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:30 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:30 --> Controller Class Initialized
INFO - 2024-03-10 15:21:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:21:30 --> Final output sent to browser
DEBUG - 2024-03-10 15:21:30 --> Total execution time: 0.0107
ERROR - 2024-03-10 15:21:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:45 --> Config Class Initialized
INFO - 2024-03-10 15:21:45 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:45 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:45 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:45 --> URI Class Initialized
INFO - 2024-03-10 15:21:45 --> Router Class Initialized
INFO - 2024-03-10 15:21:45 --> Output Class Initialized
INFO - 2024-03-10 15:21:45 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:45 --> Input Class Initialized
INFO - 2024-03-10 15:21:45 --> Language Class Initialized
INFO - 2024-03-10 15:21:45 --> Loader Class Initialized
INFO - 2024-03-10 15:21:45 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:45 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:45 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:45 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:45 --> Controller Class Initialized
INFO - 2024-03-10 15:21:45 --> Form Validation Class Initialized
INFO - 2024-03-10 15:21:45 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:21:45 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:21:45 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:21:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:21:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:21:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:21:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:21:45 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:21:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:21:45 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-10 15:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-10 15:21:45 --> Final output sent to browser
DEBUG - 2024-03-10 15:21:45 --> Total execution time: 0.0172
ERROR - 2024-03-10 15:21:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:46 --> Config Class Initialized
INFO - 2024-03-10 15:21:46 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:46 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:46 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:46 --> URI Class Initialized
INFO - 2024-03-10 15:21:46 --> Router Class Initialized
INFO - 2024-03-10 15:21:46 --> Output Class Initialized
INFO - 2024-03-10 15:21:46 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:46 --> Input Class Initialized
INFO - 2024-03-10 15:21:46 --> Language Class Initialized
INFO - 2024-03-10 15:21:46 --> Loader Class Initialized
INFO - 2024-03-10 15:21:46 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:46 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:46 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:46 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:46 --> Controller Class Initialized
INFO - 2024-03-10 15:21:46 --> Form Validation Class Initialized
INFO - 2024-03-10 15:21:46 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:21:46 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:21:46 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:21:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:21:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:21:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:21:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:21:46 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:21:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:21:46 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:21:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:51 --> Config Class Initialized
INFO - 2024-03-10 15:21:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:51 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:51 --> URI Class Initialized
INFO - 2024-03-10 15:21:51 --> Router Class Initialized
INFO - 2024-03-10 15:21:51 --> Output Class Initialized
INFO - 2024-03-10 15:21:51 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:51 --> Input Class Initialized
INFO - 2024-03-10 15:21:51 --> Language Class Initialized
INFO - 2024-03-10 15:21:51 --> Loader Class Initialized
INFO - 2024-03-10 15:21:51 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:51 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:51 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:51 --> Controller Class Initialized
INFO - 2024-03-10 15:21:51 --> Form Validation Class Initialized
INFO - 2024-03-10 15:21:51 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:21:51 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:21:51 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:21:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:21:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:21:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:21:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:21:51 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:21:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:21:51 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:21:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:21:55 --> Config Class Initialized
INFO - 2024-03-10 15:21:55 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:21:55 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:21:55 --> Utf8 Class Initialized
INFO - 2024-03-10 15:21:55 --> URI Class Initialized
INFO - 2024-03-10 15:21:55 --> Router Class Initialized
INFO - 2024-03-10 15:21:55 --> Output Class Initialized
INFO - 2024-03-10 15:21:55 --> Security Class Initialized
DEBUG - 2024-03-10 15:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:21:55 --> Input Class Initialized
INFO - 2024-03-10 15:21:55 --> Language Class Initialized
INFO - 2024-03-10 15:21:55 --> Loader Class Initialized
INFO - 2024-03-10 15:21:55 --> Helper loaded: url_helper
INFO - 2024-03-10 15:21:55 --> Helper loaded: file_helper
INFO - 2024-03-10 15:21:55 --> Helper loaded: form_helper
INFO - 2024-03-10 15:21:55 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:21:55 --> Controller Class Initialized
INFO - 2024-03-10 15:21:55 --> Form Validation Class Initialized
INFO - 2024-03-10 15:21:55 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:21:55 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:21:55 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:21:55 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:21:55 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:21:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:21:55 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:21:55 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:21:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:21:55 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:22:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:22:00 --> Config Class Initialized
INFO - 2024-03-10 15:22:00 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:22:00 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:22:00 --> Utf8 Class Initialized
INFO - 2024-03-10 15:22:00 --> URI Class Initialized
INFO - 2024-03-10 15:22:00 --> Router Class Initialized
INFO - 2024-03-10 15:22:00 --> Output Class Initialized
INFO - 2024-03-10 15:22:00 --> Security Class Initialized
DEBUG - 2024-03-10 15:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:22:00 --> Input Class Initialized
INFO - 2024-03-10 15:22:00 --> Language Class Initialized
INFO - 2024-03-10 15:22:00 --> Loader Class Initialized
INFO - 2024-03-10 15:22:00 --> Helper loaded: url_helper
INFO - 2024-03-10 15:22:00 --> Helper loaded: file_helper
INFO - 2024-03-10 15:22:00 --> Helper loaded: form_helper
INFO - 2024-03-10 15:22:00 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:22:00 --> Controller Class Initialized
INFO - 2024-03-10 15:22:00 --> Form Validation Class Initialized
INFO - 2024-03-10 15:22:00 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:22:00 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:22:00 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:22:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:22:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:22:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:22:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:22:00 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:22:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:22:00 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:22:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:22:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:22:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:22:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:22:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:22:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-10 15:22:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-10 15:22:00 --> Final output sent to browser
DEBUG - 2024-03-10 15:22:00 --> Total execution time: 0.0202
ERROR - 2024-03-10 15:22:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:22:00 --> Config Class Initialized
INFO - 2024-03-10 15:22:00 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:22:00 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:22:00 --> Utf8 Class Initialized
INFO - 2024-03-10 15:22:00 --> URI Class Initialized
INFO - 2024-03-10 15:22:00 --> Router Class Initialized
INFO - 2024-03-10 15:22:00 --> Output Class Initialized
INFO - 2024-03-10 15:22:00 --> Security Class Initialized
DEBUG - 2024-03-10 15:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:22:00 --> Input Class Initialized
INFO - 2024-03-10 15:22:00 --> Language Class Initialized
INFO - 2024-03-10 15:22:00 --> Loader Class Initialized
INFO - 2024-03-10 15:22:00 --> Helper loaded: url_helper
INFO - 2024-03-10 15:22:00 --> Helper loaded: file_helper
INFO - 2024-03-10 15:22:00 --> Helper loaded: form_helper
INFO - 2024-03-10 15:22:00 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:22:00 --> Controller Class Initialized
INFO - 2024-03-10 15:22:00 --> Form Validation Class Initialized
INFO - 2024-03-10 15:22:01 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:22:01 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:22:01 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:22:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:22:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:22:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:22:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:22:01 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:22:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:22:01 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:22:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:22:02 --> Config Class Initialized
INFO - 2024-03-10 15:22:02 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:22:02 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:22:02 --> Utf8 Class Initialized
INFO - 2024-03-10 15:22:02 --> URI Class Initialized
INFO - 2024-03-10 15:22:02 --> Router Class Initialized
INFO - 2024-03-10 15:22:02 --> Output Class Initialized
INFO - 2024-03-10 15:22:02 --> Security Class Initialized
DEBUG - 2024-03-10 15:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:22:02 --> Input Class Initialized
INFO - 2024-03-10 15:22:02 --> Language Class Initialized
INFO - 2024-03-10 15:22:02 --> Loader Class Initialized
INFO - 2024-03-10 15:22:02 --> Helper loaded: url_helper
INFO - 2024-03-10 15:22:02 --> Helper loaded: file_helper
INFO - 2024-03-10 15:22:02 --> Helper loaded: form_helper
INFO - 2024-03-10 15:22:02 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:22:02 --> Controller Class Initialized
INFO - 2024-03-10 15:22:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:22:02 --> Final output sent to browser
DEBUG - 2024-03-10 15:22:02 --> Total execution time: 0.0111
ERROR - 2024-03-10 15:22:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:22:22 --> Config Class Initialized
INFO - 2024-03-10 15:22:22 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:22:22 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:22:22 --> Utf8 Class Initialized
INFO - 2024-03-10 15:22:22 --> URI Class Initialized
INFO - 2024-03-10 15:22:22 --> Router Class Initialized
INFO - 2024-03-10 15:22:22 --> Output Class Initialized
INFO - 2024-03-10 15:22:22 --> Security Class Initialized
DEBUG - 2024-03-10 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:22:22 --> Input Class Initialized
INFO - 2024-03-10 15:22:22 --> Language Class Initialized
INFO - 2024-03-10 15:22:22 --> Loader Class Initialized
INFO - 2024-03-10 15:22:22 --> Helper loaded: url_helper
INFO - 2024-03-10 15:22:22 --> Helper loaded: file_helper
INFO - 2024-03-10 15:22:22 --> Helper loaded: form_helper
INFO - 2024-03-10 15:22:22 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:22:22 --> Controller Class Initialized
INFO - 2024-03-10 15:22:22 --> Form Validation Class Initialized
INFO - 2024-03-10 15:22:22 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:22:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:22:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:22:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:22:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:22:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:22:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-10 15:22:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-10 15:22:22 --> Final output sent to browser
DEBUG - 2024-03-10 15:22:22 --> Total execution time: 0.0185
ERROR - 2024-03-10 15:22:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:22:22 --> Config Class Initialized
INFO - 2024-03-10 15:22:22 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:22:22 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:22:22 --> Utf8 Class Initialized
INFO - 2024-03-10 15:22:22 --> URI Class Initialized
INFO - 2024-03-10 15:22:22 --> Router Class Initialized
INFO - 2024-03-10 15:22:22 --> Output Class Initialized
INFO - 2024-03-10 15:22:22 --> Security Class Initialized
DEBUG - 2024-03-10 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:22:22 --> Input Class Initialized
INFO - 2024-03-10 15:22:22 --> Language Class Initialized
INFO - 2024-03-10 15:22:22 --> Loader Class Initialized
INFO - 2024-03-10 15:22:22 --> Helper loaded: url_helper
INFO - 2024-03-10 15:22:22 --> Helper loaded: file_helper
INFO - 2024-03-10 15:22:22 --> Helper loaded: form_helper
INFO - 2024-03-10 15:22:22 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:22:22 --> Controller Class Initialized
INFO - 2024-03-10 15:22:22 --> Form Validation Class Initialized
INFO - 2024-03-10 15:22:22 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:22:22 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:22:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:22:24 --> Config Class Initialized
INFO - 2024-03-10 15:22:24 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:22:24 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:22:24 --> Utf8 Class Initialized
INFO - 2024-03-10 15:22:24 --> URI Class Initialized
INFO - 2024-03-10 15:22:24 --> Router Class Initialized
INFO - 2024-03-10 15:22:24 --> Output Class Initialized
INFO - 2024-03-10 15:22:24 --> Security Class Initialized
DEBUG - 2024-03-10 15:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:22:24 --> Input Class Initialized
INFO - 2024-03-10 15:22:24 --> Language Class Initialized
INFO - 2024-03-10 15:22:24 --> Loader Class Initialized
INFO - 2024-03-10 15:22:24 --> Helper loaded: url_helper
INFO - 2024-03-10 15:22:24 --> Helper loaded: file_helper
INFO - 2024-03-10 15:22:24 --> Helper loaded: form_helper
INFO - 2024-03-10 15:22:24 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:22:24 --> Controller Class Initialized
INFO - 2024-03-10 15:22:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:22:24 --> Final output sent to browser
DEBUG - 2024-03-10 15:22:24 --> Total execution time: 0.0108
ERROR - 2024-03-10 15:22:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:22:37 --> Config Class Initialized
INFO - 2024-03-10 15:22:37 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:22:37 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:22:37 --> Utf8 Class Initialized
INFO - 2024-03-10 15:22:37 --> URI Class Initialized
INFO - 2024-03-10 15:22:37 --> Router Class Initialized
INFO - 2024-03-10 15:22:37 --> Output Class Initialized
INFO - 2024-03-10 15:22:37 --> Security Class Initialized
DEBUG - 2024-03-10 15:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:22:37 --> Input Class Initialized
INFO - 2024-03-10 15:22:37 --> Language Class Initialized
INFO - 2024-03-10 15:22:37 --> Loader Class Initialized
INFO - 2024-03-10 15:22:37 --> Helper loaded: url_helper
INFO - 2024-03-10 15:22:37 --> Helper loaded: file_helper
INFO - 2024-03-10 15:22:37 --> Helper loaded: form_helper
INFO - 2024-03-10 15:22:37 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:22:37 --> Controller Class Initialized
INFO - 2024-03-10 15:22:37 --> Form Validation Class Initialized
INFO - 2024-03-10 15:22:37 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:22:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:22:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:22:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:22:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:22:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:22:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-10 15:22:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-10 15:22:37 --> Final output sent to browser
DEBUG - 2024-03-10 15:22:37 --> Total execution time: 0.0179
ERROR - 2024-03-10 15:22:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:22:37 --> Config Class Initialized
INFO - 2024-03-10 15:22:37 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:22:37 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:22:37 --> Utf8 Class Initialized
INFO - 2024-03-10 15:22:37 --> URI Class Initialized
INFO - 2024-03-10 15:22:37 --> Router Class Initialized
INFO - 2024-03-10 15:22:37 --> Output Class Initialized
INFO - 2024-03-10 15:22:37 --> Security Class Initialized
DEBUG - 2024-03-10 15:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:22:37 --> Input Class Initialized
INFO - 2024-03-10 15:22:37 --> Language Class Initialized
INFO - 2024-03-10 15:22:37 --> Loader Class Initialized
INFO - 2024-03-10 15:22:37 --> Helper loaded: url_helper
INFO - 2024-03-10 15:22:37 --> Helper loaded: file_helper
INFO - 2024-03-10 15:22:37 --> Helper loaded: form_helper
INFO - 2024-03-10 15:22:37 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:22:37 --> Controller Class Initialized
INFO - 2024-03-10 15:22:37 --> Form Validation Class Initialized
INFO - 2024-03-10 15:22:37 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:22:37 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:22:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:22:39 --> Config Class Initialized
INFO - 2024-03-10 15:22:39 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:22:39 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:22:39 --> Utf8 Class Initialized
INFO - 2024-03-10 15:22:39 --> URI Class Initialized
INFO - 2024-03-10 15:22:39 --> Router Class Initialized
INFO - 2024-03-10 15:22:39 --> Output Class Initialized
INFO - 2024-03-10 15:22:39 --> Security Class Initialized
DEBUG - 2024-03-10 15:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:22:39 --> Input Class Initialized
INFO - 2024-03-10 15:22:39 --> Language Class Initialized
INFO - 2024-03-10 15:22:39 --> Loader Class Initialized
INFO - 2024-03-10 15:22:39 --> Helper loaded: url_helper
INFO - 2024-03-10 15:22:39 --> Helper loaded: file_helper
INFO - 2024-03-10 15:22:39 --> Helper loaded: form_helper
INFO - 2024-03-10 15:22:39 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:22:39 --> Controller Class Initialized
INFO - 2024-03-10 15:22:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:22:39 --> Final output sent to browser
DEBUG - 2024-03-10 15:22:39 --> Total execution time: 0.0105
ERROR - 2024-03-10 15:23:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:23:01 --> Config Class Initialized
INFO - 2024-03-10 15:23:01 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:23:01 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:23:01 --> Utf8 Class Initialized
INFO - 2024-03-10 15:23:01 --> URI Class Initialized
INFO - 2024-03-10 15:23:01 --> Router Class Initialized
INFO - 2024-03-10 15:23:01 --> Output Class Initialized
INFO - 2024-03-10 15:23:01 --> Security Class Initialized
DEBUG - 2024-03-10 15:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:23:01 --> Input Class Initialized
INFO - 2024-03-10 15:23:01 --> Language Class Initialized
INFO - 2024-03-10 15:23:01 --> Loader Class Initialized
INFO - 2024-03-10 15:23:01 --> Helper loaded: url_helper
INFO - 2024-03-10 15:23:01 --> Helper loaded: file_helper
INFO - 2024-03-10 15:23:01 --> Helper loaded: form_helper
INFO - 2024-03-10 15:23:01 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:23:01 --> Controller Class Initialized
INFO - 2024-03-10 15:23:01 --> Form Validation Class Initialized
INFO - 2024-03-10 15:23:01 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:23:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:23:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:23:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:23:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:23:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:23:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-10 15:23:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-10 15:23:01 --> Final output sent to browser
DEBUG - 2024-03-10 15:23:01 --> Total execution time: 0.0169
ERROR - 2024-03-10 15:23:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:23:01 --> Config Class Initialized
INFO - 2024-03-10 15:23:01 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:23:01 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:23:01 --> Utf8 Class Initialized
INFO - 2024-03-10 15:23:01 --> URI Class Initialized
INFO - 2024-03-10 15:23:01 --> Router Class Initialized
INFO - 2024-03-10 15:23:01 --> Output Class Initialized
INFO - 2024-03-10 15:23:01 --> Security Class Initialized
DEBUG - 2024-03-10 15:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:23:01 --> Input Class Initialized
INFO - 2024-03-10 15:23:01 --> Language Class Initialized
INFO - 2024-03-10 15:23:01 --> Loader Class Initialized
INFO - 2024-03-10 15:23:01 --> Helper loaded: url_helper
INFO - 2024-03-10 15:23:01 --> Helper loaded: file_helper
INFO - 2024-03-10 15:23:01 --> Helper loaded: form_helper
INFO - 2024-03-10 15:23:01 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:23:01 --> Controller Class Initialized
INFO - 2024-03-10 15:23:01 --> Form Validation Class Initialized
INFO - 2024-03-10 15:23:01 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:23:01 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:24:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:16 --> Config Class Initialized
INFO - 2024-03-10 15:24:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:16 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:16 --> URI Class Initialized
INFO - 2024-03-10 15:24:16 --> Router Class Initialized
INFO - 2024-03-10 15:24:16 --> Output Class Initialized
INFO - 2024-03-10 15:24:16 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:16 --> Input Class Initialized
INFO - 2024-03-10 15:24:16 --> Language Class Initialized
INFO - 2024-03-10 15:24:16 --> Loader Class Initialized
INFO - 2024-03-10 15:24:16 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:16 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:16 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:16 --> Controller Class Initialized
INFO - 2024-03-10 15:24:16 --> Form Validation Class Initialized
INFO - 2024-03-10 15:24:16 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:24:16 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:24:16 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:24:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:24:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:24:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:24:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:24:16 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:24:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:24:16 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:24:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:24:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:24:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:24:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:24:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:24:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-10 15:24:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-10 15:24:16 --> Final output sent to browser
DEBUG - 2024-03-10 15:24:16 --> Total execution time: 0.0398
ERROR - 2024-03-10 15:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:17 --> Config Class Initialized
INFO - 2024-03-10 15:24:17 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:17 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:17 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:17 --> URI Class Initialized
INFO - 2024-03-10 15:24:17 --> Router Class Initialized
INFO - 2024-03-10 15:24:17 --> Output Class Initialized
INFO - 2024-03-10 15:24:17 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:17 --> Input Class Initialized
INFO - 2024-03-10 15:24:17 --> Language Class Initialized
INFO - 2024-03-10 15:24:17 --> Loader Class Initialized
INFO - 2024-03-10 15:24:17 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:17 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:17 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:17 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:17 --> Controller Class Initialized
INFO - 2024-03-10 15:24:17 --> Form Validation Class Initialized
INFO - 2024-03-10 15:24:17 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:24:17 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:24:17 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:24:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:24:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:24:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:24:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:24:17 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:24:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:24:17 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:24:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:18 --> Config Class Initialized
INFO - 2024-03-10 15:24:18 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:18 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:18 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:18 --> URI Class Initialized
INFO - 2024-03-10 15:24:18 --> Router Class Initialized
INFO - 2024-03-10 15:24:18 --> Output Class Initialized
INFO - 2024-03-10 15:24:18 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:18 --> Input Class Initialized
INFO - 2024-03-10 15:24:18 --> Language Class Initialized
INFO - 2024-03-10 15:24:18 --> Loader Class Initialized
INFO - 2024-03-10 15:24:18 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:18 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:18 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:18 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:18 --> Controller Class Initialized
INFO - 2024-03-10 15:24:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:24:18 --> Final output sent to browser
DEBUG - 2024-03-10 15:24:18 --> Total execution time: 0.0128
ERROR - 2024-03-10 15:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:20 --> Config Class Initialized
INFO - 2024-03-10 15:24:20 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:20 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:20 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:20 --> URI Class Initialized
INFO - 2024-03-10 15:24:20 --> Router Class Initialized
INFO - 2024-03-10 15:24:20 --> Output Class Initialized
INFO - 2024-03-10 15:24:20 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:20 --> Input Class Initialized
INFO - 2024-03-10 15:24:20 --> Language Class Initialized
INFO - 2024-03-10 15:24:20 --> Loader Class Initialized
INFO - 2024-03-10 15:24:20 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:20 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:20 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:20 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:20 --> Controller Class Initialized
INFO - 2024-03-10 15:24:20 --> Form Validation Class Initialized
INFO - 2024-03-10 15:24:20 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:24:20 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:24:20 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:24:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:24:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:24:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:24:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:24:20 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:24:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:24:20 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:24:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:23 --> Config Class Initialized
INFO - 2024-03-10 15:24:23 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:23 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:23 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:23 --> URI Class Initialized
INFO - 2024-03-10 15:24:23 --> Router Class Initialized
INFO - 2024-03-10 15:24:23 --> Output Class Initialized
INFO - 2024-03-10 15:24:23 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:23 --> Input Class Initialized
INFO - 2024-03-10 15:24:23 --> Language Class Initialized
INFO - 2024-03-10 15:24:23 --> Loader Class Initialized
INFO - 2024-03-10 15:24:23 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:23 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:23 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:23 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:23 --> Controller Class Initialized
INFO - 2024-03-10 15:24:23 --> Form Validation Class Initialized
INFO - 2024-03-10 15:24:23 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:24:23 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:24:23 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:24:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:24:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:24:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:24:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:24:23 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:24:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:24:23 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:24:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:26 --> Config Class Initialized
INFO - 2024-03-10 15:24:26 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:26 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:26 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:26 --> URI Class Initialized
INFO - 2024-03-10 15:24:26 --> Router Class Initialized
INFO - 2024-03-10 15:24:26 --> Output Class Initialized
INFO - 2024-03-10 15:24:26 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:26 --> Input Class Initialized
INFO - 2024-03-10 15:24:26 --> Language Class Initialized
INFO - 2024-03-10 15:24:26 --> Loader Class Initialized
INFO - 2024-03-10 15:24:26 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:26 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:26 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:26 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:26 --> Controller Class Initialized
INFO - 2024-03-10 15:24:26 --> Form Validation Class Initialized
INFO - 2024-03-10 15:24:26 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:24:26 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:24:26 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:24:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:24:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:24:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:24:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:24:26 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:24:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:24:26 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:24:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:29 --> Config Class Initialized
INFO - 2024-03-10 15:24:29 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:29 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:29 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:29 --> URI Class Initialized
INFO - 2024-03-10 15:24:29 --> Router Class Initialized
INFO - 2024-03-10 15:24:29 --> Output Class Initialized
INFO - 2024-03-10 15:24:29 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:29 --> Input Class Initialized
INFO - 2024-03-10 15:24:29 --> Language Class Initialized
INFO - 2024-03-10 15:24:29 --> Loader Class Initialized
INFO - 2024-03-10 15:24:29 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:29 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:29 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:29 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:29 --> Controller Class Initialized
INFO - 2024-03-10 15:24:29 --> Form Validation Class Initialized
INFO - 2024-03-10 15:24:29 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:24:29 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:24:29 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:24:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:24:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:24:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:24:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:24:29 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:24:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:24:29 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:24:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:33 --> Config Class Initialized
INFO - 2024-03-10 15:24:33 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:33 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:33 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:33 --> URI Class Initialized
INFO - 2024-03-10 15:24:33 --> Router Class Initialized
INFO - 2024-03-10 15:24:33 --> Output Class Initialized
INFO - 2024-03-10 15:24:33 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:33 --> Input Class Initialized
INFO - 2024-03-10 15:24:33 --> Language Class Initialized
INFO - 2024-03-10 15:24:33 --> Loader Class Initialized
INFO - 2024-03-10 15:24:33 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:33 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:33 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:33 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:33 --> Controller Class Initialized
INFO - 2024-03-10 15:24:33 --> Form Validation Class Initialized
INFO - 2024-03-10 15:24:33 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:24:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:24:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:24:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:24:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:24:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:24:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:24:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:24:33 --> Final output sent to browser
DEBUG - 2024-03-10 15:24:33 --> Total execution time: 0.0199
ERROR - 2024-03-10 15:24:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:33 --> Config Class Initialized
INFO - 2024-03-10 15:24:33 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:33 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:33 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:33 --> URI Class Initialized
INFO - 2024-03-10 15:24:33 --> Router Class Initialized
INFO - 2024-03-10 15:24:33 --> Output Class Initialized
INFO - 2024-03-10 15:24:33 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:33 --> Input Class Initialized
INFO - 2024-03-10 15:24:33 --> Language Class Initialized
INFO - 2024-03-10 15:24:33 --> Loader Class Initialized
INFO - 2024-03-10 15:24:33 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:33 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:33 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:33 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:33 --> Controller Class Initialized
INFO - 2024-03-10 15:24:33 --> Form Validation Class Initialized
INFO - 2024-03-10 15:24:33 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:24:33 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:24:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:34 --> Config Class Initialized
INFO - 2024-03-10 15:24:34 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:34 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:34 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:34 --> URI Class Initialized
INFO - 2024-03-10 15:24:34 --> Router Class Initialized
INFO - 2024-03-10 15:24:34 --> Output Class Initialized
INFO - 2024-03-10 15:24:34 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:34 --> Input Class Initialized
INFO - 2024-03-10 15:24:34 --> Language Class Initialized
INFO - 2024-03-10 15:24:34 --> Loader Class Initialized
INFO - 2024-03-10 15:24:34 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:34 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:34 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:34 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:34 --> Controller Class Initialized
INFO - 2024-03-10 15:24:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:24:34 --> Final output sent to browser
DEBUG - 2024-03-10 15:24:34 --> Total execution time: 0.0146
ERROR - 2024-03-10 15:24:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:47 --> Config Class Initialized
INFO - 2024-03-10 15:24:47 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:47 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:47 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:47 --> URI Class Initialized
INFO - 2024-03-10 15:24:47 --> Router Class Initialized
INFO - 2024-03-10 15:24:47 --> Output Class Initialized
INFO - 2024-03-10 15:24:47 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:47 --> Input Class Initialized
INFO - 2024-03-10 15:24:47 --> Language Class Initialized
INFO - 2024-03-10 15:24:47 --> Loader Class Initialized
INFO - 2024-03-10 15:24:47 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:47 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:47 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:47 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:47 --> Controller Class Initialized
INFO - 2024-03-10 15:24:47 --> Form Validation Class Initialized
INFO - 2024-03-10 15:24:47 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:24:47 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:24:47 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:24:47 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:24:47 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:24:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:24:47 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:24:47 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:24:47 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:24:47 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:24:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:24:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:24:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:24:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:24:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:24:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-10 15:24:47 --> Final output sent to browser
DEBUG - 2024-03-10 15:24:47 --> Total execution time: 0.0317
ERROR - 2024-03-10 15:24:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:49 --> Config Class Initialized
INFO - 2024-03-10 15:24:49 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:49 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:49 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:49 --> URI Class Initialized
INFO - 2024-03-10 15:24:49 --> Router Class Initialized
INFO - 2024-03-10 15:24:49 --> Output Class Initialized
INFO - 2024-03-10 15:24:49 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:49 --> Input Class Initialized
INFO - 2024-03-10 15:24:49 --> Language Class Initialized
INFO - 2024-03-10 15:24:49 --> Loader Class Initialized
INFO - 2024-03-10 15:24:49 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:49 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:49 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:49 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:49 --> Controller Class Initialized
INFO - 2024-03-10 15:24:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:24:49 --> Final output sent to browser
DEBUG - 2024-03-10 15:24:49 --> Total execution time: 0.0133
ERROR - 2024-03-10 15:24:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:51 --> Config Class Initialized
INFO - 2024-03-10 15:24:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:51 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:51 --> URI Class Initialized
INFO - 2024-03-10 15:24:51 --> Router Class Initialized
INFO - 2024-03-10 15:24:51 --> Output Class Initialized
INFO - 2024-03-10 15:24:51 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:51 --> Input Class Initialized
INFO - 2024-03-10 15:24:51 --> Language Class Initialized
INFO - 2024-03-10 15:24:51 --> Loader Class Initialized
INFO - 2024-03-10 15:24:51 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:51 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:51 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:51 --> Controller Class Initialized
INFO - 2024-03-10 15:24:51 --> Form Validation Class Initialized
INFO - 2024-03-10 15:24:51 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:24:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:24:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:24:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:24:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:24:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:24:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:24:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:24:51 --> Final output sent to browser
DEBUG - 2024-03-10 15:24:51 --> Total execution time: 0.0214
ERROR - 2024-03-10 15:24:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:51 --> Config Class Initialized
INFO - 2024-03-10 15:24:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:51 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:51 --> URI Class Initialized
INFO - 2024-03-10 15:24:51 --> Router Class Initialized
INFO - 2024-03-10 15:24:51 --> Output Class Initialized
INFO - 2024-03-10 15:24:51 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:51 --> Input Class Initialized
INFO - 2024-03-10 15:24:51 --> Language Class Initialized
INFO - 2024-03-10 15:24:51 --> Loader Class Initialized
INFO - 2024-03-10 15:24:51 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:51 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:51 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:51 --> Controller Class Initialized
INFO - 2024-03-10 15:24:51 --> Form Validation Class Initialized
INFO - 2024-03-10 15:24:51 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:24:51 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:24:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:24:53 --> Config Class Initialized
INFO - 2024-03-10 15:24:53 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:24:53 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:24:53 --> Utf8 Class Initialized
INFO - 2024-03-10 15:24:53 --> URI Class Initialized
INFO - 2024-03-10 15:24:53 --> Router Class Initialized
INFO - 2024-03-10 15:24:53 --> Output Class Initialized
INFO - 2024-03-10 15:24:53 --> Security Class Initialized
DEBUG - 2024-03-10 15:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:24:53 --> Input Class Initialized
INFO - 2024-03-10 15:24:53 --> Language Class Initialized
INFO - 2024-03-10 15:24:53 --> Loader Class Initialized
INFO - 2024-03-10 15:24:53 --> Helper loaded: url_helper
INFO - 2024-03-10 15:24:53 --> Helper loaded: file_helper
INFO - 2024-03-10 15:24:53 --> Helper loaded: form_helper
INFO - 2024-03-10 15:24:53 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:24:53 --> Controller Class Initialized
INFO - 2024-03-10 15:24:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:24:53 --> Final output sent to browser
DEBUG - 2024-03-10 15:24:53 --> Total execution time: 0.0129
ERROR - 2024-03-10 15:25:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:08 --> Config Class Initialized
INFO - 2024-03-10 15:25:08 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:08 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:08 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:08 --> URI Class Initialized
INFO - 2024-03-10 15:25:08 --> Router Class Initialized
INFO - 2024-03-10 15:25:08 --> Output Class Initialized
INFO - 2024-03-10 15:25:08 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:08 --> Input Class Initialized
INFO - 2024-03-10 15:25:08 --> Language Class Initialized
INFO - 2024-03-10 15:25:08 --> Loader Class Initialized
INFO - 2024-03-10 15:25:08 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:08 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:08 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:08 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:08 --> Controller Class Initialized
INFO - 2024-03-10 15:25:08 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:08 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:25:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:25:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:25:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:25:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:25:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:25:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:25:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:25:08 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:08 --> Total execution time: 0.0214
ERROR - 2024-03-10 15:25:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:08 --> Config Class Initialized
INFO - 2024-03-10 15:25:08 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:08 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:08 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:08 --> URI Class Initialized
INFO - 2024-03-10 15:25:08 --> Router Class Initialized
INFO - 2024-03-10 15:25:08 --> Output Class Initialized
INFO - 2024-03-10 15:25:08 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:08 --> Input Class Initialized
INFO - 2024-03-10 15:25:08 --> Language Class Initialized
INFO - 2024-03-10 15:25:08 --> Loader Class Initialized
INFO - 2024-03-10 15:25:08 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:08 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:08 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:08 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:08 --> Controller Class Initialized
INFO - 2024-03-10 15:25:08 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:08 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:08 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:25:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:12 --> Config Class Initialized
INFO - 2024-03-10 15:25:12 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:12 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:12 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:12 --> URI Class Initialized
INFO - 2024-03-10 15:25:12 --> Router Class Initialized
INFO - 2024-03-10 15:25:12 --> Output Class Initialized
INFO - 2024-03-10 15:25:12 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:12 --> Input Class Initialized
INFO - 2024-03-10 15:25:12 --> Language Class Initialized
INFO - 2024-03-10 15:25:12 --> Loader Class Initialized
INFO - 2024-03-10 15:25:12 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:12 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:12 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:12 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:12 --> Controller Class Initialized
INFO - 2024-03-10 15:25:12 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:12 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:12 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:12 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:12 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:12 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:25:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:25:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:25:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:25:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:25:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:25:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:25:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:25:12 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:12 --> Total execution time: 0.0202
ERROR - 2024-03-10 15:25:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:14 --> Config Class Initialized
INFO - 2024-03-10 15:25:14 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:14 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:14 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:14 --> URI Class Initialized
INFO - 2024-03-10 15:25:14 --> Router Class Initialized
INFO - 2024-03-10 15:25:14 --> Output Class Initialized
INFO - 2024-03-10 15:25:14 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:14 --> Input Class Initialized
INFO - 2024-03-10 15:25:14 --> Language Class Initialized
INFO - 2024-03-10 15:25:14 --> Loader Class Initialized
INFO - 2024-03-10 15:25:14 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:14 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:14 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:14 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:14 --> Controller Class Initialized
INFO - 2024-03-10 15:25:14 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:14 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:25:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:25:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:25:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:25:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:25:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:25:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 15:25:14 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:14 --> Total execution time: 0.0258
ERROR - 2024-03-10 15:25:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:14 --> Config Class Initialized
INFO - 2024-03-10 15:25:14 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:14 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:14 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:14 --> URI Class Initialized
INFO - 2024-03-10 15:25:14 --> Router Class Initialized
INFO - 2024-03-10 15:25:14 --> Output Class Initialized
INFO - 2024-03-10 15:25:14 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:14 --> Input Class Initialized
INFO - 2024-03-10 15:25:14 --> Language Class Initialized
INFO - 2024-03-10 15:25:14 --> Loader Class Initialized
INFO - 2024-03-10 15:25:14 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:14 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:14 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:14 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:14 --> Controller Class Initialized
INFO - 2024-03-10 15:25:14 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:14 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:14 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:25:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:15 --> Config Class Initialized
INFO - 2024-03-10 15:25:15 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:15 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:15 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:15 --> URI Class Initialized
INFO - 2024-03-10 15:25:15 --> Router Class Initialized
INFO - 2024-03-10 15:25:15 --> Output Class Initialized
INFO - 2024-03-10 15:25:15 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:15 --> Input Class Initialized
INFO - 2024-03-10 15:25:15 --> Language Class Initialized
INFO - 2024-03-10 15:25:15 --> Loader Class Initialized
INFO - 2024-03-10 15:25:15 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:15 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:15 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:15 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:15 --> Controller Class Initialized
INFO - 2024-03-10 15:25:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:25:15 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:15 --> Total execution time: 0.0126
ERROR - 2024-03-10 15:25:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:17 --> Config Class Initialized
INFO - 2024-03-10 15:25:17 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:17 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:17 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:17 --> URI Class Initialized
INFO - 2024-03-10 15:25:17 --> Router Class Initialized
INFO - 2024-03-10 15:25:17 --> Output Class Initialized
INFO - 2024-03-10 15:25:17 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:17 --> Input Class Initialized
INFO - 2024-03-10 15:25:17 --> Language Class Initialized
INFO - 2024-03-10 15:25:17 --> Loader Class Initialized
INFO - 2024-03-10 15:25:17 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:17 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:17 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:17 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:17 --> Controller Class Initialized
INFO - 2024-03-10 15:25:17 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:17 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:25:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:25:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:25:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:25:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:25:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:25:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 15:25:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 15:25:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 15:25:17 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:17 --> Total execution time: 0.0226
ERROR - 2024-03-10 15:25:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:17 --> Config Class Initialized
INFO - 2024-03-10 15:25:17 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:17 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:17 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:17 --> URI Class Initialized
INFO - 2024-03-10 15:25:17 --> Router Class Initialized
INFO - 2024-03-10 15:25:17 --> Output Class Initialized
INFO - 2024-03-10 15:25:17 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:17 --> Input Class Initialized
INFO - 2024-03-10 15:25:17 --> Language Class Initialized
INFO - 2024-03-10 15:25:17 --> Loader Class Initialized
INFO - 2024-03-10 15:25:17 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:17 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:17 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:17 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:17 --> Controller Class Initialized
INFO - 2024-03-10 15:25:17 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:17 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:17 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:25:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:18 --> Config Class Initialized
INFO - 2024-03-10 15:25:18 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:18 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:18 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:18 --> URI Class Initialized
INFO - 2024-03-10 15:25:18 --> Router Class Initialized
INFO - 2024-03-10 15:25:18 --> Output Class Initialized
INFO - 2024-03-10 15:25:18 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:18 --> Input Class Initialized
INFO - 2024-03-10 15:25:18 --> Language Class Initialized
INFO - 2024-03-10 15:25:18 --> Loader Class Initialized
INFO - 2024-03-10 15:25:18 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:18 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:18 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:18 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:18 --> Controller Class Initialized
INFO - 2024-03-10 15:25:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:25:18 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:18 --> Total execution time: 0.0136
ERROR - 2024-03-10 15:25:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:19 --> Config Class Initialized
INFO - 2024-03-10 15:25:19 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:19 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:19 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:19 --> URI Class Initialized
INFO - 2024-03-10 15:25:19 --> Router Class Initialized
INFO - 2024-03-10 15:25:19 --> Output Class Initialized
INFO - 2024-03-10 15:25:19 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:19 --> Input Class Initialized
INFO - 2024-03-10 15:25:19 --> Language Class Initialized
INFO - 2024-03-10 15:25:19 --> Loader Class Initialized
INFO - 2024-03-10 15:25:19 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:19 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:19 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:19 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:19 --> Controller Class Initialized
INFO - 2024-03-10 15:25:19 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:19 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:25:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:25:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:25:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:25:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:25:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:25:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-10 15:25:19 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:19 --> Total execution time: 0.0224
ERROR - 2024-03-10 15:25:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:19 --> Config Class Initialized
INFO - 2024-03-10 15:25:19 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:19 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:19 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:19 --> URI Class Initialized
INFO - 2024-03-10 15:25:19 --> Router Class Initialized
INFO - 2024-03-10 15:25:19 --> Output Class Initialized
INFO - 2024-03-10 15:25:19 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:19 --> Input Class Initialized
INFO - 2024-03-10 15:25:19 --> Language Class Initialized
INFO - 2024-03-10 15:25:19 --> Loader Class Initialized
INFO - 2024-03-10 15:25:19 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:19 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:19 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:19 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:19 --> Controller Class Initialized
INFO - 2024-03-10 15:25:19 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:19 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:19 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:25:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:21 --> Config Class Initialized
INFO - 2024-03-10 15:25:21 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:21 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:21 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:21 --> URI Class Initialized
INFO - 2024-03-10 15:25:21 --> Router Class Initialized
INFO - 2024-03-10 15:25:21 --> Output Class Initialized
INFO - 2024-03-10 15:25:21 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:21 --> Input Class Initialized
INFO - 2024-03-10 15:25:21 --> Language Class Initialized
INFO - 2024-03-10 15:25:21 --> Loader Class Initialized
INFO - 2024-03-10 15:25:21 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:21 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:21 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:21 --> Controller Class Initialized
INFO - 2024-03-10 15:25:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:25:21 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:21 --> Total execution time: 0.0136
ERROR - 2024-03-10 15:25:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:21 --> Config Class Initialized
INFO - 2024-03-10 15:25:21 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:21 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:21 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:21 --> URI Class Initialized
INFO - 2024-03-10 15:25:21 --> Router Class Initialized
INFO - 2024-03-10 15:25:21 --> Output Class Initialized
INFO - 2024-03-10 15:25:21 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:21 --> Input Class Initialized
INFO - 2024-03-10 15:25:21 --> Language Class Initialized
INFO - 2024-03-10 15:25:21 --> Loader Class Initialized
INFO - 2024-03-10 15:25:21 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:21 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:21 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:21 --> Controller Class Initialized
INFO - 2024-03-10 15:25:21 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:21 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:21 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:21 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:21 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:21 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:25:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:25:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:25:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:25:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:25:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:25:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-10 15:25:21 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:21 --> Total execution time: 0.0238
ERROR - 2024-03-10 15:25:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:23 --> Config Class Initialized
INFO - 2024-03-10 15:25:23 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:23 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:23 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:23 --> URI Class Initialized
INFO - 2024-03-10 15:25:23 --> Router Class Initialized
INFO - 2024-03-10 15:25:23 --> Output Class Initialized
INFO - 2024-03-10 15:25:23 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:23 --> Input Class Initialized
INFO - 2024-03-10 15:25:23 --> Language Class Initialized
INFO - 2024-03-10 15:25:23 --> Loader Class Initialized
INFO - 2024-03-10 15:25:23 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:23 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:23 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:23 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:23 --> Controller Class Initialized
INFO - 2024-03-10 15:25:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:25:23 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:23 --> Total execution time: 0.0124
ERROR - 2024-03-10 15:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:24 --> Config Class Initialized
INFO - 2024-03-10 15:25:24 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:24 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:24 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:24 --> URI Class Initialized
INFO - 2024-03-10 15:25:24 --> Router Class Initialized
INFO - 2024-03-10 15:25:24 --> Output Class Initialized
INFO - 2024-03-10 15:25:24 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:24 --> Input Class Initialized
INFO - 2024-03-10 15:25:24 --> Language Class Initialized
INFO - 2024-03-10 15:25:24 --> Loader Class Initialized
INFO - 2024-03-10 15:25:24 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:24 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:24 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:24 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:24 --> Controller Class Initialized
INFO - 2024-03-10 15:25:24 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:24 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:25:24 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:24 --> Total execution time: 0.0204
ERROR - 2024-03-10 15:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:24 --> Config Class Initialized
INFO - 2024-03-10 15:25:24 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:24 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:24 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:24 --> URI Class Initialized
INFO - 2024-03-10 15:25:24 --> Router Class Initialized
INFO - 2024-03-10 15:25:24 --> Output Class Initialized
INFO - 2024-03-10 15:25:24 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:24 --> Input Class Initialized
INFO - 2024-03-10 15:25:24 --> Language Class Initialized
INFO - 2024-03-10 15:25:24 --> Loader Class Initialized
INFO - 2024-03-10 15:25:24 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:24 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:24 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:24 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:24 --> Controller Class Initialized
INFO - 2024-03-10 15:25:24 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:24 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:24 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:25:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:26 --> Config Class Initialized
INFO - 2024-03-10 15:25:26 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:26 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:26 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:26 --> URI Class Initialized
INFO - 2024-03-10 15:25:26 --> Router Class Initialized
INFO - 2024-03-10 15:25:26 --> Output Class Initialized
INFO - 2024-03-10 15:25:26 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:26 --> Input Class Initialized
INFO - 2024-03-10 15:25:26 --> Language Class Initialized
INFO - 2024-03-10 15:25:26 --> Loader Class Initialized
INFO - 2024-03-10 15:25:26 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:26 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:26 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:26 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:26 --> Controller Class Initialized
INFO - 2024-03-10 15:25:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:25:26 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:26 --> Total execution time: 0.0171
ERROR - 2024-03-10 15:25:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:30 --> Config Class Initialized
INFO - 2024-03-10 15:25:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:30 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:30 --> URI Class Initialized
INFO - 2024-03-10 15:25:30 --> Router Class Initialized
INFO - 2024-03-10 15:25:30 --> Output Class Initialized
INFO - 2024-03-10 15:25:30 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:30 --> Input Class Initialized
INFO - 2024-03-10 15:25:30 --> Language Class Initialized
INFO - 2024-03-10 15:25:30 --> Loader Class Initialized
INFO - 2024-03-10 15:25:30 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:30 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:30 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:30 --> Controller Class Initialized
INFO - 2024-03-10 15:25:30 --> Model "LoginModel" initialized
INFO - 2024-03-10 15:25:30 --> Form Validation Class Initialized
ERROR - 2024-03-10 15:25:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:30 --> Config Class Initialized
INFO - 2024-03-10 15:25:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:30 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:30 --> URI Class Initialized
INFO - 2024-03-10 15:25:30 --> Router Class Initialized
INFO - 2024-03-10 15:25:30 --> Output Class Initialized
INFO - 2024-03-10 15:25:30 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:30 --> Input Class Initialized
INFO - 2024-03-10 15:25:30 --> Language Class Initialized
INFO - 2024-03-10 15:25:30 --> Loader Class Initialized
INFO - 2024-03-10 15:25:30 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:30 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:30 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:30 --> Controller Class Initialized
INFO - 2024-03-10 15:25:30 --> Model "LoginModel" initialized
INFO - 2024-03-10 15:25:30 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-10 15:25:30 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:30 --> Total execution time: 0.0137
ERROR - 2024-03-10 15:25:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:32 --> Config Class Initialized
INFO - 2024-03-10 15:25:32 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:32 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:32 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:32 --> URI Class Initialized
INFO - 2024-03-10 15:25:32 --> Router Class Initialized
INFO - 2024-03-10 15:25:32 --> Output Class Initialized
INFO - 2024-03-10 15:25:32 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:32 --> Input Class Initialized
INFO - 2024-03-10 15:25:32 --> Language Class Initialized
INFO - 2024-03-10 15:25:32 --> Loader Class Initialized
INFO - 2024-03-10 15:25:32 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:32 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:32 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:32 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:32 --> Controller Class Initialized
INFO - 2024-03-10 15:25:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:25:32 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:32 --> Total execution time: 0.0173
ERROR - 2024-03-10 15:25:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:39 --> Config Class Initialized
INFO - 2024-03-10 15:25:39 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:39 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:39 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:39 --> URI Class Initialized
INFO - 2024-03-10 15:25:39 --> Router Class Initialized
INFO - 2024-03-10 15:25:39 --> Output Class Initialized
INFO - 2024-03-10 15:25:39 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:39 --> Input Class Initialized
INFO - 2024-03-10 15:25:39 --> Language Class Initialized
INFO - 2024-03-10 15:25:39 --> Loader Class Initialized
INFO - 2024-03-10 15:25:40 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:40 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:40 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:40 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:40 --> Controller Class Initialized
INFO - 2024-03-10 15:25:40 --> Model "LoginModel" initialized
INFO - 2024-03-10 15:25:40 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-10 15:25:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:40 --> Config Class Initialized
INFO - 2024-03-10 15:25:40 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:40 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:40 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:40 --> URI Class Initialized
INFO - 2024-03-10 15:25:40 --> Router Class Initialized
INFO - 2024-03-10 15:25:40 --> Output Class Initialized
INFO - 2024-03-10 15:25:40 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:40 --> Input Class Initialized
INFO - 2024-03-10 15:25:40 --> Language Class Initialized
INFO - 2024-03-10 15:25:40 --> Loader Class Initialized
INFO - 2024-03-10 15:25:40 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:40 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:40 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:40 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:40 --> Controller Class Initialized
INFO - 2024-03-10 15:25:40 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:40 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:25:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:25:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:25:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:25:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:25:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:25:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:25:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:25:40 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:40 --> Total execution time: 0.0245
ERROR - 2024-03-10 15:25:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:40 --> Config Class Initialized
INFO - 2024-03-10 15:25:40 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:40 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:40 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:40 --> URI Class Initialized
INFO - 2024-03-10 15:25:40 --> Router Class Initialized
INFO - 2024-03-10 15:25:40 --> Output Class Initialized
INFO - 2024-03-10 15:25:40 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:40 --> Input Class Initialized
INFO - 2024-03-10 15:25:40 --> Language Class Initialized
INFO - 2024-03-10 15:25:40 --> Loader Class Initialized
INFO - 2024-03-10 15:25:40 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:40 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:40 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:40 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:40 --> Controller Class Initialized
INFO - 2024-03-10 15:25:40 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:40 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:40 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:25:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:41 --> Config Class Initialized
INFO - 2024-03-10 15:25:41 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:41 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:41 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:41 --> URI Class Initialized
INFO - 2024-03-10 15:25:41 --> Router Class Initialized
INFO - 2024-03-10 15:25:41 --> Output Class Initialized
INFO - 2024-03-10 15:25:41 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:41 --> Input Class Initialized
INFO - 2024-03-10 15:25:41 --> Language Class Initialized
INFO - 2024-03-10 15:25:41 --> Loader Class Initialized
INFO - 2024-03-10 15:25:41 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:41 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:41 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:41 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:41 --> Controller Class Initialized
INFO - 2024-03-10 15:25:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:25:41 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:41 --> Total execution time: 0.0148
ERROR - 2024-03-10 15:25:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:46 --> Config Class Initialized
INFO - 2024-03-10 15:25:46 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:46 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:46 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:46 --> URI Class Initialized
INFO - 2024-03-10 15:25:46 --> Router Class Initialized
INFO - 2024-03-10 15:25:46 --> Output Class Initialized
INFO - 2024-03-10 15:25:46 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:46 --> Input Class Initialized
INFO - 2024-03-10 15:25:46 --> Language Class Initialized
INFO - 2024-03-10 15:25:46 --> Loader Class Initialized
INFO - 2024-03-10 15:25:46 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:46 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:46 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:46 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:46 --> Controller Class Initialized
INFO - 2024-03-10 15:25:46 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:46 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:46 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:46 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:46 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:46 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:25:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:25:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:25:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:25:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:25:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:25:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:25:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:25:46 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:46 --> Total execution time: 0.0216
ERROR - 2024-03-10 15:25:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:48 --> Config Class Initialized
INFO - 2024-03-10 15:25:48 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:48 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:48 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:48 --> URI Class Initialized
INFO - 2024-03-10 15:25:48 --> Router Class Initialized
INFO - 2024-03-10 15:25:48 --> Output Class Initialized
INFO - 2024-03-10 15:25:48 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:48 --> Input Class Initialized
INFO - 2024-03-10 15:25:48 --> Language Class Initialized
INFO - 2024-03-10 15:25:48 --> Loader Class Initialized
INFO - 2024-03-10 15:25:48 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:48 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:48 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:48 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:48 --> Controller Class Initialized
INFO - 2024-03-10 15:25:48 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:48 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:48 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:48 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:48 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:48 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:25:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:25:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:25:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:25:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:25:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:25:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-10 15:25:48 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:48 --> Total execution time: 0.0253
ERROR - 2024-03-10 15:25:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:50 --> Config Class Initialized
INFO - 2024-03-10 15:25:50 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:50 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:50 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:50 --> URI Class Initialized
INFO - 2024-03-10 15:25:50 --> Router Class Initialized
INFO - 2024-03-10 15:25:50 --> Output Class Initialized
INFO - 2024-03-10 15:25:50 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:50 --> Input Class Initialized
INFO - 2024-03-10 15:25:50 --> Language Class Initialized
INFO - 2024-03-10 15:25:50 --> Loader Class Initialized
INFO - 2024-03-10 15:25:50 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:50 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:50 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:50 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:50 --> Controller Class Initialized
INFO - 2024-03-10 15:25:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:25:50 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:50 --> Total execution time: 0.0128
ERROR - 2024-03-10 15:25:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:51 --> Config Class Initialized
INFO - 2024-03-10 15:25:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:51 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:51 --> URI Class Initialized
INFO - 2024-03-10 15:25:51 --> Router Class Initialized
INFO - 2024-03-10 15:25:51 --> Output Class Initialized
INFO - 2024-03-10 15:25:51 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:51 --> Input Class Initialized
INFO - 2024-03-10 15:25:51 --> Language Class Initialized
INFO - 2024-03-10 15:25:51 --> Loader Class Initialized
INFO - 2024-03-10 15:25:51 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:51 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:51 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:51 --> Controller Class Initialized
INFO - 2024-03-10 15:25:51 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:51 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:25:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:25:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:25:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:25:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:25:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:25:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:25:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:25:51 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:51 --> Total execution time: 0.0181
ERROR - 2024-03-10 15:25:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:51 --> Config Class Initialized
INFO - 2024-03-10 15:25:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:51 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:51 --> URI Class Initialized
INFO - 2024-03-10 15:25:51 --> Router Class Initialized
INFO - 2024-03-10 15:25:51 --> Output Class Initialized
INFO - 2024-03-10 15:25:51 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:51 --> Input Class Initialized
INFO - 2024-03-10 15:25:51 --> Language Class Initialized
INFO - 2024-03-10 15:25:51 --> Loader Class Initialized
INFO - 2024-03-10 15:25:51 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:51 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:51 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:51 --> Controller Class Initialized
INFO - 2024-03-10 15:25:51 --> Form Validation Class Initialized
INFO - 2024-03-10 15:25:51 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:25:51 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:25:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:25:53 --> Config Class Initialized
INFO - 2024-03-10 15:25:53 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:25:53 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:25:53 --> Utf8 Class Initialized
INFO - 2024-03-10 15:25:53 --> URI Class Initialized
INFO - 2024-03-10 15:25:53 --> Router Class Initialized
INFO - 2024-03-10 15:25:53 --> Output Class Initialized
INFO - 2024-03-10 15:25:53 --> Security Class Initialized
DEBUG - 2024-03-10 15:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:25:53 --> Input Class Initialized
INFO - 2024-03-10 15:25:53 --> Language Class Initialized
INFO - 2024-03-10 15:25:53 --> Loader Class Initialized
INFO - 2024-03-10 15:25:53 --> Helper loaded: url_helper
INFO - 2024-03-10 15:25:53 --> Helper loaded: file_helper
INFO - 2024-03-10 15:25:53 --> Helper loaded: form_helper
INFO - 2024-03-10 15:25:53 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:25:53 --> Controller Class Initialized
INFO - 2024-03-10 15:25:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:25:53 --> Final output sent to browser
DEBUG - 2024-03-10 15:25:53 --> Total execution time: 0.0133
ERROR - 2024-03-10 15:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:07 --> Config Class Initialized
INFO - 2024-03-10 15:26:07 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:07 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:07 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:07 --> URI Class Initialized
INFO - 2024-03-10 15:26:07 --> Router Class Initialized
INFO - 2024-03-10 15:26:07 --> Output Class Initialized
INFO - 2024-03-10 15:26:07 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:07 --> Input Class Initialized
INFO - 2024-03-10 15:26:07 --> Language Class Initialized
INFO - 2024-03-10 15:26:07 --> Loader Class Initialized
INFO - 2024-03-10 15:26:07 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:07 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:07 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:07 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:07 --> Controller Class Initialized
INFO - 2024-03-10 15:26:07 --> Form Validation Class Initialized
INFO - 2024-03-10 15:26:07 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:26:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:26:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:26:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:26:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:26:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:26:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:26:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:26:07 --> Final output sent to browser
DEBUG - 2024-03-10 15:26:07 --> Total execution time: 0.0178
ERROR - 2024-03-10 15:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:07 --> Config Class Initialized
INFO - 2024-03-10 15:26:07 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:07 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:07 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:07 --> URI Class Initialized
INFO - 2024-03-10 15:26:07 --> Router Class Initialized
INFO - 2024-03-10 15:26:07 --> Output Class Initialized
INFO - 2024-03-10 15:26:07 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:07 --> Input Class Initialized
INFO - 2024-03-10 15:26:07 --> Language Class Initialized
INFO - 2024-03-10 15:26:07 --> Loader Class Initialized
INFO - 2024-03-10 15:26:07 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:07 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:07 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:07 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:07 --> Controller Class Initialized
INFO - 2024-03-10 15:26:07 --> Form Validation Class Initialized
INFO - 2024-03-10 15:26:07 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:26:07 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:26:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:09 --> Config Class Initialized
INFO - 2024-03-10 15:26:09 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:09 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:09 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:09 --> URI Class Initialized
INFO - 2024-03-10 15:26:09 --> Router Class Initialized
INFO - 2024-03-10 15:26:09 --> Output Class Initialized
INFO - 2024-03-10 15:26:09 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:09 --> Input Class Initialized
INFO - 2024-03-10 15:26:09 --> Language Class Initialized
INFO - 2024-03-10 15:26:09 --> Loader Class Initialized
INFO - 2024-03-10 15:26:09 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:09 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:09 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:09 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:09 --> Controller Class Initialized
INFO - 2024-03-10 15:26:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:26:09 --> Final output sent to browser
DEBUG - 2024-03-10 15:26:09 --> Total execution time: 0.0127
ERROR - 2024-03-10 15:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:12 --> Config Class Initialized
INFO - 2024-03-10 15:26:12 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:12 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:12 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:12 --> URI Class Initialized
INFO - 2024-03-10 15:26:12 --> Router Class Initialized
INFO - 2024-03-10 15:26:12 --> Output Class Initialized
INFO - 2024-03-10 15:26:12 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:12 --> Input Class Initialized
INFO - 2024-03-10 15:26:12 --> Language Class Initialized
INFO - 2024-03-10 15:26:12 --> Loader Class Initialized
INFO - 2024-03-10 15:26:12 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:12 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:12 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:12 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:12 --> Controller Class Initialized
INFO - 2024-03-10 15:26:12 --> Form Validation Class Initialized
INFO - 2024-03-10 15:26:12 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:26:12 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:26:12 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:26:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:26:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:26:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:26:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:26:12 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:26:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:26:12 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:26:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:26:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:26:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:26:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:26:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:26:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-03-10 15:26:12 --> Final output sent to browser
DEBUG - 2024-03-10 15:26:12 --> Total execution time: 0.0330
ERROR - 2024-03-10 15:26:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:13 --> Config Class Initialized
INFO - 2024-03-10 15:26:13 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:13 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:13 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:13 --> URI Class Initialized
INFO - 2024-03-10 15:26:13 --> Router Class Initialized
INFO - 2024-03-10 15:26:13 --> Output Class Initialized
INFO - 2024-03-10 15:26:13 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:13 --> Input Class Initialized
INFO - 2024-03-10 15:26:13 --> Language Class Initialized
INFO - 2024-03-10 15:26:13 --> Loader Class Initialized
INFO - 2024-03-10 15:26:13 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:13 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:13 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:13 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:13 --> Controller Class Initialized
INFO - 2024-03-10 15:26:13 --> Form Validation Class Initialized
INFO - 2024-03-10 15:26:13 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:26:13 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:26:13 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:26:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:26:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:26:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:26:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:26:13 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:26:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:26:13 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:26:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:14 --> Config Class Initialized
INFO - 2024-03-10 15:26:14 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:14 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:14 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:14 --> URI Class Initialized
INFO - 2024-03-10 15:26:14 --> Router Class Initialized
INFO - 2024-03-10 15:26:14 --> Output Class Initialized
INFO - 2024-03-10 15:26:14 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:14 --> Input Class Initialized
INFO - 2024-03-10 15:26:14 --> Language Class Initialized
INFO - 2024-03-10 15:26:14 --> Loader Class Initialized
INFO - 2024-03-10 15:26:14 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:14 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:14 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:14 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:14 --> Controller Class Initialized
INFO - 2024-03-10 15:26:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:26:14 --> Final output sent to browser
DEBUG - 2024-03-10 15:26:14 --> Total execution time: 0.0124
ERROR - 2024-03-10 15:26:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:36 --> Config Class Initialized
INFO - 2024-03-10 15:26:36 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:36 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:36 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:36 --> URI Class Initialized
INFO - 2024-03-10 15:26:36 --> Router Class Initialized
INFO - 2024-03-10 15:26:36 --> Output Class Initialized
INFO - 2024-03-10 15:26:36 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:36 --> Input Class Initialized
INFO - 2024-03-10 15:26:36 --> Language Class Initialized
INFO - 2024-03-10 15:26:36 --> Loader Class Initialized
INFO - 2024-03-10 15:26:36 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:36 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:36 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:36 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:36 --> Controller Class Initialized
INFO - 2024-03-10 15:26:36 --> Form Validation Class Initialized
INFO - 2024-03-10 15:26:36 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:26:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:26:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:26:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:26:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:26:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:26:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-03-10 15:26:36 --> Final output sent to browser
DEBUG - 2024-03-10 15:26:36 --> Total execution time: 0.0179
ERROR - 2024-03-10 15:26:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:36 --> Config Class Initialized
INFO - 2024-03-10 15:26:36 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:36 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:36 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:36 --> URI Class Initialized
INFO - 2024-03-10 15:26:36 --> Router Class Initialized
INFO - 2024-03-10 15:26:36 --> Output Class Initialized
INFO - 2024-03-10 15:26:36 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:36 --> Input Class Initialized
INFO - 2024-03-10 15:26:36 --> Language Class Initialized
INFO - 2024-03-10 15:26:36 --> Loader Class Initialized
INFO - 2024-03-10 15:26:36 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:36 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:36 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:36 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:36 --> Controller Class Initialized
INFO - 2024-03-10 15:26:36 --> Form Validation Class Initialized
INFO - 2024-03-10 15:26:36 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:26:36 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:26:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:38 --> Config Class Initialized
INFO - 2024-03-10 15:26:38 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:38 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:38 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:38 --> URI Class Initialized
INFO - 2024-03-10 15:26:38 --> Router Class Initialized
INFO - 2024-03-10 15:26:38 --> Output Class Initialized
INFO - 2024-03-10 15:26:38 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:38 --> Input Class Initialized
INFO - 2024-03-10 15:26:38 --> Language Class Initialized
INFO - 2024-03-10 15:26:38 --> Loader Class Initialized
INFO - 2024-03-10 15:26:38 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:38 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:38 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:38 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:38 --> Controller Class Initialized
INFO - 2024-03-10 15:26:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:26:38 --> Final output sent to browser
DEBUG - 2024-03-10 15:26:38 --> Total execution time: 0.0118
ERROR - 2024-03-10 15:26:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:38 --> Config Class Initialized
INFO - 2024-03-10 15:26:38 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:38 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:38 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:38 --> URI Class Initialized
INFO - 2024-03-10 15:26:38 --> Router Class Initialized
INFO - 2024-03-10 15:26:38 --> Output Class Initialized
INFO - 2024-03-10 15:26:38 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:38 --> Input Class Initialized
INFO - 2024-03-10 15:26:38 --> Language Class Initialized
INFO - 2024-03-10 15:26:38 --> Loader Class Initialized
INFO - 2024-03-10 15:26:38 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:38 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:38 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:38 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:38 --> Controller Class Initialized
INFO - 2024-03-10 15:26:38 --> Form Validation Class Initialized
INFO - 2024-03-10 15:26:38 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:26:38 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:26:38 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:26:38 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:26:38 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:26:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:26:38 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:26:38 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:26:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:26:38 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:26:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-03-10 15:26:38 --> Final output sent to browser
DEBUG - 2024-03-10 15:26:38 --> Total execution time: 0.0191
ERROR - 2024-03-10 15:26:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:42 --> Config Class Initialized
INFO - 2024-03-10 15:26:42 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:42 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:42 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:42 --> URI Class Initialized
INFO - 2024-03-10 15:26:42 --> Router Class Initialized
INFO - 2024-03-10 15:26:42 --> Output Class Initialized
INFO - 2024-03-10 15:26:42 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:42 --> Input Class Initialized
INFO - 2024-03-10 15:26:42 --> Language Class Initialized
INFO - 2024-03-10 15:26:42 --> Loader Class Initialized
INFO - 2024-03-10 15:26:42 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:42 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:42 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:42 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:42 --> Controller Class Initialized
INFO - 2024-03-10 15:26:42 --> Form Validation Class Initialized
INFO - 2024-03-10 15:26:42 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:26:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:26:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:26:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:26:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:26:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:26:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:26:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:26:42 --> Final output sent to browser
DEBUG - 2024-03-10 15:26:42 --> Total execution time: 0.0228
ERROR - 2024-03-10 15:26:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:42 --> Config Class Initialized
INFO - 2024-03-10 15:26:42 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:42 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:42 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:42 --> URI Class Initialized
INFO - 2024-03-10 15:26:42 --> Router Class Initialized
INFO - 2024-03-10 15:26:42 --> Output Class Initialized
INFO - 2024-03-10 15:26:42 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:42 --> Input Class Initialized
INFO - 2024-03-10 15:26:42 --> Language Class Initialized
INFO - 2024-03-10 15:26:42 --> Loader Class Initialized
INFO - 2024-03-10 15:26:42 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:42 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:42 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:42 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:42 --> Controller Class Initialized
INFO - 2024-03-10 15:26:42 --> Form Validation Class Initialized
INFO - 2024-03-10 15:26:42 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:26:42 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:26:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:44 --> Config Class Initialized
INFO - 2024-03-10 15:26:44 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:44 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:44 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:44 --> URI Class Initialized
INFO - 2024-03-10 15:26:44 --> Router Class Initialized
INFO - 2024-03-10 15:26:44 --> Output Class Initialized
INFO - 2024-03-10 15:26:44 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:44 --> Input Class Initialized
INFO - 2024-03-10 15:26:44 --> Language Class Initialized
INFO - 2024-03-10 15:26:44 --> Loader Class Initialized
INFO - 2024-03-10 15:26:44 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:44 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:44 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:44 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:44 --> Controller Class Initialized
INFO - 2024-03-10 15:26:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:26:44 --> Final output sent to browser
DEBUG - 2024-03-10 15:26:44 --> Total execution time: 0.0147
ERROR - 2024-03-10 15:26:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:51 --> Config Class Initialized
INFO - 2024-03-10 15:26:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:51 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:51 --> URI Class Initialized
INFO - 2024-03-10 15:26:51 --> Router Class Initialized
INFO - 2024-03-10 15:26:51 --> Output Class Initialized
INFO - 2024-03-10 15:26:51 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:51 --> Input Class Initialized
INFO - 2024-03-10 15:26:51 --> Language Class Initialized
INFO - 2024-03-10 15:26:51 --> Loader Class Initialized
INFO - 2024-03-10 15:26:51 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:51 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:51 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:51 --> Controller Class Initialized
INFO - 2024-03-10 15:26:51 --> Form Validation Class Initialized
INFO - 2024-03-10 15:26:51 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:26:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:26:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:26:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:26:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:26:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:26:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:26:51 --> Final output sent to browser
DEBUG - 2024-03-10 15:26:51 --> Total execution time: 0.0378
ERROR - 2024-03-10 15:26:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:51 --> Config Class Initialized
INFO - 2024-03-10 15:26:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:51 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:51 --> URI Class Initialized
INFO - 2024-03-10 15:26:51 --> Router Class Initialized
INFO - 2024-03-10 15:26:51 --> Output Class Initialized
INFO - 2024-03-10 15:26:51 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:51 --> Input Class Initialized
INFO - 2024-03-10 15:26:51 --> Language Class Initialized
INFO - 2024-03-10 15:26:51 --> Loader Class Initialized
INFO - 2024-03-10 15:26:51 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:51 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:51 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:51 --> Controller Class Initialized
INFO - 2024-03-10 15:26:51 --> Form Validation Class Initialized
INFO - 2024-03-10 15:26:51 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:26:51 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:26:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:26:52 --> Config Class Initialized
INFO - 2024-03-10 15:26:52 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:26:52 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:26:52 --> Utf8 Class Initialized
INFO - 2024-03-10 15:26:52 --> URI Class Initialized
INFO - 2024-03-10 15:26:52 --> Router Class Initialized
INFO - 2024-03-10 15:26:52 --> Output Class Initialized
INFO - 2024-03-10 15:26:52 --> Security Class Initialized
DEBUG - 2024-03-10 15:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:26:52 --> Input Class Initialized
INFO - 2024-03-10 15:26:52 --> Language Class Initialized
INFO - 2024-03-10 15:26:53 --> Loader Class Initialized
INFO - 2024-03-10 15:26:53 --> Helper loaded: url_helper
INFO - 2024-03-10 15:26:53 --> Helper loaded: file_helper
INFO - 2024-03-10 15:26:53 --> Helper loaded: form_helper
INFO - 2024-03-10 15:26:53 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:26:53 --> Controller Class Initialized
INFO - 2024-03-10 15:26:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:26:53 --> Final output sent to browser
DEBUG - 2024-03-10 15:26:53 --> Total execution time: 0.0122
ERROR - 2024-03-10 15:27:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:10 --> Config Class Initialized
INFO - 2024-03-10 15:27:10 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:10 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:10 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:10 --> URI Class Initialized
INFO - 2024-03-10 15:27:10 --> Router Class Initialized
INFO - 2024-03-10 15:27:10 --> Output Class Initialized
INFO - 2024-03-10 15:27:10 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:10 --> Input Class Initialized
INFO - 2024-03-10 15:27:10 --> Language Class Initialized
INFO - 2024-03-10 15:27:10 --> Loader Class Initialized
INFO - 2024-03-10 15:27:10 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:10 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:10 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:10 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:10 --> Controller Class Initialized
INFO - 2024-03-10 15:27:10 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:10 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:27:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:27:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:27:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:27:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:27:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:27:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:27:10 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:10 --> Total execution time: 0.0223
ERROR - 2024-03-10 15:27:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:10 --> Config Class Initialized
INFO - 2024-03-10 15:27:10 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:10 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:10 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:10 --> URI Class Initialized
INFO - 2024-03-10 15:27:10 --> Router Class Initialized
INFO - 2024-03-10 15:27:10 --> Output Class Initialized
INFO - 2024-03-10 15:27:10 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:10 --> Input Class Initialized
INFO - 2024-03-10 15:27:10 --> Language Class Initialized
INFO - 2024-03-10 15:27:10 --> Loader Class Initialized
INFO - 2024-03-10 15:27:10 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:10 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:10 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:10 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:10 --> Controller Class Initialized
INFO - 2024-03-10 15:27:10 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:10 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:10 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:27:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:12 --> Config Class Initialized
INFO - 2024-03-10 15:27:12 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:12 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:12 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:12 --> URI Class Initialized
INFO - 2024-03-10 15:27:12 --> Router Class Initialized
INFO - 2024-03-10 15:27:12 --> Output Class Initialized
INFO - 2024-03-10 15:27:12 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:12 --> Input Class Initialized
INFO - 2024-03-10 15:27:12 --> Language Class Initialized
INFO - 2024-03-10 15:27:12 --> Loader Class Initialized
INFO - 2024-03-10 15:27:12 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:12 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:12 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:12 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:12 --> Controller Class Initialized
INFO - 2024-03-10 15:27:12 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:12 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:12 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:12 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:12 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:12 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:27:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-03-10 15:27:12 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:12 --> Total execution time: 0.0183
ERROR - 2024-03-10 15:27:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:16 --> Config Class Initialized
INFO - 2024-03-10 15:27:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:16 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:16 --> URI Class Initialized
INFO - 2024-03-10 15:27:16 --> Router Class Initialized
INFO - 2024-03-10 15:27:16 --> Output Class Initialized
INFO - 2024-03-10 15:27:16 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:16 --> Input Class Initialized
INFO - 2024-03-10 15:27:16 --> Language Class Initialized
INFO - 2024-03-10 15:27:16 --> Loader Class Initialized
INFO - 2024-03-10 15:27:16 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:16 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:16 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:16 --> Controller Class Initialized
INFO - 2024-03-10 15:27:16 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:16 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:27:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:27:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:27:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:27:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:27:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:27:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:27:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:27:16 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:16 --> Total execution time: 0.0273
ERROR - 2024-03-10 15:27:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:16 --> Config Class Initialized
INFO - 2024-03-10 15:27:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:16 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:16 --> URI Class Initialized
INFO - 2024-03-10 15:27:16 --> Router Class Initialized
INFO - 2024-03-10 15:27:16 --> Output Class Initialized
INFO - 2024-03-10 15:27:16 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:16 --> Input Class Initialized
INFO - 2024-03-10 15:27:16 --> Language Class Initialized
INFO - 2024-03-10 15:27:16 --> Loader Class Initialized
INFO - 2024-03-10 15:27:16 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:16 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:16 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:16 --> Controller Class Initialized
INFO - 2024-03-10 15:27:16 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:16 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:16 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:27:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:18 --> Config Class Initialized
INFO - 2024-03-10 15:27:18 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:18 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:18 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:18 --> URI Class Initialized
INFO - 2024-03-10 15:27:18 --> Router Class Initialized
INFO - 2024-03-10 15:27:18 --> Output Class Initialized
INFO - 2024-03-10 15:27:18 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:18 --> Input Class Initialized
INFO - 2024-03-10 15:27:18 --> Language Class Initialized
INFO - 2024-03-10 15:27:18 --> Loader Class Initialized
INFO - 2024-03-10 15:27:18 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:18 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:18 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:18 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:18 --> Controller Class Initialized
INFO - 2024-03-10 15:27:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:27:18 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:18 --> Total execution time: 0.0134
ERROR - 2024-03-10 15:27:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:23 --> Config Class Initialized
INFO - 2024-03-10 15:27:23 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:23 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:23 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:23 --> URI Class Initialized
INFO - 2024-03-10 15:27:23 --> Router Class Initialized
INFO - 2024-03-10 15:27:23 --> Output Class Initialized
INFO - 2024-03-10 15:27:23 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:23 --> Input Class Initialized
INFO - 2024-03-10 15:27:23 --> Language Class Initialized
INFO - 2024-03-10 15:27:23 --> Loader Class Initialized
INFO - 2024-03-10 15:27:23 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:23 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:23 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:23 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:23 --> Controller Class Initialized
INFO - 2024-03-10 15:27:23 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:23 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:27:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:27:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:27:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:27:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:27:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:27:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-10 15:27:23 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:23 --> Total execution time: 0.0209
ERROR - 2024-03-10 15:27:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:23 --> Config Class Initialized
INFO - 2024-03-10 15:27:23 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:23 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:23 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:23 --> URI Class Initialized
INFO - 2024-03-10 15:27:23 --> Router Class Initialized
INFO - 2024-03-10 15:27:23 --> Output Class Initialized
INFO - 2024-03-10 15:27:23 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:23 --> Input Class Initialized
INFO - 2024-03-10 15:27:23 --> Language Class Initialized
INFO - 2024-03-10 15:27:23 --> Loader Class Initialized
INFO - 2024-03-10 15:27:23 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:23 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:23 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:23 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:23 --> Controller Class Initialized
INFO - 2024-03-10 15:27:23 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:23 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:23 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:27:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:25 --> Config Class Initialized
INFO - 2024-03-10 15:27:25 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:25 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:25 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:25 --> URI Class Initialized
INFO - 2024-03-10 15:27:25 --> Router Class Initialized
INFO - 2024-03-10 15:27:25 --> Output Class Initialized
INFO - 2024-03-10 15:27:25 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:25 --> Input Class Initialized
INFO - 2024-03-10 15:27:25 --> Language Class Initialized
INFO - 2024-03-10 15:27:25 --> Loader Class Initialized
INFO - 2024-03-10 15:27:25 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:25 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:25 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:25 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:25 --> Controller Class Initialized
INFO - 2024-03-10 15:27:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:27:25 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:25 --> Total execution time: 0.0119
ERROR - 2024-03-10 15:27:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:27 --> Config Class Initialized
INFO - 2024-03-10 15:27:27 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:27 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:27 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:27 --> URI Class Initialized
INFO - 2024-03-10 15:27:27 --> Router Class Initialized
INFO - 2024-03-10 15:27:27 --> Output Class Initialized
INFO - 2024-03-10 15:27:27 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:27 --> Input Class Initialized
INFO - 2024-03-10 15:27:27 --> Language Class Initialized
INFO - 2024-03-10 15:27:27 --> Loader Class Initialized
INFO - 2024-03-10 15:27:27 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:27 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:27 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:27 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:27 --> Controller Class Initialized
INFO - 2024-03-10 15:27:27 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:27 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:27 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:27 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:27 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:27 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:27:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:29 --> Config Class Initialized
INFO - 2024-03-10 15:27:29 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:29 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:29 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:29 --> URI Class Initialized
INFO - 2024-03-10 15:27:29 --> Router Class Initialized
INFO - 2024-03-10 15:27:29 --> Output Class Initialized
INFO - 2024-03-10 15:27:29 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:29 --> Input Class Initialized
INFO - 2024-03-10 15:27:29 --> Language Class Initialized
INFO - 2024-03-10 15:27:29 --> Loader Class Initialized
INFO - 2024-03-10 15:27:29 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:29 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:29 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:29 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:29 --> Controller Class Initialized
INFO - 2024-03-10 15:27:29 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:29 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:27:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:27:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:27:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:27:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:27:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:27:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:27:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:27:29 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:29 --> Total execution time: 0.0207
ERROR - 2024-03-10 15:27:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:29 --> Config Class Initialized
INFO - 2024-03-10 15:27:29 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:29 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:29 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:29 --> URI Class Initialized
INFO - 2024-03-10 15:27:29 --> Router Class Initialized
INFO - 2024-03-10 15:27:29 --> Output Class Initialized
INFO - 2024-03-10 15:27:29 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:29 --> Input Class Initialized
INFO - 2024-03-10 15:27:29 --> Language Class Initialized
INFO - 2024-03-10 15:27:29 --> Loader Class Initialized
INFO - 2024-03-10 15:27:29 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:29 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:29 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:29 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:29 --> Controller Class Initialized
INFO - 2024-03-10 15:27:29 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:29 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:29 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:27:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:31 --> Config Class Initialized
INFO - 2024-03-10 15:27:31 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:31 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:31 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:31 --> URI Class Initialized
INFO - 2024-03-10 15:27:31 --> Router Class Initialized
INFO - 2024-03-10 15:27:31 --> Output Class Initialized
INFO - 2024-03-10 15:27:31 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:31 --> Input Class Initialized
INFO - 2024-03-10 15:27:31 --> Language Class Initialized
INFO - 2024-03-10 15:27:31 --> Loader Class Initialized
INFO - 2024-03-10 15:27:31 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:31 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:31 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:31 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:31 --> Controller Class Initialized
INFO - 2024-03-10 15:27:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:27:31 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:31 --> Total execution time: 0.0128
ERROR - 2024-03-10 15:27:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:33 --> Config Class Initialized
INFO - 2024-03-10 15:27:33 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:33 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:33 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:33 --> URI Class Initialized
INFO - 2024-03-10 15:27:33 --> Router Class Initialized
INFO - 2024-03-10 15:27:33 --> Output Class Initialized
INFO - 2024-03-10 15:27:33 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:33 --> Input Class Initialized
INFO - 2024-03-10 15:27:33 --> Language Class Initialized
INFO - 2024-03-10 15:27:33 --> Loader Class Initialized
INFO - 2024-03-10 15:27:33 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:33 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:33 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:33 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:33 --> Controller Class Initialized
INFO - 2024-03-10 15:27:33 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:33 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:27:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:27:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:27:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:27:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:27:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:27:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/index.php
INFO - 2024-03-10 15:27:33 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:33 --> Total execution time: 0.0207
ERROR - 2024-03-10 15:27:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:33 --> Config Class Initialized
INFO - 2024-03-10 15:27:33 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:33 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:33 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:33 --> URI Class Initialized
INFO - 2024-03-10 15:27:33 --> Router Class Initialized
INFO - 2024-03-10 15:27:33 --> Output Class Initialized
INFO - 2024-03-10 15:27:33 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:33 --> Input Class Initialized
INFO - 2024-03-10 15:27:33 --> Language Class Initialized
INFO - 2024-03-10 15:27:33 --> Loader Class Initialized
INFO - 2024-03-10 15:27:33 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:33 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:33 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:33 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:33 --> Controller Class Initialized
INFO - 2024-03-10 15:27:33 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:33 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:33 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:27:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:34 --> Config Class Initialized
INFO - 2024-03-10 15:27:34 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:34 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:34 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:34 --> URI Class Initialized
INFO - 2024-03-10 15:27:34 --> Router Class Initialized
INFO - 2024-03-10 15:27:34 --> Output Class Initialized
INFO - 2024-03-10 15:27:34 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:34 --> Input Class Initialized
INFO - 2024-03-10 15:27:34 --> Language Class Initialized
INFO - 2024-03-10 15:27:34 --> Loader Class Initialized
INFO - 2024-03-10 15:27:34 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:34 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:34 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:34 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:34 --> Controller Class Initialized
INFO - 2024-03-10 15:27:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:27:34 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:34 --> Total execution time: 0.0155
ERROR - 2024-03-10 15:27:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:45 --> Config Class Initialized
INFO - 2024-03-10 15:27:45 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:45 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:45 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:45 --> URI Class Initialized
INFO - 2024-03-10 15:27:45 --> Router Class Initialized
INFO - 2024-03-10 15:27:45 --> Output Class Initialized
INFO - 2024-03-10 15:27:45 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:45 --> Input Class Initialized
INFO - 2024-03-10 15:27:45 --> Language Class Initialized
INFO - 2024-03-10 15:27:45 --> Loader Class Initialized
INFO - 2024-03-10 15:27:45 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:45 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:45 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:45 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:45 --> Controller Class Initialized
INFO - 2024-03-10 15:27:45 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:45 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:27:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:27:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:27:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:27:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:27:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:27:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/index.php
INFO - 2024-03-10 15:27:45 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:45 --> Total execution time: 0.0181
ERROR - 2024-03-10 15:27:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:45 --> Config Class Initialized
INFO - 2024-03-10 15:27:45 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:45 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:45 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:45 --> URI Class Initialized
INFO - 2024-03-10 15:27:45 --> Router Class Initialized
INFO - 2024-03-10 15:27:45 --> Output Class Initialized
INFO - 2024-03-10 15:27:45 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:45 --> Input Class Initialized
INFO - 2024-03-10 15:27:45 --> Language Class Initialized
INFO - 2024-03-10 15:27:45 --> Loader Class Initialized
INFO - 2024-03-10 15:27:45 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:45 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:45 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:45 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:45 --> Controller Class Initialized
INFO - 2024-03-10 15:27:45 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:45 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:45 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:27:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:52 --> Config Class Initialized
INFO - 2024-03-10 15:27:52 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:52 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:52 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:52 --> URI Class Initialized
INFO - 2024-03-10 15:27:52 --> Router Class Initialized
INFO - 2024-03-10 15:27:52 --> Output Class Initialized
INFO - 2024-03-10 15:27:52 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:52 --> Input Class Initialized
INFO - 2024-03-10 15:27:52 --> Language Class Initialized
INFO - 2024-03-10 15:27:52 --> Loader Class Initialized
INFO - 2024-03-10 15:27:52 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:52 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:52 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:52 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:52 --> Controller Class Initialized
INFO - 2024-03-10 15:27:52 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:52 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:27:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:27:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:27:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:27:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:27:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:27:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:27:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:27:52 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:52 --> Total execution time: 0.0221
ERROR - 2024-03-10 15:27:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:52 --> Config Class Initialized
INFO - 2024-03-10 15:27:52 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:52 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:52 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:52 --> URI Class Initialized
INFO - 2024-03-10 15:27:52 --> Router Class Initialized
INFO - 2024-03-10 15:27:52 --> Output Class Initialized
INFO - 2024-03-10 15:27:52 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:52 --> Input Class Initialized
INFO - 2024-03-10 15:27:52 --> Language Class Initialized
INFO - 2024-03-10 15:27:52 --> Loader Class Initialized
INFO - 2024-03-10 15:27:52 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:52 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:52 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:52 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:52 --> Controller Class Initialized
INFO - 2024-03-10 15:27:52 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:52 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:52 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:27:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:54 --> Config Class Initialized
INFO - 2024-03-10 15:27:54 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:54 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:54 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:54 --> URI Class Initialized
INFO - 2024-03-10 15:27:54 --> Router Class Initialized
INFO - 2024-03-10 15:27:54 --> Output Class Initialized
INFO - 2024-03-10 15:27:54 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:54 --> Input Class Initialized
INFO - 2024-03-10 15:27:54 --> Language Class Initialized
INFO - 2024-03-10 15:27:54 --> Loader Class Initialized
INFO - 2024-03-10 15:27:54 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:54 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:54 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:54 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:54 --> Controller Class Initialized
INFO - 2024-03-10 15:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:27:54 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:54 --> Total execution time: 0.0128
ERROR - 2024-03-10 15:27:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:27:54 --> Config Class Initialized
INFO - 2024-03-10 15:27:54 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:27:54 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:27:54 --> Utf8 Class Initialized
INFO - 2024-03-10 15:27:54 --> URI Class Initialized
INFO - 2024-03-10 15:27:54 --> Router Class Initialized
INFO - 2024-03-10 15:27:54 --> Output Class Initialized
INFO - 2024-03-10 15:27:54 --> Security Class Initialized
DEBUG - 2024-03-10 15:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:27:54 --> Input Class Initialized
INFO - 2024-03-10 15:27:54 --> Language Class Initialized
INFO - 2024-03-10 15:27:54 --> Loader Class Initialized
INFO - 2024-03-10 15:27:54 --> Helper loaded: url_helper
INFO - 2024-03-10 15:27:54 --> Helper loaded: file_helper
INFO - 2024-03-10 15:27:54 --> Helper loaded: form_helper
INFO - 2024-03-10 15:27:54 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:27:54 --> Controller Class Initialized
INFO - 2024-03-10 15:27:54 --> Form Validation Class Initialized
INFO - 2024-03-10 15:27:54 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:27:54 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:27:54 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:27:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:27:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:27:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:27:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:27:54 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:27:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:27:54 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:27:54 --> Final output sent to browser
DEBUG - 2024-03-10 15:27:54 --> Total execution time: 0.0269
ERROR - 2024-03-10 15:31:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:00 --> Config Class Initialized
INFO - 2024-03-10 15:31:00 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:00 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:00 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:00 --> URI Class Initialized
INFO - 2024-03-10 15:31:00 --> Router Class Initialized
INFO - 2024-03-10 15:31:00 --> Output Class Initialized
INFO - 2024-03-10 15:31:00 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:00 --> Input Class Initialized
INFO - 2024-03-10 15:31:00 --> Language Class Initialized
INFO - 2024-03-10 15:31:00 --> Loader Class Initialized
INFO - 2024-03-10 15:31:00 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:00 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:00 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:00 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:00 --> Controller Class Initialized
INFO - 2024-03-10 15:31:00 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:00 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:31:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:31:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:31:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:31:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:31:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:31:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:31:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:31:00 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:00 --> Total execution time: 0.0269
ERROR - 2024-03-10 15:31:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:00 --> Config Class Initialized
INFO - 2024-03-10 15:31:00 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:00 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:00 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:00 --> URI Class Initialized
INFO - 2024-03-10 15:31:00 --> Router Class Initialized
INFO - 2024-03-10 15:31:00 --> Output Class Initialized
INFO - 2024-03-10 15:31:00 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:00 --> Input Class Initialized
INFO - 2024-03-10 15:31:00 --> Language Class Initialized
INFO - 2024-03-10 15:31:00 --> Loader Class Initialized
INFO - 2024-03-10 15:31:00 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:00 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:00 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:00 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:00 --> Controller Class Initialized
INFO - 2024-03-10 15:31:00 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:00 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:00 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:02 --> Config Class Initialized
INFO - 2024-03-10 15:31:02 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:02 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:02 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:02 --> URI Class Initialized
INFO - 2024-03-10 15:31:02 --> Router Class Initialized
INFO - 2024-03-10 15:31:02 --> Output Class Initialized
INFO - 2024-03-10 15:31:02 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:02 --> Input Class Initialized
INFO - 2024-03-10 15:31:02 --> Language Class Initialized
INFO - 2024-03-10 15:31:02 --> Loader Class Initialized
INFO - 2024-03-10 15:31:02 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:02 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:02 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:02 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:02 --> Controller Class Initialized
INFO - 2024-03-10 15:31:02 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:02 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:31:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:31:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:31:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:31:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:31:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:31:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-03-10 15:31:02 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:02 --> Total execution time: 0.0168
ERROR - 2024-03-10 15:31:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:02 --> Config Class Initialized
INFO - 2024-03-10 15:31:02 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:02 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:02 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:02 --> URI Class Initialized
INFO - 2024-03-10 15:31:02 --> Router Class Initialized
INFO - 2024-03-10 15:31:02 --> Output Class Initialized
INFO - 2024-03-10 15:31:02 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:02 --> Input Class Initialized
INFO - 2024-03-10 15:31:02 --> Language Class Initialized
INFO - 2024-03-10 15:31:02 --> Loader Class Initialized
INFO - 2024-03-10 15:31:02 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:02 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:02 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:02 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:02 --> Controller Class Initialized
INFO - 2024-03-10 15:31:02 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:02 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:02 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:04 --> Config Class Initialized
INFO - 2024-03-10 15:31:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:04 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:04 --> URI Class Initialized
INFO - 2024-03-10 15:31:04 --> Router Class Initialized
INFO - 2024-03-10 15:31:04 --> Output Class Initialized
INFO - 2024-03-10 15:31:04 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:04 --> Input Class Initialized
INFO - 2024-03-10 15:31:04 --> Language Class Initialized
INFO - 2024-03-10 15:31:04 --> Loader Class Initialized
INFO - 2024-03-10 15:31:04 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:04 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:04 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:04 --> Controller Class Initialized
INFO - 2024-03-10 15:31:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:31:04 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:04 --> Total execution time: 0.0147
ERROR - 2024-03-10 15:31:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:05 --> Config Class Initialized
INFO - 2024-03-10 15:31:05 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:05 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:05 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:05 --> URI Class Initialized
INFO - 2024-03-10 15:31:05 --> Router Class Initialized
INFO - 2024-03-10 15:31:05 --> Output Class Initialized
INFO - 2024-03-10 15:31:05 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:05 --> Input Class Initialized
INFO - 2024-03-10 15:31:05 --> Language Class Initialized
INFO - 2024-03-10 15:31:05 --> Loader Class Initialized
INFO - 2024-03-10 15:31:05 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:05 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:05 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:05 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:05 --> Controller Class Initialized
INFO - 2024-03-10 15:31:05 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:05 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-03-10 15:31:05 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:05 --> Total execution time: 0.0213
ERROR - 2024-03-10 15:31:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:05 --> Config Class Initialized
INFO - 2024-03-10 15:31:05 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:05 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:05 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:05 --> URI Class Initialized
INFO - 2024-03-10 15:31:05 --> Router Class Initialized
INFO - 2024-03-10 15:31:05 --> Output Class Initialized
INFO - 2024-03-10 15:31:05 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:05 --> Input Class Initialized
INFO - 2024-03-10 15:31:05 --> Language Class Initialized
INFO - 2024-03-10 15:31:05 --> Loader Class Initialized
INFO - 2024-03-10 15:31:05 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:05 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:05 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:05 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:05 --> Controller Class Initialized
INFO - 2024-03-10 15:31:05 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:05 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:05 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:08 --> Config Class Initialized
INFO - 2024-03-10 15:31:08 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:08 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:08 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:08 --> URI Class Initialized
INFO - 2024-03-10 15:31:08 --> Router Class Initialized
INFO - 2024-03-10 15:31:08 --> Output Class Initialized
INFO - 2024-03-10 15:31:08 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:08 --> Input Class Initialized
INFO - 2024-03-10 15:31:08 --> Language Class Initialized
INFO - 2024-03-10 15:31:08 --> Loader Class Initialized
INFO - 2024-03-10 15:31:08 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:08 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:08 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:08 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:08 --> Controller Class Initialized
INFO - 2024-03-10 15:31:08 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:08 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:08 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:08 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:08 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:08 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:11 --> Config Class Initialized
INFO - 2024-03-10 15:31:11 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:11 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:11 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:11 --> URI Class Initialized
INFO - 2024-03-10 15:31:11 --> Router Class Initialized
INFO - 2024-03-10 15:31:11 --> Output Class Initialized
INFO - 2024-03-10 15:31:11 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:11 --> Input Class Initialized
INFO - 2024-03-10 15:31:11 --> Language Class Initialized
INFO - 2024-03-10 15:31:11 --> Loader Class Initialized
INFO - 2024-03-10 15:31:11 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:11 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:11 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:11 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:11 --> Controller Class Initialized
INFO - 2024-03-10 15:31:11 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:11 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:11 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:11 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:11 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:11 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:11 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:11 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:11 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:12 --> Config Class Initialized
INFO - 2024-03-10 15:31:12 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:12 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:12 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:12 --> URI Class Initialized
INFO - 2024-03-10 15:31:12 --> Router Class Initialized
INFO - 2024-03-10 15:31:12 --> Output Class Initialized
INFO - 2024-03-10 15:31:12 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:12 --> Input Class Initialized
INFO - 2024-03-10 15:31:12 --> Language Class Initialized
INFO - 2024-03-10 15:31:12 --> Loader Class Initialized
INFO - 2024-03-10 15:31:12 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:12 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:12 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:12 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:12 --> Controller Class Initialized
INFO - 2024-03-10 15:31:12 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:12 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:31:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:31:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:31:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:31:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:31:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:31:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:31:12 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:12 --> Total execution time: 0.0198
ERROR - 2024-03-10 15:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:12 --> Config Class Initialized
INFO - 2024-03-10 15:31:12 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:12 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:12 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:12 --> URI Class Initialized
INFO - 2024-03-10 15:31:12 --> Router Class Initialized
INFO - 2024-03-10 15:31:12 --> Output Class Initialized
INFO - 2024-03-10 15:31:12 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:12 --> Input Class Initialized
INFO - 2024-03-10 15:31:12 --> Language Class Initialized
INFO - 2024-03-10 15:31:12 --> Loader Class Initialized
INFO - 2024-03-10 15:31:12 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:12 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:12 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:12 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:12 --> Controller Class Initialized
INFO - 2024-03-10 15:31:12 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:12 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:12 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:14 --> Config Class Initialized
INFO - 2024-03-10 15:31:14 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:14 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:14 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:14 --> URI Class Initialized
INFO - 2024-03-10 15:31:14 --> Router Class Initialized
INFO - 2024-03-10 15:31:14 --> Output Class Initialized
INFO - 2024-03-10 15:31:14 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:14 --> Input Class Initialized
INFO - 2024-03-10 15:31:14 --> Language Class Initialized
INFO - 2024-03-10 15:31:14 --> Loader Class Initialized
INFO - 2024-03-10 15:31:14 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:14 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:14 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:14 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:14 --> Controller Class Initialized
INFO - 2024-03-10 15:31:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:31:14 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:14 --> Total execution time: 0.0149
ERROR - 2024-03-10 15:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:15 --> Config Class Initialized
INFO - 2024-03-10 15:31:15 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:15 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:15 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:15 --> URI Class Initialized
INFO - 2024-03-10 15:31:15 --> Router Class Initialized
INFO - 2024-03-10 15:31:15 --> Output Class Initialized
INFO - 2024-03-10 15:31:15 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:15 --> Input Class Initialized
INFO - 2024-03-10 15:31:15 --> Language Class Initialized
INFO - 2024-03-10 15:31:15 --> Loader Class Initialized
INFO - 2024-03-10 15:31:15 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:15 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:15 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:15 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:15 --> Controller Class Initialized
INFO - 2024-03-10 15:31:15 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:15 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:31:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:31:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:31:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:31:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:31:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:31:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:31:15 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:15 --> Total execution time: 0.0181
ERROR - 2024-03-10 15:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:15 --> Config Class Initialized
INFO - 2024-03-10 15:31:15 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:15 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:15 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:15 --> URI Class Initialized
INFO - 2024-03-10 15:31:15 --> Router Class Initialized
INFO - 2024-03-10 15:31:15 --> Output Class Initialized
INFO - 2024-03-10 15:31:15 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:15 --> Input Class Initialized
INFO - 2024-03-10 15:31:15 --> Language Class Initialized
INFO - 2024-03-10 15:31:15 --> Loader Class Initialized
INFO - 2024-03-10 15:31:15 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:15 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:15 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:15 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:15 --> Controller Class Initialized
INFO - 2024-03-10 15:31:15 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:15 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:15 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:18 --> Config Class Initialized
INFO - 2024-03-10 15:31:18 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:18 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:18 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:18 --> URI Class Initialized
INFO - 2024-03-10 15:31:18 --> Router Class Initialized
INFO - 2024-03-10 15:31:18 --> Output Class Initialized
INFO - 2024-03-10 15:31:18 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:18 --> Input Class Initialized
INFO - 2024-03-10 15:31:18 --> Language Class Initialized
INFO - 2024-03-10 15:31:18 --> Loader Class Initialized
INFO - 2024-03-10 15:31:18 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:18 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:18 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:18 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:18 --> Controller Class Initialized
INFO - 2024-03-10 15:31:18 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:18 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:18 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:18 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:18 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:18 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:18 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:18 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:18 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:21 --> Config Class Initialized
INFO - 2024-03-10 15:31:21 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:21 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:21 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:21 --> URI Class Initialized
INFO - 2024-03-10 15:31:21 --> Router Class Initialized
INFO - 2024-03-10 15:31:21 --> Output Class Initialized
INFO - 2024-03-10 15:31:21 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:21 --> Input Class Initialized
INFO - 2024-03-10 15:31:21 --> Language Class Initialized
INFO - 2024-03-10 15:31:21 --> Loader Class Initialized
INFO - 2024-03-10 15:31:21 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:21 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:21 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:22 --> Controller Class Initialized
INFO - 2024-03-10 15:31:22 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:22 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:31:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:31:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:31:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:31:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:31:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:31:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-10 15:31:22 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:22 --> Total execution time: 0.0207
ERROR - 2024-03-10 15:31:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:22 --> Config Class Initialized
INFO - 2024-03-10 15:31:22 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:22 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:22 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:22 --> URI Class Initialized
INFO - 2024-03-10 15:31:22 --> Router Class Initialized
INFO - 2024-03-10 15:31:22 --> Output Class Initialized
INFO - 2024-03-10 15:31:22 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:22 --> Input Class Initialized
INFO - 2024-03-10 15:31:22 --> Language Class Initialized
INFO - 2024-03-10 15:31:22 --> Loader Class Initialized
INFO - 2024-03-10 15:31:22 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:22 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:22 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:22 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:22 --> Controller Class Initialized
INFO - 2024-03-10 15:31:22 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:22 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:22 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:23 --> Config Class Initialized
INFO - 2024-03-10 15:31:23 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:23 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:23 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:23 --> URI Class Initialized
INFO - 2024-03-10 15:31:23 --> Router Class Initialized
INFO - 2024-03-10 15:31:23 --> Output Class Initialized
INFO - 2024-03-10 15:31:23 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:23 --> Input Class Initialized
INFO - 2024-03-10 15:31:23 --> Language Class Initialized
INFO - 2024-03-10 15:31:23 --> Loader Class Initialized
INFO - 2024-03-10 15:31:23 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:23 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:23 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:23 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:23 --> Controller Class Initialized
INFO - 2024-03-10 15:31:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:31:23 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:23 --> Total execution time: 0.0118
ERROR - 2024-03-10 15:31:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:24 --> Config Class Initialized
INFO - 2024-03-10 15:31:24 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:24 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:24 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:24 --> URI Class Initialized
INFO - 2024-03-10 15:31:24 --> Router Class Initialized
INFO - 2024-03-10 15:31:24 --> Output Class Initialized
INFO - 2024-03-10 15:31:24 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:24 --> Input Class Initialized
INFO - 2024-03-10 15:31:24 --> Language Class Initialized
INFO - 2024-03-10 15:31:24 --> Loader Class Initialized
INFO - 2024-03-10 15:31:24 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:24 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:24 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:24 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:24 --> Controller Class Initialized
INFO - 2024-03-10 15:31:24 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:24 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:31:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:31:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:31:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:31:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:31:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:31:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-10 15:31:24 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:24 --> Total execution time: 0.0169
ERROR - 2024-03-10 15:31:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:24 --> Config Class Initialized
INFO - 2024-03-10 15:31:24 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:24 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:24 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:24 --> URI Class Initialized
INFO - 2024-03-10 15:31:24 --> Router Class Initialized
INFO - 2024-03-10 15:31:24 --> Output Class Initialized
INFO - 2024-03-10 15:31:24 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:24 --> Input Class Initialized
INFO - 2024-03-10 15:31:24 --> Language Class Initialized
INFO - 2024-03-10 15:31:24 --> Loader Class Initialized
INFO - 2024-03-10 15:31:24 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:24 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:24 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:24 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:24 --> Controller Class Initialized
INFO - 2024-03-10 15:31:24 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:24 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:24 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:29 --> Config Class Initialized
INFO - 2024-03-10 15:31:29 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:29 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:29 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:29 --> URI Class Initialized
INFO - 2024-03-10 15:31:29 --> Router Class Initialized
INFO - 2024-03-10 15:31:29 --> Output Class Initialized
INFO - 2024-03-10 15:31:29 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:29 --> Input Class Initialized
INFO - 2024-03-10 15:31:29 --> Language Class Initialized
INFO - 2024-03-10 15:31:29 --> Loader Class Initialized
INFO - 2024-03-10 15:31:29 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:29 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:29 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:29 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:29 --> Controller Class Initialized
INFO - 2024-03-10 15:31:29 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:29 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:29 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:29 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:29 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:29 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:31 --> Config Class Initialized
INFO - 2024-03-10 15:31:31 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:31 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:31 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:31 --> URI Class Initialized
INFO - 2024-03-10 15:31:31 --> Router Class Initialized
INFO - 2024-03-10 15:31:31 --> Output Class Initialized
INFO - 2024-03-10 15:31:31 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:31 --> Input Class Initialized
INFO - 2024-03-10 15:31:31 --> Language Class Initialized
INFO - 2024-03-10 15:31:31 --> Loader Class Initialized
INFO - 2024-03-10 15:31:31 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:31 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:31 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:31 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:31 --> Controller Class Initialized
INFO - 2024-03-10 15:31:31 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:31 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:31 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:31 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:31 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:31 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:31 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:31 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:31 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:31 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:35 --> Config Class Initialized
INFO - 2024-03-10 15:31:35 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:35 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:35 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:35 --> URI Class Initialized
INFO - 2024-03-10 15:31:35 --> Router Class Initialized
INFO - 2024-03-10 15:31:35 --> Output Class Initialized
INFO - 2024-03-10 15:31:35 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:35 --> Input Class Initialized
INFO - 2024-03-10 15:31:35 --> Language Class Initialized
INFO - 2024-03-10 15:31:35 --> Loader Class Initialized
INFO - 2024-03-10 15:31:35 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:35 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:35 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:35 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:35 --> Controller Class Initialized
INFO - 2024-03-10 15:31:35 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:35 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:31:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:31:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:31:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:31:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:31:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:31:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:31:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:31:35 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:35 --> Total execution time: 0.0224
ERROR - 2024-03-10 15:31:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:35 --> Config Class Initialized
INFO - 2024-03-10 15:31:35 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:35 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:35 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:35 --> URI Class Initialized
INFO - 2024-03-10 15:31:35 --> Router Class Initialized
INFO - 2024-03-10 15:31:35 --> Output Class Initialized
INFO - 2024-03-10 15:31:35 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:35 --> Input Class Initialized
INFO - 2024-03-10 15:31:35 --> Language Class Initialized
INFO - 2024-03-10 15:31:35 --> Loader Class Initialized
INFO - 2024-03-10 15:31:35 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:35 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:35 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:35 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:35 --> Controller Class Initialized
INFO - 2024-03-10 15:31:35 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:35 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:35 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:36 --> Config Class Initialized
INFO - 2024-03-10 15:31:36 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:36 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:36 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:36 --> URI Class Initialized
INFO - 2024-03-10 15:31:36 --> Router Class Initialized
INFO - 2024-03-10 15:31:36 --> Output Class Initialized
INFO - 2024-03-10 15:31:36 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:36 --> Input Class Initialized
INFO - 2024-03-10 15:31:36 --> Language Class Initialized
INFO - 2024-03-10 15:31:36 --> Loader Class Initialized
INFO - 2024-03-10 15:31:36 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:36 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:36 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:36 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:36 --> Controller Class Initialized
INFO - 2024-03-10 15:31:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:31:36 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:36 --> Total execution time: 0.0170
ERROR - 2024-03-10 15:31:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:42 --> Config Class Initialized
INFO - 2024-03-10 15:31:42 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:42 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:42 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:42 --> URI Class Initialized
INFO - 2024-03-10 15:31:42 --> Router Class Initialized
INFO - 2024-03-10 15:31:42 --> Output Class Initialized
INFO - 2024-03-10 15:31:42 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:42 --> Input Class Initialized
INFO - 2024-03-10 15:31:42 --> Language Class Initialized
INFO - 2024-03-10 15:31:42 --> Loader Class Initialized
INFO - 2024-03-10 15:31:42 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:42 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:42 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:42 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:42 --> Controller Class Initialized
INFO - 2024-03-10 15:31:42 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:42 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:31:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:31:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:31:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:31:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:31:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:31:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/index.php
INFO - 2024-03-10 15:31:42 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:42 --> Total execution time: 0.0230
ERROR - 2024-03-10 15:31:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:42 --> Config Class Initialized
INFO - 2024-03-10 15:31:42 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:42 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:42 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:42 --> URI Class Initialized
INFO - 2024-03-10 15:31:42 --> Router Class Initialized
INFO - 2024-03-10 15:31:42 --> Output Class Initialized
INFO - 2024-03-10 15:31:42 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:42 --> Input Class Initialized
INFO - 2024-03-10 15:31:42 --> Language Class Initialized
INFO - 2024-03-10 15:31:42 --> Loader Class Initialized
INFO - 2024-03-10 15:31:42 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:42 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:42 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:42 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:42 --> Controller Class Initialized
INFO - 2024-03-10 15:31:42 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:42 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:42 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:44 --> Config Class Initialized
INFO - 2024-03-10 15:31:44 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:44 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:44 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:44 --> URI Class Initialized
INFO - 2024-03-10 15:31:44 --> Router Class Initialized
INFO - 2024-03-10 15:31:44 --> Output Class Initialized
INFO - 2024-03-10 15:31:44 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:44 --> Input Class Initialized
INFO - 2024-03-10 15:31:44 --> Language Class Initialized
INFO - 2024-03-10 15:31:44 --> Loader Class Initialized
INFO - 2024-03-10 15:31:44 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:44 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:44 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:44 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:44 --> Controller Class Initialized
INFO - 2024-03-10 15:31:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:31:44 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:44 --> Total execution time: 0.0145
ERROR - 2024-03-10 15:31:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:45 --> Config Class Initialized
INFO - 2024-03-10 15:31:45 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:45 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:45 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:45 --> URI Class Initialized
INFO - 2024-03-10 15:31:45 --> Router Class Initialized
INFO - 2024-03-10 15:31:45 --> Output Class Initialized
INFO - 2024-03-10 15:31:45 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:45 --> Input Class Initialized
INFO - 2024-03-10 15:31:45 --> Language Class Initialized
INFO - 2024-03-10 15:31:45 --> Loader Class Initialized
INFO - 2024-03-10 15:31:45 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:45 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:45 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:45 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:45 --> Controller Class Initialized
INFO - 2024-03-10 15:31:45 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:45 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:31:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:31:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:31:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:31:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:31:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:31:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:31:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:31:45 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:45 --> Total execution time: 0.0206
ERROR - 2024-03-10 15:31:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:45 --> Config Class Initialized
INFO - 2024-03-10 15:31:45 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:45 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:45 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:45 --> URI Class Initialized
INFO - 2024-03-10 15:31:45 --> Router Class Initialized
INFO - 2024-03-10 15:31:45 --> Output Class Initialized
INFO - 2024-03-10 15:31:45 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:45 --> Input Class Initialized
INFO - 2024-03-10 15:31:45 --> Language Class Initialized
INFO - 2024-03-10 15:31:45 --> Loader Class Initialized
INFO - 2024-03-10 15:31:45 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:45 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:45 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:45 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:45 --> Controller Class Initialized
INFO - 2024-03-10 15:31:45 --> Form Validation Class Initialized
INFO - 2024-03-10 15:31:45 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:31:45 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:31:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:31:47 --> Config Class Initialized
INFO - 2024-03-10 15:31:47 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:31:47 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:31:47 --> Utf8 Class Initialized
INFO - 2024-03-10 15:31:47 --> URI Class Initialized
INFO - 2024-03-10 15:31:47 --> Router Class Initialized
INFO - 2024-03-10 15:31:47 --> Output Class Initialized
INFO - 2024-03-10 15:31:47 --> Security Class Initialized
DEBUG - 2024-03-10 15:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:31:47 --> Input Class Initialized
INFO - 2024-03-10 15:31:47 --> Language Class Initialized
INFO - 2024-03-10 15:31:47 --> Loader Class Initialized
INFO - 2024-03-10 15:31:47 --> Helper loaded: url_helper
INFO - 2024-03-10 15:31:47 --> Helper loaded: file_helper
INFO - 2024-03-10 15:31:47 --> Helper loaded: form_helper
INFO - 2024-03-10 15:31:47 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:31:47 --> Controller Class Initialized
INFO - 2024-03-10 15:31:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:31:47 --> Final output sent to browser
DEBUG - 2024-03-10 15:31:47 --> Total execution time: 0.0199
ERROR - 2024-03-10 15:35:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:14 --> Config Class Initialized
INFO - 2024-03-10 15:35:14 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:14 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:14 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:14 --> URI Class Initialized
INFO - 2024-03-10 15:35:14 --> Router Class Initialized
INFO - 2024-03-10 15:35:14 --> Output Class Initialized
INFO - 2024-03-10 15:35:14 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:14 --> Input Class Initialized
INFO - 2024-03-10 15:35:14 --> Language Class Initialized
INFO - 2024-03-10 15:35:14 --> Loader Class Initialized
INFO - 2024-03-10 15:35:14 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:14 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:14 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:14 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:14 --> Controller Class Initialized
INFO - 2024-03-10 15:35:14 --> Form Validation Class Initialized
INFO - 2024-03-10 15:35:14 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:35:14 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:35:14 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:35:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:35:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:35:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:35:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:35:14 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:35:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:35:14 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:35:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:35:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:35:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:35:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:35:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:35:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:35:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:35:14 --> Final output sent to browser
DEBUG - 2024-03-10 15:35:14 --> Total execution time: 0.0246
ERROR - 2024-03-10 15:35:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:15 --> Config Class Initialized
INFO - 2024-03-10 15:35:15 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:15 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:15 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:15 --> URI Class Initialized
INFO - 2024-03-10 15:35:15 --> Router Class Initialized
INFO - 2024-03-10 15:35:15 --> Output Class Initialized
INFO - 2024-03-10 15:35:15 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:15 --> Input Class Initialized
INFO - 2024-03-10 15:35:15 --> Language Class Initialized
INFO - 2024-03-10 15:35:15 --> Loader Class Initialized
INFO - 2024-03-10 15:35:15 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:15 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:15 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:15 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:15 --> Controller Class Initialized
INFO - 2024-03-10 15:35:15 --> Form Validation Class Initialized
INFO - 2024-03-10 15:35:15 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:35:15 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:35:15 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:35:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:35:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:35:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:35:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:35:15 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:35:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:35:15 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:35:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:16 --> Config Class Initialized
INFO - 2024-03-10 15:35:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:16 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:16 --> URI Class Initialized
INFO - 2024-03-10 15:35:16 --> Router Class Initialized
INFO - 2024-03-10 15:35:16 --> Output Class Initialized
INFO - 2024-03-10 15:35:16 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:16 --> Input Class Initialized
INFO - 2024-03-10 15:35:16 --> Language Class Initialized
INFO - 2024-03-10 15:35:16 --> Loader Class Initialized
INFO - 2024-03-10 15:35:16 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:16 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:16 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:16 --> Controller Class Initialized
INFO - 2024-03-10 15:35:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:35:16 --> Final output sent to browser
DEBUG - 2024-03-10 15:35:16 --> Total execution time: 0.0131
ERROR - 2024-03-10 15:35:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:17 --> Config Class Initialized
INFO - 2024-03-10 15:35:17 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:17 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:17 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:17 --> URI Class Initialized
INFO - 2024-03-10 15:35:17 --> Router Class Initialized
INFO - 2024-03-10 15:35:17 --> Output Class Initialized
INFO - 2024-03-10 15:35:17 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:17 --> Input Class Initialized
INFO - 2024-03-10 15:35:17 --> Language Class Initialized
INFO - 2024-03-10 15:35:17 --> Loader Class Initialized
INFO - 2024-03-10 15:35:17 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:17 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:17 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:17 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:17 --> Controller Class Initialized
INFO - 2024-03-10 15:35:17 --> Form Validation Class Initialized
INFO - 2024-03-10 15:35:17 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:35:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:35:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:35:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:35:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:35:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:35:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:35:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:35:17 --> Final output sent to browser
DEBUG - 2024-03-10 15:35:17 --> Total execution time: 0.0189
ERROR - 2024-03-10 15:35:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:17 --> Config Class Initialized
INFO - 2024-03-10 15:35:17 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:17 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:17 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:17 --> URI Class Initialized
INFO - 2024-03-10 15:35:17 --> Router Class Initialized
INFO - 2024-03-10 15:35:17 --> Output Class Initialized
INFO - 2024-03-10 15:35:17 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:17 --> Input Class Initialized
INFO - 2024-03-10 15:35:17 --> Language Class Initialized
INFO - 2024-03-10 15:35:17 --> Loader Class Initialized
INFO - 2024-03-10 15:35:17 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:17 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:17 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:17 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:17 --> Controller Class Initialized
INFO - 2024-03-10 15:35:17 --> Form Validation Class Initialized
INFO - 2024-03-10 15:35:17 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:35:17 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:35:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:21 --> Config Class Initialized
INFO - 2024-03-10 15:35:21 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:21 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:21 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:21 --> URI Class Initialized
INFO - 2024-03-10 15:35:21 --> Router Class Initialized
INFO - 2024-03-10 15:35:21 --> Output Class Initialized
INFO - 2024-03-10 15:35:21 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:21 --> Input Class Initialized
INFO - 2024-03-10 15:35:21 --> Language Class Initialized
INFO - 2024-03-10 15:35:21 --> Loader Class Initialized
INFO - 2024-03-10 15:35:21 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:21 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:21 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:21 --> Controller Class Initialized
INFO - 2024-03-10 15:35:21 --> Form Validation Class Initialized
INFO - 2024-03-10 15:35:21 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:35:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:35:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:35:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:35:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:35:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:35:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-10 15:35:21 --> Final output sent to browser
DEBUG - 2024-03-10 15:35:21 --> Total execution time: 0.0234
ERROR - 2024-03-10 15:35:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:21 --> Config Class Initialized
INFO - 2024-03-10 15:35:21 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:21 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:21 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:21 --> URI Class Initialized
INFO - 2024-03-10 15:35:21 --> Router Class Initialized
INFO - 2024-03-10 15:35:21 --> Output Class Initialized
INFO - 2024-03-10 15:35:21 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:21 --> Input Class Initialized
INFO - 2024-03-10 15:35:21 --> Language Class Initialized
INFO - 2024-03-10 15:35:21 --> Loader Class Initialized
INFO - 2024-03-10 15:35:21 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:21 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:21 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:21 --> Controller Class Initialized
INFO - 2024-03-10 15:35:21 --> Form Validation Class Initialized
INFO - 2024-03-10 15:35:21 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:35:21 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:35:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:23 --> Config Class Initialized
INFO - 2024-03-10 15:35:23 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:23 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:23 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:23 --> URI Class Initialized
INFO - 2024-03-10 15:35:23 --> Router Class Initialized
INFO - 2024-03-10 15:35:23 --> Output Class Initialized
INFO - 2024-03-10 15:35:23 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:23 --> Input Class Initialized
INFO - 2024-03-10 15:35:23 --> Language Class Initialized
INFO - 2024-03-10 15:35:23 --> Loader Class Initialized
INFO - 2024-03-10 15:35:23 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:23 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:23 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:23 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:23 --> Controller Class Initialized
INFO - 2024-03-10 15:35:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:35:23 --> Final output sent to browser
DEBUG - 2024-03-10 15:35:23 --> Total execution time: 0.0135
ERROR - 2024-03-10 15:35:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:26 --> Config Class Initialized
INFO - 2024-03-10 15:35:26 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:26 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:26 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:26 --> URI Class Initialized
INFO - 2024-03-10 15:35:26 --> Router Class Initialized
INFO - 2024-03-10 15:35:26 --> Output Class Initialized
INFO - 2024-03-10 15:35:26 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:26 --> Input Class Initialized
INFO - 2024-03-10 15:35:26 --> Language Class Initialized
INFO - 2024-03-10 15:35:26 --> Loader Class Initialized
INFO - 2024-03-10 15:35:26 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:26 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:26 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:26 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:26 --> Controller Class Initialized
INFO - 2024-03-10 15:35:26 --> Form Validation Class Initialized
INFO - 2024-03-10 15:35:26 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:35:26 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:35:26 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:35:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:35:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:35:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:35:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:35:26 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:35:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:35:26 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:35:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:28 --> Config Class Initialized
INFO - 2024-03-10 15:35:28 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:28 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:28 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:28 --> URI Class Initialized
INFO - 2024-03-10 15:35:28 --> Router Class Initialized
INFO - 2024-03-10 15:35:28 --> Output Class Initialized
INFO - 2024-03-10 15:35:28 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:28 --> Input Class Initialized
INFO - 2024-03-10 15:35:28 --> Language Class Initialized
INFO - 2024-03-10 15:35:28 --> Loader Class Initialized
INFO - 2024-03-10 15:35:28 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:28 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:28 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:28 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:28 --> Controller Class Initialized
INFO - 2024-03-10 15:35:28 --> Form Validation Class Initialized
INFO - 2024-03-10 15:35:28 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:35:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:35:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:35:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:35:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:35:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:35:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-03-10 15:35:28 --> Final output sent to browser
DEBUG - 2024-03-10 15:35:28 --> Total execution time: 0.0190
ERROR - 2024-03-10 15:35:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:28 --> Config Class Initialized
INFO - 2024-03-10 15:35:28 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:28 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:28 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:28 --> URI Class Initialized
INFO - 2024-03-10 15:35:28 --> Router Class Initialized
INFO - 2024-03-10 15:35:28 --> Output Class Initialized
INFO - 2024-03-10 15:35:28 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:28 --> Input Class Initialized
INFO - 2024-03-10 15:35:28 --> Language Class Initialized
INFO - 2024-03-10 15:35:28 --> Loader Class Initialized
INFO - 2024-03-10 15:35:28 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:28 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:28 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:28 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:28 --> Controller Class Initialized
INFO - 2024-03-10 15:35:28 --> Form Validation Class Initialized
INFO - 2024-03-10 15:35:28 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:35:28 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:35:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:30 --> Config Class Initialized
INFO - 2024-03-10 15:35:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:30 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:30 --> URI Class Initialized
INFO - 2024-03-10 15:35:30 --> Router Class Initialized
INFO - 2024-03-10 15:35:30 --> Output Class Initialized
INFO - 2024-03-10 15:35:30 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:30 --> Input Class Initialized
INFO - 2024-03-10 15:35:30 --> Language Class Initialized
INFO - 2024-03-10 15:35:30 --> Loader Class Initialized
INFO - 2024-03-10 15:35:30 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:30 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:30 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:30 --> Controller Class Initialized
INFO - 2024-03-10 15:35:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:35:30 --> Final output sent to browser
DEBUG - 2024-03-10 15:35:30 --> Total execution time: 0.0132
ERROR - 2024-03-10 15:35:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:35:30 --> Config Class Initialized
INFO - 2024-03-10 15:35:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:35:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:35:30 --> Utf8 Class Initialized
INFO - 2024-03-10 15:35:30 --> URI Class Initialized
INFO - 2024-03-10 15:35:30 --> Router Class Initialized
INFO - 2024-03-10 15:35:30 --> Output Class Initialized
INFO - 2024-03-10 15:35:30 --> Security Class Initialized
DEBUG - 2024-03-10 15:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:35:30 --> Input Class Initialized
INFO - 2024-03-10 15:35:30 --> Language Class Initialized
INFO - 2024-03-10 15:35:30 --> Loader Class Initialized
INFO - 2024-03-10 15:35:30 --> Helper loaded: url_helper
INFO - 2024-03-10 15:35:30 --> Helper loaded: file_helper
INFO - 2024-03-10 15:35:30 --> Helper loaded: form_helper
INFO - 2024-03-10 15:35:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:35:30 --> Controller Class Initialized
INFO - 2024-03-10 15:35:30 --> Form Validation Class Initialized
INFO - 2024-03-10 15:35:30 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:35:30 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:35:30 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:35:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:35:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:35:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:35:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:35:30 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:35:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:35:30 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:35:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-03-10 15:35:30 --> Final output sent to browser
DEBUG - 2024-03-10 15:35:30 --> Total execution time: 0.0239
ERROR - 2024-03-10 15:37:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:37:14 --> Config Class Initialized
INFO - 2024-03-10 15:37:14 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:37:14 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:37:14 --> Utf8 Class Initialized
INFO - 2024-03-10 15:37:14 --> URI Class Initialized
INFO - 2024-03-10 15:37:14 --> Router Class Initialized
INFO - 2024-03-10 15:37:14 --> Output Class Initialized
INFO - 2024-03-10 15:37:14 --> Security Class Initialized
DEBUG - 2024-03-10 15:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:37:14 --> Input Class Initialized
INFO - 2024-03-10 15:37:14 --> Language Class Initialized
INFO - 2024-03-10 15:37:14 --> Loader Class Initialized
INFO - 2024-03-10 15:37:14 --> Helper loaded: url_helper
INFO - 2024-03-10 15:37:14 --> Helper loaded: file_helper
INFO - 2024-03-10 15:37:14 --> Helper loaded: form_helper
INFO - 2024-03-10 15:37:14 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:37:14 --> Controller Class Initialized
INFO - 2024-03-10 15:37:14 --> Form Validation Class Initialized
INFO - 2024-03-10 15:37:14 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:37:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:37:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:37:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:37:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:37:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:37:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-03-10 15:37:14 --> Final output sent to browser
DEBUG - 2024-03-10 15:37:14 --> Total execution time: 0.0183
ERROR - 2024-03-10 15:37:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:37:14 --> Config Class Initialized
INFO - 2024-03-10 15:37:14 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:37:14 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:37:14 --> Utf8 Class Initialized
INFO - 2024-03-10 15:37:14 --> URI Class Initialized
INFO - 2024-03-10 15:37:14 --> Router Class Initialized
INFO - 2024-03-10 15:37:14 --> Output Class Initialized
INFO - 2024-03-10 15:37:14 --> Security Class Initialized
DEBUG - 2024-03-10 15:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:37:14 --> Input Class Initialized
INFO - 2024-03-10 15:37:14 --> Language Class Initialized
INFO - 2024-03-10 15:37:14 --> Loader Class Initialized
INFO - 2024-03-10 15:37:14 --> Helper loaded: url_helper
INFO - 2024-03-10 15:37:14 --> Helper loaded: file_helper
INFO - 2024-03-10 15:37:14 --> Helper loaded: form_helper
INFO - 2024-03-10 15:37:14 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:37:14 --> Controller Class Initialized
INFO - 2024-03-10 15:37:14 --> Form Validation Class Initialized
INFO - 2024-03-10 15:37:14 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:37:14 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:37:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:37:16 --> Config Class Initialized
INFO - 2024-03-10 15:37:16 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:37:16 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:37:16 --> Utf8 Class Initialized
INFO - 2024-03-10 15:37:16 --> URI Class Initialized
INFO - 2024-03-10 15:37:16 --> Router Class Initialized
INFO - 2024-03-10 15:37:16 --> Output Class Initialized
INFO - 2024-03-10 15:37:16 --> Security Class Initialized
DEBUG - 2024-03-10 15:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:37:16 --> Input Class Initialized
INFO - 2024-03-10 15:37:16 --> Language Class Initialized
INFO - 2024-03-10 15:37:16 --> Loader Class Initialized
INFO - 2024-03-10 15:37:16 --> Helper loaded: url_helper
INFO - 2024-03-10 15:37:16 --> Helper loaded: file_helper
INFO - 2024-03-10 15:37:16 --> Helper loaded: form_helper
INFO - 2024-03-10 15:37:16 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:37:16 --> Controller Class Initialized
INFO - 2024-03-10 15:37:16 --> Form Validation Class Initialized
INFO - 2024-03-10 15:37:16 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:37:16 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:37:16 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:37:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:37:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:37:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:37:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:37:16 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:37:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:37:16 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:37:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-03-10 15:37:16 --> Final output sent to browser
DEBUG - 2024-03-10 15:37:16 --> Total execution time: 0.0145
ERROR - 2024-03-10 15:38:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:38:10 --> Config Class Initialized
INFO - 2024-03-10 15:38:10 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:38:10 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:38:10 --> Utf8 Class Initialized
INFO - 2024-03-10 15:38:10 --> URI Class Initialized
INFO - 2024-03-10 15:38:10 --> Router Class Initialized
INFO - 2024-03-10 15:38:10 --> Output Class Initialized
INFO - 2024-03-10 15:38:10 --> Security Class Initialized
DEBUG - 2024-03-10 15:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:38:10 --> Input Class Initialized
INFO - 2024-03-10 15:38:10 --> Language Class Initialized
INFO - 2024-03-10 15:38:10 --> Loader Class Initialized
INFO - 2024-03-10 15:38:10 --> Helper loaded: url_helper
INFO - 2024-03-10 15:38:10 --> Helper loaded: file_helper
INFO - 2024-03-10 15:38:10 --> Helper loaded: form_helper
INFO - 2024-03-10 15:38:10 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:38:10 --> Controller Class Initialized
INFO - 2024-03-10 15:38:10 --> Form Validation Class Initialized
INFO - 2024-03-10 15:38:10 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:38:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:38:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:38:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:38:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:38:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:38:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-03-10 15:38:10 --> Final output sent to browser
DEBUG - 2024-03-10 15:38:10 --> Total execution time: 0.0170
ERROR - 2024-03-10 15:38:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:38:10 --> Config Class Initialized
INFO - 2024-03-10 15:38:10 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:38:10 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:38:10 --> Utf8 Class Initialized
INFO - 2024-03-10 15:38:10 --> URI Class Initialized
INFO - 2024-03-10 15:38:10 --> Router Class Initialized
INFO - 2024-03-10 15:38:10 --> Output Class Initialized
INFO - 2024-03-10 15:38:10 --> Security Class Initialized
DEBUG - 2024-03-10 15:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:38:10 --> Input Class Initialized
INFO - 2024-03-10 15:38:10 --> Language Class Initialized
INFO - 2024-03-10 15:38:10 --> Loader Class Initialized
INFO - 2024-03-10 15:38:10 --> Helper loaded: url_helper
INFO - 2024-03-10 15:38:10 --> Helper loaded: file_helper
INFO - 2024-03-10 15:38:10 --> Helper loaded: form_helper
INFO - 2024-03-10 15:38:10 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:38:10 --> Controller Class Initialized
INFO - 2024-03-10 15:38:10 --> Form Validation Class Initialized
INFO - 2024-03-10 15:38:10 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:38:10 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:38:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:38:12 --> Config Class Initialized
INFO - 2024-03-10 15:38:12 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:38:12 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:38:12 --> Utf8 Class Initialized
INFO - 2024-03-10 15:38:12 --> URI Class Initialized
INFO - 2024-03-10 15:38:12 --> Router Class Initialized
INFO - 2024-03-10 15:38:12 --> Output Class Initialized
INFO - 2024-03-10 15:38:12 --> Security Class Initialized
DEBUG - 2024-03-10 15:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:38:12 --> Input Class Initialized
INFO - 2024-03-10 15:38:12 --> Language Class Initialized
INFO - 2024-03-10 15:38:12 --> Loader Class Initialized
INFO - 2024-03-10 15:38:12 --> Helper loaded: url_helper
INFO - 2024-03-10 15:38:12 --> Helper loaded: file_helper
INFO - 2024-03-10 15:38:12 --> Helper loaded: form_helper
INFO - 2024-03-10 15:38:12 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:38:12 --> Controller Class Initialized
INFO - 2024-03-10 15:38:12 --> Form Validation Class Initialized
INFO - 2024-03-10 15:38:12 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:38:12 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:38:12 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:38:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:38:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:38:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:38:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:38:12 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:38:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:38:12 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:38:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-03-10 15:38:12 --> Final output sent to browser
DEBUG - 2024-03-10 15:38:12 --> Total execution time: 0.0175
ERROR - 2024-03-10 15:38:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:38:34 --> Config Class Initialized
INFO - 2024-03-10 15:38:34 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:38:34 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:38:34 --> Utf8 Class Initialized
INFO - 2024-03-10 15:38:34 --> URI Class Initialized
INFO - 2024-03-10 15:38:34 --> Router Class Initialized
INFO - 2024-03-10 15:38:34 --> Output Class Initialized
INFO - 2024-03-10 15:38:34 --> Security Class Initialized
DEBUG - 2024-03-10 15:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:38:34 --> Input Class Initialized
INFO - 2024-03-10 15:38:34 --> Language Class Initialized
INFO - 2024-03-10 15:38:34 --> Loader Class Initialized
INFO - 2024-03-10 15:38:34 --> Helper loaded: url_helper
INFO - 2024-03-10 15:38:34 --> Helper loaded: file_helper
INFO - 2024-03-10 15:38:34 --> Helper loaded: form_helper
INFO - 2024-03-10 15:38:34 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:38:34 --> Controller Class Initialized
INFO - 2024-03-10 15:38:34 --> Form Validation Class Initialized
INFO - 2024-03-10 15:38:34 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:38:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:38:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:38:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:38:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:38:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:38:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:38:34 --> Final output sent to browser
DEBUG - 2024-03-10 15:38:34 --> Total execution time: 0.0202
ERROR - 2024-03-10 15:38:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:38:34 --> Config Class Initialized
INFO - 2024-03-10 15:38:34 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:38:34 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:38:34 --> Utf8 Class Initialized
INFO - 2024-03-10 15:38:34 --> URI Class Initialized
INFO - 2024-03-10 15:38:34 --> Router Class Initialized
INFO - 2024-03-10 15:38:34 --> Output Class Initialized
INFO - 2024-03-10 15:38:34 --> Security Class Initialized
DEBUG - 2024-03-10 15:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:38:34 --> Input Class Initialized
INFO - 2024-03-10 15:38:34 --> Language Class Initialized
INFO - 2024-03-10 15:38:34 --> Loader Class Initialized
INFO - 2024-03-10 15:38:34 --> Helper loaded: url_helper
INFO - 2024-03-10 15:38:34 --> Helper loaded: file_helper
INFO - 2024-03-10 15:38:34 --> Helper loaded: form_helper
INFO - 2024-03-10 15:38:34 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:38:34 --> Controller Class Initialized
INFO - 2024-03-10 15:38:34 --> Form Validation Class Initialized
INFO - 2024-03-10 15:38:34 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:38:34 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:38:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:38:35 --> Config Class Initialized
INFO - 2024-03-10 15:38:35 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:38:35 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:38:35 --> Utf8 Class Initialized
INFO - 2024-03-10 15:38:35 --> URI Class Initialized
INFO - 2024-03-10 15:38:35 --> Router Class Initialized
INFO - 2024-03-10 15:38:35 --> Output Class Initialized
INFO - 2024-03-10 15:38:35 --> Security Class Initialized
DEBUG - 2024-03-10 15:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:38:35 --> Input Class Initialized
INFO - 2024-03-10 15:38:35 --> Language Class Initialized
INFO - 2024-03-10 15:38:35 --> Loader Class Initialized
INFO - 2024-03-10 15:38:35 --> Helper loaded: url_helper
INFO - 2024-03-10 15:38:35 --> Helper loaded: file_helper
INFO - 2024-03-10 15:38:35 --> Helper loaded: form_helper
INFO - 2024-03-10 15:38:35 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:38:35 --> Controller Class Initialized
INFO - 2024-03-10 15:38:35 --> Form Validation Class Initialized
INFO - 2024-03-10 15:38:35 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:38:35 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:38:35 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:38:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:38:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:38:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:38:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:38:35 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:38:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:38:35 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:38:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-03-10 15:38:35 --> Final output sent to browser
DEBUG - 2024-03-10 15:38:35 --> Total execution time: 0.0186
ERROR - 2024-03-10 15:38:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:38:35 --> Config Class Initialized
INFO - 2024-03-10 15:38:35 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:38:35 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:38:35 --> Utf8 Class Initialized
INFO - 2024-03-10 15:38:35 --> URI Class Initialized
INFO - 2024-03-10 15:38:35 --> Router Class Initialized
INFO - 2024-03-10 15:38:35 --> Output Class Initialized
INFO - 2024-03-10 15:38:35 --> Security Class Initialized
DEBUG - 2024-03-10 15:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:38:35 --> Input Class Initialized
INFO - 2024-03-10 15:38:35 --> Language Class Initialized
INFO - 2024-03-10 15:38:35 --> Loader Class Initialized
INFO - 2024-03-10 15:38:35 --> Helper loaded: url_helper
INFO - 2024-03-10 15:38:35 --> Helper loaded: file_helper
INFO - 2024-03-10 15:38:35 --> Helper loaded: form_helper
INFO - 2024-03-10 15:38:35 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:38:35 --> Controller Class Initialized
INFO - 2024-03-10 15:38:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:38:35 --> Final output sent to browser
DEBUG - 2024-03-10 15:38:35 --> Total execution time: 0.0126
ERROR - 2024-03-10 15:40:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:40:53 --> Config Class Initialized
INFO - 2024-03-10 15:40:53 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:40:53 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:40:53 --> Utf8 Class Initialized
INFO - 2024-03-10 15:40:53 --> URI Class Initialized
INFO - 2024-03-10 15:40:53 --> Router Class Initialized
INFO - 2024-03-10 15:40:53 --> Output Class Initialized
INFO - 2024-03-10 15:40:53 --> Security Class Initialized
DEBUG - 2024-03-10 15:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:40:53 --> Input Class Initialized
INFO - 2024-03-10 15:40:53 --> Language Class Initialized
INFO - 2024-03-10 15:40:53 --> Loader Class Initialized
INFO - 2024-03-10 15:40:53 --> Helper loaded: url_helper
INFO - 2024-03-10 15:40:53 --> Helper loaded: file_helper
INFO - 2024-03-10 15:40:53 --> Helper loaded: form_helper
INFO - 2024-03-10 15:40:53 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:40:53 --> Controller Class Initialized
INFO - 2024-03-10 15:40:53 --> Form Validation Class Initialized
INFO - 2024-03-10 15:40:53 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:40:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:40:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:40:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:40:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:40:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:40:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:40:53 --> Final output sent to browser
DEBUG - 2024-03-10 15:40:53 --> Total execution time: 0.0181
ERROR - 2024-03-10 15:40:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:40:53 --> Config Class Initialized
INFO - 2024-03-10 15:40:53 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:40:53 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:40:53 --> Utf8 Class Initialized
INFO - 2024-03-10 15:40:53 --> URI Class Initialized
INFO - 2024-03-10 15:40:53 --> Router Class Initialized
INFO - 2024-03-10 15:40:53 --> Output Class Initialized
INFO - 2024-03-10 15:40:53 --> Security Class Initialized
DEBUG - 2024-03-10 15:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:40:53 --> Input Class Initialized
INFO - 2024-03-10 15:40:53 --> Language Class Initialized
INFO - 2024-03-10 15:40:53 --> Loader Class Initialized
INFO - 2024-03-10 15:40:53 --> Helper loaded: url_helper
INFO - 2024-03-10 15:40:53 --> Helper loaded: file_helper
INFO - 2024-03-10 15:40:53 --> Helper loaded: form_helper
INFO - 2024-03-10 15:40:53 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:40:53 --> Controller Class Initialized
INFO - 2024-03-10 15:40:53 --> Form Validation Class Initialized
INFO - 2024-03-10 15:40:53 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:40:53 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:40:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:40:55 --> Config Class Initialized
INFO - 2024-03-10 15:40:55 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:40:55 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:40:55 --> Utf8 Class Initialized
INFO - 2024-03-10 15:40:55 --> URI Class Initialized
INFO - 2024-03-10 15:40:55 --> Router Class Initialized
INFO - 2024-03-10 15:40:55 --> Output Class Initialized
INFO - 2024-03-10 15:40:55 --> Security Class Initialized
DEBUG - 2024-03-10 15:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:40:55 --> Input Class Initialized
INFO - 2024-03-10 15:40:55 --> Language Class Initialized
INFO - 2024-03-10 15:40:55 --> Loader Class Initialized
INFO - 2024-03-10 15:40:55 --> Helper loaded: url_helper
INFO - 2024-03-10 15:40:55 --> Helper loaded: file_helper
INFO - 2024-03-10 15:40:55 --> Helper loaded: form_helper
INFO - 2024-03-10 15:40:55 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:40:55 --> Controller Class Initialized
INFO - 2024-03-10 15:40:55 --> Form Validation Class Initialized
INFO - 2024-03-10 15:40:55 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:40:55 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:40:55 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:40:55 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:40:55 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:40:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:40:55 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:40:55 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:40:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:40:55 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:40:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-03-10 15:40:55 --> Final output sent to browser
DEBUG - 2024-03-10 15:40:55 --> Total execution time: 0.0169
ERROR - 2024-03-10 15:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:41:04 --> Config Class Initialized
INFO - 2024-03-10 15:41:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:41:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:41:04 --> Utf8 Class Initialized
INFO - 2024-03-10 15:41:04 --> URI Class Initialized
INFO - 2024-03-10 15:41:04 --> Router Class Initialized
INFO - 2024-03-10 15:41:04 --> Output Class Initialized
INFO - 2024-03-10 15:41:04 --> Security Class Initialized
DEBUG - 2024-03-10 15:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:41:04 --> Input Class Initialized
INFO - 2024-03-10 15:41:04 --> Language Class Initialized
INFO - 2024-03-10 15:41:04 --> Loader Class Initialized
INFO - 2024-03-10 15:41:04 --> Helper loaded: url_helper
INFO - 2024-03-10 15:41:04 --> Helper loaded: file_helper
INFO - 2024-03-10 15:41:04 --> Helper loaded: form_helper
INFO - 2024-03-10 15:41:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:41:04 --> Controller Class Initialized
INFO - 2024-03-10 15:41:04 --> Form Validation Class Initialized
INFO - 2024-03-10 15:41:04 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:41:04 --> Final output sent to browser
DEBUG - 2024-03-10 15:41:04 --> Total execution time: 0.0160
ERROR - 2024-03-10 15:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:41:04 --> Config Class Initialized
INFO - 2024-03-10 15:41:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:41:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:41:04 --> Utf8 Class Initialized
INFO - 2024-03-10 15:41:04 --> URI Class Initialized
INFO - 2024-03-10 15:41:04 --> Router Class Initialized
INFO - 2024-03-10 15:41:04 --> Output Class Initialized
INFO - 2024-03-10 15:41:04 --> Security Class Initialized
DEBUG - 2024-03-10 15:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:41:04 --> Input Class Initialized
INFO - 2024-03-10 15:41:04 --> Language Class Initialized
INFO - 2024-03-10 15:41:04 --> Loader Class Initialized
INFO - 2024-03-10 15:41:04 --> Helper loaded: url_helper
INFO - 2024-03-10 15:41:04 --> Helper loaded: file_helper
INFO - 2024-03-10 15:41:04 --> Helper loaded: form_helper
INFO - 2024-03-10 15:41:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:41:04 --> Controller Class Initialized
INFO - 2024-03-10 15:41:04 --> Form Validation Class Initialized
INFO - 2024-03-10 15:41:04 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:41:04 --> Config Class Initialized
INFO - 2024-03-10 15:41:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:41:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:41:04 --> Utf8 Class Initialized
INFO - 2024-03-10 15:41:04 --> URI Class Initialized
INFO - 2024-03-10 15:41:04 --> Router Class Initialized
INFO - 2024-03-10 15:41:04 --> Output Class Initialized
INFO - 2024-03-10 15:41:04 --> Security Class Initialized
DEBUG - 2024-03-10 15:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:41:04 --> Input Class Initialized
INFO - 2024-03-10 15:41:04 --> Language Class Initialized
INFO - 2024-03-10 15:41:04 --> Loader Class Initialized
INFO - 2024-03-10 15:41:04 --> Helper loaded: url_helper
INFO - 2024-03-10 15:41:04 --> Helper loaded: file_helper
INFO - 2024-03-10 15:41:04 --> Helper loaded: form_helper
INFO - 2024-03-10 15:41:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:41:04 --> Controller Class Initialized
INFO - 2024-03-10 15:41:04 --> Form Validation Class Initialized
INFO - 2024-03-10 15:41:04 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:41:04 --> Final output sent to browser
DEBUG - 2024-03-10 15:41:04 --> Total execution time: 0.0286
ERROR - 2024-03-10 15:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:41:04 --> Config Class Initialized
INFO - 2024-03-10 15:41:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:41:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:41:04 --> Utf8 Class Initialized
INFO - 2024-03-10 15:41:04 --> URI Class Initialized
INFO - 2024-03-10 15:41:04 --> Router Class Initialized
INFO - 2024-03-10 15:41:04 --> Output Class Initialized
INFO - 2024-03-10 15:41:04 --> Security Class Initialized
DEBUG - 2024-03-10 15:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:41:04 --> Input Class Initialized
INFO - 2024-03-10 15:41:04 --> Language Class Initialized
INFO - 2024-03-10 15:41:04 --> Loader Class Initialized
INFO - 2024-03-10 15:41:04 --> Helper loaded: url_helper
INFO - 2024-03-10 15:41:04 --> Helper loaded: file_helper
INFO - 2024-03-10 15:41:04 --> Helper loaded: form_helper
INFO - 2024-03-10 15:41:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:41:04 --> Controller Class Initialized
INFO - 2024-03-10 15:41:04 --> Form Validation Class Initialized
INFO - 2024-03-10 15:41:04 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:41:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:41:04 --> Final output sent to browser
DEBUG - 2024-03-10 15:41:04 --> Total execution time: 0.0179
ERROR - 2024-03-10 15:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:41:04 --> Config Class Initialized
INFO - 2024-03-10 15:41:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:41:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:41:04 --> Utf8 Class Initialized
INFO - 2024-03-10 15:41:04 --> URI Class Initialized
INFO - 2024-03-10 15:41:04 --> Router Class Initialized
INFO - 2024-03-10 15:41:04 --> Output Class Initialized
INFO - 2024-03-10 15:41:04 --> Security Class Initialized
DEBUG - 2024-03-10 15:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:41:04 --> Input Class Initialized
INFO - 2024-03-10 15:41:04 --> Language Class Initialized
INFO - 2024-03-10 15:41:04 --> Loader Class Initialized
INFO - 2024-03-10 15:41:04 --> Helper loaded: url_helper
INFO - 2024-03-10 15:41:04 --> Helper loaded: file_helper
INFO - 2024-03-10 15:41:04 --> Helper loaded: form_helper
INFO - 2024-03-10 15:41:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:41:04 --> Controller Class Initialized
INFO - 2024-03-10 15:41:04 --> Form Validation Class Initialized
INFO - 2024-03-10 15:41:04 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:41:04 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:41:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:41:06 --> Config Class Initialized
INFO - 2024-03-10 15:41:06 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:41:06 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:41:06 --> Utf8 Class Initialized
INFO - 2024-03-10 15:41:06 --> URI Class Initialized
INFO - 2024-03-10 15:41:06 --> Router Class Initialized
INFO - 2024-03-10 15:41:06 --> Output Class Initialized
INFO - 2024-03-10 15:41:06 --> Security Class Initialized
DEBUG - 2024-03-10 15:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:41:06 --> Input Class Initialized
INFO - 2024-03-10 15:41:06 --> Language Class Initialized
INFO - 2024-03-10 15:41:06 --> Loader Class Initialized
INFO - 2024-03-10 15:41:06 --> Helper loaded: url_helper
INFO - 2024-03-10 15:41:06 --> Helper loaded: file_helper
INFO - 2024-03-10 15:41:06 --> Helper loaded: form_helper
INFO - 2024-03-10 15:41:06 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:41:06 --> Controller Class Initialized
INFO - 2024-03-10 15:41:06 --> Form Validation Class Initialized
INFO - 2024-03-10 15:41:06 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:41:06 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:41:06 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:41:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:41:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:41:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:41:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:41:06 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:41:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:41:06 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:41:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-03-10 15:41:06 --> Final output sent to browser
DEBUG - 2024-03-10 15:41:06 --> Total execution time: 0.0166
ERROR - 2024-03-10 15:42:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:42:48 --> Config Class Initialized
INFO - 2024-03-10 15:42:48 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:42:48 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:42:48 --> Utf8 Class Initialized
INFO - 2024-03-10 15:42:48 --> URI Class Initialized
INFO - 2024-03-10 15:42:48 --> Router Class Initialized
INFO - 2024-03-10 15:42:48 --> Output Class Initialized
INFO - 2024-03-10 15:42:48 --> Security Class Initialized
DEBUG - 2024-03-10 15:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:42:48 --> Input Class Initialized
INFO - 2024-03-10 15:42:48 --> Language Class Initialized
INFO - 2024-03-10 15:42:48 --> Loader Class Initialized
INFO - 2024-03-10 15:42:48 --> Helper loaded: url_helper
INFO - 2024-03-10 15:42:48 --> Helper loaded: file_helper
INFO - 2024-03-10 15:42:48 --> Helper loaded: form_helper
INFO - 2024-03-10 15:42:48 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:42:48 --> Controller Class Initialized
INFO - 2024-03-10 15:42:48 --> Form Validation Class Initialized
INFO - 2024-03-10 15:42:48 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:42:48 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:42:48 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:42:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:42:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:42:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:42:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:42:48 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:42:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:42:48 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:42:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:42:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:42:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:42:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:42:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:42:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:42:48 --> Final output sent to browser
DEBUG - 2024-03-10 15:42:48 --> Total execution time: 0.0195
ERROR - 2024-03-10 15:42:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:42:49 --> Config Class Initialized
INFO - 2024-03-10 15:42:49 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:42:49 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:42:49 --> Utf8 Class Initialized
INFO - 2024-03-10 15:42:49 --> URI Class Initialized
INFO - 2024-03-10 15:42:49 --> Router Class Initialized
INFO - 2024-03-10 15:42:49 --> Output Class Initialized
INFO - 2024-03-10 15:42:49 --> Security Class Initialized
DEBUG - 2024-03-10 15:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:42:49 --> Input Class Initialized
INFO - 2024-03-10 15:42:49 --> Language Class Initialized
INFO - 2024-03-10 15:42:49 --> Loader Class Initialized
INFO - 2024-03-10 15:42:49 --> Helper loaded: url_helper
INFO - 2024-03-10 15:42:49 --> Helper loaded: file_helper
INFO - 2024-03-10 15:42:49 --> Helper loaded: form_helper
INFO - 2024-03-10 15:42:49 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:42:49 --> Controller Class Initialized
INFO - 2024-03-10 15:42:49 --> Form Validation Class Initialized
INFO - 2024-03-10 15:42:49 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:42:49 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:42:49 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:42:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:42:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:42:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:42:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:42:49 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:42:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:42:49 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:42:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:42:51 --> Config Class Initialized
INFO - 2024-03-10 15:42:51 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:42:51 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:42:51 --> Utf8 Class Initialized
INFO - 2024-03-10 15:42:51 --> URI Class Initialized
INFO - 2024-03-10 15:42:51 --> Router Class Initialized
INFO - 2024-03-10 15:42:51 --> Output Class Initialized
INFO - 2024-03-10 15:42:51 --> Security Class Initialized
DEBUG - 2024-03-10 15:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:42:51 --> Input Class Initialized
INFO - 2024-03-10 15:42:51 --> Language Class Initialized
INFO - 2024-03-10 15:42:51 --> Loader Class Initialized
INFO - 2024-03-10 15:42:51 --> Helper loaded: url_helper
INFO - 2024-03-10 15:42:51 --> Helper loaded: file_helper
INFO - 2024-03-10 15:42:51 --> Helper loaded: form_helper
INFO - 2024-03-10 15:42:51 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:42:51 --> Controller Class Initialized
INFO - 2024-03-10 15:42:51 --> Form Validation Class Initialized
INFO - 2024-03-10 15:42:51 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:42:51 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:42:51 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:42:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:42:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:42:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:42:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:42:51 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:42:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:42:51 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-03-10 15:42:51 --> Final output sent to browser
DEBUG - 2024-03-10 15:42:51 --> Total execution time: 0.0163
ERROR - 2024-03-10 15:44:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:44:25 --> Config Class Initialized
INFO - 2024-03-10 15:44:25 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:44:25 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:44:25 --> Utf8 Class Initialized
INFO - 2024-03-10 15:44:25 --> URI Class Initialized
INFO - 2024-03-10 15:44:25 --> Router Class Initialized
INFO - 2024-03-10 15:44:25 --> Output Class Initialized
INFO - 2024-03-10 15:44:25 --> Security Class Initialized
DEBUG - 2024-03-10 15:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:44:25 --> Input Class Initialized
INFO - 2024-03-10 15:44:25 --> Language Class Initialized
INFO - 2024-03-10 15:44:25 --> Loader Class Initialized
INFO - 2024-03-10 15:44:25 --> Helper loaded: url_helper
INFO - 2024-03-10 15:44:25 --> Helper loaded: file_helper
INFO - 2024-03-10 15:44:25 --> Helper loaded: form_helper
INFO - 2024-03-10 15:44:25 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:44:25 --> Controller Class Initialized
INFO - 2024-03-10 15:44:25 --> Form Validation Class Initialized
INFO - 2024-03-10 15:44:25 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:44:25 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:44:25 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:44:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:44:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:44:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:44:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:44:25 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:44:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:44:25 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:44:25 --> Final output sent to browser
DEBUG - 2024-03-10 15:44:25 --> Total execution time: 0.0174
ERROR - 2024-03-10 15:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:44:26 --> Config Class Initialized
INFO - 2024-03-10 15:44:26 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:44:26 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:44:26 --> Utf8 Class Initialized
INFO - 2024-03-10 15:44:26 --> URI Class Initialized
INFO - 2024-03-10 15:44:26 --> Router Class Initialized
INFO - 2024-03-10 15:44:26 --> Output Class Initialized
INFO - 2024-03-10 15:44:26 --> Security Class Initialized
DEBUG - 2024-03-10 15:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:44:26 --> Input Class Initialized
INFO - 2024-03-10 15:44:26 --> Language Class Initialized
INFO - 2024-03-10 15:44:26 --> Loader Class Initialized
INFO - 2024-03-10 15:44:26 --> Helper loaded: url_helper
INFO - 2024-03-10 15:44:26 --> Helper loaded: file_helper
INFO - 2024-03-10 15:44:26 --> Helper loaded: form_helper
INFO - 2024-03-10 15:44:26 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:44:26 --> Controller Class Initialized
INFO - 2024-03-10 15:44:26 --> Form Validation Class Initialized
INFO - 2024-03-10 15:44:26 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:44:26 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:44:26 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:44:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:44:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:44:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:44:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:44:26 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:44:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:44:26 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:44:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:44:27 --> Config Class Initialized
INFO - 2024-03-10 15:44:27 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:44:27 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:44:27 --> Utf8 Class Initialized
INFO - 2024-03-10 15:44:27 --> URI Class Initialized
INFO - 2024-03-10 15:44:27 --> Router Class Initialized
INFO - 2024-03-10 15:44:27 --> Output Class Initialized
INFO - 2024-03-10 15:44:27 --> Security Class Initialized
DEBUG - 2024-03-10 15:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:44:27 --> Input Class Initialized
INFO - 2024-03-10 15:44:27 --> Language Class Initialized
INFO - 2024-03-10 15:44:27 --> Loader Class Initialized
INFO - 2024-03-10 15:44:27 --> Helper loaded: url_helper
INFO - 2024-03-10 15:44:27 --> Helper loaded: file_helper
INFO - 2024-03-10 15:44:27 --> Helper loaded: form_helper
INFO - 2024-03-10 15:44:27 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:44:27 --> Controller Class Initialized
INFO - 2024-03-10 15:44:27 --> Form Validation Class Initialized
INFO - 2024-03-10 15:44:27 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:44:27 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:44:27 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:44:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:44:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:44:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:44:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:44:27 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:44:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:44:27 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-03-10 15:44:27 --> Final output sent to browser
DEBUG - 2024-03-10 15:44:27 --> Total execution time: 0.0161
ERROR - 2024-03-10 15:46:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:46:22 --> Config Class Initialized
INFO - 2024-03-10 15:46:22 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:46:22 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:46:22 --> Utf8 Class Initialized
INFO - 2024-03-10 15:46:22 --> URI Class Initialized
INFO - 2024-03-10 15:46:22 --> Router Class Initialized
INFO - 2024-03-10 15:46:22 --> Output Class Initialized
INFO - 2024-03-10 15:46:22 --> Security Class Initialized
DEBUG - 2024-03-10 15:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:46:22 --> Input Class Initialized
INFO - 2024-03-10 15:46:22 --> Language Class Initialized
INFO - 2024-03-10 15:46:22 --> Loader Class Initialized
INFO - 2024-03-10 15:46:22 --> Helper loaded: url_helper
INFO - 2024-03-10 15:46:22 --> Helper loaded: file_helper
INFO - 2024-03-10 15:46:22 --> Helper loaded: form_helper
INFO - 2024-03-10 15:46:22 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:46:22 --> Controller Class Initialized
INFO - 2024-03-10 15:46:22 --> Form Validation Class Initialized
INFO - 2024-03-10 15:46:22 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:46:22 --> Final output sent to browser
DEBUG - 2024-03-10 15:46:22 --> Total execution time: 0.0170
ERROR - 2024-03-10 15:46:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:46:22 --> Config Class Initialized
INFO - 2024-03-10 15:46:22 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:46:22 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:46:22 --> Utf8 Class Initialized
INFO - 2024-03-10 15:46:22 --> URI Class Initialized
INFO - 2024-03-10 15:46:22 --> Router Class Initialized
INFO - 2024-03-10 15:46:22 --> Output Class Initialized
INFO - 2024-03-10 15:46:22 --> Security Class Initialized
DEBUG - 2024-03-10 15:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:46:22 --> Input Class Initialized
INFO - 2024-03-10 15:46:22 --> Language Class Initialized
INFO - 2024-03-10 15:46:22 --> Loader Class Initialized
INFO - 2024-03-10 15:46:22 --> Helper loaded: url_helper
INFO - 2024-03-10 15:46:22 --> Helper loaded: file_helper
INFO - 2024-03-10 15:46:22 --> Helper loaded: form_helper
INFO - 2024-03-10 15:46:22 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:46:22 --> Controller Class Initialized
INFO - 2024-03-10 15:46:22 --> Form Validation Class Initialized
INFO - 2024-03-10 15:46:22 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:46:22 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:46:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:46:24 --> Config Class Initialized
INFO - 2024-03-10 15:46:24 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:46:24 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:46:24 --> Utf8 Class Initialized
INFO - 2024-03-10 15:46:24 --> URI Class Initialized
INFO - 2024-03-10 15:46:24 --> Router Class Initialized
INFO - 2024-03-10 15:46:24 --> Output Class Initialized
INFO - 2024-03-10 15:46:24 --> Security Class Initialized
DEBUG - 2024-03-10 15:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:46:24 --> Input Class Initialized
INFO - 2024-03-10 15:46:24 --> Language Class Initialized
INFO - 2024-03-10 15:46:24 --> Loader Class Initialized
INFO - 2024-03-10 15:46:24 --> Helper loaded: url_helper
INFO - 2024-03-10 15:46:24 --> Helper loaded: file_helper
INFO - 2024-03-10 15:46:24 --> Helper loaded: form_helper
INFO - 2024-03-10 15:46:24 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:46:24 --> Controller Class Initialized
INFO - 2024-03-10 15:46:24 --> Form Validation Class Initialized
INFO - 2024-03-10 15:46:24 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:46:24 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:46:24 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:46:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:46:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:46:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:46:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:46:24 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:46:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:46:24 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:46:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-03-10 15:46:24 --> Final output sent to browser
DEBUG - 2024-03-10 15:46:24 --> Total execution time: 0.0218
ERROR - 2024-03-10 15:47:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:47:09 --> Config Class Initialized
INFO - 2024-03-10 15:47:09 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:47:09 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:47:09 --> Utf8 Class Initialized
INFO - 2024-03-10 15:47:09 --> URI Class Initialized
INFO - 2024-03-10 15:47:09 --> Router Class Initialized
INFO - 2024-03-10 15:47:09 --> Output Class Initialized
INFO - 2024-03-10 15:47:09 --> Security Class Initialized
DEBUG - 2024-03-10 15:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:47:09 --> Input Class Initialized
INFO - 2024-03-10 15:47:09 --> Language Class Initialized
INFO - 2024-03-10 15:47:09 --> Loader Class Initialized
INFO - 2024-03-10 15:47:09 --> Helper loaded: url_helper
INFO - 2024-03-10 15:47:09 --> Helper loaded: file_helper
INFO - 2024-03-10 15:47:09 --> Helper loaded: form_helper
INFO - 2024-03-10 15:47:09 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:47:09 --> Controller Class Initialized
INFO - 2024-03-10 15:47:09 --> Form Validation Class Initialized
INFO - 2024-03-10 15:47:09 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:47:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:47:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:47:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:47:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:47:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:47:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-03-10 15:47:09 --> Final output sent to browser
DEBUG - 2024-03-10 15:47:09 --> Total execution time: 0.0195
ERROR - 2024-03-10 15:47:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:47:09 --> Config Class Initialized
INFO - 2024-03-10 15:47:09 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:47:09 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:47:09 --> Utf8 Class Initialized
INFO - 2024-03-10 15:47:09 --> URI Class Initialized
INFO - 2024-03-10 15:47:09 --> Router Class Initialized
INFO - 2024-03-10 15:47:09 --> Output Class Initialized
INFO - 2024-03-10 15:47:09 --> Security Class Initialized
DEBUG - 2024-03-10 15:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:47:09 --> Input Class Initialized
INFO - 2024-03-10 15:47:09 --> Language Class Initialized
INFO - 2024-03-10 15:47:09 --> Loader Class Initialized
INFO - 2024-03-10 15:47:09 --> Helper loaded: url_helper
INFO - 2024-03-10 15:47:09 --> Helper loaded: file_helper
INFO - 2024-03-10 15:47:09 --> Helper loaded: form_helper
INFO - 2024-03-10 15:47:09 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:47:09 --> Controller Class Initialized
INFO - 2024-03-10 15:47:09 --> Form Validation Class Initialized
INFO - 2024-03-10 15:47:09 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:47:09 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:47:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:47:11 --> Config Class Initialized
INFO - 2024-03-10 15:47:11 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:47:11 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:47:11 --> Utf8 Class Initialized
INFO - 2024-03-10 15:47:11 --> URI Class Initialized
INFO - 2024-03-10 15:47:11 --> Router Class Initialized
INFO - 2024-03-10 15:47:11 --> Output Class Initialized
INFO - 2024-03-10 15:47:11 --> Security Class Initialized
DEBUG - 2024-03-10 15:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:47:11 --> Input Class Initialized
INFO - 2024-03-10 15:47:11 --> Language Class Initialized
INFO - 2024-03-10 15:47:11 --> Loader Class Initialized
INFO - 2024-03-10 15:47:11 --> Helper loaded: url_helper
INFO - 2024-03-10 15:47:11 --> Helper loaded: file_helper
INFO - 2024-03-10 15:47:11 --> Helper loaded: form_helper
INFO - 2024-03-10 15:47:11 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:47:11 --> Controller Class Initialized
INFO - 2024-03-10 15:47:11 --> Form Validation Class Initialized
INFO - 2024-03-10 15:47:11 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:47:11 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:47:11 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:47:11 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:47:11 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:47:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:47:11 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:47:11 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:47:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:47:11 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:47:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-03-10 15:47:11 --> Final output sent to browser
DEBUG - 2024-03-10 15:47:11 --> Total execution time: 0.0190
ERROR - 2024-03-10 15:47:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:47:56 --> Config Class Initialized
INFO - 2024-03-10 15:47:56 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:47:56 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:47:56 --> Utf8 Class Initialized
INFO - 2024-03-10 15:47:56 --> URI Class Initialized
INFO - 2024-03-10 15:47:56 --> Router Class Initialized
INFO - 2024-03-10 15:47:56 --> Output Class Initialized
INFO - 2024-03-10 15:47:56 --> Security Class Initialized
DEBUG - 2024-03-10 15:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:47:56 --> Input Class Initialized
INFO - 2024-03-10 15:47:56 --> Language Class Initialized
INFO - 2024-03-10 15:47:56 --> Loader Class Initialized
INFO - 2024-03-10 15:47:56 --> Helper loaded: url_helper
INFO - 2024-03-10 15:47:56 --> Helper loaded: file_helper
INFO - 2024-03-10 15:47:56 --> Helper loaded: form_helper
INFO - 2024-03-10 15:47:56 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:47:56 --> Controller Class Initialized
INFO - 2024-03-10 15:47:56 --> Form Validation Class Initialized
INFO - 2024-03-10 15:47:56 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:47:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:47:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:47:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:47:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:47:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:47:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-10 15:47:56 --> Final output sent to browser
DEBUG - 2024-03-10 15:47:56 --> Total execution time: 0.0192
ERROR - 2024-03-10 15:47:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:47:56 --> Config Class Initialized
INFO - 2024-03-10 15:47:56 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:47:56 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:47:56 --> Utf8 Class Initialized
INFO - 2024-03-10 15:47:56 --> URI Class Initialized
INFO - 2024-03-10 15:47:56 --> Router Class Initialized
INFO - 2024-03-10 15:47:56 --> Output Class Initialized
INFO - 2024-03-10 15:47:56 --> Security Class Initialized
DEBUG - 2024-03-10 15:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:47:56 --> Input Class Initialized
INFO - 2024-03-10 15:47:56 --> Language Class Initialized
INFO - 2024-03-10 15:47:56 --> Loader Class Initialized
INFO - 2024-03-10 15:47:56 --> Helper loaded: url_helper
INFO - 2024-03-10 15:47:56 --> Helper loaded: file_helper
INFO - 2024-03-10 15:47:56 --> Helper loaded: form_helper
INFO - 2024-03-10 15:47:56 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:47:56 --> Controller Class Initialized
INFO - 2024-03-10 15:47:56 --> Form Validation Class Initialized
INFO - 2024-03-10 15:47:56 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:47:56 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:47:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:47:57 --> Config Class Initialized
INFO - 2024-03-10 15:47:57 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:47:57 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:47:57 --> Utf8 Class Initialized
INFO - 2024-03-10 15:47:57 --> URI Class Initialized
INFO - 2024-03-10 15:47:57 --> Router Class Initialized
INFO - 2024-03-10 15:47:57 --> Output Class Initialized
INFO - 2024-03-10 15:47:57 --> Security Class Initialized
DEBUG - 2024-03-10 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:47:57 --> Input Class Initialized
INFO - 2024-03-10 15:47:57 --> Language Class Initialized
INFO - 2024-03-10 15:47:57 --> Loader Class Initialized
INFO - 2024-03-10 15:47:57 --> Helper loaded: url_helper
INFO - 2024-03-10 15:47:57 --> Helper loaded: file_helper
INFO - 2024-03-10 15:47:57 --> Helper loaded: form_helper
INFO - 2024-03-10 15:47:57 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:47:57 --> Controller Class Initialized
INFO - 2024-03-10 15:47:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:47:57 --> Final output sent to browser
DEBUG - 2024-03-10 15:47:57 --> Total execution time: 0.0112
ERROR - 2024-03-10 15:48:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:08 --> Config Class Initialized
INFO - 2024-03-10 15:48:08 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:08 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:08 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:08 --> URI Class Initialized
INFO - 2024-03-10 15:48:08 --> Router Class Initialized
INFO - 2024-03-10 15:48:08 --> Output Class Initialized
INFO - 2024-03-10 15:48:08 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:08 --> Input Class Initialized
INFO - 2024-03-10 15:48:08 --> Language Class Initialized
INFO - 2024-03-10 15:48:08 --> Loader Class Initialized
INFO - 2024-03-10 15:48:08 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:08 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:08 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:08 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:08 --> Controller Class Initialized
INFO - 2024-03-10 15:48:08 --> Form Validation Class Initialized
INFO - 2024-03-10 15:48:08 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:48:08 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:48:08 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:48:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:48:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:48:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:48:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:48:08 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:48:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:48:08 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:48:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:48:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:48:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:48:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:48:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:48:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-03-10 15:48:08 --> Final output sent to browser
DEBUG - 2024-03-10 15:48:08 --> Total execution time: 0.0169
ERROR - 2024-03-10 15:48:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:09 --> Config Class Initialized
INFO - 2024-03-10 15:48:09 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:09 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:09 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:09 --> URI Class Initialized
INFO - 2024-03-10 15:48:09 --> Router Class Initialized
INFO - 2024-03-10 15:48:09 --> Output Class Initialized
INFO - 2024-03-10 15:48:09 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:09 --> Input Class Initialized
INFO - 2024-03-10 15:48:09 --> Language Class Initialized
INFO - 2024-03-10 15:48:09 --> Loader Class Initialized
INFO - 2024-03-10 15:48:09 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:09 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:09 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:09 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:09 --> Controller Class Initialized
INFO - 2024-03-10 15:48:09 --> Form Validation Class Initialized
INFO - 2024-03-10 15:48:09 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 15:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:48:09 --> Final output sent to browser
DEBUG - 2024-03-10 15:48:09 --> Total execution time: 0.0162
ERROR - 2024-03-10 15:48:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:09 --> Config Class Initialized
INFO - 2024-03-10 15:48:09 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:09 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:09 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:09 --> URI Class Initialized
INFO - 2024-03-10 15:48:09 --> Router Class Initialized
INFO - 2024-03-10 15:48:09 --> Output Class Initialized
INFO - 2024-03-10 15:48:09 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:09 --> Input Class Initialized
INFO - 2024-03-10 15:48:09 --> Language Class Initialized
INFO - 2024-03-10 15:48:09 --> Loader Class Initialized
INFO - 2024-03-10 15:48:09 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:09 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:09 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:09 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:09 --> Controller Class Initialized
INFO - 2024-03-10 15:48:09 --> Form Validation Class Initialized
INFO - 2024-03-10 15:48:09 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:48:09 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:48:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:10 --> Config Class Initialized
INFO - 2024-03-10 15:48:10 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:10 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:10 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:10 --> URI Class Initialized
INFO - 2024-03-10 15:48:10 --> Router Class Initialized
INFO - 2024-03-10 15:48:10 --> Output Class Initialized
INFO - 2024-03-10 15:48:10 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:10 --> Input Class Initialized
INFO - 2024-03-10 15:48:10 --> Language Class Initialized
INFO - 2024-03-10 15:48:10 --> Loader Class Initialized
INFO - 2024-03-10 15:48:10 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:10 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:10 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:10 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:10 --> Controller Class Initialized
INFO - 2024-03-10 15:48:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:48:10 --> Final output sent to browser
DEBUG - 2024-03-10 15:48:10 --> Total execution time: 0.0162
ERROR - 2024-03-10 15:48:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:11 --> Config Class Initialized
INFO - 2024-03-10 15:48:11 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:11 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:11 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:11 --> URI Class Initialized
INFO - 2024-03-10 15:48:11 --> Router Class Initialized
INFO - 2024-03-10 15:48:11 --> Output Class Initialized
INFO - 2024-03-10 15:48:11 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:11 --> Input Class Initialized
INFO - 2024-03-10 15:48:11 --> Language Class Initialized
INFO - 2024-03-10 15:48:11 --> Loader Class Initialized
INFO - 2024-03-10 15:48:11 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:11 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:11 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:11 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:11 --> Controller Class Initialized
INFO - 2024-03-10 15:48:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:48:11 --> Final output sent to browser
DEBUG - 2024-03-10 15:48:11 --> Total execution time: 0.0132
ERROR - 2024-03-10 15:48:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:12 --> Config Class Initialized
INFO - 2024-03-10 15:48:12 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:12 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:12 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:12 --> URI Class Initialized
INFO - 2024-03-10 15:48:12 --> Router Class Initialized
INFO - 2024-03-10 15:48:12 --> Output Class Initialized
INFO - 2024-03-10 15:48:12 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:12 --> Input Class Initialized
INFO - 2024-03-10 15:48:12 --> Language Class Initialized
INFO - 2024-03-10 15:48:12 --> Loader Class Initialized
INFO - 2024-03-10 15:48:12 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:12 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:12 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:12 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:12 --> Controller Class Initialized
INFO - 2024-03-10 15:48:12 --> Model "LoginModel" initialized
INFO - 2024-03-10 15:48:12 --> Form Validation Class Initialized
ERROR - 2024-03-10 15:48:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:12 --> Config Class Initialized
INFO - 2024-03-10 15:48:12 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:12 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:12 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:12 --> URI Class Initialized
INFO - 2024-03-10 15:48:12 --> Router Class Initialized
INFO - 2024-03-10 15:48:12 --> Output Class Initialized
INFO - 2024-03-10 15:48:12 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:12 --> Input Class Initialized
INFO - 2024-03-10 15:48:12 --> Language Class Initialized
INFO - 2024-03-10 15:48:12 --> Loader Class Initialized
INFO - 2024-03-10 15:48:12 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:12 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:12 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:12 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:12 --> Controller Class Initialized
INFO - 2024-03-10 15:48:12 --> Model "LoginModel" initialized
INFO - 2024-03-10 15:48:12 --> Form Validation Class Initialized
INFO - 2024-03-10 15:48:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-10 15:48:12 --> Final output sent to browser
DEBUG - 2024-03-10 15:48:12 --> Total execution time: 0.0125
ERROR - 2024-03-10 15:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:14 --> Config Class Initialized
INFO - 2024-03-10 15:48:14 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:14 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:14 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:14 --> URI Class Initialized
INFO - 2024-03-10 15:48:14 --> Router Class Initialized
INFO - 2024-03-10 15:48:14 --> Output Class Initialized
INFO - 2024-03-10 15:48:14 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:14 --> Input Class Initialized
INFO - 2024-03-10 15:48:14 --> Language Class Initialized
INFO - 2024-03-10 15:48:14 --> Loader Class Initialized
INFO - 2024-03-10 15:48:14 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:14 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:14 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:14 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:14 --> Controller Class Initialized
INFO - 2024-03-10 15:48:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:48:14 --> Final output sent to browser
DEBUG - 2024-03-10 15:48:14 --> Total execution time: 0.0108
ERROR - 2024-03-10 15:48:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:21 --> Config Class Initialized
INFO - 2024-03-10 15:48:21 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:21 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:21 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:21 --> URI Class Initialized
INFO - 2024-03-10 15:48:21 --> Router Class Initialized
INFO - 2024-03-10 15:48:21 --> Output Class Initialized
INFO - 2024-03-10 15:48:21 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:21 --> Input Class Initialized
INFO - 2024-03-10 15:48:21 --> Language Class Initialized
INFO - 2024-03-10 15:48:21 --> Loader Class Initialized
INFO - 2024-03-10 15:48:21 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:21 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:21 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:21 --> Controller Class Initialized
INFO - 2024-03-10 15:48:21 --> Model "LoginModel" initialized
INFO - 2024-03-10 15:48:21 --> Form Validation Class Initialized
INFO - 2024-03-10 15:48:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-10 15:48:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:21 --> Config Class Initialized
INFO - 2024-03-10 15:48:21 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:21 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:21 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:21 --> URI Class Initialized
INFO - 2024-03-10 15:48:21 --> Router Class Initialized
INFO - 2024-03-10 15:48:21 --> Output Class Initialized
INFO - 2024-03-10 15:48:21 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:21 --> Input Class Initialized
INFO - 2024-03-10 15:48:21 --> Language Class Initialized
INFO - 2024-03-10 15:48:21 --> Loader Class Initialized
INFO - 2024-03-10 15:48:21 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:21 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:21 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:21 --> Controller Class Initialized
INFO - 2024-03-10 15:48:21 --> Form Validation Class Initialized
INFO - 2024-03-10 15:48:21 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:48:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:48:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:48:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:48:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:48:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:48:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:48:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:48:21 --> Final output sent to browser
DEBUG - 2024-03-10 15:48:21 --> Total execution time: 0.0150
ERROR - 2024-03-10 15:48:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:21 --> Config Class Initialized
INFO - 2024-03-10 15:48:21 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:21 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:21 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:21 --> URI Class Initialized
INFO - 2024-03-10 15:48:21 --> Router Class Initialized
INFO - 2024-03-10 15:48:21 --> Output Class Initialized
INFO - 2024-03-10 15:48:21 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:21 --> Input Class Initialized
INFO - 2024-03-10 15:48:21 --> Language Class Initialized
INFO - 2024-03-10 15:48:21 --> Loader Class Initialized
INFO - 2024-03-10 15:48:21 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:21 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:21 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:21 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:21 --> Controller Class Initialized
INFO - 2024-03-10 15:48:21 --> Form Validation Class Initialized
INFO - 2024-03-10 15:48:21 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:48:21 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:48:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:22 --> Config Class Initialized
INFO - 2024-03-10 15:48:22 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:22 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:22 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:22 --> URI Class Initialized
INFO - 2024-03-10 15:48:22 --> Router Class Initialized
INFO - 2024-03-10 15:48:22 --> Output Class Initialized
INFO - 2024-03-10 15:48:22 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:22 --> Input Class Initialized
INFO - 2024-03-10 15:48:22 --> Language Class Initialized
INFO - 2024-03-10 15:48:22 --> Loader Class Initialized
INFO - 2024-03-10 15:48:22 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:22 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:22 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:22 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:22 --> Controller Class Initialized
INFO - 2024-03-10 15:48:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:48:22 --> Final output sent to browser
DEBUG - 2024-03-10 15:48:22 --> Total execution time: 0.0117
ERROR - 2024-03-10 15:48:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:24 --> Config Class Initialized
INFO - 2024-03-10 15:48:24 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:24 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:24 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:24 --> URI Class Initialized
INFO - 2024-03-10 15:48:24 --> Router Class Initialized
INFO - 2024-03-10 15:48:24 --> Output Class Initialized
INFO - 2024-03-10 15:48:24 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:24 --> Input Class Initialized
INFO - 2024-03-10 15:48:24 --> Language Class Initialized
INFO - 2024-03-10 15:48:24 --> Loader Class Initialized
INFO - 2024-03-10 15:48:24 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:24 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:24 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:24 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:24 --> Controller Class Initialized
INFO - 2024-03-10 15:48:24 --> Form Validation Class Initialized
INFO - 2024-03-10 15:48:24 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 15:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 15:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 15:48:24 --> Final output sent to browser
DEBUG - 2024-03-10 15:48:24 --> Total execution time: 0.0175
ERROR - 2024-03-10 15:48:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:24 --> Config Class Initialized
INFO - 2024-03-10 15:48:24 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:24 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:24 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:24 --> URI Class Initialized
INFO - 2024-03-10 15:48:24 --> Router Class Initialized
INFO - 2024-03-10 15:48:24 --> Output Class Initialized
INFO - 2024-03-10 15:48:24 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:24 --> Input Class Initialized
INFO - 2024-03-10 15:48:24 --> Language Class Initialized
INFO - 2024-03-10 15:48:24 --> Loader Class Initialized
INFO - 2024-03-10 15:48:24 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:24 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:24 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:24 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:24 --> Controller Class Initialized
INFO - 2024-03-10 15:48:24 --> Form Validation Class Initialized
INFO - 2024-03-10 15:48:24 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:48:24 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:48:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:26 --> Config Class Initialized
INFO - 2024-03-10 15:48:26 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:26 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:26 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:26 --> URI Class Initialized
INFO - 2024-03-10 15:48:26 --> Router Class Initialized
INFO - 2024-03-10 15:48:26 --> Output Class Initialized
INFO - 2024-03-10 15:48:26 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:26 --> Input Class Initialized
INFO - 2024-03-10 15:48:26 --> Language Class Initialized
INFO - 2024-03-10 15:48:26 --> Loader Class Initialized
INFO - 2024-03-10 15:48:26 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:26 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:26 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:26 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:26 --> Controller Class Initialized
INFO - 2024-03-10 15:48:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:48:26 --> Final output sent to browser
DEBUG - 2024-03-10 15:48:26 --> Total execution time: 0.0104
ERROR - 2024-03-10 15:48:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:48:28 --> Config Class Initialized
INFO - 2024-03-10 15:48:28 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:48:28 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:48:28 --> Utf8 Class Initialized
INFO - 2024-03-10 15:48:28 --> URI Class Initialized
INFO - 2024-03-10 15:48:28 --> Router Class Initialized
INFO - 2024-03-10 15:48:28 --> Output Class Initialized
INFO - 2024-03-10 15:48:28 --> Security Class Initialized
DEBUG - 2024-03-10 15:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:48:28 --> Input Class Initialized
INFO - 2024-03-10 15:48:28 --> Language Class Initialized
INFO - 2024-03-10 15:48:28 --> Loader Class Initialized
INFO - 2024-03-10 15:48:28 --> Helper loaded: url_helper
INFO - 2024-03-10 15:48:28 --> Helper loaded: file_helper
INFO - 2024-03-10 15:48:28 --> Helper loaded: form_helper
INFO - 2024-03-10 15:48:28 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:48:28 --> Controller Class Initialized
INFO - 2024-03-10 15:48:28 --> Form Validation Class Initialized
INFO - 2024-03-10 15:48:28 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:48:28 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:48:28 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:48:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:48:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:48:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:48:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:48:28 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:48:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:48:28 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:48:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-10 15:48:28 --> Final output sent to browser
DEBUG - 2024-03-10 15:48:28 --> Total execution time: 0.0191
ERROR - 2024-03-10 15:49:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:49:10 --> Config Class Initialized
INFO - 2024-03-10 15:49:10 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:49:10 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:49:10 --> Utf8 Class Initialized
INFO - 2024-03-10 15:49:10 --> URI Class Initialized
INFO - 2024-03-10 15:49:10 --> Router Class Initialized
INFO - 2024-03-10 15:49:10 --> Output Class Initialized
INFO - 2024-03-10 15:49:10 --> Security Class Initialized
DEBUG - 2024-03-10 15:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:49:10 --> Input Class Initialized
INFO - 2024-03-10 15:49:10 --> Language Class Initialized
INFO - 2024-03-10 15:49:10 --> Loader Class Initialized
INFO - 2024-03-10 15:49:10 --> Helper loaded: url_helper
INFO - 2024-03-10 15:49:10 --> Helper loaded: file_helper
INFO - 2024-03-10 15:49:10 --> Helper loaded: form_helper
INFO - 2024-03-10 15:49:10 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:49:10 --> Controller Class Initialized
INFO - 2024-03-10 15:49:10 --> Form Validation Class Initialized
INFO - 2024-03-10 15:49:10 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:49:10 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:49:10 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:49:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:49:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:49:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:49:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:49:10 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:49:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:49:10 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 15:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 15:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 15:49:10 --> Final output sent to browser
DEBUG - 2024-03-10 15:49:10 --> Total execution time: 0.0209
ERROR - 2024-03-10 15:49:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:49:11 --> Config Class Initialized
INFO - 2024-03-10 15:49:11 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:49:11 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:49:11 --> Utf8 Class Initialized
INFO - 2024-03-10 15:49:11 --> URI Class Initialized
INFO - 2024-03-10 15:49:11 --> Router Class Initialized
INFO - 2024-03-10 15:49:11 --> Output Class Initialized
INFO - 2024-03-10 15:49:11 --> Security Class Initialized
DEBUG - 2024-03-10 15:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:49:11 --> Input Class Initialized
INFO - 2024-03-10 15:49:11 --> Language Class Initialized
INFO - 2024-03-10 15:49:11 --> Loader Class Initialized
INFO - 2024-03-10 15:49:11 --> Helper loaded: url_helper
INFO - 2024-03-10 15:49:11 --> Helper loaded: file_helper
INFO - 2024-03-10 15:49:11 --> Helper loaded: form_helper
INFO - 2024-03-10 15:49:11 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:49:11 --> Controller Class Initialized
INFO - 2024-03-10 15:49:11 --> Form Validation Class Initialized
INFO - 2024-03-10 15:49:11 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:49:11 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:49:11 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:49:11 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:49:11 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:49:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:49:11 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:49:11 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:49:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:49:11 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:49:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:49:13 --> Config Class Initialized
INFO - 2024-03-10 15:49:13 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:49:13 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:49:13 --> Utf8 Class Initialized
INFO - 2024-03-10 15:49:13 --> URI Class Initialized
INFO - 2024-03-10 15:49:13 --> Router Class Initialized
INFO - 2024-03-10 15:49:13 --> Output Class Initialized
INFO - 2024-03-10 15:49:13 --> Security Class Initialized
DEBUG - 2024-03-10 15:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:49:13 --> Input Class Initialized
INFO - 2024-03-10 15:49:13 --> Language Class Initialized
INFO - 2024-03-10 15:49:13 --> Loader Class Initialized
INFO - 2024-03-10 15:49:13 --> Helper loaded: url_helper
INFO - 2024-03-10 15:49:13 --> Helper loaded: file_helper
INFO - 2024-03-10 15:49:13 --> Helper loaded: form_helper
INFO - 2024-03-10 15:49:13 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:49:13 --> Controller Class Initialized
INFO - 2024-03-10 15:49:13 --> Form Validation Class Initialized
INFO - 2024-03-10 15:49:13 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:49:13 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:49:13 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:49:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:49:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:49:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:49:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:49:13 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:49:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:49:13 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:49:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-10 15:49:13 --> Final output sent to browser
DEBUG - 2024-03-10 15:49:13 --> Total execution time: 0.0182
ERROR - 2024-03-10 15:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:50:40 --> Config Class Initialized
INFO - 2024-03-10 15:50:40 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:50:40 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:50:40 --> Utf8 Class Initialized
INFO - 2024-03-10 15:50:40 --> URI Class Initialized
INFO - 2024-03-10 15:50:40 --> Router Class Initialized
INFO - 2024-03-10 15:50:40 --> Output Class Initialized
INFO - 2024-03-10 15:50:40 --> Security Class Initialized
DEBUG - 2024-03-10 15:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:50:40 --> Input Class Initialized
INFO - 2024-03-10 15:50:40 --> Language Class Initialized
INFO - 2024-03-10 15:50:40 --> Loader Class Initialized
INFO - 2024-03-10 15:50:40 --> Helper loaded: url_helper
INFO - 2024-03-10 15:50:40 --> Helper loaded: file_helper
INFO - 2024-03-10 15:50:40 --> Helper loaded: form_helper
INFO - 2024-03-10 15:50:40 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:50:40 --> Controller Class Initialized
INFO - 2024-03-10 15:50:40 --> Form Validation Class Initialized
INFO - 2024-03-10 15:50:40 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:50:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:50:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:50:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:50:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:50:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:50:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-10 15:50:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-10 15:50:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-10 15:50:40 --> Final output sent to browser
DEBUG - 2024-03-10 15:50:40 --> Total execution time: 0.0210
ERROR - 2024-03-10 15:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:50:40 --> Config Class Initialized
INFO - 2024-03-10 15:50:40 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:50:40 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:50:40 --> Utf8 Class Initialized
INFO - 2024-03-10 15:50:40 --> URI Class Initialized
INFO - 2024-03-10 15:50:40 --> Router Class Initialized
INFO - 2024-03-10 15:50:40 --> Output Class Initialized
INFO - 2024-03-10 15:50:40 --> Security Class Initialized
DEBUG - 2024-03-10 15:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:50:40 --> Input Class Initialized
INFO - 2024-03-10 15:50:40 --> Language Class Initialized
INFO - 2024-03-10 15:50:40 --> Loader Class Initialized
INFO - 2024-03-10 15:50:40 --> Helper loaded: url_helper
INFO - 2024-03-10 15:50:40 --> Helper loaded: file_helper
INFO - 2024-03-10 15:50:40 --> Helper loaded: form_helper
INFO - 2024-03-10 15:50:40 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:50:40 --> Controller Class Initialized
INFO - 2024-03-10 15:50:40 --> Form Validation Class Initialized
INFO - 2024-03-10 15:50:40 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:50:40 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:50:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:50:44 --> Config Class Initialized
INFO - 2024-03-10 15:50:44 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:50:44 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:50:44 --> Utf8 Class Initialized
INFO - 2024-03-10 15:50:44 --> URI Class Initialized
INFO - 2024-03-10 15:50:44 --> Router Class Initialized
INFO - 2024-03-10 15:50:44 --> Output Class Initialized
INFO - 2024-03-10 15:50:44 --> Security Class Initialized
DEBUG - 2024-03-10 15:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:50:44 --> Input Class Initialized
INFO - 2024-03-10 15:50:44 --> Language Class Initialized
INFO - 2024-03-10 15:50:44 --> Loader Class Initialized
INFO - 2024-03-10 15:50:44 --> Helper loaded: url_helper
INFO - 2024-03-10 15:50:44 --> Helper loaded: file_helper
INFO - 2024-03-10 15:50:44 --> Helper loaded: form_helper
INFO - 2024-03-10 15:50:44 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:50:44 --> Controller Class Initialized
INFO - 2024-03-10 15:50:44 --> Form Validation Class Initialized
INFO - 2024-03-10 15:50:44 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:50:44 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:50:44 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:50:44 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:50:44 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:50:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:50:44 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:50:44 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:50:44 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:50:44 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:50:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-10 15:50:44 --> Final output sent to browser
DEBUG - 2024-03-10 15:50:44 --> Total execution time: 0.0164
ERROR - 2024-03-10 15:50:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:50:54 --> Config Class Initialized
INFO - 2024-03-10 15:50:54 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:50:54 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:50:54 --> Utf8 Class Initialized
INFO - 2024-03-10 15:50:54 --> URI Class Initialized
INFO - 2024-03-10 15:50:54 --> Router Class Initialized
INFO - 2024-03-10 15:50:54 --> Output Class Initialized
INFO - 2024-03-10 15:50:54 --> Security Class Initialized
DEBUG - 2024-03-10 15:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:50:54 --> Input Class Initialized
INFO - 2024-03-10 15:50:54 --> Language Class Initialized
INFO - 2024-03-10 15:50:54 --> Loader Class Initialized
INFO - 2024-03-10 15:50:54 --> Helper loaded: url_helper
INFO - 2024-03-10 15:50:54 --> Helper loaded: file_helper
INFO - 2024-03-10 15:50:54 --> Helper loaded: form_helper
INFO - 2024-03-10 15:50:54 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:50:54 --> Controller Class Initialized
INFO - 2024-03-10 15:50:54 --> Form Validation Class Initialized
INFO - 2024-03-10 15:50:54 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:50:54 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:50:54 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:50:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:50:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:50:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:50:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:50:54 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:50:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:50:54 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:51:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:51:06 --> Config Class Initialized
INFO - 2024-03-10 15:51:06 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:51:06 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:51:06 --> Utf8 Class Initialized
INFO - 2024-03-10 15:51:06 --> URI Class Initialized
INFO - 2024-03-10 15:51:06 --> Router Class Initialized
INFO - 2024-03-10 15:51:06 --> Output Class Initialized
INFO - 2024-03-10 15:51:06 --> Security Class Initialized
DEBUG - 2024-03-10 15:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:51:06 --> Input Class Initialized
INFO - 2024-03-10 15:51:06 --> Language Class Initialized
INFO - 2024-03-10 15:51:06 --> Loader Class Initialized
INFO - 2024-03-10 15:51:06 --> Helper loaded: url_helper
INFO - 2024-03-10 15:51:06 --> Helper loaded: file_helper
INFO - 2024-03-10 15:51:06 --> Helper loaded: form_helper
INFO - 2024-03-10 15:51:06 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:51:06 --> Controller Class Initialized
INFO - 2024-03-10 15:51:06 --> Form Validation Class Initialized
INFO - 2024-03-10 15:51:06 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:51:06 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:51:06 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:51:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:51:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:51:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:51:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:51:06 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:51:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:51:06 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:51:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:51:09 --> Config Class Initialized
INFO - 2024-03-10 15:51:09 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:51:09 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:51:09 --> Utf8 Class Initialized
INFO - 2024-03-10 15:51:09 --> URI Class Initialized
INFO - 2024-03-10 15:51:09 --> Router Class Initialized
INFO - 2024-03-10 15:51:09 --> Output Class Initialized
INFO - 2024-03-10 15:51:09 --> Security Class Initialized
DEBUG - 2024-03-10 15:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:51:09 --> Input Class Initialized
INFO - 2024-03-10 15:51:09 --> Language Class Initialized
INFO - 2024-03-10 15:51:09 --> Loader Class Initialized
INFO - 2024-03-10 15:51:09 --> Helper loaded: url_helper
INFO - 2024-03-10 15:51:09 --> Helper loaded: file_helper
INFO - 2024-03-10 15:51:09 --> Helper loaded: form_helper
INFO - 2024-03-10 15:51:09 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:51:09 --> Controller Class Initialized
INFO - 2024-03-10 15:51:09 --> Form Validation Class Initialized
INFO - 2024-03-10 15:51:09 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:51:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:51:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:51:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:51:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:51:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:51:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-10 15:51:09 --> Final output sent to browser
DEBUG - 2024-03-10 15:51:09 --> Total execution time: 0.0156
ERROR - 2024-03-10 15:51:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:51:09 --> Config Class Initialized
INFO - 2024-03-10 15:51:09 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:51:09 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:51:09 --> Utf8 Class Initialized
INFO - 2024-03-10 15:51:09 --> URI Class Initialized
INFO - 2024-03-10 15:51:09 --> Router Class Initialized
INFO - 2024-03-10 15:51:09 --> Output Class Initialized
INFO - 2024-03-10 15:51:09 --> Security Class Initialized
DEBUG - 2024-03-10 15:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:51:09 --> Input Class Initialized
INFO - 2024-03-10 15:51:09 --> Language Class Initialized
INFO - 2024-03-10 15:51:09 --> Loader Class Initialized
INFO - 2024-03-10 15:51:09 --> Helper loaded: url_helper
INFO - 2024-03-10 15:51:09 --> Helper loaded: file_helper
INFO - 2024-03-10 15:51:09 --> Helper loaded: form_helper
INFO - 2024-03-10 15:51:09 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:51:09 --> Controller Class Initialized
INFO - 2024-03-10 15:51:09 --> Form Validation Class Initialized
INFO - 2024-03-10 15:51:09 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:51:09 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:51:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:51:11 --> Config Class Initialized
INFO - 2024-03-10 15:51:11 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:51:11 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:51:11 --> Utf8 Class Initialized
INFO - 2024-03-10 15:51:11 --> URI Class Initialized
INFO - 2024-03-10 15:51:11 --> Router Class Initialized
INFO - 2024-03-10 15:51:11 --> Output Class Initialized
INFO - 2024-03-10 15:51:11 --> Security Class Initialized
DEBUG - 2024-03-10 15:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:51:11 --> Input Class Initialized
INFO - 2024-03-10 15:51:11 --> Language Class Initialized
INFO - 2024-03-10 15:51:11 --> Loader Class Initialized
INFO - 2024-03-10 15:51:11 --> Helper loaded: url_helper
INFO - 2024-03-10 15:51:11 --> Helper loaded: file_helper
INFO - 2024-03-10 15:51:11 --> Helper loaded: form_helper
INFO - 2024-03-10 15:51:11 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:51:11 --> Controller Class Initialized
INFO - 2024-03-10 15:51:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:51:11 --> Final output sent to browser
DEBUG - 2024-03-10 15:51:11 --> Total execution time: 0.0193
ERROR - 2024-03-10 15:52:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:52:54 --> Config Class Initialized
INFO - 2024-03-10 15:52:54 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:52:54 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:52:54 --> Utf8 Class Initialized
INFO - 2024-03-10 15:52:54 --> URI Class Initialized
INFO - 2024-03-10 15:52:54 --> Router Class Initialized
INFO - 2024-03-10 15:52:54 --> Output Class Initialized
INFO - 2024-03-10 15:52:54 --> Security Class Initialized
DEBUG - 2024-03-10 15:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:52:54 --> Input Class Initialized
INFO - 2024-03-10 15:52:54 --> Language Class Initialized
INFO - 2024-03-10 15:52:54 --> Loader Class Initialized
INFO - 2024-03-10 15:52:54 --> Helper loaded: url_helper
INFO - 2024-03-10 15:52:54 --> Helper loaded: file_helper
INFO - 2024-03-10 15:52:54 --> Helper loaded: form_helper
INFO - 2024-03-10 15:52:54 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:52:54 --> Controller Class Initialized
INFO - 2024-03-10 15:52:54 --> Form Validation Class Initialized
INFO - 2024-03-10 15:52:54 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:52:54 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:52:54 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:52:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:52:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:52:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:52:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:52:54 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:52:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:52:54 --> Model "ReportModel" initialized
INFO - 2024-03-10 15:52:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 15:52:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 15:52:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 15:52:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 15:52:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 15:52:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 15:52:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 15:52:54 --> Final output sent to browser
DEBUG - 2024-03-10 15:52:54 --> Total execution time: 0.0165
ERROR - 2024-03-10 15:52:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:52:54 --> Config Class Initialized
INFO - 2024-03-10 15:52:54 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:52:54 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:52:54 --> Utf8 Class Initialized
INFO - 2024-03-10 15:52:54 --> URI Class Initialized
INFO - 2024-03-10 15:52:54 --> Router Class Initialized
INFO - 2024-03-10 15:52:54 --> Output Class Initialized
INFO - 2024-03-10 15:52:54 --> Security Class Initialized
DEBUG - 2024-03-10 15:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:52:54 --> Input Class Initialized
INFO - 2024-03-10 15:52:54 --> Language Class Initialized
INFO - 2024-03-10 15:52:54 --> Loader Class Initialized
INFO - 2024-03-10 15:52:54 --> Helper loaded: url_helper
INFO - 2024-03-10 15:52:54 --> Helper loaded: file_helper
INFO - 2024-03-10 15:52:54 --> Helper loaded: form_helper
INFO - 2024-03-10 15:52:55 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:52:55 --> Controller Class Initialized
INFO - 2024-03-10 15:52:55 --> Form Validation Class Initialized
INFO - 2024-03-10 15:52:55 --> Model "MasterModel" initialized
INFO - 2024-03-10 15:52:55 --> Model "NotificationModel" initialized
INFO - 2024-03-10 15:52:55 --> Model "DashboardModel" initialized
INFO - 2024-03-10 15:52:55 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 15:52:55 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 15:52:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 15:52:55 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 15:52:55 --> Model "OrderModel" initialized
INFO - 2024-03-10 15:52:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 15:52:55 --> Model "ReportModel" initialized
ERROR - 2024-03-10 15:52:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:52:56 --> Config Class Initialized
INFO - 2024-03-10 15:52:56 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:52:56 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:52:56 --> Utf8 Class Initialized
INFO - 2024-03-10 15:52:56 --> URI Class Initialized
INFO - 2024-03-10 15:52:56 --> Router Class Initialized
INFO - 2024-03-10 15:52:56 --> Output Class Initialized
INFO - 2024-03-10 15:52:56 --> Security Class Initialized
DEBUG - 2024-03-10 15:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:52:56 --> Input Class Initialized
INFO - 2024-03-10 15:52:56 --> Language Class Initialized
INFO - 2024-03-10 15:52:56 --> Loader Class Initialized
INFO - 2024-03-10 15:52:56 --> Helper loaded: url_helper
INFO - 2024-03-10 15:52:56 --> Helper loaded: file_helper
INFO - 2024-03-10 15:52:56 --> Helper loaded: form_helper
INFO - 2024-03-10 15:52:56 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:52:56 --> Controller Class Initialized
INFO - 2024-03-10 15:52:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:52:56 --> Final output sent to browser
DEBUG - 2024-03-10 15:52:56 --> Total execution time: 0.0153
ERROR - 2024-03-10 15:52:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:52:57 --> Config Class Initialized
INFO - 2024-03-10 15:52:57 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:52:57 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:52:57 --> Utf8 Class Initialized
INFO - 2024-03-10 15:52:57 --> URI Class Initialized
INFO - 2024-03-10 15:52:57 --> Router Class Initialized
INFO - 2024-03-10 15:52:57 --> Output Class Initialized
INFO - 2024-03-10 15:52:57 --> Security Class Initialized
DEBUG - 2024-03-10 15:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:52:57 --> Input Class Initialized
INFO - 2024-03-10 15:52:57 --> Language Class Initialized
INFO - 2024-03-10 15:52:57 --> Loader Class Initialized
INFO - 2024-03-10 15:52:57 --> Helper loaded: url_helper
INFO - 2024-03-10 15:52:57 --> Helper loaded: file_helper
INFO - 2024-03-10 15:52:57 --> Helper loaded: form_helper
INFO - 2024-03-10 15:52:57 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:52:57 --> Controller Class Initialized
INFO - 2024-03-10 15:52:57 --> Model "LoginModel" initialized
INFO - 2024-03-10 15:52:57 --> Form Validation Class Initialized
ERROR - 2024-03-10 15:52:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:52:57 --> Config Class Initialized
INFO - 2024-03-10 15:52:57 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:52:57 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:52:57 --> Utf8 Class Initialized
INFO - 2024-03-10 15:52:57 --> URI Class Initialized
INFO - 2024-03-10 15:52:57 --> Router Class Initialized
INFO - 2024-03-10 15:52:57 --> Output Class Initialized
INFO - 2024-03-10 15:52:57 --> Security Class Initialized
DEBUG - 2024-03-10 15:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:52:57 --> Input Class Initialized
INFO - 2024-03-10 15:52:57 --> Language Class Initialized
INFO - 2024-03-10 15:52:57 --> Loader Class Initialized
INFO - 2024-03-10 15:52:57 --> Helper loaded: url_helper
INFO - 2024-03-10 15:52:57 --> Helper loaded: file_helper
INFO - 2024-03-10 15:52:57 --> Helper loaded: form_helper
INFO - 2024-03-10 15:52:57 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:52:57 --> Controller Class Initialized
INFO - 2024-03-10 15:52:57 --> Model "LoginModel" initialized
INFO - 2024-03-10 15:52:57 --> Form Validation Class Initialized
INFO - 2024-03-10 15:52:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-10 15:52:57 --> Final output sent to browser
DEBUG - 2024-03-10 15:52:57 --> Total execution time: 0.0125
ERROR - 2024-03-10 15:52:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:52:59 --> Config Class Initialized
INFO - 2024-03-10 15:52:59 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:52:59 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:52:59 --> Utf8 Class Initialized
INFO - 2024-03-10 15:52:59 --> URI Class Initialized
INFO - 2024-03-10 15:52:59 --> Router Class Initialized
INFO - 2024-03-10 15:52:59 --> Output Class Initialized
INFO - 2024-03-10 15:52:59 --> Security Class Initialized
DEBUG - 2024-03-10 15:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:52:59 --> Input Class Initialized
INFO - 2024-03-10 15:52:59 --> Language Class Initialized
INFO - 2024-03-10 15:52:59 --> Loader Class Initialized
INFO - 2024-03-10 15:52:59 --> Helper loaded: url_helper
INFO - 2024-03-10 15:52:59 --> Helper loaded: file_helper
INFO - 2024-03-10 15:52:59 --> Helper loaded: form_helper
INFO - 2024-03-10 15:52:59 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:52:59 --> Controller Class Initialized
INFO - 2024-03-10 15:52:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 15:52:59 --> Final output sent to browser
DEBUG - 2024-03-10 15:52:59 --> Total execution time: 0.0147
ERROR - 2024-03-10 15:54:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:54:00 --> Config Class Initialized
INFO - 2024-03-10 15:54:00 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:54:00 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:54:00 --> Utf8 Class Initialized
INFO - 2024-03-10 15:54:00 --> URI Class Initialized
INFO - 2024-03-10 15:54:00 --> Router Class Initialized
INFO - 2024-03-10 15:54:00 --> Output Class Initialized
INFO - 2024-03-10 15:54:00 --> Security Class Initialized
DEBUG - 2024-03-10 15:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:54:00 --> Input Class Initialized
INFO - 2024-03-10 15:54:00 --> Language Class Initialized
INFO - 2024-03-10 15:54:00 --> Loader Class Initialized
INFO - 2024-03-10 15:54:00 --> Helper loaded: url_helper
INFO - 2024-03-10 15:54:00 --> Helper loaded: file_helper
INFO - 2024-03-10 15:54:00 --> Helper loaded: form_helper
INFO - 2024-03-10 15:54:00 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:54:00 --> Controller Class Initialized
INFO - 2024-03-10 15:54:00 --> Model "LoginModel" initialized
INFO - 2024-03-10 15:54:00 --> Form Validation Class Initialized
INFO - 2024-03-10 15:54:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-10 15:54:00 --> Final output sent to browser
DEBUG - 2024-03-10 15:54:00 --> Total execution time: 0.0140
ERROR - 2024-03-10 15:54:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 15:54:13 --> Config Class Initialized
INFO - 2024-03-10 15:54:13 --> Hooks Class Initialized
DEBUG - 2024-03-10 15:54:13 --> UTF-8 Support Enabled
INFO - 2024-03-10 15:54:13 --> Utf8 Class Initialized
INFO - 2024-03-10 15:54:13 --> URI Class Initialized
INFO - 2024-03-10 15:54:13 --> Router Class Initialized
INFO - 2024-03-10 15:54:13 --> Output Class Initialized
INFO - 2024-03-10 15:54:13 --> Security Class Initialized
DEBUG - 2024-03-10 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 15:54:13 --> Input Class Initialized
INFO - 2024-03-10 15:54:13 --> Language Class Initialized
INFO - 2024-03-10 15:54:13 --> Loader Class Initialized
INFO - 2024-03-10 15:54:13 --> Helper loaded: url_helper
INFO - 2024-03-10 15:54:13 --> Helper loaded: file_helper
INFO - 2024-03-10 15:54:13 --> Helper loaded: form_helper
INFO - 2024-03-10 15:54:13 --> Database Driver Class Initialized
DEBUG - 2024-03-10 15:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 15:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 15:54:13 --> Controller Class Initialized
INFO - 2024-03-10 15:54:13 --> Model "LoginModel" initialized
INFO - 2024-03-10 15:54:13 --> Form Validation Class Initialized
INFO - 2024-03-10 15:54:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-10 15:54:13 --> Final output sent to browser
DEBUG - 2024-03-10 15:54:13 --> Total execution time: 0.0136
ERROR - 2024-03-10 16:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:11:45 --> Config Class Initialized
INFO - 2024-03-10 16:11:45 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:11:45 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:11:45 --> Utf8 Class Initialized
INFO - 2024-03-10 16:11:45 --> URI Class Initialized
INFO - 2024-03-10 16:11:45 --> Router Class Initialized
INFO - 2024-03-10 16:11:45 --> Output Class Initialized
INFO - 2024-03-10 16:11:45 --> Security Class Initialized
DEBUG - 2024-03-10 16:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:11:45 --> Input Class Initialized
INFO - 2024-03-10 16:11:45 --> Language Class Initialized
INFO - 2024-03-10 16:11:45 --> Loader Class Initialized
INFO - 2024-03-10 16:11:45 --> Helper loaded: url_helper
INFO - 2024-03-10 16:11:45 --> Helper loaded: file_helper
INFO - 2024-03-10 16:11:45 --> Helper loaded: form_helper
INFO - 2024-03-10 16:11:45 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:11:45 --> Controller Class Initialized
INFO - 2024-03-10 16:11:45 --> Model "LoginModel" initialized
INFO - 2024-03-10 16:11:45 --> Form Validation Class Initialized
INFO - 2024-03-10 16:11:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-10 16:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:11:45 --> Config Class Initialized
INFO - 2024-03-10 16:11:45 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:11:45 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:11:45 --> Utf8 Class Initialized
INFO - 2024-03-10 16:11:45 --> URI Class Initialized
INFO - 2024-03-10 16:11:45 --> Router Class Initialized
INFO - 2024-03-10 16:11:45 --> Output Class Initialized
INFO - 2024-03-10 16:11:45 --> Security Class Initialized
DEBUG - 2024-03-10 16:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:11:45 --> Input Class Initialized
INFO - 2024-03-10 16:11:45 --> Language Class Initialized
INFO - 2024-03-10 16:11:45 --> Loader Class Initialized
INFO - 2024-03-10 16:11:45 --> Helper loaded: url_helper
INFO - 2024-03-10 16:11:45 --> Helper loaded: file_helper
INFO - 2024-03-10 16:11:45 --> Helper loaded: form_helper
INFO - 2024-03-10 16:11:45 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:11:45 --> Controller Class Initialized
INFO - 2024-03-10 16:11:45 --> Model "LoginModel" initialized
INFO - 2024-03-10 16:11:45 --> Form Validation Class Initialized
INFO - 2024-03-10 16:11:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-10 16:11:45 --> Final output sent to browser
DEBUG - 2024-03-10 16:11:45 --> Total execution time: 0.0151
ERROR - 2024-03-10 16:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:11:47 --> Config Class Initialized
INFO - 2024-03-10 16:11:47 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:11:47 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:11:47 --> Utf8 Class Initialized
INFO - 2024-03-10 16:11:47 --> URI Class Initialized
INFO - 2024-03-10 16:11:47 --> Router Class Initialized
INFO - 2024-03-10 16:11:47 --> Output Class Initialized
INFO - 2024-03-10 16:11:47 --> Security Class Initialized
DEBUG - 2024-03-10 16:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:11:47 --> Input Class Initialized
INFO - 2024-03-10 16:11:47 --> Language Class Initialized
INFO - 2024-03-10 16:11:47 --> Loader Class Initialized
INFO - 2024-03-10 16:11:47 --> Helper loaded: url_helper
INFO - 2024-03-10 16:11:47 --> Helper loaded: file_helper
INFO - 2024-03-10 16:11:47 --> Helper loaded: form_helper
INFO - 2024-03-10 16:11:47 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:11:47 --> Controller Class Initialized
INFO - 2024-03-10 16:11:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 16:11:47 --> Final output sent to browser
DEBUG - 2024-03-10 16:11:47 --> Total execution time: 0.0147
ERROR - 2024-03-10 16:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:12:02 --> Config Class Initialized
INFO - 2024-03-10 16:12:02 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:12:02 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:12:02 --> Utf8 Class Initialized
INFO - 2024-03-10 16:12:02 --> URI Class Initialized
INFO - 2024-03-10 16:12:02 --> Router Class Initialized
INFO - 2024-03-10 16:12:02 --> Output Class Initialized
INFO - 2024-03-10 16:12:02 --> Security Class Initialized
DEBUG - 2024-03-10 16:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:12:02 --> Input Class Initialized
INFO - 2024-03-10 16:12:02 --> Language Class Initialized
INFO - 2024-03-10 16:12:02 --> Loader Class Initialized
INFO - 2024-03-10 16:12:02 --> Helper loaded: url_helper
INFO - 2024-03-10 16:12:02 --> Helper loaded: file_helper
INFO - 2024-03-10 16:12:02 --> Helper loaded: form_helper
INFO - 2024-03-10 16:12:02 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:12:02 --> Controller Class Initialized
INFO - 2024-03-10 16:12:02 --> Model "LoginModel" initialized
INFO - 2024-03-10 16:12:02 --> Form Validation Class Initialized
INFO - 2024-03-10 16:12:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-10 16:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:12:02 --> Config Class Initialized
INFO - 2024-03-10 16:12:02 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:12:02 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:12:02 --> Utf8 Class Initialized
INFO - 2024-03-10 16:12:02 --> URI Class Initialized
INFO - 2024-03-10 16:12:02 --> Router Class Initialized
INFO - 2024-03-10 16:12:02 --> Output Class Initialized
INFO - 2024-03-10 16:12:02 --> Security Class Initialized
DEBUG - 2024-03-10 16:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:12:02 --> Input Class Initialized
INFO - 2024-03-10 16:12:02 --> Language Class Initialized
INFO - 2024-03-10 16:12:02 --> Loader Class Initialized
INFO - 2024-03-10 16:12:02 --> Helper loaded: url_helper
INFO - 2024-03-10 16:12:02 --> Helper loaded: file_helper
INFO - 2024-03-10 16:12:02 --> Helper loaded: form_helper
INFO - 2024-03-10 16:12:02 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:12:02 --> Controller Class Initialized
INFO - 2024-03-10 16:12:02 --> Form Validation Class Initialized
INFO - 2024-03-10 16:12:02 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "ReportModel" initialized
INFO - 2024-03-10 16:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 16:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 16:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 16:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 16:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 16:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 16:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 16:12:02 --> Final output sent to browser
DEBUG - 2024-03-10 16:12:02 --> Total execution time: 0.0189
ERROR - 2024-03-10 16:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:12:02 --> Config Class Initialized
INFO - 2024-03-10 16:12:02 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:12:02 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:12:02 --> Utf8 Class Initialized
INFO - 2024-03-10 16:12:02 --> URI Class Initialized
INFO - 2024-03-10 16:12:02 --> Router Class Initialized
INFO - 2024-03-10 16:12:02 --> Output Class Initialized
INFO - 2024-03-10 16:12:02 --> Security Class Initialized
DEBUG - 2024-03-10 16:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:12:02 --> Input Class Initialized
INFO - 2024-03-10 16:12:02 --> Language Class Initialized
INFO - 2024-03-10 16:12:02 --> Loader Class Initialized
INFO - 2024-03-10 16:12:02 --> Helper loaded: url_helper
INFO - 2024-03-10 16:12:02 --> Helper loaded: file_helper
INFO - 2024-03-10 16:12:02 --> Helper loaded: form_helper
INFO - 2024-03-10 16:12:02 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:12:02 --> Controller Class Initialized
INFO - 2024-03-10 16:12:02 --> Form Validation Class Initialized
INFO - 2024-03-10 16:12:02 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:12:02 --> Model "ReportModel" initialized
ERROR - 2024-03-10 16:12:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:12:04 --> Config Class Initialized
INFO - 2024-03-10 16:12:04 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:12:04 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:12:04 --> Utf8 Class Initialized
INFO - 2024-03-10 16:12:04 --> URI Class Initialized
INFO - 2024-03-10 16:12:04 --> Router Class Initialized
INFO - 2024-03-10 16:12:04 --> Output Class Initialized
INFO - 2024-03-10 16:12:04 --> Security Class Initialized
DEBUG - 2024-03-10 16:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:12:04 --> Input Class Initialized
INFO - 2024-03-10 16:12:04 --> Language Class Initialized
INFO - 2024-03-10 16:12:04 --> Loader Class Initialized
INFO - 2024-03-10 16:12:04 --> Helper loaded: url_helper
INFO - 2024-03-10 16:12:04 --> Helper loaded: file_helper
INFO - 2024-03-10 16:12:04 --> Helper loaded: form_helper
INFO - 2024-03-10 16:12:04 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:12:04 --> Controller Class Initialized
INFO - 2024-03-10 16:12:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 16:12:04 --> Final output sent to browser
DEBUG - 2024-03-10 16:12:04 --> Total execution time: 0.0118
ERROR - 2024-03-10 16:12:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:12:05 --> Config Class Initialized
INFO - 2024-03-10 16:12:05 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:12:05 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:12:05 --> Utf8 Class Initialized
INFO - 2024-03-10 16:12:05 --> URI Class Initialized
INFO - 2024-03-10 16:12:05 --> Router Class Initialized
INFO - 2024-03-10 16:12:05 --> Output Class Initialized
INFO - 2024-03-10 16:12:05 --> Security Class Initialized
DEBUG - 2024-03-10 16:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:12:05 --> Input Class Initialized
INFO - 2024-03-10 16:12:05 --> Language Class Initialized
INFO - 2024-03-10 16:12:05 --> Loader Class Initialized
INFO - 2024-03-10 16:12:05 --> Helper loaded: url_helper
INFO - 2024-03-10 16:12:05 --> Helper loaded: file_helper
INFO - 2024-03-10 16:12:05 --> Helper loaded: form_helper
INFO - 2024-03-10 16:12:05 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:12:05 --> Controller Class Initialized
INFO - 2024-03-10 16:12:05 --> Form Validation Class Initialized
INFO - 2024-03-10 16:12:05 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "ReportModel" initialized
INFO - 2024-03-10 16:12:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 16:12:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 16:12:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 16:12:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 16:12:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 16:12:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-10 16:12:05 --> Final output sent to browser
DEBUG - 2024-03-10 16:12:05 --> Total execution time: 0.0166
ERROR - 2024-03-10 16:12:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:12:05 --> Config Class Initialized
INFO - 2024-03-10 16:12:05 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:12:05 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:12:05 --> Utf8 Class Initialized
INFO - 2024-03-10 16:12:05 --> URI Class Initialized
INFO - 2024-03-10 16:12:05 --> Router Class Initialized
INFO - 2024-03-10 16:12:05 --> Output Class Initialized
INFO - 2024-03-10 16:12:05 --> Security Class Initialized
DEBUG - 2024-03-10 16:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:12:05 --> Input Class Initialized
INFO - 2024-03-10 16:12:05 --> Language Class Initialized
INFO - 2024-03-10 16:12:05 --> Loader Class Initialized
INFO - 2024-03-10 16:12:05 --> Helper loaded: url_helper
INFO - 2024-03-10 16:12:05 --> Helper loaded: file_helper
INFO - 2024-03-10 16:12:05 --> Helper loaded: form_helper
INFO - 2024-03-10 16:12:05 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:12:05 --> Controller Class Initialized
INFO - 2024-03-10 16:12:05 --> Form Validation Class Initialized
INFO - 2024-03-10 16:12:05 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:12:05 --> Model "ReportModel" initialized
ERROR - 2024-03-10 16:12:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:12:07 --> Config Class Initialized
INFO - 2024-03-10 16:12:07 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:12:07 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:12:07 --> Utf8 Class Initialized
INFO - 2024-03-10 16:12:07 --> URI Class Initialized
INFO - 2024-03-10 16:12:07 --> Router Class Initialized
INFO - 2024-03-10 16:12:07 --> Output Class Initialized
INFO - 2024-03-10 16:12:07 --> Security Class Initialized
DEBUG - 2024-03-10 16:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:12:07 --> Input Class Initialized
INFO - 2024-03-10 16:12:07 --> Language Class Initialized
INFO - 2024-03-10 16:12:07 --> Loader Class Initialized
INFO - 2024-03-10 16:12:07 --> Helper loaded: url_helper
INFO - 2024-03-10 16:12:07 --> Helper loaded: file_helper
INFO - 2024-03-10 16:12:07 --> Helper loaded: form_helper
INFO - 2024-03-10 16:12:07 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:12:07 --> Controller Class Initialized
INFO - 2024-03-10 16:12:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 16:12:07 --> Final output sent to browser
DEBUG - 2024-03-10 16:12:07 --> Total execution time: 0.0109
ERROR - 2024-03-10 16:30:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:27 --> Config Class Initialized
INFO - 2024-03-10 16:30:27 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:27 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:27 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:27 --> URI Class Initialized
INFO - 2024-03-10 16:30:27 --> Router Class Initialized
INFO - 2024-03-10 16:30:27 --> Output Class Initialized
INFO - 2024-03-10 16:30:27 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:27 --> Input Class Initialized
INFO - 2024-03-10 16:30:27 --> Language Class Initialized
INFO - 2024-03-10 16:30:27 --> Loader Class Initialized
INFO - 2024-03-10 16:30:27 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:27 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:27 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:27 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:27 --> Controller Class Initialized
INFO - 2024-03-10 16:30:27 --> Form Validation Class Initialized
INFO - 2024-03-10 16:30:27 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:30:27 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:30:27 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:30:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:30:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:30:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:30:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:30:27 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:30:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:30:27 --> Model "ReportModel" initialized
INFO - 2024-03-10 16:30:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 16:30:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 16:30:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 16:30:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 16:30:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 16:30:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 16:30:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 16:30:27 --> Final output sent to browser
DEBUG - 2024-03-10 16:30:27 --> Total execution time: 0.0183
ERROR - 2024-03-10 16:30:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:28 --> Config Class Initialized
INFO - 2024-03-10 16:30:28 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:28 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:28 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:28 --> URI Class Initialized
INFO - 2024-03-10 16:30:28 --> Router Class Initialized
INFO - 2024-03-10 16:30:28 --> Output Class Initialized
INFO - 2024-03-10 16:30:28 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:28 --> Input Class Initialized
INFO - 2024-03-10 16:30:28 --> Language Class Initialized
INFO - 2024-03-10 16:30:28 --> Loader Class Initialized
INFO - 2024-03-10 16:30:28 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:28 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:28 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:28 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:28 --> Controller Class Initialized
INFO - 2024-03-10 16:30:28 --> Form Validation Class Initialized
INFO - 2024-03-10 16:30:28 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:30:28 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:30:28 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:30:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:30:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:30:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:30:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:30:28 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:30:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:30:28 --> Model "ReportModel" initialized
ERROR - 2024-03-10 16:30:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:29 --> Config Class Initialized
INFO - 2024-03-10 16:30:29 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:29 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:29 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:29 --> URI Class Initialized
INFO - 2024-03-10 16:30:29 --> Router Class Initialized
INFO - 2024-03-10 16:30:29 --> Output Class Initialized
INFO - 2024-03-10 16:30:29 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:29 --> Input Class Initialized
INFO - 2024-03-10 16:30:29 --> Language Class Initialized
INFO - 2024-03-10 16:30:29 --> Loader Class Initialized
INFO - 2024-03-10 16:30:29 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:29 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:29 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:29 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:29 --> Controller Class Initialized
INFO - 2024-03-10 16:30:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 16:30:29 --> Final output sent to browser
DEBUG - 2024-03-10 16:30:29 --> Total execution time: 0.0138
ERROR - 2024-03-10 16:30:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:30 --> Config Class Initialized
INFO - 2024-03-10 16:30:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:30 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:30 --> URI Class Initialized
INFO - 2024-03-10 16:30:30 --> Router Class Initialized
INFO - 2024-03-10 16:30:30 --> Output Class Initialized
INFO - 2024-03-10 16:30:30 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:30 --> Input Class Initialized
INFO - 2024-03-10 16:30:30 --> Language Class Initialized
INFO - 2024-03-10 16:30:30 --> Loader Class Initialized
INFO - 2024-03-10 16:30:30 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:30 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:30 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:30 --> Controller Class Initialized
INFO - 2024-03-10 16:30:30 --> Model "LoginModel" initialized
INFO - 2024-03-10 16:30:30 --> Form Validation Class Initialized
ERROR - 2024-03-10 16:30:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:30 --> Config Class Initialized
INFO - 2024-03-10 16:30:30 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:30 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:30 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:30 --> URI Class Initialized
INFO - 2024-03-10 16:30:30 --> Router Class Initialized
INFO - 2024-03-10 16:30:30 --> Output Class Initialized
INFO - 2024-03-10 16:30:30 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:30 --> Input Class Initialized
INFO - 2024-03-10 16:30:30 --> Language Class Initialized
INFO - 2024-03-10 16:30:30 --> Loader Class Initialized
INFO - 2024-03-10 16:30:30 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:30 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:30 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:30 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:30 --> Controller Class Initialized
INFO - 2024-03-10 16:30:30 --> Model "LoginModel" initialized
INFO - 2024-03-10 16:30:30 --> Form Validation Class Initialized
INFO - 2024-03-10 16:30:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-10 16:30:30 --> Final output sent to browser
DEBUG - 2024-03-10 16:30:30 --> Total execution time: 0.0155
ERROR - 2024-03-10 16:30:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:32 --> Config Class Initialized
INFO - 2024-03-10 16:30:32 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:32 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:32 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:32 --> URI Class Initialized
INFO - 2024-03-10 16:30:32 --> Router Class Initialized
INFO - 2024-03-10 16:30:32 --> Output Class Initialized
INFO - 2024-03-10 16:30:32 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:32 --> Input Class Initialized
INFO - 2024-03-10 16:30:32 --> Language Class Initialized
INFO - 2024-03-10 16:30:32 --> Loader Class Initialized
INFO - 2024-03-10 16:30:32 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:32 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:32 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:32 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:32 --> Controller Class Initialized
INFO - 2024-03-10 16:30:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 16:30:32 --> Final output sent to browser
DEBUG - 2024-03-10 16:30:32 --> Total execution time: 0.0113
ERROR - 2024-03-10 16:30:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:37 --> Config Class Initialized
INFO - 2024-03-10 16:30:37 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:37 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:37 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:37 --> URI Class Initialized
INFO - 2024-03-10 16:30:37 --> Router Class Initialized
INFO - 2024-03-10 16:30:37 --> Output Class Initialized
INFO - 2024-03-10 16:30:37 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:37 --> Input Class Initialized
INFO - 2024-03-10 16:30:37 --> Language Class Initialized
INFO - 2024-03-10 16:30:37 --> Loader Class Initialized
INFO - 2024-03-10 16:30:37 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:37 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:37 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:37 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:37 --> Controller Class Initialized
INFO - 2024-03-10 16:30:37 --> Model "LoginModel" initialized
INFO - 2024-03-10 16:30:37 --> Form Validation Class Initialized
INFO - 2024-03-10 16:30:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-10 16:30:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:37 --> Config Class Initialized
INFO - 2024-03-10 16:30:37 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:37 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:37 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:37 --> URI Class Initialized
INFO - 2024-03-10 16:30:37 --> Router Class Initialized
INFO - 2024-03-10 16:30:37 --> Output Class Initialized
INFO - 2024-03-10 16:30:37 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:37 --> Input Class Initialized
INFO - 2024-03-10 16:30:37 --> Language Class Initialized
INFO - 2024-03-10 16:30:37 --> Loader Class Initialized
INFO - 2024-03-10 16:30:37 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:37 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:37 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:37 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:37 --> Controller Class Initialized
INFO - 2024-03-10 16:30:37 --> Form Validation Class Initialized
INFO - 2024-03-10 16:30:37 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:30:37 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:30:37 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:30:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:30:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:30:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:30:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:30:37 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:30:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:30:37 --> Model "ReportModel" initialized
INFO - 2024-03-10 16:30:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 16:30:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 16:30:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 16:30:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 16:30:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 16:30:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 16:30:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 16:30:37 --> Final output sent to browser
DEBUG - 2024-03-10 16:30:37 --> Total execution time: 0.0152
ERROR - 2024-03-10 16:30:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:37 --> Config Class Initialized
INFO - 2024-03-10 16:30:37 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:37 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:37 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:38 --> URI Class Initialized
INFO - 2024-03-10 16:30:38 --> Router Class Initialized
INFO - 2024-03-10 16:30:38 --> Output Class Initialized
INFO - 2024-03-10 16:30:38 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:38 --> Input Class Initialized
INFO - 2024-03-10 16:30:38 --> Language Class Initialized
INFO - 2024-03-10 16:30:38 --> Loader Class Initialized
INFO - 2024-03-10 16:30:38 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:38 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:38 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:38 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:38 --> Controller Class Initialized
INFO - 2024-03-10 16:30:38 --> Form Validation Class Initialized
INFO - 2024-03-10 16:30:38 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:30:38 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:30:38 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:30:38 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:30:38 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:30:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:30:38 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:30:38 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:30:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:30:38 --> Model "ReportModel" initialized
ERROR - 2024-03-10 16:30:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:39 --> Config Class Initialized
INFO - 2024-03-10 16:30:39 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:39 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:39 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:39 --> URI Class Initialized
INFO - 2024-03-10 16:30:39 --> Router Class Initialized
INFO - 2024-03-10 16:30:39 --> Output Class Initialized
INFO - 2024-03-10 16:30:39 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:39 --> Input Class Initialized
INFO - 2024-03-10 16:30:39 --> Language Class Initialized
INFO - 2024-03-10 16:30:39 --> Loader Class Initialized
INFO - 2024-03-10 16:30:39 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:39 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:39 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:39 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:39 --> Controller Class Initialized
INFO - 2024-03-10 16:30:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 16:30:39 --> Final output sent to browser
DEBUG - 2024-03-10 16:30:39 --> Total execution time: 0.0119
ERROR - 2024-03-10 16:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:41 --> Config Class Initialized
INFO - 2024-03-10 16:30:41 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:41 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:41 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:41 --> URI Class Initialized
INFO - 2024-03-10 16:30:41 --> Router Class Initialized
INFO - 2024-03-10 16:30:41 --> Output Class Initialized
INFO - 2024-03-10 16:30:41 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:41 --> Input Class Initialized
INFO - 2024-03-10 16:30:41 --> Language Class Initialized
INFO - 2024-03-10 16:30:41 --> Loader Class Initialized
INFO - 2024-03-10 16:30:41 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:41 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:41 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:41 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:41 --> Controller Class Initialized
INFO - 2024-03-10 16:30:41 --> Form Validation Class Initialized
INFO - 2024-03-10 16:30:41 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "ReportModel" initialized
INFO - 2024-03-10 16:30:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 16:30:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-10 16:30:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 16:30:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 16:30:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 16:30:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/index.php
INFO - 2024-03-10 16:30:41 --> Final output sent to browser
DEBUG - 2024-03-10 16:30:41 --> Total execution time: 0.0169
ERROR - 2024-03-10 16:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:41 --> Config Class Initialized
INFO - 2024-03-10 16:30:41 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:41 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:41 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:41 --> URI Class Initialized
INFO - 2024-03-10 16:30:41 --> Router Class Initialized
INFO - 2024-03-10 16:30:41 --> Output Class Initialized
INFO - 2024-03-10 16:30:41 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:41 --> Input Class Initialized
INFO - 2024-03-10 16:30:41 --> Language Class Initialized
INFO - 2024-03-10 16:30:41 --> Loader Class Initialized
INFO - 2024-03-10 16:30:41 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:41 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:41 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:41 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:41 --> Controller Class Initialized
INFO - 2024-03-10 16:30:41 --> Form Validation Class Initialized
INFO - 2024-03-10 16:30:41 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:30:41 --> Model "ReportModel" initialized
ERROR - 2024-03-10 16:30:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:42 --> Config Class Initialized
INFO - 2024-03-10 16:30:42 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:42 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:42 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:42 --> URI Class Initialized
INFO - 2024-03-10 16:30:42 --> Router Class Initialized
INFO - 2024-03-10 16:30:42 --> Output Class Initialized
INFO - 2024-03-10 16:30:42 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:42 --> Input Class Initialized
INFO - 2024-03-10 16:30:42 --> Language Class Initialized
INFO - 2024-03-10 16:30:42 --> Loader Class Initialized
INFO - 2024-03-10 16:30:42 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:42 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:42 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:42 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:42 --> Controller Class Initialized
INFO - 2024-03-10 16:30:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-10 16:30:42 --> Final output sent to browser
DEBUG - 2024-03-10 16:30:42 --> Total execution time: 0.0108
ERROR - 2024-03-10 16:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:55 --> Config Class Initialized
INFO - 2024-03-10 16:30:55 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:55 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:55 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:55 --> URI Class Initialized
INFO - 2024-03-10 16:30:55 --> Router Class Initialized
INFO - 2024-03-10 16:30:55 --> Output Class Initialized
INFO - 2024-03-10 16:30:55 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:55 --> Input Class Initialized
INFO - 2024-03-10 16:30:55 --> Language Class Initialized
INFO - 2024-03-10 16:30:55 --> Loader Class Initialized
INFO - 2024-03-10 16:30:55 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:55 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:55 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:55 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:55 --> Controller Class Initialized
INFO - 2024-03-10 16:30:55 --> Model "LoginModel" initialized
INFO - 2024-03-10 16:30:55 --> Form Validation Class Initialized
INFO - 2024-03-10 16:30:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-10 16:30:55 --> Final output sent to browser
DEBUG - 2024-03-10 16:30:55 --> Total execution time: 0.0197
ERROR - 2024-03-10 16:30:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:30:58 --> Config Class Initialized
INFO - 2024-03-10 16:30:58 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:30:58 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:30:58 --> Utf8 Class Initialized
INFO - 2024-03-10 16:30:58 --> URI Class Initialized
DEBUG - 2024-03-10 16:30:58 --> No URI present. Default controller set.
INFO - 2024-03-10 16:30:58 --> Router Class Initialized
INFO - 2024-03-10 16:30:58 --> Output Class Initialized
INFO - 2024-03-10 16:30:58 --> Security Class Initialized
DEBUG - 2024-03-10 16:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:30:58 --> Input Class Initialized
INFO - 2024-03-10 16:30:58 --> Language Class Initialized
INFO - 2024-03-10 16:30:58 --> Loader Class Initialized
INFO - 2024-03-10 16:30:58 --> Helper loaded: url_helper
INFO - 2024-03-10 16:30:58 --> Helper loaded: file_helper
INFO - 2024-03-10 16:30:58 --> Helper loaded: form_helper
INFO - 2024-03-10 16:30:58 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:30:58 --> Controller Class Initialized
INFO - 2024-03-10 16:30:58 --> Model "LoginModel" initialized
INFO - 2024-03-10 16:30:58 --> Form Validation Class Initialized
INFO - 2024-03-10 16:30:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-10 16:30:58 --> Final output sent to browser
DEBUG - 2024-03-10 16:30:58 --> Total execution time: 0.0199
ERROR - 2024-03-10 16:31:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:31:07 --> Config Class Initialized
INFO - 2024-03-10 16:31:07 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:31:07 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:31:07 --> Utf8 Class Initialized
INFO - 2024-03-10 16:31:07 --> URI Class Initialized
INFO - 2024-03-10 16:31:07 --> Router Class Initialized
INFO - 2024-03-10 16:31:07 --> Output Class Initialized
INFO - 2024-03-10 16:31:07 --> Security Class Initialized
DEBUG - 2024-03-10 16:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:31:07 --> Input Class Initialized
INFO - 2024-03-10 16:31:07 --> Language Class Initialized
INFO - 2024-03-10 16:31:07 --> Loader Class Initialized
INFO - 2024-03-10 16:31:07 --> Helper loaded: url_helper
INFO - 2024-03-10 16:31:07 --> Helper loaded: file_helper
INFO - 2024-03-10 16:31:07 --> Helper loaded: form_helper
INFO - 2024-03-10 16:31:07 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:31:07 --> Controller Class Initialized
INFO - 2024-03-10 16:31:07 --> Model "LoginModel" initialized
INFO - 2024-03-10 16:31:07 --> Form Validation Class Initialized
INFO - 2024-03-10 16:31:07 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-10 16:31:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:31:07 --> Config Class Initialized
INFO - 2024-03-10 16:31:07 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:31:07 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:31:07 --> Utf8 Class Initialized
INFO - 2024-03-10 16:31:07 --> URI Class Initialized
INFO - 2024-03-10 16:31:07 --> Router Class Initialized
INFO - 2024-03-10 16:31:07 --> Output Class Initialized
INFO - 2024-03-10 16:31:07 --> Security Class Initialized
DEBUG - 2024-03-10 16:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:31:07 --> Input Class Initialized
INFO - 2024-03-10 16:31:07 --> Language Class Initialized
INFO - 2024-03-10 16:31:07 --> Loader Class Initialized
INFO - 2024-03-10 16:31:07 --> Helper loaded: url_helper
INFO - 2024-03-10 16:31:07 --> Helper loaded: file_helper
INFO - 2024-03-10 16:31:07 --> Helper loaded: form_helper
INFO - 2024-03-10 16:31:07 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:31:07 --> Controller Class Initialized
INFO - 2024-03-10 16:31:07 --> Form Validation Class Initialized
INFO - 2024-03-10 16:31:07 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:31:07 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:31:07 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:31:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:31:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:31:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:31:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:31:07 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:31:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:31:07 --> Model "ReportModel" initialized
INFO - 2024-03-10 16:31:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 16:31:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-10 16:31:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 16:31:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 16:31:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 16:31:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 16:31:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-10 16:31:07 --> Final output sent to browser
DEBUG - 2024-03-10 16:31:07 --> Total execution time: 0.0157
ERROR - 2024-03-10 16:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:31:08 --> Config Class Initialized
INFO - 2024-03-10 16:31:08 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:31:08 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:31:08 --> Utf8 Class Initialized
INFO - 2024-03-10 16:31:08 --> URI Class Initialized
INFO - 2024-03-10 16:31:08 --> Router Class Initialized
INFO - 2024-03-10 16:31:08 --> Output Class Initialized
INFO - 2024-03-10 16:31:08 --> Security Class Initialized
DEBUG - 2024-03-10 16:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:31:08 --> Input Class Initialized
INFO - 2024-03-10 16:31:08 --> Language Class Initialized
INFO - 2024-03-10 16:31:08 --> Loader Class Initialized
INFO - 2024-03-10 16:31:08 --> Helper loaded: url_helper
INFO - 2024-03-10 16:31:08 --> Helper loaded: file_helper
INFO - 2024-03-10 16:31:08 --> Helper loaded: form_helper
INFO - 2024-03-10 16:31:08 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:31:08 --> Controller Class Initialized
INFO - 2024-03-10 16:31:08 --> Form Validation Class Initialized
INFO - 2024-03-10 16:31:08 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:31:08 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:31:08 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:31:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:31:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:31:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:31:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:31:08 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:31:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:31:08 --> Model "ReportModel" initialized
ERROR - 2024-03-10 16:31:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:31:10 --> Config Class Initialized
INFO - 2024-03-10 16:31:10 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:31:10 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:31:10 --> Utf8 Class Initialized
INFO - 2024-03-10 16:31:10 --> URI Class Initialized
INFO - 2024-03-10 16:31:10 --> Router Class Initialized
INFO - 2024-03-10 16:31:10 --> Output Class Initialized
INFO - 2024-03-10 16:31:10 --> Security Class Initialized
DEBUG - 2024-03-10 16:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:31:10 --> Input Class Initialized
INFO - 2024-03-10 16:31:10 --> Language Class Initialized
INFO - 2024-03-10 16:31:10 --> Loader Class Initialized
INFO - 2024-03-10 16:31:10 --> Helper loaded: url_helper
INFO - 2024-03-10 16:31:10 --> Helper loaded: file_helper
INFO - 2024-03-10 16:31:10 --> Helper loaded: form_helper
INFO - 2024-03-10 16:31:10 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:31:10 --> Controller Class Initialized
INFO - 2024-03-10 16:31:10 --> Form Validation Class Initialized
INFO - 2024-03-10 16:31:10 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "ReportModel" initialized
INFO - 2024-03-10 16:31:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 16:31:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 16:31:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 16:31:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 16:31:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 16:31:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-10 16:31:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-10 16:31:10 --> Final output sent to browser
DEBUG - 2024-03-10 16:31:10 --> Total execution time: 0.0185
ERROR - 2024-03-10 16:31:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:31:10 --> Config Class Initialized
INFO - 2024-03-10 16:31:10 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:31:10 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:31:10 --> Utf8 Class Initialized
INFO - 2024-03-10 16:31:10 --> URI Class Initialized
INFO - 2024-03-10 16:31:10 --> Router Class Initialized
INFO - 2024-03-10 16:31:10 --> Output Class Initialized
INFO - 2024-03-10 16:31:10 --> Security Class Initialized
DEBUG - 2024-03-10 16:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:31:10 --> Input Class Initialized
INFO - 2024-03-10 16:31:10 --> Language Class Initialized
INFO - 2024-03-10 16:31:10 --> Loader Class Initialized
INFO - 2024-03-10 16:31:10 --> Helper loaded: url_helper
INFO - 2024-03-10 16:31:10 --> Helper loaded: file_helper
INFO - 2024-03-10 16:31:10 --> Helper loaded: form_helper
INFO - 2024-03-10 16:31:10 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:31:10 --> Controller Class Initialized
INFO - 2024-03-10 16:31:10 --> Form Validation Class Initialized
INFO - 2024-03-10 16:31:10 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:31:10 --> Model "ReportModel" initialized
ERROR - 2024-03-10 16:34:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:34:10 --> Config Class Initialized
INFO - 2024-03-10 16:34:10 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:34:10 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:34:10 --> Utf8 Class Initialized
INFO - 2024-03-10 16:34:10 --> URI Class Initialized
INFO - 2024-03-10 16:34:10 --> Router Class Initialized
INFO - 2024-03-10 16:34:10 --> Output Class Initialized
INFO - 2024-03-10 16:34:10 --> Security Class Initialized
DEBUG - 2024-03-10 16:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:34:10 --> Input Class Initialized
INFO - 2024-03-10 16:34:10 --> Language Class Initialized
INFO - 2024-03-10 16:34:10 --> Loader Class Initialized
INFO - 2024-03-10 16:34:10 --> Helper loaded: url_helper
INFO - 2024-03-10 16:34:10 --> Helper loaded: file_helper
INFO - 2024-03-10 16:34:10 --> Helper loaded: form_helper
INFO - 2024-03-10 16:34:10 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:34:10 --> Controller Class Initialized
INFO - 2024-03-10 16:34:10 --> Form Validation Class Initialized
INFO - 2024-03-10 16:34:10 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "ReportModel" initialized
INFO - 2024-03-10 16:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 16:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 16:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 16:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 16:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 16:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-10 16:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-10 16:34:10 --> Final output sent to browser
DEBUG - 2024-03-10 16:34:10 --> Total execution time: 0.0198
ERROR - 2024-03-10 16:34:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:34:10 --> Config Class Initialized
INFO - 2024-03-10 16:34:10 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:34:10 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:34:10 --> Utf8 Class Initialized
INFO - 2024-03-10 16:34:10 --> URI Class Initialized
INFO - 2024-03-10 16:34:10 --> Router Class Initialized
INFO - 2024-03-10 16:34:10 --> Output Class Initialized
INFO - 2024-03-10 16:34:10 --> Security Class Initialized
DEBUG - 2024-03-10 16:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:34:10 --> Input Class Initialized
INFO - 2024-03-10 16:34:10 --> Language Class Initialized
INFO - 2024-03-10 16:34:10 --> Loader Class Initialized
INFO - 2024-03-10 16:34:10 --> Helper loaded: url_helper
INFO - 2024-03-10 16:34:10 --> Helper loaded: file_helper
INFO - 2024-03-10 16:34:10 --> Helper loaded: form_helper
INFO - 2024-03-10 16:34:10 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:34:10 --> Controller Class Initialized
INFO - 2024-03-10 16:34:10 --> Form Validation Class Initialized
INFO - 2024-03-10 16:34:10 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:34:10 --> Model "ReportModel" initialized
ERROR - 2024-03-10 16:34:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:34:17 --> Config Class Initialized
INFO - 2024-03-10 16:34:17 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:34:17 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:34:17 --> Utf8 Class Initialized
INFO - 2024-03-10 16:34:17 --> URI Class Initialized
INFO - 2024-03-10 16:34:17 --> Router Class Initialized
INFO - 2024-03-10 16:34:17 --> Output Class Initialized
INFO - 2024-03-10 16:34:17 --> Security Class Initialized
DEBUG - 2024-03-10 16:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:34:17 --> Input Class Initialized
INFO - 2024-03-10 16:34:17 --> Language Class Initialized
INFO - 2024-03-10 16:34:17 --> Loader Class Initialized
INFO - 2024-03-10 16:34:17 --> Helper loaded: url_helper
INFO - 2024-03-10 16:34:17 --> Helper loaded: file_helper
INFO - 2024-03-10 16:34:17 --> Helper loaded: form_helper
INFO - 2024-03-10 16:34:17 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:34:17 --> Controller Class Initialized
INFO - 2024-03-10 16:34:17 --> Form Validation Class Initialized
INFO - 2024-03-10 16:34:17 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "ReportModel" initialized
INFO - 2024-03-10 16:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-10 16:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-10 16:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-10 16:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-10 16:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-10 16:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-10 16:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-10 16:34:17 --> Final output sent to browser
DEBUG - 2024-03-10 16:34:17 --> Total execution time: 0.0215
ERROR - 2024-03-10 16:34:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:34:17 --> Config Class Initialized
INFO - 2024-03-10 16:34:17 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:34:17 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:34:17 --> Utf8 Class Initialized
INFO - 2024-03-10 16:34:17 --> URI Class Initialized
INFO - 2024-03-10 16:34:17 --> Router Class Initialized
INFO - 2024-03-10 16:34:17 --> Output Class Initialized
INFO - 2024-03-10 16:34:17 --> Security Class Initialized
DEBUG - 2024-03-10 16:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:34:17 --> Input Class Initialized
INFO - 2024-03-10 16:34:17 --> Language Class Initialized
INFO - 2024-03-10 16:34:17 --> Loader Class Initialized
INFO - 2024-03-10 16:34:17 --> Helper loaded: url_helper
INFO - 2024-03-10 16:34:17 --> Helper loaded: file_helper
INFO - 2024-03-10 16:34:17 --> Helper loaded: form_helper
INFO - 2024-03-10 16:34:17 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:34:17 --> Controller Class Initialized
INFO - 2024-03-10 16:34:17 --> Form Validation Class Initialized
INFO - 2024-03-10 16:34:17 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:34:17 --> Model "ReportModel" initialized
ERROR - 2024-03-10 16:34:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:34:20 --> Config Class Initialized
INFO - 2024-03-10 16:34:20 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:34:20 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:34:20 --> Utf8 Class Initialized
INFO - 2024-03-10 16:34:20 --> URI Class Initialized
INFO - 2024-03-10 16:34:20 --> Router Class Initialized
INFO - 2024-03-10 16:34:20 --> Output Class Initialized
INFO - 2024-03-10 16:34:20 --> Security Class Initialized
DEBUG - 2024-03-10 16:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:34:20 --> Input Class Initialized
INFO - 2024-03-10 16:34:20 --> Language Class Initialized
INFO - 2024-03-10 16:34:20 --> Loader Class Initialized
INFO - 2024-03-10 16:34:20 --> Helper loaded: url_helper
INFO - 2024-03-10 16:34:20 --> Helper loaded: file_helper
INFO - 2024-03-10 16:34:20 --> Helper loaded: form_helper
INFO - 2024-03-10 16:34:20 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:34:20 --> Controller Class Initialized
INFO - 2024-03-10 16:34:20 --> Form Validation Class Initialized
INFO - 2024-03-10 16:34:20 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:34:20 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:34:20 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:34:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:34:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:34:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:34:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:34:20 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:34:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:34:20 --> Model "ReportModel" initialized
ERROR - 2024-03-10 16:34:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-10 16:34:23 --> Config Class Initialized
INFO - 2024-03-10 16:34:23 --> Hooks Class Initialized
DEBUG - 2024-03-10 16:34:23 --> UTF-8 Support Enabled
INFO - 2024-03-10 16:34:23 --> Utf8 Class Initialized
INFO - 2024-03-10 16:34:23 --> URI Class Initialized
INFO - 2024-03-10 16:34:23 --> Router Class Initialized
INFO - 2024-03-10 16:34:23 --> Output Class Initialized
INFO - 2024-03-10 16:34:23 --> Security Class Initialized
DEBUG - 2024-03-10 16:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-10 16:34:23 --> Input Class Initialized
INFO - 2024-03-10 16:34:23 --> Language Class Initialized
INFO - 2024-03-10 16:34:23 --> Loader Class Initialized
INFO - 2024-03-10 16:34:23 --> Helper loaded: url_helper
INFO - 2024-03-10 16:34:23 --> Helper loaded: file_helper
INFO - 2024-03-10 16:34:23 --> Helper loaded: form_helper
INFO - 2024-03-10 16:34:23 --> Database Driver Class Initialized
DEBUG - 2024-03-10 16:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-10 16:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-10 16:34:23 --> Controller Class Initialized
INFO - 2024-03-10 16:34:23 --> Form Validation Class Initialized
INFO - 2024-03-10 16:34:23 --> Model "MasterModel" initialized
INFO - 2024-03-10 16:34:23 --> Model "NotificationModel" initialized
INFO - 2024-03-10 16:34:23 --> Model "DashboardModel" initialized
INFO - 2024-03-10 16:34:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-10 16:34:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-10 16:34:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-10 16:34:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-10 16:34:23 --> Model "OrderModel" initialized
INFO - 2024-03-10 16:34:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-10 16:34:23 --> Model "ReportModel" initialized
