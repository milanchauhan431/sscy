<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-28 00:00:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:00:10 --> Config Class Initialized
INFO - 2024-02-28 00:00:10 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:00:10 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:00:10 --> Utf8 Class Initialized
INFO - 2024-02-28 00:00:10 --> URI Class Initialized
INFO - 2024-02-28 00:00:10 --> Router Class Initialized
INFO - 2024-02-28 00:00:10 --> Output Class Initialized
INFO - 2024-02-28 00:00:10 --> Security Class Initialized
DEBUG - 2024-02-28 00:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:00:10 --> Input Class Initialized
INFO - 2024-02-28 00:00:10 --> Language Class Initialized
INFO - 2024-02-28 00:00:10 --> Loader Class Initialized
INFO - 2024-02-28 00:00:10 --> Helper loaded: url_helper
INFO - 2024-02-28 00:00:10 --> Helper loaded: file_helper
INFO - 2024-02-28 00:00:10 --> Helper loaded: form_helper
INFO - 2024-02-28 00:00:10 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:00:10 --> Controller Class Initialized
INFO - 2024-02-28 00:00:10 --> Form Validation Class Initialized
INFO - 2024-02-28 00:00:10 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:00:10 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:00:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:00:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:00:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:00:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:00:10 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:00:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:00:10 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:00:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:00:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:00:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:00:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:00:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:00:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:00:10 --> Final output sent to browser
DEBUG - 2024-02-28 00:00:10 --> Total execution time: 0.0422
ERROR - 2024-02-28 00:01:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:01:37 --> Config Class Initialized
INFO - 2024-02-28 00:01:37 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:01:37 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:01:37 --> Utf8 Class Initialized
INFO - 2024-02-28 00:01:37 --> URI Class Initialized
INFO - 2024-02-28 00:01:37 --> Router Class Initialized
INFO - 2024-02-28 00:01:37 --> Output Class Initialized
INFO - 2024-02-28 00:01:37 --> Security Class Initialized
DEBUG - 2024-02-28 00:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:01:37 --> Input Class Initialized
INFO - 2024-02-28 00:01:37 --> Language Class Initialized
INFO - 2024-02-28 00:01:37 --> Loader Class Initialized
INFO - 2024-02-28 00:01:37 --> Helper loaded: url_helper
INFO - 2024-02-28 00:01:37 --> Helper loaded: file_helper
INFO - 2024-02-28 00:01:37 --> Helper loaded: form_helper
INFO - 2024-02-28 00:01:37 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:01:37 --> Controller Class Initialized
INFO - 2024-02-28 00:01:37 --> Form Validation Class Initialized
INFO - 2024-02-28 00:01:37 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:01:37 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:01:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:01:37 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:01:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:01:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:01:37 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:01:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:01:37 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:01:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:01:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:01:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:01:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:01:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:01:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:01:37 --> Final output sent to browser
DEBUG - 2024-02-28 00:01:37 --> Total execution time: 0.0489
ERROR - 2024-02-28 00:01:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:01:59 --> Config Class Initialized
INFO - 2024-02-28 00:01:59 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:01:59 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:01:59 --> Utf8 Class Initialized
INFO - 2024-02-28 00:01:59 --> URI Class Initialized
INFO - 2024-02-28 00:01:59 --> Router Class Initialized
INFO - 2024-02-28 00:01:59 --> Output Class Initialized
INFO - 2024-02-28 00:01:59 --> Security Class Initialized
DEBUG - 2024-02-28 00:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:01:59 --> Input Class Initialized
INFO - 2024-02-28 00:01:59 --> Language Class Initialized
INFO - 2024-02-28 00:01:59 --> Loader Class Initialized
INFO - 2024-02-28 00:01:59 --> Helper loaded: url_helper
INFO - 2024-02-28 00:01:59 --> Helper loaded: file_helper
INFO - 2024-02-28 00:01:59 --> Helper loaded: form_helper
INFO - 2024-02-28 00:01:59 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:01:59 --> Controller Class Initialized
INFO - 2024-02-28 00:01:59 --> Form Validation Class Initialized
INFO - 2024-02-28 00:01:59 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:01:59 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:01:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:01:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:01:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:01:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:01:59 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:01:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:01:59 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:01:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:01:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:01:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:01:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:01:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:01:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:01:59 --> Final output sent to browser
DEBUG - 2024-02-28 00:01:59 --> Total execution time: 0.0377
ERROR - 2024-02-28 00:02:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:02:48 --> Config Class Initialized
INFO - 2024-02-28 00:02:48 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:02:48 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:02:48 --> Utf8 Class Initialized
INFO - 2024-02-28 00:02:48 --> URI Class Initialized
INFO - 2024-02-28 00:02:48 --> Router Class Initialized
INFO - 2024-02-28 00:02:48 --> Output Class Initialized
INFO - 2024-02-28 00:02:48 --> Security Class Initialized
DEBUG - 2024-02-28 00:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:02:48 --> Input Class Initialized
INFO - 2024-02-28 00:02:48 --> Language Class Initialized
INFO - 2024-02-28 00:02:48 --> Loader Class Initialized
INFO - 2024-02-28 00:02:48 --> Helper loaded: url_helper
INFO - 2024-02-28 00:02:48 --> Helper loaded: file_helper
INFO - 2024-02-28 00:02:48 --> Helper loaded: form_helper
INFO - 2024-02-28 00:02:48 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:02:48 --> Controller Class Initialized
INFO - 2024-02-28 00:02:48 --> Form Validation Class Initialized
INFO - 2024-02-28 00:02:48 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:02:48 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:02:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:02:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:02:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:02:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:02:48 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:02:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:02:48 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:02:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:02:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:02:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:02:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:02:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:02:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:02:48 --> Final output sent to browser
DEBUG - 2024-02-28 00:02:48 --> Total execution time: 0.0332
ERROR - 2024-02-28 00:03:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:03:25 --> Config Class Initialized
INFO - 2024-02-28 00:03:25 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:03:25 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:03:25 --> Utf8 Class Initialized
INFO - 2024-02-28 00:03:25 --> URI Class Initialized
INFO - 2024-02-28 00:03:25 --> Router Class Initialized
INFO - 2024-02-28 00:03:25 --> Output Class Initialized
INFO - 2024-02-28 00:03:25 --> Security Class Initialized
DEBUG - 2024-02-28 00:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:03:25 --> Input Class Initialized
INFO - 2024-02-28 00:03:25 --> Language Class Initialized
INFO - 2024-02-28 00:03:25 --> Loader Class Initialized
INFO - 2024-02-28 00:03:25 --> Helper loaded: url_helper
INFO - 2024-02-28 00:03:25 --> Helper loaded: file_helper
INFO - 2024-02-28 00:03:25 --> Helper loaded: form_helper
INFO - 2024-02-28 00:03:25 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:03:25 --> Controller Class Initialized
INFO - 2024-02-28 00:03:25 --> Form Validation Class Initialized
INFO - 2024-02-28 00:03:25 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:03:25 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:03:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:03:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:03:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:03:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:03:25 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:03:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:03:25 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:03:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:03:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:03:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:03:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:03:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:03:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:03:25 --> Final output sent to browser
DEBUG - 2024-02-28 00:03:25 --> Total execution time: 0.0311
ERROR - 2024-02-28 00:04:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:04:44 --> Config Class Initialized
INFO - 2024-02-28 00:04:44 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:04:44 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:04:44 --> Utf8 Class Initialized
INFO - 2024-02-28 00:04:44 --> URI Class Initialized
INFO - 2024-02-28 00:04:44 --> Router Class Initialized
INFO - 2024-02-28 00:04:44 --> Output Class Initialized
INFO - 2024-02-28 00:04:44 --> Security Class Initialized
DEBUG - 2024-02-28 00:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:04:44 --> Input Class Initialized
INFO - 2024-02-28 00:04:44 --> Language Class Initialized
INFO - 2024-02-28 00:04:44 --> Loader Class Initialized
INFO - 2024-02-28 00:04:44 --> Helper loaded: url_helper
INFO - 2024-02-28 00:04:44 --> Helper loaded: file_helper
INFO - 2024-02-28 00:04:44 --> Helper loaded: form_helper
INFO - 2024-02-28 00:04:44 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:04:44 --> Controller Class Initialized
INFO - 2024-02-28 00:04:44 --> Form Validation Class Initialized
INFO - 2024-02-28 00:04:44 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:04:44 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:04:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:04:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:04:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:04:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:04:44 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:04:44 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:04:44 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:04:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:04:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:04:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:04:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:04:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:04:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:04:44 --> Final output sent to browser
DEBUG - 2024-02-28 00:04:44 --> Total execution time: 0.0337
ERROR - 2024-02-28 00:05:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:05:34 --> Config Class Initialized
INFO - 2024-02-28 00:05:34 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:05:34 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:05:34 --> Utf8 Class Initialized
INFO - 2024-02-28 00:05:34 --> URI Class Initialized
INFO - 2024-02-28 00:05:34 --> Router Class Initialized
INFO - 2024-02-28 00:05:34 --> Output Class Initialized
INFO - 2024-02-28 00:05:34 --> Security Class Initialized
DEBUG - 2024-02-28 00:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:05:34 --> Input Class Initialized
INFO - 2024-02-28 00:05:34 --> Language Class Initialized
INFO - 2024-02-28 00:05:34 --> Loader Class Initialized
INFO - 2024-02-28 00:05:34 --> Helper loaded: url_helper
INFO - 2024-02-28 00:05:34 --> Helper loaded: file_helper
INFO - 2024-02-28 00:05:34 --> Helper loaded: form_helper
INFO - 2024-02-28 00:05:34 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:05:34 --> Controller Class Initialized
INFO - 2024-02-28 00:05:34 --> Form Validation Class Initialized
INFO - 2024-02-28 00:05:34 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:05:34 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:05:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:05:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:05:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:05:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:05:34 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:05:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:05:34 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:05:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:05:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:05:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:05:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:05:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:05:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:05:34 --> Final output sent to browser
DEBUG - 2024-02-28 00:05:34 --> Total execution time: 0.0499
ERROR - 2024-02-28 00:06:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:06:33 --> Config Class Initialized
INFO - 2024-02-28 00:06:33 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:06:33 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:06:33 --> Utf8 Class Initialized
INFO - 2024-02-28 00:06:33 --> URI Class Initialized
INFO - 2024-02-28 00:06:33 --> Router Class Initialized
INFO - 2024-02-28 00:06:33 --> Output Class Initialized
INFO - 2024-02-28 00:06:33 --> Security Class Initialized
DEBUG - 2024-02-28 00:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:06:33 --> Input Class Initialized
INFO - 2024-02-28 00:06:33 --> Language Class Initialized
INFO - 2024-02-28 00:06:33 --> Loader Class Initialized
INFO - 2024-02-28 00:06:33 --> Helper loaded: url_helper
INFO - 2024-02-28 00:06:33 --> Helper loaded: file_helper
INFO - 2024-02-28 00:06:33 --> Helper loaded: form_helper
INFO - 2024-02-28 00:06:33 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:06:33 --> Controller Class Initialized
INFO - 2024-02-28 00:06:33 --> Form Validation Class Initialized
INFO - 2024-02-28 00:06:33 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:06:33 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:06:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:06:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:06:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:06:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:06:33 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:06:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:06:33 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:06:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:06:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:06:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:06:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:06:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:06:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:06:33 --> Final output sent to browser
DEBUG - 2024-02-28 00:06:33 --> Total execution time: 0.0366
ERROR - 2024-02-28 00:06:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:06:49 --> Config Class Initialized
INFO - 2024-02-28 00:06:49 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:06:49 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:06:49 --> Utf8 Class Initialized
INFO - 2024-02-28 00:06:49 --> URI Class Initialized
INFO - 2024-02-28 00:06:49 --> Router Class Initialized
INFO - 2024-02-28 00:06:49 --> Output Class Initialized
INFO - 2024-02-28 00:06:49 --> Security Class Initialized
DEBUG - 2024-02-28 00:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:06:49 --> Input Class Initialized
INFO - 2024-02-28 00:06:49 --> Language Class Initialized
INFO - 2024-02-28 00:06:49 --> Loader Class Initialized
INFO - 2024-02-28 00:06:49 --> Helper loaded: url_helper
INFO - 2024-02-28 00:06:49 --> Helper loaded: file_helper
INFO - 2024-02-28 00:06:49 --> Helper loaded: form_helper
INFO - 2024-02-28 00:06:49 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:06:49 --> Controller Class Initialized
INFO - 2024-02-28 00:06:49 --> Form Validation Class Initialized
INFO - 2024-02-28 00:06:49 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:06:49 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:06:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:06:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:06:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:06:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:06:49 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:06:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:06:49 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:06:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:06:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:06:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:06:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:06:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:06:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:06:49 --> Final output sent to browser
DEBUG - 2024-02-28 00:06:49 --> Total execution time: 0.0332
ERROR - 2024-02-28 00:07:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:07:18 --> Config Class Initialized
INFO - 2024-02-28 00:07:18 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:07:18 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:07:18 --> Utf8 Class Initialized
INFO - 2024-02-28 00:07:18 --> URI Class Initialized
INFO - 2024-02-28 00:07:18 --> Router Class Initialized
INFO - 2024-02-28 00:07:18 --> Output Class Initialized
INFO - 2024-02-28 00:07:18 --> Security Class Initialized
DEBUG - 2024-02-28 00:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:07:18 --> Input Class Initialized
INFO - 2024-02-28 00:07:18 --> Language Class Initialized
INFO - 2024-02-28 00:07:18 --> Loader Class Initialized
INFO - 2024-02-28 00:07:18 --> Helper loaded: url_helper
INFO - 2024-02-28 00:07:18 --> Helper loaded: file_helper
INFO - 2024-02-28 00:07:18 --> Helper loaded: form_helper
INFO - 2024-02-28 00:07:18 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:07:18 --> Controller Class Initialized
INFO - 2024-02-28 00:07:18 --> Form Validation Class Initialized
INFO - 2024-02-28 00:07:18 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:07:18 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:07:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:07:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:07:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:07:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:07:18 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:07:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:07:18 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:07:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:07:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-28 00:07:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:07:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:07:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:07:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:07:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-28 00:07:18 --> Final output sent to browser
DEBUG - 2024-02-28 00:07:18 --> Total execution time: 0.0295
ERROR - 2024-02-28 00:07:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:07:19 --> Config Class Initialized
INFO - 2024-02-28 00:07:19 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:07:19 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:07:19 --> Utf8 Class Initialized
INFO - 2024-02-28 00:07:19 --> URI Class Initialized
INFO - 2024-02-28 00:07:19 --> Router Class Initialized
INFO - 2024-02-28 00:07:19 --> Output Class Initialized
INFO - 2024-02-28 00:07:19 --> Security Class Initialized
DEBUG - 2024-02-28 00:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:07:19 --> Input Class Initialized
INFO - 2024-02-28 00:07:19 --> Language Class Initialized
INFO - 2024-02-28 00:07:19 --> Loader Class Initialized
INFO - 2024-02-28 00:07:19 --> Helper loaded: url_helper
INFO - 2024-02-28 00:07:19 --> Helper loaded: file_helper
INFO - 2024-02-28 00:07:19 --> Helper loaded: form_helper
INFO - 2024-02-28 00:07:19 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:07:19 --> Controller Class Initialized
INFO - 2024-02-28 00:07:19 --> Form Validation Class Initialized
INFO - 2024-02-28 00:07:19 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:07:19 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:07:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:07:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:07:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:07:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:07:19 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:07:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:07:19 --> Model "ReportModel" initialized
ERROR - 2024-02-28 00:07:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:07:22 --> Config Class Initialized
INFO - 2024-02-28 00:07:22 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:07:22 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:07:22 --> Utf8 Class Initialized
INFO - 2024-02-28 00:07:22 --> URI Class Initialized
INFO - 2024-02-28 00:07:22 --> Router Class Initialized
INFO - 2024-02-28 00:07:22 --> Output Class Initialized
INFO - 2024-02-28 00:07:22 --> Security Class Initialized
DEBUG - 2024-02-28 00:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:07:22 --> Input Class Initialized
INFO - 2024-02-28 00:07:22 --> Language Class Initialized
INFO - 2024-02-28 00:07:22 --> Loader Class Initialized
INFO - 2024-02-28 00:07:22 --> Helper loaded: url_helper
INFO - 2024-02-28 00:07:22 --> Helper loaded: file_helper
INFO - 2024-02-28 00:07:22 --> Helper loaded: form_helper
INFO - 2024-02-28 00:07:22 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:07:22 --> Controller Class Initialized
INFO - 2024-02-28 00:07:22 --> Form Validation Class Initialized
INFO - 2024-02-28 00:07:22 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:07:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:07:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:07:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:07:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:07:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:07:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-28 00:07:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-28 00:07:22 --> Final output sent to browser
DEBUG - 2024-02-28 00:07:22 --> Total execution time: 0.0227
ERROR - 2024-02-28 00:07:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:07:22 --> Config Class Initialized
INFO - 2024-02-28 00:07:22 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:07:22 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:07:22 --> Utf8 Class Initialized
INFO - 2024-02-28 00:07:22 --> URI Class Initialized
INFO - 2024-02-28 00:07:22 --> Router Class Initialized
INFO - 2024-02-28 00:07:22 --> Output Class Initialized
INFO - 2024-02-28 00:07:22 --> Security Class Initialized
DEBUG - 2024-02-28 00:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:07:22 --> Input Class Initialized
INFO - 2024-02-28 00:07:22 --> Language Class Initialized
INFO - 2024-02-28 00:07:22 --> Loader Class Initialized
INFO - 2024-02-28 00:07:22 --> Helper loaded: url_helper
INFO - 2024-02-28 00:07:22 --> Helper loaded: file_helper
INFO - 2024-02-28 00:07:22 --> Helper loaded: form_helper
INFO - 2024-02-28 00:07:22 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:07:22 --> Controller Class Initialized
INFO - 2024-02-28 00:07:22 --> Form Validation Class Initialized
INFO - 2024-02-28 00:07:22 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:07:22 --> Model "ReportModel" initialized
ERROR - 2024-02-28 00:08:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:08:50 --> Config Class Initialized
INFO - 2024-02-28 00:08:50 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:08:50 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:08:50 --> Utf8 Class Initialized
INFO - 2024-02-28 00:08:50 --> URI Class Initialized
INFO - 2024-02-28 00:08:50 --> Router Class Initialized
INFO - 2024-02-28 00:08:50 --> Output Class Initialized
INFO - 2024-02-28 00:08:50 --> Security Class Initialized
DEBUG - 2024-02-28 00:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:08:50 --> Input Class Initialized
INFO - 2024-02-28 00:08:50 --> Language Class Initialized
INFO - 2024-02-28 00:08:51 --> Loader Class Initialized
INFO - 2024-02-28 00:08:51 --> Helper loaded: url_helper
INFO - 2024-02-28 00:08:51 --> Helper loaded: file_helper
INFO - 2024-02-28 00:08:51 --> Helper loaded: form_helper
INFO - 2024-02-28 00:08:51 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:08:51 --> Controller Class Initialized
INFO - 2024-02-28 00:08:51 --> Form Validation Class Initialized
INFO - 2024-02-28 00:08:51 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:08:51 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:08:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:08:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:08:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:08:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:08:51 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:08:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:08:51 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:08:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:08:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:08:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:08:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:08:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:08:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:08:51 --> Final output sent to browser
DEBUG - 2024-02-28 00:08:51 --> Total execution time: 0.0344
ERROR - 2024-02-28 00:09:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:09:01 --> Config Class Initialized
INFO - 2024-02-28 00:09:01 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:09:01 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:09:01 --> Utf8 Class Initialized
INFO - 2024-02-28 00:09:01 --> URI Class Initialized
INFO - 2024-02-28 00:09:01 --> Router Class Initialized
INFO - 2024-02-28 00:09:01 --> Output Class Initialized
INFO - 2024-02-28 00:09:01 --> Security Class Initialized
DEBUG - 2024-02-28 00:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:09:01 --> Input Class Initialized
INFO - 2024-02-28 00:09:01 --> Language Class Initialized
INFO - 2024-02-28 00:09:01 --> Loader Class Initialized
INFO - 2024-02-28 00:09:01 --> Helper loaded: url_helper
INFO - 2024-02-28 00:09:01 --> Helper loaded: file_helper
INFO - 2024-02-28 00:09:01 --> Helper loaded: form_helper
INFO - 2024-02-28 00:09:01 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:09:01 --> Controller Class Initialized
INFO - 2024-02-28 00:09:01 --> Form Validation Class Initialized
INFO - 2024-02-28 00:09:01 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:09:01 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:09:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:09:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:09:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:09:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:09:01 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:09:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:09:01 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:09:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:09:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:09:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:09:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:09:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:09:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:09:01 --> Final output sent to browser
DEBUG - 2024-02-28 00:09:01 --> Total execution time: 0.0354
ERROR - 2024-02-28 00:09:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:09:07 --> Config Class Initialized
INFO - 2024-02-28 00:09:07 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:09:07 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:09:07 --> Utf8 Class Initialized
INFO - 2024-02-28 00:09:07 --> URI Class Initialized
INFO - 2024-02-28 00:09:07 --> Router Class Initialized
INFO - 2024-02-28 00:09:07 --> Output Class Initialized
INFO - 2024-02-28 00:09:07 --> Security Class Initialized
DEBUG - 2024-02-28 00:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:09:07 --> Input Class Initialized
INFO - 2024-02-28 00:09:07 --> Language Class Initialized
INFO - 2024-02-28 00:09:07 --> Loader Class Initialized
INFO - 2024-02-28 00:09:07 --> Helper loaded: url_helper
INFO - 2024-02-28 00:09:07 --> Helper loaded: file_helper
INFO - 2024-02-28 00:09:07 --> Helper loaded: form_helper
INFO - 2024-02-28 00:09:07 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:09:07 --> Controller Class Initialized
INFO - 2024-02-28 00:09:07 --> Form Validation Class Initialized
INFO - 2024-02-28 00:09:07 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:09:07 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:09:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:09:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:09:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:09:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:09:07 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:09:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:09:07 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:09:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:09:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:09:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:09:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:09:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:09:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:09:07 --> Final output sent to browser
DEBUG - 2024-02-28 00:09:07 --> Total execution time: 0.0283
ERROR - 2024-02-28 00:09:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:09:11 --> Config Class Initialized
INFO - 2024-02-28 00:09:11 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:09:11 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:09:11 --> Utf8 Class Initialized
INFO - 2024-02-28 00:09:11 --> URI Class Initialized
INFO - 2024-02-28 00:09:11 --> Router Class Initialized
INFO - 2024-02-28 00:09:11 --> Output Class Initialized
INFO - 2024-02-28 00:09:11 --> Security Class Initialized
DEBUG - 2024-02-28 00:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:09:11 --> Input Class Initialized
INFO - 2024-02-28 00:09:11 --> Language Class Initialized
INFO - 2024-02-28 00:09:11 --> Loader Class Initialized
INFO - 2024-02-28 00:09:11 --> Helper loaded: url_helper
INFO - 2024-02-28 00:09:11 --> Helper loaded: file_helper
INFO - 2024-02-28 00:09:11 --> Helper loaded: form_helper
INFO - 2024-02-28 00:09:11 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:09:11 --> Controller Class Initialized
INFO - 2024-02-28 00:09:11 --> Form Validation Class Initialized
INFO - 2024-02-28 00:09:11 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:09:11 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:09:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:09:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:09:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:09:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:09:11 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:09:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:09:11 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:09:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:09:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:09:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:09:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:09:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:09:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:09:11 --> Final output sent to browser
DEBUG - 2024-02-28 00:09:11 --> Total execution time: 0.0416
ERROR - 2024-02-28 00:09:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:09:17 --> Config Class Initialized
INFO - 2024-02-28 00:09:17 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:09:17 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:09:17 --> Utf8 Class Initialized
INFO - 2024-02-28 00:09:17 --> URI Class Initialized
INFO - 2024-02-28 00:09:17 --> Router Class Initialized
INFO - 2024-02-28 00:09:17 --> Output Class Initialized
INFO - 2024-02-28 00:09:17 --> Security Class Initialized
DEBUG - 2024-02-28 00:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:09:17 --> Input Class Initialized
INFO - 2024-02-28 00:09:17 --> Language Class Initialized
INFO - 2024-02-28 00:09:17 --> Loader Class Initialized
INFO - 2024-02-28 00:09:17 --> Helper loaded: url_helper
INFO - 2024-02-28 00:09:17 --> Helper loaded: file_helper
INFO - 2024-02-28 00:09:17 --> Helper loaded: form_helper
INFO - 2024-02-28 00:09:17 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:09:17 --> Controller Class Initialized
INFO - 2024-02-28 00:09:17 --> Form Validation Class Initialized
INFO - 2024-02-28 00:09:17 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:09:17 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:09:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:09:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:09:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:09:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:09:17 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:09:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:09:17 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:09:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:09:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:09:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:09:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:09:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:09:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:09:17 --> Final output sent to browser
DEBUG - 2024-02-28 00:09:17 --> Total execution time: 0.0336
ERROR - 2024-02-28 00:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:09:21 --> Config Class Initialized
INFO - 2024-02-28 00:09:21 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:09:21 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:09:21 --> Utf8 Class Initialized
INFO - 2024-02-28 00:09:21 --> URI Class Initialized
INFO - 2024-02-28 00:09:21 --> Router Class Initialized
INFO - 2024-02-28 00:09:21 --> Output Class Initialized
INFO - 2024-02-28 00:09:21 --> Security Class Initialized
DEBUG - 2024-02-28 00:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:09:21 --> Input Class Initialized
INFO - 2024-02-28 00:09:21 --> Language Class Initialized
INFO - 2024-02-28 00:09:21 --> Loader Class Initialized
INFO - 2024-02-28 00:09:21 --> Helper loaded: url_helper
INFO - 2024-02-28 00:09:21 --> Helper loaded: file_helper
INFO - 2024-02-28 00:09:21 --> Helper loaded: form_helper
INFO - 2024-02-28 00:09:21 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:09:21 --> Controller Class Initialized
INFO - 2024-02-28 00:09:21 --> Form Validation Class Initialized
INFO - 2024-02-28 00:09:21 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:09:21 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:09:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:09:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:09:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:09:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:09:21 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:09:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:09:21 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:09:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:09:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:09:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:09:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:09:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:09:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:09:21 --> Final output sent to browser
DEBUG - 2024-02-28 00:09:21 --> Total execution time: 0.0256
ERROR - 2024-02-28 00:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:09:26 --> Config Class Initialized
INFO - 2024-02-28 00:09:26 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:09:26 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:09:26 --> Utf8 Class Initialized
INFO - 2024-02-28 00:09:26 --> URI Class Initialized
INFO - 2024-02-28 00:09:26 --> Router Class Initialized
INFO - 2024-02-28 00:09:26 --> Output Class Initialized
INFO - 2024-02-28 00:09:26 --> Security Class Initialized
DEBUG - 2024-02-28 00:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:09:26 --> Input Class Initialized
INFO - 2024-02-28 00:09:26 --> Language Class Initialized
INFO - 2024-02-28 00:09:26 --> Loader Class Initialized
INFO - 2024-02-28 00:09:26 --> Helper loaded: url_helper
INFO - 2024-02-28 00:09:26 --> Helper loaded: file_helper
INFO - 2024-02-28 00:09:26 --> Helper loaded: form_helper
INFO - 2024-02-28 00:09:26 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:09:26 --> Controller Class Initialized
INFO - 2024-02-28 00:09:26 --> Form Validation Class Initialized
INFO - 2024-02-28 00:09:26 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:09:26 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:09:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:09:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:09:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:09:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:09:26 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:09:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:09:26 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:09:26 --> Final output sent to browser
DEBUG - 2024-02-28 00:09:26 --> Total execution time: 0.0280
ERROR - 2024-02-28 00:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:10:32 --> Config Class Initialized
INFO - 2024-02-28 00:10:32 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:10:32 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:10:32 --> Utf8 Class Initialized
INFO - 2024-02-28 00:10:32 --> URI Class Initialized
INFO - 2024-02-28 00:10:32 --> Router Class Initialized
INFO - 2024-02-28 00:10:32 --> Output Class Initialized
INFO - 2024-02-28 00:10:32 --> Security Class Initialized
DEBUG - 2024-02-28 00:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:10:32 --> Input Class Initialized
INFO - 2024-02-28 00:10:32 --> Language Class Initialized
INFO - 2024-02-28 00:10:32 --> Loader Class Initialized
INFO - 2024-02-28 00:10:32 --> Helper loaded: url_helper
INFO - 2024-02-28 00:10:32 --> Helper loaded: file_helper
INFO - 2024-02-28 00:10:32 --> Helper loaded: form_helper
INFO - 2024-02-28 00:10:32 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:10:32 --> Controller Class Initialized
INFO - 2024-02-28 00:10:32 --> Form Validation Class Initialized
INFO - 2024-02-28 00:10:32 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:10:32 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:10:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:10:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:10:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:10:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:10:32 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:10:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:10:32 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:10:32 --> Final output sent to browser
DEBUG - 2024-02-28 00:10:32 --> Total execution time: 0.0387
ERROR - 2024-02-28 00:11:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:11:17 --> Config Class Initialized
INFO - 2024-02-28 00:11:17 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:11:17 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:11:17 --> Utf8 Class Initialized
INFO - 2024-02-28 00:11:17 --> URI Class Initialized
INFO - 2024-02-28 00:11:17 --> Router Class Initialized
INFO - 2024-02-28 00:11:17 --> Output Class Initialized
INFO - 2024-02-28 00:11:17 --> Security Class Initialized
DEBUG - 2024-02-28 00:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:11:17 --> Input Class Initialized
INFO - 2024-02-28 00:11:17 --> Language Class Initialized
INFO - 2024-02-28 00:11:17 --> Loader Class Initialized
INFO - 2024-02-28 00:11:17 --> Helper loaded: url_helper
INFO - 2024-02-28 00:11:17 --> Helper loaded: file_helper
INFO - 2024-02-28 00:11:17 --> Helper loaded: form_helper
INFO - 2024-02-28 00:11:17 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:11:17 --> Controller Class Initialized
INFO - 2024-02-28 00:11:17 --> Form Validation Class Initialized
INFO - 2024-02-28 00:11:17 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:11:17 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:11:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:11:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:11:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:11:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:11:17 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:11:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:11:17 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:11:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:11:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:11:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:11:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:11:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:11:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:11:17 --> Final output sent to browser
DEBUG - 2024-02-28 00:11:17 --> Total execution time: 0.0335
ERROR - 2024-02-28 00:11:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:11:25 --> Config Class Initialized
INFO - 2024-02-28 00:11:25 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:11:25 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:11:25 --> Utf8 Class Initialized
INFO - 2024-02-28 00:11:25 --> URI Class Initialized
INFO - 2024-02-28 00:11:25 --> Router Class Initialized
INFO - 2024-02-28 00:11:25 --> Output Class Initialized
INFO - 2024-02-28 00:11:25 --> Security Class Initialized
DEBUG - 2024-02-28 00:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:11:25 --> Input Class Initialized
INFO - 2024-02-28 00:11:25 --> Language Class Initialized
INFO - 2024-02-28 00:11:25 --> Loader Class Initialized
INFO - 2024-02-28 00:11:25 --> Helper loaded: url_helper
INFO - 2024-02-28 00:11:25 --> Helper loaded: file_helper
INFO - 2024-02-28 00:11:25 --> Helper loaded: form_helper
INFO - 2024-02-28 00:11:25 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:11:25 --> Controller Class Initialized
INFO - 2024-02-28 00:11:25 --> Form Validation Class Initialized
INFO - 2024-02-28 00:11:25 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:11:25 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:11:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:11:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:11:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:11:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:11:25 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:11:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:11:25 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:11:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:11:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:11:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:11:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:11:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:11:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:11:25 --> Final output sent to browser
DEBUG - 2024-02-28 00:11:25 --> Total execution time: 0.0389
ERROR - 2024-02-28 00:11:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:11:34 --> Config Class Initialized
INFO - 2024-02-28 00:11:34 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:11:34 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:11:34 --> Utf8 Class Initialized
INFO - 2024-02-28 00:11:34 --> URI Class Initialized
INFO - 2024-02-28 00:11:34 --> Router Class Initialized
INFO - 2024-02-28 00:11:34 --> Output Class Initialized
INFO - 2024-02-28 00:11:34 --> Security Class Initialized
DEBUG - 2024-02-28 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:11:34 --> Input Class Initialized
INFO - 2024-02-28 00:11:34 --> Language Class Initialized
INFO - 2024-02-28 00:11:34 --> Loader Class Initialized
INFO - 2024-02-28 00:11:34 --> Helper loaded: url_helper
INFO - 2024-02-28 00:11:34 --> Helper loaded: file_helper
INFO - 2024-02-28 00:11:34 --> Helper loaded: form_helper
INFO - 2024-02-28 00:11:34 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:11:34 --> Controller Class Initialized
INFO - 2024-02-28 00:11:34 --> Form Validation Class Initialized
INFO - 2024-02-28 00:11:34 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:11:34 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:11:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:11:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:11:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:11:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:11:34 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:11:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:11:34 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:11:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:11:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:11:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:11:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:11:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:11:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:11:34 --> Final output sent to browser
DEBUG - 2024-02-28 00:11:34 --> Total execution time: 0.0343
ERROR - 2024-02-28 00:11:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:11:51 --> Config Class Initialized
INFO - 2024-02-28 00:11:51 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:11:51 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:11:51 --> Utf8 Class Initialized
INFO - 2024-02-28 00:11:51 --> URI Class Initialized
INFO - 2024-02-28 00:11:51 --> Router Class Initialized
INFO - 2024-02-28 00:11:51 --> Output Class Initialized
INFO - 2024-02-28 00:11:51 --> Security Class Initialized
DEBUG - 2024-02-28 00:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:11:51 --> Input Class Initialized
INFO - 2024-02-28 00:11:51 --> Language Class Initialized
INFO - 2024-02-28 00:11:51 --> Loader Class Initialized
INFO - 2024-02-28 00:11:51 --> Helper loaded: url_helper
INFO - 2024-02-28 00:11:51 --> Helper loaded: file_helper
INFO - 2024-02-28 00:11:51 --> Helper loaded: form_helper
INFO - 2024-02-28 00:11:51 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:11:51 --> Controller Class Initialized
INFO - 2024-02-28 00:11:51 --> Form Validation Class Initialized
INFO - 2024-02-28 00:11:51 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:11:51 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:11:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:11:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:11:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:11:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:11:51 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:11:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:11:51 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:11:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:11:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:11:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:11:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:11:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:11:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:11:51 --> Final output sent to browser
DEBUG - 2024-02-28 00:11:51 --> Total execution time: 0.0291
ERROR - 2024-02-28 00:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:12:02 --> Config Class Initialized
INFO - 2024-02-28 00:12:02 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:12:02 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:12:02 --> Utf8 Class Initialized
INFO - 2024-02-28 00:12:02 --> URI Class Initialized
INFO - 2024-02-28 00:12:02 --> Router Class Initialized
INFO - 2024-02-28 00:12:02 --> Output Class Initialized
INFO - 2024-02-28 00:12:02 --> Security Class Initialized
DEBUG - 2024-02-28 00:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:12:02 --> Input Class Initialized
INFO - 2024-02-28 00:12:02 --> Language Class Initialized
INFO - 2024-02-28 00:12:02 --> Loader Class Initialized
INFO - 2024-02-28 00:12:02 --> Helper loaded: url_helper
INFO - 2024-02-28 00:12:02 --> Helper loaded: file_helper
INFO - 2024-02-28 00:12:02 --> Helper loaded: form_helper
INFO - 2024-02-28 00:12:02 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:12:02 --> Controller Class Initialized
INFO - 2024-02-28 00:12:02 --> Form Validation Class Initialized
INFO - 2024-02-28 00:12:02 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:12:02 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:12:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:12:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:12:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:12:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:12:02 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:12:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:12:02 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:12:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:12:02 --> Final output sent to browser
DEBUG - 2024-02-28 00:12:02 --> Total execution time: 0.0483
ERROR - 2024-02-28 00:12:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:12:11 --> Config Class Initialized
INFO - 2024-02-28 00:12:11 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:12:11 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:12:11 --> Utf8 Class Initialized
INFO - 2024-02-28 00:12:11 --> URI Class Initialized
INFO - 2024-02-28 00:12:11 --> Router Class Initialized
INFO - 2024-02-28 00:12:11 --> Output Class Initialized
INFO - 2024-02-28 00:12:11 --> Security Class Initialized
DEBUG - 2024-02-28 00:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:12:11 --> Input Class Initialized
INFO - 2024-02-28 00:12:11 --> Language Class Initialized
INFO - 2024-02-28 00:12:11 --> Loader Class Initialized
INFO - 2024-02-28 00:12:11 --> Helper loaded: url_helper
INFO - 2024-02-28 00:12:11 --> Helper loaded: file_helper
INFO - 2024-02-28 00:12:11 --> Helper loaded: form_helper
INFO - 2024-02-28 00:12:11 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:12:11 --> Controller Class Initialized
INFO - 2024-02-28 00:12:11 --> Form Validation Class Initialized
INFO - 2024-02-28 00:12:11 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:12:11 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:12:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:12:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:12:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:12:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:12:11 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:12:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:12:11 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:12:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:12:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:12:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:12:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:12:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:12:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:12:11 --> Final output sent to browser
DEBUG - 2024-02-28 00:12:11 --> Total execution time: 0.0322
ERROR - 2024-02-28 00:12:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:12:19 --> Config Class Initialized
INFO - 2024-02-28 00:12:19 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:12:19 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:12:19 --> Utf8 Class Initialized
INFO - 2024-02-28 00:12:19 --> URI Class Initialized
INFO - 2024-02-28 00:12:19 --> Router Class Initialized
INFO - 2024-02-28 00:12:19 --> Output Class Initialized
INFO - 2024-02-28 00:12:19 --> Security Class Initialized
DEBUG - 2024-02-28 00:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:12:19 --> Input Class Initialized
INFO - 2024-02-28 00:12:19 --> Language Class Initialized
INFO - 2024-02-28 00:12:19 --> Loader Class Initialized
INFO - 2024-02-28 00:12:19 --> Helper loaded: url_helper
INFO - 2024-02-28 00:12:19 --> Helper loaded: file_helper
INFO - 2024-02-28 00:12:19 --> Helper loaded: form_helper
INFO - 2024-02-28 00:12:19 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:12:19 --> Controller Class Initialized
INFO - 2024-02-28 00:12:19 --> Form Validation Class Initialized
INFO - 2024-02-28 00:12:19 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:12:19 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:12:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:12:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:12:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:12:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:12:19 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:12:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:12:19 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:12:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:12:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:12:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:12:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:12:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:12:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:12:19 --> Final output sent to browser
DEBUG - 2024-02-28 00:12:19 --> Total execution time: 0.0331
ERROR - 2024-02-28 00:12:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:12:26 --> Config Class Initialized
INFO - 2024-02-28 00:12:26 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:12:26 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:12:26 --> Utf8 Class Initialized
INFO - 2024-02-28 00:12:26 --> URI Class Initialized
INFO - 2024-02-28 00:12:26 --> Router Class Initialized
INFO - 2024-02-28 00:12:26 --> Output Class Initialized
INFO - 2024-02-28 00:12:26 --> Security Class Initialized
DEBUG - 2024-02-28 00:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:12:26 --> Input Class Initialized
INFO - 2024-02-28 00:12:26 --> Language Class Initialized
INFO - 2024-02-28 00:12:26 --> Loader Class Initialized
INFO - 2024-02-28 00:12:26 --> Helper loaded: url_helper
INFO - 2024-02-28 00:12:26 --> Helper loaded: file_helper
INFO - 2024-02-28 00:12:26 --> Helper loaded: form_helper
INFO - 2024-02-28 00:12:26 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:12:26 --> Controller Class Initialized
INFO - 2024-02-28 00:12:26 --> Form Validation Class Initialized
INFO - 2024-02-28 00:12:26 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:12:26 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:12:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:12:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:12:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:12:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:12:26 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:12:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:12:26 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:12:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:12:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:12:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:12:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:12:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:12:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:12:26 --> Final output sent to browser
DEBUG - 2024-02-28 00:12:26 --> Total execution time: 0.0326
ERROR - 2024-02-28 00:12:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:12:36 --> Config Class Initialized
INFO - 2024-02-28 00:12:36 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:12:36 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:12:36 --> Utf8 Class Initialized
INFO - 2024-02-28 00:12:36 --> URI Class Initialized
INFO - 2024-02-28 00:12:36 --> Router Class Initialized
INFO - 2024-02-28 00:12:36 --> Output Class Initialized
INFO - 2024-02-28 00:12:36 --> Security Class Initialized
DEBUG - 2024-02-28 00:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:12:36 --> Input Class Initialized
INFO - 2024-02-28 00:12:36 --> Language Class Initialized
INFO - 2024-02-28 00:12:36 --> Loader Class Initialized
INFO - 2024-02-28 00:12:36 --> Helper loaded: url_helper
INFO - 2024-02-28 00:12:36 --> Helper loaded: file_helper
INFO - 2024-02-28 00:12:36 --> Helper loaded: form_helper
INFO - 2024-02-28 00:12:36 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:12:36 --> Controller Class Initialized
INFO - 2024-02-28 00:12:36 --> Form Validation Class Initialized
INFO - 2024-02-28 00:12:36 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:12:36 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:12:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:12:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:12:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:12:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:12:36 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:12:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:12:36 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:12:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:12:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:12:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:12:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:12:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:12:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:12:36 --> Final output sent to browser
DEBUG - 2024-02-28 00:12:36 --> Total execution time: 0.0342
ERROR - 2024-02-28 00:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:13:09 --> Config Class Initialized
INFO - 2024-02-28 00:13:09 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:13:09 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:13:09 --> Utf8 Class Initialized
INFO - 2024-02-28 00:13:09 --> URI Class Initialized
INFO - 2024-02-28 00:13:09 --> Router Class Initialized
INFO - 2024-02-28 00:13:09 --> Output Class Initialized
INFO - 2024-02-28 00:13:09 --> Security Class Initialized
DEBUG - 2024-02-28 00:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:13:09 --> Input Class Initialized
INFO - 2024-02-28 00:13:09 --> Language Class Initialized
INFO - 2024-02-28 00:13:09 --> Loader Class Initialized
INFO - 2024-02-28 00:13:09 --> Helper loaded: url_helper
INFO - 2024-02-28 00:13:09 --> Helper loaded: file_helper
INFO - 2024-02-28 00:13:09 --> Helper loaded: form_helper
INFO - 2024-02-28 00:13:09 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:13:09 --> Controller Class Initialized
INFO - 2024-02-28 00:13:09 --> Form Validation Class Initialized
INFO - 2024-02-28 00:13:09 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:13:09 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:13:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:13:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:13:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:13:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:13:09 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:13:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:13:09 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:13:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:13:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:13:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:13:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:13:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:13:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:13:09 --> Final output sent to browser
DEBUG - 2024-02-28 00:13:09 --> Total execution time: 0.0330
ERROR - 2024-02-28 00:13:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:13:54 --> Config Class Initialized
INFO - 2024-02-28 00:13:54 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:13:54 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:13:54 --> Utf8 Class Initialized
INFO - 2024-02-28 00:13:54 --> URI Class Initialized
INFO - 2024-02-28 00:13:54 --> Router Class Initialized
INFO - 2024-02-28 00:13:54 --> Output Class Initialized
INFO - 2024-02-28 00:13:54 --> Security Class Initialized
DEBUG - 2024-02-28 00:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:13:54 --> Input Class Initialized
INFO - 2024-02-28 00:13:54 --> Language Class Initialized
INFO - 2024-02-28 00:13:54 --> Loader Class Initialized
INFO - 2024-02-28 00:13:54 --> Helper loaded: url_helper
INFO - 2024-02-28 00:13:54 --> Helper loaded: file_helper
INFO - 2024-02-28 00:13:54 --> Helper loaded: form_helper
INFO - 2024-02-28 00:13:54 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:13:54 --> Controller Class Initialized
INFO - 2024-02-28 00:13:54 --> Form Validation Class Initialized
INFO - 2024-02-28 00:13:54 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:13:54 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:13:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:13:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:13:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:13:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:13:54 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:13:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:13:54 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:13:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:13:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:13:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:13:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:13:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:13:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:13:54 --> Final output sent to browser
DEBUG - 2024-02-28 00:13:54 --> Total execution time: 0.0665
ERROR - 2024-02-28 00:14:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:14:41 --> Config Class Initialized
INFO - 2024-02-28 00:14:41 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:14:41 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:14:41 --> Utf8 Class Initialized
INFO - 2024-02-28 00:14:41 --> URI Class Initialized
INFO - 2024-02-28 00:14:41 --> Router Class Initialized
INFO - 2024-02-28 00:14:41 --> Output Class Initialized
INFO - 2024-02-28 00:14:41 --> Security Class Initialized
DEBUG - 2024-02-28 00:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:14:41 --> Input Class Initialized
INFO - 2024-02-28 00:14:41 --> Language Class Initialized
INFO - 2024-02-28 00:14:41 --> Loader Class Initialized
INFO - 2024-02-28 00:14:41 --> Helper loaded: url_helper
INFO - 2024-02-28 00:14:41 --> Helper loaded: file_helper
INFO - 2024-02-28 00:14:41 --> Helper loaded: form_helper
INFO - 2024-02-28 00:14:41 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:14:41 --> Controller Class Initialized
INFO - 2024-02-28 00:14:41 --> Form Validation Class Initialized
INFO - 2024-02-28 00:14:41 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:14:41 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:14:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:14:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:14:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:14:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:14:41 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:14:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:14:41 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:14:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:14:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:14:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:14:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:14:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:14:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:14:41 --> Final output sent to browser
DEBUG - 2024-02-28 00:14:41 --> Total execution time: 0.0367
ERROR - 2024-02-28 00:15:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:15:16 --> Config Class Initialized
INFO - 2024-02-28 00:15:16 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:15:16 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:15:16 --> Utf8 Class Initialized
INFO - 2024-02-28 00:15:16 --> URI Class Initialized
INFO - 2024-02-28 00:15:16 --> Router Class Initialized
INFO - 2024-02-28 00:15:16 --> Output Class Initialized
INFO - 2024-02-28 00:15:16 --> Security Class Initialized
DEBUG - 2024-02-28 00:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:15:16 --> Input Class Initialized
INFO - 2024-02-28 00:15:16 --> Language Class Initialized
INFO - 2024-02-28 00:15:16 --> Loader Class Initialized
INFO - 2024-02-28 00:15:16 --> Helper loaded: url_helper
INFO - 2024-02-28 00:15:16 --> Helper loaded: file_helper
INFO - 2024-02-28 00:15:16 --> Helper loaded: form_helper
INFO - 2024-02-28 00:15:16 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:15:16 --> Controller Class Initialized
INFO - 2024-02-28 00:15:16 --> Form Validation Class Initialized
INFO - 2024-02-28 00:15:16 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:15:16 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:15:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:15:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:15:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:15:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:15:16 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:15:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:15:16 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:15:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:15:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:15:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:15:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:15:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:15:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:15:16 --> Final output sent to browser
DEBUG - 2024-02-28 00:15:16 --> Total execution time: 0.0313
ERROR - 2024-02-28 00:15:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:15:30 --> Config Class Initialized
INFO - 2024-02-28 00:15:30 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:15:30 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:15:30 --> Utf8 Class Initialized
INFO - 2024-02-28 00:15:30 --> URI Class Initialized
INFO - 2024-02-28 00:15:30 --> Router Class Initialized
INFO - 2024-02-28 00:15:30 --> Output Class Initialized
INFO - 2024-02-28 00:15:30 --> Security Class Initialized
DEBUG - 2024-02-28 00:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:15:30 --> Input Class Initialized
INFO - 2024-02-28 00:15:30 --> Language Class Initialized
INFO - 2024-02-28 00:15:30 --> Loader Class Initialized
INFO - 2024-02-28 00:15:30 --> Helper loaded: url_helper
INFO - 2024-02-28 00:15:30 --> Helper loaded: file_helper
INFO - 2024-02-28 00:15:30 --> Helper loaded: form_helper
INFO - 2024-02-28 00:15:30 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:15:30 --> Controller Class Initialized
INFO - 2024-02-28 00:15:30 --> Form Validation Class Initialized
INFO - 2024-02-28 00:15:30 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:15:30 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:15:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:15:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:15:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:15:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:15:30 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:15:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:15:30 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:15:30 --> Final output sent to browser
DEBUG - 2024-02-28 00:15:30 --> Total execution time: 0.0301
ERROR - 2024-02-28 00:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:15:51 --> Config Class Initialized
INFO - 2024-02-28 00:15:51 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:15:51 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:15:51 --> Utf8 Class Initialized
INFO - 2024-02-28 00:15:51 --> URI Class Initialized
INFO - 2024-02-28 00:15:51 --> Router Class Initialized
INFO - 2024-02-28 00:15:51 --> Output Class Initialized
INFO - 2024-02-28 00:15:51 --> Security Class Initialized
DEBUG - 2024-02-28 00:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:15:51 --> Input Class Initialized
INFO - 2024-02-28 00:15:51 --> Language Class Initialized
INFO - 2024-02-28 00:15:51 --> Loader Class Initialized
INFO - 2024-02-28 00:15:51 --> Helper loaded: url_helper
INFO - 2024-02-28 00:15:51 --> Helper loaded: file_helper
INFO - 2024-02-28 00:15:51 --> Helper loaded: form_helper
INFO - 2024-02-28 00:15:51 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:15:51 --> Controller Class Initialized
INFO - 2024-02-28 00:15:51 --> Form Validation Class Initialized
INFO - 2024-02-28 00:15:51 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:15:51 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:15:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:15:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:15:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:15:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:15:51 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:15:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:15:51 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:15:51 --> Final output sent to browser
DEBUG - 2024-02-28 00:15:51 --> Total execution time: 0.0318
ERROR - 2024-02-28 00:16:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:16:43 --> Config Class Initialized
INFO - 2024-02-28 00:16:43 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:16:43 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:16:43 --> Utf8 Class Initialized
INFO - 2024-02-28 00:16:43 --> URI Class Initialized
INFO - 2024-02-28 00:16:43 --> Router Class Initialized
INFO - 2024-02-28 00:16:43 --> Output Class Initialized
INFO - 2024-02-28 00:16:43 --> Security Class Initialized
DEBUG - 2024-02-28 00:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:16:43 --> Input Class Initialized
INFO - 2024-02-28 00:16:43 --> Language Class Initialized
INFO - 2024-02-28 00:16:43 --> Loader Class Initialized
INFO - 2024-02-28 00:16:43 --> Helper loaded: url_helper
INFO - 2024-02-28 00:16:43 --> Helper loaded: file_helper
INFO - 2024-02-28 00:16:43 --> Helper loaded: form_helper
INFO - 2024-02-28 00:16:43 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:16:43 --> Controller Class Initialized
INFO - 2024-02-28 00:16:43 --> Form Validation Class Initialized
INFO - 2024-02-28 00:16:43 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:16:43 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:16:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:16:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:16:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:16:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:16:43 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:16:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:16:43 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:16:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:16:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:16:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:16:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:16:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:16:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:16:43 --> Final output sent to browser
DEBUG - 2024-02-28 00:16:43 --> Total execution time: 0.0318
ERROR - 2024-02-28 00:17:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:17:00 --> Config Class Initialized
INFO - 2024-02-28 00:17:00 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:17:00 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:17:00 --> Utf8 Class Initialized
INFO - 2024-02-28 00:17:00 --> URI Class Initialized
INFO - 2024-02-28 00:17:00 --> Router Class Initialized
INFO - 2024-02-28 00:17:00 --> Output Class Initialized
INFO - 2024-02-28 00:17:00 --> Security Class Initialized
DEBUG - 2024-02-28 00:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:17:00 --> Input Class Initialized
INFO - 2024-02-28 00:17:00 --> Language Class Initialized
INFO - 2024-02-28 00:17:00 --> Loader Class Initialized
INFO - 2024-02-28 00:17:00 --> Helper loaded: url_helper
INFO - 2024-02-28 00:17:00 --> Helper loaded: file_helper
INFO - 2024-02-28 00:17:00 --> Helper loaded: form_helper
INFO - 2024-02-28 00:17:00 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:17:00 --> Controller Class Initialized
INFO - 2024-02-28 00:17:00 --> Form Validation Class Initialized
INFO - 2024-02-28 00:17:00 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:17:00 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:17:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:17:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:17:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:17:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:17:00 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:17:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:17:00 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:17:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:17:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:17:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:17:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:17:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:17:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:17:00 --> Final output sent to browser
DEBUG - 2024-02-28 00:17:00 --> Total execution time: 0.0236
ERROR - 2024-02-28 00:17:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:17:13 --> Config Class Initialized
INFO - 2024-02-28 00:17:13 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:17:13 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:17:13 --> Utf8 Class Initialized
INFO - 2024-02-28 00:17:13 --> URI Class Initialized
INFO - 2024-02-28 00:17:13 --> Router Class Initialized
INFO - 2024-02-28 00:17:13 --> Output Class Initialized
INFO - 2024-02-28 00:17:13 --> Security Class Initialized
DEBUG - 2024-02-28 00:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:17:13 --> Input Class Initialized
INFO - 2024-02-28 00:17:13 --> Language Class Initialized
INFO - 2024-02-28 00:17:13 --> Loader Class Initialized
INFO - 2024-02-28 00:17:13 --> Helper loaded: url_helper
INFO - 2024-02-28 00:17:13 --> Helper loaded: file_helper
INFO - 2024-02-28 00:17:13 --> Helper loaded: form_helper
INFO - 2024-02-28 00:17:13 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:17:13 --> Controller Class Initialized
INFO - 2024-02-28 00:17:13 --> Form Validation Class Initialized
INFO - 2024-02-28 00:17:13 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:17:13 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:17:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:17:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:17:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:17:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:17:13 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:17:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:17:13 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:17:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:17:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:17:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:17:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:17:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:17:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:17:13 --> Final output sent to browser
DEBUG - 2024-02-28 00:17:13 --> Total execution time: 0.0267
ERROR - 2024-02-28 00:18:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:18:21 --> Config Class Initialized
INFO - 2024-02-28 00:18:21 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:18:21 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:18:21 --> Utf8 Class Initialized
INFO - 2024-02-28 00:18:21 --> URI Class Initialized
INFO - 2024-02-28 00:18:21 --> Router Class Initialized
INFO - 2024-02-28 00:18:21 --> Output Class Initialized
INFO - 2024-02-28 00:18:21 --> Security Class Initialized
DEBUG - 2024-02-28 00:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:18:21 --> Input Class Initialized
INFO - 2024-02-28 00:18:21 --> Language Class Initialized
INFO - 2024-02-28 00:18:21 --> Loader Class Initialized
INFO - 2024-02-28 00:18:21 --> Helper loaded: url_helper
INFO - 2024-02-28 00:18:21 --> Helper loaded: file_helper
INFO - 2024-02-28 00:18:21 --> Helper loaded: form_helper
INFO - 2024-02-28 00:18:21 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:18:21 --> Controller Class Initialized
INFO - 2024-02-28 00:18:21 --> Form Validation Class Initialized
INFO - 2024-02-28 00:18:21 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:18:21 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:18:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:18:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:18:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:18:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:18:21 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:18:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:18:21 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:18:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:18:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:18:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:18:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:18:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:18:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:18:21 --> Final output sent to browser
DEBUG - 2024-02-28 00:18:21 --> Total execution time: 0.0338
ERROR - 2024-02-28 00:18:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:18:48 --> Config Class Initialized
INFO - 2024-02-28 00:18:48 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:18:48 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:18:48 --> Utf8 Class Initialized
INFO - 2024-02-28 00:18:48 --> URI Class Initialized
INFO - 2024-02-28 00:18:48 --> Router Class Initialized
INFO - 2024-02-28 00:18:48 --> Output Class Initialized
INFO - 2024-02-28 00:18:48 --> Security Class Initialized
DEBUG - 2024-02-28 00:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:18:48 --> Input Class Initialized
INFO - 2024-02-28 00:18:48 --> Language Class Initialized
INFO - 2024-02-28 00:18:48 --> Loader Class Initialized
INFO - 2024-02-28 00:18:48 --> Helper loaded: url_helper
INFO - 2024-02-28 00:18:48 --> Helper loaded: file_helper
INFO - 2024-02-28 00:18:48 --> Helper loaded: form_helper
INFO - 2024-02-28 00:18:48 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:18:48 --> Controller Class Initialized
INFO - 2024-02-28 00:18:48 --> Form Validation Class Initialized
INFO - 2024-02-28 00:18:48 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:18:48 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:18:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:18:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:18:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:18:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:18:48 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:18:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:18:48 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:18:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:18:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:18:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:18:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:18:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:18:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:18:48 --> Final output sent to browser
DEBUG - 2024-02-28 00:18:48 --> Total execution time: 0.0406
ERROR - 2024-02-28 00:19:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:19:02 --> Config Class Initialized
INFO - 2024-02-28 00:19:02 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:19:02 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:19:02 --> Utf8 Class Initialized
INFO - 2024-02-28 00:19:02 --> URI Class Initialized
INFO - 2024-02-28 00:19:02 --> Router Class Initialized
INFO - 2024-02-28 00:19:02 --> Output Class Initialized
INFO - 2024-02-28 00:19:02 --> Security Class Initialized
DEBUG - 2024-02-28 00:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:19:02 --> Input Class Initialized
INFO - 2024-02-28 00:19:02 --> Language Class Initialized
INFO - 2024-02-28 00:19:02 --> Loader Class Initialized
INFO - 2024-02-28 00:19:02 --> Helper loaded: url_helper
INFO - 2024-02-28 00:19:02 --> Helper loaded: file_helper
INFO - 2024-02-28 00:19:02 --> Helper loaded: form_helper
INFO - 2024-02-28 00:19:02 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:19:02 --> Controller Class Initialized
INFO - 2024-02-28 00:19:02 --> Form Validation Class Initialized
INFO - 2024-02-28 00:19:02 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:19:02 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:19:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:19:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:19:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:19:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:19:02 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:19:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:19:02 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:19:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:19:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:19:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:19:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:19:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:19:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:19:02 --> Final output sent to browser
DEBUG - 2024-02-28 00:19:02 --> Total execution time: 0.0323
ERROR - 2024-02-28 00:20:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:20:24 --> Config Class Initialized
INFO - 2024-02-28 00:20:24 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:20:24 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:20:24 --> Utf8 Class Initialized
INFO - 2024-02-28 00:20:24 --> URI Class Initialized
INFO - 2024-02-28 00:20:24 --> Router Class Initialized
INFO - 2024-02-28 00:20:24 --> Output Class Initialized
INFO - 2024-02-28 00:20:24 --> Security Class Initialized
DEBUG - 2024-02-28 00:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:20:24 --> Input Class Initialized
INFO - 2024-02-28 00:20:24 --> Language Class Initialized
INFO - 2024-02-28 00:20:24 --> Loader Class Initialized
INFO - 2024-02-28 00:20:24 --> Helper loaded: url_helper
INFO - 2024-02-28 00:20:24 --> Helper loaded: file_helper
INFO - 2024-02-28 00:20:24 --> Helper loaded: form_helper
INFO - 2024-02-28 00:20:24 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:20:24 --> Controller Class Initialized
INFO - 2024-02-28 00:20:24 --> Form Validation Class Initialized
INFO - 2024-02-28 00:20:24 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:20:24 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:20:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:20:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:20:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:20:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:20:24 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:20:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:20:24 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:20:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:20:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:20:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:20:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:20:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:20:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:20:24 --> Final output sent to browser
DEBUG - 2024-02-28 00:20:24 --> Total execution time: 0.0278
ERROR - 2024-02-28 00:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:22:53 --> Config Class Initialized
INFO - 2024-02-28 00:22:53 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:22:53 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:22:53 --> Utf8 Class Initialized
INFO - 2024-02-28 00:22:53 --> URI Class Initialized
INFO - 2024-02-28 00:22:53 --> Router Class Initialized
INFO - 2024-02-28 00:22:53 --> Output Class Initialized
INFO - 2024-02-28 00:22:53 --> Security Class Initialized
DEBUG - 2024-02-28 00:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:22:53 --> Input Class Initialized
INFO - 2024-02-28 00:22:53 --> Language Class Initialized
INFO - 2024-02-28 00:22:53 --> Loader Class Initialized
INFO - 2024-02-28 00:22:53 --> Helper loaded: url_helper
INFO - 2024-02-28 00:22:53 --> Helper loaded: file_helper
INFO - 2024-02-28 00:22:53 --> Helper loaded: form_helper
INFO - 2024-02-28 00:22:53 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:22:53 --> Controller Class Initialized
INFO - 2024-02-28 00:22:53 --> Form Validation Class Initialized
INFO - 2024-02-28 00:22:53 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:22:53 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:22:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:22:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:22:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:22:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:22:53 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:22:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:22:53 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:22:53 --> Final output sent to browser
DEBUG - 2024-02-28 00:22:53 --> Total execution time: 0.0442
ERROR - 2024-02-28 00:23:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:23:03 --> Config Class Initialized
INFO - 2024-02-28 00:23:03 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:23:03 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:23:03 --> Utf8 Class Initialized
INFO - 2024-02-28 00:23:03 --> URI Class Initialized
INFO - 2024-02-28 00:23:03 --> Router Class Initialized
INFO - 2024-02-28 00:23:03 --> Output Class Initialized
INFO - 2024-02-28 00:23:03 --> Security Class Initialized
DEBUG - 2024-02-28 00:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:23:03 --> Input Class Initialized
INFO - 2024-02-28 00:23:03 --> Language Class Initialized
INFO - 2024-02-28 00:23:03 --> Loader Class Initialized
INFO - 2024-02-28 00:23:03 --> Helper loaded: url_helper
INFO - 2024-02-28 00:23:03 --> Helper loaded: file_helper
INFO - 2024-02-28 00:23:03 --> Helper loaded: form_helper
INFO - 2024-02-28 00:23:03 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:23:03 --> Controller Class Initialized
INFO - 2024-02-28 00:23:03 --> Form Validation Class Initialized
INFO - 2024-02-28 00:23:03 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:23:03 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:23:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:23:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:23:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:23:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:23:03 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:23:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:23:03 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:23:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:23:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:23:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:23:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:23:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:23:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:23:03 --> Final output sent to browser
DEBUG - 2024-02-28 00:23:03 --> Total execution time: 0.0283
ERROR - 2024-02-28 00:23:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:23:43 --> Config Class Initialized
INFO - 2024-02-28 00:23:43 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:23:43 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:23:43 --> Utf8 Class Initialized
INFO - 2024-02-28 00:23:43 --> URI Class Initialized
INFO - 2024-02-28 00:23:43 --> Router Class Initialized
INFO - 2024-02-28 00:23:43 --> Output Class Initialized
INFO - 2024-02-28 00:23:43 --> Security Class Initialized
DEBUG - 2024-02-28 00:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:23:43 --> Input Class Initialized
INFO - 2024-02-28 00:23:43 --> Language Class Initialized
INFO - 2024-02-28 00:23:43 --> Loader Class Initialized
INFO - 2024-02-28 00:23:43 --> Helper loaded: url_helper
INFO - 2024-02-28 00:23:43 --> Helper loaded: file_helper
INFO - 2024-02-28 00:23:43 --> Helper loaded: form_helper
INFO - 2024-02-28 00:23:43 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:23:43 --> Controller Class Initialized
INFO - 2024-02-28 00:23:43 --> Form Validation Class Initialized
INFO - 2024-02-28 00:23:43 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:23:43 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:23:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:23:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:23:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:23:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:23:43 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:23:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:23:43 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:23:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:23:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:23:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:23:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:23:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:23:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:23:43 --> Final output sent to browser
DEBUG - 2024-02-28 00:23:43 --> Total execution time: 0.0360
ERROR - 2024-02-28 00:24:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:24:41 --> Config Class Initialized
INFO - 2024-02-28 00:24:41 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:24:41 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:24:41 --> Utf8 Class Initialized
INFO - 2024-02-28 00:24:41 --> URI Class Initialized
INFO - 2024-02-28 00:24:41 --> Router Class Initialized
INFO - 2024-02-28 00:24:41 --> Output Class Initialized
INFO - 2024-02-28 00:24:41 --> Security Class Initialized
DEBUG - 2024-02-28 00:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:24:41 --> Input Class Initialized
INFO - 2024-02-28 00:24:41 --> Language Class Initialized
INFO - 2024-02-28 00:24:41 --> Loader Class Initialized
INFO - 2024-02-28 00:24:41 --> Helper loaded: url_helper
INFO - 2024-02-28 00:24:41 --> Helper loaded: file_helper
INFO - 2024-02-28 00:24:41 --> Helper loaded: form_helper
INFO - 2024-02-28 00:24:41 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:24:41 --> Controller Class Initialized
INFO - 2024-02-28 00:24:41 --> Form Validation Class Initialized
INFO - 2024-02-28 00:24:41 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:24:41 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:24:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:24:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:24:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:24:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:24:41 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:24:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:24:41 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:24:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:24:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:24:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:24:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:24:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:24:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:24:41 --> Final output sent to browser
DEBUG - 2024-02-28 00:24:41 --> Total execution time: 0.0377
ERROR - 2024-02-28 00:24:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:24:52 --> Config Class Initialized
INFO - 2024-02-28 00:24:52 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:24:52 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:24:52 --> Utf8 Class Initialized
INFO - 2024-02-28 00:24:52 --> URI Class Initialized
INFO - 2024-02-28 00:24:52 --> Router Class Initialized
INFO - 2024-02-28 00:24:52 --> Output Class Initialized
INFO - 2024-02-28 00:24:52 --> Security Class Initialized
DEBUG - 2024-02-28 00:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:24:52 --> Input Class Initialized
INFO - 2024-02-28 00:24:52 --> Language Class Initialized
INFO - 2024-02-28 00:24:52 --> Loader Class Initialized
INFO - 2024-02-28 00:24:52 --> Helper loaded: url_helper
INFO - 2024-02-28 00:24:52 --> Helper loaded: file_helper
INFO - 2024-02-28 00:24:52 --> Helper loaded: form_helper
INFO - 2024-02-28 00:24:52 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:24:52 --> Controller Class Initialized
INFO - 2024-02-28 00:24:52 --> Form Validation Class Initialized
INFO - 2024-02-28 00:24:52 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:24:52 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:24:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:24:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:24:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:24:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:24:52 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:24:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:24:52 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:24:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:24:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:24:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:24:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:24:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:24:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:24:52 --> Final output sent to browser
DEBUG - 2024-02-28 00:24:52 --> Total execution time: 0.0375
ERROR - 2024-02-28 00:25:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:25:04 --> Config Class Initialized
INFO - 2024-02-28 00:25:04 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:25:04 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:25:04 --> Utf8 Class Initialized
INFO - 2024-02-28 00:25:04 --> URI Class Initialized
INFO - 2024-02-28 00:25:04 --> Router Class Initialized
INFO - 2024-02-28 00:25:04 --> Output Class Initialized
INFO - 2024-02-28 00:25:04 --> Security Class Initialized
DEBUG - 2024-02-28 00:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:25:04 --> Input Class Initialized
INFO - 2024-02-28 00:25:04 --> Language Class Initialized
INFO - 2024-02-28 00:25:04 --> Loader Class Initialized
INFO - 2024-02-28 00:25:04 --> Helper loaded: url_helper
INFO - 2024-02-28 00:25:04 --> Helper loaded: file_helper
INFO - 2024-02-28 00:25:04 --> Helper loaded: form_helper
INFO - 2024-02-28 00:25:04 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:25:04 --> Controller Class Initialized
INFO - 2024-02-28 00:25:04 --> Form Validation Class Initialized
INFO - 2024-02-28 00:25:04 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:25:04 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:25:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:25:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:25:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:25:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:25:04 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:25:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:25:04 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:25:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:25:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:25:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:25:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:25:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:25:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:25:04 --> Final output sent to browser
DEBUG - 2024-02-28 00:25:04 --> Total execution time: 0.0447
ERROR - 2024-02-28 00:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:25:10 --> Config Class Initialized
INFO - 2024-02-28 00:25:10 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:25:10 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:25:10 --> Utf8 Class Initialized
INFO - 2024-02-28 00:25:10 --> URI Class Initialized
INFO - 2024-02-28 00:25:10 --> Router Class Initialized
INFO - 2024-02-28 00:25:10 --> Output Class Initialized
INFO - 2024-02-28 00:25:10 --> Security Class Initialized
DEBUG - 2024-02-28 00:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:25:10 --> Input Class Initialized
INFO - 2024-02-28 00:25:10 --> Language Class Initialized
INFO - 2024-02-28 00:25:10 --> Loader Class Initialized
INFO - 2024-02-28 00:25:10 --> Helper loaded: url_helper
INFO - 2024-02-28 00:25:10 --> Helper loaded: file_helper
INFO - 2024-02-28 00:25:10 --> Helper loaded: form_helper
INFO - 2024-02-28 00:25:10 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:25:10 --> Controller Class Initialized
INFO - 2024-02-28 00:25:10 --> Form Validation Class Initialized
INFO - 2024-02-28 00:25:10 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:25:10 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:25:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:25:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:25:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:25:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:25:10 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:25:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:25:10 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:25:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:25:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:25:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:25:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:25:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:25:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:25:10 --> Final output sent to browser
DEBUG - 2024-02-28 00:25:10 --> Total execution time: 0.0212
ERROR - 2024-02-28 00:25:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:25:25 --> Config Class Initialized
INFO - 2024-02-28 00:25:25 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:25:25 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:25:25 --> Utf8 Class Initialized
INFO - 2024-02-28 00:25:25 --> URI Class Initialized
INFO - 2024-02-28 00:25:25 --> Router Class Initialized
INFO - 2024-02-28 00:25:25 --> Output Class Initialized
INFO - 2024-02-28 00:25:25 --> Security Class Initialized
DEBUG - 2024-02-28 00:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:25:25 --> Input Class Initialized
INFO - 2024-02-28 00:25:25 --> Language Class Initialized
INFO - 2024-02-28 00:25:25 --> Loader Class Initialized
INFO - 2024-02-28 00:25:25 --> Helper loaded: url_helper
INFO - 2024-02-28 00:25:25 --> Helper loaded: file_helper
INFO - 2024-02-28 00:25:25 --> Helper loaded: form_helper
INFO - 2024-02-28 00:25:25 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:25:25 --> Controller Class Initialized
INFO - 2024-02-28 00:25:25 --> Form Validation Class Initialized
INFO - 2024-02-28 00:25:25 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:25:25 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:25:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:25:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:25:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:25:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:25:25 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:25:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:25:25 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:25:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:25:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:25:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:25:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:25:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:25:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:25:25 --> Final output sent to browser
DEBUG - 2024-02-28 00:25:25 --> Total execution time: 0.0253
ERROR - 2024-02-28 00:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:27:42 --> Config Class Initialized
INFO - 2024-02-28 00:27:42 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:27:42 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:27:42 --> Utf8 Class Initialized
INFO - 2024-02-28 00:27:42 --> URI Class Initialized
INFO - 2024-02-28 00:27:42 --> Router Class Initialized
INFO - 2024-02-28 00:27:42 --> Output Class Initialized
INFO - 2024-02-28 00:27:42 --> Security Class Initialized
DEBUG - 2024-02-28 00:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:27:42 --> Input Class Initialized
INFO - 2024-02-28 00:27:42 --> Language Class Initialized
INFO - 2024-02-28 00:27:42 --> Loader Class Initialized
INFO - 2024-02-28 00:27:42 --> Helper loaded: url_helper
INFO - 2024-02-28 00:27:42 --> Helper loaded: file_helper
INFO - 2024-02-28 00:27:42 --> Helper loaded: form_helper
INFO - 2024-02-28 00:27:42 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:27:42 --> Controller Class Initialized
INFO - 2024-02-28 00:27:42 --> Form Validation Class Initialized
INFO - 2024-02-28 00:27:42 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:27:42 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:27:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:27:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:27:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:27:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:27:42 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:27:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:27:42 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:27:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:27:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:27:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:27:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:27:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:27:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:27:42 --> Final output sent to browser
DEBUG - 2024-02-28 00:27:42 --> Total execution time: 0.0384
ERROR - 2024-02-28 00:27:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:27:54 --> Config Class Initialized
INFO - 2024-02-28 00:27:54 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:27:54 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:27:54 --> Utf8 Class Initialized
INFO - 2024-02-28 00:27:54 --> URI Class Initialized
INFO - 2024-02-28 00:27:54 --> Router Class Initialized
INFO - 2024-02-28 00:27:54 --> Output Class Initialized
INFO - 2024-02-28 00:27:54 --> Security Class Initialized
DEBUG - 2024-02-28 00:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:27:54 --> Input Class Initialized
INFO - 2024-02-28 00:27:54 --> Language Class Initialized
INFO - 2024-02-28 00:27:54 --> Loader Class Initialized
INFO - 2024-02-28 00:27:54 --> Helper loaded: url_helper
INFO - 2024-02-28 00:27:54 --> Helper loaded: file_helper
INFO - 2024-02-28 00:27:54 --> Helper loaded: form_helper
INFO - 2024-02-28 00:27:54 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:27:54 --> Controller Class Initialized
INFO - 2024-02-28 00:27:54 --> Form Validation Class Initialized
INFO - 2024-02-28 00:27:54 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:27:54 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:27:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:27:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:27:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:27:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:27:54 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:27:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:27:54 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:27:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:27:54 --> Final output sent to browser
DEBUG - 2024-02-28 00:27:54 --> Total execution time: 0.0424
ERROR - 2024-02-28 00:27:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:27:59 --> Config Class Initialized
INFO - 2024-02-28 00:27:59 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:27:59 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:27:59 --> Utf8 Class Initialized
INFO - 2024-02-28 00:27:59 --> URI Class Initialized
INFO - 2024-02-28 00:27:59 --> Router Class Initialized
INFO - 2024-02-28 00:27:59 --> Output Class Initialized
INFO - 2024-02-28 00:27:59 --> Security Class Initialized
DEBUG - 2024-02-28 00:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:27:59 --> Input Class Initialized
INFO - 2024-02-28 00:27:59 --> Language Class Initialized
INFO - 2024-02-28 00:27:59 --> Loader Class Initialized
INFO - 2024-02-28 00:27:59 --> Helper loaded: url_helper
INFO - 2024-02-28 00:27:59 --> Helper loaded: file_helper
INFO - 2024-02-28 00:27:59 --> Helper loaded: form_helper
INFO - 2024-02-28 00:27:59 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:27:59 --> Controller Class Initialized
INFO - 2024-02-28 00:27:59 --> Form Validation Class Initialized
INFO - 2024-02-28 00:27:59 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:27:59 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:27:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:27:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:27:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:27:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:27:59 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:27:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:27:59 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:27:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:27:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:27:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:27:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:27:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:27:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:27:59 --> Final output sent to browser
DEBUG - 2024-02-28 00:27:59 --> Total execution time: 0.0362
ERROR - 2024-02-28 00:28:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:28:05 --> Config Class Initialized
INFO - 2024-02-28 00:28:05 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:28:05 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:28:05 --> Utf8 Class Initialized
INFO - 2024-02-28 00:28:05 --> URI Class Initialized
INFO - 2024-02-28 00:28:05 --> Router Class Initialized
INFO - 2024-02-28 00:28:05 --> Output Class Initialized
INFO - 2024-02-28 00:28:05 --> Security Class Initialized
DEBUG - 2024-02-28 00:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:28:05 --> Input Class Initialized
INFO - 2024-02-28 00:28:05 --> Language Class Initialized
INFO - 2024-02-28 00:28:05 --> Loader Class Initialized
INFO - 2024-02-28 00:28:05 --> Helper loaded: url_helper
INFO - 2024-02-28 00:28:05 --> Helper loaded: file_helper
INFO - 2024-02-28 00:28:05 --> Helper loaded: form_helper
INFO - 2024-02-28 00:28:05 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:28:05 --> Controller Class Initialized
INFO - 2024-02-28 00:28:05 --> Form Validation Class Initialized
INFO - 2024-02-28 00:28:05 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:28:05 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:28:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:28:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:28:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:28:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:28:05 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:28:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:28:05 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:28:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:28:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:28:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:28:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:28:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:28:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:28:05 --> Final output sent to browser
DEBUG - 2024-02-28 00:28:05 --> Total execution time: 0.0477
ERROR - 2024-02-28 00:28:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:28:09 --> Config Class Initialized
INFO - 2024-02-28 00:28:09 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:28:09 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:28:09 --> Utf8 Class Initialized
INFO - 2024-02-28 00:28:09 --> URI Class Initialized
INFO - 2024-02-28 00:28:09 --> Router Class Initialized
INFO - 2024-02-28 00:28:09 --> Output Class Initialized
INFO - 2024-02-28 00:28:09 --> Security Class Initialized
DEBUG - 2024-02-28 00:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:28:09 --> Input Class Initialized
INFO - 2024-02-28 00:28:09 --> Language Class Initialized
INFO - 2024-02-28 00:28:09 --> Loader Class Initialized
INFO - 2024-02-28 00:28:09 --> Helper loaded: url_helper
INFO - 2024-02-28 00:28:09 --> Helper loaded: file_helper
INFO - 2024-02-28 00:28:09 --> Helper loaded: form_helper
INFO - 2024-02-28 00:28:09 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:28:09 --> Controller Class Initialized
INFO - 2024-02-28 00:28:09 --> Form Validation Class Initialized
INFO - 2024-02-28 00:28:09 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:28:09 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:28:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:28:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:28:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:28:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:28:09 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:28:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:28:09 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:28:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:28:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:28:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:28:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:28:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:28:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:28:09 --> Final output sent to browser
DEBUG - 2024-02-28 00:28:09 --> Total execution time: 0.0225
ERROR - 2024-02-28 00:28:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:28:17 --> Config Class Initialized
INFO - 2024-02-28 00:28:17 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:28:17 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:28:17 --> Utf8 Class Initialized
INFO - 2024-02-28 00:28:17 --> URI Class Initialized
INFO - 2024-02-28 00:28:17 --> Router Class Initialized
INFO - 2024-02-28 00:28:17 --> Output Class Initialized
INFO - 2024-02-28 00:28:17 --> Security Class Initialized
DEBUG - 2024-02-28 00:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:28:17 --> Input Class Initialized
INFO - 2024-02-28 00:28:17 --> Language Class Initialized
INFO - 2024-02-28 00:28:17 --> Loader Class Initialized
INFO - 2024-02-28 00:28:17 --> Helper loaded: url_helper
INFO - 2024-02-28 00:28:17 --> Helper loaded: file_helper
INFO - 2024-02-28 00:28:17 --> Helper loaded: form_helper
INFO - 2024-02-28 00:28:17 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:28:17 --> Controller Class Initialized
INFO - 2024-02-28 00:28:17 --> Form Validation Class Initialized
INFO - 2024-02-28 00:28:17 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:28:17 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:28:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:28:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:28:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:28:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:28:17 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:28:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:28:17 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:28:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:28:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:28:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:28:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:28:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:28:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:28:17 --> Final output sent to browser
DEBUG - 2024-02-28 00:28:17 --> Total execution time: 0.0320
ERROR - 2024-02-28 00:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:28:59 --> Config Class Initialized
INFO - 2024-02-28 00:28:59 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:28:59 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:28:59 --> Utf8 Class Initialized
INFO - 2024-02-28 00:28:59 --> URI Class Initialized
INFO - 2024-02-28 00:28:59 --> Router Class Initialized
INFO - 2024-02-28 00:28:59 --> Output Class Initialized
INFO - 2024-02-28 00:28:59 --> Security Class Initialized
DEBUG - 2024-02-28 00:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:28:59 --> Input Class Initialized
INFO - 2024-02-28 00:28:59 --> Language Class Initialized
INFO - 2024-02-28 00:28:59 --> Loader Class Initialized
INFO - 2024-02-28 00:28:59 --> Helper loaded: url_helper
INFO - 2024-02-28 00:28:59 --> Helper loaded: file_helper
INFO - 2024-02-28 00:28:59 --> Helper loaded: form_helper
INFO - 2024-02-28 00:28:59 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:28:59 --> Controller Class Initialized
INFO - 2024-02-28 00:28:59 --> Form Validation Class Initialized
INFO - 2024-02-28 00:28:59 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:28:59 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:28:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:28:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:28:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:28:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:28:59 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:29:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:29:00 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:29:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:29:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:29:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:29:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:29:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:29:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:29:00 --> Final output sent to browser
DEBUG - 2024-02-28 00:29:00 --> Total execution time: 0.0339
ERROR - 2024-02-28 00:29:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:29:13 --> Config Class Initialized
INFO - 2024-02-28 00:29:13 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:29:13 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:29:13 --> Utf8 Class Initialized
INFO - 2024-02-28 00:29:13 --> URI Class Initialized
INFO - 2024-02-28 00:29:13 --> Router Class Initialized
INFO - 2024-02-28 00:29:13 --> Output Class Initialized
INFO - 2024-02-28 00:29:13 --> Security Class Initialized
DEBUG - 2024-02-28 00:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:29:13 --> Input Class Initialized
INFO - 2024-02-28 00:29:13 --> Language Class Initialized
INFO - 2024-02-28 00:29:13 --> Loader Class Initialized
INFO - 2024-02-28 00:29:13 --> Helper loaded: url_helper
INFO - 2024-02-28 00:29:13 --> Helper loaded: file_helper
INFO - 2024-02-28 00:29:13 --> Helper loaded: form_helper
INFO - 2024-02-28 00:29:13 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:29:13 --> Controller Class Initialized
INFO - 2024-02-28 00:29:13 --> Form Validation Class Initialized
INFO - 2024-02-28 00:29:13 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:29:13 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:29:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:29:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:29:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:29:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:29:13 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:29:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:29:13 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:29:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:29:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:29:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:29:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:29:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:29:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:29:13 --> Final output sent to browser
DEBUG - 2024-02-28 00:29:13 --> Total execution time: 0.0382
ERROR - 2024-02-28 00:29:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:29:23 --> Config Class Initialized
INFO - 2024-02-28 00:29:23 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:29:23 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:29:23 --> Utf8 Class Initialized
INFO - 2024-02-28 00:29:23 --> URI Class Initialized
INFO - 2024-02-28 00:29:23 --> Router Class Initialized
INFO - 2024-02-28 00:29:23 --> Output Class Initialized
INFO - 2024-02-28 00:29:23 --> Security Class Initialized
DEBUG - 2024-02-28 00:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:29:23 --> Input Class Initialized
INFO - 2024-02-28 00:29:23 --> Language Class Initialized
INFO - 2024-02-28 00:29:23 --> Loader Class Initialized
INFO - 2024-02-28 00:29:23 --> Helper loaded: url_helper
INFO - 2024-02-28 00:29:23 --> Helper loaded: file_helper
INFO - 2024-02-28 00:29:23 --> Helper loaded: form_helper
INFO - 2024-02-28 00:29:23 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:29:23 --> Controller Class Initialized
INFO - 2024-02-28 00:29:23 --> Form Validation Class Initialized
INFO - 2024-02-28 00:29:23 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:29:23 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:29:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:29:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:29:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:29:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:29:23 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:29:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:29:23 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:29:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:29:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:29:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:29:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:29:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:29:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:29:23 --> Final output sent to browser
DEBUG - 2024-02-28 00:29:23 --> Total execution time: 0.0464
ERROR - 2024-02-28 00:29:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:29:39 --> Config Class Initialized
INFO - 2024-02-28 00:29:39 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:29:39 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:29:39 --> Utf8 Class Initialized
INFO - 2024-02-28 00:29:39 --> URI Class Initialized
INFO - 2024-02-28 00:29:39 --> Router Class Initialized
INFO - 2024-02-28 00:29:39 --> Output Class Initialized
INFO - 2024-02-28 00:29:39 --> Security Class Initialized
DEBUG - 2024-02-28 00:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:29:39 --> Input Class Initialized
INFO - 2024-02-28 00:29:39 --> Language Class Initialized
INFO - 2024-02-28 00:29:39 --> Loader Class Initialized
INFO - 2024-02-28 00:29:39 --> Helper loaded: url_helper
INFO - 2024-02-28 00:29:39 --> Helper loaded: file_helper
INFO - 2024-02-28 00:29:39 --> Helper loaded: form_helper
INFO - 2024-02-28 00:29:39 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:29:39 --> Controller Class Initialized
INFO - 2024-02-28 00:29:39 --> Form Validation Class Initialized
INFO - 2024-02-28 00:29:40 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:29:40 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:29:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:29:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:29:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:29:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:29:40 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:29:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:29:40 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:29:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:29:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:29:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:29:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:29:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:29:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:29:40 --> Final output sent to browser
DEBUG - 2024-02-28 00:29:40 --> Total execution time: 0.0341
ERROR - 2024-02-28 00:30:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:30:13 --> Config Class Initialized
INFO - 2024-02-28 00:30:13 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:30:13 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:30:13 --> Utf8 Class Initialized
INFO - 2024-02-28 00:30:13 --> URI Class Initialized
INFO - 2024-02-28 00:30:13 --> Router Class Initialized
INFO - 2024-02-28 00:30:13 --> Output Class Initialized
INFO - 2024-02-28 00:30:13 --> Security Class Initialized
DEBUG - 2024-02-28 00:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:30:13 --> Input Class Initialized
INFO - 2024-02-28 00:30:13 --> Language Class Initialized
INFO - 2024-02-28 00:30:13 --> Loader Class Initialized
INFO - 2024-02-28 00:30:13 --> Helper loaded: url_helper
INFO - 2024-02-28 00:30:13 --> Helper loaded: file_helper
INFO - 2024-02-28 00:30:13 --> Helper loaded: form_helper
INFO - 2024-02-28 00:30:13 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:30:13 --> Controller Class Initialized
INFO - 2024-02-28 00:30:13 --> Form Validation Class Initialized
INFO - 2024-02-28 00:30:13 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:30:13 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:30:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:30:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:30:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:30:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:30:13 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:30:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:30:13 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:30:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:30:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:30:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:30:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:30:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:30:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:30:13 --> Final output sent to browser
DEBUG - 2024-02-28 00:30:13 --> Total execution time: 0.0413
ERROR - 2024-02-28 00:30:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:30:38 --> Config Class Initialized
INFO - 2024-02-28 00:30:38 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:30:38 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:30:38 --> Utf8 Class Initialized
INFO - 2024-02-28 00:30:38 --> URI Class Initialized
INFO - 2024-02-28 00:30:38 --> Router Class Initialized
INFO - 2024-02-28 00:30:38 --> Output Class Initialized
INFO - 2024-02-28 00:30:38 --> Security Class Initialized
DEBUG - 2024-02-28 00:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:30:38 --> Input Class Initialized
INFO - 2024-02-28 00:30:38 --> Language Class Initialized
INFO - 2024-02-28 00:30:38 --> Loader Class Initialized
INFO - 2024-02-28 00:30:38 --> Helper loaded: url_helper
INFO - 2024-02-28 00:30:38 --> Helper loaded: file_helper
INFO - 2024-02-28 00:30:38 --> Helper loaded: form_helper
INFO - 2024-02-28 00:30:38 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:30:38 --> Controller Class Initialized
INFO - 2024-02-28 00:30:38 --> Form Validation Class Initialized
INFO - 2024-02-28 00:30:38 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:30:38 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:30:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:30:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:30:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:30:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:30:38 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:30:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:30:38 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:30:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:30:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:30:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:30:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:30:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:30:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:30:38 --> Final output sent to browser
DEBUG - 2024-02-28 00:30:38 --> Total execution time: 0.0412
ERROR - 2024-02-28 00:30:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:30:42 --> Config Class Initialized
INFO - 2024-02-28 00:30:42 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:30:42 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:30:42 --> Utf8 Class Initialized
INFO - 2024-02-28 00:30:42 --> URI Class Initialized
INFO - 2024-02-28 00:30:42 --> Router Class Initialized
INFO - 2024-02-28 00:30:42 --> Output Class Initialized
INFO - 2024-02-28 00:30:42 --> Security Class Initialized
DEBUG - 2024-02-28 00:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:30:42 --> Input Class Initialized
INFO - 2024-02-28 00:30:42 --> Language Class Initialized
INFO - 2024-02-28 00:30:42 --> Loader Class Initialized
INFO - 2024-02-28 00:30:42 --> Helper loaded: url_helper
INFO - 2024-02-28 00:30:42 --> Helper loaded: file_helper
INFO - 2024-02-28 00:30:42 --> Helper loaded: form_helper
INFO - 2024-02-28 00:30:42 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:30:42 --> Controller Class Initialized
INFO - 2024-02-28 00:30:42 --> Form Validation Class Initialized
INFO - 2024-02-28 00:30:42 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:30:42 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:30:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:30:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:30:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:30:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:30:42 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:30:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:30:42 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:30:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:30:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:30:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:30:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:30:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:30:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:30:42 --> Final output sent to browser
DEBUG - 2024-02-28 00:30:42 --> Total execution time: 0.0220
ERROR - 2024-02-28 00:32:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:32:10 --> Config Class Initialized
INFO - 2024-02-28 00:32:10 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:32:10 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:32:10 --> Utf8 Class Initialized
INFO - 2024-02-28 00:32:10 --> URI Class Initialized
INFO - 2024-02-28 00:32:10 --> Router Class Initialized
INFO - 2024-02-28 00:32:10 --> Output Class Initialized
INFO - 2024-02-28 00:32:10 --> Security Class Initialized
DEBUG - 2024-02-28 00:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:32:10 --> Input Class Initialized
INFO - 2024-02-28 00:32:10 --> Language Class Initialized
INFO - 2024-02-28 00:32:10 --> Loader Class Initialized
INFO - 2024-02-28 00:32:10 --> Helper loaded: url_helper
INFO - 2024-02-28 00:32:10 --> Helper loaded: file_helper
INFO - 2024-02-28 00:32:10 --> Helper loaded: form_helper
INFO - 2024-02-28 00:32:10 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:32:10 --> Controller Class Initialized
INFO - 2024-02-28 00:32:10 --> Form Validation Class Initialized
INFO - 2024-02-28 00:32:10 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:32:10 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:32:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:32:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:32:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:32:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:32:10 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:32:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:32:10 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:32:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:32:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:32:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:32:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:32:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:32:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:32:10 --> Final output sent to browser
DEBUG - 2024-02-28 00:32:10 --> Total execution time: 0.0253
ERROR - 2024-02-28 00:32:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:32:51 --> Config Class Initialized
INFO - 2024-02-28 00:32:51 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:32:51 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:32:51 --> Utf8 Class Initialized
INFO - 2024-02-28 00:32:51 --> URI Class Initialized
INFO - 2024-02-28 00:32:51 --> Router Class Initialized
INFO - 2024-02-28 00:32:51 --> Output Class Initialized
INFO - 2024-02-28 00:32:51 --> Security Class Initialized
DEBUG - 2024-02-28 00:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:32:51 --> Input Class Initialized
INFO - 2024-02-28 00:32:51 --> Language Class Initialized
INFO - 2024-02-28 00:32:51 --> Loader Class Initialized
INFO - 2024-02-28 00:32:51 --> Helper loaded: url_helper
INFO - 2024-02-28 00:32:51 --> Helper loaded: file_helper
INFO - 2024-02-28 00:32:51 --> Helper loaded: form_helper
INFO - 2024-02-28 00:32:51 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:32:51 --> Controller Class Initialized
INFO - 2024-02-28 00:32:51 --> Form Validation Class Initialized
INFO - 2024-02-28 00:32:51 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:32:51 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:32:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:32:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:32:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:32:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:32:51 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:32:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:32:51 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:32:51 --> Final output sent to browser
DEBUG - 2024-02-28 00:32:51 --> Total execution time: 0.0316
ERROR - 2024-02-28 00:32:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:32:57 --> Config Class Initialized
INFO - 2024-02-28 00:32:57 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:32:57 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:32:57 --> Utf8 Class Initialized
INFO - 2024-02-28 00:32:57 --> URI Class Initialized
INFO - 2024-02-28 00:32:57 --> Router Class Initialized
INFO - 2024-02-28 00:32:57 --> Output Class Initialized
INFO - 2024-02-28 00:32:57 --> Security Class Initialized
DEBUG - 2024-02-28 00:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:32:57 --> Input Class Initialized
INFO - 2024-02-28 00:32:57 --> Language Class Initialized
INFO - 2024-02-28 00:32:57 --> Loader Class Initialized
INFO - 2024-02-28 00:32:57 --> Helper loaded: url_helper
INFO - 2024-02-28 00:32:57 --> Helper loaded: file_helper
INFO - 2024-02-28 00:32:57 --> Helper loaded: form_helper
INFO - 2024-02-28 00:32:57 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:32:57 --> Controller Class Initialized
INFO - 2024-02-28 00:32:57 --> Form Validation Class Initialized
INFO - 2024-02-28 00:32:57 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:32:57 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:32:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:32:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:32:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:32:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:32:57 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:32:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:32:57 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:32:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:32:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:32:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:32:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:32:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:32:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:32:57 --> Final output sent to browser
DEBUG - 2024-02-28 00:32:57 --> Total execution time: 0.0495
ERROR - 2024-02-28 00:33:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:33:41 --> Config Class Initialized
INFO - 2024-02-28 00:33:41 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:33:41 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:33:41 --> Utf8 Class Initialized
INFO - 2024-02-28 00:33:41 --> URI Class Initialized
INFO - 2024-02-28 00:33:41 --> Router Class Initialized
INFO - 2024-02-28 00:33:41 --> Output Class Initialized
INFO - 2024-02-28 00:33:41 --> Security Class Initialized
DEBUG - 2024-02-28 00:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:33:41 --> Input Class Initialized
INFO - 2024-02-28 00:33:41 --> Language Class Initialized
INFO - 2024-02-28 00:33:41 --> Loader Class Initialized
INFO - 2024-02-28 00:33:41 --> Helper loaded: url_helper
INFO - 2024-02-28 00:33:41 --> Helper loaded: file_helper
INFO - 2024-02-28 00:33:41 --> Helper loaded: form_helper
INFO - 2024-02-28 00:33:41 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:33:41 --> Controller Class Initialized
INFO - 2024-02-28 00:33:41 --> Form Validation Class Initialized
INFO - 2024-02-28 00:33:41 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:33:41 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:33:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:33:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:33:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:33:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:33:41 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:33:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:33:41 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:33:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:33:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:33:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:33:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:33:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:33:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:33:41 --> Final output sent to browser
DEBUG - 2024-02-28 00:33:41 --> Total execution time: 0.0379
ERROR - 2024-02-28 00:37:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 00:37:53 --> Config Class Initialized
INFO - 2024-02-28 00:37:53 --> Hooks Class Initialized
DEBUG - 2024-02-28 00:37:53 --> UTF-8 Support Enabled
INFO - 2024-02-28 00:37:53 --> Utf8 Class Initialized
INFO - 2024-02-28 00:37:53 --> URI Class Initialized
INFO - 2024-02-28 00:37:53 --> Router Class Initialized
INFO - 2024-02-28 00:37:53 --> Output Class Initialized
INFO - 2024-02-28 00:37:53 --> Security Class Initialized
DEBUG - 2024-02-28 00:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 00:37:53 --> Input Class Initialized
INFO - 2024-02-28 00:37:53 --> Language Class Initialized
INFO - 2024-02-28 00:37:53 --> Loader Class Initialized
INFO - 2024-02-28 00:37:53 --> Helper loaded: url_helper
INFO - 2024-02-28 00:37:53 --> Helper loaded: file_helper
INFO - 2024-02-28 00:37:53 --> Helper loaded: form_helper
INFO - 2024-02-28 00:37:53 --> Database Driver Class Initialized
DEBUG - 2024-02-28 00:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 00:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 00:37:53 --> Controller Class Initialized
INFO - 2024-02-28 00:37:53 --> Form Validation Class Initialized
INFO - 2024-02-28 00:37:53 --> Model "MasterModel" initialized
INFO - 2024-02-28 00:37:53 --> Model "DashboardModel" initialized
INFO - 2024-02-28 00:37:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 00:37:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 00:37:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 00:37:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 00:37:53 --> Model "OrderModel" initialized
INFO - 2024-02-28 00:37:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 00:37:53 --> Model "ReportModel" initialized
INFO - 2024-02-28 00:37:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 00:37:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 00:37:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 00:37:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 00:37:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 00:37:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 00:37:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 00:37:53 --> Final output sent to browser
DEBUG - 2024-02-28 00:37:53 --> Total execution time: 0.0344
ERROR - 2024-02-28 01:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:15:51 --> Config Class Initialized
INFO - 2024-02-28 01:15:51 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:15:51 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:15:51 --> Utf8 Class Initialized
INFO - 2024-02-28 01:15:51 --> URI Class Initialized
INFO - 2024-02-28 01:15:51 --> Router Class Initialized
INFO - 2024-02-28 01:15:51 --> Output Class Initialized
INFO - 2024-02-28 01:15:51 --> Security Class Initialized
DEBUG - 2024-02-28 01:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:15:51 --> Input Class Initialized
INFO - 2024-02-28 01:15:51 --> Language Class Initialized
INFO - 2024-02-28 01:15:51 --> Loader Class Initialized
INFO - 2024-02-28 01:15:51 --> Helper loaded: url_helper
INFO - 2024-02-28 01:15:51 --> Helper loaded: file_helper
INFO - 2024-02-28 01:15:51 --> Helper loaded: form_helper
INFO - 2024-02-28 01:15:51 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:15:51 --> Controller Class Initialized
INFO - 2024-02-28 01:15:51 --> Form Validation Class Initialized
INFO - 2024-02-28 01:15:51 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:15:51 --> Final output sent to browser
DEBUG - 2024-02-28 01:15:51 --> Total execution time: 0.0446
ERROR - 2024-02-28 01:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:15:51 --> Config Class Initialized
INFO - 2024-02-28 01:15:51 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:15:51 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:15:51 --> Utf8 Class Initialized
INFO - 2024-02-28 01:15:51 --> URI Class Initialized
INFO - 2024-02-28 01:15:51 --> Router Class Initialized
INFO - 2024-02-28 01:15:51 --> Output Class Initialized
INFO - 2024-02-28 01:15:51 --> Security Class Initialized
DEBUG - 2024-02-28 01:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:15:51 --> Input Class Initialized
INFO - 2024-02-28 01:15:51 --> Language Class Initialized
INFO - 2024-02-28 01:15:51 --> Loader Class Initialized
INFO - 2024-02-28 01:15:51 --> Helper loaded: url_helper
INFO - 2024-02-28 01:15:51 --> Helper loaded: file_helper
INFO - 2024-02-28 01:15:51 --> Helper loaded: form_helper
INFO - 2024-02-28 01:15:51 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:15:51 --> Controller Class Initialized
INFO - 2024-02-28 01:15:51 --> Form Validation Class Initialized
INFO - 2024-02-28 01:15:51 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:15:51 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:16:28 --> Config Class Initialized
INFO - 2024-02-28 01:16:28 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:16:28 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:16:28 --> Utf8 Class Initialized
INFO - 2024-02-28 01:16:28 --> URI Class Initialized
INFO - 2024-02-28 01:16:28 --> Router Class Initialized
INFO - 2024-02-28 01:16:28 --> Output Class Initialized
INFO - 2024-02-28 01:16:28 --> Security Class Initialized
DEBUG - 2024-02-28 01:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:16:28 --> Input Class Initialized
INFO - 2024-02-28 01:16:28 --> Language Class Initialized
INFO - 2024-02-28 01:16:28 --> Loader Class Initialized
INFO - 2024-02-28 01:16:28 --> Helper loaded: url_helper
INFO - 2024-02-28 01:16:28 --> Helper loaded: file_helper
INFO - 2024-02-28 01:16:28 --> Helper loaded: form_helper
INFO - 2024-02-28 01:16:28 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:16:28 --> Controller Class Initialized
INFO - 2024-02-28 01:16:28 --> Form Validation Class Initialized
INFO - 2024-02-28 01:16:28 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:16:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:16:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:16:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:16:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:16:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:16:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:16:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:16:28 --> Final output sent to browser
DEBUG - 2024-02-28 01:16:28 --> Total execution time: 0.0343
ERROR - 2024-02-28 01:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:16:28 --> Config Class Initialized
INFO - 2024-02-28 01:16:28 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:16:28 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:16:28 --> Utf8 Class Initialized
INFO - 2024-02-28 01:16:28 --> URI Class Initialized
INFO - 2024-02-28 01:16:28 --> Router Class Initialized
INFO - 2024-02-28 01:16:28 --> Output Class Initialized
INFO - 2024-02-28 01:16:28 --> Security Class Initialized
DEBUG - 2024-02-28 01:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:16:28 --> Input Class Initialized
INFO - 2024-02-28 01:16:28 --> Language Class Initialized
INFO - 2024-02-28 01:16:28 --> Loader Class Initialized
INFO - 2024-02-28 01:16:28 --> Helper loaded: url_helper
INFO - 2024-02-28 01:16:28 --> Helper loaded: file_helper
INFO - 2024-02-28 01:16:28 --> Helper loaded: form_helper
INFO - 2024-02-28 01:16:28 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:16:28 --> Controller Class Initialized
INFO - 2024-02-28 01:16:28 --> Form Validation Class Initialized
INFO - 2024-02-28 01:16:28 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:16:28 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:16:30 --> Config Class Initialized
INFO - 2024-02-28 01:16:30 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:16:30 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:16:30 --> Utf8 Class Initialized
INFO - 2024-02-28 01:16:30 --> URI Class Initialized
INFO - 2024-02-28 01:16:30 --> Router Class Initialized
INFO - 2024-02-28 01:16:30 --> Output Class Initialized
INFO - 2024-02-28 01:16:30 --> Security Class Initialized
DEBUG - 2024-02-28 01:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:16:30 --> Input Class Initialized
INFO - 2024-02-28 01:16:30 --> Language Class Initialized
INFO - 2024-02-28 01:16:30 --> Loader Class Initialized
INFO - 2024-02-28 01:16:30 --> Helper loaded: url_helper
INFO - 2024-02-28 01:16:30 --> Helper loaded: file_helper
INFO - 2024-02-28 01:16:30 --> Helper loaded: form_helper
INFO - 2024-02-28 01:16:30 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:16:30 --> Controller Class Initialized
INFO - 2024-02-28 01:16:30 --> Form Validation Class Initialized
INFO - 2024-02-28 01:16:30 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-28 01:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-28 01:16:30 --> Final output sent to browser
DEBUG - 2024-02-28 01:16:30 --> Total execution time: 0.0298
ERROR - 2024-02-28 01:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:16:30 --> Config Class Initialized
INFO - 2024-02-28 01:16:30 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:16:30 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:16:30 --> Utf8 Class Initialized
INFO - 2024-02-28 01:16:30 --> URI Class Initialized
INFO - 2024-02-28 01:16:30 --> Router Class Initialized
INFO - 2024-02-28 01:16:30 --> Output Class Initialized
INFO - 2024-02-28 01:16:30 --> Security Class Initialized
DEBUG - 2024-02-28 01:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:16:30 --> Input Class Initialized
INFO - 2024-02-28 01:16:30 --> Language Class Initialized
INFO - 2024-02-28 01:16:30 --> Loader Class Initialized
INFO - 2024-02-28 01:16:30 --> Helper loaded: url_helper
INFO - 2024-02-28 01:16:30 --> Helper loaded: file_helper
INFO - 2024-02-28 01:16:30 --> Helper loaded: form_helper
INFO - 2024-02-28 01:16:30 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:16:30 --> Controller Class Initialized
INFO - 2024-02-28 01:16:30 --> Form Validation Class Initialized
INFO - 2024-02-28 01:16:30 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:16:30 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:16:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:16:32 --> Config Class Initialized
INFO - 2024-02-28 01:16:32 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:16:32 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:16:32 --> Utf8 Class Initialized
INFO - 2024-02-28 01:16:32 --> URI Class Initialized
INFO - 2024-02-28 01:16:32 --> Router Class Initialized
INFO - 2024-02-28 01:16:33 --> Output Class Initialized
INFO - 2024-02-28 01:16:33 --> Security Class Initialized
DEBUG - 2024-02-28 01:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:16:33 --> Input Class Initialized
INFO - 2024-02-28 01:16:33 --> Language Class Initialized
INFO - 2024-02-28 01:16:33 --> Loader Class Initialized
INFO - 2024-02-28 01:16:33 --> Helper loaded: url_helper
INFO - 2024-02-28 01:16:33 --> Helper loaded: file_helper
INFO - 2024-02-28 01:16:33 --> Helper loaded: form_helper
INFO - 2024-02-28 01:16:33 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:16:33 --> Controller Class Initialized
INFO - 2024-02-28 01:16:33 --> Form Validation Class Initialized
INFO - 2024-02-28 01:16:33 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:16:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:16:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:16:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:16:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:16:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:16:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:16:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:16:33 --> Final output sent to browser
DEBUG - 2024-02-28 01:16:33 --> Total execution time: 0.0400
ERROR - 2024-02-28 01:16:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:16:33 --> Config Class Initialized
INFO - 2024-02-28 01:16:33 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:16:33 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:16:33 --> Utf8 Class Initialized
INFO - 2024-02-28 01:16:33 --> URI Class Initialized
INFO - 2024-02-28 01:16:33 --> Router Class Initialized
INFO - 2024-02-28 01:16:33 --> Output Class Initialized
INFO - 2024-02-28 01:16:33 --> Security Class Initialized
DEBUG - 2024-02-28 01:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:16:33 --> Input Class Initialized
INFO - 2024-02-28 01:16:33 --> Language Class Initialized
INFO - 2024-02-28 01:16:33 --> Loader Class Initialized
INFO - 2024-02-28 01:16:33 --> Helper loaded: url_helper
INFO - 2024-02-28 01:16:33 --> Helper loaded: file_helper
INFO - 2024-02-28 01:16:33 --> Helper loaded: form_helper
INFO - 2024-02-28 01:16:33 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:16:33 --> Controller Class Initialized
INFO - 2024-02-28 01:16:33 --> Form Validation Class Initialized
INFO - 2024-02-28 01:16:33 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:16:33 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:18:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:18:29 --> Config Class Initialized
INFO - 2024-02-28 01:18:29 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:18:29 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:18:29 --> Utf8 Class Initialized
INFO - 2024-02-28 01:18:29 --> URI Class Initialized
INFO - 2024-02-28 01:18:29 --> Router Class Initialized
INFO - 2024-02-28 01:18:29 --> Output Class Initialized
INFO - 2024-02-28 01:18:29 --> Security Class Initialized
DEBUG - 2024-02-28 01:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:18:29 --> Input Class Initialized
INFO - 2024-02-28 01:18:29 --> Language Class Initialized
INFO - 2024-02-28 01:18:29 --> Loader Class Initialized
INFO - 2024-02-28 01:18:29 --> Helper loaded: url_helper
INFO - 2024-02-28 01:18:29 --> Helper loaded: file_helper
INFO - 2024-02-28 01:18:29 --> Helper loaded: form_helper
INFO - 2024-02-28 01:18:29 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:18:29 --> Controller Class Initialized
INFO - 2024-02-28 01:18:29 --> Form Validation Class Initialized
INFO - 2024-02-28 01:18:29 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:18:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:18:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:18:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:18:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:18:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:18:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:18:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:18:29 --> Final output sent to browser
DEBUG - 2024-02-28 01:18:29 --> Total execution time: 0.0311
ERROR - 2024-02-28 01:18:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:18:29 --> Config Class Initialized
INFO - 2024-02-28 01:18:29 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:18:29 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:18:29 --> Utf8 Class Initialized
INFO - 2024-02-28 01:18:29 --> URI Class Initialized
INFO - 2024-02-28 01:18:29 --> Router Class Initialized
INFO - 2024-02-28 01:18:29 --> Output Class Initialized
INFO - 2024-02-28 01:18:29 --> Security Class Initialized
DEBUG - 2024-02-28 01:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:18:29 --> Input Class Initialized
INFO - 2024-02-28 01:18:29 --> Language Class Initialized
INFO - 2024-02-28 01:18:29 --> Loader Class Initialized
INFO - 2024-02-28 01:18:29 --> Helper loaded: url_helper
INFO - 2024-02-28 01:18:29 --> Helper loaded: file_helper
INFO - 2024-02-28 01:18:29 --> Helper loaded: form_helper
INFO - 2024-02-28 01:18:29 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:18:29 --> Controller Class Initialized
INFO - 2024-02-28 01:18:29 --> Form Validation Class Initialized
INFO - 2024-02-28 01:18:29 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:18:29 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:21:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:21:15 --> Config Class Initialized
INFO - 2024-02-28 01:21:15 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:21:15 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:21:15 --> Utf8 Class Initialized
INFO - 2024-02-28 01:21:15 --> URI Class Initialized
INFO - 2024-02-28 01:21:15 --> Router Class Initialized
INFO - 2024-02-28 01:21:15 --> Output Class Initialized
INFO - 2024-02-28 01:21:15 --> Security Class Initialized
DEBUG - 2024-02-28 01:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:21:15 --> Input Class Initialized
INFO - 2024-02-28 01:21:15 --> Language Class Initialized
INFO - 2024-02-28 01:21:15 --> Loader Class Initialized
INFO - 2024-02-28 01:21:15 --> Helper loaded: url_helper
INFO - 2024-02-28 01:21:15 --> Helper loaded: file_helper
INFO - 2024-02-28 01:21:15 --> Helper loaded: form_helper
INFO - 2024-02-28 01:21:15 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:21:15 --> Controller Class Initialized
INFO - 2024-02-28 01:21:15 --> Form Validation Class Initialized
INFO - 2024-02-28 01:21:15 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:21:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:21:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:21:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:21:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:21:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:21:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:21:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:21:15 --> Final output sent to browser
DEBUG - 2024-02-28 01:21:15 --> Total execution time: 0.0355
ERROR - 2024-02-28 01:21:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:21:15 --> Config Class Initialized
INFO - 2024-02-28 01:21:15 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:21:15 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:21:15 --> Utf8 Class Initialized
INFO - 2024-02-28 01:21:15 --> URI Class Initialized
INFO - 2024-02-28 01:21:15 --> Router Class Initialized
INFO - 2024-02-28 01:21:15 --> Output Class Initialized
INFO - 2024-02-28 01:21:15 --> Security Class Initialized
DEBUG - 2024-02-28 01:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:21:15 --> Input Class Initialized
INFO - 2024-02-28 01:21:15 --> Language Class Initialized
INFO - 2024-02-28 01:21:15 --> Loader Class Initialized
INFO - 2024-02-28 01:21:15 --> Helper loaded: url_helper
INFO - 2024-02-28 01:21:15 --> Helper loaded: file_helper
INFO - 2024-02-28 01:21:15 --> Helper loaded: form_helper
INFO - 2024-02-28 01:21:15 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:21:15 --> Controller Class Initialized
INFO - 2024-02-28 01:21:15 --> Form Validation Class Initialized
INFO - 2024-02-28 01:21:15 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:21:15 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:21:19 --> Config Class Initialized
INFO - 2024-02-28 01:21:19 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:21:19 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:21:19 --> Utf8 Class Initialized
INFO - 2024-02-28 01:21:19 --> URI Class Initialized
INFO - 2024-02-28 01:21:19 --> Router Class Initialized
INFO - 2024-02-28 01:21:19 --> Output Class Initialized
INFO - 2024-02-28 01:21:19 --> Security Class Initialized
DEBUG - 2024-02-28 01:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:21:19 --> Input Class Initialized
INFO - 2024-02-28 01:21:19 --> Language Class Initialized
INFO - 2024-02-28 01:21:19 --> Loader Class Initialized
INFO - 2024-02-28 01:21:19 --> Helper loaded: url_helper
INFO - 2024-02-28 01:21:19 --> Helper loaded: file_helper
INFO - 2024-02-28 01:21:19 --> Helper loaded: form_helper
INFO - 2024-02-28 01:21:19 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:21:19 --> Controller Class Initialized
INFO - 2024-02-28 01:21:19 --> Form Validation Class Initialized
INFO - 2024-02-28 01:21:19 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:21:19 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:21:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:21:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:21:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:21:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:21:19 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:21:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:21:19 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:21:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:21:30 --> Config Class Initialized
INFO - 2024-02-28 01:21:30 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:21:30 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:21:30 --> Utf8 Class Initialized
INFO - 2024-02-28 01:21:30 --> URI Class Initialized
INFO - 2024-02-28 01:21:30 --> Router Class Initialized
INFO - 2024-02-28 01:21:30 --> Output Class Initialized
INFO - 2024-02-28 01:21:30 --> Security Class Initialized
DEBUG - 2024-02-28 01:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:21:30 --> Input Class Initialized
INFO - 2024-02-28 01:21:30 --> Language Class Initialized
INFO - 2024-02-28 01:21:30 --> Loader Class Initialized
INFO - 2024-02-28 01:21:30 --> Helper loaded: url_helper
INFO - 2024-02-28 01:21:30 --> Helper loaded: file_helper
INFO - 2024-02-28 01:21:30 --> Helper loaded: form_helper
INFO - 2024-02-28 01:21:30 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:21:30 --> Controller Class Initialized
INFO - 2024-02-28 01:21:30 --> Form Validation Class Initialized
INFO - 2024-02-28 01:21:30 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:21:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:21:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:21:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:21:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:21:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:21:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:21:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:21:30 --> Final output sent to browser
DEBUG - 2024-02-28 01:21:30 --> Total execution time: 0.0405
ERROR - 2024-02-28 01:21:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:21:30 --> Config Class Initialized
INFO - 2024-02-28 01:21:30 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:21:30 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:21:30 --> Utf8 Class Initialized
INFO - 2024-02-28 01:21:30 --> URI Class Initialized
INFO - 2024-02-28 01:21:30 --> Router Class Initialized
INFO - 2024-02-28 01:21:30 --> Output Class Initialized
INFO - 2024-02-28 01:21:30 --> Security Class Initialized
DEBUG - 2024-02-28 01:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:21:30 --> Input Class Initialized
INFO - 2024-02-28 01:21:30 --> Language Class Initialized
INFO - 2024-02-28 01:21:30 --> Loader Class Initialized
INFO - 2024-02-28 01:21:30 --> Helper loaded: url_helper
INFO - 2024-02-28 01:21:30 --> Helper loaded: file_helper
INFO - 2024-02-28 01:21:30 --> Helper loaded: form_helper
INFO - 2024-02-28 01:21:30 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:21:30 --> Controller Class Initialized
INFO - 2024-02-28 01:21:30 --> Form Validation Class Initialized
INFO - 2024-02-28 01:21:30 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:21:30 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:21:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:21:32 --> Config Class Initialized
INFO - 2024-02-28 01:21:32 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:21:32 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:21:32 --> Utf8 Class Initialized
INFO - 2024-02-28 01:21:32 --> URI Class Initialized
INFO - 2024-02-28 01:21:32 --> Router Class Initialized
INFO - 2024-02-28 01:21:32 --> Output Class Initialized
INFO - 2024-02-28 01:21:32 --> Security Class Initialized
DEBUG - 2024-02-28 01:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:21:32 --> Input Class Initialized
INFO - 2024-02-28 01:21:32 --> Language Class Initialized
INFO - 2024-02-28 01:21:32 --> Loader Class Initialized
INFO - 2024-02-28 01:21:32 --> Helper loaded: url_helper
INFO - 2024-02-28 01:21:32 --> Helper loaded: file_helper
INFO - 2024-02-28 01:21:32 --> Helper loaded: form_helper
INFO - 2024-02-28 01:21:32 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:21:32 --> Controller Class Initialized
INFO - 2024-02-28 01:21:32 --> Form Validation Class Initialized
INFO - 2024-02-28 01:21:32 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:21:32 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:21:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:21:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:21:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:21:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:21:32 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:21:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:21:32 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:21:43 --> Config Class Initialized
INFO - 2024-02-28 01:21:43 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:21:43 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:21:43 --> Utf8 Class Initialized
INFO - 2024-02-28 01:21:43 --> URI Class Initialized
INFO - 2024-02-28 01:21:43 --> Router Class Initialized
INFO - 2024-02-28 01:21:43 --> Output Class Initialized
INFO - 2024-02-28 01:21:43 --> Security Class Initialized
DEBUG - 2024-02-28 01:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:21:43 --> Input Class Initialized
INFO - 2024-02-28 01:21:43 --> Language Class Initialized
INFO - 2024-02-28 01:21:43 --> Loader Class Initialized
INFO - 2024-02-28 01:21:43 --> Helper loaded: url_helper
INFO - 2024-02-28 01:21:43 --> Helper loaded: file_helper
INFO - 2024-02-28 01:21:43 --> Helper loaded: form_helper
INFO - 2024-02-28 01:21:43 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:21:43 --> Controller Class Initialized
INFO - 2024-02-28 01:21:43 --> Form Validation Class Initialized
INFO - 2024-02-28 01:21:43 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:21:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:21:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:21:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:21:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:21:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:21:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:21:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:21:43 --> Final output sent to browser
DEBUG - 2024-02-28 01:21:43 --> Total execution time: 0.0474
ERROR - 2024-02-28 01:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:21:43 --> Config Class Initialized
INFO - 2024-02-28 01:21:43 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:21:43 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:21:43 --> Utf8 Class Initialized
INFO - 2024-02-28 01:21:43 --> URI Class Initialized
INFO - 2024-02-28 01:21:43 --> Router Class Initialized
INFO - 2024-02-28 01:21:43 --> Output Class Initialized
INFO - 2024-02-28 01:21:43 --> Security Class Initialized
DEBUG - 2024-02-28 01:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:21:43 --> Input Class Initialized
INFO - 2024-02-28 01:21:43 --> Language Class Initialized
INFO - 2024-02-28 01:21:43 --> Loader Class Initialized
INFO - 2024-02-28 01:21:43 --> Helper loaded: url_helper
INFO - 2024-02-28 01:21:43 --> Helper loaded: file_helper
INFO - 2024-02-28 01:21:43 --> Helper loaded: form_helper
INFO - 2024-02-28 01:21:43 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:21:43 --> Controller Class Initialized
INFO - 2024-02-28 01:21:43 --> Form Validation Class Initialized
INFO - 2024-02-28 01:21:43 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:21:43 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:21:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:21:57 --> Config Class Initialized
INFO - 2024-02-28 01:21:57 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:21:57 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:21:57 --> Utf8 Class Initialized
INFO - 2024-02-28 01:21:57 --> URI Class Initialized
INFO - 2024-02-28 01:21:57 --> Router Class Initialized
INFO - 2024-02-28 01:21:57 --> Output Class Initialized
INFO - 2024-02-28 01:21:57 --> Security Class Initialized
DEBUG - 2024-02-28 01:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:21:57 --> Input Class Initialized
INFO - 2024-02-28 01:21:57 --> Language Class Initialized
INFO - 2024-02-28 01:21:57 --> Loader Class Initialized
INFO - 2024-02-28 01:21:57 --> Helper loaded: url_helper
INFO - 2024-02-28 01:21:57 --> Helper loaded: file_helper
INFO - 2024-02-28 01:21:57 --> Helper loaded: form_helper
INFO - 2024-02-28 01:21:57 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:21:57 --> Controller Class Initialized
INFO - 2024-02-28 01:21:57 --> Form Validation Class Initialized
INFO - 2024-02-28 01:21:57 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:21:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:21:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:21:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:21:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:21:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:21:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:21:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:21:57 --> Final output sent to browser
DEBUG - 2024-02-28 01:21:57 --> Total execution time: 0.0371
ERROR - 2024-02-28 01:21:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:21:57 --> Config Class Initialized
INFO - 2024-02-28 01:21:57 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:21:57 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:21:57 --> Utf8 Class Initialized
INFO - 2024-02-28 01:21:57 --> URI Class Initialized
INFO - 2024-02-28 01:21:57 --> Router Class Initialized
INFO - 2024-02-28 01:21:57 --> Output Class Initialized
INFO - 2024-02-28 01:21:57 --> Security Class Initialized
DEBUG - 2024-02-28 01:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:21:57 --> Input Class Initialized
INFO - 2024-02-28 01:21:57 --> Language Class Initialized
INFO - 2024-02-28 01:21:57 --> Loader Class Initialized
INFO - 2024-02-28 01:21:57 --> Helper loaded: url_helper
INFO - 2024-02-28 01:21:57 --> Helper loaded: file_helper
INFO - 2024-02-28 01:21:57 --> Helper loaded: form_helper
INFO - 2024-02-28 01:21:57 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:21:57 --> Controller Class Initialized
INFO - 2024-02-28 01:21:57 --> Form Validation Class Initialized
INFO - 2024-02-28 01:21:57 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:21:57 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:21:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:21:59 --> Config Class Initialized
INFO - 2024-02-28 01:21:59 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:21:59 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:21:59 --> Utf8 Class Initialized
INFO - 2024-02-28 01:21:59 --> URI Class Initialized
INFO - 2024-02-28 01:21:59 --> Router Class Initialized
INFO - 2024-02-28 01:21:59 --> Output Class Initialized
INFO - 2024-02-28 01:21:59 --> Security Class Initialized
DEBUG - 2024-02-28 01:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:21:59 --> Input Class Initialized
INFO - 2024-02-28 01:21:59 --> Language Class Initialized
INFO - 2024-02-28 01:21:59 --> Loader Class Initialized
INFO - 2024-02-28 01:21:59 --> Helper loaded: url_helper
INFO - 2024-02-28 01:21:59 --> Helper loaded: file_helper
INFO - 2024-02-28 01:21:59 --> Helper loaded: form_helper
INFO - 2024-02-28 01:21:59 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:21:59 --> Controller Class Initialized
INFO - 2024-02-28 01:21:59 --> Form Validation Class Initialized
INFO - 2024-02-28 01:21:59 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:21:59 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:21:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:21:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:21:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:21:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:21:59 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:21:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:21:59 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:22:12 --> Config Class Initialized
INFO - 2024-02-28 01:22:12 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:22:12 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:22:12 --> Utf8 Class Initialized
INFO - 2024-02-28 01:22:12 --> URI Class Initialized
INFO - 2024-02-28 01:22:12 --> Router Class Initialized
INFO - 2024-02-28 01:22:12 --> Output Class Initialized
INFO - 2024-02-28 01:22:12 --> Security Class Initialized
DEBUG - 2024-02-28 01:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:22:12 --> Input Class Initialized
INFO - 2024-02-28 01:22:12 --> Language Class Initialized
INFO - 2024-02-28 01:22:12 --> Loader Class Initialized
INFO - 2024-02-28 01:22:12 --> Helper loaded: url_helper
INFO - 2024-02-28 01:22:12 --> Helper loaded: file_helper
INFO - 2024-02-28 01:22:12 --> Helper loaded: form_helper
INFO - 2024-02-28 01:22:12 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:22:12 --> Controller Class Initialized
INFO - 2024-02-28 01:22:12 --> Form Validation Class Initialized
INFO - 2024-02-28 01:22:12 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:22:12 --> Final output sent to browser
DEBUG - 2024-02-28 01:22:12 --> Total execution time: 0.0391
ERROR - 2024-02-28 01:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:22:12 --> Config Class Initialized
INFO - 2024-02-28 01:22:12 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:22:12 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:22:12 --> Utf8 Class Initialized
INFO - 2024-02-28 01:22:12 --> URI Class Initialized
INFO - 2024-02-28 01:22:12 --> Router Class Initialized
INFO - 2024-02-28 01:22:12 --> Output Class Initialized
INFO - 2024-02-28 01:22:12 --> Security Class Initialized
DEBUG - 2024-02-28 01:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:22:12 --> Input Class Initialized
INFO - 2024-02-28 01:22:12 --> Language Class Initialized
INFO - 2024-02-28 01:22:12 --> Loader Class Initialized
INFO - 2024-02-28 01:22:12 --> Helper loaded: url_helper
INFO - 2024-02-28 01:22:12 --> Helper loaded: file_helper
INFO - 2024-02-28 01:22:12 --> Helper loaded: form_helper
INFO - 2024-02-28 01:22:12 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:22:12 --> Controller Class Initialized
INFO - 2024-02-28 01:22:12 --> Form Validation Class Initialized
INFO - 2024-02-28 01:22:12 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:22:12 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:22:17 --> Config Class Initialized
INFO - 2024-02-28 01:22:17 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:22:17 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:22:17 --> Utf8 Class Initialized
INFO - 2024-02-28 01:22:17 --> URI Class Initialized
INFO - 2024-02-28 01:22:17 --> Router Class Initialized
INFO - 2024-02-28 01:22:17 --> Output Class Initialized
INFO - 2024-02-28 01:22:17 --> Security Class Initialized
DEBUG - 2024-02-28 01:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:22:17 --> Input Class Initialized
INFO - 2024-02-28 01:22:17 --> Language Class Initialized
INFO - 2024-02-28 01:22:17 --> Loader Class Initialized
INFO - 2024-02-28 01:22:17 --> Helper loaded: url_helper
INFO - 2024-02-28 01:22:17 --> Helper loaded: file_helper
INFO - 2024-02-28 01:22:17 --> Helper loaded: form_helper
INFO - 2024-02-28 01:22:17 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:22:17 --> Controller Class Initialized
INFO - 2024-02-28 01:22:17 --> Form Validation Class Initialized
INFO - 2024-02-28 01:22:17 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:22:17 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:22:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:22:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:22:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:22:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:22:17 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:22:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:22:17 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:23:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:23:05 --> Config Class Initialized
INFO - 2024-02-28 01:23:05 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:23:05 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:23:05 --> Utf8 Class Initialized
INFO - 2024-02-28 01:23:05 --> URI Class Initialized
INFO - 2024-02-28 01:23:05 --> Router Class Initialized
INFO - 2024-02-28 01:23:05 --> Output Class Initialized
INFO - 2024-02-28 01:23:05 --> Security Class Initialized
DEBUG - 2024-02-28 01:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:23:05 --> Input Class Initialized
INFO - 2024-02-28 01:23:05 --> Language Class Initialized
INFO - 2024-02-28 01:23:05 --> Loader Class Initialized
INFO - 2024-02-28 01:23:05 --> Helper loaded: url_helper
INFO - 2024-02-28 01:23:05 --> Helper loaded: file_helper
INFO - 2024-02-28 01:23:05 --> Helper loaded: form_helper
INFO - 2024-02-28 01:23:05 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:23:05 --> Controller Class Initialized
INFO - 2024-02-28 01:23:05 --> Form Validation Class Initialized
INFO - 2024-02-28 01:23:05 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:23:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:23:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:23:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:23:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:23:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:23:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:23:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:23:05 --> Final output sent to browser
DEBUG - 2024-02-28 01:23:05 --> Total execution time: 0.0325
ERROR - 2024-02-28 01:23:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:23:05 --> Config Class Initialized
INFO - 2024-02-28 01:23:05 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:23:05 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:23:05 --> Utf8 Class Initialized
INFO - 2024-02-28 01:23:05 --> URI Class Initialized
INFO - 2024-02-28 01:23:05 --> Router Class Initialized
INFO - 2024-02-28 01:23:05 --> Output Class Initialized
INFO - 2024-02-28 01:23:05 --> Security Class Initialized
DEBUG - 2024-02-28 01:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:23:05 --> Input Class Initialized
INFO - 2024-02-28 01:23:05 --> Language Class Initialized
INFO - 2024-02-28 01:23:05 --> Loader Class Initialized
INFO - 2024-02-28 01:23:05 --> Helper loaded: url_helper
INFO - 2024-02-28 01:23:05 --> Helper loaded: file_helper
INFO - 2024-02-28 01:23:05 --> Helper loaded: form_helper
INFO - 2024-02-28 01:23:05 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:23:05 --> Controller Class Initialized
INFO - 2024-02-28 01:23:05 --> Form Validation Class Initialized
INFO - 2024-02-28 01:23:05 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:23:05 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:23:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:23:53 --> Config Class Initialized
INFO - 2024-02-28 01:23:53 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:23:53 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:23:53 --> Utf8 Class Initialized
INFO - 2024-02-28 01:23:53 --> URI Class Initialized
INFO - 2024-02-28 01:23:53 --> Router Class Initialized
INFO - 2024-02-28 01:23:53 --> Output Class Initialized
INFO - 2024-02-28 01:23:53 --> Security Class Initialized
DEBUG - 2024-02-28 01:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:23:53 --> Input Class Initialized
INFO - 2024-02-28 01:23:53 --> Language Class Initialized
INFO - 2024-02-28 01:23:53 --> Loader Class Initialized
INFO - 2024-02-28 01:23:53 --> Helper loaded: url_helper
INFO - 2024-02-28 01:23:53 --> Helper loaded: file_helper
INFO - 2024-02-28 01:23:53 --> Helper loaded: form_helper
INFO - 2024-02-28 01:23:53 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:23:53 --> Controller Class Initialized
INFO - 2024-02-28 01:23:53 --> Form Validation Class Initialized
INFO - 2024-02-28 01:23:53 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:23:53 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:23:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:23:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:23:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:23:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:23:53 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:23:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:23:53 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:23:53 --> Final output sent to browser
DEBUG - 2024-02-28 01:23:53 --> Total execution time: 0.0324
ERROR - 2024-02-28 01:23:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:23:54 --> Config Class Initialized
INFO - 2024-02-28 01:23:54 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:23:54 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:23:54 --> Utf8 Class Initialized
INFO - 2024-02-28 01:23:54 --> URI Class Initialized
INFO - 2024-02-28 01:23:54 --> Router Class Initialized
INFO - 2024-02-28 01:23:54 --> Output Class Initialized
INFO - 2024-02-28 01:23:54 --> Security Class Initialized
DEBUG - 2024-02-28 01:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:23:54 --> Input Class Initialized
INFO - 2024-02-28 01:23:54 --> Language Class Initialized
INFO - 2024-02-28 01:23:54 --> Loader Class Initialized
INFO - 2024-02-28 01:23:54 --> Helper loaded: url_helper
INFO - 2024-02-28 01:23:54 --> Helper loaded: file_helper
INFO - 2024-02-28 01:23:54 --> Helper loaded: form_helper
INFO - 2024-02-28 01:23:54 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:23:54 --> Controller Class Initialized
INFO - 2024-02-28 01:23:54 --> Form Validation Class Initialized
INFO - 2024-02-28 01:23:54 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:23:54 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:23:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:23:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:23:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:23:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:23:54 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:23:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:23:54 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:24:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:24:03 --> Config Class Initialized
INFO - 2024-02-28 01:24:03 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:24:03 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:24:03 --> Utf8 Class Initialized
INFO - 2024-02-28 01:24:03 --> URI Class Initialized
INFO - 2024-02-28 01:24:03 --> Router Class Initialized
INFO - 2024-02-28 01:24:03 --> Output Class Initialized
INFO - 2024-02-28 01:24:03 --> Security Class Initialized
DEBUG - 2024-02-28 01:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:24:03 --> Input Class Initialized
INFO - 2024-02-28 01:24:03 --> Language Class Initialized
INFO - 2024-02-28 01:24:03 --> Loader Class Initialized
INFO - 2024-02-28 01:24:03 --> Helper loaded: url_helper
INFO - 2024-02-28 01:24:03 --> Helper loaded: file_helper
INFO - 2024-02-28 01:24:03 --> Helper loaded: form_helper
INFO - 2024-02-28 01:24:03 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:24:03 --> Controller Class Initialized
INFO - 2024-02-28 01:24:03 --> Form Validation Class Initialized
INFO - 2024-02-28 01:24:03 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:24:03 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:24:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:24:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:24:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:24:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:24:03 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:24:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:24:03 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:24:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:24:04 --> Config Class Initialized
INFO - 2024-02-28 01:24:04 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:24:04 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:24:04 --> Utf8 Class Initialized
INFO - 2024-02-28 01:24:04 --> URI Class Initialized
INFO - 2024-02-28 01:24:04 --> Router Class Initialized
INFO - 2024-02-28 01:24:04 --> Output Class Initialized
INFO - 2024-02-28 01:24:04 --> Security Class Initialized
DEBUG - 2024-02-28 01:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:24:04 --> Input Class Initialized
INFO - 2024-02-28 01:24:04 --> Language Class Initialized
INFO - 2024-02-28 01:24:04 --> Loader Class Initialized
INFO - 2024-02-28 01:24:04 --> Helper loaded: url_helper
INFO - 2024-02-28 01:24:04 --> Helper loaded: file_helper
INFO - 2024-02-28 01:24:04 --> Helper loaded: form_helper
INFO - 2024-02-28 01:24:04 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:24:04 --> Controller Class Initialized
INFO - 2024-02-28 01:24:04 --> Form Validation Class Initialized
INFO - 2024-02-28 01:24:04 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:24:04 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:24:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:24:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:24:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:24:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:24:04 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:24:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:24:04 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:24:32 --> Config Class Initialized
INFO - 2024-02-28 01:24:32 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:24:32 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:24:32 --> Utf8 Class Initialized
INFO - 2024-02-28 01:24:32 --> URI Class Initialized
INFO - 2024-02-28 01:24:32 --> Router Class Initialized
INFO - 2024-02-28 01:24:32 --> Output Class Initialized
INFO - 2024-02-28 01:24:32 --> Security Class Initialized
DEBUG - 2024-02-28 01:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:24:32 --> Input Class Initialized
INFO - 2024-02-28 01:24:32 --> Language Class Initialized
INFO - 2024-02-28 01:24:32 --> Loader Class Initialized
INFO - 2024-02-28 01:24:32 --> Helper loaded: url_helper
INFO - 2024-02-28 01:24:32 --> Helper loaded: file_helper
INFO - 2024-02-28 01:24:32 --> Helper loaded: form_helper
INFO - 2024-02-28 01:24:32 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:24:32 --> Controller Class Initialized
INFO - 2024-02-28 01:24:32 --> Form Validation Class Initialized
INFO - 2024-02-28 01:24:32 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:24:32 --> Final output sent to browser
DEBUG - 2024-02-28 01:24:32 --> Total execution time: 0.0324
ERROR - 2024-02-28 01:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:24:32 --> Config Class Initialized
INFO - 2024-02-28 01:24:32 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:24:32 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:24:32 --> Utf8 Class Initialized
INFO - 2024-02-28 01:24:32 --> URI Class Initialized
INFO - 2024-02-28 01:24:32 --> Router Class Initialized
INFO - 2024-02-28 01:24:32 --> Output Class Initialized
INFO - 2024-02-28 01:24:32 --> Security Class Initialized
DEBUG - 2024-02-28 01:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:24:32 --> Input Class Initialized
INFO - 2024-02-28 01:24:32 --> Language Class Initialized
INFO - 2024-02-28 01:24:32 --> Loader Class Initialized
INFO - 2024-02-28 01:24:32 --> Helper loaded: url_helper
INFO - 2024-02-28 01:24:32 --> Helper loaded: file_helper
INFO - 2024-02-28 01:24:32 --> Helper loaded: form_helper
INFO - 2024-02-28 01:24:32 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:24:32 --> Controller Class Initialized
INFO - 2024-02-28 01:24:32 --> Form Validation Class Initialized
INFO - 2024-02-28 01:24:32 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:24:32 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:24:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:24:35 --> Config Class Initialized
INFO - 2024-02-28 01:24:35 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:24:35 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:24:35 --> Utf8 Class Initialized
INFO - 2024-02-28 01:24:35 --> URI Class Initialized
INFO - 2024-02-28 01:24:35 --> Router Class Initialized
INFO - 2024-02-28 01:24:35 --> Output Class Initialized
INFO - 2024-02-28 01:24:35 --> Security Class Initialized
DEBUG - 2024-02-28 01:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:24:35 --> Input Class Initialized
INFO - 2024-02-28 01:24:35 --> Language Class Initialized
INFO - 2024-02-28 01:24:35 --> Loader Class Initialized
INFO - 2024-02-28 01:24:35 --> Helper loaded: url_helper
INFO - 2024-02-28 01:24:35 --> Helper loaded: file_helper
INFO - 2024-02-28 01:24:35 --> Helper loaded: form_helper
INFO - 2024-02-28 01:24:35 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:24:35 --> Controller Class Initialized
INFO - 2024-02-28 01:24:35 --> Form Validation Class Initialized
INFO - 2024-02-28 01:24:35 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:24:35 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:24:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:24:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:24:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:24:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:24:35 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:24:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:24:35 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:24:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:24:37 --> Config Class Initialized
INFO - 2024-02-28 01:24:37 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:24:37 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:24:37 --> Utf8 Class Initialized
INFO - 2024-02-28 01:24:37 --> URI Class Initialized
INFO - 2024-02-28 01:24:37 --> Router Class Initialized
INFO - 2024-02-28 01:24:37 --> Output Class Initialized
INFO - 2024-02-28 01:24:37 --> Security Class Initialized
DEBUG - 2024-02-28 01:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:24:37 --> Input Class Initialized
INFO - 2024-02-28 01:24:37 --> Language Class Initialized
INFO - 2024-02-28 01:24:37 --> Loader Class Initialized
INFO - 2024-02-28 01:24:37 --> Helper loaded: url_helper
INFO - 2024-02-28 01:24:37 --> Helper loaded: file_helper
INFO - 2024-02-28 01:24:37 --> Helper loaded: form_helper
INFO - 2024-02-28 01:24:37 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:24:37 --> Controller Class Initialized
INFO - 2024-02-28 01:24:37 --> Form Validation Class Initialized
INFO - 2024-02-28 01:24:37 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:24:37 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:24:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:24:37 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:24:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:24:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:24:37 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:24:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:24:37 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:24:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:24:41 --> Config Class Initialized
INFO - 2024-02-28 01:24:41 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:24:41 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:24:41 --> Utf8 Class Initialized
INFO - 2024-02-28 01:24:41 --> URI Class Initialized
INFO - 2024-02-28 01:24:41 --> Router Class Initialized
INFO - 2024-02-28 01:24:41 --> Output Class Initialized
INFO - 2024-02-28 01:24:41 --> Security Class Initialized
DEBUG - 2024-02-28 01:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:24:41 --> Input Class Initialized
INFO - 2024-02-28 01:24:41 --> Language Class Initialized
INFO - 2024-02-28 01:24:41 --> Loader Class Initialized
INFO - 2024-02-28 01:24:41 --> Helper loaded: url_helper
INFO - 2024-02-28 01:24:41 --> Helper loaded: file_helper
INFO - 2024-02-28 01:24:41 --> Helper loaded: form_helper
INFO - 2024-02-28 01:24:41 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:24:41 --> Controller Class Initialized
INFO - 2024-02-28 01:24:41 --> Form Validation Class Initialized
INFO - 2024-02-28 01:24:41 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:24:41 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:24:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:24:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:24:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:24:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:24:41 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:24:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:24:41 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:25:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:25:00 --> Config Class Initialized
INFO - 2024-02-28 01:25:00 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:25:00 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:25:00 --> Utf8 Class Initialized
INFO - 2024-02-28 01:25:00 --> URI Class Initialized
INFO - 2024-02-28 01:25:00 --> Router Class Initialized
INFO - 2024-02-28 01:25:00 --> Output Class Initialized
INFO - 2024-02-28 01:25:00 --> Security Class Initialized
DEBUG - 2024-02-28 01:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:25:00 --> Input Class Initialized
INFO - 2024-02-28 01:25:00 --> Language Class Initialized
INFO - 2024-02-28 01:25:00 --> Loader Class Initialized
INFO - 2024-02-28 01:25:00 --> Helper loaded: url_helper
INFO - 2024-02-28 01:25:00 --> Helper loaded: file_helper
INFO - 2024-02-28 01:25:00 --> Helper loaded: form_helper
INFO - 2024-02-28 01:25:00 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:25:00 --> Controller Class Initialized
INFO - 2024-02-28 01:25:00 --> Form Validation Class Initialized
INFO - 2024-02-28 01:25:00 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:25:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:25:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:25:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:25:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:25:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:25:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:25:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:25:00 --> Final output sent to browser
DEBUG - 2024-02-28 01:25:00 --> Total execution time: 0.0360
ERROR - 2024-02-28 01:25:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:25:00 --> Config Class Initialized
INFO - 2024-02-28 01:25:00 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:25:00 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:25:00 --> Utf8 Class Initialized
INFO - 2024-02-28 01:25:00 --> URI Class Initialized
INFO - 2024-02-28 01:25:00 --> Router Class Initialized
INFO - 2024-02-28 01:25:00 --> Output Class Initialized
INFO - 2024-02-28 01:25:00 --> Security Class Initialized
DEBUG - 2024-02-28 01:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:25:00 --> Input Class Initialized
INFO - 2024-02-28 01:25:00 --> Language Class Initialized
INFO - 2024-02-28 01:25:00 --> Loader Class Initialized
INFO - 2024-02-28 01:25:00 --> Helper loaded: url_helper
INFO - 2024-02-28 01:25:00 --> Helper loaded: file_helper
INFO - 2024-02-28 01:25:00 --> Helper loaded: form_helper
INFO - 2024-02-28 01:25:00 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:25:00 --> Controller Class Initialized
INFO - 2024-02-28 01:25:00 --> Form Validation Class Initialized
INFO - 2024-02-28 01:25:00 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:25:00 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:25:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:25:04 --> Config Class Initialized
INFO - 2024-02-28 01:25:04 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:25:04 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:25:04 --> Utf8 Class Initialized
INFO - 2024-02-28 01:25:04 --> URI Class Initialized
INFO - 2024-02-28 01:25:04 --> Router Class Initialized
INFO - 2024-02-28 01:25:04 --> Output Class Initialized
INFO - 2024-02-28 01:25:04 --> Security Class Initialized
DEBUG - 2024-02-28 01:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:25:04 --> Input Class Initialized
INFO - 2024-02-28 01:25:04 --> Language Class Initialized
INFO - 2024-02-28 01:25:04 --> Loader Class Initialized
INFO - 2024-02-28 01:25:04 --> Helper loaded: url_helper
INFO - 2024-02-28 01:25:04 --> Helper loaded: file_helper
INFO - 2024-02-28 01:25:04 --> Helper loaded: form_helper
INFO - 2024-02-28 01:25:04 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:25:04 --> Controller Class Initialized
INFO - 2024-02-28 01:25:04 --> Form Validation Class Initialized
INFO - 2024-02-28 01:25:04 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:25:04 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:25:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:25:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:25:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:25:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:25:04 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:25:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:25:04 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:25:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:25:21 --> Config Class Initialized
INFO - 2024-02-28 01:25:21 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:25:21 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:25:21 --> Utf8 Class Initialized
INFO - 2024-02-28 01:25:21 --> URI Class Initialized
INFO - 2024-02-28 01:25:21 --> Router Class Initialized
INFO - 2024-02-28 01:25:21 --> Output Class Initialized
INFO - 2024-02-28 01:25:21 --> Security Class Initialized
DEBUG - 2024-02-28 01:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:25:21 --> Input Class Initialized
INFO - 2024-02-28 01:25:21 --> Language Class Initialized
INFO - 2024-02-28 01:25:21 --> Loader Class Initialized
INFO - 2024-02-28 01:25:21 --> Helper loaded: url_helper
INFO - 2024-02-28 01:25:21 --> Helper loaded: file_helper
INFO - 2024-02-28 01:25:21 --> Helper loaded: form_helper
INFO - 2024-02-28 01:25:21 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:25:21 --> Controller Class Initialized
INFO - 2024-02-28 01:25:21 --> Form Validation Class Initialized
INFO - 2024-02-28 01:25:21 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:25:21 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:25:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:25:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:25:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:25:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:25:21 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:25:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:25:21 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:25:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:25:22 --> Config Class Initialized
INFO - 2024-02-28 01:25:22 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:25:22 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:25:22 --> Utf8 Class Initialized
INFO - 2024-02-28 01:25:22 --> URI Class Initialized
INFO - 2024-02-28 01:25:22 --> Router Class Initialized
INFO - 2024-02-28 01:25:22 --> Output Class Initialized
INFO - 2024-02-28 01:25:22 --> Security Class Initialized
DEBUG - 2024-02-28 01:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:25:22 --> Input Class Initialized
INFO - 2024-02-28 01:25:22 --> Language Class Initialized
INFO - 2024-02-28 01:25:22 --> Loader Class Initialized
INFO - 2024-02-28 01:25:22 --> Helper loaded: url_helper
INFO - 2024-02-28 01:25:22 --> Helper loaded: file_helper
INFO - 2024-02-28 01:25:22 --> Helper loaded: form_helper
INFO - 2024-02-28 01:25:22 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:25:22 --> Controller Class Initialized
INFO - 2024-02-28 01:25:22 --> Form Validation Class Initialized
INFO - 2024-02-28 01:25:22 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:25:22 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:25:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:25:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:25:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:25:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:25:22 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:25:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:25:22 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:26:01 --> Config Class Initialized
INFO - 2024-02-28 01:26:01 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:26:01 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:26:01 --> Utf8 Class Initialized
INFO - 2024-02-28 01:26:01 --> URI Class Initialized
INFO - 2024-02-28 01:26:01 --> Router Class Initialized
INFO - 2024-02-28 01:26:01 --> Output Class Initialized
INFO - 2024-02-28 01:26:01 --> Security Class Initialized
DEBUG - 2024-02-28 01:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:26:01 --> Input Class Initialized
INFO - 2024-02-28 01:26:01 --> Language Class Initialized
INFO - 2024-02-28 01:26:01 --> Loader Class Initialized
INFO - 2024-02-28 01:26:01 --> Helper loaded: url_helper
INFO - 2024-02-28 01:26:01 --> Helper loaded: file_helper
INFO - 2024-02-28 01:26:01 --> Helper loaded: form_helper
INFO - 2024-02-28 01:26:01 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:26:01 --> Controller Class Initialized
INFO - 2024-02-28 01:26:01 --> Form Validation Class Initialized
INFO - 2024-02-28 01:26:01 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:26:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:26:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:26:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:26:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:26:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:26:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:26:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:26:01 --> Final output sent to browser
DEBUG - 2024-02-28 01:26:01 --> Total execution time: 0.0356
ERROR - 2024-02-28 01:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:26:01 --> Config Class Initialized
INFO - 2024-02-28 01:26:01 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:26:01 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:26:01 --> Utf8 Class Initialized
INFO - 2024-02-28 01:26:01 --> URI Class Initialized
INFO - 2024-02-28 01:26:01 --> Router Class Initialized
INFO - 2024-02-28 01:26:01 --> Output Class Initialized
INFO - 2024-02-28 01:26:01 --> Security Class Initialized
DEBUG - 2024-02-28 01:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:26:01 --> Input Class Initialized
INFO - 2024-02-28 01:26:01 --> Language Class Initialized
INFO - 2024-02-28 01:26:01 --> Loader Class Initialized
INFO - 2024-02-28 01:26:01 --> Helper loaded: url_helper
INFO - 2024-02-28 01:26:01 --> Helper loaded: file_helper
INFO - 2024-02-28 01:26:01 --> Helper loaded: form_helper
INFO - 2024-02-28 01:26:01 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:26:01 --> Controller Class Initialized
INFO - 2024-02-28 01:26:01 --> Form Validation Class Initialized
INFO - 2024-02-28 01:26:01 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:26:01 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:26:17 --> Config Class Initialized
INFO - 2024-02-28 01:26:17 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:26:17 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:26:17 --> Utf8 Class Initialized
INFO - 2024-02-28 01:26:17 --> URI Class Initialized
INFO - 2024-02-28 01:26:17 --> Router Class Initialized
INFO - 2024-02-28 01:26:17 --> Output Class Initialized
INFO - 2024-02-28 01:26:17 --> Security Class Initialized
DEBUG - 2024-02-28 01:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:26:17 --> Input Class Initialized
INFO - 2024-02-28 01:26:17 --> Language Class Initialized
INFO - 2024-02-28 01:26:17 --> Loader Class Initialized
INFO - 2024-02-28 01:26:17 --> Helper loaded: url_helper
INFO - 2024-02-28 01:26:17 --> Helper loaded: file_helper
INFO - 2024-02-28 01:26:17 --> Helper loaded: form_helper
INFO - 2024-02-28 01:26:17 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:26:17 --> Controller Class Initialized
INFO - 2024-02-28 01:26:17 --> Form Validation Class Initialized
INFO - 2024-02-28 01:26:17 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:26:17 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:26:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:26:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:26:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:26:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:26:17 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:26:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:26:17 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:26:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:26:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:26:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:26:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:26:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:26:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:26:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:26:17 --> Final output sent to browser
DEBUG - 2024-02-28 01:26:17 --> Total execution time: 0.0619
ERROR - 2024-02-28 01:26:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:26:18 --> Config Class Initialized
INFO - 2024-02-28 01:26:18 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:26:18 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:26:18 --> Utf8 Class Initialized
INFO - 2024-02-28 01:26:18 --> URI Class Initialized
INFO - 2024-02-28 01:26:18 --> Router Class Initialized
INFO - 2024-02-28 01:26:18 --> Output Class Initialized
INFO - 2024-02-28 01:26:18 --> Security Class Initialized
DEBUG - 2024-02-28 01:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:26:18 --> Input Class Initialized
INFO - 2024-02-28 01:26:18 --> Language Class Initialized
INFO - 2024-02-28 01:26:18 --> Loader Class Initialized
INFO - 2024-02-28 01:26:18 --> Helper loaded: url_helper
INFO - 2024-02-28 01:26:18 --> Helper loaded: file_helper
INFO - 2024-02-28 01:26:18 --> Helper loaded: form_helper
INFO - 2024-02-28 01:26:18 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:26:18 --> Controller Class Initialized
INFO - 2024-02-28 01:26:18 --> Form Validation Class Initialized
INFO - 2024-02-28 01:26:18 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:26:18 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:26:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:26:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:26:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:26:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:26:18 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:26:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:26:18 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:26:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:26:27 --> Config Class Initialized
INFO - 2024-02-28 01:26:27 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:26:27 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:26:27 --> Utf8 Class Initialized
INFO - 2024-02-28 01:26:27 --> URI Class Initialized
INFO - 2024-02-28 01:26:27 --> Router Class Initialized
INFO - 2024-02-28 01:26:27 --> Output Class Initialized
INFO - 2024-02-28 01:26:27 --> Security Class Initialized
DEBUG - 2024-02-28 01:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:26:27 --> Input Class Initialized
INFO - 2024-02-28 01:26:27 --> Language Class Initialized
INFO - 2024-02-28 01:26:27 --> Loader Class Initialized
INFO - 2024-02-28 01:26:27 --> Helper loaded: url_helper
INFO - 2024-02-28 01:26:27 --> Helper loaded: file_helper
INFO - 2024-02-28 01:26:27 --> Helper loaded: form_helper
INFO - 2024-02-28 01:26:27 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:26:27 --> Controller Class Initialized
INFO - 2024-02-28 01:26:27 --> Form Validation Class Initialized
INFO - 2024-02-28 01:26:27 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:26:27 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:26:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:26:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:26:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:26:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:26:27 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:26:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:26:27 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:28:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:28:30 --> Config Class Initialized
INFO - 2024-02-28 01:28:30 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:28:30 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:28:30 --> Utf8 Class Initialized
INFO - 2024-02-28 01:28:30 --> URI Class Initialized
INFO - 2024-02-28 01:28:30 --> Router Class Initialized
INFO - 2024-02-28 01:28:30 --> Output Class Initialized
INFO - 2024-02-28 01:28:30 --> Security Class Initialized
DEBUG - 2024-02-28 01:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:28:30 --> Input Class Initialized
INFO - 2024-02-28 01:28:30 --> Language Class Initialized
INFO - 2024-02-28 01:28:30 --> Loader Class Initialized
INFO - 2024-02-28 01:28:30 --> Helper loaded: url_helper
INFO - 2024-02-28 01:28:30 --> Helper loaded: file_helper
INFO - 2024-02-28 01:28:30 --> Helper loaded: form_helper
INFO - 2024-02-28 01:28:30 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:28:30 --> Controller Class Initialized
INFO - 2024-02-28 01:28:30 --> Form Validation Class Initialized
INFO - 2024-02-28 01:28:30 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:28:30 --> Final output sent to browser
DEBUG - 2024-02-28 01:28:30 --> Total execution time: 0.0301
ERROR - 2024-02-28 01:28:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:28:30 --> Config Class Initialized
INFO - 2024-02-28 01:28:30 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:28:30 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:28:30 --> Utf8 Class Initialized
INFO - 2024-02-28 01:28:30 --> URI Class Initialized
INFO - 2024-02-28 01:28:30 --> Router Class Initialized
INFO - 2024-02-28 01:28:30 --> Output Class Initialized
INFO - 2024-02-28 01:28:30 --> Security Class Initialized
DEBUG - 2024-02-28 01:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:28:30 --> Input Class Initialized
INFO - 2024-02-28 01:28:30 --> Language Class Initialized
INFO - 2024-02-28 01:28:30 --> Loader Class Initialized
INFO - 2024-02-28 01:28:30 --> Helper loaded: url_helper
INFO - 2024-02-28 01:28:30 --> Helper loaded: file_helper
INFO - 2024-02-28 01:28:30 --> Helper loaded: form_helper
INFO - 2024-02-28 01:28:30 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:28:30 --> Controller Class Initialized
INFO - 2024-02-28 01:28:30 --> Form Validation Class Initialized
INFO - 2024-02-28 01:28:30 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:28:30 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:28:34 --> Config Class Initialized
INFO - 2024-02-28 01:28:34 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:28:34 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:28:34 --> Utf8 Class Initialized
INFO - 2024-02-28 01:28:34 --> URI Class Initialized
INFO - 2024-02-28 01:28:34 --> Router Class Initialized
INFO - 2024-02-28 01:28:34 --> Output Class Initialized
INFO - 2024-02-28 01:28:34 --> Security Class Initialized
DEBUG - 2024-02-28 01:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:28:34 --> Input Class Initialized
INFO - 2024-02-28 01:28:34 --> Language Class Initialized
INFO - 2024-02-28 01:28:34 --> Loader Class Initialized
INFO - 2024-02-28 01:28:34 --> Helper loaded: url_helper
INFO - 2024-02-28 01:28:34 --> Helper loaded: file_helper
INFO - 2024-02-28 01:28:34 --> Helper loaded: form_helper
INFO - 2024-02-28 01:28:34 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:28:34 --> Controller Class Initialized
INFO - 2024-02-28 01:28:34 --> Form Validation Class Initialized
INFO - 2024-02-28 01:28:34 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:28:34 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:28:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:28:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:28:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:28:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:28:34 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:28:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:28:34 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:29:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:29:26 --> Config Class Initialized
INFO - 2024-02-28 01:29:26 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:29:26 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:29:26 --> Utf8 Class Initialized
INFO - 2024-02-28 01:29:26 --> URI Class Initialized
INFO - 2024-02-28 01:29:26 --> Router Class Initialized
INFO - 2024-02-28 01:29:26 --> Output Class Initialized
INFO - 2024-02-28 01:29:26 --> Security Class Initialized
DEBUG - 2024-02-28 01:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:29:26 --> Input Class Initialized
INFO - 2024-02-28 01:29:26 --> Language Class Initialized
INFO - 2024-02-28 01:29:26 --> Loader Class Initialized
INFO - 2024-02-28 01:29:26 --> Helper loaded: url_helper
INFO - 2024-02-28 01:29:26 --> Helper loaded: file_helper
INFO - 2024-02-28 01:29:26 --> Helper loaded: form_helper
INFO - 2024-02-28 01:29:26 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:29:26 --> Controller Class Initialized
INFO - 2024-02-28 01:29:26 --> Form Validation Class Initialized
INFO - 2024-02-28 01:29:26 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:29:26 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:29:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:29:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:29:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:29:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:29:26 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:29:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:29:26 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:29:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:29:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:29:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:29:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:29:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:29:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:29:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:29:26 --> Final output sent to browser
DEBUG - 2024-02-28 01:29:26 --> Total execution time: 0.0389
ERROR - 2024-02-28 01:29:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:29:27 --> Config Class Initialized
INFO - 2024-02-28 01:29:27 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:29:27 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:29:27 --> Utf8 Class Initialized
INFO - 2024-02-28 01:29:27 --> URI Class Initialized
INFO - 2024-02-28 01:29:27 --> Router Class Initialized
INFO - 2024-02-28 01:29:27 --> Output Class Initialized
INFO - 2024-02-28 01:29:27 --> Security Class Initialized
DEBUG - 2024-02-28 01:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:29:27 --> Input Class Initialized
INFO - 2024-02-28 01:29:27 --> Language Class Initialized
INFO - 2024-02-28 01:29:27 --> Loader Class Initialized
INFO - 2024-02-28 01:29:27 --> Helper loaded: url_helper
INFO - 2024-02-28 01:29:27 --> Helper loaded: file_helper
INFO - 2024-02-28 01:29:27 --> Helper loaded: form_helper
INFO - 2024-02-28 01:29:27 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:29:27 --> Controller Class Initialized
INFO - 2024-02-28 01:29:27 --> Form Validation Class Initialized
INFO - 2024-02-28 01:29:27 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:29:27 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:29:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:29:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:29:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:29:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:29:27 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:29:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:29:27 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:30:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:30:32 --> Config Class Initialized
INFO - 2024-02-28 01:30:32 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:30:32 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:30:32 --> Utf8 Class Initialized
INFO - 2024-02-28 01:30:32 --> URI Class Initialized
INFO - 2024-02-28 01:30:32 --> Router Class Initialized
INFO - 2024-02-28 01:30:32 --> Output Class Initialized
INFO - 2024-02-28 01:30:32 --> Security Class Initialized
DEBUG - 2024-02-28 01:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:30:32 --> Input Class Initialized
INFO - 2024-02-28 01:30:32 --> Language Class Initialized
INFO - 2024-02-28 01:30:32 --> Loader Class Initialized
INFO - 2024-02-28 01:30:32 --> Helper loaded: url_helper
INFO - 2024-02-28 01:30:32 --> Helper loaded: file_helper
INFO - 2024-02-28 01:30:32 --> Helper loaded: form_helper
INFO - 2024-02-28 01:30:32 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:30:32 --> Controller Class Initialized
INFO - 2024-02-28 01:30:32 --> Form Validation Class Initialized
INFO - 2024-02-28 01:30:32 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:30:32 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:30:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:30:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:30:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:30:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:30:32 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:30:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:30:32 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:30:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:30:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:30:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:30:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:30:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:30:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:30:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:30:32 --> Final output sent to browser
DEBUG - 2024-02-28 01:30:32 --> Total execution time: 0.0606
ERROR - 2024-02-28 01:30:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:30:33 --> Config Class Initialized
INFO - 2024-02-28 01:30:33 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:30:33 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:30:33 --> Utf8 Class Initialized
INFO - 2024-02-28 01:30:33 --> URI Class Initialized
INFO - 2024-02-28 01:30:33 --> Router Class Initialized
INFO - 2024-02-28 01:30:33 --> Output Class Initialized
INFO - 2024-02-28 01:30:33 --> Security Class Initialized
DEBUG - 2024-02-28 01:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:30:33 --> Input Class Initialized
INFO - 2024-02-28 01:30:33 --> Language Class Initialized
INFO - 2024-02-28 01:30:33 --> Loader Class Initialized
INFO - 2024-02-28 01:30:33 --> Helper loaded: url_helper
INFO - 2024-02-28 01:30:33 --> Helper loaded: file_helper
INFO - 2024-02-28 01:30:33 --> Helper loaded: form_helper
INFO - 2024-02-28 01:30:33 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:30:33 --> Controller Class Initialized
INFO - 2024-02-28 01:30:33 --> Form Validation Class Initialized
INFO - 2024-02-28 01:30:33 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:30:33 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:30:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:30:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:30:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:30:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:30:33 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:30:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:30:33 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:30:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(order_transaction.net_amount > 0, `order_transaction`.`c_or_d`, '') as c_or_...' at line 1 - Invalid query: SELECT `order_transaction`.`trans_number`, DATE_FORMAT(order_transaction.trans_date, '%d-%m-%Y') as trans_date, `order_transaction`.`net_amount`, id(order_transaction.net_amount > 0, `order_transaction`.`c_or_d`, '') as c_or_d, ifnull(order_transaction.remark, '') as remark, (CASE WHEN entry_type = 5 THEN 'Order' WHEN entry_type = 6 THEN 'Payment' ELSE '' END) as entry_name
FROM `order_transaction`
WHERE `party_id` = '106'
AND ((entry_type = 5 AND `trans_status` = 2) OR (entry_type = 6))
AND `order_transaction`.`is_delete` = 0
INFO - 2024-02-28 01:30:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-02-28 01:31:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:31:09 --> Config Class Initialized
INFO - 2024-02-28 01:31:09 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:31:09 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:31:09 --> Utf8 Class Initialized
INFO - 2024-02-28 01:31:09 --> URI Class Initialized
INFO - 2024-02-28 01:31:09 --> Router Class Initialized
INFO - 2024-02-28 01:31:09 --> Output Class Initialized
INFO - 2024-02-28 01:31:09 --> Security Class Initialized
DEBUG - 2024-02-28 01:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:31:09 --> Input Class Initialized
INFO - 2024-02-28 01:31:09 --> Language Class Initialized
INFO - 2024-02-28 01:31:09 --> Loader Class Initialized
INFO - 2024-02-28 01:31:09 --> Helper loaded: url_helper
INFO - 2024-02-28 01:31:09 --> Helper loaded: file_helper
INFO - 2024-02-28 01:31:09 --> Helper loaded: form_helper
INFO - 2024-02-28 01:31:09 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:31:09 --> Controller Class Initialized
INFO - 2024-02-28 01:31:09 --> Form Validation Class Initialized
INFO - 2024-02-28 01:31:09 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:31:09 --> Final output sent to browser
DEBUG - 2024-02-28 01:31:09 --> Total execution time: 0.0462
ERROR - 2024-02-28 01:31:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:31:09 --> Config Class Initialized
INFO - 2024-02-28 01:31:09 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:31:09 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:31:09 --> Utf8 Class Initialized
INFO - 2024-02-28 01:31:09 --> URI Class Initialized
INFO - 2024-02-28 01:31:09 --> Router Class Initialized
INFO - 2024-02-28 01:31:09 --> Output Class Initialized
INFO - 2024-02-28 01:31:09 --> Security Class Initialized
DEBUG - 2024-02-28 01:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:31:09 --> Input Class Initialized
INFO - 2024-02-28 01:31:09 --> Language Class Initialized
INFO - 2024-02-28 01:31:09 --> Loader Class Initialized
INFO - 2024-02-28 01:31:09 --> Helper loaded: url_helper
INFO - 2024-02-28 01:31:09 --> Helper loaded: file_helper
INFO - 2024-02-28 01:31:09 --> Helper loaded: form_helper
INFO - 2024-02-28 01:31:09 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:31:09 --> Controller Class Initialized
INFO - 2024-02-28 01:31:09 --> Form Validation Class Initialized
INFO - 2024-02-28 01:31:09 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:31:09 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:31:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(order_transaction.net_amount > 0, `order_transaction`.`c_or_d`, '') as c_or_...' at line 1 - Invalid query: SELECT `order_transaction`.`trans_number`, DATE_FORMAT(order_transaction.trans_date, '%d-%m-%Y') as trans_date, `order_transaction`.`net_amount`, id(order_transaction.net_amount > 0, `order_transaction`.`c_or_d`, '') as c_or_d, ifnull(order_transaction.remark, '') as remark, (CASE WHEN entry_type = 5 THEN 'Order' WHEN entry_type = 6 THEN 'Payment' ELSE '' END) as entry_name
FROM `order_transaction`
WHERE `party_id` = '106'
AND ((entry_type = 5 AND `trans_status` = 2) OR (entry_type = 6))
AND `order_transaction`.`is_delete` = 0
INFO - 2024-02-28 01:31:09 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-02-28 01:31:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:31:19 --> Config Class Initialized
INFO - 2024-02-28 01:31:19 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:31:19 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:31:19 --> Utf8 Class Initialized
INFO - 2024-02-28 01:31:19 --> URI Class Initialized
INFO - 2024-02-28 01:31:19 --> Router Class Initialized
INFO - 2024-02-28 01:31:19 --> Output Class Initialized
INFO - 2024-02-28 01:31:19 --> Security Class Initialized
DEBUG - 2024-02-28 01:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:31:19 --> Input Class Initialized
INFO - 2024-02-28 01:31:19 --> Language Class Initialized
INFO - 2024-02-28 01:31:19 --> Loader Class Initialized
INFO - 2024-02-28 01:31:19 --> Helper loaded: url_helper
INFO - 2024-02-28 01:31:19 --> Helper loaded: file_helper
INFO - 2024-02-28 01:31:19 --> Helper loaded: form_helper
INFO - 2024-02-28 01:31:19 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:31:19 --> Controller Class Initialized
INFO - 2024-02-28 01:31:19 --> Form Validation Class Initialized
INFO - 2024-02-28 01:31:19 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:31:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:31:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:31:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:31:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:31:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:31:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:31:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:31:19 --> Final output sent to browser
DEBUG - 2024-02-28 01:31:19 --> Total execution time: 0.0665
ERROR - 2024-02-28 01:31:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:31:19 --> Config Class Initialized
INFO - 2024-02-28 01:31:19 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:31:19 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:31:19 --> Utf8 Class Initialized
INFO - 2024-02-28 01:31:19 --> URI Class Initialized
INFO - 2024-02-28 01:31:19 --> Router Class Initialized
INFO - 2024-02-28 01:31:19 --> Output Class Initialized
INFO - 2024-02-28 01:31:19 --> Security Class Initialized
DEBUG - 2024-02-28 01:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:31:19 --> Input Class Initialized
INFO - 2024-02-28 01:31:19 --> Language Class Initialized
INFO - 2024-02-28 01:31:19 --> Loader Class Initialized
INFO - 2024-02-28 01:31:19 --> Helper loaded: url_helper
INFO - 2024-02-28 01:31:19 --> Helper loaded: file_helper
INFO - 2024-02-28 01:31:19 --> Helper loaded: form_helper
INFO - 2024-02-28 01:31:19 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:31:19 --> Controller Class Initialized
INFO - 2024-02-28 01:31:19 --> Form Validation Class Initialized
INFO - 2024-02-28 01:31:19 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:31:19 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:31:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:31:24 --> Config Class Initialized
INFO - 2024-02-28 01:31:24 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:31:24 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:31:24 --> Utf8 Class Initialized
INFO - 2024-02-28 01:31:24 --> URI Class Initialized
INFO - 2024-02-28 01:31:24 --> Router Class Initialized
INFO - 2024-02-28 01:31:24 --> Output Class Initialized
INFO - 2024-02-28 01:31:24 --> Security Class Initialized
DEBUG - 2024-02-28 01:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:31:24 --> Input Class Initialized
INFO - 2024-02-28 01:31:24 --> Language Class Initialized
INFO - 2024-02-28 01:31:24 --> Loader Class Initialized
INFO - 2024-02-28 01:31:24 --> Helper loaded: url_helper
INFO - 2024-02-28 01:31:24 --> Helper loaded: file_helper
INFO - 2024-02-28 01:31:24 --> Helper loaded: form_helper
INFO - 2024-02-28 01:31:24 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:31:24 --> Controller Class Initialized
INFO - 2024-02-28 01:31:24 --> Form Validation Class Initialized
INFO - 2024-02-28 01:31:24 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:31:24 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:31:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:31:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:31:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:31:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:31:24 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:31:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:31:24 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:31:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:31:28 --> Config Class Initialized
INFO - 2024-02-28 01:31:28 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:31:28 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:31:28 --> Utf8 Class Initialized
INFO - 2024-02-28 01:31:28 --> URI Class Initialized
INFO - 2024-02-28 01:31:28 --> Router Class Initialized
INFO - 2024-02-28 01:31:28 --> Output Class Initialized
INFO - 2024-02-28 01:31:28 --> Security Class Initialized
DEBUG - 2024-02-28 01:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:31:28 --> Input Class Initialized
INFO - 2024-02-28 01:31:28 --> Language Class Initialized
INFO - 2024-02-28 01:31:28 --> Loader Class Initialized
INFO - 2024-02-28 01:31:28 --> Helper loaded: url_helper
INFO - 2024-02-28 01:31:28 --> Helper loaded: file_helper
INFO - 2024-02-28 01:31:28 --> Helper loaded: form_helper
INFO - 2024-02-28 01:31:28 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:31:28 --> Controller Class Initialized
INFO - 2024-02-28 01:31:28 --> Form Validation Class Initialized
INFO - 2024-02-28 01:31:28 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:31:28 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:31:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:31:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:31:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:31:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:31:28 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:31:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:31:28 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:31:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:31:31 --> Config Class Initialized
INFO - 2024-02-28 01:31:31 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:31:31 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:31:31 --> Utf8 Class Initialized
INFO - 2024-02-28 01:31:31 --> URI Class Initialized
INFO - 2024-02-28 01:31:31 --> Router Class Initialized
INFO - 2024-02-28 01:31:31 --> Output Class Initialized
INFO - 2024-02-28 01:31:31 --> Security Class Initialized
DEBUG - 2024-02-28 01:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:31:31 --> Input Class Initialized
INFO - 2024-02-28 01:31:31 --> Language Class Initialized
INFO - 2024-02-28 01:31:31 --> Loader Class Initialized
INFO - 2024-02-28 01:31:31 --> Helper loaded: url_helper
INFO - 2024-02-28 01:31:31 --> Helper loaded: file_helper
INFO - 2024-02-28 01:31:31 --> Helper loaded: form_helper
INFO - 2024-02-28 01:31:31 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:31:31 --> Controller Class Initialized
INFO - 2024-02-28 01:31:31 --> Form Validation Class Initialized
INFO - 2024-02-28 01:31:31 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:31:31 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:31:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:31:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:31:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:31:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:31:31 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:31:31 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:31:31 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:31:55 --> Config Class Initialized
INFO - 2024-02-28 01:31:55 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:31:55 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:31:55 --> Utf8 Class Initialized
INFO - 2024-02-28 01:31:55 --> URI Class Initialized
INFO - 2024-02-28 01:31:55 --> Router Class Initialized
INFO - 2024-02-28 01:31:55 --> Output Class Initialized
INFO - 2024-02-28 01:31:55 --> Security Class Initialized
DEBUG - 2024-02-28 01:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:31:55 --> Input Class Initialized
INFO - 2024-02-28 01:31:55 --> Language Class Initialized
INFO - 2024-02-28 01:31:55 --> Loader Class Initialized
INFO - 2024-02-28 01:31:55 --> Helper loaded: url_helper
INFO - 2024-02-28 01:31:55 --> Helper loaded: file_helper
INFO - 2024-02-28 01:31:55 --> Helper loaded: form_helper
INFO - 2024-02-28 01:31:55 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:31:55 --> Controller Class Initialized
INFO - 2024-02-28 01:31:55 --> Form Validation Class Initialized
INFO - 2024-02-28 01:31:55 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:31:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:31:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:31:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:31:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:31:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:31:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:31:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:31:55 --> Final output sent to browser
DEBUG - 2024-02-28 01:31:55 --> Total execution time: 0.0724
ERROR - 2024-02-28 01:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:31:55 --> Config Class Initialized
INFO - 2024-02-28 01:31:55 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:31:55 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:31:55 --> Utf8 Class Initialized
INFO - 2024-02-28 01:31:55 --> URI Class Initialized
INFO - 2024-02-28 01:31:55 --> Router Class Initialized
INFO - 2024-02-28 01:31:55 --> Output Class Initialized
INFO - 2024-02-28 01:31:55 --> Security Class Initialized
DEBUG - 2024-02-28 01:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:31:55 --> Input Class Initialized
INFO - 2024-02-28 01:31:55 --> Language Class Initialized
INFO - 2024-02-28 01:31:55 --> Loader Class Initialized
INFO - 2024-02-28 01:31:55 --> Helper loaded: url_helper
INFO - 2024-02-28 01:31:55 --> Helper loaded: file_helper
INFO - 2024-02-28 01:31:55 --> Helper loaded: form_helper
INFO - 2024-02-28 01:31:55 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:31:55 --> Controller Class Initialized
INFO - 2024-02-28 01:31:55 --> Form Validation Class Initialized
INFO - 2024-02-28 01:31:55 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:31:55 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:32:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:32:13 --> Config Class Initialized
INFO - 2024-02-28 01:32:13 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:32:13 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:32:13 --> Utf8 Class Initialized
INFO - 2024-02-28 01:32:13 --> URI Class Initialized
INFO - 2024-02-28 01:32:13 --> Router Class Initialized
INFO - 2024-02-28 01:32:13 --> Output Class Initialized
INFO - 2024-02-28 01:32:13 --> Security Class Initialized
DEBUG - 2024-02-28 01:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:32:13 --> Input Class Initialized
INFO - 2024-02-28 01:32:13 --> Language Class Initialized
INFO - 2024-02-28 01:32:13 --> Loader Class Initialized
INFO - 2024-02-28 01:32:13 --> Helper loaded: url_helper
INFO - 2024-02-28 01:32:13 --> Helper loaded: file_helper
INFO - 2024-02-28 01:32:13 --> Helper loaded: form_helper
INFO - 2024-02-28 01:32:13 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:32:13 --> Controller Class Initialized
INFO - 2024-02-28 01:32:13 --> Form Validation Class Initialized
INFO - 2024-02-28 01:32:13 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:32:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:32:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:32:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:32:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:32:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:32:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:32:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:32:13 --> Final output sent to browser
DEBUG - 2024-02-28 01:32:13 --> Total execution time: 0.0720
ERROR - 2024-02-28 01:32:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:32:13 --> Config Class Initialized
INFO - 2024-02-28 01:32:13 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:32:13 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:32:13 --> Utf8 Class Initialized
INFO - 2024-02-28 01:32:13 --> URI Class Initialized
INFO - 2024-02-28 01:32:13 --> Router Class Initialized
INFO - 2024-02-28 01:32:13 --> Output Class Initialized
INFO - 2024-02-28 01:32:13 --> Security Class Initialized
DEBUG - 2024-02-28 01:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:32:13 --> Input Class Initialized
INFO - 2024-02-28 01:32:13 --> Language Class Initialized
INFO - 2024-02-28 01:32:13 --> Loader Class Initialized
INFO - 2024-02-28 01:32:13 --> Helper loaded: url_helper
INFO - 2024-02-28 01:32:13 --> Helper loaded: file_helper
INFO - 2024-02-28 01:32:13 --> Helper loaded: form_helper
INFO - 2024-02-28 01:32:13 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:32:13 --> Controller Class Initialized
INFO - 2024-02-28 01:32:13 --> Form Validation Class Initialized
INFO - 2024-02-28 01:32:13 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:32:13 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:32:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:32:18 --> Config Class Initialized
INFO - 2024-02-28 01:32:18 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:32:18 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:32:18 --> Utf8 Class Initialized
INFO - 2024-02-28 01:32:18 --> URI Class Initialized
INFO - 2024-02-28 01:32:18 --> Router Class Initialized
INFO - 2024-02-28 01:32:18 --> Output Class Initialized
INFO - 2024-02-28 01:32:18 --> Security Class Initialized
DEBUG - 2024-02-28 01:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:32:18 --> Input Class Initialized
INFO - 2024-02-28 01:32:18 --> Language Class Initialized
INFO - 2024-02-28 01:32:18 --> Loader Class Initialized
INFO - 2024-02-28 01:32:18 --> Helper loaded: url_helper
INFO - 2024-02-28 01:32:18 --> Helper loaded: file_helper
INFO - 2024-02-28 01:32:18 --> Helper loaded: form_helper
INFO - 2024-02-28 01:32:18 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:32:18 --> Controller Class Initialized
INFO - 2024-02-28 01:32:18 --> Form Validation Class Initialized
INFO - 2024-02-28 01:32:18 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:32:18 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:32:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:32:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:32:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:32:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:32:18 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:32:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:32:18 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:32:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:32:33 --> Config Class Initialized
INFO - 2024-02-28 01:32:33 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:32:33 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:32:33 --> Utf8 Class Initialized
INFO - 2024-02-28 01:32:33 --> URI Class Initialized
INFO - 2024-02-28 01:32:33 --> Router Class Initialized
INFO - 2024-02-28 01:32:33 --> Output Class Initialized
INFO - 2024-02-28 01:32:33 --> Security Class Initialized
DEBUG - 2024-02-28 01:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:32:33 --> Input Class Initialized
INFO - 2024-02-28 01:32:33 --> Language Class Initialized
INFO - 2024-02-28 01:32:33 --> Loader Class Initialized
INFO - 2024-02-28 01:32:33 --> Helper loaded: url_helper
INFO - 2024-02-28 01:32:33 --> Helper loaded: file_helper
INFO - 2024-02-28 01:32:33 --> Helper loaded: form_helper
INFO - 2024-02-28 01:32:33 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:32:33 --> Controller Class Initialized
INFO - 2024-02-28 01:32:33 --> Form Validation Class Initialized
INFO - 2024-02-28 01:32:33 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:32:33 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:32:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:32:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:32:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:32:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:32:33 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:32:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:32:33 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:32:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:32:36 --> Config Class Initialized
INFO - 2024-02-28 01:32:36 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:32:36 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:32:36 --> Utf8 Class Initialized
INFO - 2024-02-28 01:32:36 --> URI Class Initialized
INFO - 2024-02-28 01:32:36 --> Router Class Initialized
INFO - 2024-02-28 01:32:36 --> Output Class Initialized
INFO - 2024-02-28 01:32:36 --> Security Class Initialized
DEBUG - 2024-02-28 01:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:32:36 --> Input Class Initialized
INFO - 2024-02-28 01:32:36 --> Language Class Initialized
INFO - 2024-02-28 01:32:36 --> Loader Class Initialized
INFO - 2024-02-28 01:32:36 --> Helper loaded: url_helper
INFO - 2024-02-28 01:32:36 --> Helper loaded: file_helper
INFO - 2024-02-28 01:32:36 --> Helper loaded: form_helper
INFO - 2024-02-28 01:32:36 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:32:36 --> Controller Class Initialized
INFO - 2024-02-28 01:32:36 --> Form Validation Class Initialized
INFO - 2024-02-28 01:32:36 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:32:36 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:32:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:32:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:32:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:32:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:32:36 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:32:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:32:36 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:32:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:32:42 --> Config Class Initialized
INFO - 2024-02-28 01:32:42 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:32:42 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:32:42 --> Utf8 Class Initialized
INFO - 2024-02-28 01:32:42 --> URI Class Initialized
INFO - 2024-02-28 01:32:42 --> Router Class Initialized
INFO - 2024-02-28 01:32:42 --> Output Class Initialized
INFO - 2024-02-28 01:32:42 --> Security Class Initialized
DEBUG - 2024-02-28 01:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:32:42 --> Input Class Initialized
INFO - 2024-02-28 01:32:42 --> Language Class Initialized
INFO - 2024-02-28 01:32:42 --> Loader Class Initialized
INFO - 2024-02-28 01:32:42 --> Helper loaded: url_helper
INFO - 2024-02-28 01:32:42 --> Helper loaded: file_helper
INFO - 2024-02-28 01:32:42 --> Helper loaded: form_helper
INFO - 2024-02-28 01:32:42 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:32:42 --> Controller Class Initialized
INFO - 2024-02-28 01:32:42 --> Form Validation Class Initialized
INFO - 2024-02-28 01:32:42 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:32:42 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:32:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:32:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:32:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:32:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:32:42 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:32:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:32:42 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:32:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:32:45 --> Config Class Initialized
INFO - 2024-02-28 01:32:45 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:32:45 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:32:45 --> Utf8 Class Initialized
INFO - 2024-02-28 01:32:45 --> URI Class Initialized
INFO - 2024-02-28 01:32:45 --> Router Class Initialized
INFO - 2024-02-28 01:32:45 --> Output Class Initialized
INFO - 2024-02-28 01:32:45 --> Security Class Initialized
DEBUG - 2024-02-28 01:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:32:45 --> Input Class Initialized
INFO - 2024-02-28 01:32:45 --> Language Class Initialized
INFO - 2024-02-28 01:32:45 --> Loader Class Initialized
INFO - 2024-02-28 01:32:45 --> Helper loaded: url_helper
INFO - 2024-02-28 01:32:45 --> Helper loaded: file_helper
INFO - 2024-02-28 01:32:45 --> Helper loaded: form_helper
INFO - 2024-02-28 01:32:45 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:32:45 --> Controller Class Initialized
INFO - 2024-02-28 01:32:45 --> Form Validation Class Initialized
INFO - 2024-02-28 01:32:45 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:32:45 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:32:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:32:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:32:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:32:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:32:45 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:32:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:32:45 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:32:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:32:53 --> Config Class Initialized
INFO - 2024-02-28 01:32:53 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:32:53 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:32:53 --> Utf8 Class Initialized
INFO - 2024-02-28 01:32:53 --> URI Class Initialized
INFO - 2024-02-28 01:32:53 --> Router Class Initialized
INFO - 2024-02-28 01:32:53 --> Output Class Initialized
INFO - 2024-02-28 01:32:53 --> Security Class Initialized
DEBUG - 2024-02-28 01:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:32:53 --> Input Class Initialized
INFO - 2024-02-28 01:32:53 --> Language Class Initialized
INFO - 2024-02-28 01:32:53 --> Loader Class Initialized
INFO - 2024-02-28 01:32:53 --> Helper loaded: url_helper
INFO - 2024-02-28 01:32:53 --> Helper loaded: file_helper
INFO - 2024-02-28 01:32:53 --> Helper loaded: form_helper
INFO - 2024-02-28 01:32:53 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:32:53 --> Controller Class Initialized
INFO - 2024-02-28 01:32:53 --> Form Validation Class Initialized
INFO - 2024-02-28 01:32:53 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:32:53 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:32:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:32:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:32:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:32:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:32:53 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:32:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:32:53 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:32:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:32:59 --> Config Class Initialized
INFO - 2024-02-28 01:32:59 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:32:59 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:32:59 --> Utf8 Class Initialized
INFO - 2024-02-28 01:32:59 --> URI Class Initialized
INFO - 2024-02-28 01:32:59 --> Router Class Initialized
INFO - 2024-02-28 01:32:59 --> Output Class Initialized
INFO - 2024-02-28 01:32:59 --> Security Class Initialized
DEBUG - 2024-02-28 01:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:32:59 --> Input Class Initialized
INFO - 2024-02-28 01:32:59 --> Language Class Initialized
INFO - 2024-02-28 01:32:59 --> Loader Class Initialized
INFO - 2024-02-28 01:32:59 --> Helper loaded: url_helper
INFO - 2024-02-28 01:32:59 --> Helper loaded: file_helper
INFO - 2024-02-28 01:32:59 --> Helper loaded: form_helper
INFO - 2024-02-28 01:32:59 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:32:59 --> Controller Class Initialized
INFO - 2024-02-28 01:32:59 --> Form Validation Class Initialized
INFO - 2024-02-28 01:32:59 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:32:59 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:32:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:32:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:32:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:32:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:32:59 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:32:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:32:59 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:33:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:33:24 --> Config Class Initialized
INFO - 2024-02-28 01:33:24 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:33:24 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:33:24 --> Utf8 Class Initialized
INFO - 2024-02-28 01:33:24 --> URI Class Initialized
INFO - 2024-02-28 01:33:24 --> Router Class Initialized
INFO - 2024-02-28 01:33:24 --> Output Class Initialized
INFO - 2024-02-28 01:33:24 --> Security Class Initialized
DEBUG - 2024-02-28 01:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:33:24 --> Input Class Initialized
INFO - 2024-02-28 01:33:24 --> Language Class Initialized
INFO - 2024-02-28 01:33:24 --> Loader Class Initialized
INFO - 2024-02-28 01:33:24 --> Helper loaded: url_helper
INFO - 2024-02-28 01:33:24 --> Helper loaded: file_helper
INFO - 2024-02-28 01:33:24 --> Helper loaded: form_helper
INFO - 2024-02-28 01:33:24 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:33:24 --> Controller Class Initialized
INFO - 2024-02-28 01:33:24 --> Form Validation Class Initialized
INFO - 2024-02-28 01:33:24 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:33:24 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:33:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:33:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:33:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:33:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:33:24 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:33:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:33:24 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:33:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:33:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:33:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:33:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:33:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:33:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:33:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:33:24 --> Final output sent to browser
DEBUG - 2024-02-28 01:33:24 --> Total execution time: 0.0592
ERROR - 2024-02-28 01:33:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:33:25 --> Config Class Initialized
INFO - 2024-02-28 01:33:25 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:33:25 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:33:25 --> Utf8 Class Initialized
INFO - 2024-02-28 01:33:25 --> URI Class Initialized
INFO - 2024-02-28 01:33:25 --> Router Class Initialized
INFO - 2024-02-28 01:33:25 --> Output Class Initialized
INFO - 2024-02-28 01:33:25 --> Security Class Initialized
DEBUG - 2024-02-28 01:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:33:25 --> Input Class Initialized
INFO - 2024-02-28 01:33:25 --> Language Class Initialized
INFO - 2024-02-28 01:33:25 --> Loader Class Initialized
INFO - 2024-02-28 01:33:25 --> Helper loaded: url_helper
INFO - 2024-02-28 01:33:25 --> Helper loaded: file_helper
INFO - 2024-02-28 01:33:25 --> Helper loaded: form_helper
INFO - 2024-02-28 01:33:25 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:33:25 --> Controller Class Initialized
INFO - 2024-02-28 01:33:25 --> Form Validation Class Initialized
INFO - 2024-02-28 01:33:25 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:33:25 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:33:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:33:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:33:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:33:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:33:25 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:33:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:33:25 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:33:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:33:34 --> Config Class Initialized
INFO - 2024-02-28 01:33:34 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:33:34 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:33:34 --> Utf8 Class Initialized
INFO - 2024-02-28 01:33:34 --> URI Class Initialized
INFO - 2024-02-28 01:33:34 --> Router Class Initialized
INFO - 2024-02-28 01:33:34 --> Output Class Initialized
INFO - 2024-02-28 01:33:34 --> Security Class Initialized
DEBUG - 2024-02-28 01:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:33:34 --> Input Class Initialized
INFO - 2024-02-28 01:33:34 --> Language Class Initialized
INFO - 2024-02-28 01:33:34 --> Loader Class Initialized
INFO - 2024-02-28 01:33:34 --> Helper loaded: url_helper
INFO - 2024-02-28 01:33:34 --> Helper loaded: file_helper
INFO - 2024-02-28 01:33:34 --> Helper loaded: form_helper
INFO - 2024-02-28 01:33:34 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:33:34 --> Controller Class Initialized
INFO - 2024-02-28 01:33:34 --> Form Validation Class Initialized
INFO - 2024-02-28 01:33:34 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:33:34 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:33:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:33:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:33:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:33:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:33:34 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:33:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:33:34 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:33:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:33:37 --> Config Class Initialized
INFO - 2024-02-28 01:33:37 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:33:37 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:33:37 --> Utf8 Class Initialized
INFO - 2024-02-28 01:33:37 --> URI Class Initialized
INFO - 2024-02-28 01:33:37 --> Router Class Initialized
INFO - 2024-02-28 01:33:37 --> Output Class Initialized
INFO - 2024-02-28 01:33:37 --> Security Class Initialized
DEBUG - 2024-02-28 01:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:33:37 --> Input Class Initialized
INFO - 2024-02-28 01:33:37 --> Language Class Initialized
INFO - 2024-02-28 01:33:37 --> Loader Class Initialized
INFO - 2024-02-28 01:33:38 --> Helper loaded: url_helper
INFO - 2024-02-28 01:33:38 --> Helper loaded: file_helper
INFO - 2024-02-28 01:33:38 --> Helper loaded: form_helper
INFO - 2024-02-28 01:33:38 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:33:38 --> Controller Class Initialized
INFO - 2024-02-28 01:33:38 --> Form Validation Class Initialized
INFO - 2024-02-28 01:33:38 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:33:38 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:33:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:33:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:33:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:33:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:33:38 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:33:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:33:38 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:33:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:33:45 --> Config Class Initialized
INFO - 2024-02-28 01:33:45 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:33:45 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:33:45 --> Utf8 Class Initialized
INFO - 2024-02-28 01:33:45 --> URI Class Initialized
INFO - 2024-02-28 01:33:45 --> Router Class Initialized
INFO - 2024-02-28 01:33:45 --> Output Class Initialized
INFO - 2024-02-28 01:33:45 --> Security Class Initialized
DEBUG - 2024-02-28 01:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:33:45 --> Input Class Initialized
INFO - 2024-02-28 01:33:45 --> Language Class Initialized
INFO - 2024-02-28 01:33:45 --> Loader Class Initialized
INFO - 2024-02-28 01:33:45 --> Helper loaded: url_helper
INFO - 2024-02-28 01:33:45 --> Helper loaded: file_helper
INFO - 2024-02-28 01:33:45 --> Helper loaded: form_helper
INFO - 2024-02-28 01:33:45 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:33:45 --> Controller Class Initialized
INFO - 2024-02-28 01:33:45 --> Form Validation Class Initialized
INFO - 2024-02-28 01:33:45 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:33:45 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:33:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:33:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:33:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:33:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:33:45 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:33:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:33:45 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:34:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:34:02 --> Config Class Initialized
INFO - 2024-02-28 01:34:02 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:34:02 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:34:02 --> Utf8 Class Initialized
INFO - 2024-02-28 01:34:02 --> URI Class Initialized
INFO - 2024-02-28 01:34:02 --> Router Class Initialized
INFO - 2024-02-28 01:34:02 --> Output Class Initialized
INFO - 2024-02-28 01:34:02 --> Security Class Initialized
DEBUG - 2024-02-28 01:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:34:02 --> Input Class Initialized
INFO - 2024-02-28 01:34:02 --> Language Class Initialized
INFO - 2024-02-28 01:34:02 --> Loader Class Initialized
INFO - 2024-02-28 01:34:02 --> Helper loaded: url_helper
INFO - 2024-02-28 01:34:02 --> Helper loaded: file_helper
INFO - 2024-02-28 01:34:02 --> Helper loaded: form_helper
INFO - 2024-02-28 01:34:02 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:34:02 --> Controller Class Initialized
INFO - 2024-02-28 01:34:02 --> Form Validation Class Initialized
INFO - 2024-02-28 01:34:02 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:34:02 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:34:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:34:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:34:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:34:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:34:02 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:34:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:34:02 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:34:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:34:09 --> Config Class Initialized
INFO - 2024-02-28 01:34:09 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:34:09 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:34:09 --> Utf8 Class Initialized
INFO - 2024-02-28 01:34:09 --> URI Class Initialized
INFO - 2024-02-28 01:34:09 --> Router Class Initialized
INFO - 2024-02-28 01:34:09 --> Output Class Initialized
INFO - 2024-02-28 01:34:10 --> Security Class Initialized
DEBUG - 2024-02-28 01:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:34:10 --> Input Class Initialized
INFO - 2024-02-28 01:34:10 --> Language Class Initialized
INFO - 2024-02-28 01:34:10 --> Loader Class Initialized
INFO - 2024-02-28 01:34:10 --> Helper loaded: url_helper
INFO - 2024-02-28 01:34:10 --> Helper loaded: file_helper
INFO - 2024-02-28 01:34:10 --> Helper loaded: form_helper
INFO - 2024-02-28 01:34:10 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:34:10 --> Controller Class Initialized
INFO - 2024-02-28 01:34:10 --> Form Validation Class Initialized
INFO - 2024-02-28 01:34:10 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:34:10 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:34:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:34:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:34:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:34:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:34:10 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:34:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:34:10 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:34:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:34:13 --> Config Class Initialized
INFO - 2024-02-28 01:34:13 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:34:13 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:34:13 --> Utf8 Class Initialized
INFO - 2024-02-28 01:34:13 --> URI Class Initialized
INFO - 2024-02-28 01:34:13 --> Router Class Initialized
INFO - 2024-02-28 01:34:13 --> Output Class Initialized
INFO - 2024-02-28 01:34:13 --> Security Class Initialized
DEBUG - 2024-02-28 01:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:34:13 --> Input Class Initialized
INFO - 2024-02-28 01:34:13 --> Language Class Initialized
INFO - 2024-02-28 01:34:13 --> Loader Class Initialized
INFO - 2024-02-28 01:34:13 --> Helper loaded: url_helper
INFO - 2024-02-28 01:34:13 --> Helper loaded: file_helper
INFO - 2024-02-28 01:34:13 --> Helper loaded: form_helper
INFO - 2024-02-28 01:34:13 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:34:13 --> Controller Class Initialized
INFO - 2024-02-28 01:34:13 --> Form Validation Class Initialized
INFO - 2024-02-28 01:34:13 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:34:13 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:34:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:34:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:34:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:34:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:34:13 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:34:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:34:13 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:34:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:34:16 --> Config Class Initialized
INFO - 2024-02-28 01:34:16 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:34:16 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:34:16 --> Utf8 Class Initialized
INFO - 2024-02-28 01:34:16 --> URI Class Initialized
INFO - 2024-02-28 01:34:16 --> Router Class Initialized
INFO - 2024-02-28 01:34:16 --> Output Class Initialized
INFO - 2024-02-28 01:34:16 --> Security Class Initialized
DEBUG - 2024-02-28 01:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:34:16 --> Input Class Initialized
INFO - 2024-02-28 01:34:16 --> Language Class Initialized
INFO - 2024-02-28 01:34:16 --> Loader Class Initialized
INFO - 2024-02-28 01:34:16 --> Helper loaded: url_helper
INFO - 2024-02-28 01:34:16 --> Helper loaded: file_helper
INFO - 2024-02-28 01:34:16 --> Helper loaded: form_helper
INFO - 2024-02-28 01:34:16 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:34:16 --> Controller Class Initialized
INFO - 2024-02-28 01:34:16 --> Form Validation Class Initialized
INFO - 2024-02-28 01:34:16 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:34:16 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:34:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:34:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:34:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:34:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:34:16 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:34:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:34:16 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:34:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:34:21 --> Config Class Initialized
INFO - 2024-02-28 01:34:21 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:34:21 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:34:21 --> Utf8 Class Initialized
INFO - 2024-02-28 01:34:21 --> URI Class Initialized
INFO - 2024-02-28 01:34:21 --> Router Class Initialized
INFO - 2024-02-28 01:34:21 --> Output Class Initialized
INFO - 2024-02-28 01:34:21 --> Security Class Initialized
DEBUG - 2024-02-28 01:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:34:21 --> Input Class Initialized
INFO - 2024-02-28 01:34:21 --> Language Class Initialized
INFO - 2024-02-28 01:34:21 --> Loader Class Initialized
INFO - 2024-02-28 01:34:21 --> Helper loaded: url_helper
INFO - 2024-02-28 01:34:21 --> Helper loaded: file_helper
INFO - 2024-02-28 01:34:21 --> Helper loaded: form_helper
INFO - 2024-02-28 01:34:21 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:34:21 --> Controller Class Initialized
INFO - 2024-02-28 01:34:21 --> Form Validation Class Initialized
INFO - 2024-02-28 01:34:21 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:34:21 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:34:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:34:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:34:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:34:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:34:21 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:34:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:34:21 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:35:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:35:21 --> Config Class Initialized
INFO - 2024-02-28 01:35:21 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:35:21 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:35:21 --> Utf8 Class Initialized
INFO - 2024-02-28 01:35:21 --> URI Class Initialized
INFO - 2024-02-28 01:35:21 --> Router Class Initialized
INFO - 2024-02-28 01:35:21 --> Output Class Initialized
INFO - 2024-02-28 01:35:21 --> Security Class Initialized
DEBUG - 2024-02-28 01:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:35:21 --> Input Class Initialized
INFO - 2024-02-28 01:35:21 --> Language Class Initialized
INFO - 2024-02-28 01:35:21 --> Loader Class Initialized
INFO - 2024-02-28 01:35:21 --> Helper loaded: url_helper
INFO - 2024-02-28 01:35:21 --> Helper loaded: file_helper
INFO - 2024-02-28 01:35:21 --> Helper loaded: form_helper
INFO - 2024-02-28 01:35:21 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:35:21 --> Controller Class Initialized
INFO - 2024-02-28 01:35:21 --> Form Validation Class Initialized
INFO - 2024-02-28 01:35:21 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:35:21 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:35:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:35:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:35:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:35:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:35:21 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:35:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:35:21 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:35:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:35:28 --> Config Class Initialized
INFO - 2024-02-28 01:35:28 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:35:28 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:35:28 --> Utf8 Class Initialized
INFO - 2024-02-28 01:35:28 --> URI Class Initialized
INFO - 2024-02-28 01:35:28 --> Router Class Initialized
INFO - 2024-02-28 01:35:28 --> Output Class Initialized
INFO - 2024-02-28 01:35:28 --> Security Class Initialized
DEBUG - 2024-02-28 01:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:35:28 --> Input Class Initialized
INFO - 2024-02-28 01:35:28 --> Language Class Initialized
INFO - 2024-02-28 01:35:28 --> Loader Class Initialized
INFO - 2024-02-28 01:35:28 --> Helper loaded: url_helper
INFO - 2024-02-28 01:35:28 --> Helper loaded: file_helper
INFO - 2024-02-28 01:35:28 --> Helper loaded: form_helper
INFO - 2024-02-28 01:35:28 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:35:28 --> Controller Class Initialized
INFO - 2024-02-28 01:35:28 --> Form Validation Class Initialized
INFO - 2024-02-28 01:35:28 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:35:28 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:35:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:35:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:35:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:35:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:35:28 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:35:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:35:28 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:35:49 --> Config Class Initialized
INFO - 2024-02-28 01:35:49 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:35:49 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:35:49 --> Utf8 Class Initialized
INFO - 2024-02-28 01:35:49 --> URI Class Initialized
INFO - 2024-02-28 01:35:49 --> Router Class Initialized
INFO - 2024-02-28 01:35:49 --> Output Class Initialized
INFO - 2024-02-28 01:35:49 --> Security Class Initialized
DEBUG - 2024-02-28 01:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:35:49 --> Input Class Initialized
INFO - 2024-02-28 01:35:49 --> Language Class Initialized
INFO - 2024-02-28 01:35:49 --> Loader Class Initialized
INFO - 2024-02-28 01:35:49 --> Helper loaded: url_helper
INFO - 2024-02-28 01:35:49 --> Helper loaded: file_helper
INFO - 2024-02-28 01:35:49 --> Helper loaded: form_helper
INFO - 2024-02-28 01:35:49 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:35:49 --> Controller Class Initialized
INFO - 2024-02-28 01:35:49 --> Form Validation Class Initialized
INFO - 2024-02-28 01:35:49 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:35:49 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:35:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:35:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:35:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:35:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:35:49 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:35:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:35:49 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:36:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:36:09 --> Config Class Initialized
INFO - 2024-02-28 01:36:09 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:36:09 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:36:09 --> Utf8 Class Initialized
INFO - 2024-02-28 01:36:09 --> URI Class Initialized
INFO - 2024-02-28 01:36:09 --> Router Class Initialized
INFO - 2024-02-28 01:36:09 --> Output Class Initialized
INFO - 2024-02-28 01:36:09 --> Security Class Initialized
DEBUG - 2024-02-28 01:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:36:09 --> Input Class Initialized
INFO - 2024-02-28 01:36:09 --> Language Class Initialized
INFO - 2024-02-28 01:36:09 --> Loader Class Initialized
INFO - 2024-02-28 01:36:09 --> Helper loaded: url_helper
INFO - 2024-02-28 01:36:09 --> Helper loaded: file_helper
INFO - 2024-02-28 01:36:09 --> Helper loaded: form_helper
INFO - 2024-02-28 01:36:09 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:36:10 --> Controller Class Initialized
INFO - 2024-02-28 01:36:10 --> Form Validation Class Initialized
INFO - 2024-02-28 01:36:10 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:36:10 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:36:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:36:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:36:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:36:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:36:10 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:36:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:36:10 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:37:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:37:04 --> Config Class Initialized
INFO - 2024-02-28 01:37:04 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:37:04 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:37:04 --> Utf8 Class Initialized
INFO - 2024-02-28 01:37:04 --> URI Class Initialized
INFO - 2024-02-28 01:37:04 --> Router Class Initialized
INFO - 2024-02-28 01:37:04 --> Output Class Initialized
INFO - 2024-02-28 01:37:04 --> Security Class Initialized
DEBUG - 2024-02-28 01:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:37:04 --> Input Class Initialized
INFO - 2024-02-28 01:37:04 --> Language Class Initialized
INFO - 2024-02-28 01:37:04 --> Loader Class Initialized
INFO - 2024-02-28 01:37:04 --> Helper loaded: url_helper
INFO - 2024-02-28 01:37:04 --> Helper loaded: file_helper
INFO - 2024-02-28 01:37:04 --> Helper loaded: form_helper
INFO - 2024-02-28 01:37:04 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:37:04 --> Controller Class Initialized
INFO - 2024-02-28 01:37:04 --> Form Validation Class Initialized
INFO - 2024-02-28 01:37:04 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:37:04 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:37:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:37:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:37:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:37:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:37:04 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:37:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:37:04 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:37:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:37:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-28 01:37:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-28 01:37:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:37:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:37:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:37:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-28 01:37:04 --> Final output sent to browser
DEBUG - 2024-02-28 01:37:04 --> Total execution time: 0.0502
ERROR - 2024-02-28 01:37:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:37:05 --> Config Class Initialized
INFO - 2024-02-28 01:37:05 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:37:05 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:37:05 --> Utf8 Class Initialized
INFO - 2024-02-28 01:37:05 --> URI Class Initialized
INFO - 2024-02-28 01:37:05 --> Router Class Initialized
INFO - 2024-02-28 01:37:05 --> Output Class Initialized
INFO - 2024-02-28 01:37:05 --> Security Class Initialized
DEBUG - 2024-02-28 01:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:37:05 --> Input Class Initialized
INFO - 2024-02-28 01:37:05 --> Language Class Initialized
INFO - 2024-02-28 01:37:05 --> Loader Class Initialized
INFO - 2024-02-28 01:37:05 --> Helper loaded: url_helper
INFO - 2024-02-28 01:37:05 --> Helper loaded: file_helper
INFO - 2024-02-28 01:37:05 --> Helper loaded: form_helper
INFO - 2024-02-28 01:37:05 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:37:05 --> Controller Class Initialized
INFO - 2024-02-28 01:37:05 --> Form Validation Class Initialized
INFO - 2024-02-28 01:37:05 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:37:05 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:37:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:37:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:37:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:37:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:37:05 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:37:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:37:05 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:37:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:37:09 --> Config Class Initialized
INFO - 2024-02-28 01:37:09 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:37:09 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:37:09 --> Utf8 Class Initialized
INFO - 2024-02-28 01:37:09 --> URI Class Initialized
INFO - 2024-02-28 01:37:09 --> Router Class Initialized
INFO - 2024-02-28 01:37:09 --> Output Class Initialized
INFO - 2024-02-28 01:37:09 --> Security Class Initialized
DEBUG - 2024-02-28 01:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:37:09 --> Input Class Initialized
INFO - 2024-02-28 01:37:09 --> Language Class Initialized
INFO - 2024-02-28 01:37:09 --> Loader Class Initialized
INFO - 2024-02-28 01:37:09 --> Helper loaded: url_helper
INFO - 2024-02-28 01:37:09 --> Helper loaded: file_helper
INFO - 2024-02-28 01:37:09 --> Helper loaded: form_helper
INFO - 2024-02-28 01:37:09 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:37:09 --> Controller Class Initialized
INFO - 2024-02-28 01:37:09 --> Form Validation Class Initialized
INFO - 2024-02-28 01:37:09 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-28 01:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/index.php
INFO - 2024-02-28 01:37:09 --> Final output sent to browser
DEBUG - 2024-02-28 01:37:09 --> Total execution time: 0.0449
ERROR - 2024-02-28 01:37:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:37:09 --> Config Class Initialized
INFO - 2024-02-28 01:37:09 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:37:09 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:37:09 --> Utf8 Class Initialized
INFO - 2024-02-28 01:37:09 --> URI Class Initialized
INFO - 2024-02-28 01:37:09 --> Router Class Initialized
INFO - 2024-02-28 01:37:09 --> Output Class Initialized
INFO - 2024-02-28 01:37:09 --> Security Class Initialized
DEBUG - 2024-02-28 01:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:37:09 --> Input Class Initialized
INFO - 2024-02-28 01:37:09 --> Language Class Initialized
INFO - 2024-02-28 01:37:09 --> Loader Class Initialized
INFO - 2024-02-28 01:37:09 --> Helper loaded: url_helper
INFO - 2024-02-28 01:37:09 --> Helper loaded: file_helper
INFO - 2024-02-28 01:37:09 --> Helper loaded: form_helper
INFO - 2024-02-28 01:37:09 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:37:09 --> Controller Class Initialized
INFO - 2024-02-28 01:37:09 --> Form Validation Class Initialized
INFO - 2024-02-28 01:37:09 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:37:09 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:37:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:37:51 --> Config Class Initialized
INFO - 2024-02-28 01:37:51 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:37:51 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:37:51 --> Utf8 Class Initialized
INFO - 2024-02-28 01:37:51 --> URI Class Initialized
INFO - 2024-02-28 01:37:51 --> Router Class Initialized
INFO - 2024-02-28 01:37:51 --> Output Class Initialized
INFO - 2024-02-28 01:37:51 --> Security Class Initialized
DEBUG - 2024-02-28 01:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:37:51 --> Input Class Initialized
INFO - 2024-02-28 01:37:51 --> Language Class Initialized
INFO - 2024-02-28 01:37:51 --> Loader Class Initialized
INFO - 2024-02-28 01:37:51 --> Helper loaded: url_helper
INFO - 2024-02-28 01:37:51 --> Helper loaded: file_helper
INFO - 2024-02-28 01:37:51 --> Helper loaded: form_helper
INFO - 2024-02-28 01:37:51 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:37:51 --> Controller Class Initialized
INFO - 2024-02-28 01:37:51 --> Form Validation Class Initialized
INFO - 2024-02-28 01:37:51 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:37:51 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:37:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:37:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:37:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:37:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:37:51 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:37:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:37:51 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:37:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/form.php
INFO - 2024-02-28 01:37:51 --> Final output sent to browser
DEBUG - 2024-02-28 01:37:51 --> Total execution time: 0.0347
ERROR - 2024-02-28 01:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:38:03 --> Config Class Initialized
INFO - 2024-02-28 01:38:03 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:38:03 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:38:03 --> Utf8 Class Initialized
INFO - 2024-02-28 01:38:03 --> URI Class Initialized
INFO - 2024-02-28 01:38:03 --> Router Class Initialized
INFO - 2024-02-28 01:38:03 --> Output Class Initialized
INFO - 2024-02-28 01:38:03 --> Security Class Initialized
DEBUG - 2024-02-28 01:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:38:03 --> Input Class Initialized
INFO - 2024-02-28 01:38:03 --> Language Class Initialized
INFO - 2024-02-28 01:38:03 --> Loader Class Initialized
INFO - 2024-02-28 01:38:03 --> Helper loaded: url_helper
INFO - 2024-02-28 01:38:03 --> Helper loaded: file_helper
INFO - 2024-02-28 01:38:03 --> Helper loaded: form_helper
INFO - 2024-02-28 01:38:03 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:38:03 --> Controller Class Initialized
INFO - 2024-02-28 01:38:03 --> Form Validation Class Initialized
INFO - 2024-02-28 01:38:03 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:38:03 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:38:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:38:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:38:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:38:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:38:04 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:38:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:38:04 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:38:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:38:04 --> Config Class Initialized
INFO - 2024-02-28 01:38:04 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:38:04 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:38:04 --> Utf8 Class Initialized
INFO - 2024-02-28 01:38:04 --> URI Class Initialized
INFO - 2024-02-28 01:38:04 --> Router Class Initialized
INFO - 2024-02-28 01:38:04 --> Output Class Initialized
INFO - 2024-02-28 01:38:04 --> Security Class Initialized
DEBUG - 2024-02-28 01:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:38:04 --> Input Class Initialized
INFO - 2024-02-28 01:38:04 --> Language Class Initialized
INFO - 2024-02-28 01:38:04 --> Loader Class Initialized
INFO - 2024-02-28 01:38:04 --> Helper loaded: url_helper
INFO - 2024-02-28 01:38:04 --> Helper loaded: file_helper
INFO - 2024-02-28 01:38:04 --> Helper loaded: form_helper
INFO - 2024-02-28 01:38:04 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:38:04 --> Controller Class Initialized
INFO - 2024-02-28 01:38:04 --> Form Validation Class Initialized
INFO - 2024-02-28 01:38:04 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:38:04 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:38:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:38:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:38:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:38:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:38:04 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:38:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:38:04 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:38:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:38:09 --> Config Class Initialized
INFO - 2024-02-28 01:38:09 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:38:09 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:38:09 --> Utf8 Class Initialized
INFO - 2024-02-28 01:38:09 --> URI Class Initialized
INFO - 2024-02-28 01:38:09 --> Router Class Initialized
INFO - 2024-02-28 01:38:09 --> Output Class Initialized
INFO - 2024-02-28 01:38:09 --> Security Class Initialized
DEBUG - 2024-02-28 01:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:38:09 --> Input Class Initialized
INFO - 2024-02-28 01:38:09 --> Language Class Initialized
INFO - 2024-02-28 01:38:09 --> Loader Class Initialized
INFO - 2024-02-28 01:38:09 --> Helper loaded: url_helper
INFO - 2024-02-28 01:38:09 --> Helper loaded: file_helper
INFO - 2024-02-28 01:38:09 --> Helper loaded: form_helper
INFO - 2024-02-28 01:38:09 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:38:09 --> Controller Class Initialized
INFO - 2024-02-28 01:38:09 --> Form Validation Class Initialized
INFO - 2024-02-28 01:38:09 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:38:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:38:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:38:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:38:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:38:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:38:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:38:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:38:09 --> Final output sent to browser
DEBUG - 2024-02-28 01:38:09 --> Total execution time: 0.0618
ERROR - 2024-02-28 01:38:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:38:09 --> Config Class Initialized
INFO - 2024-02-28 01:38:09 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:38:09 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:38:09 --> Utf8 Class Initialized
INFO - 2024-02-28 01:38:09 --> URI Class Initialized
INFO - 2024-02-28 01:38:09 --> Router Class Initialized
INFO - 2024-02-28 01:38:09 --> Output Class Initialized
INFO - 2024-02-28 01:38:09 --> Security Class Initialized
DEBUG - 2024-02-28 01:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:38:09 --> Input Class Initialized
INFO - 2024-02-28 01:38:09 --> Language Class Initialized
INFO - 2024-02-28 01:38:09 --> Loader Class Initialized
INFO - 2024-02-28 01:38:09 --> Helper loaded: url_helper
INFO - 2024-02-28 01:38:09 --> Helper loaded: file_helper
INFO - 2024-02-28 01:38:09 --> Helper loaded: form_helper
INFO - 2024-02-28 01:38:09 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:38:09 --> Controller Class Initialized
INFO - 2024-02-28 01:38:09 --> Form Validation Class Initialized
INFO - 2024-02-28 01:38:09 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:38:09 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:38:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:38:15 --> Config Class Initialized
INFO - 2024-02-28 01:38:15 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:38:15 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:38:15 --> Utf8 Class Initialized
INFO - 2024-02-28 01:38:15 --> URI Class Initialized
INFO - 2024-02-28 01:38:15 --> Router Class Initialized
INFO - 2024-02-28 01:38:15 --> Output Class Initialized
INFO - 2024-02-28 01:38:15 --> Security Class Initialized
DEBUG - 2024-02-28 01:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:38:15 --> Input Class Initialized
INFO - 2024-02-28 01:38:15 --> Language Class Initialized
INFO - 2024-02-28 01:38:15 --> Loader Class Initialized
INFO - 2024-02-28 01:38:15 --> Helper loaded: url_helper
INFO - 2024-02-28 01:38:15 --> Helper loaded: file_helper
INFO - 2024-02-28 01:38:15 --> Helper loaded: form_helper
INFO - 2024-02-28 01:38:15 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:38:15 --> Controller Class Initialized
INFO - 2024-02-28 01:38:15 --> Form Validation Class Initialized
INFO - 2024-02-28 01:38:15 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:38:15 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:38:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:38:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:38:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:38:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:38:15 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:38:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:38:15 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:38:24 --> Config Class Initialized
INFO - 2024-02-28 01:38:24 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:38:24 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:38:24 --> Utf8 Class Initialized
INFO - 2024-02-28 01:38:24 --> URI Class Initialized
INFO - 2024-02-28 01:38:24 --> Router Class Initialized
INFO - 2024-02-28 01:38:24 --> Output Class Initialized
INFO - 2024-02-28 01:38:24 --> Security Class Initialized
DEBUG - 2024-02-28 01:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:38:24 --> Input Class Initialized
INFO - 2024-02-28 01:38:24 --> Language Class Initialized
INFO - 2024-02-28 01:38:24 --> Loader Class Initialized
INFO - 2024-02-28 01:38:24 --> Helper loaded: url_helper
INFO - 2024-02-28 01:38:24 --> Helper loaded: file_helper
INFO - 2024-02-28 01:38:24 --> Helper loaded: form_helper
INFO - 2024-02-28 01:38:24 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:38:24 --> Controller Class Initialized
INFO - 2024-02-28 01:38:24 --> Form Validation Class Initialized
INFO - 2024-02-28 01:38:24 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:38:24 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:38:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:38:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:38:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:38:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:38:24 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:38:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:38:24 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:38:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:38:26 --> Config Class Initialized
INFO - 2024-02-28 01:38:26 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:38:26 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:38:26 --> Utf8 Class Initialized
INFO - 2024-02-28 01:38:26 --> URI Class Initialized
INFO - 2024-02-28 01:38:26 --> Router Class Initialized
INFO - 2024-02-28 01:38:26 --> Output Class Initialized
INFO - 2024-02-28 01:38:26 --> Security Class Initialized
DEBUG - 2024-02-28 01:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:38:26 --> Input Class Initialized
INFO - 2024-02-28 01:38:26 --> Language Class Initialized
INFO - 2024-02-28 01:38:26 --> Loader Class Initialized
INFO - 2024-02-28 01:38:26 --> Helper loaded: url_helper
INFO - 2024-02-28 01:38:26 --> Helper loaded: file_helper
INFO - 2024-02-28 01:38:26 --> Helper loaded: form_helper
INFO - 2024-02-28 01:38:26 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:38:26 --> Controller Class Initialized
INFO - 2024-02-28 01:38:26 --> Form Validation Class Initialized
INFO - 2024-02-28 01:38:26 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:38:26 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:38:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:38:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:38:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:38:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:38:26 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:38:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:38:26 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:46:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:46:25 --> Config Class Initialized
INFO - 2024-02-28 01:46:25 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:46:25 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:46:25 --> Utf8 Class Initialized
INFO - 2024-02-28 01:46:25 --> URI Class Initialized
INFO - 2024-02-28 01:46:25 --> Router Class Initialized
INFO - 2024-02-28 01:46:25 --> Output Class Initialized
INFO - 2024-02-28 01:46:25 --> Security Class Initialized
DEBUG - 2024-02-28 01:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:46:25 --> Input Class Initialized
INFO - 2024-02-28 01:46:25 --> Language Class Initialized
INFO - 2024-02-28 01:46:25 --> Loader Class Initialized
INFO - 2024-02-28 01:46:25 --> Helper loaded: url_helper
INFO - 2024-02-28 01:46:25 --> Helper loaded: file_helper
INFO - 2024-02-28 01:46:25 --> Helper loaded: form_helper
INFO - 2024-02-28 01:46:25 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:46:25 --> Controller Class Initialized
INFO - 2024-02-28 01:46:25 --> Form Validation Class Initialized
INFO - 2024-02-28 01:46:25 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:46:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:46:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:46:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:46:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:46:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:46:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:46:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:46:25 --> Final output sent to browser
DEBUG - 2024-02-28 01:46:25 --> Total execution time: 0.0553
ERROR - 2024-02-28 01:46:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:46:25 --> Config Class Initialized
INFO - 2024-02-28 01:46:25 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:46:25 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:46:25 --> Utf8 Class Initialized
INFO - 2024-02-28 01:46:25 --> URI Class Initialized
INFO - 2024-02-28 01:46:25 --> Router Class Initialized
INFO - 2024-02-28 01:46:25 --> Output Class Initialized
INFO - 2024-02-28 01:46:25 --> Security Class Initialized
DEBUG - 2024-02-28 01:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:46:25 --> Input Class Initialized
INFO - 2024-02-28 01:46:25 --> Language Class Initialized
INFO - 2024-02-28 01:46:25 --> Loader Class Initialized
INFO - 2024-02-28 01:46:25 --> Helper loaded: url_helper
INFO - 2024-02-28 01:46:25 --> Helper loaded: file_helper
INFO - 2024-02-28 01:46:25 --> Helper loaded: form_helper
INFO - 2024-02-28 01:46:25 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:46:25 --> Controller Class Initialized
INFO - 2024-02-28 01:46:25 --> Form Validation Class Initialized
INFO - 2024-02-28 01:46:25 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:46:25 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:46:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:46:32 --> Config Class Initialized
INFO - 2024-02-28 01:46:32 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:46:32 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:46:32 --> Utf8 Class Initialized
INFO - 2024-02-28 01:46:32 --> URI Class Initialized
INFO - 2024-02-28 01:46:32 --> Router Class Initialized
INFO - 2024-02-28 01:46:32 --> Output Class Initialized
INFO - 2024-02-28 01:46:32 --> Security Class Initialized
DEBUG - 2024-02-28 01:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:46:32 --> Input Class Initialized
INFO - 2024-02-28 01:46:32 --> Language Class Initialized
INFO - 2024-02-28 01:46:32 --> Loader Class Initialized
INFO - 2024-02-28 01:46:32 --> Helper loaded: url_helper
INFO - 2024-02-28 01:46:32 --> Helper loaded: file_helper
INFO - 2024-02-28 01:46:32 --> Helper loaded: form_helper
INFO - 2024-02-28 01:46:32 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:46:32 --> Controller Class Initialized
INFO - 2024-02-28 01:46:32 --> Form Validation Class Initialized
INFO - 2024-02-28 01:46:32 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:46:32 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:46:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:46:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:46:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:46:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:46:32 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:46:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:46:32 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:47:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:47:05 --> Config Class Initialized
INFO - 2024-02-28 01:47:05 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:47:05 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:47:05 --> Utf8 Class Initialized
INFO - 2024-02-28 01:47:05 --> URI Class Initialized
INFO - 2024-02-28 01:47:05 --> Router Class Initialized
INFO - 2024-02-28 01:47:05 --> Output Class Initialized
INFO - 2024-02-28 01:47:05 --> Security Class Initialized
DEBUG - 2024-02-28 01:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:47:05 --> Input Class Initialized
INFO - 2024-02-28 01:47:05 --> Language Class Initialized
INFO - 2024-02-28 01:47:05 --> Loader Class Initialized
INFO - 2024-02-28 01:47:05 --> Helper loaded: url_helper
INFO - 2024-02-28 01:47:05 --> Helper loaded: file_helper
INFO - 2024-02-28 01:47:05 --> Helper loaded: form_helper
INFO - 2024-02-28 01:47:05 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:47:05 --> Controller Class Initialized
INFO - 2024-02-28 01:47:05 --> Form Validation Class Initialized
INFO - 2024-02-28 01:47:05 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:47:05 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:47:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:47:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:47:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:47:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:47:05 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:47:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:47:05 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:47:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:47:08 --> Config Class Initialized
INFO - 2024-02-28 01:47:08 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:47:08 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:47:08 --> Utf8 Class Initialized
INFO - 2024-02-28 01:47:08 --> URI Class Initialized
INFO - 2024-02-28 01:47:08 --> Router Class Initialized
INFO - 2024-02-28 01:47:08 --> Output Class Initialized
INFO - 2024-02-28 01:47:08 --> Security Class Initialized
DEBUG - 2024-02-28 01:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:47:08 --> Input Class Initialized
INFO - 2024-02-28 01:47:08 --> Language Class Initialized
INFO - 2024-02-28 01:47:08 --> Loader Class Initialized
INFO - 2024-02-28 01:47:08 --> Helper loaded: url_helper
INFO - 2024-02-28 01:47:08 --> Helper loaded: file_helper
INFO - 2024-02-28 01:47:08 --> Helper loaded: form_helper
INFO - 2024-02-28 01:47:08 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:47:08 --> Controller Class Initialized
INFO - 2024-02-28 01:47:08 --> Form Validation Class Initialized
INFO - 2024-02-28 01:47:08 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:47:08 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:47:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:47:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:47:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:47:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:47:08 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:47:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:47:08 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:47:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:47:25 --> Config Class Initialized
INFO - 2024-02-28 01:47:25 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:47:25 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:47:25 --> Utf8 Class Initialized
INFO - 2024-02-28 01:47:25 --> URI Class Initialized
INFO - 2024-02-28 01:47:25 --> Router Class Initialized
INFO - 2024-02-28 01:47:25 --> Output Class Initialized
INFO - 2024-02-28 01:47:25 --> Security Class Initialized
DEBUG - 2024-02-28 01:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:47:25 --> Input Class Initialized
INFO - 2024-02-28 01:47:25 --> Language Class Initialized
INFO - 2024-02-28 01:47:25 --> Loader Class Initialized
INFO - 2024-02-28 01:47:25 --> Helper loaded: url_helper
INFO - 2024-02-28 01:47:25 --> Helper loaded: file_helper
INFO - 2024-02-28 01:47:25 --> Helper loaded: form_helper
INFO - 2024-02-28 01:47:25 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:47:25 --> Controller Class Initialized
INFO - 2024-02-28 01:47:25 --> Form Validation Class Initialized
INFO - 2024-02-28 01:47:25 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:47:25 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:47:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:47:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:47:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:47:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:47:25 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:47:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:47:25 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:47:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:47:31 --> Config Class Initialized
INFO - 2024-02-28 01:47:31 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:47:31 --> Utf8 Class Initialized
INFO - 2024-02-28 01:47:31 --> URI Class Initialized
INFO - 2024-02-28 01:47:31 --> Router Class Initialized
INFO - 2024-02-28 01:47:31 --> Output Class Initialized
INFO - 2024-02-28 01:47:31 --> Security Class Initialized
DEBUG - 2024-02-28 01:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:47:31 --> Input Class Initialized
INFO - 2024-02-28 01:47:31 --> Language Class Initialized
INFO - 2024-02-28 01:47:31 --> Loader Class Initialized
INFO - 2024-02-28 01:47:31 --> Helper loaded: url_helper
INFO - 2024-02-28 01:47:31 --> Helper loaded: file_helper
INFO - 2024-02-28 01:47:31 --> Helper loaded: form_helper
INFO - 2024-02-28 01:47:31 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:47:31 --> Controller Class Initialized
INFO - 2024-02-28 01:47:31 --> Form Validation Class Initialized
INFO - 2024-02-28 01:47:31 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:47:31 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:47:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:47:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:47:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:47:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:47:31 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:47:31 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:47:31 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:47:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:47:36 --> Config Class Initialized
INFO - 2024-02-28 01:47:36 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:47:36 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:47:36 --> Utf8 Class Initialized
INFO - 2024-02-28 01:47:36 --> URI Class Initialized
INFO - 2024-02-28 01:47:36 --> Router Class Initialized
INFO - 2024-02-28 01:47:36 --> Output Class Initialized
INFO - 2024-02-28 01:47:36 --> Security Class Initialized
DEBUG - 2024-02-28 01:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:47:36 --> Input Class Initialized
INFO - 2024-02-28 01:47:36 --> Language Class Initialized
INFO - 2024-02-28 01:47:36 --> Loader Class Initialized
INFO - 2024-02-28 01:47:36 --> Helper loaded: url_helper
INFO - 2024-02-28 01:47:36 --> Helper loaded: file_helper
INFO - 2024-02-28 01:47:36 --> Helper loaded: form_helper
INFO - 2024-02-28 01:47:36 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:47:36 --> Controller Class Initialized
INFO - 2024-02-28 01:47:36 --> Form Validation Class Initialized
INFO - 2024-02-28 01:47:36 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:47:36 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:47:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:47:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:47:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:47:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:47:36 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:47:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:47:36 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:47:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:47:39 --> Config Class Initialized
INFO - 2024-02-28 01:47:39 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:47:39 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:47:39 --> Utf8 Class Initialized
INFO - 2024-02-28 01:47:39 --> URI Class Initialized
INFO - 2024-02-28 01:47:39 --> Router Class Initialized
INFO - 2024-02-28 01:47:39 --> Output Class Initialized
INFO - 2024-02-28 01:47:39 --> Security Class Initialized
DEBUG - 2024-02-28 01:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:47:39 --> Input Class Initialized
INFO - 2024-02-28 01:47:39 --> Language Class Initialized
INFO - 2024-02-28 01:47:39 --> Loader Class Initialized
INFO - 2024-02-28 01:47:39 --> Helper loaded: url_helper
INFO - 2024-02-28 01:47:39 --> Helper loaded: file_helper
INFO - 2024-02-28 01:47:39 --> Helper loaded: form_helper
INFO - 2024-02-28 01:47:39 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:47:39 --> Controller Class Initialized
INFO - 2024-02-28 01:47:39 --> Form Validation Class Initialized
INFO - 2024-02-28 01:47:39 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:47:39 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:47:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:47:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:47:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:47:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:47:39 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:47:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:47:39 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:47:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:47:41 --> Config Class Initialized
INFO - 2024-02-28 01:47:41 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:47:41 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:47:41 --> Utf8 Class Initialized
INFO - 2024-02-28 01:47:41 --> URI Class Initialized
INFO - 2024-02-28 01:47:41 --> Router Class Initialized
INFO - 2024-02-28 01:47:41 --> Output Class Initialized
INFO - 2024-02-28 01:47:41 --> Security Class Initialized
DEBUG - 2024-02-28 01:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:47:41 --> Input Class Initialized
INFO - 2024-02-28 01:47:41 --> Language Class Initialized
INFO - 2024-02-28 01:47:41 --> Loader Class Initialized
INFO - 2024-02-28 01:47:41 --> Helper loaded: url_helper
INFO - 2024-02-28 01:47:41 --> Helper loaded: file_helper
INFO - 2024-02-28 01:47:41 --> Helper loaded: form_helper
INFO - 2024-02-28 01:47:41 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:47:41 --> Controller Class Initialized
INFO - 2024-02-28 01:47:41 --> Form Validation Class Initialized
INFO - 2024-02-28 01:47:41 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:47:41 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:47:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:47:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:47:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:47:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:47:41 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:47:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:47:41 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:48:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:48:02 --> Config Class Initialized
INFO - 2024-02-28 01:48:02 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:48:02 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:48:02 --> Utf8 Class Initialized
INFO - 2024-02-28 01:48:02 --> URI Class Initialized
INFO - 2024-02-28 01:48:02 --> Router Class Initialized
INFO - 2024-02-28 01:48:02 --> Output Class Initialized
INFO - 2024-02-28 01:48:02 --> Security Class Initialized
DEBUG - 2024-02-28 01:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:48:02 --> Input Class Initialized
INFO - 2024-02-28 01:48:02 --> Language Class Initialized
INFO - 2024-02-28 01:48:02 --> Loader Class Initialized
INFO - 2024-02-28 01:48:02 --> Helper loaded: url_helper
INFO - 2024-02-28 01:48:02 --> Helper loaded: file_helper
INFO - 2024-02-28 01:48:02 --> Helper loaded: form_helper
INFO - 2024-02-28 01:48:02 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:48:02 --> Controller Class Initialized
INFO - 2024-02-28 01:48:02 --> Form Validation Class Initialized
INFO - 2024-02-28 01:48:02 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:48:02 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:48:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:48:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:48:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:48:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:48:02 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:48:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:48:02 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:48:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:48:05 --> Config Class Initialized
INFO - 2024-02-28 01:48:05 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:48:05 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:48:05 --> Utf8 Class Initialized
INFO - 2024-02-28 01:48:05 --> URI Class Initialized
INFO - 2024-02-28 01:48:05 --> Router Class Initialized
INFO - 2024-02-28 01:48:05 --> Output Class Initialized
INFO - 2024-02-28 01:48:05 --> Security Class Initialized
DEBUG - 2024-02-28 01:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:48:05 --> Input Class Initialized
INFO - 2024-02-28 01:48:05 --> Language Class Initialized
INFO - 2024-02-28 01:48:05 --> Loader Class Initialized
INFO - 2024-02-28 01:48:05 --> Helper loaded: url_helper
INFO - 2024-02-28 01:48:05 --> Helper loaded: file_helper
INFO - 2024-02-28 01:48:05 --> Helper loaded: form_helper
INFO - 2024-02-28 01:48:05 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:48:05 --> Controller Class Initialized
INFO - 2024-02-28 01:48:05 --> Form Validation Class Initialized
INFO - 2024-02-28 01:48:05 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:48:05 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:48:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:48:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:48:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:48:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:48:05 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:48:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:48:05 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:48:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:48:17 --> Config Class Initialized
INFO - 2024-02-28 01:48:17 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:48:17 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:48:17 --> Utf8 Class Initialized
INFO - 2024-02-28 01:48:17 --> URI Class Initialized
INFO - 2024-02-28 01:48:17 --> Router Class Initialized
INFO - 2024-02-28 01:48:17 --> Output Class Initialized
INFO - 2024-02-28 01:48:17 --> Security Class Initialized
DEBUG - 2024-02-28 01:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:48:17 --> Input Class Initialized
INFO - 2024-02-28 01:48:17 --> Language Class Initialized
INFO - 2024-02-28 01:48:17 --> Loader Class Initialized
INFO - 2024-02-28 01:48:17 --> Helper loaded: url_helper
INFO - 2024-02-28 01:48:17 --> Helper loaded: file_helper
INFO - 2024-02-28 01:48:17 --> Helper loaded: form_helper
INFO - 2024-02-28 01:48:17 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:48:17 --> Controller Class Initialized
INFO - 2024-02-28 01:48:17 --> Form Validation Class Initialized
INFO - 2024-02-28 01:48:17 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:48:17 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:48:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:48:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:48:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:48:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:48:17 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:48:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:48:17 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:49:08 --> Config Class Initialized
INFO - 2024-02-28 01:49:08 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:49:08 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:49:08 --> Utf8 Class Initialized
INFO - 2024-02-28 01:49:08 --> URI Class Initialized
INFO - 2024-02-28 01:49:08 --> Router Class Initialized
INFO - 2024-02-28 01:49:08 --> Output Class Initialized
INFO - 2024-02-28 01:49:08 --> Security Class Initialized
DEBUG - 2024-02-28 01:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:49:08 --> Input Class Initialized
INFO - 2024-02-28 01:49:08 --> Language Class Initialized
INFO - 2024-02-28 01:49:08 --> Loader Class Initialized
INFO - 2024-02-28 01:49:08 --> Helper loaded: url_helper
INFO - 2024-02-28 01:49:08 --> Helper loaded: file_helper
INFO - 2024-02-28 01:49:08 --> Helper loaded: form_helper
INFO - 2024-02-28 01:49:08 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:49:08 --> Controller Class Initialized
INFO - 2024-02-28 01:49:08 --> Form Validation Class Initialized
INFO - 2024-02-28 01:49:08 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:49:08 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:49:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:49:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:49:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:49:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:49:08 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:49:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:49:08 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:49:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:49:16 --> Config Class Initialized
INFO - 2024-02-28 01:49:16 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:49:16 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:49:16 --> Utf8 Class Initialized
INFO - 2024-02-28 01:49:16 --> URI Class Initialized
INFO - 2024-02-28 01:49:16 --> Router Class Initialized
INFO - 2024-02-28 01:49:16 --> Output Class Initialized
INFO - 2024-02-28 01:49:16 --> Security Class Initialized
DEBUG - 2024-02-28 01:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:49:16 --> Input Class Initialized
INFO - 2024-02-28 01:49:16 --> Language Class Initialized
INFO - 2024-02-28 01:49:16 --> Loader Class Initialized
INFO - 2024-02-28 01:49:16 --> Helper loaded: url_helper
INFO - 2024-02-28 01:49:16 --> Helper loaded: file_helper
INFO - 2024-02-28 01:49:16 --> Helper loaded: form_helper
INFO - 2024-02-28 01:49:16 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:49:16 --> Controller Class Initialized
INFO - 2024-02-28 01:49:16 --> Form Validation Class Initialized
INFO - 2024-02-28 01:49:16 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:49:16 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:49:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:49:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:49:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:49:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:49:16 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:49:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:49:16 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:49:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:49:22 --> Config Class Initialized
INFO - 2024-02-28 01:49:22 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:49:22 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:49:22 --> Utf8 Class Initialized
INFO - 2024-02-28 01:49:22 --> URI Class Initialized
INFO - 2024-02-28 01:49:22 --> Router Class Initialized
INFO - 2024-02-28 01:49:22 --> Output Class Initialized
INFO - 2024-02-28 01:49:22 --> Security Class Initialized
DEBUG - 2024-02-28 01:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:49:22 --> Input Class Initialized
INFO - 2024-02-28 01:49:22 --> Language Class Initialized
INFO - 2024-02-28 01:49:22 --> Loader Class Initialized
INFO - 2024-02-28 01:49:22 --> Helper loaded: url_helper
INFO - 2024-02-28 01:49:22 --> Helper loaded: file_helper
INFO - 2024-02-28 01:49:22 --> Helper loaded: form_helper
INFO - 2024-02-28 01:49:22 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:49:22 --> Controller Class Initialized
INFO - 2024-02-28 01:49:22 --> Form Validation Class Initialized
INFO - 2024-02-28 01:49:22 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:49:22 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:49:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:49:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:49:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:49:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:49:22 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:49:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:49:22 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:52:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:52:58 --> Config Class Initialized
INFO - 2024-02-28 01:52:58 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:52:58 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:52:58 --> Utf8 Class Initialized
INFO - 2024-02-28 01:52:58 --> URI Class Initialized
INFO - 2024-02-28 01:52:58 --> Router Class Initialized
INFO - 2024-02-28 01:52:58 --> Output Class Initialized
INFO - 2024-02-28 01:52:58 --> Security Class Initialized
DEBUG - 2024-02-28 01:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:52:58 --> Input Class Initialized
INFO - 2024-02-28 01:52:58 --> Language Class Initialized
INFO - 2024-02-28 01:52:58 --> Loader Class Initialized
INFO - 2024-02-28 01:52:58 --> Helper loaded: url_helper
INFO - 2024-02-28 01:52:58 --> Helper loaded: file_helper
INFO - 2024-02-28 01:52:58 --> Helper loaded: form_helper
INFO - 2024-02-28 01:52:58 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:52:58 --> Controller Class Initialized
INFO - 2024-02-28 01:52:58 --> Form Validation Class Initialized
INFO - 2024-02-28 01:52:58 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "ReportModel" initialized
INFO - 2024-02-28 01:52:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 01:52:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 01:52:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 01:52:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 01:52:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 01:52:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-02-28 01:52:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-28 01:52:58 --> Final output sent to browser
DEBUG - 2024-02-28 01:52:58 --> Total execution time: 0.0577
ERROR - 2024-02-28 01:52:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:52:58 --> Config Class Initialized
INFO - 2024-02-28 01:52:58 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:52:58 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:52:58 --> Utf8 Class Initialized
INFO - 2024-02-28 01:52:58 --> URI Class Initialized
INFO - 2024-02-28 01:52:58 --> Router Class Initialized
INFO - 2024-02-28 01:52:58 --> Output Class Initialized
INFO - 2024-02-28 01:52:58 --> Security Class Initialized
DEBUG - 2024-02-28 01:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:52:58 --> Input Class Initialized
INFO - 2024-02-28 01:52:58 --> Language Class Initialized
INFO - 2024-02-28 01:52:58 --> Loader Class Initialized
INFO - 2024-02-28 01:52:58 --> Helper loaded: url_helper
INFO - 2024-02-28 01:52:58 --> Helper loaded: file_helper
INFO - 2024-02-28 01:52:58 --> Helper loaded: form_helper
INFO - 2024-02-28 01:52:58 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:52:58 --> Controller Class Initialized
INFO - 2024-02-28 01:52:58 --> Form Validation Class Initialized
INFO - 2024-02-28 01:52:58 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:52:58 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:53:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:53:06 --> Config Class Initialized
INFO - 2024-02-28 01:53:06 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:53:06 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:53:06 --> Utf8 Class Initialized
INFO - 2024-02-28 01:53:06 --> URI Class Initialized
INFO - 2024-02-28 01:53:06 --> Router Class Initialized
INFO - 2024-02-28 01:53:06 --> Output Class Initialized
INFO - 2024-02-28 01:53:06 --> Security Class Initialized
DEBUG - 2024-02-28 01:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:53:06 --> Input Class Initialized
INFO - 2024-02-28 01:53:06 --> Language Class Initialized
INFO - 2024-02-28 01:53:06 --> Loader Class Initialized
INFO - 2024-02-28 01:53:06 --> Helper loaded: url_helper
INFO - 2024-02-28 01:53:06 --> Helper loaded: file_helper
INFO - 2024-02-28 01:53:06 --> Helper loaded: form_helper
INFO - 2024-02-28 01:53:06 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:53:06 --> Controller Class Initialized
INFO - 2024-02-28 01:53:06 --> Form Validation Class Initialized
INFO - 2024-02-28 01:53:06 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:53:06 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:53:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:53:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:53:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:53:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:53:06 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:53:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:53:06 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:53:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:53:15 --> Config Class Initialized
INFO - 2024-02-28 01:53:15 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:53:15 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:53:15 --> Utf8 Class Initialized
INFO - 2024-02-28 01:53:15 --> URI Class Initialized
INFO - 2024-02-28 01:53:15 --> Router Class Initialized
INFO - 2024-02-28 01:53:15 --> Output Class Initialized
INFO - 2024-02-28 01:53:15 --> Security Class Initialized
DEBUG - 2024-02-28 01:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:53:15 --> Input Class Initialized
INFO - 2024-02-28 01:53:15 --> Language Class Initialized
INFO - 2024-02-28 01:53:15 --> Loader Class Initialized
INFO - 2024-02-28 01:53:15 --> Helper loaded: url_helper
INFO - 2024-02-28 01:53:15 --> Helper loaded: file_helper
INFO - 2024-02-28 01:53:15 --> Helper loaded: form_helper
INFO - 2024-02-28 01:53:15 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:53:15 --> Controller Class Initialized
INFO - 2024-02-28 01:53:15 --> Form Validation Class Initialized
INFO - 2024-02-28 01:53:15 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:53:15 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:53:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:53:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:53:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:53:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:53:15 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:53:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:53:15 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:53:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:53:22 --> Config Class Initialized
INFO - 2024-02-28 01:53:22 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:53:22 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:53:22 --> Utf8 Class Initialized
INFO - 2024-02-28 01:53:22 --> URI Class Initialized
INFO - 2024-02-28 01:53:22 --> Router Class Initialized
INFO - 2024-02-28 01:53:22 --> Output Class Initialized
INFO - 2024-02-28 01:53:22 --> Security Class Initialized
DEBUG - 2024-02-28 01:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:53:22 --> Input Class Initialized
INFO - 2024-02-28 01:53:22 --> Language Class Initialized
INFO - 2024-02-28 01:53:22 --> Loader Class Initialized
INFO - 2024-02-28 01:53:22 --> Helper loaded: url_helper
INFO - 2024-02-28 01:53:22 --> Helper loaded: file_helper
INFO - 2024-02-28 01:53:22 --> Helper loaded: form_helper
INFO - 2024-02-28 01:53:22 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:53:22 --> Controller Class Initialized
INFO - 2024-02-28 01:53:22 --> Form Validation Class Initialized
INFO - 2024-02-28 01:53:22 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:53:22 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:53:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:53:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:53:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:53:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:53:22 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:53:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:53:22 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:53:46 --> Config Class Initialized
INFO - 2024-02-28 01:53:46 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:53:46 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:53:46 --> Utf8 Class Initialized
INFO - 2024-02-28 01:53:46 --> URI Class Initialized
INFO - 2024-02-28 01:53:46 --> Router Class Initialized
INFO - 2024-02-28 01:53:46 --> Output Class Initialized
INFO - 2024-02-28 01:53:46 --> Security Class Initialized
DEBUG - 2024-02-28 01:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:53:46 --> Input Class Initialized
INFO - 2024-02-28 01:53:46 --> Language Class Initialized
INFO - 2024-02-28 01:53:46 --> Loader Class Initialized
INFO - 2024-02-28 01:53:46 --> Helper loaded: url_helper
INFO - 2024-02-28 01:53:46 --> Helper loaded: file_helper
INFO - 2024-02-28 01:53:46 --> Helper loaded: form_helper
INFO - 2024-02-28 01:53:46 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:53:46 --> Controller Class Initialized
INFO - 2024-02-28 01:53:46 --> Form Validation Class Initialized
INFO - 2024-02-28 01:53:46 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:53:46 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:53:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:53:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:53:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:53:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:53:46 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:53:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:53:46 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:53:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:53:59 --> Config Class Initialized
INFO - 2024-02-28 01:53:59 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:53:59 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:53:59 --> Utf8 Class Initialized
INFO - 2024-02-28 01:53:59 --> URI Class Initialized
INFO - 2024-02-28 01:53:59 --> Router Class Initialized
INFO - 2024-02-28 01:53:59 --> Output Class Initialized
INFO - 2024-02-28 01:53:59 --> Security Class Initialized
DEBUG - 2024-02-28 01:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:53:59 --> Input Class Initialized
INFO - 2024-02-28 01:53:59 --> Language Class Initialized
INFO - 2024-02-28 01:53:59 --> Loader Class Initialized
INFO - 2024-02-28 01:53:59 --> Helper loaded: url_helper
INFO - 2024-02-28 01:53:59 --> Helper loaded: file_helper
INFO - 2024-02-28 01:53:59 --> Helper loaded: form_helper
INFO - 2024-02-28 01:53:59 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:53:59 --> Controller Class Initialized
INFO - 2024-02-28 01:53:59 --> Form Validation Class Initialized
INFO - 2024-02-28 01:53:59 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:53:59 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:53:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:53:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:53:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:53:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:53:59 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:53:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:53:59 --> Model "ReportModel" initialized
ERROR - 2024-02-28 01:54:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 01:54:01 --> Config Class Initialized
INFO - 2024-02-28 01:54:01 --> Hooks Class Initialized
DEBUG - 2024-02-28 01:54:01 --> UTF-8 Support Enabled
INFO - 2024-02-28 01:54:01 --> Utf8 Class Initialized
INFO - 2024-02-28 01:54:01 --> URI Class Initialized
INFO - 2024-02-28 01:54:01 --> Router Class Initialized
INFO - 2024-02-28 01:54:01 --> Output Class Initialized
INFO - 2024-02-28 01:54:01 --> Security Class Initialized
DEBUG - 2024-02-28 01:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 01:54:01 --> Input Class Initialized
INFO - 2024-02-28 01:54:01 --> Language Class Initialized
INFO - 2024-02-28 01:54:01 --> Loader Class Initialized
INFO - 2024-02-28 01:54:01 --> Helper loaded: url_helper
INFO - 2024-02-28 01:54:01 --> Helper loaded: file_helper
INFO - 2024-02-28 01:54:01 --> Helper loaded: form_helper
INFO - 2024-02-28 01:54:01 --> Database Driver Class Initialized
DEBUG - 2024-02-28 01:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 01:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 01:54:01 --> Controller Class Initialized
INFO - 2024-02-28 01:54:01 --> Form Validation Class Initialized
INFO - 2024-02-28 01:54:01 --> Model "MasterModel" initialized
INFO - 2024-02-28 01:54:01 --> Model "DashboardModel" initialized
INFO - 2024-02-28 01:54:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 01:54:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 01:54:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 01:54:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 01:54:01 --> Model "OrderModel" initialized
INFO - 2024-02-28 01:54:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 01:54:01 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:46:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:46:48 --> Config Class Initialized
INFO - 2024-02-28 23:46:48 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:46:48 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:46:48 --> Utf8 Class Initialized
INFO - 2024-02-28 23:46:48 --> URI Class Initialized
INFO - 2024-02-28 23:46:48 --> Router Class Initialized
INFO - 2024-02-28 23:46:48 --> Output Class Initialized
INFO - 2024-02-28 23:46:48 --> Security Class Initialized
DEBUG - 2024-02-28 23:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:46:48 --> Input Class Initialized
INFO - 2024-02-28 23:46:48 --> Language Class Initialized
INFO - 2024-02-28 23:46:48 --> Loader Class Initialized
INFO - 2024-02-28 23:46:48 --> Helper loaded: url_helper
INFO - 2024-02-28 23:46:48 --> Helper loaded: file_helper
INFO - 2024-02-28 23:46:48 --> Helper loaded: form_helper
INFO - 2024-02-28 23:46:48 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:46:48 --> Controller Class Initialized
INFO - 2024-02-28 23:46:48 --> Model "LoginModel" initialized
INFO - 2024-02-28 23:46:48 --> Form Validation Class Initialized
INFO - 2024-02-28 23:46:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-28 23:46:48 --> Final output sent to browser
DEBUG - 2024-02-28 23:46:48 --> Total execution time: 0.0282
ERROR - 2024-02-28 23:47:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:47:13 --> Config Class Initialized
INFO - 2024-02-28 23:47:13 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:47:13 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:47:13 --> Utf8 Class Initialized
INFO - 2024-02-28 23:47:13 --> URI Class Initialized
INFO - 2024-02-28 23:47:13 --> Router Class Initialized
INFO - 2024-02-28 23:47:13 --> Output Class Initialized
INFO - 2024-02-28 23:47:13 --> Security Class Initialized
DEBUG - 2024-02-28 23:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:47:13 --> Input Class Initialized
INFO - 2024-02-28 23:47:13 --> Language Class Initialized
INFO - 2024-02-28 23:47:13 --> Loader Class Initialized
INFO - 2024-02-28 23:47:13 --> Helper loaded: url_helper
INFO - 2024-02-28 23:47:13 --> Helper loaded: file_helper
INFO - 2024-02-28 23:47:13 --> Helper loaded: form_helper
INFO - 2024-02-28 23:47:13 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:47:13 --> Controller Class Initialized
INFO - 2024-02-28 23:47:13 --> Model "LoginModel" initialized
INFO - 2024-02-28 23:47:13 --> Form Validation Class Initialized
INFO - 2024-02-28 23:47:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-28 23:47:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:47:13 --> Config Class Initialized
INFO - 2024-02-28 23:47:13 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:47:13 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:47:13 --> Utf8 Class Initialized
INFO - 2024-02-28 23:47:13 --> URI Class Initialized
INFO - 2024-02-28 23:47:13 --> Router Class Initialized
INFO - 2024-02-28 23:47:13 --> Output Class Initialized
INFO - 2024-02-28 23:47:13 --> Security Class Initialized
DEBUG - 2024-02-28 23:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:47:13 --> Input Class Initialized
INFO - 2024-02-28 23:47:13 --> Language Class Initialized
INFO - 2024-02-28 23:47:13 --> Loader Class Initialized
INFO - 2024-02-28 23:47:13 --> Helper loaded: url_helper
INFO - 2024-02-28 23:47:13 --> Helper loaded: file_helper
INFO - 2024-02-28 23:47:13 --> Helper loaded: form_helper
INFO - 2024-02-28 23:47:13 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:47:13 --> Controller Class Initialized
INFO - 2024-02-28 23:47:13 --> Model "LoginModel" initialized
INFO - 2024-02-28 23:47:13 --> Form Validation Class Initialized
INFO - 2024-02-28 23:47:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-28 23:47:13 --> Final output sent to browser
DEBUG - 2024-02-28 23:47:13 --> Total execution time: 0.0219
ERROR - 2024-02-28 23:47:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:47:26 --> Config Class Initialized
INFO - 2024-02-28 23:47:26 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:47:26 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:47:26 --> Utf8 Class Initialized
INFO - 2024-02-28 23:47:26 --> URI Class Initialized
INFO - 2024-02-28 23:47:26 --> Router Class Initialized
INFO - 2024-02-28 23:47:26 --> Output Class Initialized
INFO - 2024-02-28 23:47:26 --> Security Class Initialized
DEBUG - 2024-02-28 23:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:47:26 --> Input Class Initialized
INFO - 2024-02-28 23:47:26 --> Language Class Initialized
INFO - 2024-02-28 23:47:26 --> Loader Class Initialized
INFO - 2024-02-28 23:47:26 --> Helper loaded: url_helper
INFO - 2024-02-28 23:47:26 --> Helper loaded: file_helper
INFO - 2024-02-28 23:47:26 --> Helper loaded: form_helper
INFO - 2024-02-28 23:47:26 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:47:26 --> Controller Class Initialized
INFO - 2024-02-28 23:47:26 --> Model "LoginModel" initialized
INFO - 2024-02-28 23:47:26 --> Form Validation Class Initialized
INFO - 2024-02-28 23:47:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-28 23:47:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:47:26 --> Config Class Initialized
INFO - 2024-02-28 23:47:26 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:47:26 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:47:26 --> Utf8 Class Initialized
INFO - 2024-02-28 23:47:26 --> URI Class Initialized
INFO - 2024-02-28 23:47:26 --> Router Class Initialized
INFO - 2024-02-28 23:47:26 --> Output Class Initialized
INFO - 2024-02-28 23:47:26 --> Security Class Initialized
DEBUG - 2024-02-28 23:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:47:26 --> Input Class Initialized
INFO - 2024-02-28 23:47:26 --> Language Class Initialized
INFO - 2024-02-28 23:47:26 --> Loader Class Initialized
INFO - 2024-02-28 23:47:26 --> Helper loaded: url_helper
INFO - 2024-02-28 23:47:26 --> Helper loaded: file_helper
INFO - 2024-02-28 23:47:26 --> Helper loaded: form_helper
INFO - 2024-02-28 23:47:26 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:47:26 --> Controller Class Initialized
INFO - 2024-02-28 23:47:26 --> Model "LoginModel" initialized
INFO - 2024-02-28 23:47:26 --> Form Validation Class Initialized
INFO - 2024-02-28 23:47:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-28 23:47:26 --> Final output sent to browser
DEBUG - 2024-02-28 23:47:26 --> Total execution time: 0.0228
ERROR - 2024-02-28 23:47:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:47:39 --> Config Class Initialized
INFO - 2024-02-28 23:47:39 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:47:39 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:47:39 --> Utf8 Class Initialized
INFO - 2024-02-28 23:47:39 --> URI Class Initialized
INFO - 2024-02-28 23:47:39 --> Router Class Initialized
INFO - 2024-02-28 23:47:39 --> Output Class Initialized
INFO - 2024-02-28 23:47:39 --> Security Class Initialized
DEBUG - 2024-02-28 23:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:47:39 --> Input Class Initialized
INFO - 2024-02-28 23:47:39 --> Language Class Initialized
INFO - 2024-02-28 23:47:39 --> Loader Class Initialized
INFO - 2024-02-28 23:47:39 --> Helper loaded: url_helper
INFO - 2024-02-28 23:47:39 --> Helper loaded: file_helper
INFO - 2024-02-28 23:47:39 --> Helper loaded: form_helper
INFO - 2024-02-28 23:47:39 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:47:39 --> Controller Class Initialized
INFO - 2024-02-28 23:47:39 --> Model "LoginModel" initialized
INFO - 2024-02-28 23:47:39 --> Form Validation Class Initialized
INFO - 2024-02-28 23:47:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-28 23:47:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:47:39 --> Config Class Initialized
INFO - 2024-02-28 23:47:39 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:47:39 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:47:39 --> Utf8 Class Initialized
INFO - 2024-02-28 23:47:39 --> URI Class Initialized
INFO - 2024-02-28 23:47:39 --> Router Class Initialized
INFO - 2024-02-28 23:47:39 --> Output Class Initialized
INFO - 2024-02-28 23:47:39 --> Security Class Initialized
DEBUG - 2024-02-28 23:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:47:39 --> Input Class Initialized
INFO - 2024-02-28 23:47:39 --> Language Class Initialized
INFO - 2024-02-28 23:47:39 --> Loader Class Initialized
INFO - 2024-02-28 23:47:39 --> Helper loaded: url_helper
INFO - 2024-02-28 23:47:39 --> Helper loaded: file_helper
INFO - 2024-02-28 23:47:39 --> Helper loaded: form_helper
INFO - 2024-02-28 23:47:39 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:47:39 --> Controller Class Initialized
INFO - 2024-02-28 23:47:39 --> Model "LoginModel" initialized
INFO - 2024-02-28 23:47:39 --> Form Validation Class Initialized
INFO - 2024-02-28 23:47:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-28 23:47:39 --> Final output sent to browser
DEBUG - 2024-02-28 23:47:39 --> Total execution time: 0.0211
ERROR - 2024-02-28 23:47:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:47:52 --> Config Class Initialized
INFO - 2024-02-28 23:47:52 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:47:52 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:47:52 --> Utf8 Class Initialized
INFO - 2024-02-28 23:47:52 --> URI Class Initialized
INFO - 2024-02-28 23:47:52 --> Router Class Initialized
INFO - 2024-02-28 23:47:52 --> Output Class Initialized
INFO - 2024-02-28 23:47:52 --> Security Class Initialized
DEBUG - 2024-02-28 23:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:47:52 --> Input Class Initialized
INFO - 2024-02-28 23:47:52 --> Language Class Initialized
INFO - 2024-02-28 23:47:52 --> Loader Class Initialized
INFO - 2024-02-28 23:47:52 --> Helper loaded: url_helper
INFO - 2024-02-28 23:47:52 --> Helper loaded: file_helper
INFO - 2024-02-28 23:47:52 --> Helper loaded: form_helper
INFO - 2024-02-28 23:47:52 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:47:52 --> Controller Class Initialized
INFO - 2024-02-28 23:47:52 --> Model "LoginModel" initialized
INFO - 2024-02-28 23:47:52 --> Form Validation Class Initialized
INFO - 2024-02-28 23:47:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-28 23:47:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:47:52 --> Config Class Initialized
INFO - 2024-02-28 23:47:52 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:47:52 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:47:52 --> Utf8 Class Initialized
INFO - 2024-02-28 23:47:52 --> URI Class Initialized
INFO - 2024-02-28 23:47:52 --> Router Class Initialized
INFO - 2024-02-28 23:47:52 --> Output Class Initialized
INFO - 2024-02-28 23:47:52 --> Security Class Initialized
DEBUG - 2024-02-28 23:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:47:52 --> Input Class Initialized
INFO - 2024-02-28 23:47:52 --> Language Class Initialized
INFO - 2024-02-28 23:47:52 --> Loader Class Initialized
INFO - 2024-02-28 23:47:52 --> Helper loaded: url_helper
INFO - 2024-02-28 23:47:52 --> Helper loaded: file_helper
INFO - 2024-02-28 23:47:52 --> Helper loaded: form_helper
INFO - 2024-02-28 23:47:52 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:47:52 --> Controller Class Initialized
INFO - 2024-02-28 23:47:52 --> Form Validation Class Initialized
INFO - 2024-02-28 23:47:52 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:47:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 23:47:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-28 23:47:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 23:47:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 23:47:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 23:47:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 23:47:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-28 23:47:52 --> Final output sent to browser
DEBUG - 2024-02-28 23:47:52 --> Total execution time: 0.0336
ERROR - 2024-02-28 23:47:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:47:52 --> Config Class Initialized
INFO - 2024-02-28 23:47:52 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:47:52 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:47:52 --> Utf8 Class Initialized
INFO - 2024-02-28 23:47:52 --> URI Class Initialized
INFO - 2024-02-28 23:47:52 --> Router Class Initialized
INFO - 2024-02-28 23:47:52 --> Output Class Initialized
INFO - 2024-02-28 23:47:52 --> Security Class Initialized
DEBUG - 2024-02-28 23:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:47:52 --> Input Class Initialized
INFO - 2024-02-28 23:47:52 --> Language Class Initialized
INFO - 2024-02-28 23:47:52 --> Loader Class Initialized
INFO - 2024-02-28 23:47:52 --> Helper loaded: url_helper
INFO - 2024-02-28 23:47:52 --> Helper loaded: file_helper
INFO - 2024-02-28 23:47:52 --> Helper loaded: form_helper
INFO - 2024-02-28 23:47:52 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:47:52 --> Controller Class Initialized
INFO - 2024-02-28 23:47:52 --> Form Validation Class Initialized
INFO - 2024-02-28 23:47:52 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:47:52 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:47:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:47:54 --> Config Class Initialized
INFO - 2024-02-28 23:47:54 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:47:54 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:47:54 --> Utf8 Class Initialized
INFO - 2024-02-28 23:47:54 --> URI Class Initialized
INFO - 2024-02-28 23:47:54 --> Router Class Initialized
INFO - 2024-02-28 23:47:54 --> Output Class Initialized
INFO - 2024-02-28 23:47:54 --> Security Class Initialized
DEBUG - 2024-02-28 23:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:47:54 --> Input Class Initialized
INFO - 2024-02-28 23:47:54 --> Language Class Initialized
INFO - 2024-02-28 23:47:54 --> Loader Class Initialized
INFO - 2024-02-28 23:47:54 --> Helper loaded: url_helper
INFO - 2024-02-28 23:47:54 --> Helper loaded: file_helper
INFO - 2024-02-28 23:47:54 --> Helper loaded: form_helper
INFO - 2024-02-28 23:47:54 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:47:54 --> Controller Class Initialized
INFO - 2024-02-28 23:47:54 --> Form Validation Class Initialized
INFO - 2024-02-28 23:47:54 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:47:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 23:47:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 23:47:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 23:47:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 23:47:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 23:47:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-28 23:47:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-28 23:47:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-28 23:47:54 --> Final output sent to browser
DEBUG - 2024-02-28 23:47:54 --> Total execution time: 0.0564
ERROR - 2024-02-28 23:47:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:47:54 --> Config Class Initialized
INFO - 2024-02-28 23:47:54 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:47:54 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:47:54 --> Utf8 Class Initialized
INFO - 2024-02-28 23:47:54 --> URI Class Initialized
INFO - 2024-02-28 23:47:54 --> Router Class Initialized
INFO - 2024-02-28 23:47:54 --> Output Class Initialized
INFO - 2024-02-28 23:47:54 --> Security Class Initialized
DEBUG - 2024-02-28 23:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:47:54 --> Input Class Initialized
INFO - 2024-02-28 23:47:54 --> Language Class Initialized
INFO - 2024-02-28 23:47:54 --> Loader Class Initialized
INFO - 2024-02-28 23:47:54 --> Helper loaded: url_helper
INFO - 2024-02-28 23:47:54 --> Helper loaded: file_helper
INFO - 2024-02-28 23:47:54 --> Helper loaded: form_helper
INFO - 2024-02-28 23:47:54 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:47:54 --> Controller Class Initialized
INFO - 2024-02-28 23:47:54 --> Form Validation Class Initialized
INFO - 2024-02-28 23:47:54 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:47:54 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:48:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:48:02 --> Config Class Initialized
INFO - 2024-02-28 23:48:02 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:48:02 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:48:02 --> Utf8 Class Initialized
INFO - 2024-02-28 23:48:02 --> URI Class Initialized
INFO - 2024-02-28 23:48:02 --> Router Class Initialized
INFO - 2024-02-28 23:48:02 --> Output Class Initialized
INFO - 2024-02-28 23:48:02 --> Security Class Initialized
DEBUG - 2024-02-28 23:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:48:02 --> Input Class Initialized
INFO - 2024-02-28 23:48:02 --> Language Class Initialized
INFO - 2024-02-28 23:48:02 --> Loader Class Initialized
INFO - 2024-02-28 23:48:02 --> Helper loaded: url_helper
INFO - 2024-02-28 23:48:02 --> Helper loaded: file_helper
INFO - 2024-02-28 23:48:02 --> Helper loaded: form_helper
INFO - 2024-02-28 23:48:02 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:48:02 --> Controller Class Initialized
INFO - 2024-02-28 23:48:02 --> Form Validation Class Initialized
INFO - 2024-02-28 23:48:02 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:48:02 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:48:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:48:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:48:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:48:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:48:02 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:48:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:48:02 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:48:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-02-28 23:48:02 --> Final output sent to browser
DEBUG - 2024-02-28 23:48:02 --> Total execution time: 0.0324
ERROR - 2024-02-28 23:48:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:48:25 --> Config Class Initialized
INFO - 2024-02-28 23:48:25 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:48:25 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:48:25 --> Utf8 Class Initialized
INFO - 2024-02-28 23:48:25 --> URI Class Initialized
INFO - 2024-02-28 23:48:25 --> Router Class Initialized
INFO - 2024-02-28 23:48:25 --> Output Class Initialized
INFO - 2024-02-28 23:48:25 --> Security Class Initialized
DEBUG - 2024-02-28 23:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:48:25 --> Input Class Initialized
INFO - 2024-02-28 23:48:25 --> Language Class Initialized
INFO - 2024-02-28 23:48:25 --> Loader Class Initialized
INFO - 2024-02-28 23:48:25 --> Helper loaded: url_helper
INFO - 2024-02-28 23:48:25 --> Helper loaded: file_helper
INFO - 2024-02-28 23:48:25 --> Helper loaded: form_helper
INFO - 2024-02-28 23:48:25 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:48:25 --> Controller Class Initialized
INFO - 2024-02-28 23:48:25 --> Form Validation Class Initialized
INFO - 2024-02-28 23:48:25 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:48:25 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:48:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:48:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:48:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:48:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:48:25 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:48:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:48:25 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:48:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-02-28 23:48:25 --> Final output sent to browser
DEBUG - 2024-02-28 23:48:25 --> Total execution time: 0.0510
ERROR - 2024-02-28 23:48:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:48:35 --> Config Class Initialized
INFO - 2024-02-28 23:48:35 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:48:35 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:48:35 --> Utf8 Class Initialized
INFO - 2024-02-28 23:48:35 --> URI Class Initialized
INFO - 2024-02-28 23:48:35 --> Router Class Initialized
INFO - 2024-02-28 23:48:35 --> Output Class Initialized
INFO - 2024-02-28 23:48:35 --> Security Class Initialized
DEBUG - 2024-02-28 23:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:48:35 --> Input Class Initialized
INFO - 2024-02-28 23:48:35 --> Language Class Initialized
INFO - 2024-02-28 23:48:35 --> Loader Class Initialized
INFO - 2024-02-28 23:48:35 --> Helper loaded: url_helper
INFO - 2024-02-28 23:48:35 --> Helper loaded: file_helper
INFO - 2024-02-28 23:48:35 --> Helper loaded: form_helper
INFO - 2024-02-28 23:48:35 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:48:35 --> Controller Class Initialized
INFO - 2024-02-28 23:48:35 --> Form Validation Class Initialized
INFO - 2024-02-28 23:48:35 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:48:35 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:48:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:48:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:48:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:48:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:48:35 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:48:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:48:35 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:48:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-02-28 23:48:35 --> Final output sent to browser
DEBUG - 2024-02-28 23:48:35 --> Total execution time: 0.0435
ERROR - 2024-02-28 23:48:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:48:56 --> Config Class Initialized
INFO - 2024-02-28 23:48:56 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:48:56 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:48:56 --> Utf8 Class Initialized
INFO - 2024-02-28 23:48:56 --> URI Class Initialized
INFO - 2024-02-28 23:48:56 --> Router Class Initialized
INFO - 2024-02-28 23:48:56 --> Output Class Initialized
INFO - 2024-02-28 23:48:56 --> Security Class Initialized
DEBUG - 2024-02-28 23:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:48:56 --> Input Class Initialized
INFO - 2024-02-28 23:48:56 --> Language Class Initialized
INFO - 2024-02-28 23:48:56 --> Loader Class Initialized
INFO - 2024-02-28 23:48:56 --> Helper loaded: url_helper
INFO - 2024-02-28 23:48:56 --> Helper loaded: file_helper
INFO - 2024-02-28 23:48:56 --> Helper loaded: form_helper
INFO - 2024-02-28 23:48:56 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:48:56 --> Controller Class Initialized
INFO - 2024-02-28 23:48:56 --> Form Validation Class Initialized
INFO - 2024-02-28 23:48:56 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 23:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-28 23:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 23:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 23:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 23:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 23:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-28 23:48:56 --> Final output sent to browser
DEBUG - 2024-02-28 23:48:56 --> Total execution time: 0.0267
ERROR - 2024-02-28 23:48:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:48:56 --> Config Class Initialized
INFO - 2024-02-28 23:48:56 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:48:56 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:48:56 --> Utf8 Class Initialized
INFO - 2024-02-28 23:48:56 --> URI Class Initialized
INFO - 2024-02-28 23:48:56 --> Router Class Initialized
INFO - 2024-02-28 23:48:56 --> Output Class Initialized
INFO - 2024-02-28 23:48:56 --> Security Class Initialized
DEBUG - 2024-02-28 23:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:48:56 --> Input Class Initialized
INFO - 2024-02-28 23:48:56 --> Language Class Initialized
INFO - 2024-02-28 23:48:56 --> Loader Class Initialized
INFO - 2024-02-28 23:48:56 --> Helper loaded: url_helper
INFO - 2024-02-28 23:48:56 --> Helper loaded: file_helper
INFO - 2024-02-28 23:48:56 --> Helper loaded: form_helper
INFO - 2024-02-28 23:48:56 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:48:56 --> Controller Class Initialized
INFO - 2024-02-28 23:48:56 --> Form Validation Class Initialized
INFO - 2024-02-28 23:48:56 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:48:56 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:49:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:00 --> Config Class Initialized
INFO - 2024-02-28 23:49:00 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:00 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:00 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:00 --> URI Class Initialized
INFO - 2024-02-28 23:49:00 --> Router Class Initialized
INFO - 2024-02-28 23:49:00 --> Output Class Initialized
INFO - 2024-02-28 23:49:00 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:00 --> Input Class Initialized
INFO - 2024-02-28 23:49:00 --> Language Class Initialized
INFO - 2024-02-28 23:49:00 --> Loader Class Initialized
INFO - 2024-02-28 23:49:00 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:00 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:00 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:00 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:00 --> Controller Class Initialized
INFO - 2024-02-28 23:49:00 --> Model "LoginModel" initialized
INFO - 2024-02-28 23:49:00 --> Form Validation Class Initialized
ERROR - 2024-02-28 23:49:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:00 --> Config Class Initialized
INFO - 2024-02-28 23:49:00 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:00 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:00 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:00 --> URI Class Initialized
INFO - 2024-02-28 23:49:00 --> Router Class Initialized
INFO - 2024-02-28 23:49:00 --> Output Class Initialized
INFO - 2024-02-28 23:49:00 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:00 --> Input Class Initialized
INFO - 2024-02-28 23:49:00 --> Language Class Initialized
INFO - 2024-02-28 23:49:00 --> Loader Class Initialized
INFO - 2024-02-28 23:49:00 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:00 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:00 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:00 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:00 --> Controller Class Initialized
INFO - 2024-02-28 23:49:00 --> Model "LoginModel" initialized
INFO - 2024-02-28 23:49:00 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-28 23:49:00 --> Final output sent to browser
DEBUG - 2024-02-28 23:49:00 --> Total execution time: 0.0257
ERROR - 2024-02-28 23:49:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:07 --> Config Class Initialized
INFO - 2024-02-28 23:49:07 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:07 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:07 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:07 --> URI Class Initialized
INFO - 2024-02-28 23:49:07 --> Router Class Initialized
INFO - 2024-02-28 23:49:07 --> Output Class Initialized
INFO - 2024-02-28 23:49:07 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:07 --> Input Class Initialized
INFO - 2024-02-28 23:49:07 --> Language Class Initialized
INFO - 2024-02-28 23:49:07 --> Loader Class Initialized
INFO - 2024-02-28 23:49:07 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:07 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:07 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:07 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:07 --> Controller Class Initialized
INFO - 2024-02-28 23:49:07 --> Model "LoginModel" initialized
INFO - 2024-02-28 23:49:07 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:07 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-28 23:49:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:07 --> Config Class Initialized
INFO - 2024-02-28 23:49:07 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:07 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:07 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:07 --> URI Class Initialized
INFO - 2024-02-28 23:49:07 --> Router Class Initialized
INFO - 2024-02-28 23:49:07 --> Output Class Initialized
INFO - 2024-02-28 23:49:07 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:07 --> Input Class Initialized
INFO - 2024-02-28 23:49:07 --> Language Class Initialized
INFO - 2024-02-28 23:49:07 --> Loader Class Initialized
INFO - 2024-02-28 23:49:07 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:07 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:07 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:07 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:07 --> Controller Class Initialized
INFO - 2024-02-28 23:49:07 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:07 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:49:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 23:49:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-28 23:49:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-28 23:49:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 23:49:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 23:49:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 23:49:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-28 23:49:07 --> Final output sent to browser
DEBUG - 2024-02-28 23:49:07 --> Total execution time: 0.0304
ERROR - 2024-02-28 23:49:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:07 --> Config Class Initialized
INFO - 2024-02-28 23:49:07 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:07 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:07 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:07 --> URI Class Initialized
INFO - 2024-02-28 23:49:07 --> Router Class Initialized
INFO - 2024-02-28 23:49:07 --> Output Class Initialized
INFO - 2024-02-28 23:49:07 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:07 --> Input Class Initialized
INFO - 2024-02-28 23:49:07 --> Language Class Initialized
INFO - 2024-02-28 23:49:07 --> Loader Class Initialized
INFO - 2024-02-28 23:49:07 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:07 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:07 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:07 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:07 --> Controller Class Initialized
INFO - 2024-02-28 23:49:07 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:07 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:49:07 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:09 --> Config Class Initialized
INFO - 2024-02-28 23:49:09 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:09 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:09 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:09 --> URI Class Initialized
INFO - 2024-02-28 23:49:09 --> Router Class Initialized
INFO - 2024-02-28 23:49:09 --> Output Class Initialized
INFO - 2024-02-28 23:49:09 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:09 --> Input Class Initialized
INFO - 2024-02-28 23:49:09 --> Language Class Initialized
INFO - 2024-02-28 23:49:09 --> Loader Class Initialized
INFO - 2024-02-28 23:49:09 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:09 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:09 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:10 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:10 --> Controller Class Initialized
INFO - 2024-02-28 23:49:10 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:10 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 23:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-28 23:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 23:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 23:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 23:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-28 23:49:10 --> Final output sent to browser
DEBUG - 2024-02-28 23:49:10 --> Total execution time: 0.0290
ERROR - 2024-02-28 23:49:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:10 --> Config Class Initialized
INFO - 2024-02-28 23:49:10 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:10 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:10 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:10 --> URI Class Initialized
INFO - 2024-02-28 23:49:10 --> Router Class Initialized
INFO - 2024-02-28 23:49:10 --> Output Class Initialized
INFO - 2024-02-28 23:49:10 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:10 --> Input Class Initialized
INFO - 2024-02-28 23:49:10 --> Language Class Initialized
INFO - 2024-02-28 23:49:10 --> Loader Class Initialized
INFO - 2024-02-28 23:49:10 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:10 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:10 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:10 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:10 --> Controller Class Initialized
INFO - 2024-02-28 23:49:10 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:10 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:49:10 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:49:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:15 --> Config Class Initialized
INFO - 2024-02-28 23:49:15 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:15 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:15 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:15 --> URI Class Initialized
INFO - 2024-02-28 23:49:15 --> Router Class Initialized
INFO - 2024-02-28 23:49:15 --> Output Class Initialized
INFO - 2024-02-28 23:49:15 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:15 --> Input Class Initialized
INFO - 2024-02-28 23:49:15 --> Language Class Initialized
INFO - 2024-02-28 23:49:15 --> Loader Class Initialized
INFO - 2024-02-28 23:49:15 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:15 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:15 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:15 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:15 --> Controller Class Initialized
INFO - 2024-02-28 23:49:15 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:15 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:49:15 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:49:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:49:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:49:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:49:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:49:15 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:49:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:49:15 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:49:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-28 23:49:15 --> Final output sent to browser
DEBUG - 2024-02-28 23:49:15 --> Total execution time: 0.0362
ERROR - 2024-02-28 23:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:23 --> Config Class Initialized
INFO - 2024-02-28 23:49:23 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:23 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:23 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:23 --> URI Class Initialized
INFO - 2024-02-28 23:49:23 --> Router Class Initialized
INFO - 2024-02-28 23:49:23 --> Output Class Initialized
INFO - 2024-02-28 23:49:23 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:23 --> Input Class Initialized
INFO - 2024-02-28 23:49:23 --> Language Class Initialized
INFO - 2024-02-28 23:49:23 --> Loader Class Initialized
INFO - 2024-02-28 23:49:23 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:23 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:23 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:23 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:23 --> Controller Class Initialized
INFO - 2024-02-28 23:49:23 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:23 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:23 --> Config Class Initialized
INFO - 2024-02-28 23:49:23 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:23 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:23 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:23 --> URI Class Initialized
INFO - 2024-02-28 23:49:23 --> Router Class Initialized
INFO - 2024-02-28 23:49:23 --> Output Class Initialized
INFO - 2024-02-28 23:49:23 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:23 --> Input Class Initialized
INFO - 2024-02-28 23:49:23 --> Language Class Initialized
INFO - 2024-02-28 23:49:23 --> Loader Class Initialized
INFO - 2024-02-28 23:49:23 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:23 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:23 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:23 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:23 --> Controller Class Initialized
INFO - 2024-02-28 23:49:23 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:23 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:49:23 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:49:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:26 --> Config Class Initialized
INFO - 2024-02-28 23:49:26 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:26 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:26 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:26 --> URI Class Initialized
INFO - 2024-02-28 23:49:26 --> Router Class Initialized
INFO - 2024-02-28 23:49:26 --> Output Class Initialized
INFO - 2024-02-28 23:49:26 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:26 --> Input Class Initialized
INFO - 2024-02-28 23:49:26 --> Language Class Initialized
INFO - 2024-02-28 23:49:26 --> Loader Class Initialized
INFO - 2024-02-28 23:49:26 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:26 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:26 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:26 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:26 --> Controller Class Initialized
INFO - 2024-02-28 23:49:26 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:26 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:49:26 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:49:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:49:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:49:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:49:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:49:26 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:49:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:49:26 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 23:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 23:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 23:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 23:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 23:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-28 23:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-28 23:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-28 23:49:26 --> Final output sent to browser
DEBUG - 2024-02-28 23:49:26 --> Total execution time: 0.0492
ERROR - 2024-02-28 23:49:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:27 --> Config Class Initialized
INFO - 2024-02-28 23:49:27 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:27 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:27 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:27 --> URI Class Initialized
INFO - 2024-02-28 23:49:27 --> Router Class Initialized
INFO - 2024-02-28 23:49:27 --> Output Class Initialized
INFO - 2024-02-28 23:49:27 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:27 --> Input Class Initialized
INFO - 2024-02-28 23:49:27 --> Language Class Initialized
INFO - 2024-02-28 23:49:27 --> Loader Class Initialized
INFO - 2024-02-28 23:49:27 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:27 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:27 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:27 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:27 --> Controller Class Initialized
INFO - 2024-02-28 23:49:27 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:27 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:49:27 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:49:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:49:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:49:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:49:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:49:27 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:49:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:49:27 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:49:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:30 --> Config Class Initialized
INFO - 2024-02-28 23:49:30 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:30 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:30 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:30 --> URI Class Initialized
INFO - 2024-02-28 23:49:30 --> Router Class Initialized
INFO - 2024-02-28 23:49:30 --> Output Class Initialized
INFO - 2024-02-28 23:49:30 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:30 --> Input Class Initialized
INFO - 2024-02-28 23:49:30 --> Language Class Initialized
INFO - 2024-02-28 23:49:30 --> Loader Class Initialized
INFO - 2024-02-28 23:49:30 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:30 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:30 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:30 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:30 --> Controller Class Initialized
INFO - 2024-02-28 23:49:30 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:30 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:49:30 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:49:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:49:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:49:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:49:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:49:30 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:49:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:49:30 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:49:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:49:33 --> Config Class Initialized
INFO - 2024-02-28 23:49:33 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:49:33 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:49:33 --> Utf8 Class Initialized
INFO - 2024-02-28 23:49:33 --> URI Class Initialized
INFO - 2024-02-28 23:49:33 --> Router Class Initialized
INFO - 2024-02-28 23:49:33 --> Output Class Initialized
INFO - 2024-02-28 23:49:33 --> Security Class Initialized
DEBUG - 2024-02-28 23:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:49:33 --> Input Class Initialized
INFO - 2024-02-28 23:49:33 --> Language Class Initialized
INFO - 2024-02-28 23:49:33 --> Loader Class Initialized
INFO - 2024-02-28 23:49:33 --> Helper loaded: url_helper
INFO - 2024-02-28 23:49:33 --> Helper loaded: file_helper
INFO - 2024-02-28 23:49:33 --> Helper loaded: form_helper
INFO - 2024-02-28 23:49:33 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:49:33 --> Controller Class Initialized
INFO - 2024-02-28 23:49:33 --> Form Validation Class Initialized
INFO - 2024-02-28 23:49:33 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:49:33 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:49:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:49:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:49:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:49:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:49:33 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:49:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:49:33 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:49:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-02-28 23:49:33 --> Final output sent to browser
DEBUG - 2024-02-28 23:49:33 --> Total execution time: 0.0338
ERROR - 2024-02-28 23:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:50:09 --> Config Class Initialized
INFO - 2024-02-28 23:50:09 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:50:09 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:50:09 --> Utf8 Class Initialized
INFO - 2024-02-28 23:50:09 --> URI Class Initialized
INFO - 2024-02-28 23:50:09 --> Router Class Initialized
INFO - 2024-02-28 23:50:09 --> Output Class Initialized
INFO - 2024-02-28 23:50:09 --> Security Class Initialized
DEBUG - 2024-02-28 23:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:50:09 --> Input Class Initialized
INFO - 2024-02-28 23:50:09 --> Language Class Initialized
INFO - 2024-02-28 23:50:09 --> Loader Class Initialized
INFO - 2024-02-28 23:50:09 --> Helper loaded: url_helper
INFO - 2024-02-28 23:50:09 --> Helper loaded: file_helper
INFO - 2024-02-28 23:50:09 --> Helper loaded: form_helper
INFO - 2024-02-28 23:50:09 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:50:09 --> Controller Class Initialized
INFO - 2024-02-28 23:50:09 --> Form Validation Class Initialized
INFO - 2024-02-28 23:50:09 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:50:09 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:50:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:50:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:50:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:50:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:50:09 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:50:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:50:09 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:50:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 23:50:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 23:50:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 23:50:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 23:50:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 23:50:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-28 23:50:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-28 23:50:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-28 23:50:09 --> Final output sent to browser
DEBUG - 2024-02-28 23:50:09 --> Total execution time: 0.0386
ERROR - 2024-02-28 23:50:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:50:10 --> Config Class Initialized
INFO - 2024-02-28 23:50:10 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:50:10 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:50:10 --> Utf8 Class Initialized
INFO - 2024-02-28 23:50:10 --> URI Class Initialized
INFO - 2024-02-28 23:50:10 --> Router Class Initialized
INFO - 2024-02-28 23:50:10 --> Output Class Initialized
INFO - 2024-02-28 23:50:10 --> Security Class Initialized
DEBUG - 2024-02-28 23:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:50:10 --> Input Class Initialized
INFO - 2024-02-28 23:50:10 --> Language Class Initialized
INFO - 2024-02-28 23:50:10 --> Loader Class Initialized
INFO - 2024-02-28 23:50:10 --> Helper loaded: url_helper
INFO - 2024-02-28 23:50:10 --> Helper loaded: file_helper
INFO - 2024-02-28 23:50:10 --> Helper loaded: form_helper
INFO - 2024-02-28 23:50:10 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:50:10 --> Controller Class Initialized
ERROR - 2024-02-28 23:50:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:50:10 --> Config Class Initialized
INFO - 2024-02-28 23:50:10 --> Hooks Class Initialized
INFO - 2024-02-28 23:50:10 --> Form Validation Class Initialized
DEBUG - 2024-02-28 23:50:10 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:50:10 --> Utf8 Class Initialized
INFO - 2024-02-28 23:50:10 --> URI Class Initialized
INFO - 2024-02-28 23:50:10 --> Router Class Initialized
INFO - 2024-02-28 23:50:10 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:50:10 --> Output Class Initialized
INFO - 2024-02-28 23:50:10 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:50:10 --> Security Class Initialized
INFO - 2024-02-28 23:50:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ItemGroupModel" initialized
DEBUG - 2024-02-28 23:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:50:10 --> Input Class Initialized
INFO - 2024-02-28 23:50:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:50:10 --> Language Class Initialized
INFO - 2024-02-28 23:50:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:50:10 --> Loader Class Initialized
INFO - 2024-02-28 23:50:10 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:50:10 --> Helper loaded: url_helper
INFO - 2024-02-28 23:50:10 --> Helper loaded: file_helper
INFO - 2024-02-28 23:50:10 --> Helper loaded: form_helper
INFO - 2024-02-28 23:50:10 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:50:10 --> Controller Class Initialized
INFO - 2024-02-28 23:50:10 --> Form Validation Class Initialized
INFO - 2024-02-28 23:50:10 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-28 23:50:10 --> Final output sent to browser
DEBUG - 2024-02-28 23:50:10 --> Total execution time: 0.0441
ERROR - 2024-02-28 23:50:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:50:10 --> Config Class Initialized
INFO - 2024-02-28 23:50:10 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:50:10 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:50:10 --> Utf8 Class Initialized
INFO - 2024-02-28 23:50:10 --> URI Class Initialized
INFO - 2024-02-28 23:50:10 --> Router Class Initialized
INFO - 2024-02-28 23:50:10 --> Output Class Initialized
INFO - 2024-02-28 23:50:10 --> Security Class Initialized
DEBUG - 2024-02-28 23:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:50:10 --> Input Class Initialized
INFO - 2024-02-28 23:50:10 --> Language Class Initialized
INFO - 2024-02-28 23:50:10 --> Loader Class Initialized
INFO - 2024-02-28 23:50:10 --> Helper loaded: url_helper
INFO - 2024-02-28 23:50:10 --> Helper loaded: file_helper
INFO - 2024-02-28 23:50:10 --> Helper loaded: form_helper
INFO - 2024-02-28 23:50:10 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:50:10 --> Controller Class Initialized
INFO - 2024-02-28 23:50:10 --> Form Validation Class Initialized
INFO - 2024-02-28 23:50:10 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-28 23:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-28 23:50:10 --> Final output sent to browser
DEBUG - 2024-02-28 23:50:10 --> Total execution time: 0.0804
ERROR - 2024-02-28 23:50:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:50:10 --> Config Class Initialized
INFO - 2024-02-28 23:50:10 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:50:10 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:50:10 --> Utf8 Class Initialized
INFO - 2024-02-28 23:50:10 --> URI Class Initialized
INFO - 2024-02-28 23:50:10 --> Router Class Initialized
INFO - 2024-02-28 23:50:10 --> Output Class Initialized
INFO - 2024-02-28 23:50:10 --> Security Class Initialized
DEBUG - 2024-02-28 23:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:50:10 --> Input Class Initialized
INFO - 2024-02-28 23:50:10 --> Language Class Initialized
INFO - 2024-02-28 23:50:10 --> Loader Class Initialized
INFO - 2024-02-28 23:50:10 --> Helper loaded: url_helper
INFO - 2024-02-28 23:50:10 --> Helper loaded: file_helper
INFO - 2024-02-28 23:50:10 --> Helper loaded: form_helper
INFO - 2024-02-28 23:50:10 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:50:10 --> Controller Class Initialized
INFO - 2024-02-28 23:50:10 --> Form Validation Class Initialized
INFO - 2024-02-28 23:50:10 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:50:10 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:50:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:50:14 --> Config Class Initialized
INFO - 2024-02-28 23:50:14 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:50:14 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:50:14 --> Utf8 Class Initialized
INFO - 2024-02-28 23:50:14 --> URI Class Initialized
INFO - 2024-02-28 23:50:14 --> Router Class Initialized
INFO - 2024-02-28 23:50:14 --> Output Class Initialized
INFO - 2024-02-28 23:50:14 --> Security Class Initialized
DEBUG - 2024-02-28 23:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:50:14 --> Input Class Initialized
INFO - 2024-02-28 23:50:14 --> Language Class Initialized
INFO - 2024-02-28 23:50:14 --> Loader Class Initialized
INFO - 2024-02-28 23:50:14 --> Helper loaded: url_helper
INFO - 2024-02-28 23:50:14 --> Helper loaded: file_helper
INFO - 2024-02-28 23:50:14 --> Helper loaded: form_helper
INFO - 2024-02-28 23:50:14 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:50:14 --> Controller Class Initialized
INFO - 2024-02-28 23:50:14 --> Form Validation Class Initialized
INFO - 2024-02-28 23:50:14 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:50:14 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:50:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:50:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:50:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:50:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:50:14 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:50:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:50:14 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:50:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-02-28 23:50:14 --> Final output sent to browser
DEBUG - 2024-02-28 23:50:14 --> Total execution time: 0.0439
ERROR - 2024-02-28 23:51:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:51:07 --> Config Class Initialized
INFO - 2024-02-28 23:51:07 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:51:07 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:51:07 --> Utf8 Class Initialized
INFO - 2024-02-28 23:51:07 --> URI Class Initialized
INFO - 2024-02-28 23:51:07 --> Router Class Initialized
INFO - 2024-02-28 23:51:07 --> Output Class Initialized
INFO - 2024-02-28 23:51:07 --> Security Class Initialized
DEBUG - 2024-02-28 23:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:51:07 --> Input Class Initialized
INFO - 2024-02-28 23:51:07 --> Language Class Initialized
INFO - 2024-02-28 23:51:07 --> Loader Class Initialized
INFO - 2024-02-28 23:51:07 --> Helper loaded: url_helper
INFO - 2024-02-28 23:51:07 --> Helper loaded: file_helper
INFO - 2024-02-28 23:51:07 --> Helper loaded: form_helper
INFO - 2024-02-28 23:51:07 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:51:07 --> Controller Class Initialized
INFO - 2024-02-28 23:51:07 --> Form Validation Class Initialized
INFO - 2024-02-28 23:51:07 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:51:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 23:51:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 23:51:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 23:51:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 23:51:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 23:51:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-28 23:51:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-28 23:51:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-28 23:51:07 --> Final output sent to browser
DEBUG - 2024-02-28 23:51:07 --> Total execution time: 0.0468
ERROR - 2024-02-28 23:51:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:51:07 --> Config Class Initialized
INFO - 2024-02-28 23:51:07 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:51:07 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:51:07 --> Utf8 Class Initialized
INFO - 2024-02-28 23:51:07 --> URI Class Initialized
INFO - 2024-02-28 23:51:07 --> Router Class Initialized
INFO - 2024-02-28 23:51:07 --> Output Class Initialized
INFO - 2024-02-28 23:51:07 --> Security Class Initialized
DEBUG - 2024-02-28 23:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:51:07 --> Input Class Initialized
INFO - 2024-02-28 23:51:07 --> Language Class Initialized
INFO - 2024-02-28 23:51:07 --> Loader Class Initialized
INFO - 2024-02-28 23:51:07 --> Helper loaded: url_helper
INFO - 2024-02-28 23:51:07 --> Helper loaded: file_helper
INFO - 2024-02-28 23:51:07 --> Helper loaded: form_helper
INFO - 2024-02-28 23:51:07 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:51:07 --> Controller Class Initialized
INFO - 2024-02-28 23:51:07 --> Form Validation Class Initialized
INFO - 2024-02-28 23:51:07 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:51:07 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:51:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:51:10 --> Config Class Initialized
INFO - 2024-02-28 23:51:10 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:51:10 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:51:10 --> Utf8 Class Initialized
INFO - 2024-02-28 23:51:10 --> URI Class Initialized
INFO - 2024-02-28 23:51:10 --> Router Class Initialized
INFO - 2024-02-28 23:51:10 --> Output Class Initialized
INFO - 2024-02-28 23:51:10 --> Security Class Initialized
DEBUG - 2024-02-28 23:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:51:10 --> Input Class Initialized
INFO - 2024-02-28 23:51:10 --> Language Class Initialized
INFO - 2024-02-28 23:51:10 --> Loader Class Initialized
INFO - 2024-02-28 23:51:10 --> Helper loaded: url_helper
INFO - 2024-02-28 23:51:10 --> Helper loaded: file_helper
INFO - 2024-02-28 23:51:10 --> Helper loaded: form_helper
INFO - 2024-02-28 23:51:11 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:51:11 --> Controller Class Initialized
INFO - 2024-02-28 23:51:11 --> Form Validation Class Initialized
INFO - 2024-02-28 23:51:11 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:51:11 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:51:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:51:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:51:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:51:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:51:11 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:51:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:51:11 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:51:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-02-28 23:51:11 --> Final output sent to browser
DEBUG - 2024-02-28 23:51:11 --> Total execution time: 0.0434
ERROR - 2024-02-28 23:53:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:53:25 --> Config Class Initialized
INFO - 2024-02-28 23:53:25 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:53:25 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:53:25 --> Utf8 Class Initialized
INFO - 2024-02-28 23:53:25 --> URI Class Initialized
INFO - 2024-02-28 23:53:25 --> Router Class Initialized
INFO - 2024-02-28 23:53:25 --> Output Class Initialized
INFO - 2024-02-28 23:53:25 --> Security Class Initialized
DEBUG - 2024-02-28 23:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:53:25 --> Input Class Initialized
INFO - 2024-02-28 23:53:25 --> Language Class Initialized
INFO - 2024-02-28 23:53:25 --> Loader Class Initialized
INFO - 2024-02-28 23:53:25 --> Helper loaded: url_helper
INFO - 2024-02-28 23:53:25 --> Helper loaded: file_helper
INFO - 2024-02-28 23:53:25 --> Helper loaded: form_helper
INFO - 2024-02-28 23:53:25 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:53:25 --> Controller Class Initialized
INFO - 2024-02-28 23:53:25 --> Form Validation Class Initialized
INFO - 2024-02-28 23:53:25 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-28 23:53:25 --> Final output sent to browser
DEBUG - 2024-02-28 23:53:25 --> Total execution time: 0.0600
ERROR - 2024-02-28 23:53:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:53:25 --> Config Class Initialized
INFO - 2024-02-28 23:53:25 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:53:25 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:53:25 --> Utf8 Class Initialized
INFO - 2024-02-28 23:53:25 --> URI Class Initialized
INFO - 2024-02-28 23:53:25 --> Router Class Initialized
INFO - 2024-02-28 23:53:25 --> Output Class Initialized
INFO - 2024-02-28 23:53:25 --> Security Class Initialized
DEBUG - 2024-02-28 23:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:53:25 --> Input Class Initialized
INFO - 2024-02-28 23:53:25 --> Language Class Initialized
INFO - 2024-02-28 23:53:25 --> Loader Class Initialized
INFO - 2024-02-28 23:53:25 --> Helper loaded: url_helper
INFO - 2024-02-28 23:53:25 --> Helper loaded: file_helper
INFO - 2024-02-28 23:53:25 --> Helper loaded: form_helper
INFO - 2024-02-28 23:53:25 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:53:25 --> Controller Class Initialized
INFO - 2024-02-28 23:53:25 --> Form Validation Class Initialized
INFO - 2024-02-28 23:53:25 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:53:25 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-28 23:53:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-28 23:53:25 --> Final output sent to browser
DEBUG - 2024-02-28 23:53:25 --> Total execution time: 0.0330
ERROR - 2024-02-28 23:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:53:27 --> Config Class Initialized
INFO - 2024-02-28 23:53:27 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:53:27 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:53:27 --> Utf8 Class Initialized
INFO - 2024-02-28 23:53:27 --> URI Class Initialized
INFO - 2024-02-28 23:53:27 --> Router Class Initialized
INFO - 2024-02-28 23:53:27 --> Output Class Initialized
INFO - 2024-02-28 23:53:27 --> Security Class Initialized
DEBUG - 2024-02-28 23:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:53:27 --> Input Class Initialized
INFO - 2024-02-28 23:53:27 --> Language Class Initialized
INFO - 2024-02-28 23:53:27 --> Loader Class Initialized
INFO - 2024-02-28 23:53:27 --> Helper loaded: url_helper
INFO - 2024-02-28 23:53:27 --> Helper loaded: file_helper
INFO - 2024-02-28 23:53:27 --> Helper loaded: form_helper
INFO - 2024-02-28 23:53:27 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:53:27 --> Controller Class Initialized
INFO - 2024-02-28 23:53:27 --> Form Validation Class Initialized
INFO - 2024-02-28 23:53:27 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:53:27 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:53:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:53:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:53:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:53:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:53:27 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:53:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:53:27 --> Model "ReportModel" initialized
ERROR - 2024-02-28 23:53:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-28 23:53:30 --> Config Class Initialized
INFO - 2024-02-28 23:53:30 --> Hooks Class Initialized
DEBUG - 2024-02-28 23:53:30 --> UTF-8 Support Enabled
INFO - 2024-02-28 23:53:30 --> Utf8 Class Initialized
INFO - 2024-02-28 23:53:30 --> URI Class Initialized
INFO - 2024-02-28 23:53:30 --> Router Class Initialized
INFO - 2024-02-28 23:53:30 --> Output Class Initialized
INFO - 2024-02-28 23:53:30 --> Security Class Initialized
DEBUG - 2024-02-28 23:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-28 23:53:30 --> Input Class Initialized
INFO - 2024-02-28 23:53:30 --> Language Class Initialized
INFO - 2024-02-28 23:53:30 --> Loader Class Initialized
INFO - 2024-02-28 23:53:30 --> Helper loaded: url_helper
INFO - 2024-02-28 23:53:30 --> Helper loaded: file_helper
INFO - 2024-02-28 23:53:30 --> Helper loaded: form_helper
INFO - 2024-02-28 23:53:30 --> Database Driver Class Initialized
DEBUG - 2024-02-28 23:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-28 23:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-28 23:53:30 --> Controller Class Initialized
INFO - 2024-02-28 23:53:30 --> Form Validation Class Initialized
INFO - 2024-02-28 23:53:30 --> Model "MasterModel" initialized
INFO - 2024-02-28 23:53:30 --> Model "DashboardModel" initialized
INFO - 2024-02-28 23:53:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-28 23:53:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-28 23:53:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-28 23:53:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-28 23:53:30 --> Model "OrderModel" initialized
INFO - 2024-02-28 23:53:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-28 23:53:30 --> Model "ReportModel" initialized
INFO - 2024-02-28 23:53:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-02-28 23:53:30 --> Final output sent to browser
DEBUG - 2024-02-28 23:53:30 --> Total execution time: 0.0378
