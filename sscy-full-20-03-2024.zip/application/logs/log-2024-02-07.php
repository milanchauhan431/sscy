<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-07 11:55:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 11:55:35 --> Config Class Initialized
INFO - 2024-02-07 11:55:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 11:55:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 11:55:35 --> Utf8 Class Initialized
INFO - 2024-02-07 11:55:35 --> URI Class Initialized
INFO - 2024-02-07 11:55:35 --> Router Class Initialized
INFO - 2024-02-07 11:55:35 --> Output Class Initialized
INFO - 2024-02-07 11:55:35 --> Security Class Initialized
DEBUG - 2024-02-07 11:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 11:55:35 --> Input Class Initialized
INFO - 2024-02-07 11:55:35 --> Language Class Initialized
INFO - 2024-02-07 11:55:35 --> Loader Class Initialized
INFO - 2024-02-07 11:55:35 --> Helper loaded: url_helper
INFO - 2024-02-07 11:55:35 --> Helper loaded: file_helper
INFO - 2024-02-07 11:55:35 --> Helper loaded: form_helper
INFO - 2024-02-07 11:55:35 --> Database Driver Class Initialized
DEBUG - 2024-02-07 11:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 11:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 11:55:35 --> Controller Class Initialized
INFO - 2024-02-07 11:55:35 --> Model "LoginModel" initialized
INFO - 2024-02-07 11:55:35 --> Form Validation Class Initialized
INFO - 2024-02-07 11:55:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-07 11:55:35 --> Final output sent to browser
DEBUG - 2024-02-07 11:55:35 --> Total execution time: 0.0352
ERROR - 2024-02-07 11:55:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 11:55:38 --> Config Class Initialized
INFO - 2024-02-07 11:55:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 11:55:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 11:55:38 --> Utf8 Class Initialized
INFO - 2024-02-07 11:55:38 --> URI Class Initialized
INFO - 2024-02-07 11:55:38 --> Router Class Initialized
INFO - 2024-02-07 11:55:38 --> Output Class Initialized
INFO - 2024-02-07 11:55:38 --> Security Class Initialized
DEBUG - 2024-02-07 11:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 11:55:38 --> Input Class Initialized
INFO - 2024-02-07 11:55:38 --> Language Class Initialized
INFO - 2024-02-07 11:55:38 --> Loader Class Initialized
INFO - 2024-02-07 11:55:38 --> Helper loaded: url_helper
INFO - 2024-02-07 11:55:38 --> Helper loaded: file_helper
INFO - 2024-02-07 11:55:38 --> Helper loaded: form_helper
INFO - 2024-02-07 11:55:38 --> Database Driver Class Initialized
DEBUG - 2024-02-07 11:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 11:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 11:55:38 --> Controller Class Initialized
INFO - 2024-02-07 11:55:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 11:55:38 --> Final output sent to browser
DEBUG - 2024-02-07 11:55:38 --> Total execution time: 0.0296
ERROR - 2024-02-07 18:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:34:08 --> Config Class Initialized
INFO - 2024-02-07 18:34:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:34:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:34:08 --> Utf8 Class Initialized
INFO - 2024-02-07 18:34:08 --> URI Class Initialized
INFO - 2024-02-07 18:34:08 --> Router Class Initialized
INFO - 2024-02-07 18:34:08 --> Output Class Initialized
INFO - 2024-02-07 18:34:08 --> Security Class Initialized
DEBUG - 2024-02-07 18:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:34:08 --> Input Class Initialized
INFO - 2024-02-07 18:34:08 --> Language Class Initialized
INFO - 2024-02-07 18:34:08 --> Loader Class Initialized
INFO - 2024-02-07 18:34:08 --> Helper loaded: url_helper
INFO - 2024-02-07 18:34:08 --> Helper loaded: file_helper
INFO - 2024-02-07 18:34:08 --> Helper loaded: form_helper
INFO - 2024-02-07 18:34:08 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:34:08 --> Controller Class Initialized
INFO - 2024-02-07 18:34:08 --> Model "LoginModel" initialized
INFO - 2024-02-07 18:34:08 --> Form Validation Class Initialized
ERROR - 2024-02-07 18:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:34:08 --> Config Class Initialized
INFO - 2024-02-07 18:34:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:34:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:34:08 --> Utf8 Class Initialized
INFO - 2024-02-07 18:34:08 --> URI Class Initialized
INFO - 2024-02-07 18:34:08 --> Router Class Initialized
INFO - 2024-02-07 18:34:08 --> Output Class Initialized
INFO - 2024-02-07 18:34:08 --> Security Class Initialized
DEBUG - 2024-02-07 18:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:34:08 --> Input Class Initialized
INFO - 2024-02-07 18:34:08 --> Language Class Initialized
INFO - 2024-02-07 18:34:08 --> Loader Class Initialized
INFO - 2024-02-07 18:34:08 --> Helper loaded: url_helper
INFO - 2024-02-07 18:34:08 --> Helper loaded: file_helper
INFO - 2024-02-07 18:34:08 --> Helper loaded: form_helper
INFO - 2024-02-07 18:34:08 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:34:08 --> Controller Class Initialized
INFO - 2024-02-07 18:34:08 --> Form Validation Class Initialized
INFO - 2024-02-07 18:34:08 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:34:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:34:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:34:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-07 18:34:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:34:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:34:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:34:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-07 18:34:08 --> Final output sent to browser
DEBUG - 2024-02-07 18:34:08 --> Total execution time: 0.0211
ERROR - 2024-02-07 18:34:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:34:10 --> Config Class Initialized
INFO - 2024-02-07 18:34:10 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:34:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:34:11 --> Utf8 Class Initialized
INFO - 2024-02-07 18:34:11 --> URI Class Initialized
INFO - 2024-02-07 18:34:11 --> Router Class Initialized
INFO - 2024-02-07 18:34:11 --> Output Class Initialized
INFO - 2024-02-07 18:34:11 --> Security Class Initialized
DEBUG - 2024-02-07 18:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:34:11 --> Input Class Initialized
INFO - 2024-02-07 18:34:11 --> Language Class Initialized
INFO - 2024-02-07 18:34:11 --> Loader Class Initialized
INFO - 2024-02-07 18:34:11 --> Helper loaded: url_helper
INFO - 2024-02-07 18:34:11 --> Helper loaded: file_helper
INFO - 2024-02-07 18:34:11 --> Helper loaded: form_helper
INFO - 2024-02-07 18:34:11 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:34:11 --> Controller Class Initialized
INFO - 2024-02-07 18:34:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 18:34:11 --> Final output sent to browser
DEBUG - 2024-02-07 18:34:11 --> Total execution time: 0.0240
ERROR - 2024-02-07 18:34:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:34:12 --> Config Class Initialized
INFO - 2024-02-07 18:34:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:34:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:34:12 --> Utf8 Class Initialized
INFO - 2024-02-07 18:34:12 --> URI Class Initialized
INFO - 2024-02-07 18:34:12 --> Router Class Initialized
INFO - 2024-02-07 18:34:12 --> Output Class Initialized
INFO - 2024-02-07 18:34:12 --> Security Class Initialized
DEBUG - 2024-02-07 18:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:34:12 --> Input Class Initialized
INFO - 2024-02-07 18:34:12 --> Language Class Initialized
INFO - 2024-02-07 18:34:12 --> Loader Class Initialized
INFO - 2024-02-07 18:34:12 --> Helper loaded: url_helper
INFO - 2024-02-07 18:34:12 --> Helper loaded: file_helper
INFO - 2024-02-07 18:34:12 --> Helper loaded: form_helper
INFO - 2024-02-07 18:34:12 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:34:12 --> Controller Class Initialized
INFO - 2024-02-07 18:34:12 --> Form Validation Class Initialized
INFO - 2024-02-07 18:34:12 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:34:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:34:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:34:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:34:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:34:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:34:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:34:12 --> Final output sent to browser
DEBUG - 2024-02-07 18:34:12 --> Total execution time: 0.0246
ERROR - 2024-02-07 18:34:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:34:12 --> Config Class Initialized
INFO - 2024-02-07 18:34:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:34:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:34:12 --> Utf8 Class Initialized
INFO - 2024-02-07 18:34:12 --> URI Class Initialized
INFO - 2024-02-07 18:34:12 --> Router Class Initialized
INFO - 2024-02-07 18:34:12 --> Output Class Initialized
INFO - 2024-02-07 18:34:12 --> Security Class Initialized
DEBUG - 2024-02-07 18:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:34:12 --> Input Class Initialized
INFO - 2024-02-07 18:34:12 --> Language Class Initialized
INFO - 2024-02-07 18:34:12 --> Loader Class Initialized
INFO - 2024-02-07 18:34:12 --> Helper loaded: url_helper
INFO - 2024-02-07 18:34:12 --> Helper loaded: file_helper
INFO - 2024-02-07 18:34:12 --> Helper loaded: form_helper
INFO - 2024-02-07 18:34:12 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:34:12 --> Controller Class Initialized
INFO - 2024-02-07 18:34:12 --> Form Validation Class Initialized
INFO - 2024-02-07 18:34:12 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:34:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:34:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:34:14 --> Config Class Initialized
INFO - 2024-02-07 18:34:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:34:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:34:14 --> Utf8 Class Initialized
INFO - 2024-02-07 18:34:14 --> URI Class Initialized
INFO - 2024-02-07 18:34:14 --> Router Class Initialized
INFO - 2024-02-07 18:34:14 --> Output Class Initialized
INFO - 2024-02-07 18:34:14 --> Security Class Initialized
DEBUG - 2024-02-07 18:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:34:14 --> Input Class Initialized
INFO - 2024-02-07 18:34:14 --> Language Class Initialized
INFO - 2024-02-07 18:34:14 --> Loader Class Initialized
INFO - 2024-02-07 18:34:14 --> Helper loaded: url_helper
INFO - 2024-02-07 18:34:14 --> Helper loaded: file_helper
INFO - 2024-02-07 18:34:14 --> Helper loaded: form_helper
INFO - 2024-02-07 18:34:14 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:34:14 --> Controller Class Initialized
INFO - 2024-02-07 18:34:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 18:34:14 --> Final output sent to browser
DEBUG - 2024-02-07 18:34:14 --> Total execution time: 0.0271
ERROR - 2024-02-07 18:34:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:34:33 --> Config Class Initialized
INFO - 2024-02-07 18:34:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:34:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:34:33 --> Utf8 Class Initialized
INFO - 2024-02-07 18:34:33 --> URI Class Initialized
INFO - 2024-02-07 18:34:33 --> Router Class Initialized
INFO - 2024-02-07 18:34:33 --> Output Class Initialized
INFO - 2024-02-07 18:34:33 --> Security Class Initialized
DEBUG - 2024-02-07 18:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:34:33 --> Input Class Initialized
INFO - 2024-02-07 18:34:33 --> Language Class Initialized
INFO - 2024-02-07 18:34:33 --> Loader Class Initialized
INFO - 2024-02-07 18:34:33 --> Helper loaded: url_helper
INFO - 2024-02-07 18:34:33 --> Helper loaded: file_helper
INFO - 2024-02-07 18:34:33 --> Helper loaded: form_helper
INFO - 2024-02-07 18:34:33 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:34:33 --> Controller Class Initialized
INFO - 2024-02-07 18:34:33 --> Form Validation Class Initialized
INFO - 2024-02-07 18:34:33 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:34:33 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:34:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:34:36 --> Config Class Initialized
INFO - 2024-02-07 18:34:36 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:34:36 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:34:36 --> Utf8 Class Initialized
INFO - 2024-02-07 18:34:36 --> URI Class Initialized
INFO - 2024-02-07 18:34:36 --> Router Class Initialized
INFO - 2024-02-07 18:34:36 --> Output Class Initialized
INFO - 2024-02-07 18:34:36 --> Security Class Initialized
DEBUG - 2024-02-07 18:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:34:36 --> Input Class Initialized
INFO - 2024-02-07 18:34:36 --> Language Class Initialized
INFO - 2024-02-07 18:34:36 --> Loader Class Initialized
INFO - 2024-02-07 18:34:36 --> Helper loaded: url_helper
INFO - 2024-02-07 18:34:36 --> Helper loaded: file_helper
INFO - 2024-02-07 18:34:36 --> Helper loaded: form_helper
INFO - 2024-02-07 18:34:36 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:34:36 --> Controller Class Initialized
INFO - 2024-02-07 18:34:36 --> Form Validation Class Initialized
INFO - 2024-02-07 18:34:36 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:34:36 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:34:39 --> Config Class Initialized
INFO - 2024-02-07 18:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:34:39 --> Utf8 Class Initialized
INFO - 2024-02-07 18:34:39 --> URI Class Initialized
INFO - 2024-02-07 18:34:39 --> Router Class Initialized
INFO - 2024-02-07 18:34:39 --> Output Class Initialized
INFO - 2024-02-07 18:34:39 --> Security Class Initialized
DEBUG - 2024-02-07 18:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:34:39 --> Input Class Initialized
INFO - 2024-02-07 18:34:39 --> Language Class Initialized
INFO - 2024-02-07 18:34:39 --> Loader Class Initialized
INFO - 2024-02-07 18:34:39 --> Helper loaded: url_helper
INFO - 2024-02-07 18:34:39 --> Helper loaded: file_helper
INFO - 2024-02-07 18:34:39 --> Helper loaded: form_helper
INFO - 2024-02-07 18:34:39 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:34:39 --> Controller Class Initialized
INFO - 2024-02-07 18:34:39 --> Form Validation Class Initialized
INFO - 2024-02-07 18:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 18:34:39 --> Final output sent to browser
DEBUG - 2024-02-07 18:34:39 --> Total execution time: 0.0297
ERROR - 2024-02-07 18:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:37:45 --> Config Class Initialized
INFO - 2024-02-07 18:37:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:37:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:37:45 --> Utf8 Class Initialized
INFO - 2024-02-07 18:37:45 --> URI Class Initialized
INFO - 2024-02-07 18:37:45 --> Router Class Initialized
INFO - 2024-02-07 18:37:45 --> Output Class Initialized
INFO - 2024-02-07 18:37:45 --> Security Class Initialized
DEBUG - 2024-02-07 18:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:37:45 --> Input Class Initialized
INFO - 2024-02-07 18:37:45 --> Language Class Initialized
INFO - 2024-02-07 18:37:45 --> Loader Class Initialized
INFO - 2024-02-07 18:37:45 --> Helper loaded: url_helper
INFO - 2024-02-07 18:37:45 --> Helper loaded: file_helper
INFO - 2024-02-07 18:37:45 --> Helper loaded: form_helper
INFO - 2024-02-07 18:37:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:37:45 --> Controller Class Initialized
INFO - 2024-02-07 18:37:45 --> Form Validation Class Initialized
INFO - 2024-02-07 18:37:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:37:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:37:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:37:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:37:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:37:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:37:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:37:45 --> Final output sent to browser
DEBUG - 2024-02-07 18:37:45 --> Total execution time: 0.0297
ERROR - 2024-02-07 18:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:37:45 --> Config Class Initialized
INFO - 2024-02-07 18:37:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:37:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:37:45 --> Utf8 Class Initialized
INFO - 2024-02-07 18:37:45 --> URI Class Initialized
INFO - 2024-02-07 18:37:45 --> Router Class Initialized
INFO - 2024-02-07 18:37:45 --> Output Class Initialized
INFO - 2024-02-07 18:37:45 --> Security Class Initialized
DEBUG - 2024-02-07 18:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:37:45 --> Input Class Initialized
INFO - 2024-02-07 18:37:45 --> Language Class Initialized
INFO - 2024-02-07 18:37:45 --> Loader Class Initialized
INFO - 2024-02-07 18:37:45 --> Helper loaded: url_helper
INFO - 2024-02-07 18:37:45 --> Helper loaded: file_helper
INFO - 2024-02-07 18:37:45 --> Helper loaded: form_helper
INFO - 2024-02-07 18:37:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:37:45 --> Controller Class Initialized
INFO - 2024-02-07 18:37:45 --> Form Validation Class Initialized
INFO - 2024-02-07 18:37:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:37:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:37:47 --> Config Class Initialized
INFO - 2024-02-07 18:37:47 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:37:47 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:37:47 --> Utf8 Class Initialized
INFO - 2024-02-07 18:37:47 --> URI Class Initialized
INFO - 2024-02-07 18:37:47 --> Router Class Initialized
INFO - 2024-02-07 18:37:47 --> Output Class Initialized
INFO - 2024-02-07 18:37:47 --> Security Class Initialized
DEBUG - 2024-02-07 18:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:37:47 --> Input Class Initialized
INFO - 2024-02-07 18:37:47 --> Language Class Initialized
INFO - 2024-02-07 18:37:47 --> Loader Class Initialized
INFO - 2024-02-07 18:37:47 --> Helper loaded: url_helper
INFO - 2024-02-07 18:37:47 --> Helper loaded: file_helper
INFO - 2024-02-07 18:37:47 --> Helper loaded: form_helper
INFO - 2024-02-07 18:37:47 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:37:47 --> Controller Class Initialized
INFO - 2024-02-07 18:37:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 18:37:47 --> Final output sent to browser
DEBUG - 2024-02-07 18:37:47 --> Total execution time: 0.0216
ERROR - 2024-02-07 18:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:37:48 --> Config Class Initialized
INFO - 2024-02-07 18:37:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:37:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:37:48 --> Utf8 Class Initialized
INFO - 2024-02-07 18:37:48 --> URI Class Initialized
INFO - 2024-02-07 18:37:48 --> Router Class Initialized
INFO - 2024-02-07 18:37:48 --> Output Class Initialized
INFO - 2024-02-07 18:37:48 --> Security Class Initialized
DEBUG - 2024-02-07 18:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:37:48 --> Input Class Initialized
INFO - 2024-02-07 18:37:48 --> Language Class Initialized
INFO - 2024-02-07 18:37:48 --> Loader Class Initialized
INFO - 2024-02-07 18:37:48 --> Helper loaded: url_helper
INFO - 2024-02-07 18:37:48 --> Helper loaded: file_helper
INFO - 2024-02-07 18:37:48 --> Helper loaded: form_helper
INFO - 2024-02-07 18:37:48 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:37:48 --> Controller Class Initialized
INFO - 2024-02-07 18:37:48 --> Form Validation Class Initialized
INFO - 2024-02-07 18:37:48 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:37:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:37:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 18:37:48 --> Final output sent to browser
DEBUG - 2024-02-07 18:37:48 --> Total execution time: 0.0309
ERROR - 2024-02-07 18:37:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:37:54 --> Config Class Initialized
INFO - 2024-02-07 18:37:54 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:37:54 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:37:54 --> Utf8 Class Initialized
INFO - 2024-02-07 18:37:54 --> URI Class Initialized
INFO - 2024-02-07 18:37:54 --> Router Class Initialized
INFO - 2024-02-07 18:37:54 --> Output Class Initialized
INFO - 2024-02-07 18:37:54 --> Security Class Initialized
DEBUG - 2024-02-07 18:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:37:54 --> Input Class Initialized
INFO - 2024-02-07 18:37:54 --> Language Class Initialized
INFO - 2024-02-07 18:37:54 --> Loader Class Initialized
INFO - 2024-02-07 18:37:54 --> Helper loaded: url_helper
INFO - 2024-02-07 18:37:54 --> Helper loaded: file_helper
INFO - 2024-02-07 18:37:54 --> Helper loaded: form_helper
INFO - 2024-02-07 18:37:54 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:37:54 --> Controller Class Initialized
INFO - 2024-02-07 18:37:54 --> Form Validation Class Initialized
INFO - 2024-02-07 18:37:54 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:37:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:37:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:37:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:37:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:37:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:37:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:37:54 --> Final output sent to browser
DEBUG - 2024-02-07 18:37:54 --> Total execution time: 0.0356
ERROR - 2024-02-07 18:39:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:39:19 --> Config Class Initialized
INFO - 2024-02-07 18:39:19 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:39:19 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:39:19 --> Utf8 Class Initialized
INFO - 2024-02-07 18:39:19 --> URI Class Initialized
INFO - 2024-02-07 18:39:19 --> Router Class Initialized
INFO - 2024-02-07 18:39:19 --> Output Class Initialized
INFO - 2024-02-07 18:39:19 --> Security Class Initialized
DEBUG - 2024-02-07 18:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:39:19 --> Input Class Initialized
INFO - 2024-02-07 18:39:19 --> Language Class Initialized
INFO - 2024-02-07 18:39:19 --> Loader Class Initialized
INFO - 2024-02-07 18:39:19 --> Helper loaded: url_helper
INFO - 2024-02-07 18:39:19 --> Helper loaded: file_helper
INFO - 2024-02-07 18:39:19 --> Helper loaded: form_helper
INFO - 2024-02-07 18:39:19 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:39:19 --> Controller Class Initialized
INFO - 2024-02-07 18:39:19 --> Form Validation Class Initialized
INFO - 2024-02-07 18:39:19 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:39:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:39:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:39:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:39:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:39:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:39:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:39:19 --> Final output sent to browser
DEBUG - 2024-02-07 18:39:19 --> Total execution time: 0.0364
ERROR - 2024-02-07 18:39:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:39:19 --> Config Class Initialized
INFO - 2024-02-07 18:39:19 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:39:19 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:39:19 --> Utf8 Class Initialized
INFO - 2024-02-07 18:39:19 --> URI Class Initialized
INFO - 2024-02-07 18:39:19 --> Router Class Initialized
INFO - 2024-02-07 18:39:19 --> Output Class Initialized
INFO - 2024-02-07 18:39:19 --> Security Class Initialized
DEBUG - 2024-02-07 18:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:39:19 --> Input Class Initialized
INFO - 2024-02-07 18:39:19 --> Language Class Initialized
INFO - 2024-02-07 18:39:19 --> Loader Class Initialized
INFO - 2024-02-07 18:39:19 --> Helper loaded: url_helper
INFO - 2024-02-07 18:39:19 --> Helper loaded: file_helper
INFO - 2024-02-07 18:39:19 --> Helper loaded: form_helper
INFO - 2024-02-07 18:39:19 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:39:19 --> Controller Class Initialized
INFO - 2024-02-07 18:39:20 --> Form Validation Class Initialized
INFO - 2024-02-07 18:39:20 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:39:20 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:39:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:39:21 --> Config Class Initialized
INFO - 2024-02-07 18:39:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:39:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:39:21 --> Utf8 Class Initialized
INFO - 2024-02-07 18:39:21 --> URI Class Initialized
INFO - 2024-02-07 18:39:21 --> Router Class Initialized
INFO - 2024-02-07 18:39:21 --> Output Class Initialized
INFO - 2024-02-07 18:39:21 --> Security Class Initialized
DEBUG - 2024-02-07 18:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:39:21 --> Input Class Initialized
INFO - 2024-02-07 18:39:21 --> Language Class Initialized
INFO - 2024-02-07 18:39:21 --> Loader Class Initialized
INFO - 2024-02-07 18:39:21 --> Helper loaded: url_helper
INFO - 2024-02-07 18:39:21 --> Helper loaded: file_helper
INFO - 2024-02-07 18:39:21 --> Helper loaded: form_helper
INFO - 2024-02-07 18:39:21 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:39:21 --> Controller Class Initialized
INFO - 2024-02-07 18:39:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 18:39:21 --> Final output sent to browser
DEBUG - 2024-02-07 18:39:21 --> Total execution time: 0.0215
ERROR - 2024-02-07 18:48:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:48:56 --> Config Class Initialized
INFO - 2024-02-07 18:48:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:48:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:48:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:48:56 --> URI Class Initialized
INFO - 2024-02-07 18:48:56 --> Router Class Initialized
INFO - 2024-02-07 18:48:56 --> Output Class Initialized
INFO - 2024-02-07 18:48:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:48:56 --> Input Class Initialized
INFO - 2024-02-07 18:48:56 --> Language Class Initialized
INFO - 2024-02-07 18:48:56 --> Loader Class Initialized
INFO - 2024-02-07 18:48:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:48:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:48:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:48:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:48:56 --> Controller Class Initialized
INFO - 2024-02-07 18:48:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:48:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:48:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:48:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:48:56 --> Total execution time: 0.0289
ERROR - 2024-02-07 18:48:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:48:56 --> Config Class Initialized
INFO - 2024-02-07 18:48:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:48:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:48:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:48:56 --> URI Class Initialized
INFO - 2024-02-07 18:48:56 --> Router Class Initialized
INFO - 2024-02-07 18:48:56 --> Output Class Initialized
INFO - 2024-02-07 18:48:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:48:56 --> Input Class Initialized
INFO - 2024-02-07 18:48:56 --> Language Class Initialized
INFO - 2024-02-07 18:48:56 --> Loader Class Initialized
INFO - 2024-02-07 18:48:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:48:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:48:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:48:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:48:56 --> Controller Class Initialized
INFO - 2024-02-07 18:48:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:48:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:48:56 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:48:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:48:58 --> Config Class Initialized
INFO - 2024-02-07 18:48:58 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:48:58 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:48:58 --> Utf8 Class Initialized
INFO - 2024-02-07 18:48:58 --> URI Class Initialized
INFO - 2024-02-07 18:48:58 --> Router Class Initialized
INFO - 2024-02-07 18:48:58 --> Output Class Initialized
INFO - 2024-02-07 18:48:58 --> Security Class Initialized
DEBUG - 2024-02-07 18:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:48:58 --> Input Class Initialized
INFO - 2024-02-07 18:48:58 --> Language Class Initialized
INFO - 2024-02-07 18:48:58 --> Loader Class Initialized
INFO - 2024-02-07 18:48:58 --> Helper loaded: url_helper
INFO - 2024-02-07 18:48:58 --> Helper loaded: file_helper
INFO - 2024-02-07 18:48:58 --> Helper loaded: form_helper
INFO - 2024-02-07 18:48:58 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:48:58 --> Controller Class Initialized
INFO - 2024-02-07 18:48:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 18:48:58 --> Final output sent to browser
DEBUG - 2024-02-07 18:48:58 --> Total execution time: 0.0221
ERROR - 2024-02-07 18:48:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:48:59 --> Config Class Initialized
INFO - 2024-02-07 18:48:59 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:48:59 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:48:59 --> Utf8 Class Initialized
INFO - 2024-02-07 18:48:59 --> URI Class Initialized
INFO - 2024-02-07 18:48:59 --> Router Class Initialized
INFO - 2024-02-07 18:48:59 --> Output Class Initialized
INFO - 2024-02-07 18:48:59 --> Security Class Initialized
DEBUG - 2024-02-07 18:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:48:59 --> Input Class Initialized
INFO - 2024-02-07 18:48:59 --> Language Class Initialized
INFO - 2024-02-07 18:48:59 --> Loader Class Initialized
INFO - 2024-02-07 18:48:59 --> Helper loaded: url_helper
INFO - 2024-02-07 18:48:59 --> Helper loaded: file_helper
INFO - 2024-02-07 18:48:59 --> Helper loaded: form_helper
INFO - 2024-02-07 18:48:59 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:48:59 --> Controller Class Initialized
INFO - 2024-02-07 18:48:59 --> Form Validation Class Initialized
INFO - 2024-02-07 18:48:59 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:48:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:48:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 18:48:59 --> Final output sent to browser
DEBUG - 2024-02-07 18:48:59 --> Total execution time: 0.0291
ERROR - 2024-02-07 18:50:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:03 --> Config Class Initialized
INFO - 2024-02-07 18:50:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:03 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:03 --> URI Class Initialized
INFO - 2024-02-07 18:50:03 --> Router Class Initialized
INFO - 2024-02-07 18:50:03 --> Output Class Initialized
INFO - 2024-02-07 18:50:03 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:03 --> Input Class Initialized
INFO - 2024-02-07 18:50:03 --> Language Class Initialized
INFO - 2024-02-07 18:50:03 --> Loader Class Initialized
INFO - 2024-02-07 18:50:03 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:03 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:03 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:03 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:03 --> Controller Class Initialized
INFO - 2024-02-07 18:50:03 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:03 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:03 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:03 --> Total execution time: 0.0329
ERROR - 2024-02-07 18:50:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:03 --> Config Class Initialized
INFO - 2024-02-07 18:50:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:03 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:03 --> URI Class Initialized
INFO - 2024-02-07 18:50:03 --> Router Class Initialized
INFO - 2024-02-07 18:50:03 --> Output Class Initialized
INFO - 2024-02-07 18:50:03 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:03 --> Input Class Initialized
INFO - 2024-02-07 18:50:03 --> Language Class Initialized
INFO - 2024-02-07 18:50:03 --> Loader Class Initialized
INFO - 2024-02-07 18:50:03 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:03 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:03 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:03 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:03 --> Controller Class Initialized
INFO - 2024-02-07 18:50:03 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:03 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:03 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:50:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:05 --> Config Class Initialized
INFO - 2024-02-07 18:50:05 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:05 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:05 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:05 --> URI Class Initialized
INFO - 2024-02-07 18:50:05 --> Router Class Initialized
INFO - 2024-02-07 18:50:05 --> Output Class Initialized
INFO - 2024-02-07 18:50:05 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:05 --> Input Class Initialized
INFO - 2024-02-07 18:50:05 --> Language Class Initialized
INFO - 2024-02-07 18:50:05 --> Loader Class Initialized
INFO - 2024-02-07 18:50:05 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:05 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:05 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:05 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:05 --> Controller Class Initialized
INFO - 2024-02-07 18:50:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 18:50:05 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:05 --> Total execution time: 0.0225
ERROR - 2024-02-07 18:50:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:14 --> Config Class Initialized
INFO - 2024-02-07 18:50:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:14 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:14 --> URI Class Initialized
INFO - 2024-02-07 18:50:14 --> Router Class Initialized
INFO - 2024-02-07 18:50:14 --> Output Class Initialized
INFO - 2024-02-07 18:50:14 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:14 --> Input Class Initialized
INFO - 2024-02-07 18:50:14 --> Language Class Initialized
INFO - 2024-02-07 18:50:14 --> Loader Class Initialized
INFO - 2024-02-07 18:50:14 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:14 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:14 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:14 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:14 --> Controller Class Initialized
INFO - 2024-02-07 18:50:14 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:14 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:14 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:14 --> Total execution time: 0.0341
ERROR - 2024-02-07 18:50:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:15 --> Config Class Initialized
INFO - 2024-02-07 18:50:15 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:15 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:15 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:15 --> URI Class Initialized
INFO - 2024-02-07 18:50:15 --> Router Class Initialized
INFO - 2024-02-07 18:50:15 --> Output Class Initialized
INFO - 2024-02-07 18:50:15 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:15 --> Input Class Initialized
INFO - 2024-02-07 18:50:15 --> Language Class Initialized
INFO - 2024-02-07 18:50:15 --> Loader Class Initialized
INFO - 2024-02-07 18:50:15 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:15 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:15 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:15 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:15 --> Controller Class Initialized
INFO - 2024-02-07 18:50:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 18:50:15 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:15 --> Total execution time: 0.0330
ERROR - 2024-02-07 18:50:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:15 --> Config Class Initialized
INFO - 2024-02-07 18:50:15 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:15 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:15 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:15 --> URI Class Initialized
INFO - 2024-02-07 18:50:15 --> Router Class Initialized
INFO - 2024-02-07 18:50:15 --> Output Class Initialized
INFO - 2024-02-07 18:50:15 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:15 --> Input Class Initialized
INFO - 2024-02-07 18:50:15 --> Language Class Initialized
INFO - 2024-02-07 18:50:15 --> Loader Class Initialized
INFO - 2024-02-07 18:50:15 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:15 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:15 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:15 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:15 --> Controller Class Initialized
INFO - 2024-02-07 18:50:15 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:15 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:15 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:21 --> Config Class Initialized
INFO - 2024-02-07 18:50:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:21 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:21 --> URI Class Initialized
INFO - 2024-02-07 18:50:21 --> Router Class Initialized
INFO - 2024-02-07 18:50:21 --> Output Class Initialized
INFO - 2024-02-07 18:50:21 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:21 --> Input Class Initialized
INFO - 2024-02-07 18:50:21 --> Language Class Initialized
INFO - 2024-02-07 18:50:21 --> Loader Class Initialized
INFO - 2024-02-07 18:50:21 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:21 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:21 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:21 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:21 --> Controller Class Initialized
INFO - 2024-02-07 18:50:21 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:21 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 18:50:21 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:21 --> Total execution time: 0.0285
ERROR - 2024-02-07 18:50:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:50 --> Config Class Initialized
INFO - 2024-02-07 18:50:50 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:50 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:50 --> URI Class Initialized
INFO - 2024-02-07 18:50:50 --> Router Class Initialized
INFO - 2024-02-07 18:50:50 --> Output Class Initialized
INFO - 2024-02-07 18:50:50 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:50 --> Input Class Initialized
INFO - 2024-02-07 18:50:50 --> Language Class Initialized
INFO - 2024-02-07 18:50:50 --> Loader Class Initialized
INFO - 2024-02-07 18:50:50 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:50 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:50 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:50 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:50 --> Controller Class Initialized
INFO - 2024-02-07 18:50:50 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:50 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:50 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:50 --> Total execution time: 0.0239
ERROR - 2024-02-07 18:50:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:51 --> Config Class Initialized
INFO - 2024-02-07 18:50:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:51 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:51 --> URI Class Initialized
INFO - 2024-02-07 18:50:51 --> Router Class Initialized
INFO - 2024-02-07 18:50:51 --> Output Class Initialized
INFO - 2024-02-07 18:50:51 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:51 --> Input Class Initialized
INFO - 2024-02-07 18:50:51 --> Language Class Initialized
INFO - 2024-02-07 18:50:51 --> Loader Class Initialized
INFO - 2024-02-07 18:50:51 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:51 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:51 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:51 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:51 --> Controller Class Initialized
INFO - 2024-02-07 18:50:51 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:51 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:51 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:53 --> Config Class Initialized
INFO - 2024-02-07 18:50:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:53 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:53 --> URI Class Initialized
INFO - 2024-02-07 18:50:53 --> Router Class Initialized
INFO - 2024-02-07 18:50:53 --> Output Class Initialized
INFO - 2024-02-07 18:50:53 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:53 --> Input Class Initialized
INFO - 2024-02-07 18:50:53 --> Language Class Initialized
INFO - 2024-02-07 18:50:53 --> Loader Class Initialized
INFO - 2024-02-07 18:50:53 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:53 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:53 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:53 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:53 --> Controller Class Initialized
INFO - 2024-02-07 18:50:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 18:50:53 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:53 --> Total execution time: 0.0188
ERROR - 2024-02-07 18:50:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:55 --> Config Class Initialized
INFO - 2024-02-07 18:50:55 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:55 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:55 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:55 --> URI Class Initialized
INFO - 2024-02-07 18:50:55 --> Router Class Initialized
INFO - 2024-02-07 18:50:55 --> Output Class Initialized
INFO - 2024-02-07 18:50:55 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:55 --> Input Class Initialized
INFO - 2024-02-07 18:50:55 --> Language Class Initialized
INFO - 2024-02-07 18:50:55 --> Loader Class Initialized
INFO - 2024-02-07 18:50:55 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:55 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:55 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:55 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:55 --> Controller Class Initialized
INFO - 2024-02-07 18:50:55 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:55 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:55 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:55 --> Total execution time: 0.0303
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0468
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0416
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0750
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0735
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0664
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0450
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0552
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0378
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0292
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0389
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0543
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0379
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0276
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0214
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0280
ERROR - 2024-02-07 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:56 --> Config Class Initialized
INFO - 2024-02-07 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:56 --> URI Class Initialized
INFO - 2024-02-07 18:50:56 --> Router Class Initialized
INFO - 2024-02-07 18:50:56 --> Output Class Initialized
INFO - 2024-02-07 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:56 --> Input Class Initialized
INFO - 2024-02-07 18:50:56 --> Language Class Initialized
INFO - 2024-02-07 18:50:56 --> Loader Class Initialized
INFO - 2024-02-07 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:56 --> Controller Class Initialized
INFO - 2024-02-07 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-07 18:50:56 --> Total execution time: 0.0264
ERROR - 2024-02-07 18:50:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:50:57 --> Config Class Initialized
INFO - 2024-02-07 18:50:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:50:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:50:57 --> Utf8 Class Initialized
INFO - 2024-02-07 18:50:57 --> URI Class Initialized
INFO - 2024-02-07 18:50:57 --> Router Class Initialized
INFO - 2024-02-07 18:50:57 --> Output Class Initialized
INFO - 2024-02-07 18:50:57 --> Security Class Initialized
DEBUG - 2024-02-07 18:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:50:57 --> Input Class Initialized
INFO - 2024-02-07 18:50:57 --> Language Class Initialized
INFO - 2024-02-07 18:50:57 --> Loader Class Initialized
INFO - 2024-02-07 18:50:57 --> Helper loaded: url_helper
INFO - 2024-02-07 18:50:57 --> Helper loaded: file_helper
INFO - 2024-02-07 18:50:57 --> Helper loaded: form_helper
INFO - 2024-02-07 18:50:57 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:50:57 --> Controller Class Initialized
INFO - 2024-02-07 18:50:57 --> Form Validation Class Initialized
INFO - 2024-02-07 18:50:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:50:57 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:51:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:51:16 --> Config Class Initialized
INFO - 2024-02-07 18:51:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:51:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:51:16 --> Utf8 Class Initialized
INFO - 2024-02-07 18:51:16 --> URI Class Initialized
INFO - 2024-02-07 18:51:16 --> Router Class Initialized
INFO - 2024-02-07 18:51:16 --> Output Class Initialized
INFO - 2024-02-07 18:51:16 --> Security Class Initialized
DEBUG - 2024-02-07 18:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:51:16 --> Input Class Initialized
INFO - 2024-02-07 18:51:16 --> Language Class Initialized
INFO - 2024-02-07 18:51:16 --> Loader Class Initialized
INFO - 2024-02-07 18:51:16 --> Helper loaded: url_helper
INFO - 2024-02-07 18:51:16 --> Helper loaded: file_helper
INFO - 2024-02-07 18:51:16 --> Helper loaded: form_helper
INFO - 2024-02-07 18:51:16 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:51:16 --> Controller Class Initialized
INFO - 2024-02-07 18:51:16 --> Form Validation Class Initialized
INFO - 2024-02-07 18:51:16 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:51:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:51:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 18:51:16 --> Final output sent to browser
DEBUG - 2024-02-07 18:51:16 --> Total execution time: 0.0362
ERROR - 2024-02-07 18:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:58:18 --> Config Class Initialized
INFO - 2024-02-07 18:58:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:58:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:58:18 --> Utf8 Class Initialized
INFO - 2024-02-07 18:58:18 --> URI Class Initialized
INFO - 2024-02-07 18:58:18 --> Router Class Initialized
INFO - 2024-02-07 18:58:18 --> Output Class Initialized
INFO - 2024-02-07 18:58:18 --> Security Class Initialized
DEBUG - 2024-02-07 18:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:58:18 --> Input Class Initialized
INFO - 2024-02-07 18:58:18 --> Language Class Initialized
INFO - 2024-02-07 18:58:18 --> Loader Class Initialized
INFO - 2024-02-07 18:58:18 --> Helper loaded: url_helper
INFO - 2024-02-07 18:58:18 --> Helper loaded: file_helper
INFO - 2024-02-07 18:58:18 --> Helper loaded: form_helper
INFO - 2024-02-07 18:58:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:58:18 --> Controller Class Initialized
INFO - 2024-02-07 18:58:18 --> Form Validation Class Initialized
INFO - 2024-02-07 18:58:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:58:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:58:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:58:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:58:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:58:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:58:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:58:18 --> Final output sent to browser
DEBUG - 2024-02-07 18:58:18 --> Total execution time: 0.0302
ERROR - 2024-02-07 18:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:58:18 --> Config Class Initialized
INFO - 2024-02-07 18:58:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:58:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:58:18 --> Utf8 Class Initialized
INFO - 2024-02-07 18:58:18 --> URI Class Initialized
INFO - 2024-02-07 18:58:18 --> Router Class Initialized
INFO - 2024-02-07 18:58:18 --> Output Class Initialized
INFO - 2024-02-07 18:58:18 --> Security Class Initialized
DEBUG - 2024-02-07 18:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:58:18 --> Input Class Initialized
INFO - 2024-02-07 18:58:18 --> Language Class Initialized
INFO - 2024-02-07 18:58:18 --> Loader Class Initialized
INFO - 2024-02-07 18:58:18 --> Helper loaded: url_helper
INFO - 2024-02-07 18:58:18 --> Helper loaded: file_helper
INFO - 2024-02-07 18:58:18 --> Helper loaded: form_helper
INFO - 2024-02-07 18:58:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:58:18 --> Controller Class Initialized
INFO - 2024-02-07 18:58:18 --> Form Validation Class Initialized
INFO - 2024-02-07 18:58:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:58:18 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:58:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:58:20 --> Config Class Initialized
INFO - 2024-02-07 18:58:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:58:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:58:20 --> Utf8 Class Initialized
INFO - 2024-02-07 18:58:20 --> URI Class Initialized
INFO - 2024-02-07 18:58:20 --> Router Class Initialized
INFO - 2024-02-07 18:58:20 --> Output Class Initialized
INFO - 2024-02-07 18:58:20 --> Security Class Initialized
DEBUG - 2024-02-07 18:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:58:20 --> Input Class Initialized
INFO - 2024-02-07 18:58:20 --> Language Class Initialized
INFO - 2024-02-07 18:58:20 --> Loader Class Initialized
INFO - 2024-02-07 18:58:20 --> Helper loaded: url_helper
INFO - 2024-02-07 18:58:20 --> Helper loaded: file_helper
INFO - 2024-02-07 18:58:20 --> Helper loaded: form_helper
INFO - 2024-02-07 18:58:20 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:58:20 --> Controller Class Initialized
INFO - 2024-02-07 18:58:20 --> Form Validation Class Initialized
INFO - 2024-02-07 18:58:20 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:58:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:58:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 18:58:20 --> Final output sent to browser
DEBUG - 2024-02-07 18:58:20 --> Total execution time: 0.0169
ERROR - 2024-02-07 18:58:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:58:20 --> Config Class Initialized
INFO - 2024-02-07 18:58:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:58:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:58:20 --> Utf8 Class Initialized
INFO - 2024-02-07 18:58:20 --> URI Class Initialized
INFO - 2024-02-07 18:58:20 --> Router Class Initialized
INFO - 2024-02-07 18:58:20 --> Output Class Initialized
INFO - 2024-02-07 18:58:20 --> Security Class Initialized
DEBUG - 2024-02-07 18:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:58:20 --> Input Class Initialized
INFO - 2024-02-07 18:58:20 --> Language Class Initialized
INFO - 2024-02-07 18:58:20 --> Loader Class Initialized
INFO - 2024-02-07 18:58:20 --> Helper loaded: url_helper
INFO - 2024-02-07 18:58:20 --> Helper loaded: file_helper
INFO - 2024-02-07 18:58:20 --> Helper loaded: form_helper
INFO - 2024-02-07 18:58:20 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:58:20 --> Controller Class Initialized
INFO - 2024-02-07 18:58:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 18:58:20 --> Final output sent to browser
DEBUG - 2024-02-07 18:58:20 --> Total execution time: 0.0152
ERROR - 2024-02-07 18:58:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:58:41 --> Config Class Initialized
INFO - 2024-02-07 18:58:41 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:58:41 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:58:41 --> Utf8 Class Initialized
INFO - 2024-02-07 18:58:41 --> URI Class Initialized
INFO - 2024-02-07 18:58:41 --> Router Class Initialized
INFO - 2024-02-07 18:58:41 --> Output Class Initialized
INFO - 2024-02-07 18:58:41 --> Security Class Initialized
DEBUG - 2024-02-07 18:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:58:41 --> Input Class Initialized
INFO - 2024-02-07 18:58:41 --> Language Class Initialized
INFO - 2024-02-07 18:58:41 --> Loader Class Initialized
INFO - 2024-02-07 18:58:41 --> Helper loaded: url_helper
INFO - 2024-02-07 18:58:41 --> Helper loaded: file_helper
INFO - 2024-02-07 18:58:41 --> Helper loaded: form_helper
INFO - 2024-02-07 18:58:41 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:58:41 --> Controller Class Initialized
INFO - 2024-02-07 18:58:41 --> Form Validation Class Initialized
INFO - 2024-02-07 18:58:41 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:58:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:58:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:58:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:58:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:58:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:58:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:58:41 --> Final output sent to browser
DEBUG - 2024-02-07 18:58:41 --> Total execution time: 0.0431
ERROR - 2024-02-07 18:58:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:58:42 --> Config Class Initialized
INFO - 2024-02-07 18:58:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:58:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:58:42 --> Utf8 Class Initialized
INFO - 2024-02-07 18:58:42 --> URI Class Initialized
INFO - 2024-02-07 18:58:42 --> Router Class Initialized
INFO - 2024-02-07 18:58:42 --> Output Class Initialized
INFO - 2024-02-07 18:58:42 --> Security Class Initialized
DEBUG - 2024-02-07 18:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:58:42 --> Input Class Initialized
INFO - 2024-02-07 18:58:42 --> Language Class Initialized
INFO - 2024-02-07 18:58:42 --> Loader Class Initialized
INFO - 2024-02-07 18:58:42 --> Helper loaded: url_helper
INFO - 2024-02-07 18:58:42 --> Helper loaded: file_helper
INFO - 2024-02-07 18:58:42 --> Helper loaded: form_helper
INFO - 2024-02-07 18:58:42 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:58:42 --> Controller Class Initialized
INFO - 2024-02-07 18:58:42 --> Form Validation Class Initialized
INFO - 2024-02-07 18:58:42 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:58:42 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:58:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:58:45 --> Config Class Initialized
INFO - 2024-02-07 18:58:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:58:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:58:45 --> Utf8 Class Initialized
INFO - 2024-02-07 18:58:45 --> URI Class Initialized
INFO - 2024-02-07 18:58:45 --> Router Class Initialized
INFO - 2024-02-07 18:58:45 --> Output Class Initialized
INFO - 2024-02-07 18:58:45 --> Security Class Initialized
DEBUG - 2024-02-07 18:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:58:45 --> Input Class Initialized
INFO - 2024-02-07 18:58:45 --> Language Class Initialized
INFO - 2024-02-07 18:58:45 --> Loader Class Initialized
INFO - 2024-02-07 18:58:45 --> Helper loaded: url_helper
INFO - 2024-02-07 18:58:45 --> Helper loaded: file_helper
INFO - 2024-02-07 18:58:45 --> Helper loaded: form_helper
INFO - 2024-02-07 18:58:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:58:45 --> Controller Class Initialized
INFO - 2024-02-07 18:58:45 --> Form Validation Class Initialized
INFO - 2024-02-07 18:58:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:58:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:58:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 18:58:45 --> Final output sent to browser
DEBUG - 2024-02-07 18:58:45 --> Total execution time: 0.0340
ERROR - 2024-02-07 18:59:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:59:18 --> Config Class Initialized
INFO - 2024-02-07 18:59:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:59:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:59:18 --> Utf8 Class Initialized
INFO - 2024-02-07 18:59:18 --> URI Class Initialized
INFO - 2024-02-07 18:59:18 --> Router Class Initialized
INFO - 2024-02-07 18:59:18 --> Output Class Initialized
INFO - 2024-02-07 18:59:18 --> Security Class Initialized
DEBUG - 2024-02-07 18:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:59:18 --> Input Class Initialized
INFO - 2024-02-07 18:59:18 --> Language Class Initialized
INFO - 2024-02-07 18:59:18 --> Loader Class Initialized
INFO - 2024-02-07 18:59:18 --> Helper loaded: url_helper
INFO - 2024-02-07 18:59:18 --> Helper loaded: file_helper
INFO - 2024-02-07 18:59:18 --> Helper loaded: form_helper
INFO - 2024-02-07 18:59:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:59:18 --> Controller Class Initialized
INFO - 2024-02-07 18:59:18 --> Form Validation Class Initialized
INFO - 2024-02-07 18:59:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:59:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:59:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:59:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:59:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:59:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:59:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:59:18 --> Final output sent to browser
DEBUG - 2024-02-07 18:59:18 --> Total execution time: 0.0288
ERROR - 2024-02-07 18:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:59:20 --> Config Class Initialized
INFO - 2024-02-07 18:59:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:59:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:59:20 --> Utf8 Class Initialized
INFO - 2024-02-07 18:59:20 --> URI Class Initialized
INFO - 2024-02-07 18:59:20 --> Router Class Initialized
INFO - 2024-02-07 18:59:20 --> Output Class Initialized
INFO - 2024-02-07 18:59:20 --> Security Class Initialized
DEBUG - 2024-02-07 18:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:59:20 --> Input Class Initialized
INFO - 2024-02-07 18:59:20 --> Language Class Initialized
INFO - 2024-02-07 18:59:20 --> Loader Class Initialized
INFO - 2024-02-07 18:59:20 --> Helper loaded: url_helper
INFO - 2024-02-07 18:59:20 --> Helper loaded: file_helper
INFO - 2024-02-07 18:59:20 --> Helper loaded: form_helper
INFO - 2024-02-07 18:59:20 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:59:20 --> Controller Class Initialized
INFO - 2024-02-07 18:59:20 --> Form Validation Class Initialized
INFO - 2024-02-07 18:59:20 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:59:20 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:59:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:59:23 --> Config Class Initialized
INFO - 2024-02-07 18:59:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:59:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:59:23 --> Utf8 Class Initialized
INFO - 2024-02-07 18:59:23 --> URI Class Initialized
INFO - 2024-02-07 18:59:23 --> Router Class Initialized
INFO - 2024-02-07 18:59:23 --> Output Class Initialized
INFO - 2024-02-07 18:59:23 --> Security Class Initialized
DEBUG - 2024-02-07 18:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:59:23 --> Input Class Initialized
INFO - 2024-02-07 18:59:23 --> Language Class Initialized
INFO - 2024-02-07 18:59:23 --> Loader Class Initialized
INFO - 2024-02-07 18:59:23 --> Helper loaded: url_helper
INFO - 2024-02-07 18:59:23 --> Helper loaded: file_helper
INFO - 2024-02-07 18:59:23 --> Helper loaded: form_helper
INFO - 2024-02-07 18:59:23 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:59:23 --> Controller Class Initialized
INFO - 2024-02-07 18:59:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 18:59:23 --> Final output sent to browser
DEBUG - 2024-02-07 18:59:23 --> Total execution time: 0.0202
ERROR - 2024-02-07 18:59:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:59:26 --> Config Class Initialized
INFO - 2024-02-07 18:59:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:59:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:59:26 --> Utf8 Class Initialized
INFO - 2024-02-07 18:59:26 --> URI Class Initialized
INFO - 2024-02-07 18:59:26 --> Router Class Initialized
INFO - 2024-02-07 18:59:26 --> Output Class Initialized
INFO - 2024-02-07 18:59:26 --> Security Class Initialized
DEBUG - 2024-02-07 18:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:59:26 --> Input Class Initialized
INFO - 2024-02-07 18:59:26 --> Language Class Initialized
INFO - 2024-02-07 18:59:26 --> Loader Class Initialized
INFO - 2024-02-07 18:59:26 --> Helper loaded: url_helper
INFO - 2024-02-07 18:59:26 --> Helper loaded: file_helper
INFO - 2024-02-07 18:59:26 --> Helper loaded: form_helper
INFO - 2024-02-07 18:59:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:59:26 --> Controller Class Initialized
INFO - 2024-02-07 18:59:26 --> Form Validation Class Initialized
INFO - 2024-02-07 18:59:26 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:59:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:59:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 18:59:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 18:59:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 18:59:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 18:59:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 18:59:26 --> Final output sent to browser
DEBUG - 2024-02-07 18:59:26 --> Total execution time: 0.0361
ERROR - 2024-02-07 18:59:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:59:26 --> Config Class Initialized
INFO - 2024-02-07 18:59:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:59:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:59:26 --> Utf8 Class Initialized
INFO - 2024-02-07 18:59:26 --> URI Class Initialized
INFO - 2024-02-07 18:59:26 --> Router Class Initialized
INFO - 2024-02-07 18:59:26 --> Output Class Initialized
INFO - 2024-02-07 18:59:26 --> Security Class Initialized
DEBUG - 2024-02-07 18:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:59:26 --> Input Class Initialized
INFO - 2024-02-07 18:59:26 --> Language Class Initialized
INFO - 2024-02-07 18:59:26 --> Loader Class Initialized
INFO - 2024-02-07 18:59:26 --> Helper loaded: url_helper
INFO - 2024-02-07 18:59:26 --> Helper loaded: file_helper
INFO - 2024-02-07 18:59:26 --> Helper loaded: form_helper
INFO - 2024-02-07 18:59:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:59:26 --> Controller Class Initialized
INFO - 2024-02-07 18:59:26 --> Form Validation Class Initialized
INFO - 2024-02-07 18:59:26 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:59:26 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 18:59:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 18:59:30 --> Config Class Initialized
INFO - 2024-02-07 18:59:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 18:59:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 18:59:30 --> Utf8 Class Initialized
INFO - 2024-02-07 18:59:30 --> URI Class Initialized
INFO - 2024-02-07 18:59:30 --> Router Class Initialized
INFO - 2024-02-07 18:59:30 --> Output Class Initialized
INFO - 2024-02-07 18:59:30 --> Security Class Initialized
DEBUG - 2024-02-07 18:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 18:59:30 --> Input Class Initialized
INFO - 2024-02-07 18:59:30 --> Language Class Initialized
INFO - 2024-02-07 18:59:30 --> Loader Class Initialized
INFO - 2024-02-07 18:59:30 --> Helper loaded: url_helper
INFO - 2024-02-07 18:59:30 --> Helper loaded: file_helper
INFO - 2024-02-07 18:59:30 --> Helper loaded: form_helper
INFO - 2024-02-07 18:59:30 --> Database Driver Class Initialized
DEBUG - 2024-02-07 18:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 18:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 18:59:30 --> Controller Class Initialized
INFO - 2024-02-07 18:59:30 --> Form Validation Class Initialized
INFO - 2024-02-07 18:59:30 --> Model "MasterModel" initialized
INFO - 2024-02-07 18:59:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 18:59:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 18:59:30 --> Final output sent to browser
DEBUG - 2024-02-07 18:59:30 --> Total execution time: 0.0440
ERROR - 2024-02-07 19:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:02:52 --> Config Class Initialized
INFO - 2024-02-07 19:02:52 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:02:52 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:02:52 --> Utf8 Class Initialized
INFO - 2024-02-07 19:02:52 --> URI Class Initialized
INFO - 2024-02-07 19:02:52 --> Router Class Initialized
INFO - 2024-02-07 19:02:52 --> Output Class Initialized
INFO - 2024-02-07 19:02:52 --> Security Class Initialized
DEBUG - 2024-02-07 19:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:02:52 --> Input Class Initialized
INFO - 2024-02-07 19:02:52 --> Language Class Initialized
INFO - 2024-02-07 19:02:52 --> Loader Class Initialized
INFO - 2024-02-07 19:02:52 --> Helper loaded: url_helper
INFO - 2024-02-07 19:02:52 --> Helper loaded: file_helper
INFO - 2024-02-07 19:02:52 --> Helper loaded: form_helper
INFO - 2024-02-07 19:02:52 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:02:52 --> Controller Class Initialized
INFO - 2024-02-07 19:02:52 --> Form Validation Class Initialized
INFO - 2024-02-07 19:02:52 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:02:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:02:52 --> Final output sent to browser
DEBUG - 2024-02-07 19:02:52 --> Total execution time: 0.0346
ERROR - 2024-02-07 19:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:02:52 --> Config Class Initialized
INFO - 2024-02-07 19:02:52 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:02:52 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:02:52 --> Utf8 Class Initialized
INFO - 2024-02-07 19:02:52 --> URI Class Initialized
INFO - 2024-02-07 19:02:52 --> Router Class Initialized
INFO - 2024-02-07 19:02:52 --> Output Class Initialized
INFO - 2024-02-07 19:02:52 --> Security Class Initialized
DEBUG - 2024-02-07 19:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:02:52 --> Input Class Initialized
INFO - 2024-02-07 19:02:52 --> Language Class Initialized
INFO - 2024-02-07 19:02:52 --> Loader Class Initialized
INFO - 2024-02-07 19:02:52 --> Helper loaded: url_helper
INFO - 2024-02-07 19:02:52 --> Helper loaded: file_helper
INFO - 2024-02-07 19:02:52 --> Helper loaded: form_helper
INFO - 2024-02-07 19:02:52 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:02:52 --> Controller Class Initialized
INFO - 2024-02-07 19:02:52 --> Form Validation Class Initialized
INFO - 2024-02-07 19:02:52 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:02:52 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:02:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:02:54 --> Config Class Initialized
INFO - 2024-02-07 19:02:54 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:02:54 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:02:54 --> Utf8 Class Initialized
INFO - 2024-02-07 19:02:54 --> URI Class Initialized
INFO - 2024-02-07 19:02:54 --> Router Class Initialized
INFO - 2024-02-07 19:02:54 --> Output Class Initialized
INFO - 2024-02-07 19:02:54 --> Security Class Initialized
DEBUG - 2024-02-07 19:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:02:54 --> Input Class Initialized
INFO - 2024-02-07 19:02:54 --> Language Class Initialized
INFO - 2024-02-07 19:02:54 --> Loader Class Initialized
INFO - 2024-02-07 19:02:54 --> Helper loaded: url_helper
INFO - 2024-02-07 19:02:54 --> Helper loaded: file_helper
INFO - 2024-02-07 19:02:54 --> Helper loaded: form_helper
INFO - 2024-02-07 19:02:54 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:02:54 --> Controller Class Initialized
INFO - 2024-02-07 19:02:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:02:54 --> Final output sent to browser
DEBUG - 2024-02-07 19:02:54 --> Total execution time: 0.0184
ERROR - 2024-02-07 19:02:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:02:57 --> Config Class Initialized
INFO - 2024-02-07 19:02:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:02:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:02:57 --> Utf8 Class Initialized
INFO - 2024-02-07 19:02:57 --> URI Class Initialized
INFO - 2024-02-07 19:02:57 --> Router Class Initialized
INFO - 2024-02-07 19:02:57 --> Output Class Initialized
INFO - 2024-02-07 19:02:57 --> Security Class Initialized
DEBUG - 2024-02-07 19:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:02:57 --> Input Class Initialized
INFO - 2024-02-07 19:02:57 --> Language Class Initialized
INFO - 2024-02-07 19:02:57 --> Loader Class Initialized
INFO - 2024-02-07 19:02:57 --> Helper loaded: url_helper
INFO - 2024-02-07 19:02:57 --> Helper loaded: file_helper
INFO - 2024-02-07 19:02:57 --> Helper loaded: form_helper
INFO - 2024-02-07 19:02:57 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:02:57 --> Controller Class Initialized
INFO - 2024-02-07 19:02:57 --> Form Validation Class Initialized
INFO - 2024-02-07 19:02:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:02:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:02:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:02:57 --> Final output sent to browser
DEBUG - 2024-02-07 19:02:57 --> Total execution time: 0.0346
ERROR - 2024-02-07 19:03:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:03:18 --> Config Class Initialized
INFO - 2024-02-07 19:03:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:03:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:03:18 --> Utf8 Class Initialized
INFO - 2024-02-07 19:03:18 --> URI Class Initialized
INFO - 2024-02-07 19:03:18 --> Router Class Initialized
INFO - 2024-02-07 19:03:18 --> Output Class Initialized
INFO - 2024-02-07 19:03:18 --> Security Class Initialized
DEBUG - 2024-02-07 19:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:03:18 --> Input Class Initialized
INFO - 2024-02-07 19:03:18 --> Language Class Initialized
INFO - 2024-02-07 19:03:18 --> Loader Class Initialized
INFO - 2024-02-07 19:03:18 --> Helper loaded: url_helper
INFO - 2024-02-07 19:03:18 --> Helper loaded: file_helper
INFO - 2024-02-07 19:03:18 --> Helper loaded: form_helper
INFO - 2024-02-07 19:03:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:03:18 --> Controller Class Initialized
INFO - 2024-02-07 19:03:18 --> Form Validation Class Initialized
INFO - 2024-02-07 19:03:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:03:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:03:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:03:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:03:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:03:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:03:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:03:18 --> Final output sent to browser
DEBUG - 2024-02-07 19:03:18 --> Total execution time: 0.0283
ERROR - 2024-02-07 19:03:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:03:18 --> Config Class Initialized
INFO - 2024-02-07 19:03:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:03:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:03:18 --> Utf8 Class Initialized
INFO - 2024-02-07 19:03:18 --> URI Class Initialized
INFO - 2024-02-07 19:03:18 --> Router Class Initialized
INFO - 2024-02-07 19:03:18 --> Output Class Initialized
INFO - 2024-02-07 19:03:18 --> Security Class Initialized
DEBUG - 2024-02-07 19:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:03:18 --> Input Class Initialized
INFO - 2024-02-07 19:03:18 --> Language Class Initialized
INFO - 2024-02-07 19:03:18 --> Loader Class Initialized
INFO - 2024-02-07 19:03:18 --> Helper loaded: url_helper
INFO - 2024-02-07 19:03:18 --> Helper loaded: file_helper
INFO - 2024-02-07 19:03:18 --> Helper loaded: form_helper
INFO - 2024-02-07 19:03:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:03:18 --> Controller Class Initialized
INFO - 2024-02-07 19:03:18 --> Form Validation Class Initialized
INFO - 2024-02-07 19:03:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:03:18 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:03:22 --> Config Class Initialized
INFO - 2024-02-07 19:03:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:03:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:03:22 --> Utf8 Class Initialized
INFO - 2024-02-07 19:03:22 --> URI Class Initialized
INFO - 2024-02-07 19:03:22 --> Router Class Initialized
INFO - 2024-02-07 19:03:22 --> Output Class Initialized
INFO - 2024-02-07 19:03:22 --> Security Class Initialized
DEBUG - 2024-02-07 19:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:03:22 --> Input Class Initialized
INFO - 2024-02-07 19:03:22 --> Language Class Initialized
INFO - 2024-02-07 19:03:22 --> Loader Class Initialized
INFO - 2024-02-07 19:03:22 --> Helper loaded: url_helper
INFO - 2024-02-07 19:03:22 --> Helper loaded: file_helper
INFO - 2024-02-07 19:03:22 --> Helper loaded: form_helper
INFO - 2024-02-07 19:03:22 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:03:22 --> Controller Class Initialized
INFO - 2024-02-07 19:03:22 --> Form Validation Class Initialized
INFO - 2024-02-07 19:03:22 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:03:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:03:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:03:22 --> Final output sent to browser
DEBUG - 2024-02-07 19:03:22 --> Total execution time: 0.0263
ERROR - 2024-02-07 19:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:03:48 --> Config Class Initialized
INFO - 2024-02-07 19:03:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:03:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:03:48 --> Utf8 Class Initialized
INFO - 2024-02-07 19:03:48 --> URI Class Initialized
INFO - 2024-02-07 19:03:48 --> Router Class Initialized
INFO - 2024-02-07 19:03:48 --> Output Class Initialized
INFO - 2024-02-07 19:03:48 --> Security Class Initialized
DEBUG - 2024-02-07 19:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:03:48 --> Input Class Initialized
INFO - 2024-02-07 19:03:48 --> Language Class Initialized
INFO - 2024-02-07 19:03:48 --> Loader Class Initialized
INFO - 2024-02-07 19:03:48 --> Helper loaded: url_helper
INFO - 2024-02-07 19:03:48 --> Helper loaded: file_helper
INFO - 2024-02-07 19:03:48 --> Helper loaded: form_helper
INFO - 2024-02-07 19:03:48 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:03:48 --> Controller Class Initialized
INFO - 2024-02-07 19:03:48 --> Form Validation Class Initialized
INFO - 2024-02-07 19:03:48 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:03:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:03:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:03:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:03:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:03:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:03:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:03:48 --> Final output sent to browser
DEBUG - 2024-02-07 19:03:48 --> Total execution time: 0.0279
ERROR - 2024-02-07 19:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:03:48 --> Config Class Initialized
INFO - 2024-02-07 19:03:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:03:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:03:48 --> Utf8 Class Initialized
INFO - 2024-02-07 19:03:48 --> URI Class Initialized
INFO - 2024-02-07 19:03:48 --> Router Class Initialized
INFO - 2024-02-07 19:03:48 --> Output Class Initialized
INFO - 2024-02-07 19:03:48 --> Security Class Initialized
DEBUG - 2024-02-07 19:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:03:48 --> Input Class Initialized
INFO - 2024-02-07 19:03:48 --> Language Class Initialized
INFO - 2024-02-07 19:03:48 --> Loader Class Initialized
INFO - 2024-02-07 19:03:48 --> Helper loaded: url_helper
INFO - 2024-02-07 19:03:48 --> Helper loaded: file_helper
INFO - 2024-02-07 19:03:48 --> Helper loaded: form_helper
INFO - 2024-02-07 19:03:48 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:03:48 --> Controller Class Initialized
INFO - 2024-02-07 19:03:48 --> Form Validation Class Initialized
INFO - 2024-02-07 19:03:48 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:03:48 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:03:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:03:53 --> Config Class Initialized
INFO - 2024-02-07 19:03:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:03:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:03:53 --> Utf8 Class Initialized
INFO - 2024-02-07 19:03:53 --> URI Class Initialized
INFO - 2024-02-07 19:03:53 --> Router Class Initialized
INFO - 2024-02-07 19:03:53 --> Output Class Initialized
INFO - 2024-02-07 19:03:53 --> Security Class Initialized
DEBUG - 2024-02-07 19:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:03:53 --> Input Class Initialized
INFO - 2024-02-07 19:03:53 --> Language Class Initialized
INFO - 2024-02-07 19:03:53 --> Loader Class Initialized
INFO - 2024-02-07 19:03:53 --> Helper loaded: url_helper
INFO - 2024-02-07 19:03:53 --> Helper loaded: file_helper
INFO - 2024-02-07 19:03:53 --> Helper loaded: form_helper
INFO - 2024-02-07 19:03:53 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:03:53 --> Controller Class Initialized
INFO - 2024-02-07 19:03:53 --> Form Validation Class Initialized
INFO - 2024-02-07 19:03:53 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:03:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:03:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:03:53 --> Final output sent to browser
DEBUG - 2024-02-07 19:03:53 --> Total execution time: 0.0320
ERROR - 2024-02-07 19:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:05:27 --> Config Class Initialized
INFO - 2024-02-07 19:05:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:05:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:05:27 --> Utf8 Class Initialized
INFO - 2024-02-07 19:05:27 --> URI Class Initialized
INFO - 2024-02-07 19:05:27 --> Router Class Initialized
INFO - 2024-02-07 19:05:27 --> Output Class Initialized
INFO - 2024-02-07 19:05:27 --> Security Class Initialized
DEBUG - 2024-02-07 19:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:05:27 --> Input Class Initialized
INFO - 2024-02-07 19:05:27 --> Language Class Initialized
INFO - 2024-02-07 19:05:27 --> Loader Class Initialized
INFO - 2024-02-07 19:05:27 --> Helper loaded: url_helper
INFO - 2024-02-07 19:05:27 --> Helper loaded: file_helper
INFO - 2024-02-07 19:05:27 --> Helper loaded: form_helper
INFO - 2024-02-07 19:05:27 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:05:27 --> Controller Class Initialized
INFO - 2024-02-07 19:05:27 --> Form Validation Class Initialized
INFO - 2024-02-07 19:05:27 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:05:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:05:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:05:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:05:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:05:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:05:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:05:27 --> Final output sent to browser
DEBUG - 2024-02-07 19:05:27 --> Total execution time: 0.0326
ERROR - 2024-02-07 19:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:05:28 --> Config Class Initialized
INFO - 2024-02-07 19:05:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:05:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:05:28 --> Utf8 Class Initialized
INFO - 2024-02-07 19:05:28 --> URI Class Initialized
INFO - 2024-02-07 19:05:28 --> Router Class Initialized
INFO - 2024-02-07 19:05:28 --> Output Class Initialized
INFO - 2024-02-07 19:05:28 --> Security Class Initialized
DEBUG - 2024-02-07 19:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:05:28 --> Input Class Initialized
INFO - 2024-02-07 19:05:28 --> Language Class Initialized
INFO - 2024-02-07 19:05:28 --> Loader Class Initialized
INFO - 2024-02-07 19:05:28 --> Helper loaded: url_helper
INFO - 2024-02-07 19:05:28 --> Helper loaded: file_helper
INFO - 2024-02-07 19:05:28 --> Helper loaded: form_helper
INFO - 2024-02-07 19:05:28 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:05:28 --> Controller Class Initialized
INFO - 2024-02-07 19:05:28 --> Form Validation Class Initialized
INFO - 2024-02-07 19:05:28 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:05:28 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:05:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:05:31 --> Config Class Initialized
INFO - 2024-02-07 19:05:31 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:05:31 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:05:31 --> Utf8 Class Initialized
INFO - 2024-02-07 19:05:31 --> URI Class Initialized
INFO - 2024-02-07 19:05:31 --> Router Class Initialized
INFO - 2024-02-07 19:05:31 --> Output Class Initialized
INFO - 2024-02-07 19:05:31 --> Security Class Initialized
DEBUG - 2024-02-07 19:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:05:31 --> Input Class Initialized
INFO - 2024-02-07 19:05:31 --> Language Class Initialized
INFO - 2024-02-07 19:05:31 --> Loader Class Initialized
INFO - 2024-02-07 19:05:31 --> Helper loaded: url_helper
INFO - 2024-02-07 19:05:31 --> Helper loaded: file_helper
INFO - 2024-02-07 19:05:31 --> Helper loaded: form_helper
INFO - 2024-02-07 19:05:31 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:05:31 --> Controller Class Initialized
INFO - 2024-02-07 19:05:31 --> Form Validation Class Initialized
INFO - 2024-02-07 19:05:31 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:05:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:05:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:05:31 --> Final output sent to browser
DEBUG - 2024-02-07 19:05:31 --> Total execution time: 0.0260
ERROR - 2024-02-07 19:06:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:06:27 --> Config Class Initialized
INFO - 2024-02-07 19:06:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:06:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:06:27 --> Utf8 Class Initialized
INFO - 2024-02-07 19:06:27 --> URI Class Initialized
INFO - 2024-02-07 19:06:27 --> Router Class Initialized
INFO - 2024-02-07 19:06:27 --> Output Class Initialized
INFO - 2024-02-07 19:06:27 --> Security Class Initialized
DEBUG - 2024-02-07 19:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:06:27 --> Input Class Initialized
INFO - 2024-02-07 19:06:27 --> Language Class Initialized
INFO - 2024-02-07 19:06:27 --> Loader Class Initialized
INFO - 2024-02-07 19:06:27 --> Helper loaded: url_helper
INFO - 2024-02-07 19:06:27 --> Helper loaded: file_helper
INFO - 2024-02-07 19:06:27 --> Helper loaded: form_helper
INFO - 2024-02-07 19:06:27 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:06:27 --> Controller Class Initialized
INFO - 2024-02-07 19:06:27 --> Form Validation Class Initialized
INFO - 2024-02-07 19:06:27 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:06:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:06:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:06:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:06:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:06:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:06:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:06:27 --> Final output sent to browser
DEBUG - 2024-02-07 19:06:27 --> Total execution time: 0.0312
ERROR - 2024-02-07 19:06:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:06:27 --> Config Class Initialized
INFO - 2024-02-07 19:06:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:06:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:06:27 --> Utf8 Class Initialized
INFO - 2024-02-07 19:06:27 --> URI Class Initialized
INFO - 2024-02-07 19:06:27 --> Router Class Initialized
INFO - 2024-02-07 19:06:27 --> Output Class Initialized
INFO - 2024-02-07 19:06:27 --> Security Class Initialized
DEBUG - 2024-02-07 19:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:06:27 --> Input Class Initialized
INFO - 2024-02-07 19:06:27 --> Language Class Initialized
INFO - 2024-02-07 19:06:27 --> Loader Class Initialized
INFO - 2024-02-07 19:06:27 --> Helper loaded: url_helper
INFO - 2024-02-07 19:06:27 --> Helper loaded: file_helper
INFO - 2024-02-07 19:06:27 --> Helper loaded: form_helper
INFO - 2024-02-07 19:06:27 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:06:27 --> Controller Class Initialized
INFO - 2024-02-07 19:06:27 --> Form Validation Class Initialized
INFO - 2024-02-07 19:06:27 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:06:27 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:06:30 --> Config Class Initialized
INFO - 2024-02-07 19:06:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:06:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:06:30 --> Utf8 Class Initialized
INFO - 2024-02-07 19:06:30 --> URI Class Initialized
INFO - 2024-02-07 19:06:30 --> Router Class Initialized
INFO - 2024-02-07 19:06:30 --> Output Class Initialized
INFO - 2024-02-07 19:06:30 --> Security Class Initialized
DEBUG - 2024-02-07 19:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:06:30 --> Input Class Initialized
INFO - 2024-02-07 19:06:30 --> Language Class Initialized
INFO - 2024-02-07 19:06:30 --> Loader Class Initialized
INFO - 2024-02-07 19:06:30 --> Helper loaded: url_helper
INFO - 2024-02-07 19:06:30 --> Helper loaded: file_helper
INFO - 2024-02-07 19:06:30 --> Helper loaded: form_helper
INFO - 2024-02-07 19:06:30 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:06:30 --> Controller Class Initialized
INFO - 2024-02-07 19:06:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:06:30 --> Final output sent to browser
DEBUG - 2024-02-07 19:06:30 --> Total execution time: 0.0211
ERROR - 2024-02-07 19:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:06:30 --> Config Class Initialized
INFO - 2024-02-07 19:06:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:06:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:06:30 --> Utf8 Class Initialized
INFO - 2024-02-07 19:06:30 --> URI Class Initialized
INFO - 2024-02-07 19:06:30 --> Router Class Initialized
INFO - 2024-02-07 19:06:30 --> Output Class Initialized
INFO - 2024-02-07 19:06:30 --> Security Class Initialized
DEBUG - 2024-02-07 19:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:06:30 --> Input Class Initialized
INFO - 2024-02-07 19:06:30 --> Language Class Initialized
INFO - 2024-02-07 19:06:30 --> Loader Class Initialized
INFO - 2024-02-07 19:06:30 --> Helper loaded: url_helper
INFO - 2024-02-07 19:06:30 --> Helper loaded: file_helper
INFO - 2024-02-07 19:06:30 --> Helper loaded: form_helper
INFO - 2024-02-07 19:06:30 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:06:30 --> Controller Class Initialized
INFO - 2024-02-07 19:06:30 --> Form Validation Class Initialized
INFO - 2024-02-07 19:06:30 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:06:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:06:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:06:30 --> Final output sent to browser
DEBUG - 2024-02-07 19:06:30 --> Total execution time: 0.0280
ERROR - 2024-02-07 19:07:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:07:17 --> Config Class Initialized
INFO - 2024-02-07 19:07:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:07:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:07:17 --> Utf8 Class Initialized
INFO - 2024-02-07 19:07:17 --> URI Class Initialized
INFO - 2024-02-07 19:07:17 --> Router Class Initialized
INFO - 2024-02-07 19:07:17 --> Output Class Initialized
INFO - 2024-02-07 19:07:17 --> Security Class Initialized
DEBUG - 2024-02-07 19:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:07:17 --> Input Class Initialized
INFO - 2024-02-07 19:07:17 --> Language Class Initialized
INFO - 2024-02-07 19:07:17 --> Loader Class Initialized
INFO - 2024-02-07 19:07:17 --> Helper loaded: url_helper
INFO - 2024-02-07 19:07:17 --> Helper loaded: file_helper
INFO - 2024-02-07 19:07:17 --> Helper loaded: form_helper
INFO - 2024-02-07 19:07:17 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:07:17 --> Controller Class Initialized
INFO - 2024-02-07 19:07:17 --> Form Validation Class Initialized
INFO - 2024-02-07 19:07:17 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:07:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:07:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:07:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:07:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:07:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:07:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:07:17 --> Final output sent to browser
DEBUG - 2024-02-07 19:07:17 --> Total execution time: 0.0331
ERROR - 2024-02-07 19:07:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:07:18 --> Config Class Initialized
INFO - 2024-02-07 19:07:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:07:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:07:18 --> Utf8 Class Initialized
INFO - 2024-02-07 19:07:18 --> URI Class Initialized
INFO - 2024-02-07 19:07:18 --> Router Class Initialized
INFO - 2024-02-07 19:07:18 --> Output Class Initialized
INFO - 2024-02-07 19:07:18 --> Security Class Initialized
DEBUG - 2024-02-07 19:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:07:18 --> Input Class Initialized
INFO - 2024-02-07 19:07:18 --> Language Class Initialized
INFO - 2024-02-07 19:07:18 --> Loader Class Initialized
INFO - 2024-02-07 19:07:18 --> Helper loaded: url_helper
INFO - 2024-02-07 19:07:18 --> Helper loaded: file_helper
INFO - 2024-02-07 19:07:18 --> Helper loaded: form_helper
INFO - 2024-02-07 19:07:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:07:18 --> Controller Class Initialized
INFO - 2024-02-07 19:07:18 --> Form Validation Class Initialized
INFO - 2024-02-07 19:07:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:07:18 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:07:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:07:22 --> Config Class Initialized
INFO - 2024-02-07 19:07:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:07:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:07:22 --> Utf8 Class Initialized
INFO - 2024-02-07 19:07:22 --> URI Class Initialized
INFO - 2024-02-07 19:07:22 --> Router Class Initialized
INFO - 2024-02-07 19:07:22 --> Output Class Initialized
INFO - 2024-02-07 19:07:22 --> Security Class Initialized
DEBUG - 2024-02-07 19:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:07:22 --> Input Class Initialized
INFO - 2024-02-07 19:07:22 --> Language Class Initialized
INFO - 2024-02-07 19:07:22 --> Loader Class Initialized
INFO - 2024-02-07 19:07:22 --> Helper loaded: url_helper
INFO - 2024-02-07 19:07:22 --> Helper loaded: file_helper
INFO - 2024-02-07 19:07:22 --> Helper loaded: form_helper
INFO - 2024-02-07 19:07:22 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:07:22 --> Controller Class Initialized
INFO - 2024-02-07 19:07:22 --> Form Validation Class Initialized
INFO - 2024-02-07 19:07:22 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:07:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:07:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:07:22 --> Final output sent to browser
DEBUG - 2024-02-07 19:07:22 --> Total execution time: 0.0248
ERROR - 2024-02-07 19:07:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:07:49 --> Config Class Initialized
INFO - 2024-02-07 19:07:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:07:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:07:49 --> Utf8 Class Initialized
INFO - 2024-02-07 19:07:49 --> URI Class Initialized
INFO - 2024-02-07 19:07:49 --> Router Class Initialized
INFO - 2024-02-07 19:07:49 --> Output Class Initialized
INFO - 2024-02-07 19:07:49 --> Security Class Initialized
DEBUG - 2024-02-07 19:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:07:49 --> Input Class Initialized
INFO - 2024-02-07 19:07:49 --> Language Class Initialized
INFO - 2024-02-07 19:07:49 --> Loader Class Initialized
INFO - 2024-02-07 19:07:49 --> Helper loaded: url_helper
INFO - 2024-02-07 19:07:49 --> Helper loaded: file_helper
INFO - 2024-02-07 19:07:49 --> Helper loaded: form_helper
INFO - 2024-02-07 19:07:49 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:07:49 --> Controller Class Initialized
INFO - 2024-02-07 19:07:49 --> Form Validation Class Initialized
INFO - 2024-02-07 19:07:49 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:07:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:07:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:07:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:07:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:07:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:07:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:07:49 --> Final output sent to browser
DEBUG - 2024-02-07 19:07:49 --> Total execution time: 0.0297
ERROR - 2024-02-07 19:07:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:07:50 --> Config Class Initialized
INFO - 2024-02-07 19:07:50 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:07:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:07:50 --> Utf8 Class Initialized
INFO - 2024-02-07 19:07:50 --> URI Class Initialized
INFO - 2024-02-07 19:07:50 --> Router Class Initialized
INFO - 2024-02-07 19:07:50 --> Output Class Initialized
INFO - 2024-02-07 19:07:50 --> Security Class Initialized
DEBUG - 2024-02-07 19:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:07:50 --> Input Class Initialized
INFO - 2024-02-07 19:07:50 --> Language Class Initialized
INFO - 2024-02-07 19:07:50 --> Loader Class Initialized
INFO - 2024-02-07 19:07:50 --> Helper loaded: url_helper
INFO - 2024-02-07 19:07:50 --> Helper loaded: file_helper
INFO - 2024-02-07 19:07:50 --> Helper loaded: form_helper
INFO - 2024-02-07 19:07:50 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:07:50 --> Controller Class Initialized
INFO - 2024-02-07 19:07:50 --> Form Validation Class Initialized
INFO - 2024-02-07 19:07:50 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:07:50 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:07:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:07:52 --> Config Class Initialized
INFO - 2024-02-07 19:07:52 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:07:52 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:07:52 --> Utf8 Class Initialized
INFO - 2024-02-07 19:07:52 --> URI Class Initialized
INFO - 2024-02-07 19:07:52 --> Router Class Initialized
INFO - 2024-02-07 19:07:52 --> Output Class Initialized
INFO - 2024-02-07 19:07:52 --> Security Class Initialized
DEBUG - 2024-02-07 19:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:07:52 --> Input Class Initialized
INFO - 2024-02-07 19:07:52 --> Language Class Initialized
INFO - 2024-02-07 19:07:52 --> Loader Class Initialized
INFO - 2024-02-07 19:07:52 --> Helper loaded: url_helper
INFO - 2024-02-07 19:07:52 --> Helper loaded: file_helper
INFO - 2024-02-07 19:07:52 --> Helper loaded: form_helper
INFO - 2024-02-07 19:07:52 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:07:52 --> Controller Class Initialized
INFO - 2024-02-07 19:07:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:07:52 --> Final output sent to browser
DEBUG - 2024-02-07 19:07:52 --> Total execution time: 0.0201
ERROR - 2024-02-07 19:08:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:08:14 --> Config Class Initialized
INFO - 2024-02-07 19:08:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:08:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:08:14 --> Utf8 Class Initialized
INFO - 2024-02-07 19:08:14 --> URI Class Initialized
INFO - 2024-02-07 19:08:14 --> Router Class Initialized
INFO - 2024-02-07 19:08:14 --> Output Class Initialized
INFO - 2024-02-07 19:08:14 --> Security Class Initialized
DEBUG - 2024-02-07 19:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:08:14 --> Input Class Initialized
INFO - 2024-02-07 19:08:14 --> Language Class Initialized
INFO - 2024-02-07 19:08:14 --> Loader Class Initialized
INFO - 2024-02-07 19:08:14 --> Helper loaded: url_helper
INFO - 2024-02-07 19:08:14 --> Helper loaded: file_helper
INFO - 2024-02-07 19:08:14 --> Helper loaded: form_helper
INFO - 2024-02-07 19:08:14 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:08:14 --> Controller Class Initialized
INFO - 2024-02-07 19:08:14 --> Form Validation Class Initialized
INFO - 2024-02-07 19:08:14 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:08:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:08:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:08:14 --> Final output sent to browser
DEBUG - 2024-02-07 19:08:14 --> Total execution time: 0.0345
ERROR - 2024-02-07 19:08:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:08:57 --> Config Class Initialized
INFO - 2024-02-07 19:08:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:08:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:08:57 --> Utf8 Class Initialized
INFO - 2024-02-07 19:08:57 --> URI Class Initialized
INFO - 2024-02-07 19:08:57 --> Router Class Initialized
INFO - 2024-02-07 19:08:57 --> Output Class Initialized
INFO - 2024-02-07 19:08:57 --> Security Class Initialized
DEBUG - 2024-02-07 19:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:08:57 --> Input Class Initialized
INFO - 2024-02-07 19:08:57 --> Language Class Initialized
INFO - 2024-02-07 19:08:57 --> Loader Class Initialized
INFO - 2024-02-07 19:08:57 --> Helper loaded: url_helper
INFO - 2024-02-07 19:08:57 --> Helper loaded: file_helper
INFO - 2024-02-07 19:08:57 --> Helper loaded: form_helper
INFO - 2024-02-07 19:08:57 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:08:57 --> Controller Class Initialized
INFO - 2024-02-07 19:08:57 --> Form Validation Class Initialized
INFO - 2024-02-07 19:08:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:08:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:08:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:08:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:08:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:08:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:08:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:08:57 --> Final output sent to browser
DEBUG - 2024-02-07 19:08:57 --> Total execution time: 0.0269
ERROR - 2024-02-07 19:08:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:08:57 --> Config Class Initialized
INFO - 2024-02-07 19:08:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:08:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:08:57 --> Utf8 Class Initialized
INFO - 2024-02-07 19:08:57 --> URI Class Initialized
INFO - 2024-02-07 19:08:57 --> Router Class Initialized
INFO - 2024-02-07 19:08:57 --> Output Class Initialized
INFO - 2024-02-07 19:08:57 --> Security Class Initialized
DEBUG - 2024-02-07 19:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:08:57 --> Input Class Initialized
INFO - 2024-02-07 19:08:57 --> Language Class Initialized
INFO - 2024-02-07 19:08:57 --> Loader Class Initialized
INFO - 2024-02-07 19:08:57 --> Helper loaded: url_helper
INFO - 2024-02-07 19:08:57 --> Helper loaded: file_helper
INFO - 2024-02-07 19:08:57 --> Helper loaded: form_helper
INFO - 2024-02-07 19:08:57 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:08:57 --> Controller Class Initialized
INFO - 2024-02-07 19:08:57 --> Form Validation Class Initialized
INFO - 2024-02-07 19:08:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:08:57 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:08:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:08:59 --> Config Class Initialized
INFO - 2024-02-07 19:08:59 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:08:59 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:08:59 --> Utf8 Class Initialized
INFO - 2024-02-07 19:08:59 --> URI Class Initialized
INFO - 2024-02-07 19:08:59 --> Router Class Initialized
INFO - 2024-02-07 19:08:59 --> Output Class Initialized
INFO - 2024-02-07 19:08:59 --> Security Class Initialized
DEBUG - 2024-02-07 19:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:08:59 --> Input Class Initialized
INFO - 2024-02-07 19:08:59 --> Language Class Initialized
INFO - 2024-02-07 19:08:59 --> Loader Class Initialized
INFO - 2024-02-07 19:08:59 --> Helper loaded: url_helper
INFO - 2024-02-07 19:08:59 --> Helper loaded: file_helper
INFO - 2024-02-07 19:08:59 --> Helper loaded: form_helper
INFO - 2024-02-07 19:08:59 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:08:59 --> Controller Class Initialized
INFO - 2024-02-07 19:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:08:59 --> Final output sent to browser
DEBUG - 2024-02-07 19:08:59 --> Total execution time: 0.0253
ERROR - 2024-02-07 19:09:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:09:01 --> Config Class Initialized
INFO - 2024-02-07 19:09:01 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:09:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:09:01 --> Utf8 Class Initialized
INFO - 2024-02-07 19:09:01 --> URI Class Initialized
INFO - 2024-02-07 19:09:01 --> Router Class Initialized
INFO - 2024-02-07 19:09:01 --> Output Class Initialized
INFO - 2024-02-07 19:09:01 --> Security Class Initialized
DEBUG - 2024-02-07 19:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:09:01 --> Input Class Initialized
INFO - 2024-02-07 19:09:01 --> Language Class Initialized
INFO - 2024-02-07 19:09:01 --> Loader Class Initialized
INFO - 2024-02-07 19:09:01 --> Helper loaded: url_helper
INFO - 2024-02-07 19:09:01 --> Helper loaded: file_helper
INFO - 2024-02-07 19:09:01 --> Helper loaded: form_helper
INFO - 2024-02-07 19:09:01 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:09:01 --> Controller Class Initialized
INFO - 2024-02-07 19:09:01 --> Form Validation Class Initialized
INFO - 2024-02-07 19:09:01 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:09:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:09:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:09:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:09:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:09:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:09:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:09:01 --> Final output sent to browser
DEBUG - 2024-02-07 19:09:01 --> Total execution time: 0.0324
ERROR - 2024-02-07 19:09:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:09:01 --> Config Class Initialized
INFO - 2024-02-07 19:09:01 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:09:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:09:01 --> Utf8 Class Initialized
INFO - 2024-02-07 19:09:01 --> URI Class Initialized
INFO - 2024-02-07 19:09:01 --> Router Class Initialized
INFO - 2024-02-07 19:09:01 --> Output Class Initialized
INFO - 2024-02-07 19:09:01 --> Security Class Initialized
DEBUG - 2024-02-07 19:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:09:01 --> Input Class Initialized
INFO - 2024-02-07 19:09:01 --> Language Class Initialized
INFO - 2024-02-07 19:09:01 --> Loader Class Initialized
INFO - 2024-02-07 19:09:01 --> Helper loaded: url_helper
INFO - 2024-02-07 19:09:01 --> Helper loaded: file_helper
INFO - 2024-02-07 19:09:01 --> Helper loaded: form_helper
INFO - 2024-02-07 19:09:01 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:09:01 --> Controller Class Initialized
INFO - 2024-02-07 19:09:01 --> Form Validation Class Initialized
INFO - 2024-02-07 19:09:01 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:09:01 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:09:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:09:06 --> Config Class Initialized
INFO - 2024-02-07 19:09:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:09:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:09:06 --> Utf8 Class Initialized
INFO - 2024-02-07 19:09:06 --> URI Class Initialized
INFO - 2024-02-07 19:09:06 --> Router Class Initialized
INFO - 2024-02-07 19:09:06 --> Output Class Initialized
INFO - 2024-02-07 19:09:06 --> Security Class Initialized
DEBUG - 2024-02-07 19:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:09:06 --> Input Class Initialized
INFO - 2024-02-07 19:09:06 --> Language Class Initialized
INFO - 2024-02-07 19:09:06 --> Loader Class Initialized
INFO - 2024-02-07 19:09:06 --> Helper loaded: url_helper
INFO - 2024-02-07 19:09:06 --> Helper loaded: file_helper
INFO - 2024-02-07 19:09:06 --> Helper loaded: form_helper
INFO - 2024-02-07 19:09:06 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:09:06 --> Controller Class Initialized
INFO - 2024-02-07 19:09:06 --> Form Validation Class Initialized
INFO - 2024-02-07 19:09:06 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:09:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:09:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:09:06 --> Final output sent to browser
DEBUG - 2024-02-07 19:09:06 --> Total execution time: 0.0331
ERROR - 2024-02-07 19:09:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:09:27 --> Config Class Initialized
INFO - 2024-02-07 19:09:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:09:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:09:27 --> Utf8 Class Initialized
INFO - 2024-02-07 19:09:27 --> URI Class Initialized
INFO - 2024-02-07 19:09:27 --> Router Class Initialized
INFO - 2024-02-07 19:09:27 --> Output Class Initialized
INFO - 2024-02-07 19:09:27 --> Security Class Initialized
DEBUG - 2024-02-07 19:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:09:27 --> Input Class Initialized
INFO - 2024-02-07 19:09:27 --> Language Class Initialized
INFO - 2024-02-07 19:09:27 --> Loader Class Initialized
INFO - 2024-02-07 19:09:27 --> Helper loaded: url_helper
INFO - 2024-02-07 19:09:27 --> Helper loaded: file_helper
INFO - 2024-02-07 19:09:27 --> Helper loaded: form_helper
INFO - 2024-02-07 19:09:27 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:09:27 --> Controller Class Initialized
INFO - 2024-02-07 19:09:27 --> Form Validation Class Initialized
INFO - 2024-02-07 19:09:27 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:09:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:09:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:09:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:09:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:09:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:09:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:09:27 --> Final output sent to browser
DEBUG - 2024-02-07 19:09:27 --> Total execution time: 0.0303
ERROR - 2024-02-07 19:09:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:09:27 --> Config Class Initialized
INFO - 2024-02-07 19:09:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:09:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:09:27 --> Utf8 Class Initialized
INFO - 2024-02-07 19:09:27 --> URI Class Initialized
INFO - 2024-02-07 19:09:27 --> Router Class Initialized
INFO - 2024-02-07 19:09:27 --> Output Class Initialized
INFO - 2024-02-07 19:09:27 --> Security Class Initialized
DEBUG - 2024-02-07 19:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:09:27 --> Input Class Initialized
INFO - 2024-02-07 19:09:27 --> Language Class Initialized
INFO - 2024-02-07 19:09:27 --> Loader Class Initialized
INFO - 2024-02-07 19:09:27 --> Helper loaded: url_helper
INFO - 2024-02-07 19:09:27 --> Helper loaded: file_helper
INFO - 2024-02-07 19:09:27 --> Helper loaded: form_helper
INFO - 2024-02-07 19:09:27 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:09:27 --> Controller Class Initialized
INFO - 2024-02-07 19:09:27 --> Form Validation Class Initialized
INFO - 2024-02-07 19:09:27 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:09:27 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:09:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:09:29 --> Config Class Initialized
INFO - 2024-02-07 19:09:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:09:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:09:29 --> Utf8 Class Initialized
INFO - 2024-02-07 19:09:29 --> URI Class Initialized
INFO - 2024-02-07 19:09:29 --> Router Class Initialized
INFO - 2024-02-07 19:09:29 --> Output Class Initialized
INFO - 2024-02-07 19:09:29 --> Security Class Initialized
DEBUG - 2024-02-07 19:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:09:29 --> Input Class Initialized
INFO - 2024-02-07 19:09:29 --> Language Class Initialized
INFO - 2024-02-07 19:09:29 --> Loader Class Initialized
INFO - 2024-02-07 19:09:29 --> Helper loaded: url_helper
INFO - 2024-02-07 19:09:29 --> Helper loaded: file_helper
INFO - 2024-02-07 19:09:29 --> Helper loaded: form_helper
INFO - 2024-02-07 19:09:29 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:09:29 --> Controller Class Initialized
INFO - 2024-02-07 19:09:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:09:29 --> Final output sent to browser
DEBUG - 2024-02-07 19:09:29 --> Total execution time: 0.0207
ERROR - 2024-02-07 19:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:09:36 --> Config Class Initialized
INFO - 2024-02-07 19:09:36 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:09:36 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:09:36 --> Utf8 Class Initialized
INFO - 2024-02-07 19:09:36 --> URI Class Initialized
INFO - 2024-02-07 19:09:36 --> Router Class Initialized
INFO - 2024-02-07 19:09:36 --> Output Class Initialized
INFO - 2024-02-07 19:09:36 --> Security Class Initialized
DEBUG - 2024-02-07 19:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:09:36 --> Input Class Initialized
INFO - 2024-02-07 19:09:37 --> Language Class Initialized
INFO - 2024-02-07 19:09:37 --> Loader Class Initialized
INFO - 2024-02-07 19:09:37 --> Helper loaded: url_helper
INFO - 2024-02-07 19:09:37 --> Helper loaded: file_helper
INFO - 2024-02-07 19:09:37 --> Helper loaded: form_helper
INFO - 2024-02-07 19:09:37 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:09:37 --> Controller Class Initialized
INFO - 2024-02-07 19:09:37 --> Form Validation Class Initialized
INFO - 2024-02-07 19:09:37 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:09:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:09:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:09:37 --> Final output sent to browser
DEBUG - 2024-02-07 19:09:37 --> Total execution time: 0.0317
ERROR - 2024-02-07 19:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:10:16 --> Config Class Initialized
INFO - 2024-02-07 19:10:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:10:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:10:16 --> Utf8 Class Initialized
INFO - 2024-02-07 19:10:16 --> URI Class Initialized
INFO - 2024-02-07 19:10:16 --> Router Class Initialized
INFO - 2024-02-07 19:10:16 --> Output Class Initialized
INFO - 2024-02-07 19:10:16 --> Security Class Initialized
DEBUG - 2024-02-07 19:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:10:16 --> Input Class Initialized
INFO - 2024-02-07 19:10:16 --> Language Class Initialized
INFO - 2024-02-07 19:10:16 --> Loader Class Initialized
INFO - 2024-02-07 19:10:16 --> Helper loaded: url_helper
INFO - 2024-02-07 19:10:16 --> Helper loaded: file_helper
INFO - 2024-02-07 19:10:16 --> Helper loaded: form_helper
INFO - 2024-02-07 19:10:16 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:10:16 --> Controller Class Initialized
INFO - 2024-02-07 19:10:16 --> Form Validation Class Initialized
INFO - 2024-02-07 19:10:16 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:10:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:10:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:10:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:10:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:10:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:10:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:10:16 --> Final output sent to browser
DEBUG - 2024-02-07 19:10:16 --> Total execution time: 0.0239
ERROR - 2024-02-07 19:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:10:16 --> Config Class Initialized
INFO - 2024-02-07 19:10:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:10:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:10:16 --> Utf8 Class Initialized
INFO - 2024-02-07 19:10:16 --> URI Class Initialized
INFO - 2024-02-07 19:10:16 --> Router Class Initialized
INFO - 2024-02-07 19:10:16 --> Output Class Initialized
INFO - 2024-02-07 19:10:16 --> Security Class Initialized
DEBUG - 2024-02-07 19:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:10:16 --> Input Class Initialized
INFO - 2024-02-07 19:10:16 --> Language Class Initialized
INFO - 2024-02-07 19:10:16 --> Loader Class Initialized
INFO - 2024-02-07 19:10:16 --> Helper loaded: url_helper
INFO - 2024-02-07 19:10:16 --> Helper loaded: file_helper
INFO - 2024-02-07 19:10:16 --> Helper loaded: form_helper
INFO - 2024-02-07 19:10:16 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:10:16 --> Controller Class Initialized
INFO - 2024-02-07 19:10:16 --> Form Validation Class Initialized
INFO - 2024-02-07 19:10:16 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:10:16 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:10:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:10:18 --> Config Class Initialized
INFO - 2024-02-07 19:10:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:10:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:10:18 --> Utf8 Class Initialized
INFO - 2024-02-07 19:10:18 --> URI Class Initialized
INFO - 2024-02-07 19:10:18 --> Router Class Initialized
INFO - 2024-02-07 19:10:18 --> Output Class Initialized
INFO - 2024-02-07 19:10:18 --> Security Class Initialized
DEBUG - 2024-02-07 19:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:10:18 --> Input Class Initialized
INFO - 2024-02-07 19:10:18 --> Language Class Initialized
INFO - 2024-02-07 19:10:18 --> Loader Class Initialized
INFO - 2024-02-07 19:10:18 --> Helper loaded: url_helper
INFO - 2024-02-07 19:10:18 --> Helper loaded: file_helper
INFO - 2024-02-07 19:10:18 --> Helper loaded: form_helper
INFO - 2024-02-07 19:10:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:10:18 --> Controller Class Initialized
INFO - 2024-02-07 19:10:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:10:18 --> Final output sent to browser
DEBUG - 2024-02-07 19:10:18 --> Total execution time: 0.0191
ERROR - 2024-02-07 19:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:10:20 --> Config Class Initialized
INFO - 2024-02-07 19:10:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:10:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:10:20 --> Utf8 Class Initialized
INFO - 2024-02-07 19:10:20 --> URI Class Initialized
INFO - 2024-02-07 19:10:20 --> Router Class Initialized
INFO - 2024-02-07 19:10:20 --> Output Class Initialized
INFO - 2024-02-07 19:10:20 --> Security Class Initialized
DEBUG - 2024-02-07 19:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:10:20 --> Input Class Initialized
INFO - 2024-02-07 19:10:20 --> Language Class Initialized
INFO - 2024-02-07 19:10:20 --> Loader Class Initialized
INFO - 2024-02-07 19:10:20 --> Helper loaded: url_helper
INFO - 2024-02-07 19:10:20 --> Helper loaded: file_helper
INFO - 2024-02-07 19:10:20 --> Helper loaded: form_helper
INFO - 2024-02-07 19:10:20 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:10:20 --> Controller Class Initialized
INFO - 2024-02-07 19:10:20 --> Form Validation Class Initialized
INFO - 2024-02-07 19:10:20 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:10:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:10:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:10:20 --> Final output sent to browser
DEBUG - 2024-02-07 19:10:20 --> Total execution time: 0.0294
ERROR - 2024-02-07 19:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:10:32 --> Config Class Initialized
INFO - 2024-02-07 19:10:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:10:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:10:32 --> Utf8 Class Initialized
INFO - 2024-02-07 19:10:32 --> URI Class Initialized
INFO - 2024-02-07 19:10:32 --> Router Class Initialized
INFO - 2024-02-07 19:10:32 --> Output Class Initialized
INFO - 2024-02-07 19:10:32 --> Security Class Initialized
DEBUG - 2024-02-07 19:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:10:32 --> Input Class Initialized
INFO - 2024-02-07 19:10:32 --> Language Class Initialized
INFO - 2024-02-07 19:10:32 --> Loader Class Initialized
INFO - 2024-02-07 19:10:32 --> Helper loaded: url_helper
INFO - 2024-02-07 19:10:32 --> Helper loaded: file_helper
INFO - 2024-02-07 19:10:32 --> Helper loaded: form_helper
INFO - 2024-02-07 19:10:32 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:10:32 --> Controller Class Initialized
INFO - 2024-02-07 19:10:32 --> Form Validation Class Initialized
INFO - 2024-02-07 19:10:32 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:10:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:10:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:10:32 --> Final output sent to browser
DEBUG - 2024-02-07 19:10:32 --> Total execution time: 0.0378
ERROR - 2024-02-07 19:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:10:32 --> Config Class Initialized
INFO - 2024-02-07 19:10:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:10:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:10:32 --> Utf8 Class Initialized
INFO - 2024-02-07 19:10:32 --> URI Class Initialized
INFO - 2024-02-07 19:10:32 --> Router Class Initialized
INFO - 2024-02-07 19:10:32 --> Output Class Initialized
INFO - 2024-02-07 19:10:32 --> Security Class Initialized
DEBUG - 2024-02-07 19:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:10:32 --> Input Class Initialized
INFO - 2024-02-07 19:10:32 --> Language Class Initialized
INFO - 2024-02-07 19:10:32 --> Loader Class Initialized
INFO - 2024-02-07 19:10:32 --> Helper loaded: url_helper
INFO - 2024-02-07 19:10:32 --> Helper loaded: file_helper
INFO - 2024-02-07 19:10:32 --> Helper loaded: form_helper
INFO - 2024-02-07 19:10:32 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:10:32 --> Controller Class Initialized
INFO - 2024-02-07 19:10:32 --> Form Validation Class Initialized
INFO - 2024-02-07 19:10:32 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:10:32 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:10:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:10:35 --> Config Class Initialized
INFO - 2024-02-07 19:10:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:10:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:10:35 --> Utf8 Class Initialized
INFO - 2024-02-07 19:10:35 --> URI Class Initialized
INFO - 2024-02-07 19:10:35 --> Router Class Initialized
INFO - 2024-02-07 19:10:35 --> Output Class Initialized
INFO - 2024-02-07 19:10:35 --> Security Class Initialized
DEBUG - 2024-02-07 19:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:10:35 --> Input Class Initialized
INFO - 2024-02-07 19:10:35 --> Language Class Initialized
INFO - 2024-02-07 19:10:35 --> Loader Class Initialized
INFO - 2024-02-07 19:10:35 --> Helper loaded: url_helper
INFO - 2024-02-07 19:10:35 --> Helper loaded: file_helper
INFO - 2024-02-07 19:10:35 --> Helper loaded: form_helper
INFO - 2024-02-07 19:10:35 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:10:35 --> Controller Class Initialized
INFO - 2024-02-07 19:10:35 --> Form Validation Class Initialized
INFO - 2024-02-07 19:10:35 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:10:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:10:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:10:35 --> Final output sent to browser
DEBUG - 2024-02-07 19:10:35 --> Total execution time: 0.0279
ERROR - 2024-02-07 19:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:11:37 --> Config Class Initialized
INFO - 2024-02-07 19:11:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:11:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:11:37 --> Utf8 Class Initialized
INFO - 2024-02-07 19:11:37 --> URI Class Initialized
INFO - 2024-02-07 19:11:37 --> Router Class Initialized
INFO - 2024-02-07 19:11:37 --> Output Class Initialized
INFO - 2024-02-07 19:11:37 --> Security Class Initialized
DEBUG - 2024-02-07 19:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:11:37 --> Input Class Initialized
INFO - 2024-02-07 19:11:37 --> Language Class Initialized
INFO - 2024-02-07 19:11:37 --> Loader Class Initialized
INFO - 2024-02-07 19:11:37 --> Helper loaded: url_helper
INFO - 2024-02-07 19:11:37 --> Helper loaded: file_helper
INFO - 2024-02-07 19:11:37 --> Helper loaded: form_helper
INFO - 2024-02-07 19:11:37 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:11:37 --> Controller Class Initialized
INFO - 2024-02-07 19:11:37 --> Form Validation Class Initialized
INFO - 2024-02-07 19:11:37 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:11:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:11:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:11:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:11:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:11:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:11:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:11:37 --> Final output sent to browser
DEBUG - 2024-02-07 19:11:37 --> Total execution time: 0.0303
ERROR - 2024-02-07 19:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:11:37 --> Config Class Initialized
INFO - 2024-02-07 19:11:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:11:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:11:37 --> Utf8 Class Initialized
INFO - 2024-02-07 19:11:37 --> URI Class Initialized
INFO - 2024-02-07 19:11:37 --> Router Class Initialized
INFO - 2024-02-07 19:11:37 --> Output Class Initialized
INFO - 2024-02-07 19:11:37 --> Security Class Initialized
DEBUG - 2024-02-07 19:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:11:37 --> Input Class Initialized
INFO - 2024-02-07 19:11:37 --> Language Class Initialized
INFO - 2024-02-07 19:11:37 --> Loader Class Initialized
INFO - 2024-02-07 19:11:37 --> Helper loaded: url_helper
INFO - 2024-02-07 19:11:37 --> Helper loaded: file_helper
INFO - 2024-02-07 19:11:37 --> Helper loaded: form_helper
INFO - 2024-02-07 19:11:37 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:11:37 --> Controller Class Initialized
INFO - 2024-02-07 19:11:37 --> Form Validation Class Initialized
INFO - 2024-02-07 19:11:37 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:11:37 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:11:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:11:41 --> Config Class Initialized
INFO - 2024-02-07 19:11:41 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:11:41 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:11:41 --> Utf8 Class Initialized
INFO - 2024-02-07 19:11:41 --> URI Class Initialized
INFO - 2024-02-07 19:11:41 --> Router Class Initialized
INFO - 2024-02-07 19:11:41 --> Output Class Initialized
INFO - 2024-02-07 19:11:41 --> Security Class Initialized
DEBUG - 2024-02-07 19:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:11:41 --> Input Class Initialized
INFO - 2024-02-07 19:11:41 --> Language Class Initialized
INFO - 2024-02-07 19:11:41 --> Loader Class Initialized
INFO - 2024-02-07 19:11:41 --> Helper loaded: url_helper
INFO - 2024-02-07 19:11:41 --> Helper loaded: file_helper
INFO - 2024-02-07 19:11:41 --> Helper loaded: form_helper
INFO - 2024-02-07 19:11:41 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:11:41 --> Controller Class Initialized
INFO - 2024-02-07 19:11:41 --> Form Validation Class Initialized
INFO - 2024-02-07 19:11:41 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:11:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:11:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:11:41 --> Final output sent to browser
DEBUG - 2024-02-07 19:11:41 --> Total execution time: 0.0276
ERROR - 2024-02-07 19:12:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:12:06 --> Config Class Initialized
INFO - 2024-02-07 19:12:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:12:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:12:06 --> Utf8 Class Initialized
INFO - 2024-02-07 19:12:06 --> URI Class Initialized
INFO - 2024-02-07 19:12:06 --> Router Class Initialized
INFO - 2024-02-07 19:12:06 --> Output Class Initialized
INFO - 2024-02-07 19:12:06 --> Security Class Initialized
DEBUG - 2024-02-07 19:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:12:06 --> Input Class Initialized
INFO - 2024-02-07 19:12:06 --> Language Class Initialized
INFO - 2024-02-07 19:12:06 --> Loader Class Initialized
INFO - 2024-02-07 19:12:06 --> Helper loaded: url_helper
INFO - 2024-02-07 19:12:06 --> Helper loaded: file_helper
INFO - 2024-02-07 19:12:06 --> Helper loaded: form_helper
INFO - 2024-02-07 19:12:06 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:12:06 --> Controller Class Initialized
INFO - 2024-02-07 19:12:06 --> Form Validation Class Initialized
INFO - 2024-02-07 19:12:06 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:12:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:12:06 --> Final output sent to browser
DEBUG - 2024-02-07 19:12:06 --> Total execution time: 0.0294
ERROR - 2024-02-07 19:12:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:12:07 --> Config Class Initialized
INFO - 2024-02-07 19:12:07 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:12:07 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:12:07 --> Utf8 Class Initialized
INFO - 2024-02-07 19:12:07 --> URI Class Initialized
INFO - 2024-02-07 19:12:07 --> Router Class Initialized
INFO - 2024-02-07 19:12:07 --> Output Class Initialized
INFO - 2024-02-07 19:12:07 --> Security Class Initialized
DEBUG - 2024-02-07 19:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:12:07 --> Input Class Initialized
INFO - 2024-02-07 19:12:07 --> Language Class Initialized
INFO - 2024-02-07 19:12:07 --> Loader Class Initialized
INFO - 2024-02-07 19:12:07 --> Helper loaded: url_helper
INFO - 2024-02-07 19:12:07 --> Helper loaded: file_helper
INFO - 2024-02-07 19:12:07 --> Helper loaded: form_helper
INFO - 2024-02-07 19:12:07 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:12:07 --> Controller Class Initialized
INFO - 2024-02-07 19:12:07 --> Form Validation Class Initialized
INFO - 2024-02-07 19:12:07 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:12:07 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:12:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:12:10 --> Config Class Initialized
INFO - 2024-02-07 19:12:10 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:12:10 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:12:10 --> Utf8 Class Initialized
INFO - 2024-02-07 19:12:10 --> URI Class Initialized
INFO - 2024-02-07 19:12:10 --> Router Class Initialized
INFO - 2024-02-07 19:12:10 --> Output Class Initialized
INFO - 2024-02-07 19:12:10 --> Security Class Initialized
DEBUG - 2024-02-07 19:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:12:10 --> Input Class Initialized
INFO - 2024-02-07 19:12:10 --> Language Class Initialized
INFO - 2024-02-07 19:12:10 --> Loader Class Initialized
INFO - 2024-02-07 19:12:10 --> Helper loaded: url_helper
INFO - 2024-02-07 19:12:10 --> Helper loaded: file_helper
INFO - 2024-02-07 19:12:10 --> Helper loaded: form_helper
INFO - 2024-02-07 19:12:10 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:12:10 --> Controller Class Initialized
INFO - 2024-02-07 19:12:10 --> Form Validation Class Initialized
INFO - 2024-02-07 19:12:10 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:12:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:12:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:12:10 --> Final output sent to browser
DEBUG - 2024-02-07 19:12:10 --> Total execution time: 0.0288
ERROR - 2024-02-07 19:12:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:12:38 --> Config Class Initialized
INFO - 2024-02-07 19:12:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:12:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:12:38 --> Utf8 Class Initialized
INFO - 2024-02-07 19:12:38 --> URI Class Initialized
INFO - 2024-02-07 19:12:38 --> Router Class Initialized
INFO - 2024-02-07 19:12:38 --> Output Class Initialized
INFO - 2024-02-07 19:12:38 --> Security Class Initialized
DEBUG - 2024-02-07 19:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:12:38 --> Input Class Initialized
INFO - 2024-02-07 19:12:38 --> Language Class Initialized
INFO - 2024-02-07 19:12:38 --> Loader Class Initialized
INFO - 2024-02-07 19:12:38 --> Helper loaded: url_helper
INFO - 2024-02-07 19:12:38 --> Helper loaded: file_helper
INFO - 2024-02-07 19:12:38 --> Helper loaded: form_helper
INFO - 2024-02-07 19:12:38 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:12:38 --> Controller Class Initialized
INFO - 2024-02-07 19:12:38 --> Form Validation Class Initialized
INFO - 2024-02-07 19:12:38 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:12:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:12:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:12:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:12:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:12:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:12:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:12:38 --> Final output sent to browser
DEBUG - 2024-02-07 19:12:38 --> Total execution time: 0.0205
ERROR - 2024-02-07 19:12:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:12:38 --> Config Class Initialized
INFO - 2024-02-07 19:12:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:12:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:12:38 --> Utf8 Class Initialized
INFO - 2024-02-07 19:12:38 --> URI Class Initialized
INFO - 2024-02-07 19:12:38 --> Router Class Initialized
INFO - 2024-02-07 19:12:38 --> Output Class Initialized
INFO - 2024-02-07 19:12:38 --> Security Class Initialized
DEBUG - 2024-02-07 19:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:12:38 --> Input Class Initialized
INFO - 2024-02-07 19:12:38 --> Language Class Initialized
INFO - 2024-02-07 19:12:38 --> Loader Class Initialized
INFO - 2024-02-07 19:12:38 --> Helper loaded: url_helper
INFO - 2024-02-07 19:12:38 --> Helper loaded: file_helper
INFO - 2024-02-07 19:12:38 --> Helper loaded: form_helper
INFO - 2024-02-07 19:12:38 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:12:38 --> Controller Class Initialized
INFO - 2024-02-07 19:12:38 --> Form Validation Class Initialized
INFO - 2024-02-07 19:12:38 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:12:38 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:12:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:12:40 --> Config Class Initialized
INFO - 2024-02-07 19:12:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:12:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:12:40 --> Utf8 Class Initialized
INFO - 2024-02-07 19:12:40 --> URI Class Initialized
INFO - 2024-02-07 19:12:40 --> Router Class Initialized
INFO - 2024-02-07 19:12:40 --> Output Class Initialized
INFO - 2024-02-07 19:12:40 --> Security Class Initialized
DEBUG - 2024-02-07 19:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:12:40 --> Input Class Initialized
INFO - 2024-02-07 19:12:40 --> Language Class Initialized
INFO - 2024-02-07 19:12:40 --> Loader Class Initialized
INFO - 2024-02-07 19:12:40 --> Helper loaded: url_helper
INFO - 2024-02-07 19:12:40 --> Helper loaded: file_helper
INFO - 2024-02-07 19:12:40 --> Helper loaded: form_helper
INFO - 2024-02-07 19:12:40 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:12:40 --> Controller Class Initialized
INFO - 2024-02-07 19:12:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:12:40 --> Final output sent to browser
DEBUG - 2024-02-07 19:12:40 --> Total execution time: 0.0212
ERROR - 2024-02-07 19:12:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:12:41 --> Config Class Initialized
INFO - 2024-02-07 19:12:41 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:12:41 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:12:41 --> Utf8 Class Initialized
INFO - 2024-02-07 19:12:41 --> URI Class Initialized
INFO - 2024-02-07 19:12:41 --> Router Class Initialized
INFO - 2024-02-07 19:12:41 --> Output Class Initialized
INFO - 2024-02-07 19:12:41 --> Security Class Initialized
DEBUG - 2024-02-07 19:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:12:41 --> Input Class Initialized
INFO - 2024-02-07 19:12:41 --> Language Class Initialized
INFO - 2024-02-07 19:12:41 --> Loader Class Initialized
INFO - 2024-02-07 19:12:41 --> Helper loaded: url_helper
INFO - 2024-02-07 19:12:41 --> Helper loaded: file_helper
INFO - 2024-02-07 19:12:41 --> Helper loaded: form_helper
INFO - 2024-02-07 19:12:41 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:12:41 --> Controller Class Initialized
INFO - 2024-02-07 19:12:41 --> Form Validation Class Initialized
INFO - 2024-02-07 19:12:41 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:12:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:12:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:12:41 --> Final output sent to browser
DEBUG - 2024-02-07 19:12:41 --> Total execution time: 0.0265
ERROR - 2024-02-07 19:12:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:12:55 --> Config Class Initialized
INFO - 2024-02-07 19:12:55 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:12:55 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:12:55 --> Utf8 Class Initialized
INFO - 2024-02-07 19:12:55 --> URI Class Initialized
INFO - 2024-02-07 19:12:55 --> Router Class Initialized
INFO - 2024-02-07 19:12:55 --> Output Class Initialized
INFO - 2024-02-07 19:12:55 --> Security Class Initialized
DEBUG - 2024-02-07 19:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:12:55 --> Input Class Initialized
INFO - 2024-02-07 19:12:55 --> Language Class Initialized
INFO - 2024-02-07 19:12:55 --> Loader Class Initialized
INFO - 2024-02-07 19:12:55 --> Helper loaded: url_helper
INFO - 2024-02-07 19:12:55 --> Helper loaded: file_helper
INFO - 2024-02-07 19:12:55 --> Helper loaded: form_helper
INFO - 2024-02-07 19:12:55 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:12:55 --> Controller Class Initialized
INFO - 2024-02-07 19:12:55 --> Form Validation Class Initialized
INFO - 2024-02-07 19:12:55 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:12:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:12:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:12:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:12:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:12:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:12:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:12:55 --> Final output sent to browser
DEBUG - 2024-02-07 19:12:55 --> Total execution time: 0.0271
ERROR - 2024-02-07 19:12:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:12:55 --> Config Class Initialized
INFO - 2024-02-07 19:12:55 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:12:55 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:12:55 --> Utf8 Class Initialized
INFO - 2024-02-07 19:12:55 --> URI Class Initialized
INFO - 2024-02-07 19:12:55 --> Router Class Initialized
INFO - 2024-02-07 19:12:55 --> Output Class Initialized
INFO - 2024-02-07 19:12:55 --> Security Class Initialized
DEBUG - 2024-02-07 19:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:12:55 --> Input Class Initialized
INFO - 2024-02-07 19:12:55 --> Language Class Initialized
INFO - 2024-02-07 19:12:55 --> Loader Class Initialized
INFO - 2024-02-07 19:12:55 --> Helper loaded: url_helper
INFO - 2024-02-07 19:12:55 --> Helper loaded: file_helper
INFO - 2024-02-07 19:12:55 --> Helper loaded: form_helper
INFO - 2024-02-07 19:12:55 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:12:55 --> Controller Class Initialized
INFO - 2024-02-07 19:12:55 --> Form Validation Class Initialized
INFO - 2024-02-07 19:12:55 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:12:55 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:12:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:12:58 --> Config Class Initialized
INFO - 2024-02-07 19:12:58 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:12:58 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:12:58 --> Utf8 Class Initialized
INFO - 2024-02-07 19:12:58 --> URI Class Initialized
INFO - 2024-02-07 19:12:58 --> Router Class Initialized
INFO - 2024-02-07 19:12:58 --> Output Class Initialized
INFO - 2024-02-07 19:12:58 --> Security Class Initialized
DEBUG - 2024-02-07 19:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:12:58 --> Input Class Initialized
INFO - 2024-02-07 19:12:58 --> Language Class Initialized
INFO - 2024-02-07 19:12:58 --> Loader Class Initialized
INFO - 2024-02-07 19:12:58 --> Helper loaded: url_helper
INFO - 2024-02-07 19:12:58 --> Helper loaded: file_helper
INFO - 2024-02-07 19:12:58 --> Helper loaded: form_helper
INFO - 2024-02-07 19:12:58 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:12:58 --> Controller Class Initialized
INFO - 2024-02-07 19:12:58 --> Form Validation Class Initialized
INFO - 2024-02-07 19:12:58 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:12:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:12:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:12:58 --> Final output sent to browser
DEBUG - 2024-02-07 19:12:58 --> Total execution time: 0.0277
ERROR - 2024-02-07 19:13:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:13:06 --> Config Class Initialized
INFO - 2024-02-07 19:13:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:13:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:13:06 --> Utf8 Class Initialized
INFO - 2024-02-07 19:13:06 --> URI Class Initialized
INFO - 2024-02-07 19:13:06 --> Router Class Initialized
INFO - 2024-02-07 19:13:06 --> Output Class Initialized
INFO - 2024-02-07 19:13:06 --> Security Class Initialized
DEBUG - 2024-02-07 19:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:13:06 --> Input Class Initialized
INFO - 2024-02-07 19:13:06 --> Language Class Initialized
INFO - 2024-02-07 19:13:06 --> Loader Class Initialized
INFO - 2024-02-07 19:13:06 --> Helper loaded: url_helper
INFO - 2024-02-07 19:13:06 --> Helper loaded: file_helper
INFO - 2024-02-07 19:13:06 --> Helper loaded: form_helper
INFO - 2024-02-07 19:13:06 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:13:06 --> Controller Class Initialized
INFO - 2024-02-07 19:13:06 --> Form Validation Class Initialized
INFO - 2024-02-07 19:13:06 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:13:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:13:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:13:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:13:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:13:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:13:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:13:06 --> Final output sent to browser
DEBUG - 2024-02-07 19:13:06 --> Total execution time: 0.0372
ERROR - 2024-02-07 19:13:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:13:06 --> Config Class Initialized
INFO - 2024-02-07 19:13:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:13:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:13:06 --> Utf8 Class Initialized
INFO - 2024-02-07 19:13:06 --> URI Class Initialized
INFO - 2024-02-07 19:13:06 --> Router Class Initialized
INFO - 2024-02-07 19:13:06 --> Output Class Initialized
INFO - 2024-02-07 19:13:06 --> Security Class Initialized
DEBUG - 2024-02-07 19:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:13:06 --> Input Class Initialized
INFO - 2024-02-07 19:13:06 --> Language Class Initialized
INFO - 2024-02-07 19:13:06 --> Loader Class Initialized
INFO - 2024-02-07 19:13:06 --> Helper loaded: url_helper
INFO - 2024-02-07 19:13:06 --> Helper loaded: file_helper
INFO - 2024-02-07 19:13:06 --> Helper loaded: form_helper
INFO - 2024-02-07 19:13:06 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:13:06 --> Controller Class Initialized
INFO - 2024-02-07 19:13:06 --> Form Validation Class Initialized
INFO - 2024-02-07 19:13:06 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:13:06 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:13:09 --> Config Class Initialized
INFO - 2024-02-07 19:13:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:13:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:13:09 --> Utf8 Class Initialized
INFO - 2024-02-07 19:13:09 --> URI Class Initialized
INFO - 2024-02-07 19:13:09 --> Router Class Initialized
INFO - 2024-02-07 19:13:09 --> Output Class Initialized
INFO - 2024-02-07 19:13:09 --> Security Class Initialized
DEBUG - 2024-02-07 19:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:13:09 --> Input Class Initialized
INFO - 2024-02-07 19:13:09 --> Language Class Initialized
INFO - 2024-02-07 19:13:09 --> Loader Class Initialized
INFO - 2024-02-07 19:13:09 --> Helper loaded: url_helper
INFO - 2024-02-07 19:13:09 --> Helper loaded: file_helper
INFO - 2024-02-07 19:13:09 --> Helper loaded: form_helper
INFO - 2024-02-07 19:13:09 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:13:09 --> Controller Class Initialized
INFO - 2024-02-07 19:13:09 --> Form Validation Class Initialized
INFO - 2024-02-07 19:13:09 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:13:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:13:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:13:09 --> Final output sent to browser
DEBUG - 2024-02-07 19:13:09 --> Total execution time: 0.0289
ERROR - 2024-02-07 19:13:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:13:32 --> Config Class Initialized
INFO - 2024-02-07 19:13:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:13:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:13:32 --> Utf8 Class Initialized
INFO - 2024-02-07 19:13:32 --> URI Class Initialized
INFO - 2024-02-07 19:13:32 --> Router Class Initialized
INFO - 2024-02-07 19:13:32 --> Output Class Initialized
INFO - 2024-02-07 19:13:32 --> Security Class Initialized
DEBUG - 2024-02-07 19:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:13:32 --> Input Class Initialized
INFO - 2024-02-07 19:13:32 --> Language Class Initialized
INFO - 2024-02-07 19:13:32 --> Loader Class Initialized
INFO - 2024-02-07 19:13:32 --> Helper loaded: url_helper
INFO - 2024-02-07 19:13:32 --> Helper loaded: file_helper
INFO - 2024-02-07 19:13:32 --> Helper loaded: form_helper
INFO - 2024-02-07 19:13:32 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:13:32 --> Controller Class Initialized
INFO - 2024-02-07 19:13:32 --> Form Validation Class Initialized
INFO - 2024-02-07 19:13:32 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:13:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:13:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:13:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:13:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:13:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:13:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:13:32 --> Final output sent to browser
DEBUG - 2024-02-07 19:13:32 --> Total execution time: 0.0331
ERROR - 2024-02-07 19:13:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:13:33 --> Config Class Initialized
INFO - 2024-02-07 19:13:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:13:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:13:33 --> Utf8 Class Initialized
INFO - 2024-02-07 19:13:33 --> URI Class Initialized
INFO - 2024-02-07 19:13:33 --> Router Class Initialized
INFO - 2024-02-07 19:13:33 --> Output Class Initialized
INFO - 2024-02-07 19:13:33 --> Security Class Initialized
DEBUG - 2024-02-07 19:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:13:33 --> Input Class Initialized
INFO - 2024-02-07 19:13:33 --> Language Class Initialized
INFO - 2024-02-07 19:13:33 --> Loader Class Initialized
INFO - 2024-02-07 19:13:33 --> Helper loaded: url_helper
INFO - 2024-02-07 19:13:33 --> Helper loaded: file_helper
INFO - 2024-02-07 19:13:33 --> Helper loaded: form_helper
INFO - 2024-02-07 19:13:33 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:13:33 --> Controller Class Initialized
INFO - 2024-02-07 19:13:33 --> Form Validation Class Initialized
INFO - 2024-02-07 19:13:33 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:13:33 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:13:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:13:36 --> Config Class Initialized
INFO - 2024-02-07 19:13:36 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:13:36 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:13:36 --> Utf8 Class Initialized
INFO - 2024-02-07 19:13:36 --> URI Class Initialized
INFO - 2024-02-07 19:13:36 --> Router Class Initialized
INFO - 2024-02-07 19:13:36 --> Output Class Initialized
INFO - 2024-02-07 19:13:36 --> Security Class Initialized
DEBUG - 2024-02-07 19:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:13:36 --> Input Class Initialized
INFO - 2024-02-07 19:13:36 --> Language Class Initialized
INFO - 2024-02-07 19:13:36 --> Loader Class Initialized
INFO - 2024-02-07 19:13:36 --> Helper loaded: url_helper
INFO - 2024-02-07 19:13:36 --> Helper loaded: file_helper
INFO - 2024-02-07 19:13:36 --> Helper loaded: form_helper
INFO - 2024-02-07 19:13:36 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:13:36 --> Controller Class Initialized
INFO - 2024-02-07 19:13:36 --> Form Validation Class Initialized
INFO - 2024-02-07 19:13:36 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:13:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:13:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:13:36 --> Final output sent to browser
DEBUG - 2024-02-07 19:13:36 --> Total execution time: 0.0353
ERROR - 2024-02-07 19:15:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:15:01 --> Config Class Initialized
INFO - 2024-02-07 19:15:01 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:15:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:15:01 --> Utf8 Class Initialized
INFO - 2024-02-07 19:15:01 --> URI Class Initialized
INFO - 2024-02-07 19:15:01 --> Router Class Initialized
INFO - 2024-02-07 19:15:01 --> Output Class Initialized
INFO - 2024-02-07 19:15:01 --> Security Class Initialized
DEBUG - 2024-02-07 19:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:15:01 --> Input Class Initialized
INFO - 2024-02-07 19:15:01 --> Language Class Initialized
INFO - 2024-02-07 19:15:01 --> Loader Class Initialized
INFO - 2024-02-07 19:15:01 --> Helper loaded: url_helper
INFO - 2024-02-07 19:15:01 --> Helper loaded: file_helper
INFO - 2024-02-07 19:15:01 --> Helper loaded: form_helper
INFO - 2024-02-07 19:15:01 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:15:01 --> Controller Class Initialized
INFO - 2024-02-07 19:15:01 --> Form Validation Class Initialized
INFO - 2024-02-07 19:15:01 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:15:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:15:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:15:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:15:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:15:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:15:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:15:01 --> Final output sent to browser
DEBUG - 2024-02-07 19:15:01 --> Total execution time: 0.0450
ERROR - 2024-02-07 19:15:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:15:02 --> Config Class Initialized
INFO - 2024-02-07 19:15:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:15:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:15:02 --> Utf8 Class Initialized
INFO - 2024-02-07 19:15:02 --> URI Class Initialized
INFO - 2024-02-07 19:15:02 --> Router Class Initialized
INFO - 2024-02-07 19:15:02 --> Output Class Initialized
INFO - 2024-02-07 19:15:02 --> Security Class Initialized
DEBUG - 2024-02-07 19:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:15:02 --> Input Class Initialized
INFO - 2024-02-07 19:15:02 --> Language Class Initialized
INFO - 2024-02-07 19:15:02 --> Loader Class Initialized
INFO - 2024-02-07 19:15:02 --> Helper loaded: url_helper
INFO - 2024-02-07 19:15:02 --> Helper loaded: file_helper
INFO - 2024-02-07 19:15:02 --> Helper loaded: form_helper
INFO - 2024-02-07 19:15:02 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:15:02 --> Controller Class Initialized
INFO - 2024-02-07 19:15:02 --> Form Validation Class Initialized
INFO - 2024-02-07 19:15:02 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:15:02 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:15:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:15:04 --> Config Class Initialized
INFO - 2024-02-07 19:15:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:15:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:15:04 --> Utf8 Class Initialized
INFO - 2024-02-07 19:15:04 --> URI Class Initialized
INFO - 2024-02-07 19:15:04 --> Router Class Initialized
INFO - 2024-02-07 19:15:04 --> Output Class Initialized
INFO - 2024-02-07 19:15:04 --> Security Class Initialized
DEBUG - 2024-02-07 19:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:15:04 --> Input Class Initialized
INFO - 2024-02-07 19:15:04 --> Language Class Initialized
INFO - 2024-02-07 19:15:04 --> Loader Class Initialized
INFO - 2024-02-07 19:15:04 --> Helper loaded: url_helper
INFO - 2024-02-07 19:15:04 --> Helper loaded: file_helper
INFO - 2024-02-07 19:15:04 --> Helper loaded: form_helper
INFO - 2024-02-07 19:15:04 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:15:04 --> Controller Class Initialized
INFO - 2024-02-07 19:15:04 --> Form Validation Class Initialized
INFO - 2024-02-07 19:15:04 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:15:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:15:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:15:04 --> Final output sent to browser
DEBUG - 2024-02-07 19:15:04 --> Total execution time: 0.0272
ERROR - 2024-02-07 19:15:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:15:23 --> Config Class Initialized
INFO - 2024-02-07 19:15:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:15:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:15:23 --> Utf8 Class Initialized
INFO - 2024-02-07 19:15:23 --> URI Class Initialized
INFO - 2024-02-07 19:15:23 --> Router Class Initialized
INFO - 2024-02-07 19:15:23 --> Output Class Initialized
INFO - 2024-02-07 19:15:23 --> Security Class Initialized
DEBUG - 2024-02-07 19:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:15:23 --> Input Class Initialized
INFO - 2024-02-07 19:15:23 --> Language Class Initialized
INFO - 2024-02-07 19:15:23 --> Loader Class Initialized
INFO - 2024-02-07 19:15:23 --> Helper loaded: url_helper
INFO - 2024-02-07 19:15:23 --> Helper loaded: file_helper
INFO - 2024-02-07 19:15:23 --> Helper loaded: form_helper
INFO - 2024-02-07 19:15:23 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:15:23 --> Controller Class Initialized
INFO - 2024-02-07 19:15:23 --> Form Validation Class Initialized
INFO - 2024-02-07 19:15:23 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:15:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:15:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:15:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:15:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:15:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:15:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:15:23 --> Final output sent to browser
DEBUG - 2024-02-07 19:15:23 --> Total execution time: 0.0311
ERROR - 2024-02-07 19:15:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:15:23 --> Config Class Initialized
INFO - 2024-02-07 19:15:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:15:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:15:23 --> Utf8 Class Initialized
INFO - 2024-02-07 19:15:23 --> URI Class Initialized
INFO - 2024-02-07 19:15:23 --> Router Class Initialized
INFO - 2024-02-07 19:15:23 --> Output Class Initialized
INFO - 2024-02-07 19:15:23 --> Security Class Initialized
DEBUG - 2024-02-07 19:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:15:23 --> Input Class Initialized
INFO - 2024-02-07 19:15:23 --> Language Class Initialized
INFO - 2024-02-07 19:15:23 --> Loader Class Initialized
INFO - 2024-02-07 19:15:23 --> Helper loaded: url_helper
INFO - 2024-02-07 19:15:23 --> Helper loaded: file_helper
INFO - 2024-02-07 19:15:23 --> Helper loaded: form_helper
INFO - 2024-02-07 19:15:23 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:15:23 --> Controller Class Initialized
INFO - 2024-02-07 19:15:23 --> Form Validation Class Initialized
INFO - 2024-02-07 19:15:23 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:15:23 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:15:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:15:25 --> Config Class Initialized
INFO - 2024-02-07 19:15:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:15:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:15:25 --> Utf8 Class Initialized
INFO - 2024-02-07 19:15:25 --> URI Class Initialized
INFO - 2024-02-07 19:15:25 --> Router Class Initialized
INFO - 2024-02-07 19:15:25 --> Output Class Initialized
INFO - 2024-02-07 19:15:25 --> Security Class Initialized
DEBUG - 2024-02-07 19:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:15:25 --> Input Class Initialized
INFO - 2024-02-07 19:15:25 --> Language Class Initialized
INFO - 2024-02-07 19:15:25 --> Loader Class Initialized
INFO - 2024-02-07 19:15:25 --> Helper loaded: url_helper
INFO - 2024-02-07 19:15:25 --> Helper loaded: file_helper
INFO - 2024-02-07 19:15:25 --> Helper loaded: form_helper
INFO - 2024-02-07 19:15:25 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:15:25 --> Controller Class Initialized
INFO - 2024-02-07 19:15:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:15:25 --> Final output sent to browser
DEBUG - 2024-02-07 19:15:25 --> Total execution time: 0.0295
ERROR - 2024-02-07 19:15:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:15:26 --> Config Class Initialized
INFO - 2024-02-07 19:15:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:15:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:15:26 --> Utf8 Class Initialized
INFO - 2024-02-07 19:15:26 --> URI Class Initialized
INFO - 2024-02-07 19:15:26 --> Router Class Initialized
INFO - 2024-02-07 19:15:26 --> Output Class Initialized
INFO - 2024-02-07 19:15:26 --> Security Class Initialized
DEBUG - 2024-02-07 19:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:15:26 --> Input Class Initialized
INFO - 2024-02-07 19:15:26 --> Language Class Initialized
INFO - 2024-02-07 19:15:26 --> Loader Class Initialized
INFO - 2024-02-07 19:15:26 --> Helper loaded: url_helper
INFO - 2024-02-07 19:15:26 --> Helper loaded: file_helper
INFO - 2024-02-07 19:15:26 --> Helper loaded: form_helper
INFO - 2024-02-07 19:15:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:15:26 --> Controller Class Initialized
INFO - 2024-02-07 19:15:26 --> Form Validation Class Initialized
INFO - 2024-02-07 19:15:26 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:15:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:15:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:15:26 --> Final output sent to browser
DEBUG - 2024-02-07 19:15:26 --> Total execution time: 0.0261
ERROR - 2024-02-07 19:15:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:15:32 --> Config Class Initialized
INFO - 2024-02-07 19:15:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:15:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:15:32 --> Utf8 Class Initialized
INFO - 2024-02-07 19:15:32 --> URI Class Initialized
INFO - 2024-02-07 19:15:32 --> Router Class Initialized
INFO - 2024-02-07 19:15:32 --> Output Class Initialized
INFO - 2024-02-07 19:15:32 --> Security Class Initialized
DEBUG - 2024-02-07 19:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:15:32 --> Input Class Initialized
INFO - 2024-02-07 19:15:32 --> Language Class Initialized
INFO - 2024-02-07 19:15:32 --> Loader Class Initialized
INFO - 2024-02-07 19:15:32 --> Helper loaded: url_helper
INFO - 2024-02-07 19:15:32 --> Helper loaded: file_helper
INFO - 2024-02-07 19:15:32 --> Helper loaded: form_helper
INFO - 2024-02-07 19:15:32 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:15:32 --> Controller Class Initialized
INFO - 2024-02-07 19:15:32 --> Form Validation Class Initialized
INFO - 2024-02-07 19:15:32 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:15:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:15:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:15:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:15:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:15:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:15:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:15:32 --> Final output sent to browser
DEBUG - 2024-02-07 19:15:32 --> Total execution time: 0.0325
ERROR - 2024-02-07 19:15:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:15:33 --> Config Class Initialized
INFO - 2024-02-07 19:15:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:15:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:15:33 --> Utf8 Class Initialized
INFO - 2024-02-07 19:15:33 --> URI Class Initialized
INFO - 2024-02-07 19:15:33 --> Router Class Initialized
INFO - 2024-02-07 19:15:33 --> Output Class Initialized
INFO - 2024-02-07 19:15:33 --> Security Class Initialized
DEBUG - 2024-02-07 19:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:15:33 --> Input Class Initialized
INFO - 2024-02-07 19:15:33 --> Language Class Initialized
INFO - 2024-02-07 19:15:33 --> Loader Class Initialized
INFO - 2024-02-07 19:15:33 --> Helper loaded: url_helper
INFO - 2024-02-07 19:15:33 --> Helper loaded: file_helper
INFO - 2024-02-07 19:15:33 --> Helper loaded: form_helper
INFO - 2024-02-07 19:15:33 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:15:33 --> Controller Class Initialized
INFO - 2024-02-07 19:15:33 --> Form Validation Class Initialized
INFO - 2024-02-07 19:15:33 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:15:33 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:15:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:15:40 --> Config Class Initialized
INFO - 2024-02-07 19:15:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:15:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:15:40 --> Utf8 Class Initialized
INFO - 2024-02-07 19:15:40 --> URI Class Initialized
INFO - 2024-02-07 19:15:40 --> Router Class Initialized
INFO - 2024-02-07 19:15:40 --> Output Class Initialized
INFO - 2024-02-07 19:15:40 --> Security Class Initialized
DEBUG - 2024-02-07 19:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:15:40 --> Input Class Initialized
INFO - 2024-02-07 19:15:40 --> Language Class Initialized
INFO - 2024-02-07 19:15:40 --> Loader Class Initialized
INFO - 2024-02-07 19:15:40 --> Helper loaded: url_helper
INFO - 2024-02-07 19:15:40 --> Helper loaded: file_helper
INFO - 2024-02-07 19:15:40 --> Helper loaded: form_helper
INFO - 2024-02-07 19:15:40 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:15:40 --> Controller Class Initialized
INFO - 2024-02-07 19:15:40 --> Form Validation Class Initialized
INFO - 2024-02-07 19:15:40 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:15:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:15:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:15:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:15:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:15:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:15:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:15:40 --> Final output sent to browser
DEBUG - 2024-02-07 19:15:40 --> Total execution time: 0.0290
ERROR - 2024-02-07 19:15:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:15:41 --> Config Class Initialized
INFO - 2024-02-07 19:15:41 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:15:41 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:15:41 --> Utf8 Class Initialized
INFO - 2024-02-07 19:15:41 --> URI Class Initialized
INFO - 2024-02-07 19:15:41 --> Router Class Initialized
INFO - 2024-02-07 19:15:41 --> Output Class Initialized
INFO - 2024-02-07 19:15:41 --> Security Class Initialized
DEBUG - 2024-02-07 19:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:15:41 --> Input Class Initialized
INFO - 2024-02-07 19:15:41 --> Language Class Initialized
INFO - 2024-02-07 19:15:41 --> Loader Class Initialized
INFO - 2024-02-07 19:15:41 --> Helper loaded: url_helper
INFO - 2024-02-07 19:15:41 --> Helper loaded: file_helper
INFO - 2024-02-07 19:15:41 --> Helper loaded: form_helper
INFO - 2024-02-07 19:15:41 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:15:41 --> Controller Class Initialized
INFO - 2024-02-07 19:15:41 --> Form Validation Class Initialized
INFO - 2024-02-07 19:15:41 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:15:41 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:15:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:15:44 --> Config Class Initialized
INFO - 2024-02-07 19:15:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:15:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:15:44 --> Utf8 Class Initialized
INFO - 2024-02-07 19:15:44 --> URI Class Initialized
INFO - 2024-02-07 19:15:44 --> Router Class Initialized
INFO - 2024-02-07 19:15:44 --> Output Class Initialized
INFO - 2024-02-07 19:15:44 --> Security Class Initialized
DEBUG - 2024-02-07 19:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:15:44 --> Input Class Initialized
INFO - 2024-02-07 19:15:44 --> Language Class Initialized
INFO - 2024-02-07 19:15:44 --> Loader Class Initialized
INFO - 2024-02-07 19:15:44 --> Helper loaded: url_helper
INFO - 2024-02-07 19:15:44 --> Helper loaded: file_helper
INFO - 2024-02-07 19:15:44 --> Helper loaded: form_helper
INFO - 2024-02-07 19:15:44 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:15:44 --> Controller Class Initialized
INFO - 2024-02-07 19:15:44 --> Form Validation Class Initialized
INFO - 2024-02-07 19:15:44 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:15:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:15:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:15:44 --> Final output sent to browser
DEBUG - 2024-02-07 19:15:44 --> Total execution time: 0.0206
ERROR - 2024-02-07 19:16:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:16:14 --> Config Class Initialized
INFO - 2024-02-07 19:16:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:16:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:16:14 --> Utf8 Class Initialized
INFO - 2024-02-07 19:16:14 --> URI Class Initialized
INFO - 2024-02-07 19:16:14 --> Router Class Initialized
INFO - 2024-02-07 19:16:14 --> Output Class Initialized
INFO - 2024-02-07 19:16:14 --> Security Class Initialized
DEBUG - 2024-02-07 19:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:16:14 --> Input Class Initialized
INFO - 2024-02-07 19:16:14 --> Language Class Initialized
INFO - 2024-02-07 19:16:14 --> Loader Class Initialized
INFO - 2024-02-07 19:16:14 --> Helper loaded: url_helper
INFO - 2024-02-07 19:16:14 --> Helper loaded: file_helper
INFO - 2024-02-07 19:16:14 --> Helper loaded: form_helper
INFO - 2024-02-07 19:16:14 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:16:14 --> Controller Class Initialized
INFO - 2024-02-07 19:16:14 --> Form Validation Class Initialized
INFO - 2024-02-07 19:16:14 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:16:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:16:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:16:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:16:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:16:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:16:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:16:14 --> Final output sent to browser
DEBUG - 2024-02-07 19:16:14 --> Total execution time: 0.0297
ERROR - 2024-02-07 19:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:16:15 --> Config Class Initialized
INFO - 2024-02-07 19:16:15 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:16:15 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:16:15 --> Utf8 Class Initialized
INFO - 2024-02-07 19:16:15 --> URI Class Initialized
INFO - 2024-02-07 19:16:15 --> Router Class Initialized
INFO - 2024-02-07 19:16:15 --> Output Class Initialized
INFO - 2024-02-07 19:16:15 --> Security Class Initialized
DEBUG - 2024-02-07 19:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:16:15 --> Input Class Initialized
INFO - 2024-02-07 19:16:15 --> Language Class Initialized
INFO - 2024-02-07 19:16:15 --> Loader Class Initialized
INFO - 2024-02-07 19:16:15 --> Helper loaded: url_helper
INFO - 2024-02-07 19:16:15 --> Helper loaded: file_helper
INFO - 2024-02-07 19:16:15 --> Helper loaded: form_helper
INFO - 2024-02-07 19:16:15 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:16:15 --> Controller Class Initialized
INFO - 2024-02-07 19:16:15 --> Form Validation Class Initialized
INFO - 2024-02-07 19:16:15 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:16:15 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:16:17 --> Config Class Initialized
INFO - 2024-02-07 19:16:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:16:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:16:17 --> Utf8 Class Initialized
INFO - 2024-02-07 19:16:17 --> URI Class Initialized
INFO - 2024-02-07 19:16:17 --> Router Class Initialized
INFO - 2024-02-07 19:16:17 --> Output Class Initialized
INFO - 2024-02-07 19:16:17 --> Security Class Initialized
DEBUG - 2024-02-07 19:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:16:17 --> Input Class Initialized
INFO - 2024-02-07 19:16:17 --> Language Class Initialized
INFO - 2024-02-07 19:16:17 --> Loader Class Initialized
INFO - 2024-02-07 19:16:17 --> Helper loaded: url_helper
INFO - 2024-02-07 19:16:17 --> Helper loaded: file_helper
INFO - 2024-02-07 19:16:17 --> Helper loaded: form_helper
INFO - 2024-02-07 19:16:17 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:16:17 --> Controller Class Initialized
INFO - 2024-02-07 19:16:17 --> Form Validation Class Initialized
INFO - 2024-02-07 19:16:17 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:16:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:16:17 --> Final output sent to browser
DEBUG - 2024-02-07 19:16:17 --> Total execution time: 0.0232
ERROR - 2024-02-07 19:16:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:16:48 --> Config Class Initialized
INFO - 2024-02-07 19:16:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:16:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:16:48 --> Utf8 Class Initialized
INFO - 2024-02-07 19:16:48 --> URI Class Initialized
INFO - 2024-02-07 19:16:48 --> Router Class Initialized
INFO - 2024-02-07 19:16:48 --> Output Class Initialized
INFO - 2024-02-07 19:16:48 --> Security Class Initialized
DEBUG - 2024-02-07 19:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:16:48 --> Input Class Initialized
INFO - 2024-02-07 19:16:48 --> Language Class Initialized
INFO - 2024-02-07 19:16:48 --> Loader Class Initialized
INFO - 2024-02-07 19:16:48 --> Helper loaded: url_helper
INFO - 2024-02-07 19:16:48 --> Helper loaded: file_helper
INFO - 2024-02-07 19:16:48 --> Helper loaded: form_helper
INFO - 2024-02-07 19:16:48 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:16:48 --> Controller Class Initialized
INFO - 2024-02-07 19:16:48 --> Form Validation Class Initialized
INFO - 2024-02-07 19:16:48 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:16:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:16:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:16:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:16:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:16:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:16:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:16:48 --> Final output sent to browser
DEBUG - 2024-02-07 19:16:48 --> Total execution time: 0.0311
ERROR - 2024-02-07 19:16:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:16:48 --> Config Class Initialized
INFO - 2024-02-07 19:16:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:16:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:16:48 --> Utf8 Class Initialized
INFO - 2024-02-07 19:16:48 --> URI Class Initialized
INFO - 2024-02-07 19:16:48 --> Router Class Initialized
INFO - 2024-02-07 19:16:48 --> Output Class Initialized
INFO - 2024-02-07 19:16:48 --> Security Class Initialized
DEBUG - 2024-02-07 19:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:16:48 --> Input Class Initialized
INFO - 2024-02-07 19:16:48 --> Language Class Initialized
INFO - 2024-02-07 19:16:48 --> Loader Class Initialized
INFO - 2024-02-07 19:16:48 --> Helper loaded: url_helper
INFO - 2024-02-07 19:16:48 --> Helper loaded: file_helper
INFO - 2024-02-07 19:16:48 --> Helper loaded: form_helper
INFO - 2024-02-07 19:16:48 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:16:48 --> Controller Class Initialized
INFO - 2024-02-07 19:16:48 --> Form Validation Class Initialized
INFO - 2024-02-07 19:16:48 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:16:48 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:16:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:16:50 --> Config Class Initialized
INFO - 2024-02-07 19:16:50 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:16:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:16:50 --> Utf8 Class Initialized
INFO - 2024-02-07 19:16:50 --> URI Class Initialized
INFO - 2024-02-07 19:16:50 --> Router Class Initialized
INFO - 2024-02-07 19:16:50 --> Output Class Initialized
INFO - 2024-02-07 19:16:50 --> Security Class Initialized
DEBUG - 2024-02-07 19:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:16:50 --> Input Class Initialized
INFO - 2024-02-07 19:16:50 --> Language Class Initialized
INFO - 2024-02-07 19:16:50 --> Loader Class Initialized
INFO - 2024-02-07 19:16:50 --> Helper loaded: url_helper
INFO - 2024-02-07 19:16:50 --> Helper loaded: file_helper
INFO - 2024-02-07 19:16:50 --> Helper loaded: form_helper
INFO - 2024-02-07 19:16:50 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:16:50 --> Controller Class Initialized
INFO - 2024-02-07 19:16:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:16:50 --> Final output sent to browser
DEBUG - 2024-02-07 19:16:50 --> Total execution time: 0.0225
ERROR - 2024-02-07 19:16:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:16:51 --> Config Class Initialized
INFO - 2024-02-07 19:16:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:16:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:16:51 --> Utf8 Class Initialized
INFO - 2024-02-07 19:16:51 --> URI Class Initialized
INFO - 2024-02-07 19:16:51 --> Router Class Initialized
INFO - 2024-02-07 19:16:51 --> Output Class Initialized
INFO - 2024-02-07 19:16:51 --> Security Class Initialized
DEBUG - 2024-02-07 19:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:16:51 --> Input Class Initialized
INFO - 2024-02-07 19:16:51 --> Language Class Initialized
INFO - 2024-02-07 19:16:51 --> Loader Class Initialized
INFO - 2024-02-07 19:16:51 --> Helper loaded: url_helper
INFO - 2024-02-07 19:16:51 --> Helper loaded: file_helper
INFO - 2024-02-07 19:16:51 --> Helper loaded: form_helper
INFO - 2024-02-07 19:16:51 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:16:51 --> Controller Class Initialized
INFO - 2024-02-07 19:16:51 --> Form Validation Class Initialized
INFO - 2024-02-07 19:16:51 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:16:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:16:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:16:51 --> Final output sent to browser
DEBUG - 2024-02-07 19:16:51 --> Total execution time: 0.0353
ERROR - 2024-02-07 19:17:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:17:16 --> Config Class Initialized
INFO - 2024-02-07 19:17:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:17:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:17:16 --> Utf8 Class Initialized
INFO - 2024-02-07 19:17:16 --> URI Class Initialized
INFO - 2024-02-07 19:17:16 --> Router Class Initialized
INFO - 2024-02-07 19:17:16 --> Output Class Initialized
INFO - 2024-02-07 19:17:16 --> Security Class Initialized
DEBUG - 2024-02-07 19:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:17:16 --> Input Class Initialized
INFO - 2024-02-07 19:17:16 --> Language Class Initialized
INFO - 2024-02-07 19:17:16 --> Loader Class Initialized
INFO - 2024-02-07 19:17:16 --> Helper loaded: url_helper
INFO - 2024-02-07 19:17:16 --> Helper loaded: file_helper
INFO - 2024-02-07 19:17:16 --> Helper loaded: form_helper
INFO - 2024-02-07 19:17:16 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:17:16 --> Controller Class Initialized
INFO - 2024-02-07 19:17:16 --> Form Validation Class Initialized
INFO - 2024-02-07 19:17:16 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:17:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:17:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:17:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:17:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:17:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:17:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:17:16 --> Final output sent to browser
DEBUG - 2024-02-07 19:17:16 --> Total execution time: 0.0374
ERROR - 2024-02-07 19:17:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:17:16 --> Config Class Initialized
INFO - 2024-02-07 19:17:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:17:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:17:16 --> Utf8 Class Initialized
INFO - 2024-02-07 19:17:16 --> URI Class Initialized
INFO - 2024-02-07 19:17:17 --> Router Class Initialized
INFO - 2024-02-07 19:17:17 --> Output Class Initialized
INFO - 2024-02-07 19:17:17 --> Security Class Initialized
DEBUG - 2024-02-07 19:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:17:17 --> Input Class Initialized
INFO - 2024-02-07 19:17:17 --> Language Class Initialized
INFO - 2024-02-07 19:17:17 --> Loader Class Initialized
INFO - 2024-02-07 19:17:17 --> Helper loaded: url_helper
INFO - 2024-02-07 19:17:17 --> Helper loaded: file_helper
INFO - 2024-02-07 19:17:17 --> Helper loaded: form_helper
INFO - 2024-02-07 19:17:17 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:17:17 --> Controller Class Initialized
INFO - 2024-02-07 19:17:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-02-07 19:17:17 --> Final output sent to browser
DEBUG - 2024-02-07 19:17:17 --> Total execution time: 0.0242
ERROR - 2024-02-07 19:17:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:17:23 --> Config Class Initialized
INFO - 2024-02-07 19:17:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:17:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:17:23 --> Utf8 Class Initialized
INFO - 2024-02-07 19:17:23 --> URI Class Initialized
INFO - 2024-02-07 19:17:23 --> Router Class Initialized
INFO - 2024-02-07 19:17:23 --> Output Class Initialized
INFO - 2024-02-07 19:17:23 --> Security Class Initialized
DEBUG - 2024-02-07 19:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:17:23 --> Input Class Initialized
INFO - 2024-02-07 19:17:23 --> Language Class Initialized
INFO - 2024-02-07 19:17:23 --> Loader Class Initialized
INFO - 2024-02-07 19:17:23 --> Helper loaded: url_helper
INFO - 2024-02-07 19:17:23 --> Helper loaded: file_helper
INFO - 2024-02-07 19:17:23 --> Helper loaded: form_helper
INFO - 2024-02-07 19:17:23 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:17:23 --> Controller Class Initialized
INFO - 2024-02-07 19:17:23 --> Model "LoginModel" initialized
INFO - 2024-02-07 19:17:23 --> Form Validation Class Initialized
INFO - 2024-02-07 19:17:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-07 19:17:23 --> Final output sent to browser
DEBUG - 2024-02-07 19:17:23 --> Total execution time: 0.0315
ERROR - 2024-02-07 19:17:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:17:23 --> Config Class Initialized
INFO - 2024-02-07 19:17:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:17:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:17:23 --> Utf8 Class Initialized
INFO - 2024-02-07 19:17:23 --> URI Class Initialized
INFO - 2024-02-07 19:17:23 --> Router Class Initialized
INFO - 2024-02-07 19:17:23 --> Output Class Initialized
INFO - 2024-02-07 19:17:23 --> Security Class Initialized
DEBUG - 2024-02-07 19:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:17:23 --> Input Class Initialized
INFO - 2024-02-07 19:17:23 --> Language Class Initialized
INFO - 2024-02-07 19:17:23 --> Loader Class Initialized
INFO - 2024-02-07 19:17:23 --> Helper loaded: url_helper
INFO - 2024-02-07 19:17:23 --> Helper loaded: file_helper
INFO - 2024-02-07 19:17:23 --> Helper loaded: form_helper
INFO - 2024-02-07 19:17:23 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:17:23 --> Controller Class Initialized
INFO - 2024-02-07 19:17:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:17:23 --> Final output sent to browser
DEBUG - 2024-02-07 19:17:23 --> Total execution time: 0.0353
ERROR - 2024-02-07 19:19:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:19:28 --> Config Class Initialized
INFO - 2024-02-07 19:19:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:19:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:19:28 --> Utf8 Class Initialized
INFO - 2024-02-07 19:19:28 --> URI Class Initialized
INFO - 2024-02-07 19:19:28 --> Router Class Initialized
INFO - 2024-02-07 19:19:28 --> Output Class Initialized
INFO - 2024-02-07 19:19:28 --> Security Class Initialized
DEBUG - 2024-02-07 19:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:19:28 --> Input Class Initialized
INFO - 2024-02-07 19:19:28 --> Language Class Initialized
INFO - 2024-02-07 19:19:28 --> Loader Class Initialized
INFO - 2024-02-07 19:19:28 --> Helper loaded: url_helper
INFO - 2024-02-07 19:19:28 --> Helper loaded: file_helper
INFO - 2024-02-07 19:19:28 --> Helper loaded: form_helper
INFO - 2024-02-07 19:19:28 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:19:28 --> Controller Class Initialized
INFO - 2024-02-07 19:19:28 --> Model "LoginModel" initialized
INFO - 2024-02-07 19:19:28 --> Form Validation Class Initialized
INFO - 2024-02-07 19:19:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-07 19:19:28 --> Final output sent to browser
DEBUG - 2024-02-07 19:19:28 --> Total execution time: 0.0331
ERROR - 2024-02-07 19:19:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:19:28 --> Config Class Initialized
INFO - 2024-02-07 19:19:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:19:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:19:28 --> Utf8 Class Initialized
INFO - 2024-02-07 19:19:28 --> URI Class Initialized
INFO - 2024-02-07 19:19:28 --> Router Class Initialized
INFO - 2024-02-07 19:19:28 --> Output Class Initialized
INFO - 2024-02-07 19:19:28 --> Security Class Initialized
DEBUG - 2024-02-07 19:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:19:28 --> Input Class Initialized
INFO - 2024-02-07 19:19:28 --> Language Class Initialized
INFO - 2024-02-07 19:19:28 --> Loader Class Initialized
INFO - 2024-02-07 19:19:28 --> Helper loaded: url_helper
INFO - 2024-02-07 19:19:28 --> Helper loaded: file_helper
INFO - 2024-02-07 19:19:28 --> Helper loaded: form_helper
INFO - 2024-02-07 19:19:28 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:19:28 --> Controller Class Initialized
INFO - 2024-02-07 19:19:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:19:28 --> Final output sent to browser
DEBUG - 2024-02-07 19:19:28 --> Total execution time: 0.0230
ERROR - 2024-02-07 19:19:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:19:52 --> Config Class Initialized
INFO - 2024-02-07 19:19:52 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:19:52 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:19:52 --> Utf8 Class Initialized
INFO - 2024-02-07 19:19:52 --> URI Class Initialized
INFO - 2024-02-07 19:19:52 --> Router Class Initialized
INFO - 2024-02-07 19:19:52 --> Output Class Initialized
INFO - 2024-02-07 19:19:52 --> Security Class Initialized
DEBUG - 2024-02-07 19:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:19:52 --> Input Class Initialized
INFO - 2024-02-07 19:19:52 --> Language Class Initialized
INFO - 2024-02-07 19:19:52 --> Loader Class Initialized
INFO - 2024-02-07 19:19:52 --> Helper loaded: url_helper
INFO - 2024-02-07 19:19:52 --> Helper loaded: file_helper
INFO - 2024-02-07 19:19:52 --> Helper loaded: form_helper
INFO - 2024-02-07 19:19:52 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:19:52 --> Controller Class Initialized
INFO - 2024-02-07 19:19:52 --> Model "LoginModel" initialized
INFO - 2024-02-07 19:19:52 --> Form Validation Class Initialized
INFO - 2024-02-07 19:19:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-07 19:19:52 --> Final output sent to browser
DEBUG - 2024-02-07 19:19:52 --> Total execution time: 0.0281
ERROR - 2024-02-07 19:19:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:19:53 --> Config Class Initialized
INFO - 2024-02-07 19:19:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:19:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:19:53 --> Utf8 Class Initialized
INFO - 2024-02-07 19:19:53 --> URI Class Initialized
INFO - 2024-02-07 19:19:53 --> Router Class Initialized
INFO - 2024-02-07 19:19:53 --> Output Class Initialized
INFO - 2024-02-07 19:19:53 --> Security Class Initialized
DEBUG - 2024-02-07 19:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:19:53 --> Input Class Initialized
INFO - 2024-02-07 19:19:53 --> Language Class Initialized
INFO - 2024-02-07 19:19:53 --> Loader Class Initialized
INFO - 2024-02-07 19:19:53 --> Helper loaded: url_helper
INFO - 2024-02-07 19:19:53 --> Helper loaded: file_helper
INFO - 2024-02-07 19:19:53 --> Helper loaded: form_helper
INFO - 2024-02-07 19:19:53 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:19:53 --> Controller Class Initialized
INFO - 2024-02-07 19:19:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:19:53 --> Final output sent to browser
DEBUG - 2024-02-07 19:19:53 --> Total execution time: 0.0212
ERROR - 2024-02-07 19:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:20:10 --> Config Class Initialized
INFO - 2024-02-07 19:20:10 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:20:10 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:20:10 --> Utf8 Class Initialized
INFO - 2024-02-07 19:20:10 --> URI Class Initialized
INFO - 2024-02-07 19:20:10 --> Router Class Initialized
INFO - 2024-02-07 19:20:10 --> Output Class Initialized
INFO - 2024-02-07 19:20:10 --> Security Class Initialized
DEBUG - 2024-02-07 19:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:20:10 --> Input Class Initialized
INFO - 2024-02-07 19:20:10 --> Language Class Initialized
INFO - 2024-02-07 19:20:10 --> Loader Class Initialized
INFO - 2024-02-07 19:20:10 --> Helper loaded: url_helper
INFO - 2024-02-07 19:20:10 --> Helper loaded: file_helper
INFO - 2024-02-07 19:20:10 --> Helper loaded: form_helper
INFO - 2024-02-07 19:20:10 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:20:10 --> Controller Class Initialized
INFO - 2024-02-07 19:20:10 --> Model "LoginModel" initialized
INFO - 2024-02-07 19:20:10 --> Form Validation Class Initialized
INFO - 2024-02-07 19:20:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-07 19:20:10 --> Final output sent to browser
DEBUG - 2024-02-07 19:20:10 --> Total execution time: 0.0253
ERROR - 2024-02-07 19:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:20:10 --> Config Class Initialized
INFO - 2024-02-07 19:20:10 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:20:10 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:20:10 --> Utf8 Class Initialized
INFO - 2024-02-07 19:20:10 --> URI Class Initialized
INFO - 2024-02-07 19:20:10 --> Router Class Initialized
INFO - 2024-02-07 19:20:10 --> Output Class Initialized
INFO - 2024-02-07 19:20:10 --> Security Class Initialized
DEBUG - 2024-02-07 19:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:20:10 --> Input Class Initialized
INFO - 2024-02-07 19:20:10 --> Language Class Initialized
INFO - 2024-02-07 19:20:10 --> Loader Class Initialized
INFO - 2024-02-07 19:20:10 --> Helper loaded: url_helper
INFO - 2024-02-07 19:20:10 --> Helper loaded: file_helper
INFO - 2024-02-07 19:20:10 --> Helper loaded: form_helper
INFO - 2024-02-07 19:20:10 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:20:10 --> Controller Class Initialized
INFO - 2024-02-07 19:20:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:20:10 --> Final output sent to browser
DEBUG - 2024-02-07 19:20:10 --> Total execution time: 0.0437
ERROR - 2024-02-07 19:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:20:29 --> Config Class Initialized
INFO - 2024-02-07 19:20:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:20:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:20:29 --> Utf8 Class Initialized
INFO - 2024-02-07 19:20:29 --> URI Class Initialized
INFO - 2024-02-07 19:20:29 --> Router Class Initialized
INFO - 2024-02-07 19:20:29 --> Output Class Initialized
INFO - 2024-02-07 19:20:29 --> Security Class Initialized
DEBUG - 2024-02-07 19:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:20:29 --> Input Class Initialized
INFO - 2024-02-07 19:20:29 --> Language Class Initialized
INFO - 2024-02-07 19:20:29 --> Loader Class Initialized
INFO - 2024-02-07 19:20:29 --> Helper loaded: url_helper
INFO - 2024-02-07 19:20:29 --> Helper loaded: file_helper
INFO - 2024-02-07 19:20:29 --> Helper loaded: form_helper
INFO - 2024-02-07 19:20:29 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:20:29 --> Controller Class Initialized
INFO - 2024-02-07 19:20:29 --> Model "LoginModel" initialized
INFO - 2024-02-07 19:20:29 --> Form Validation Class Initialized
INFO - 2024-02-07 19:20:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-07 19:20:29 --> Final output sent to browser
DEBUG - 2024-02-07 19:20:29 --> Total execution time: 0.0263
ERROR - 2024-02-07 19:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:20:29 --> Config Class Initialized
INFO - 2024-02-07 19:20:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:20:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:20:29 --> Utf8 Class Initialized
INFO - 2024-02-07 19:20:29 --> URI Class Initialized
INFO - 2024-02-07 19:20:29 --> Router Class Initialized
INFO - 2024-02-07 19:20:29 --> Output Class Initialized
INFO - 2024-02-07 19:20:29 --> Security Class Initialized
DEBUG - 2024-02-07 19:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:20:29 --> Input Class Initialized
INFO - 2024-02-07 19:20:29 --> Language Class Initialized
INFO - 2024-02-07 19:20:29 --> Loader Class Initialized
INFO - 2024-02-07 19:20:29 --> Helper loaded: url_helper
INFO - 2024-02-07 19:20:29 --> Helper loaded: file_helper
INFO - 2024-02-07 19:20:29 --> Helper loaded: form_helper
INFO - 2024-02-07 19:20:29 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:20:29 --> Controller Class Initialized
INFO - 2024-02-07 19:20:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:20:29 --> Final output sent to browser
DEBUG - 2024-02-07 19:20:29 --> Total execution time: 0.0289
ERROR - 2024-02-07 19:20:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:20:46 --> Config Class Initialized
INFO - 2024-02-07 19:20:46 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:20:46 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:20:46 --> Utf8 Class Initialized
INFO - 2024-02-07 19:20:46 --> URI Class Initialized
INFO - 2024-02-07 19:20:46 --> Router Class Initialized
INFO - 2024-02-07 19:20:46 --> Output Class Initialized
INFO - 2024-02-07 19:20:46 --> Security Class Initialized
DEBUG - 2024-02-07 19:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:20:46 --> Input Class Initialized
INFO - 2024-02-07 19:20:46 --> Language Class Initialized
INFO - 2024-02-07 19:20:46 --> Loader Class Initialized
INFO - 2024-02-07 19:20:46 --> Helper loaded: url_helper
INFO - 2024-02-07 19:20:46 --> Helper loaded: file_helper
INFO - 2024-02-07 19:20:46 --> Helper loaded: form_helper
INFO - 2024-02-07 19:20:46 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:20:46 --> Controller Class Initialized
INFO - 2024-02-07 19:20:46 --> Model "LoginModel" initialized
INFO - 2024-02-07 19:20:46 --> Form Validation Class Initialized
INFO - 2024-02-07 19:20:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-07 19:20:46 --> Final output sent to browser
DEBUG - 2024-02-07 19:20:46 --> Total execution time: 0.0249
ERROR - 2024-02-07 19:20:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:20:46 --> Config Class Initialized
INFO - 2024-02-07 19:20:46 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:20:46 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:20:46 --> Utf8 Class Initialized
INFO - 2024-02-07 19:20:46 --> URI Class Initialized
INFO - 2024-02-07 19:20:46 --> Router Class Initialized
INFO - 2024-02-07 19:20:46 --> Output Class Initialized
INFO - 2024-02-07 19:20:46 --> Security Class Initialized
DEBUG - 2024-02-07 19:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:20:46 --> Input Class Initialized
INFO - 2024-02-07 19:20:46 --> Language Class Initialized
INFO - 2024-02-07 19:20:46 --> Loader Class Initialized
INFO - 2024-02-07 19:20:46 --> Helper loaded: url_helper
INFO - 2024-02-07 19:20:46 --> Helper loaded: file_helper
INFO - 2024-02-07 19:20:46 --> Helper loaded: form_helper
INFO - 2024-02-07 19:20:46 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:20:46 --> Controller Class Initialized
INFO - 2024-02-07 19:20:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:20:46 --> Final output sent to browser
DEBUG - 2024-02-07 19:20:46 --> Total execution time: 0.0327
ERROR - 2024-02-07 19:21:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:21:24 --> Config Class Initialized
INFO - 2024-02-07 19:21:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:21:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:21:24 --> Utf8 Class Initialized
INFO - 2024-02-07 19:21:24 --> URI Class Initialized
INFO - 2024-02-07 19:21:24 --> Router Class Initialized
INFO - 2024-02-07 19:21:24 --> Output Class Initialized
INFO - 2024-02-07 19:21:24 --> Security Class Initialized
DEBUG - 2024-02-07 19:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:21:24 --> Input Class Initialized
INFO - 2024-02-07 19:21:24 --> Language Class Initialized
INFO - 2024-02-07 19:21:24 --> Loader Class Initialized
INFO - 2024-02-07 19:21:24 --> Helper loaded: url_helper
INFO - 2024-02-07 19:21:24 --> Helper loaded: file_helper
INFO - 2024-02-07 19:21:24 --> Helper loaded: form_helper
INFO - 2024-02-07 19:21:24 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:21:24 --> Controller Class Initialized
INFO - 2024-02-07 19:21:24 --> Model "LoginModel" initialized
INFO - 2024-02-07 19:21:24 --> Form Validation Class Initialized
INFO - 2024-02-07 19:21:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-07 19:21:24 --> Final output sent to browser
DEBUG - 2024-02-07 19:21:24 --> Total execution time: 0.0291
ERROR - 2024-02-07 19:21:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:21:24 --> Config Class Initialized
INFO - 2024-02-07 19:21:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:21:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:21:24 --> Utf8 Class Initialized
INFO - 2024-02-07 19:21:24 --> URI Class Initialized
INFO - 2024-02-07 19:21:24 --> Router Class Initialized
INFO - 2024-02-07 19:21:24 --> Output Class Initialized
INFO - 2024-02-07 19:21:24 --> Security Class Initialized
DEBUG - 2024-02-07 19:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:21:24 --> Input Class Initialized
INFO - 2024-02-07 19:21:24 --> Language Class Initialized
INFO - 2024-02-07 19:21:24 --> Loader Class Initialized
INFO - 2024-02-07 19:21:24 --> Helper loaded: url_helper
INFO - 2024-02-07 19:21:24 --> Helper loaded: file_helper
INFO - 2024-02-07 19:21:24 --> Helper loaded: form_helper
INFO - 2024-02-07 19:21:24 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:21:24 --> Controller Class Initialized
INFO - 2024-02-07 19:21:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:21:24 --> Final output sent to browser
DEBUG - 2024-02-07 19:21:24 --> Total execution time: 0.0327
ERROR - 2024-02-07 19:21:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:21:36 --> Config Class Initialized
INFO - 2024-02-07 19:21:36 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:21:36 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:21:36 --> Utf8 Class Initialized
INFO - 2024-02-07 19:21:36 --> URI Class Initialized
INFO - 2024-02-07 19:21:36 --> Router Class Initialized
INFO - 2024-02-07 19:21:36 --> Output Class Initialized
INFO - 2024-02-07 19:21:36 --> Security Class Initialized
DEBUG - 2024-02-07 19:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:21:36 --> Input Class Initialized
INFO - 2024-02-07 19:21:36 --> Language Class Initialized
INFO - 2024-02-07 19:21:36 --> Loader Class Initialized
INFO - 2024-02-07 19:21:36 --> Helper loaded: url_helper
INFO - 2024-02-07 19:21:36 --> Helper loaded: file_helper
INFO - 2024-02-07 19:21:36 --> Helper loaded: form_helper
INFO - 2024-02-07 19:21:36 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:21:36 --> Controller Class Initialized
INFO - 2024-02-07 19:21:36 --> Model "LoginModel" initialized
INFO - 2024-02-07 19:21:36 --> Form Validation Class Initialized
INFO - 2024-02-07 19:21:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-07 19:21:36 --> Severity: Notice --> Undefined property: stdClass::$emp_role D:\xampp\htdocs\sscy\application\models\LoginModel.php 18
ERROR - 2024-02-07 19:21:36 --> Severity: Notice --> Undefined variable: empRole D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-07 19:21:36 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-07 19:21:36 --> Severity: Notice --> Undefined property: stdClass::$emp_name D:\xampp\htdocs\sscy\application\models\LoginModel.php 20
ERROR - 2024-02-07 19:21:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:21:36 --> Config Class Initialized
INFO - 2024-02-07 19:21:36 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:21:36 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:21:36 --> Utf8 Class Initialized
INFO - 2024-02-07 19:21:36 --> URI Class Initialized
INFO - 2024-02-07 19:21:36 --> Router Class Initialized
INFO - 2024-02-07 19:21:36 --> Output Class Initialized
INFO - 2024-02-07 19:21:36 --> Security Class Initialized
DEBUG - 2024-02-07 19:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:21:36 --> Input Class Initialized
INFO - 2024-02-07 19:21:36 --> Language Class Initialized
INFO - 2024-02-07 19:21:36 --> Loader Class Initialized
INFO - 2024-02-07 19:21:36 --> Helper loaded: url_helper
INFO - 2024-02-07 19:21:36 --> Helper loaded: file_helper
INFO - 2024-02-07 19:21:36 --> Helper loaded: form_helper
INFO - 2024-02-07 19:21:36 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:21:36 --> Controller Class Initialized
INFO - 2024-02-07 19:21:36 --> Form Validation Class Initialized
INFO - 2024-02-07 19:21:36 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:21:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:21:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:21:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-07 19:21:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:21:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:21:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:21:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-07 19:21:36 --> Final output sent to browser
DEBUG - 2024-02-07 19:21:36 --> Total execution time: 0.0210
ERROR - 2024-02-07 19:21:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:21:37 --> Config Class Initialized
INFO - 2024-02-07 19:21:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:21:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:21:37 --> Utf8 Class Initialized
INFO - 2024-02-07 19:21:37 --> URI Class Initialized
INFO - 2024-02-07 19:21:37 --> Router Class Initialized
INFO - 2024-02-07 19:21:37 --> Output Class Initialized
INFO - 2024-02-07 19:21:37 --> Security Class Initialized
DEBUG - 2024-02-07 19:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:21:37 --> Input Class Initialized
INFO - 2024-02-07 19:21:37 --> Language Class Initialized
INFO - 2024-02-07 19:21:37 --> Loader Class Initialized
INFO - 2024-02-07 19:21:37 --> Helper loaded: url_helper
INFO - 2024-02-07 19:21:37 --> Helper loaded: file_helper
INFO - 2024-02-07 19:21:37 --> Helper loaded: form_helper
INFO - 2024-02-07 19:21:37 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:21:37 --> Controller Class Initialized
INFO - 2024-02-07 19:21:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:21:37 --> Final output sent to browser
DEBUG - 2024-02-07 19:21:37 --> Total execution time: 0.0227
ERROR - 2024-02-07 19:21:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:21:40 --> Config Class Initialized
INFO - 2024-02-07 19:21:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:21:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:21:40 --> Utf8 Class Initialized
INFO - 2024-02-07 19:21:40 --> URI Class Initialized
INFO - 2024-02-07 19:21:40 --> Router Class Initialized
INFO - 2024-02-07 19:21:40 --> Output Class Initialized
INFO - 2024-02-07 19:21:40 --> Security Class Initialized
DEBUG - 2024-02-07 19:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:21:40 --> Input Class Initialized
INFO - 2024-02-07 19:21:40 --> Language Class Initialized
INFO - 2024-02-07 19:21:40 --> Loader Class Initialized
INFO - 2024-02-07 19:21:40 --> Helper loaded: url_helper
INFO - 2024-02-07 19:21:40 --> Helper loaded: file_helper
INFO - 2024-02-07 19:21:40 --> Helper loaded: form_helper
INFO - 2024-02-07 19:21:40 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:21:40 --> Controller Class Initialized
INFO - 2024-02-07 19:21:40 --> Form Validation Class Initialized
INFO - 2024-02-07 19:21:40 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:21:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:21:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:21:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:21:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:21:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:21:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:21:40 --> Final output sent to browser
DEBUG - 2024-02-07 19:21:40 --> Total execution time: 0.0290
ERROR - 2024-02-07 19:21:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:21:40 --> Config Class Initialized
ERROR - 2024-02-07 19:21:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:21:40 --> Hooks Class Initialized
INFO - 2024-02-07 19:21:40 --> Config Class Initialized
INFO - 2024-02-07 19:21:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:21:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:21:40 --> Utf8 Class Initialized
DEBUG - 2024-02-07 19:21:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:21:40 --> Utf8 Class Initialized
INFO - 2024-02-07 19:21:40 --> URI Class Initialized
INFO - 2024-02-07 19:21:40 --> URI Class Initialized
INFO - 2024-02-07 19:21:40 --> Router Class Initialized
INFO - 2024-02-07 19:21:40 --> Router Class Initialized
INFO - 2024-02-07 19:21:40 --> Output Class Initialized
INFO - 2024-02-07 19:21:40 --> Output Class Initialized
INFO - 2024-02-07 19:21:40 --> Security Class Initialized
INFO - 2024-02-07 19:21:40 --> Security Class Initialized
DEBUG - 2024-02-07 19:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:21:40 --> Input Class Initialized
DEBUG - 2024-02-07 19:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:21:40 --> Input Class Initialized
INFO - 2024-02-07 19:21:40 --> Language Class Initialized
INFO - 2024-02-07 19:21:40 --> Language Class Initialized
INFO - 2024-02-07 19:21:40 --> Loader Class Initialized
INFO - 2024-02-07 19:21:40 --> Loader Class Initialized
INFO - 2024-02-07 19:21:40 --> Helper loaded: url_helper
INFO - 2024-02-07 19:21:40 --> Helper loaded: url_helper
INFO - 2024-02-07 19:21:40 --> Helper loaded: file_helper
INFO - 2024-02-07 19:21:40 --> Helper loaded: file_helper
INFO - 2024-02-07 19:21:40 --> Helper loaded: form_helper
INFO - 2024-02-07 19:21:40 --> Helper loaded: form_helper
INFO - 2024-02-07 19:21:40 --> Database Driver Class Initialized
INFO - 2024-02-07 19:21:40 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 19:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:21:40 --> Controller Class Initialized
INFO - 2024-02-07 19:21:40 --> Form Validation Class Initialized
INFO - 2024-02-07 19:21:40 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:21:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:21:40 --> Controller Class Initialized
INFO - 2024-02-07 19:21:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:21:40 --> Final output sent to browser
DEBUG - 2024-02-07 19:21:40 --> Total execution time: 0.0353
ERROR - 2024-02-07 19:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:21:43 --> Config Class Initialized
INFO - 2024-02-07 19:21:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:21:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:21:43 --> Utf8 Class Initialized
INFO - 2024-02-07 19:21:43 --> URI Class Initialized
INFO - 2024-02-07 19:21:43 --> Router Class Initialized
INFO - 2024-02-07 19:21:43 --> Output Class Initialized
INFO - 2024-02-07 19:21:43 --> Security Class Initialized
DEBUG - 2024-02-07 19:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:21:43 --> Input Class Initialized
INFO - 2024-02-07 19:21:43 --> Language Class Initialized
INFO - 2024-02-07 19:21:43 --> Loader Class Initialized
INFO - 2024-02-07 19:21:43 --> Helper loaded: url_helper
INFO - 2024-02-07 19:21:43 --> Helper loaded: file_helper
INFO - 2024-02-07 19:21:43 --> Helper loaded: form_helper
INFO - 2024-02-07 19:21:43 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:21:43 --> Controller Class Initialized
INFO - 2024-02-07 19:21:43 --> Form Validation Class Initialized
INFO - 2024-02-07 19:21:43 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:21:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:21:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:21:43 --> Final output sent to browser
DEBUG - 2024-02-07 19:21:43 --> Total execution time: 0.0245
ERROR - 2024-02-07 19:22:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:22:09 --> Config Class Initialized
INFO - 2024-02-07 19:22:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:22:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:22:09 --> Utf8 Class Initialized
INFO - 2024-02-07 19:22:09 --> URI Class Initialized
INFO - 2024-02-07 19:22:09 --> Router Class Initialized
INFO - 2024-02-07 19:22:09 --> Output Class Initialized
INFO - 2024-02-07 19:22:09 --> Security Class Initialized
DEBUG - 2024-02-07 19:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:22:09 --> Input Class Initialized
INFO - 2024-02-07 19:22:09 --> Language Class Initialized
INFO - 2024-02-07 19:22:09 --> Loader Class Initialized
INFO - 2024-02-07 19:22:09 --> Helper loaded: url_helper
INFO - 2024-02-07 19:22:09 --> Helper loaded: file_helper
INFO - 2024-02-07 19:22:09 --> Helper loaded: form_helper
INFO - 2024-02-07 19:22:09 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:22:09 --> Controller Class Initialized
INFO - 2024-02-07 19:22:09 --> Form Validation Class Initialized
INFO - 2024-02-07 19:22:09 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:22:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:22:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:22:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:22:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:22:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:22:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:22:09 --> Final output sent to browser
DEBUG - 2024-02-07 19:22:09 --> Total execution time: 0.0309
ERROR - 2024-02-07 19:22:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:22:09 --> Config Class Initialized
INFO - 2024-02-07 19:22:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:22:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:22:09 --> Utf8 Class Initialized
INFO - 2024-02-07 19:22:09 --> URI Class Initialized
INFO - 2024-02-07 19:22:09 --> Router Class Initialized
INFO - 2024-02-07 19:22:09 --> Output Class Initialized
ERROR - 2024-02-07 19:22:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:22:09 --> Security Class Initialized
DEBUG - 2024-02-07 19:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:22:09 --> Config Class Initialized
INFO - 2024-02-07 19:22:09 --> Input Class Initialized
INFO - 2024-02-07 19:22:09 --> Hooks Class Initialized
INFO - 2024-02-07 19:22:09 --> Language Class Initialized
DEBUG - 2024-02-07 19:22:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:22:09 --> Utf8 Class Initialized
INFO - 2024-02-07 19:22:09 --> Loader Class Initialized
INFO - 2024-02-07 19:22:09 --> URI Class Initialized
INFO - 2024-02-07 19:22:09 --> Helper loaded: url_helper
INFO - 2024-02-07 19:22:09 --> Helper loaded: file_helper
INFO - 2024-02-07 19:22:09 --> Router Class Initialized
INFO - 2024-02-07 19:22:09 --> Helper loaded: form_helper
INFO - 2024-02-07 19:22:09 --> Output Class Initialized
INFO - 2024-02-07 19:22:09 --> Security Class Initialized
DEBUG - 2024-02-07 19:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:22:09 --> Input Class Initialized
INFO - 2024-02-07 19:22:09 --> Language Class Initialized
INFO - 2024-02-07 19:22:09 --> Database Driver Class Initialized
INFO - 2024-02-07 19:22:09 --> Loader Class Initialized
INFO - 2024-02-07 19:22:09 --> Helper loaded: url_helper
INFO - 2024-02-07 19:22:09 --> Helper loaded: file_helper
INFO - 2024-02-07 19:22:09 --> Helper loaded: form_helper
DEBUG - 2024-02-07 19:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:22:09 --> Controller Class Initialized
INFO - 2024-02-07 19:22:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:22:09 --> Final output sent to browser
INFO - 2024-02-07 19:22:09 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:22:09 --> Total execution time: 0.0325
DEBUG - 2024-02-07 19:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:22:09 --> Controller Class Initialized
INFO - 2024-02-07 19:22:09 --> Form Validation Class Initialized
INFO - 2024-02-07 19:22:09 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:22:09 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:22:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:22:13 --> Config Class Initialized
INFO - 2024-02-07 19:22:13 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:22:13 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:22:13 --> Utf8 Class Initialized
INFO - 2024-02-07 19:22:13 --> URI Class Initialized
INFO - 2024-02-07 19:22:13 --> Router Class Initialized
INFO - 2024-02-07 19:22:13 --> Output Class Initialized
INFO - 2024-02-07 19:22:13 --> Security Class Initialized
DEBUG - 2024-02-07 19:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:22:13 --> Input Class Initialized
INFO - 2024-02-07 19:22:13 --> Language Class Initialized
INFO - 2024-02-07 19:22:13 --> Loader Class Initialized
INFO - 2024-02-07 19:22:13 --> Helper loaded: url_helper
INFO - 2024-02-07 19:22:13 --> Helper loaded: file_helper
INFO - 2024-02-07 19:22:13 --> Helper loaded: form_helper
INFO - 2024-02-07 19:22:13 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:22:13 --> Controller Class Initialized
INFO - 2024-02-07 19:22:13 --> Form Validation Class Initialized
INFO - 2024-02-07 19:22:13 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:22:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:22:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:22:13 --> Final output sent to browser
DEBUG - 2024-02-07 19:22:13 --> Total execution time: 0.0269
ERROR - 2024-02-07 19:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:22:49 --> Config Class Initialized
INFO - 2024-02-07 19:22:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:22:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:22:49 --> Utf8 Class Initialized
INFO - 2024-02-07 19:22:49 --> URI Class Initialized
INFO - 2024-02-07 19:22:49 --> Router Class Initialized
INFO - 2024-02-07 19:22:49 --> Output Class Initialized
INFO - 2024-02-07 19:22:49 --> Security Class Initialized
DEBUG - 2024-02-07 19:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:22:49 --> Input Class Initialized
INFO - 2024-02-07 19:22:49 --> Language Class Initialized
INFO - 2024-02-07 19:22:49 --> Loader Class Initialized
INFO - 2024-02-07 19:22:49 --> Helper loaded: url_helper
INFO - 2024-02-07 19:22:49 --> Helper loaded: file_helper
INFO - 2024-02-07 19:22:49 --> Helper loaded: form_helper
INFO - 2024-02-07 19:22:49 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:22:49 --> Controller Class Initialized
INFO - 2024-02-07 19:22:49 --> Form Validation Class Initialized
INFO - 2024-02-07 19:22:49 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:22:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:22:49 --> Final output sent to browser
DEBUG - 2024-02-07 19:22:49 --> Total execution time: 0.0265
ERROR - 2024-02-07 19:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:22:49 --> Config Class Initialized
INFO - 2024-02-07 19:22:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:22:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:22:49 --> Utf8 Class Initialized
INFO - 2024-02-07 19:22:49 --> URI Class Initialized
INFO - 2024-02-07 19:22:49 --> Router Class Initialized
INFO - 2024-02-07 19:22:49 --> Output Class Initialized
ERROR - 2024-02-07 19:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:22:49 --> Security Class Initialized
INFO - 2024-02-07 19:22:49 --> Config Class Initialized
INFO - 2024-02-07 19:22:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:22:49 --> Input Class Initialized
INFO - 2024-02-07 19:22:49 --> Language Class Initialized
INFO - 2024-02-07 19:22:49 --> Loader Class Initialized
DEBUG - 2024-02-07 19:22:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:22:49 --> Helper loaded: url_helper
INFO - 2024-02-07 19:22:49 --> Utf8 Class Initialized
INFO - 2024-02-07 19:22:49 --> Helper loaded: file_helper
INFO - 2024-02-07 19:22:49 --> Helper loaded: form_helper
INFO - 2024-02-07 19:22:49 --> URI Class Initialized
INFO - 2024-02-07 19:22:49 --> Router Class Initialized
INFO - 2024-02-07 19:22:49 --> Output Class Initialized
INFO - 2024-02-07 19:22:49 --> Security Class Initialized
INFO - 2024-02-07 19:22:49 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:22:49 --> Input Class Initialized
INFO - 2024-02-07 19:22:49 --> Language Class Initialized
INFO - 2024-02-07 19:22:49 --> Loader Class Initialized
DEBUG - 2024-02-07 19:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:22:49 --> Controller Class Initialized
INFO - 2024-02-07 19:22:49 --> Helper loaded: url_helper
INFO - 2024-02-07 19:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:22:49 --> Final output sent to browser
DEBUG - 2024-02-07 19:22:49 --> Total execution time: 0.0220
INFO - 2024-02-07 19:22:49 --> Helper loaded: file_helper
INFO - 2024-02-07 19:22:49 --> Helper loaded: form_helper
INFO - 2024-02-07 19:22:49 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:22:49 --> Controller Class Initialized
INFO - 2024-02-07 19:22:49 --> Form Validation Class Initialized
INFO - 2024-02-07 19:22:49 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:22:49 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:22:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:22:50 --> Config Class Initialized
INFO - 2024-02-07 19:22:50 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:22:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:22:50 --> Utf8 Class Initialized
INFO - 2024-02-07 19:22:50 --> URI Class Initialized
INFO - 2024-02-07 19:22:50 --> Router Class Initialized
INFO - 2024-02-07 19:22:50 --> Output Class Initialized
INFO - 2024-02-07 19:22:50 --> Security Class Initialized
DEBUG - 2024-02-07 19:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:22:50 --> Input Class Initialized
INFO - 2024-02-07 19:22:50 --> Language Class Initialized
INFO - 2024-02-07 19:22:50 --> Loader Class Initialized
INFO - 2024-02-07 19:22:50 --> Helper loaded: url_helper
INFO - 2024-02-07 19:22:50 --> Helper loaded: file_helper
INFO - 2024-02-07 19:22:50 --> Helper loaded: form_helper
INFO - 2024-02-07 19:22:50 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:22:50 --> Controller Class Initialized
INFO - 2024-02-07 19:22:50 --> Form Validation Class Initialized
INFO - 2024-02-07 19:22:50 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:22:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:22:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:22:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:22:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:22:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:22:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:22:50 --> Final output sent to browser
DEBUG - 2024-02-07 19:22:50 --> Total execution time: 0.0259
ERROR - 2024-02-07 19:22:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:22:51 --> Config Class Initialized
INFO - 2024-02-07 19:22:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:22:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:22:51 --> Utf8 Class Initialized
INFO - 2024-02-07 19:22:51 --> URI Class Initialized
INFO - 2024-02-07 19:22:51 --> Router Class Initialized
INFO - 2024-02-07 19:22:51 --> Output Class Initialized
INFO - 2024-02-07 19:22:51 --> Security Class Initialized
DEBUG - 2024-02-07 19:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:22:51 --> Input Class Initialized
INFO - 2024-02-07 19:22:51 --> Language Class Initialized
INFO - 2024-02-07 19:22:51 --> Loader Class Initialized
INFO - 2024-02-07 19:22:51 --> Helper loaded: url_helper
INFO - 2024-02-07 19:22:51 --> Helper loaded: file_helper
INFO - 2024-02-07 19:22:51 --> Helper loaded: form_helper
ERROR - 2024-02-07 19:22:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:22:51 --> Config Class Initialized
INFO - 2024-02-07 19:22:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:22:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:22:51 --> Utf8 Class Initialized
INFO - 2024-02-07 19:22:51 --> Database Driver Class Initialized
INFO - 2024-02-07 19:22:51 --> URI Class Initialized
INFO - 2024-02-07 19:22:51 --> Router Class Initialized
INFO - 2024-02-07 19:22:51 --> Output Class Initialized
DEBUG - 2024-02-07 19:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:22:51 --> Security Class Initialized
INFO - 2024-02-07 19:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:22:51 --> Controller Class Initialized
INFO - 2024-02-07 19:22:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:22:51 --> Final output sent to browser
DEBUG - 2024-02-07 19:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 19:22:51 --> Total execution time: 0.0373
INFO - 2024-02-07 19:22:51 --> Input Class Initialized
INFO - 2024-02-07 19:22:51 --> Language Class Initialized
INFO - 2024-02-07 19:22:51 --> Loader Class Initialized
INFO - 2024-02-07 19:22:51 --> Helper loaded: url_helper
INFO - 2024-02-07 19:22:51 --> Helper loaded: file_helper
INFO - 2024-02-07 19:22:51 --> Helper loaded: form_helper
INFO - 2024-02-07 19:22:51 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:22:51 --> Controller Class Initialized
INFO - 2024-02-07 19:22:51 --> Form Validation Class Initialized
INFO - 2024-02-07 19:22:51 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:22:51 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:22:53 --> Config Class Initialized
INFO - 2024-02-07 19:22:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:22:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:22:53 --> Utf8 Class Initialized
INFO - 2024-02-07 19:22:53 --> URI Class Initialized
INFO - 2024-02-07 19:22:53 --> Router Class Initialized
INFO - 2024-02-07 19:22:53 --> Output Class Initialized
INFO - 2024-02-07 19:22:53 --> Security Class Initialized
DEBUG - 2024-02-07 19:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:22:53 --> Input Class Initialized
INFO - 2024-02-07 19:22:53 --> Language Class Initialized
INFO - 2024-02-07 19:22:53 --> Loader Class Initialized
INFO - 2024-02-07 19:22:53 --> Helper loaded: url_helper
INFO - 2024-02-07 19:22:53 --> Helper loaded: file_helper
INFO - 2024-02-07 19:22:53 --> Helper loaded: form_helper
INFO - 2024-02-07 19:22:53 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:22:53 --> Controller Class Initialized
INFO - 2024-02-07 19:22:53 --> Form Validation Class Initialized
INFO - 2024-02-07 19:22:53 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:22:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:22:53 --> Final output sent to browser
DEBUG - 2024-02-07 19:22:53 --> Total execution time: 0.0252
ERROR - 2024-02-07 19:25:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:25:39 --> Config Class Initialized
INFO - 2024-02-07 19:25:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:25:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:25:39 --> Utf8 Class Initialized
INFO - 2024-02-07 19:25:39 --> URI Class Initialized
INFO - 2024-02-07 19:25:39 --> Router Class Initialized
INFO - 2024-02-07 19:25:39 --> Output Class Initialized
INFO - 2024-02-07 19:25:39 --> Security Class Initialized
DEBUG - 2024-02-07 19:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:25:39 --> Input Class Initialized
INFO - 2024-02-07 19:25:39 --> Language Class Initialized
INFO - 2024-02-07 19:25:39 --> Loader Class Initialized
INFO - 2024-02-07 19:25:39 --> Helper loaded: url_helper
INFO - 2024-02-07 19:25:39 --> Helper loaded: file_helper
INFO - 2024-02-07 19:25:39 --> Helper loaded: form_helper
INFO - 2024-02-07 19:25:39 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:25:39 --> Controller Class Initialized
INFO - 2024-02-07 19:25:39 --> Form Validation Class Initialized
INFO - 2024-02-07 19:25:39 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:25:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:25:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:25:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:25:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:25:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:25:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:25:39 --> Final output sent to browser
DEBUG - 2024-02-07 19:25:39 --> Total execution time: 0.0311
ERROR - 2024-02-07 19:25:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:25:40 --> Config Class Initialized
INFO - 2024-02-07 19:25:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:25:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:25:40 --> Utf8 Class Initialized
INFO - 2024-02-07 19:25:40 --> URI Class Initialized
INFO - 2024-02-07 19:25:40 --> Router Class Initialized
INFO - 2024-02-07 19:25:40 --> Output Class Initialized
INFO - 2024-02-07 19:25:40 --> Security Class Initialized
DEBUG - 2024-02-07 19:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:25:40 --> Input Class Initialized
INFO - 2024-02-07 19:25:40 --> Language Class Initialized
INFO - 2024-02-07 19:25:40 --> Loader Class Initialized
INFO - 2024-02-07 19:25:40 --> Helper loaded: url_helper
INFO - 2024-02-07 19:25:40 --> Helper loaded: file_helper
INFO - 2024-02-07 19:25:40 --> Helper loaded: form_helper
INFO - 2024-02-07 19:25:40 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:25:40 --> Controller Class Initialized
INFO - 2024-02-07 19:25:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:25:40 --> Final output sent to browser
DEBUG - 2024-02-07 19:25:40 --> Total execution time: 0.0257
ERROR - 2024-02-07 19:25:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:25:40 --> Config Class Initialized
INFO - 2024-02-07 19:25:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:25:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:25:40 --> Utf8 Class Initialized
INFO - 2024-02-07 19:25:40 --> URI Class Initialized
INFO - 2024-02-07 19:25:40 --> Router Class Initialized
INFO - 2024-02-07 19:25:40 --> Output Class Initialized
INFO - 2024-02-07 19:25:40 --> Security Class Initialized
DEBUG - 2024-02-07 19:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:25:40 --> Input Class Initialized
INFO - 2024-02-07 19:25:40 --> Language Class Initialized
INFO - 2024-02-07 19:25:40 --> Loader Class Initialized
INFO - 2024-02-07 19:25:40 --> Helper loaded: url_helper
INFO - 2024-02-07 19:25:40 --> Helper loaded: file_helper
INFO - 2024-02-07 19:25:40 --> Helper loaded: form_helper
INFO - 2024-02-07 19:25:40 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:25:40 --> Controller Class Initialized
INFO - 2024-02-07 19:25:40 --> Form Validation Class Initialized
INFO - 2024-02-07 19:25:40 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:25:40 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:25:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:25:43 --> Config Class Initialized
INFO - 2024-02-07 19:25:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:25:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:25:43 --> Utf8 Class Initialized
INFO - 2024-02-07 19:25:43 --> URI Class Initialized
INFO - 2024-02-07 19:25:43 --> Router Class Initialized
INFO - 2024-02-07 19:25:43 --> Output Class Initialized
INFO - 2024-02-07 19:25:43 --> Security Class Initialized
DEBUG - 2024-02-07 19:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:25:43 --> Input Class Initialized
INFO - 2024-02-07 19:25:43 --> Language Class Initialized
INFO - 2024-02-07 19:25:43 --> Loader Class Initialized
INFO - 2024-02-07 19:25:43 --> Helper loaded: url_helper
INFO - 2024-02-07 19:25:43 --> Helper loaded: file_helper
INFO - 2024-02-07 19:25:43 --> Helper loaded: form_helper
INFO - 2024-02-07 19:25:43 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:25:43 --> Controller Class Initialized
INFO - 2024-02-07 19:25:43 --> Form Validation Class Initialized
INFO - 2024-02-07 19:25:43 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:25:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:25:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:25:43 --> Final output sent to browser
DEBUG - 2024-02-07 19:25:43 --> Total execution time: 0.0348
ERROR - 2024-02-07 19:25:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:25:56 --> Config Class Initialized
INFO - 2024-02-07 19:25:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:25:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:25:56 --> Utf8 Class Initialized
INFO - 2024-02-07 19:25:56 --> URI Class Initialized
INFO - 2024-02-07 19:25:56 --> Router Class Initialized
INFO - 2024-02-07 19:25:56 --> Output Class Initialized
INFO - 2024-02-07 19:25:56 --> Security Class Initialized
DEBUG - 2024-02-07 19:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:25:56 --> Input Class Initialized
INFO - 2024-02-07 19:25:56 --> Language Class Initialized
INFO - 2024-02-07 19:25:56 --> Loader Class Initialized
INFO - 2024-02-07 19:25:56 --> Helper loaded: url_helper
INFO - 2024-02-07 19:25:56 --> Helper loaded: file_helper
INFO - 2024-02-07 19:25:56 --> Helper loaded: form_helper
INFO - 2024-02-07 19:25:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:25:56 --> Controller Class Initialized
INFO - 2024-02-07 19:25:56 --> Form Validation Class Initialized
INFO - 2024-02-07 19:25:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:25:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:25:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:25:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:25:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:25:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:25:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:25:56 --> Final output sent to browser
DEBUG - 2024-02-07 19:25:56 --> Total execution time: 0.0298
ERROR - 2024-02-07 19:25:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:25:57 --> Config Class Initialized
INFO - 2024-02-07 19:25:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:25:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:25:57 --> Utf8 Class Initialized
INFO - 2024-02-07 19:25:57 --> URI Class Initialized
INFO - 2024-02-07 19:25:57 --> Router Class Initialized
INFO - 2024-02-07 19:25:57 --> Output Class Initialized
INFO - 2024-02-07 19:25:57 --> Security Class Initialized
DEBUG - 2024-02-07 19:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:25:57 --> Input Class Initialized
INFO - 2024-02-07 19:25:57 --> Language Class Initialized
INFO - 2024-02-07 19:25:57 --> Loader Class Initialized
INFO - 2024-02-07 19:25:57 --> Helper loaded: url_helper
INFO - 2024-02-07 19:25:57 --> Helper loaded: file_helper
INFO - 2024-02-07 19:25:57 --> Helper loaded: form_helper
INFO - 2024-02-07 19:25:57 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:25:57 --> Controller Class Initialized
INFO - 2024-02-07 19:25:57 --> Form Validation Class Initialized
INFO - 2024-02-07 19:25:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:25:57 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:25:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:25:58 --> Config Class Initialized
INFO - 2024-02-07 19:25:58 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:25:58 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:25:58 --> Utf8 Class Initialized
INFO - 2024-02-07 19:25:58 --> URI Class Initialized
INFO - 2024-02-07 19:25:58 --> Router Class Initialized
INFO - 2024-02-07 19:25:58 --> Output Class Initialized
INFO - 2024-02-07 19:25:58 --> Security Class Initialized
DEBUG - 2024-02-07 19:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:25:58 --> Input Class Initialized
INFO - 2024-02-07 19:25:58 --> Language Class Initialized
INFO - 2024-02-07 19:25:58 --> Loader Class Initialized
INFO - 2024-02-07 19:25:58 --> Helper loaded: url_helper
INFO - 2024-02-07 19:25:58 --> Helper loaded: file_helper
INFO - 2024-02-07 19:25:58 --> Helper loaded: form_helper
INFO - 2024-02-07 19:25:58 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:25:58 --> Controller Class Initialized
INFO - 2024-02-07 19:25:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:25:58 --> Final output sent to browser
DEBUG - 2024-02-07 19:25:58 --> Total execution time: 0.0241
ERROR - 2024-02-07 19:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:26:01 --> Config Class Initialized
INFO - 2024-02-07 19:26:01 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:26:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:26:01 --> Utf8 Class Initialized
INFO - 2024-02-07 19:26:01 --> URI Class Initialized
INFO - 2024-02-07 19:26:01 --> Router Class Initialized
INFO - 2024-02-07 19:26:01 --> Output Class Initialized
INFO - 2024-02-07 19:26:01 --> Security Class Initialized
DEBUG - 2024-02-07 19:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:26:01 --> Input Class Initialized
INFO - 2024-02-07 19:26:01 --> Language Class Initialized
INFO - 2024-02-07 19:26:01 --> Loader Class Initialized
INFO - 2024-02-07 19:26:01 --> Helper loaded: url_helper
INFO - 2024-02-07 19:26:01 --> Helper loaded: file_helper
INFO - 2024-02-07 19:26:01 --> Helper loaded: form_helper
INFO - 2024-02-07 19:26:01 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:26:01 --> Controller Class Initialized
INFO - 2024-02-07 19:26:01 --> Form Validation Class Initialized
INFO - 2024-02-07 19:26:01 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:26:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:26:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:26:01 --> Final output sent to browser
DEBUG - 2024-02-07 19:26:01 --> Total execution time: 0.0264
ERROR - 2024-02-07 19:26:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:26:14 --> Config Class Initialized
INFO - 2024-02-07 19:26:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:26:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:26:14 --> Utf8 Class Initialized
INFO - 2024-02-07 19:26:14 --> URI Class Initialized
INFO - 2024-02-07 19:26:14 --> Router Class Initialized
INFO - 2024-02-07 19:26:14 --> Output Class Initialized
INFO - 2024-02-07 19:26:14 --> Security Class Initialized
DEBUG - 2024-02-07 19:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:26:14 --> Input Class Initialized
INFO - 2024-02-07 19:26:14 --> Language Class Initialized
INFO - 2024-02-07 19:26:14 --> Loader Class Initialized
INFO - 2024-02-07 19:26:14 --> Helper loaded: url_helper
INFO - 2024-02-07 19:26:14 --> Helper loaded: file_helper
INFO - 2024-02-07 19:26:14 --> Helper loaded: form_helper
INFO - 2024-02-07 19:26:14 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:26:14 --> Controller Class Initialized
INFO - 2024-02-07 19:26:14 --> Form Validation Class Initialized
INFO - 2024-02-07 19:26:14 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:26:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:26:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:26:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:26:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:26:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:26:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:26:14 --> Final output sent to browser
DEBUG - 2024-02-07 19:26:14 --> Total execution time: 0.0306
ERROR - 2024-02-07 19:26:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:26:15 --> Config Class Initialized
INFO - 2024-02-07 19:26:15 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:26:15 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:26:15 --> Utf8 Class Initialized
INFO - 2024-02-07 19:26:15 --> URI Class Initialized
INFO - 2024-02-07 19:26:15 --> Router Class Initialized
INFO - 2024-02-07 19:26:15 --> Output Class Initialized
INFO - 2024-02-07 19:26:15 --> Security Class Initialized
DEBUG - 2024-02-07 19:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:26:15 --> Input Class Initialized
INFO - 2024-02-07 19:26:15 --> Language Class Initialized
INFO - 2024-02-07 19:26:15 --> Loader Class Initialized
INFO - 2024-02-07 19:26:15 --> Helper loaded: url_helper
INFO - 2024-02-07 19:26:15 --> Helper loaded: file_helper
INFO - 2024-02-07 19:26:15 --> Helper loaded: form_helper
ERROR - 2024-02-07 19:26:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:26:15 --> Database Driver Class Initialized
INFO - 2024-02-07 19:26:15 --> Config Class Initialized
INFO - 2024-02-07 19:26:15 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:26:15 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:26:15 --> Utf8 Class Initialized
INFO - 2024-02-07 19:26:15 --> URI Class Initialized
DEBUG - 2024-02-07 19:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:26:15 --> Router Class Initialized
INFO - 2024-02-07 19:26:15 --> Controller Class Initialized
INFO - 2024-02-07 19:26:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:26:15 --> Final output sent to browser
DEBUG - 2024-02-07 19:26:15 --> Total execution time: 0.0264
INFO - 2024-02-07 19:26:15 --> Output Class Initialized
INFO - 2024-02-07 19:26:15 --> Security Class Initialized
DEBUG - 2024-02-07 19:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:26:15 --> Input Class Initialized
INFO - 2024-02-07 19:26:15 --> Language Class Initialized
INFO - 2024-02-07 19:26:15 --> Loader Class Initialized
INFO - 2024-02-07 19:26:15 --> Helper loaded: url_helper
INFO - 2024-02-07 19:26:15 --> Helper loaded: file_helper
INFO - 2024-02-07 19:26:15 --> Helper loaded: form_helper
INFO - 2024-02-07 19:26:15 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:26:15 --> Controller Class Initialized
INFO - 2024-02-07 19:26:15 --> Form Validation Class Initialized
INFO - 2024-02-07 19:26:15 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:26:15 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:26:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:26:18 --> Config Class Initialized
INFO - 2024-02-07 19:26:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:26:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:26:18 --> Utf8 Class Initialized
INFO - 2024-02-07 19:26:18 --> URI Class Initialized
INFO - 2024-02-07 19:26:18 --> Router Class Initialized
INFO - 2024-02-07 19:26:18 --> Output Class Initialized
INFO - 2024-02-07 19:26:18 --> Security Class Initialized
DEBUG - 2024-02-07 19:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:26:18 --> Input Class Initialized
INFO - 2024-02-07 19:26:18 --> Language Class Initialized
INFO - 2024-02-07 19:26:18 --> Loader Class Initialized
INFO - 2024-02-07 19:26:18 --> Helper loaded: url_helper
INFO - 2024-02-07 19:26:18 --> Helper loaded: file_helper
INFO - 2024-02-07 19:26:18 --> Helper loaded: form_helper
INFO - 2024-02-07 19:26:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:26:18 --> Controller Class Initialized
INFO - 2024-02-07 19:26:18 --> Form Validation Class Initialized
INFO - 2024-02-07 19:26:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:26:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:26:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:26:18 --> Final output sent to browser
DEBUG - 2024-02-07 19:26:18 --> Total execution time: 0.0288
ERROR - 2024-02-07 19:26:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:26:53 --> Config Class Initialized
INFO - 2024-02-07 19:26:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:26:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:26:53 --> Utf8 Class Initialized
INFO - 2024-02-07 19:26:53 --> URI Class Initialized
INFO - 2024-02-07 19:26:53 --> Router Class Initialized
INFO - 2024-02-07 19:26:53 --> Output Class Initialized
INFO - 2024-02-07 19:26:53 --> Security Class Initialized
DEBUG - 2024-02-07 19:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:26:53 --> Input Class Initialized
INFO - 2024-02-07 19:26:53 --> Language Class Initialized
INFO - 2024-02-07 19:26:53 --> Loader Class Initialized
INFO - 2024-02-07 19:26:53 --> Helper loaded: url_helper
INFO - 2024-02-07 19:26:53 --> Helper loaded: file_helper
INFO - 2024-02-07 19:26:53 --> Helper loaded: form_helper
INFO - 2024-02-07 19:26:53 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:26:53 --> Controller Class Initialized
INFO - 2024-02-07 19:26:53 --> Form Validation Class Initialized
INFO - 2024-02-07 19:26:53 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:26:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:26:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:26:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:26:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:26:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:26:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:26:53 --> Final output sent to browser
DEBUG - 2024-02-07 19:26:53 --> Total execution time: 0.0356
ERROR - 2024-02-07 19:26:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-07 19:26:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:26:53 --> Config Class Initialized
INFO - 2024-02-07 19:26:53 --> Hooks Class Initialized
INFO - 2024-02-07 19:26:53 --> Config Class Initialized
INFO - 2024-02-07 19:26:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:26:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 19:26:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:26:53 --> Utf8 Class Initialized
INFO - 2024-02-07 19:26:53 --> Utf8 Class Initialized
INFO - 2024-02-07 19:26:53 --> URI Class Initialized
INFO - 2024-02-07 19:26:53 --> URI Class Initialized
INFO - 2024-02-07 19:26:53 --> Router Class Initialized
INFO - 2024-02-07 19:26:53 --> Router Class Initialized
INFO - 2024-02-07 19:26:53 --> Output Class Initialized
INFO - 2024-02-07 19:26:53 --> Output Class Initialized
INFO - 2024-02-07 19:26:53 --> Security Class Initialized
INFO - 2024-02-07 19:26:53 --> Security Class Initialized
DEBUG - 2024-02-07 19:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:26:53 --> Input Class Initialized
DEBUG - 2024-02-07 19:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:26:53 --> Input Class Initialized
INFO - 2024-02-07 19:26:53 --> Language Class Initialized
INFO - 2024-02-07 19:26:53 --> Language Class Initialized
INFO - 2024-02-07 19:26:53 --> Loader Class Initialized
INFO - 2024-02-07 19:26:53 --> Loader Class Initialized
INFO - 2024-02-07 19:26:53 --> Helper loaded: url_helper
INFO - 2024-02-07 19:26:53 --> Helper loaded: url_helper
INFO - 2024-02-07 19:26:53 --> Helper loaded: file_helper
INFO - 2024-02-07 19:26:53 --> Helper loaded: file_helper
INFO - 2024-02-07 19:26:53 --> Helper loaded: form_helper
INFO - 2024-02-07 19:26:53 --> Helper loaded: form_helper
INFO - 2024-02-07 19:26:53 --> Database Driver Class Initialized
INFO - 2024-02-07 19:26:53 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 19:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:26:53 --> Controller Class Initialized
INFO - 2024-02-07 19:26:53 --> Form Validation Class Initialized
INFO - 2024-02-07 19:26:53 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:26:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:26:53 --> Controller Class Initialized
INFO - 2024-02-07 19:26:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:26:53 --> Final output sent to browser
DEBUG - 2024-02-07 19:26:53 --> Total execution time: 0.0314
ERROR - 2024-02-07 19:26:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:26:56 --> Config Class Initialized
INFO - 2024-02-07 19:26:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:26:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:26:56 --> Utf8 Class Initialized
INFO - 2024-02-07 19:26:56 --> URI Class Initialized
INFO - 2024-02-07 19:26:56 --> Router Class Initialized
INFO - 2024-02-07 19:26:56 --> Output Class Initialized
INFO - 2024-02-07 19:26:56 --> Security Class Initialized
DEBUG - 2024-02-07 19:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:26:56 --> Input Class Initialized
INFO - 2024-02-07 19:26:56 --> Language Class Initialized
INFO - 2024-02-07 19:26:56 --> Loader Class Initialized
INFO - 2024-02-07 19:26:56 --> Helper loaded: url_helper
INFO - 2024-02-07 19:26:56 --> Helper loaded: file_helper
INFO - 2024-02-07 19:26:57 --> Helper loaded: form_helper
INFO - 2024-02-07 19:26:57 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:26:57 --> Controller Class Initialized
INFO - 2024-02-07 19:26:57 --> Form Validation Class Initialized
INFO - 2024-02-07 19:26:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:26:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:26:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:26:57 --> Final output sent to browser
DEBUG - 2024-02-07 19:26:57 --> Total execution time: 0.0278
ERROR - 2024-02-07 19:27:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:27:33 --> Config Class Initialized
INFO - 2024-02-07 19:27:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:27:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:27:33 --> Utf8 Class Initialized
INFO - 2024-02-07 19:27:33 --> URI Class Initialized
INFO - 2024-02-07 19:27:33 --> Router Class Initialized
INFO - 2024-02-07 19:27:33 --> Output Class Initialized
INFO - 2024-02-07 19:27:33 --> Security Class Initialized
DEBUG - 2024-02-07 19:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:27:33 --> Input Class Initialized
INFO - 2024-02-07 19:27:33 --> Language Class Initialized
INFO - 2024-02-07 19:27:33 --> Loader Class Initialized
INFO - 2024-02-07 19:27:33 --> Helper loaded: url_helper
INFO - 2024-02-07 19:27:33 --> Helper loaded: file_helper
INFO - 2024-02-07 19:27:33 --> Helper loaded: form_helper
INFO - 2024-02-07 19:27:33 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:27:33 --> Controller Class Initialized
INFO - 2024-02-07 19:27:33 --> Form Validation Class Initialized
INFO - 2024-02-07 19:27:33 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:27:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:27:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:27:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:27:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:27:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:27:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:27:33 --> Final output sent to browser
DEBUG - 2024-02-07 19:27:33 --> Total execution time: 0.0338
ERROR - 2024-02-07 19:27:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:27:33 --> Config Class Initialized
INFO - 2024-02-07 19:27:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:27:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:27:33 --> Utf8 Class Initialized
INFO - 2024-02-07 19:27:33 --> URI Class Initialized
INFO - 2024-02-07 19:27:33 --> Router Class Initialized
INFO - 2024-02-07 19:27:33 --> Output Class Initialized
INFO - 2024-02-07 19:27:33 --> Security Class Initialized
DEBUG - 2024-02-07 19:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:27:33 --> Input Class Initialized
INFO - 2024-02-07 19:27:33 --> Language Class Initialized
INFO - 2024-02-07 19:27:33 --> Loader Class Initialized
INFO - 2024-02-07 19:27:33 --> Helper loaded: url_helper
INFO - 2024-02-07 19:27:33 --> Helper loaded: file_helper
INFO - 2024-02-07 19:27:33 --> Helper loaded: form_helper
INFO - 2024-02-07 19:27:33 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:27:33 --> Controller Class Initialized
INFO - 2024-02-07 19:27:33 --> Form Validation Class Initialized
INFO - 2024-02-07 19:27:33 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:27:33 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:27:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:27:33 --> Config Class Initialized
INFO - 2024-02-07 19:27:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:27:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:27:33 --> Utf8 Class Initialized
INFO - 2024-02-07 19:27:33 --> URI Class Initialized
INFO - 2024-02-07 19:27:33 --> Router Class Initialized
INFO - 2024-02-07 19:27:33 --> Output Class Initialized
INFO - 2024-02-07 19:27:33 --> Security Class Initialized
DEBUG - 2024-02-07 19:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:27:33 --> Input Class Initialized
INFO - 2024-02-07 19:27:33 --> Language Class Initialized
INFO - 2024-02-07 19:27:33 --> Loader Class Initialized
INFO - 2024-02-07 19:27:33 --> Helper loaded: url_helper
INFO - 2024-02-07 19:27:33 --> Helper loaded: file_helper
INFO - 2024-02-07 19:27:33 --> Helper loaded: form_helper
INFO - 2024-02-07 19:27:33 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:27:33 --> Controller Class Initialized
INFO - 2024-02-07 19:27:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:27:33 --> Final output sent to browser
DEBUG - 2024-02-07 19:27:33 --> Total execution time: 0.0317
ERROR - 2024-02-07 19:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:27:35 --> Config Class Initialized
INFO - 2024-02-07 19:27:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:27:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:27:35 --> Utf8 Class Initialized
INFO - 2024-02-07 19:27:35 --> URI Class Initialized
INFO - 2024-02-07 19:27:35 --> Router Class Initialized
INFO - 2024-02-07 19:27:35 --> Output Class Initialized
INFO - 2024-02-07 19:27:35 --> Security Class Initialized
DEBUG - 2024-02-07 19:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:27:35 --> Input Class Initialized
INFO - 2024-02-07 19:27:35 --> Language Class Initialized
INFO - 2024-02-07 19:27:35 --> Loader Class Initialized
INFO - 2024-02-07 19:27:35 --> Helper loaded: url_helper
INFO - 2024-02-07 19:27:35 --> Helper loaded: file_helper
INFO - 2024-02-07 19:27:35 --> Helper loaded: form_helper
INFO - 2024-02-07 19:27:35 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:27:35 --> Controller Class Initialized
INFO - 2024-02-07 19:27:35 --> Form Validation Class Initialized
INFO - 2024-02-07 19:27:35 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:27:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:27:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:27:35 --> Final output sent to browser
DEBUG - 2024-02-07 19:27:35 --> Total execution time: 0.0252
ERROR - 2024-02-07 19:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:28:21 --> Config Class Initialized
INFO - 2024-02-07 19:28:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:28:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:28:21 --> Utf8 Class Initialized
INFO - 2024-02-07 19:28:21 --> URI Class Initialized
INFO - 2024-02-07 19:28:21 --> Router Class Initialized
INFO - 2024-02-07 19:28:21 --> Output Class Initialized
INFO - 2024-02-07 19:28:21 --> Security Class Initialized
DEBUG - 2024-02-07 19:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:28:21 --> Input Class Initialized
INFO - 2024-02-07 19:28:21 --> Language Class Initialized
INFO - 2024-02-07 19:28:21 --> Loader Class Initialized
INFO - 2024-02-07 19:28:21 --> Helper loaded: url_helper
INFO - 2024-02-07 19:28:21 --> Helper loaded: file_helper
INFO - 2024-02-07 19:28:21 --> Helper loaded: form_helper
INFO - 2024-02-07 19:28:21 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:28:21 --> Controller Class Initialized
INFO - 2024-02-07 19:28:21 --> Form Validation Class Initialized
INFO - 2024-02-07 19:28:21 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:28:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:28:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:28:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:28:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:28:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:28:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:28:21 --> Final output sent to browser
DEBUG - 2024-02-07 19:28:21 --> Total execution time: 0.0396
ERROR - 2024-02-07 19:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:28:21 --> Config Class Initialized
INFO - 2024-02-07 19:28:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:28:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:28:21 --> Utf8 Class Initialized
INFO - 2024-02-07 19:28:21 --> URI Class Initialized
INFO - 2024-02-07 19:28:21 --> Router Class Initialized
INFO - 2024-02-07 19:28:21 --> Output Class Initialized
INFO - 2024-02-07 19:28:21 --> Security Class Initialized
DEBUG - 2024-02-07 19:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:28:21 --> Input Class Initialized
INFO - 2024-02-07 19:28:21 --> Language Class Initialized
INFO - 2024-02-07 19:28:21 --> Loader Class Initialized
INFO - 2024-02-07 19:28:21 --> Helper loaded: url_helper
INFO - 2024-02-07 19:28:21 --> Helper loaded: file_helper
INFO - 2024-02-07 19:28:21 --> Helper loaded: form_helper
INFO - 2024-02-07 19:28:21 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:28:21 --> Controller Class Initialized
INFO - 2024-02-07 19:28:21 --> Form Validation Class Initialized
INFO - 2024-02-07 19:28:21 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:28:21 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:28:21 --> Config Class Initialized
INFO - 2024-02-07 19:28:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:28:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:28:21 --> Utf8 Class Initialized
INFO - 2024-02-07 19:28:21 --> URI Class Initialized
INFO - 2024-02-07 19:28:21 --> Router Class Initialized
INFO - 2024-02-07 19:28:21 --> Output Class Initialized
INFO - 2024-02-07 19:28:21 --> Security Class Initialized
DEBUG - 2024-02-07 19:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:28:21 --> Input Class Initialized
INFO - 2024-02-07 19:28:21 --> Language Class Initialized
INFO - 2024-02-07 19:28:21 --> Loader Class Initialized
INFO - 2024-02-07 19:28:21 --> Helper loaded: url_helper
INFO - 2024-02-07 19:28:21 --> Helper loaded: file_helper
INFO - 2024-02-07 19:28:21 --> Helper loaded: form_helper
INFO - 2024-02-07 19:28:21 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:28:21 --> Controller Class Initialized
INFO - 2024-02-07 19:28:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:28:21 --> Final output sent to browser
DEBUG - 2024-02-07 19:28:21 --> Total execution time: 0.0301
ERROR - 2024-02-07 19:28:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:28:24 --> Config Class Initialized
INFO - 2024-02-07 19:28:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:28:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:28:24 --> Utf8 Class Initialized
INFO - 2024-02-07 19:28:24 --> URI Class Initialized
INFO - 2024-02-07 19:28:24 --> Router Class Initialized
INFO - 2024-02-07 19:28:24 --> Output Class Initialized
INFO - 2024-02-07 19:28:24 --> Security Class Initialized
DEBUG - 2024-02-07 19:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:28:24 --> Input Class Initialized
INFO - 2024-02-07 19:28:24 --> Language Class Initialized
INFO - 2024-02-07 19:28:24 --> Loader Class Initialized
INFO - 2024-02-07 19:28:24 --> Helper loaded: url_helper
INFO - 2024-02-07 19:28:24 --> Helper loaded: file_helper
INFO - 2024-02-07 19:28:24 --> Helper loaded: form_helper
INFO - 2024-02-07 19:28:24 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:28:24 --> Controller Class Initialized
INFO - 2024-02-07 19:28:24 --> Form Validation Class Initialized
INFO - 2024-02-07 19:28:24 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:28:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:28:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:28:24 --> Final output sent to browser
DEBUG - 2024-02-07 19:28:24 --> Total execution time: 0.0299
ERROR - 2024-02-07 19:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:28:38 --> Config Class Initialized
INFO - 2024-02-07 19:28:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:28:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:28:38 --> Utf8 Class Initialized
INFO - 2024-02-07 19:28:38 --> URI Class Initialized
INFO - 2024-02-07 19:28:38 --> Router Class Initialized
INFO - 2024-02-07 19:28:38 --> Output Class Initialized
INFO - 2024-02-07 19:28:38 --> Security Class Initialized
DEBUG - 2024-02-07 19:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:28:38 --> Input Class Initialized
INFO - 2024-02-07 19:28:38 --> Language Class Initialized
INFO - 2024-02-07 19:28:38 --> Loader Class Initialized
INFO - 2024-02-07 19:28:38 --> Helper loaded: url_helper
INFO - 2024-02-07 19:28:38 --> Helper loaded: file_helper
INFO - 2024-02-07 19:28:38 --> Helper loaded: form_helper
INFO - 2024-02-07 19:28:38 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:28:38 --> Controller Class Initialized
INFO - 2024-02-07 19:28:38 --> Form Validation Class Initialized
INFO - 2024-02-07 19:28:38 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:28:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:28:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:28:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:28:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:28:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:28:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:28:38 --> Final output sent to browser
DEBUG - 2024-02-07 19:28:38 --> Total execution time: 0.0374
ERROR - 2024-02-07 19:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-07 19:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:28:39 --> Config Class Initialized
INFO - 2024-02-07 19:28:39 --> Hooks Class Initialized
INFO - 2024-02-07 19:28:39 --> Config Class Initialized
INFO - 2024-02-07 19:28:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:28:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:28:39 --> Utf8 Class Initialized
DEBUG - 2024-02-07 19:28:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:28:39 --> URI Class Initialized
INFO - 2024-02-07 19:28:39 --> Utf8 Class Initialized
INFO - 2024-02-07 19:28:39 --> Router Class Initialized
INFO - 2024-02-07 19:28:39 --> URI Class Initialized
INFO - 2024-02-07 19:28:39 --> Output Class Initialized
INFO - 2024-02-07 19:28:39 --> Router Class Initialized
INFO - 2024-02-07 19:28:39 --> Security Class Initialized
INFO - 2024-02-07 19:28:39 --> Output Class Initialized
INFO - 2024-02-07 19:28:39 --> Security Class Initialized
DEBUG - 2024-02-07 19:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:28:39 --> Input Class Initialized
INFO - 2024-02-07 19:28:39 --> Language Class Initialized
DEBUG - 2024-02-07 19:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:28:39 --> Input Class Initialized
INFO - 2024-02-07 19:28:39 --> Language Class Initialized
INFO - 2024-02-07 19:28:39 --> Loader Class Initialized
INFO - 2024-02-07 19:28:39 --> Loader Class Initialized
INFO - 2024-02-07 19:28:39 --> Helper loaded: url_helper
INFO - 2024-02-07 19:28:39 --> Helper loaded: url_helper
INFO - 2024-02-07 19:28:39 --> Helper loaded: file_helper
INFO - 2024-02-07 19:28:39 --> Helper loaded: file_helper
INFO - 2024-02-07 19:28:39 --> Helper loaded: form_helper
INFO - 2024-02-07 19:28:39 --> Helper loaded: form_helper
INFO - 2024-02-07 19:28:39 --> Database Driver Class Initialized
INFO - 2024-02-07 19:28:39 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 19:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:28:39 --> Controller Class Initialized
INFO - 2024-02-07 19:28:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:28:39 --> Final output sent to browser
DEBUG - 2024-02-07 19:28:39 --> Total execution time: 0.0225
INFO - 2024-02-07 19:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:28:39 --> Controller Class Initialized
INFO - 2024-02-07 19:28:39 --> Form Validation Class Initialized
INFO - 2024-02-07 19:28:39 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:28:39 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:28:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:28:40 --> Config Class Initialized
INFO - 2024-02-07 19:28:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:28:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:28:40 --> Utf8 Class Initialized
INFO - 2024-02-07 19:28:40 --> URI Class Initialized
INFO - 2024-02-07 19:28:40 --> Router Class Initialized
INFO - 2024-02-07 19:28:40 --> Output Class Initialized
INFO - 2024-02-07 19:28:40 --> Security Class Initialized
DEBUG - 2024-02-07 19:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:28:40 --> Input Class Initialized
INFO - 2024-02-07 19:28:40 --> Language Class Initialized
INFO - 2024-02-07 19:28:40 --> Loader Class Initialized
INFO - 2024-02-07 19:28:40 --> Helper loaded: url_helper
INFO - 2024-02-07 19:28:40 --> Helper loaded: file_helper
INFO - 2024-02-07 19:28:40 --> Helper loaded: form_helper
INFO - 2024-02-07 19:28:40 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:28:40 --> Controller Class Initialized
INFO - 2024-02-07 19:28:40 --> Form Validation Class Initialized
INFO - 2024-02-07 19:28:40 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:28:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:28:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:28:40 --> Final output sent to browser
DEBUG - 2024-02-07 19:28:40 --> Total execution time: 0.0287
ERROR - 2024-02-07 19:29:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:29:48 --> Config Class Initialized
INFO - 2024-02-07 19:29:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:29:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:29:48 --> Utf8 Class Initialized
INFO - 2024-02-07 19:29:48 --> URI Class Initialized
INFO - 2024-02-07 19:29:48 --> Router Class Initialized
INFO - 2024-02-07 19:29:48 --> Output Class Initialized
INFO - 2024-02-07 19:29:48 --> Security Class Initialized
DEBUG - 2024-02-07 19:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:29:48 --> Input Class Initialized
INFO - 2024-02-07 19:29:48 --> Language Class Initialized
INFO - 2024-02-07 19:29:48 --> Loader Class Initialized
INFO - 2024-02-07 19:29:48 --> Helper loaded: url_helper
INFO - 2024-02-07 19:29:48 --> Helper loaded: file_helper
INFO - 2024-02-07 19:29:48 --> Helper loaded: form_helper
INFO - 2024-02-07 19:29:48 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:29:48 --> Controller Class Initialized
INFO - 2024-02-07 19:29:48 --> Form Validation Class Initialized
INFO - 2024-02-07 19:29:48 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:29:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:29:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:29:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:29:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:29:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:29:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:29:48 --> Final output sent to browser
DEBUG - 2024-02-07 19:29:48 --> Total execution time: 0.0338
ERROR - 2024-02-07 19:29:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:29:49 --> Config Class Initialized
INFO - 2024-02-07 19:29:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:29:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:29:49 --> Utf8 Class Initialized
INFO - 2024-02-07 19:29:49 --> URI Class Initialized
INFO - 2024-02-07 19:29:49 --> Router Class Initialized
INFO - 2024-02-07 19:29:49 --> Output Class Initialized
INFO - 2024-02-07 19:29:49 --> Security Class Initialized
DEBUG - 2024-02-07 19:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:29:49 --> Input Class Initialized
INFO - 2024-02-07 19:29:49 --> Language Class Initialized
INFO - 2024-02-07 19:29:49 --> Loader Class Initialized
INFO - 2024-02-07 19:29:49 --> Helper loaded: url_helper
INFO - 2024-02-07 19:29:49 --> Helper loaded: file_helper
INFO - 2024-02-07 19:29:49 --> Helper loaded: form_helper
INFO - 2024-02-07 19:29:49 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:29:49 --> Controller Class Initialized
INFO - 2024-02-07 19:29:49 --> Form Validation Class Initialized
INFO - 2024-02-07 19:29:49 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:29:49 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:29:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:29:49 --> Config Class Initialized
INFO - 2024-02-07 19:29:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:29:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:29:49 --> Utf8 Class Initialized
INFO - 2024-02-07 19:29:49 --> URI Class Initialized
INFO - 2024-02-07 19:29:49 --> Router Class Initialized
INFO - 2024-02-07 19:29:49 --> Output Class Initialized
INFO - 2024-02-07 19:29:49 --> Security Class Initialized
DEBUG - 2024-02-07 19:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:29:49 --> Input Class Initialized
INFO - 2024-02-07 19:29:49 --> Language Class Initialized
INFO - 2024-02-07 19:29:49 --> Loader Class Initialized
INFO - 2024-02-07 19:29:49 --> Helper loaded: url_helper
INFO - 2024-02-07 19:29:49 --> Helper loaded: file_helper
INFO - 2024-02-07 19:29:49 --> Helper loaded: form_helper
INFO - 2024-02-07 19:29:49 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:29:49 --> Controller Class Initialized
INFO - 2024-02-07 19:29:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:29:49 --> Final output sent to browser
DEBUG - 2024-02-07 19:29:49 --> Total execution time: 0.0296
ERROR - 2024-02-07 19:29:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:29:51 --> Config Class Initialized
INFO - 2024-02-07 19:29:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:29:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:29:51 --> Utf8 Class Initialized
INFO - 2024-02-07 19:29:51 --> URI Class Initialized
INFO - 2024-02-07 19:29:51 --> Router Class Initialized
INFO - 2024-02-07 19:29:51 --> Output Class Initialized
INFO - 2024-02-07 19:29:51 --> Security Class Initialized
DEBUG - 2024-02-07 19:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:29:51 --> Input Class Initialized
INFO - 2024-02-07 19:29:51 --> Language Class Initialized
INFO - 2024-02-07 19:29:51 --> Loader Class Initialized
INFO - 2024-02-07 19:29:51 --> Helper loaded: url_helper
INFO - 2024-02-07 19:29:51 --> Helper loaded: file_helper
INFO - 2024-02-07 19:29:51 --> Helper loaded: form_helper
INFO - 2024-02-07 19:29:51 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:29:51 --> Controller Class Initialized
INFO - 2024-02-07 19:29:51 --> Form Validation Class Initialized
INFO - 2024-02-07 19:29:51 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:29:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:29:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:29:51 --> Final output sent to browser
DEBUG - 2024-02-07 19:29:51 --> Total execution time: 0.0287
ERROR - 2024-02-07 19:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:30:19 --> Config Class Initialized
INFO - 2024-02-07 19:30:19 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:30:19 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:30:19 --> Utf8 Class Initialized
INFO - 2024-02-07 19:30:19 --> URI Class Initialized
INFO - 2024-02-07 19:30:19 --> Router Class Initialized
INFO - 2024-02-07 19:30:19 --> Output Class Initialized
INFO - 2024-02-07 19:30:19 --> Security Class Initialized
DEBUG - 2024-02-07 19:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:30:19 --> Input Class Initialized
INFO - 2024-02-07 19:30:19 --> Language Class Initialized
INFO - 2024-02-07 19:30:19 --> Loader Class Initialized
INFO - 2024-02-07 19:30:19 --> Helper loaded: url_helper
INFO - 2024-02-07 19:30:19 --> Helper loaded: file_helper
INFO - 2024-02-07 19:30:19 --> Helper loaded: form_helper
INFO - 2024-02-07 19:30:19 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:30:19 --> Controller Class Initialized
INFO - 2024-02-07 19:30:19 --> Form Validation Class Initialized
INFO - 2024-02-07 19:30:19 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:30:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:30:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:30:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:30:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:30:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:30:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:30:19 --> Final output sent to browser
DEBUG - 2024-02-07 19:30:19 --> Total execution time: 0.0873
ERROR - 2024-02-07 19:30:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:30:20 --> Config Class Initialized
INFO - 2024-02-07 19:30:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:30:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:30:20 --> Utf8 Class Initialized
INFO - 2024-02-07 19:30:20 --> URI Class Initialized
INFO - 2024-02-07 19:30:20 --> Router Class Initialized
INFO - 2024-02-07 19:30:20 --> Output Class Initialized
INFO - 2024-02-07 19:30:20 --> Security Class Initialized
DEBUG - 2024-02-07 19:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:30:20 --> Input Class Initialized
INFO - 2024-02-07 19:30:20 --> Language Class Initialized
ERROR - 2024-02-07 19:30:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:30:20 --> Loader Class Initialized
INFO - 2024-02-07 19:30:20 --> Config Class Initialized
INFO - 2024-02-07 19:30:20 --> Helper loaded: url_helper
INFO - 2024-02-07 19:30:20 --> Hooks Class Initialized
INFO - 2024-02-07 19:30:20 --> Helper loaded: file_helper
DEBUG - 2024-02-07 19:30:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:30:20 --> Utf8 Class Initialized
INFO - 2024-02-07 19:30:20 --> Helper loaded: form_helper
INFO - 2024-02-07 19:30:20 --> URI Class Initialized
INFO - 2024-02-07 19:30:20 --> Router Class Initialized
INFO - 2024-02-07 19:30:20 --> Output Class Initialized
INFO - 2024-02-07 19:30:20 --> Security Class Initialized
DEBUG - 2024-02-07 19:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:30:20 --> Database Driver Class Initialized
INFO - 2024-02-07 19:30:20 --> Input Class Initialized
INFO - 2024-02-07 19:30:20 --> Language Class Initialized
INFO - 2024-02-07 19:30:20 --> Loader Class Initialized
DEBUG - 2024-02-07 19:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:30:20 --> Helper loaded: url_helper
INFO - 2024-02-07 19:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:30:20 --> Controller Class Initialized
INFO - 2024-02-07 19:30:20 --> Helper loaded: file_helper
INFO - 2024-02-07 19:30:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:30:20 --> Final output sent to browser
DEBUG - 2024-02-07 19:30:20 --> Total execution time: 0.0252
INFO - 2024-02-07 19:30:20 --> Helper loaded: form_helper
INFO - 2024-02-07 19:30:20 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:30:20 --> Controller Class Initialized
INFO - 2024-02-07 19:30:20 --> Form Validation Class Initialized
INFO - 2024-02-07 19:30:20 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:30:20 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:30:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:30:23 --> Config Class Initialized
INFO - 2024-02-07 19:30:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:30:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:30:23 --> Utf8 Class Initialized
INFO - 2024-02-07 19:30:23 --> URI Class Initialized
INFO - 2024-02-07 19:30:23 --> Router Class Initialized
INFO - 2024-02-07 19:30:23 --> Output Class Initialized
INFO - 2024-02-07 19:30:23 --> Security Class Initialized
DEBUG - 2024-02-07 19:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:30:23 --> Input Class Initialized
INFO - 2024-02-07 19:30:23 --> Language Class Initialized
INFO - 2024-02-07 19:30:23 --> Loader Class Initialized
INFO - 2024-02-07 19:30:23 --> Helper loaded: url_helper
INFO - 2024-02-07 19:30:23 --> Helper loaded: file_helper
INFO - 2024-02-07 19:30:23 --> Helper loaded: form_helper
INFO - 2024-02-07 19:30:23 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:30:23 --> Controller Class Initialized
INFO - 2024-02-07 19:30:23 --> Form Validation Class Initialized
INFO - 2024-02-07 19:30:23 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:30:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:30:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:30:23 --> Final output sent to browser
DEBUG - 2024-02-07 19:30:23 --> Total execution time: 0.0292
ERROR - 2024-02-07 19:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:31:08 --> Config Class Initialized
INFO - 2024-02-07 19:31:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:31:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:31:08 --> Utf8 Class Initialized
INFO - 2024-02-07 19:31:08 --> URI Class Initialized
INFO - 2024-02-07 19:31:08 --> Router Class Initialized
INFO - 2024-02-07 19:31:08 --> Output Class Initialized
INFO - 2024-02-07 19:31:08 --> Security Class Initialized
DEBUG - 2024-02-07 19:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:31:08 --> Input Class Initialized
INFO - 2024-02-07 19:31:08 --> Language Class Initialized
INFO - 2024-02-07 19:31:08 --> Loader Class Initialized
INFO - 2024-02-07 19:31:08 --> Helper loaded: url_helper
INFO - 2024-02-07 19:31:08 --> Helper loaded: file_helper
INFO - 2024-02-07 19:31:08 --> Helper loaded: form_helper
INFO - 2024-02-07 19:31:08 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:31:08 --> Controller Class Initialized
INFO - 2024-02-07 19:31:08 --> Form Validation Class Initialized
INFO - 2024-02-07 19:31:08 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:31:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:31:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:31:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:31:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:31:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:31:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:31:08 --> Final output sent to browser
DEBUG - 2024-02-07 19:31:08 --> Total execution time: 0.0302
ERROR - 2024-02-07 19:31:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:31:09 --> Config Class Initialized
INFO - 2024-02-07 19:31:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:31:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:31:09 --> Utf8 Class Initialized
INFO - 2024-02-07 19:31:09 --> URI Class Initialized
INFO - 2024-02-07 19:31:09 --> Router Class Initialized
INFO - 2024-02-07 19:31:09 --> Output Class Initialized
INFO - 2024-02-07 19:31:09 --> Security Class Initialized
DEBUG - 2024-02-07 19:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:31:09 --> Input Class Initialized
INFO - 2024-02-07 19:31:09 --> Language Class Initialized
INFO - 2024-02-07 19:31:09 --> Loader Class Initialized
INFO - 2024-02-07 19:31:09 --> Helper loaded: url_helper
INFO - 2024-02-07 19:31:09 --> Helper loaded: file_helper
INFO - 2024-02-07 19:31:09 --> Helper loaded: form_helper
INFO - 2024-02-07 19:31:09 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:31:09 --> Controller Class Initialized
INFO - 2024-02-07 19:31:09 --> Form Validation Class Initialized
INFO - 2024-02-07 19:31:09 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:31:09 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:31:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:31:10 --> Config Class Initialized
INFO - 2024-02-07 19:31:10 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:31:10 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:31:10 --> Utf8 Class Initialized
INFO - 2024-02-07 19:31:10 --> URI Class Initialized
INFO - 2024-02-07 19:31:10 --> Router Class Initialized
INFO - 2024-02-07 19:31:10 --> Output Class Initialized
INFO - 2024-02-07 19:31:10 --> Security Class Initialized
DEBUG - 2024-02-07 19:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:31:10 --> Input Class Initialized
INFO - 2024-02-07 19:31:10 --> Language Class Initialized
INFO - 2024-02-07 19:31:10 --> Loader Class Initialized
INFO - 2024-02-07 19:31:10 --> Helper loaded: url_helper
INFO - 2024-02-07 19:31:10 --> Helper loaded: file_helper
INFO - 2024-02-07 19:31:10 --> Helper loaded: form_helper
INFO - 2024-02-07 19:31:10 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:31:10 --> Controller Class Initialized
INFO - 2024-02-07 19:31:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:31:10 --> Final output sent to browser
DEBUG - 2024-02-07 19:31:10 --> Total execution time: 0.0243
ERROR - 2024-02-07 19:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:31:12 --> Config Class Initialized
INFO - 2024-02-07 19:31:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:31:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:31:12 --> Utf8 Class Initialized
INFO - 2024-02-07 19:31:12 --> URI Class Initialized
INFO - 2024-02-07 19:31:12 --> Router Class Initialized
INFO - 2024-02-07 19:31:12 --> Output Class Initialized
INFO - 2024-02-07 19:31:12 --> Security Class Initialized
DEBUG - 2024-02-07 19:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:31:12 --> Input Class Initialized
INFO - 2024-02-07 19:31:12 --> Language Class Initialized
INFO - 2024-02-07 19:31:12 --> Loader Class Initialized
INFO - 2024-02-07 19:31:12 --> Helper loaded: url_helper
INFO - 2024-02-07 19:31:12 --> Helper loaded: file_helper
INFO - 2024-02-07 19:31:12 --> Helper loaded: form_helper
INFO - 2024-02-07 19:31:12 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:31:12 --> Controller Class Initialized
INFO - 2024-02-07 19:31:12 --> Form Validation Class Initialized
INFO - 2024-02-07 19:31:12 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:31:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:31:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:31:12 --> Final output sent to browser
DEBUG - 2024-02-07 19:31:12 --> Total execution time: 0.0341
ERROR - 2024-02-07 19:33:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:33:47 --> Config Class Initialized
INFO - 2024-02-07 19:33:47 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:33:47 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:33:47 --> Utf8 Class Initialized
INFO - 2024-02-07 19:33:47 --> URI Class Initialized
INFO - 2024-02-07 19:33:47 --> Router Class Initialized
INFO - 2024-02-07 19:33:47 --> Output Class Initialized
INFO - 2024-02-07 19:33:47 --> Security Class Initialized
DEBUG - 2024-02-07 19:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:33:47 --> Input Class Initialized
INFO - 2024-02-07 19:33:47 --> Language Class Initialized
INFO - 2024-02-07 19:33:47 --> Loader Class Initialized
INFO - 2024-02-07 19:33:47 --> Helper loaded: url_helper
INFO - 2024-02-07 19:33:47 --> Helper loaded: file_helper
INFO - 2024-02-07 19:33:47 --> Helper loaded: form_helper
INFO - 2024-02-07 19:33:47 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:33:47 --> Controller Class Initialized
INFO - 2024-02-07 19:33:47 --> Form Validation Class Initialized
INFO - 2024-02-07 19:33:47 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:33:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:33:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:33:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:33:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:33:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:33:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:33:47 --> Final output sent to browser
DEBUG - 2024-02-07 19:33:47 --> Total execution time: 0.0317
ERROR - 2024-02-07 19:33:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-07 19:33:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:33:47 --> Config Class Initialized
INFO - 2024-02-07 19:33:47 --> Hooks Class Initialized
INFO - 2024-02-07 19:33:47 --> Config Class Initialized
INFO - 2024-02-07 19:33:47 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:33:47 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:33:47 --> Utf8 Class Initialized
DEBUG - 2024-02-07 19:33:47 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:33:47 --> Utf8 Class Initialized
INFO - 2024-02-07 19:33:47 --> URI Class Initialized
INFO - 2024-02-07 19:33:47 --> URI Class Initialized
INFO - 2024-02-07 19:33:47 --> Router Class Initialized
INFO - 2024-02-07 19:33:47 --> Router Class Initialized
INFO - 2024-02-07 19:33:47 --> Output Class Initialized
INFO - 2024-02-07 19:33:47 --> Security Class Initialized
INFO - 2024-02-07 19:33:47 --> Output Class Initialized
DEBUG - 2024-02-07 19:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:33:47 --> Input Class Initialized
INFO - 2024-02-07 19:33:47 --> Language Class Initialized
INFO - 2024-02-07 19:33:47 --> Security Class Initialized
DEBUG - 2024-02-07 19:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:33:47 --> Input Class Initialized
INFO - 2024-02-07 19:33:47 --> Loader Class Initialized
INFO - 2024-02-07 19:33:47 --> Language Class Initialized
INFO - 2024-02-07 19:33:47 --> Helper loaded: url_helper
INFO - 2024-02-07 19:33:47 --> Helper loaded: file_helper
INFO - 2024-02-07 19:33:47 --> Loader Class Initialized
INFO - 2024-02-07 19:33:47 --> Helper loaded: form_helper
INFO - 2024-02-07 19:33:47 --> Helper loaded: url_helper
INFO - 2024-02-07 19:33:47 --> Helper loaded: file_helper
INFO - 2024-02-07 19:33:47 --> Helper loaded: form_helper
INFO - 2024-02-07 19:33:47 --> Database Driver Class Initialized
INFO - 2024-02-07 19:33:47 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:33:47 --> Controller Class Initialized
INFO - 2024-02-07 19:33:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:33:47 --> Final output sent to browser
DEBUG - 2024-02-07 19:33:47 --> Total execution time: 0.0209
DEBUG - 2024-02-07 19:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:33:47 --> Controller Class Initialized
INFO - 2024-02-07 19:33:47 --> Form Validation Class Initialized
INFO - 2024-02-07 19:33:47 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:33:47 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:33:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:33:50 --> Config Class Initialized
INFO - 2024-02-07 19:33:50 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:33:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:33:50 --> Utf8 Class Initialized
INFO - 2024-02-07 19:33:50 --> URI Class Initialized
INFO - 2024-02-07 19:33:50 --> Router Class Initialized
INFO - 2024-02-07 19:33:50 --> Output Class Initialized
INFO - 2024-02-07 19:33:50 --> Security Class Initialized
DEBUG - 2024-02-07 19:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:33:50 --> Input Class Initialized
INFO - 2024-02-07 19:33:50 --> Language Class Initialized
INFO - 2024-02-07 19:33:50 --> Loader Class Initialized
INFO - 2024-02-07 19:33:50 --> Helper loaded: url_helper
INFO - 2024-02-07 19:33:50 --> Helper loaded: file_helper
INFO - 2024-02-07 19:33:50 --> Helper loaded: form_helper
INFO - 2024-02-07 19:33:50 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:33:50 --> Controller Class Initialized
INFO - 2024-02-07 19:33:50 --> Form Validation Class Initialized
INFO - 2024-02-07 19:33:50 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:33:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:33:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:33:50 --> Final output sent to browser
DEBUG - 2024-02-07 19:33:50 --> Total execution time: 0.0245
ERROR - 2024-02-07 19:34:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:34:10 --> Config Class Initialized
INFO - 2024-02-07 19:34:10 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:34:10 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:34:10 --> Utf8 Class Initialized
INFO - 2024-02-07 19:34:10 --> URI Class Initialized
INFO - 2024-02-07 19:34:10 --> Router Class Initialized
INFO - 2024-02-07 19:34:10 --> Output Class Initialized
INFO - 2024-02-07 19:34:10 --> Security Class Initialized
DEBUG - 2024-02-07 19:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:34:10 --> Input Class Initialized
INFO - 2024-02-07 19:34:10 --> Language Class Initialized
INFO - 2024-02-07 19:34:10 --> Loader Class Initialized
INFO - 2024-02-07 19:34:10 --> Helper loaded: url_helper
INFO - 2024-02-07 19:34:10 --> Helper loaded: file_helper
INFO - 2024-02-07 19:34:10 --> Helper loaded: form_helper
INFO - 2024-02-07 19:34:10 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:34:10 --> Controller Class Initialized
INFO - 2024-02-07 19:34:10 --> Form Validation Class Initialized
INFO - 2024-02-07 19:34:10 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:34:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 19:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 19:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 19:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 19:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 19:34:10 --> Final output sent to browser
DEBUG - 2024-02-07 19:34:10 --> Total execution time: 0.0340
ERROR - 2024-02-07 19:34:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:34:11 --> Config Class Initialized
INFO - 2024-02-07 19:34:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:34:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:34:11 --> Utf8 Class Initialized
INFO - 2024-02-07 19:34:11 --> URI Class Initialized
INFO - 2024-02-07 19:34:11 --> Router Class Initialized
INFO - 2024-02-07 19:34:11 --> Output Class Initialized
ERROR - 2024-02-07 19:34:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:34:11 --> Security Class Initialized
INFO - 2024-02-07 19:34:11 --> Config Class Initialized
INFO - 2024-02-07 19:34:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:34:11 --> Input Class Initialized
DEBUG - 2024-02-07 19:34:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:34:11 --> Language Class Initialized
INFO - 2024-02-07 19:34:11 --> Utf8 Class Initialized
INFO - 2024-02-07 19:34:11 --> URI Class Initialized
INFO - 2024-02-07 19:34:11 --> Router Class Initialized
INFO - 2024-02-07 19:34:11 --> Loader Class Initialized
INFO - 2024-02-07 19:34:11 --> Output Class Initialized
INFO - 2024-02-07 19:34:11 --> Helper loaded: url_helper
INFO - 2024-02-07 19:34:11 --> Helper loaded: file_helper
INFO - 2024-02-07 19:34:11 --> Security Class Initialized
INFO - 2024-02-07 19:34:11 --> Helper loaded: form_helper
DEBUG - 2024-02-07 19:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:34:11 --> Input Class Initialized
INFO - 2024-02-07 19:34:11 --> Language Class Initialized
INFO - 2024-02-07 19:34:11 --> Loader Class Initialized
INFO - 2024-02-07 19:34:11 --> Helper loaded: url_helper
INFO - 2024-02-07 19:34:11 --> Database Driver Class Initialized
INFO - 2024-02-07 19:34:11 --> Helper loaded: file_helper
DEBUG - 2024-02-07 19:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:34:11 --> Controller Class Initialized
INFO - 2024-02-07 19:34:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 19:34:11 --> Final output sent to browser
DEBUG - 2024-02-07 19:34:11 --> Total execution time: 0.0220
INFO - 2024-02-07 19:34:11 --> Helper loaded: form_helper
INFO - 2024-02-07 19:34:11 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:34:11 --> Controller Class Initialized
INFO - 2024-02-07 19:34:11 --> Form Validation Class Initialized
INFO - 2024-02-07 19:34:11 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:34:11 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 19:34:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 19:34:14 --> Config Class Initialized
INFO - 2024-02-07 19:34:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 19:34:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 19:34:14 --> Utf8 Class Initialized
INFO - 2024-02-07 19:34:14 --> URI Class Initialized
INFO - 2024-02-07 19:34:14 --> Router Class Initialized
INFO - 2024-02-07 19:34:14 --> Output Class Initialized
INFO - 2024-02-07 19:34:14 --> Security Class Initialized
DEBUG - 2024-02-07 19:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 19:34:14 --> Input Class Initialized
INFO - 2024-02-07 19:34:14 --> Language Class Initialized
INFO - 2024-02-07 19:34:14 --> Loader Class Initialized
INFO - 2024-02-07 19:34:14 --> Helper loaded: url_helper
INFO - 2024-02-07 19:34:14 --> Helper loaded: file_helper
INFO - 2024-02-07 19:34:14 --> Helper loaded: form_helper
INFO - 2024-02-07 19:34:14 --> Database Driver Class Initialized
DEBUG - 2024-02-07 19:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 19:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 19:34:14 --> Controller Class Initialized
INFO - 2024-02-07 19:34:14 --> Form Validation Class Initialized
INFO - 2024-02-07 19:34:14 --> Model "MasterModel" initialized
INFO - 2024-02-07 19:34:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 19:34:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 19:34:14 --> Final output sent to browser
DEBUG - 2024-02-07 19:34:14 --> Total execution time: 0.0290
ERROR - 2024-02-07 20:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:09:26 --> Config Class Initialized
INFO - 2024-02-07 20:09:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:09:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:09:26 --> Utf8 Class Initialized
INFO - 2024-02-07 20:09:26 --> URI Class Initialized
INFO - 2024-02-07 20:09:26 --> Router Class Initialized
INFO - 2024-02-07 20:09:26 --> Output Class Initialized
INFO - 2024-02-07 20:09:26 --> Security Class Initialized
DEBUG - 2024-02-07 20:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:09:26 --> Input Class Initialized
INFO - 2024-02-07 20:09:26 --> Language Class Initialized
INFO - 2024-02-07 20:09:26 --> Loader Class Initialized
INFO - 2024-02-07 20:09:26 --> Helper loaded: url_helper
INFO - 2024-02-07 20:09:26 --> Helper loaded: file_helper
INFO - 2024-02-07 20:09:26 --> Helper loaded: form_helper
INFO - 2024-02-07 20:09:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:09:26 --> Controller Class Initialized
INFO - 2024-02-07 20:09:26 --> Form Validation Class Initialized
INFO - 2024-02-07 20:09:26 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:09:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:09:26 --> Final output sent to browser
DEBUG - 2024-02-07 20:09:26 --> Total execution time: 0.0253
ERROR - 2024-02-07 20:09:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:09:27 --> Config Class Initialized
INFO - 2024-02-07 20:09:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:09:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:09:27 --> Utf8 Class Initialized
INFO - 2024-02-07 20:09:27 --> URI Class Initialized
INFO - 2024-02-07 20:09:27 --> Router Class Initialized
INFO - 2024-02-07 20:09:27 --> Output Class Initialized
INFO - 2024-02-07 20:09:27 --> Security Class Initialized
DEBUG - 2024-02-07 20:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:09:27 --> Input Class Initialized
INFO - 2024-02-07 20:09:27 --> Language Class Initialized
INFO - 2024-02-07 20:09:27 --> Loader Class Initialized
INFO - 2024-02-07 20:09:27 --> Helper loaded: url_helper
INFO - 2024-02-07 20:09:27 --> Helper loaded: file_helper
INFO - 2024-02-07 20:09:27 --> Helper loaded: form_helper
INFO - 2024-02-07 20:09:27 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:09:27 --> Controller Class Initialized
INFO - 2024-02-07 20:09:27 --> Form Validation Class Initialized
INFO - 2024-02-07 20:09:27 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:09:27 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:09:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:09:27 --> Config Class Initialized
INFO - 2024-02-07 20:09:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:09:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:09:27 --> Utf8 Class Initialized
INFO - 2024-02-07 20:09:27 --> URI Class Initialized
INFO - 2024-02-07 20:09:27 --> Router Class Initialized
INFO - 2024-02-07 20:09:27 --> Output Class Initialized
INFO - 2024-02-07 20:09:27 --> Security Class Initialized
DEBUG - 2024-02-07 20:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:09:27 --> Input Class Initialized
INFO - 2024-02-07 20:09:27 --> Language Class Initialized
INFO - 2024-02-07 20:09:27 --> Loader Class Initialized
INFO - 2024-02-07 20:09:27 --> Helper loaded: url_helper
INFO - 2024-02-07 20:09:27 --> Helper loaded: file_helper
INFO - 2024-02-07 20:09:27 --> Helper loaded: form_helper
INFO - 2024-02-07 20:09:27 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:09:27 --> Controller Class Initialized
INFO - 2024-02-07 20:09:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:09:27 --> Final output sent to browser
DEBUG - 2024-02-07 20:09:27 --> Total execution time: 0.0236
ERROR - 2024-02-07 20:09:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:09:29 --> Config Class Initialized
INFO - 2024-02-07 20:09:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:09:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:09:29 --> Utf8 Class Initialized
INFO - 2024-02-07 20:09:29 --> URI Class Initialized
INFO - 2024-02-07 20:09:29 --> Router Class Initialized
INFO - 2024-02-07 20:09:29 --> Output Class Initialized
INFO - 2024-02-07 20:09:29 --> Security Class Initialized
DEBUG - 2024-02-07 20:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:09:29 --> Input Class Initialized
INFO - 2024-02-07 20:09:29 --> Language Class Initialized
INFO - 2024-02-07 20:09:29 --> Loader Class Initialized
INFO - 2024-02-07 20:09:29 --> Helper loaded: url_helper
INFO - 2024-02-07 20:09:29 --> Helper loaded: file_helper
INFO - 2024-02-07 20:09:29 --> Helper loaded: form_helper
INFO - 2024-02-07 20:09:29 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:09:29 --> Controller Class Initialized
INFO - 2024-02-07 20:09:29 --> Form Validation Class Initialized
INFO - 2024-02-07 20:09:29 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:09:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:09:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:09:29 --> Final output sent to browser
DEBUG - 2024-02-07 20:09:29 --> Total execution time: 0.0367
ERROR - 2024-02-07 20:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:11:37 --> Config Class Initialized
INFO - 2024-02-07 20:11:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:11:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:11:37 --> Utf8 Class Initialized
INFO - 2024-02-07 20:11:37 --> URI Class Initialized
INFO - 2024-02-07 20:11:37 --> Router Class Initialized
INFO - 2024-02-07 20:11:37 --> Output Class Initialized
INFO - 2024-02-07 20:11:37 --> Security Class Initialized
DEBUG - 2024-02-07 20:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:11:37 --> Input Class Initialized
INFO - 2024-02-07 20:11:37 --> Language Class Initialized
INFO - 2024-02-07 20:11:37 --> Loader Class Initialized
INFO - 2024-02-07 20:11:37 --> Helper loaded: url_helper
INFO - 2024-02-07 20:11:37 --> Helper loaded: file_helper
INFO - 2024-02-07 20:11:37 --> Helper loaded: form_helper
INFO - 2024-02-07 20:11:37 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:11:37 --> Controller Class Initialized
INFO - 2024-02-07 20:11:37 --> Form Validation Class Initialized
INFO - 2024-02-07 20:11:37 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:11:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:11:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:11:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:11:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:11:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:11:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:11:37 --> Final output sent to browser
DEBUG - 2024-02-07 20:11:37 --> Total execution time: 0.0341
ERROR - 2024-02-07 20:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:11:37 --> Config Class Initialized
INFO - 2024-02-07 20:11:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:11:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:11:37 --> Utf8 Class Initialized
INFO - 2024-02-07 20:11:37 --> URI Class Initialized
ERROR - 2024-02-07 20:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:11:37 --> Router Class Initialized
INFO - 2024-02-07 20:11:37 --> Config Class Initialized
INFO - 2024-02-07 20:11:37 --> Hooks Class Initialized
INFO - 2024-02-07 20:11:37 --> Output Class Initialized
DEBUG - 2024-02-07 20:11:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:11:37 --> Security Class Initialized
INFO - 2024-02-07 20:11:37 --> Utf8 Class Initialized
INFO - 2024-02-07 20:11:37 --> URI Class Initialized
DEBUG - 2024-02-07 20:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:11:37 --> Input Class Initialized
INFO - 2024-02-07 20:11:37 --> Router Class Initialized
INFO - 2024-02-07 20:11:37 --> Language Class Initialized
INFO - 2024-02-07 20:11:37 --> Output Class Initialized
INFO - 2024-02-07 20:11:37 --> Security Class Initialized
DEBUG - 2024-02-07 20:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:11:37 --> Input Class Initialized
INFO - 2024-02-07 20:11:37 --> Language Class Initialized
INFO - 2024-02-07 20:11:37 --> Loader Class Initialized
INFO - 2024-02-07 20:11:37 --> Helper loaded: url_helper
INFO - 2024-02-07 20:11:37 --> Helper loaded: file_helper
INFO - 2024-02-07 20:11:37 --> Loader Class Initialized
INFO - 2024-02-07 20:11:37 --> Helper loaded: form_helper
INFO - 2024-02-07 20:11:37 --> Helper loaded: url_helper
INFO - 2024-02-07 20:11:37 --> Helper loaded: file_helper
INFO - 2024-02-07 20:11:37 --> Helper loaded: form_helper
INFO - 2024-02-07 20:11:37 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:11:37 --> Controller Class Initialized
INFO - 2024-02-07 20:11:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:11:37 --> Final output sent to browser
DEBUG - 2024-02-07 20:11:37 --> Total execution time: 0.0304
INFO - 2024-02-07 20:11:37 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:11:37 --> Controller Class Initialized
INFO - 2024-02-07 20:11:37 --> Form Validation Class Initialized
INFO - 2024-02-07 20:11:37 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:11:37 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:11:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:11:40 --> Config Class Initialized
INFO - 2024-02-07 20:11:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:11:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:11:40 --> Utf8 Class Initialized
INFO - 2024-02-07 20:11:40 --> URI Class Initialized
INFO - 2024-02-07 20:11:40 --> Router Class Initialized
INFO - 2024-02-07 20:11:40 --> Output Class Initialized
INFO - 2024-02-07 20:11:40 --> Security Class Initialized
DEBUG - 2024-02-07 20:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:11:40 --> Input Class Initialized
INFO - 2024-02-07 20:11:40 --> Language Class Initialized
INFO - 2024-02-07 20:11:40 --> Loader Class Initialized
INFO - 2024-02-07 20:11:40 --> Helper loaded: url_helper
INFO - 2024-02-07 20:11:40 --> Helper loaded: file_helper
INFO - 2024-02-07 20:11:40 --> Helper loaded: form_helper
INFO - 2024-02-07 20:11:40 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:11:40 --> Controller Class Initialized
INFO - 2024-02-07 20:11:40 --> Form Validation Class Initialized
INFO - 2024-02-07 20:11:40 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:11:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:11:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:11:40 --> Final output sent to browser
DEBUG - 2024-02-07 20:11:40 --> Total execution time: 0.0302
ERROR - 2024-02-07 20:12:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:12:22 --> Config Class Initialized
INFO - 2024-02-07 20:12:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:12:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:12:22 --> Utf8 Class Initialized
INFO - 2024-02-07 20:12:22 --> URI Class Initialized
INFO - 2024-02-07 20:12:22 --> Router Class Initialized
INFO - 2024-02-07 20:12:22 --> Output Class Initialized
INFO - 2024-02-07 20:12:22 --> Security Class Initialized
DEBUG - 2024-02-07 20:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:12:22 --> Input Class Initialized
INFO - 2024-02-07 20:12:22 --> Language Class Initialized
INFO - 2024-02-07 20:12:22 --> Loader Class Initialized
INFO - 2024-02-07 20:12:22 --> Helper loaded: url_helper
INFO - 2024-02-07 20:12:22 --> Helper loaded: file_helper
INFO - 2024-02-07 20:12:22 --> Helper loaded: form_helper
INFO - 2024-02-07 20:12:22 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:12:22 --> Controller Class Initialized
INFO - 2024-02-07 20:12:22 --> Form Validation Class Initialized
INFO - 2024-02-07 20:12:22 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:12:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:12:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:12:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:12:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:12:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:12:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:12:22 --> Final output sent to browser
DEBUG - 2024-02-07 20:12:22 --> Total execution time: 0.0353
ERROR - 2024-02-07 20:12:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:12:22 --> Config Class Initialized
INFO - 2024-02-07 20:12:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:12:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:12:22 --> Utf8 Class Initialized
INFO - 2024-02-07 20:12:22 --> URI Class Initialized
INFO - 2024-02-07 20:12:22 --> Router Class Initialized
INFO - 2024-02-07 20:12:22 --> Output Class Initialized
INFO - 2024-02-07 20:12:22 --> Security Class Initialized
DEBUG - 2024-02-07 20:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:12:22 --> Input Class Initialized
INFO - 2024-02-07 20:12:22 --> Language Class Initialized
INFO - 2024-02-07 20:12:22 --> Loader Class Initialized
INFO - 2024-02-07 20:12:22 --> Helper loaded: url_helper
INFO - 2024-02-07 20:12:22 --> Helper loaded: file_helper
INFO - 2024-02-07 20:12:22 --> Helper loaded: form_helper
ERROR - 2024-02-07 20:12:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:12:22 --> Config Class Initialized
INFO - 2024-02-07 20:12:22 --> Hooks Class Initialized
INFO - 2024-02-07 20:12:22 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:12:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:12:22 --> Utf8 Class Initialized
INFO - 2024-02-07 20:12:22 --> URI Class Initialized
INFO - 2024-02-07 20:12:22 --> Router Class Initialized
DEBUG - 2024-02-07 20:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:12:22 --> Controller Class Initialized
INFO - 2024-02-07 20:12:22 --> Output Class Initialized
INFO - 2024-02-07 20:12:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:12:22 --> Final output sent to browser
DEBUG - 2024-02-07 20:12:22 --> Total execution time: 0.0358
INFO - 2024-02-07 20:12:22 --> Security Class Initialized
DEBUG - 2024-02-07 20:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:12:22 --> Input Class Initialized
INFO - 2024-02-07 20:12:22 --> Language Class Initialized
INFO - 2024-02-07 20:12:22 --> Loader Class Initialized
INFO - 2024-02-07 20:12:22 --> Helper loaded: url_helper
INFO - 2024-02-07 20:12:22 --> Helper loaded: file_helper
INFO - 2024-02-07 20:12:22 --> Helper loaded: form_helper
INFO - 2024-02-07 20:12:22 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:12:22 --> Controller Class Initialized
INFO - 2024-02-07 20:12:22 --> Form Validation Class Initialized
INFO - 2024-02-07 20:12:22 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:12:22 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:12:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:12:31 --> Config Class Initialized
INFO - 2024-02-07 20:12:31 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:12:31 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:12:31 --> Utf8 Class Initialized
INFO - 2024-02-07 20:12:31 --> URI Class Initialized
INFO - 2024-02-07 20:12:31 --> Router Class Initialized
INFO - 2024-02-07 20:12:31 --> Output Class Initialized
INFO - 2024-02-07 20:12:31 --> Security Class Initialized
DEBUG - 2024-02-07 20:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:12:31 --> Input Class Initialized
INFO - 2024-02-07 20:12:31 --> Language Class Initialized
INFO - 2024-02-07 20:12:31 --> Loader Class Initialized
INFO - 2024-02-07 20:12:31 --> Helper loaded: url_helper
INFO - 2024-02-07 20:12:31 --> Helper loaded: file_helper
INFO - 2024-02-07 20:12:31 --> Helper loaded: form_helper
INFO - 2024-02-07 20:12:31 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:12:31 --> Controller Class Initialized
INFO - 2024-02-07 20:12:31 --> Form Validation Class Initialized
INFO - 2024-02-07 20:12:31 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:12:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:12:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:12:31 --> Final output sent to browser
DEBUG - 2024-02-07 20:12:31 --> Total execution time: 0.0275
ERROR - 2024-02-07 20:12:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:12:57 --> Config Class Initialized
INFO - 2024-02-07 20:12:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:12:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:12:57 --> Utf8 Class Initialized
INFO - 2024-02-07 20:12:57 --> URI Class Initialized
INFO - 2024-02-07 20:12:57 --> Router Class Initialized
INFO - 2024-02-07 20:12:57 --> Output Class Initialized
INFO - 2024-02-07 20:12:57 --> Security Class Initialized
DEBUG - 2024-02-07 20:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:12:57 --> Input Class Initialized
INFO - 2024-02-07 20:12:57 --> Language Class Initialized
INFO - 2024-02-07 20:12:57 --> Loader Class Initialized
INFO - 2024-02-07 20:12:57 --> Helper loaded: url_helper
INFO - 2024-02-07 20:12:57 --> Helper loaded: file_helper
INFO - 2024-02-07 20:12:57 --> Helper loaded: form_helper
INFO - 2024-02-07 20:12:57 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:12:57 --> Controller Class Initialized
INFO - 2024-02-07 20:12:57 --> Form Validation Class Initialized
INFO - 2024-02-07 20:12:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:12:57 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:12:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:12:57 --> Config Class Initialized
INFO - 2024-02-07 20:12:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:12:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:12:57 --> Utf8 Class Initialized
INFO - 2024-02-07 20:12:57 --> URI Class Initialized
INFO - 2024-02-07 20:12:57 --> Router Class Initialized
INFO - 2024-02-07 20:12:57 --> Output Class Initialized
INFO - 2024-02-07 20:12:57 --> Security Class Initialized
DEBUG - 2024-02-07 20:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:12:57 --> Input Class Initialized
INFO - 2024-02-07 20:12:57 --> Language Class Initialized
INFO - 2024-02-07 20:12:57 --> Loader Class Initialized
INFO - 2024-02-07 20:12:57 --> Helper loaded: url_helper
INFO - 2024-02-07 20:12:57 --> Helper loaded: file_helper
INFO - 2024-02-07 20:12:57 --> Helper loaded: form_helper
INFO - 2024-02-07 20:12:57 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:12:57 --> Controller Class Initialized
INFO - 2024-02-07 20:12:57 --> Form Validation Class Initialized
INFO - 2024-02-07 20:12:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:12:57 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:14:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:14:37 --> Config Class Initialized
INFO - 2024-02-07 20:14:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:14:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:14:37 --> Utf8 Class Initialized
INFO - 2024-02-07 20:14:37 --> URI Class Initialized
INFO - 2024-02-07 20:14:37 --> Router Class Initialized
INFO - 2024-02-07 20:14:37 --> Output Class Initialized
INFO - 2024-02-07 20:14:37 --> Security Class Initialized
DEBUG - 2024-02-07 20:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:14:37 --> Input Class Initialized
INFO - 2024-02-07 20:14:37 --> Language Class Initialized
INFO - 2024-02-07 20:14:37 --> Loader Class Initialized
INFO - 2024-02-07 20:14:37 --> Helper loaded: url_helper
INFO - 2024-02-07 20:14:37 --> Helper loaded: file_helper
INFO - 2024-02-07 20:14:37 --> Helper loaded: form_helper
INFO - 2024-02-07 20:14:37 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:14:37 --> Controller Class Initialized
INFO - 2024-02-07 20:14:37 --> Form Validation Class Initialized
INFO - 2024-02-07 20:14:37 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:14:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:14:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:14:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:14:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:14:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:14:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:14:37 --> Final output sent to browser
DEBUG - 2024-02-07 20:14:37 --> Total execution time: 0.0377
ERROR - 2024-02-07 20:14:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:14:37 --> Config Class Initialized
INFO - 2024-02-07 20:14:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:14:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:14:37 --> Utf8 Class Initialized
INFO - 2024-02-07 20:14:37 --> URI Class Initialized
INFO - 2024-02-07 20:14:37 --> Router Class Initialized
INFO - 2024-02-07 20:14:37 --> Output Class Initialized
INFO - 2024-02-07 20:14:37 --> Security Class Initialized
DEBUG - 2024-02-07 20:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:14:37 --> Input Class Initialized
INFO - 2024-02-07 20:14:37 --> Language Class Initialized
INFO - 2024-02-07 20:14:37 --> Loader Class Initialized
INFO - 2024-02-07 20:14:37 --> Helper loaded: url_helper
INFO - 2024-02-07 20:14:37 --> Helper loaded: file_helper
INFO - 2024-02-07 20:14:37 --> Helper loaded: form_helper
INFO - 2024-02-07 20:14:37 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:14:37 --> Controller Class Initialized
INFO - 2024-02-07 20:14:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:14:37 --> Final output sent to browser
DEBUG - 2024-02-07 20:14:37 --> Total execution time: 0.0412
ERROR - 2024-02-07 20:14:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:14:37 --> Config Class Initialized
INFO - 2024-02-07 20:14:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:14:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:14:37 --> Utf8 Class Initialized
INFO - 2024-02-07 20:14:37 --> URI Class Initialized
INFO - 2024-02-07 20:14:37 --> Router Class Initialized
INFO - 2024-02-07 20:14:37 --> Output Class Initialized
INFO - 2024-02-07 20:14:37 --> Security Class Initialized
DEBUG - 2024-02-07 20:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:14:37 --> Input Class Initialized
INFO - 2024-02-07 20:14:37 --> Language Class Initialized
INFO - 2024-02-07 20:14:37 --> Loader Class Initialized
INFO - 2024-02-07 20:14:37 --> Helper loaded: url_helper
INFO - 2024-02-07 20:14:37 --> Helper loaded: file_helper
INFO - 2024-02-07 20:14:37 --> Helper loaded: form_helper
INFO - 2024-02-07 20:14:37 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:14:38 --> Controller Class Initialized
INFO - 2024-02-07 20:14:38 --> Form Validation Class Initialized
INFO - 2024-02-07 20:14:38 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:14:38 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:14:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:14:43 --> Config Class Initialized
INFO - 2024-02-07 20:14:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:14:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:14:43 --> Utf8 Class Initialized
INFO - 2024-02-07 20:14:43 --> URI Class Initialized
INFO - 2024-02-07 20:14:43 --> Router Class Initialized
INFO - 2024-02-07 20:14:43 --> Output Class Initialized
INFO - 2024-02-07 20:14:43 --> Security Class Initialized
DEBUG - 2024-02-07 20:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:14:43 --> Input Class Initialized
INFO - 2024-02-07 20:14:43 --> Language Class Initialized
INFO - 2024-02-07 20:14:43 --> Loader Class Initialized
INFO - 2024-02-07 20:14:43 --> Helper loaded: url_helper
INFO - 2024-02-07 20:14:43 --> Helper loaded: file_helper
INFO - 2024-02-07 20:14:43 --> Helper loaded: form_helper
INFO - 2024-02-07 20:14:43 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:14:43 --> Controller Class Initialized
INFO - 2024-02-07 20:14:43 --> Form Validation Class Initialized
INFO - 2024-02-07 20:14:43 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:14:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:14:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:14:43 --> Final output sent to browser
DEBUG - 2024-02-07 20:14:43 --> Total execution time: 0.0339
ERROR - 2024-02-07 20:15:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:15:21 --> Config Class Initialized
INFO - 2024-02-07 20:15:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:15:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:15:21 --> Utf8 Class Initialized
INFO - 2024-02-07 20:15:21 --> URI Class Initialized
INFO - 2024-02-07 20:15:21 --> Router Class Initialized
INFO - 2024-02-07 20:15:21 --> Output Class Initialized
INFO - 2024-02-07 20:15:21 --> Security Class Initialized
DEBUG - 2024-02-07 20:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:15:21 --> Input Class Initialized
INFO - 2024-02-07 20:15:21 --> Language Class Initialized
INFO - 2024-02-07 20:15:21 --> Loader Class Initialized
INFO - 2024-02-07 20:15:21 --> Helper loaded: url_helper
INFO - 2024-02-07 20:15:21 --> Helper loaded: file_helper
INFO - 2024-02-07 20:15:21 --> Helper loaded: form_helper
INFO - 2024-02-07 20:15:21 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:15:21 --> Controller Class Initialized
INFO - 2024-02-07 20:15:21 --> Form Validation Class Initialized
INFO - 2024-02-07 20:15:21 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:15:21 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:15:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:15:21 --> Config Class Initialized
INFO - 2024-02-07 20:15:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:15:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:15:21 --> Utf8 Class Initialized
INFO - 2024-02-07 20:15:21 --> URI Class Initialized
INFO - 2024-02-07 20:15:21 --> Router Class Initialized
INFO - 2024-02-07 20:15:21 --> Output Class Initialized
INFO - 2024-02-07 20:15:21 --> Security Class Initialized
DEBUG - 2024-02-07 20:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:15:21 --> Input Class Initialized
INFO - 2024-02-07 20:15:21 --> Language Class Initialized
INFO - 2024-02-07 20:15:21 --> Loader Class Initialized
INFO - 2024-02-07 20:15:21 --> Helper loaded: url_helper
INFO - 2024-02-07 20:15:21 --> Helper loaded: file_helper
INFO - 2024-02-07 20:15:21 --> Helper loaded: form_helper
INFO - 2024-02-07 20:15:21 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:15:21 --> Controller Class Initialized
INFO - 2024-02-07 20:15:21 --> Form Validation Class Initialized
INFO - 2024-02-07 20:15:21 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:15:21 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:16:26 --> Config Class Initialized
INFO - 2024-02-07 20:16:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:16:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:16:26 --> Utf8 Class Initialized
INFO - 2024-02-07 20:16:26 --> URI Class Initialized
INFO - 2024-02-07 20:16:26 --> Router Class Initialized
INFO - 2024-02-07 20:16:26 --> Output Class Initialized
INFO - 2024-02-07 20:16:26 --> Security Class Initialized
DEBUG - 2024-02-07 20:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:16:26 --> Input Class Initialized
INFO - 2024-02-07 20:16:26 --> Language Class Initialized
INFO - 2024-02-07 20:16:26 --> Loader Class Initialized
INFO - 2024-02-07 20:16:26 --> Helper loaded: url_helper
INFO - 2024-02-07 20:16:26 --> Helper loaded: file_helper
INFO - 2024-02-07 20:16:26 --> Helper loaded: form_helper
INFO - 2024-02-07 20:16:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:16:26 --> Controller Class Initialized
INFO - 2024-02-07 20:16:26 --> Form Validation Class Initialized
INFO - 2024-02-07 20:16:26 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:16:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:16:26 --> Final output sent to browser
DEBUG - 2024-02-07 20:16:26 --> Total execution time: 0.0320
ERROR - 2024-02-07 20:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:16:26 --> Config Class Initialized
INFO - 2024-02-07 20:16:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:16:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:16:26 --> Utf8 Class Initialized
INFO - 2024-02-07 20:16:26 --> URI Class Initialized
INFO - 2024-02-07 20:16:26 --> Router Class Initialized
INFO - 2024-02-07 20:16:26 --> Output Class Initialized
INFO - 2024-02-07 20:16:26 --> Security Class Initialized
DEBUG - 2024-02-07 20:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:16:26 --> Input Class Initialized
INFO - 2024-02-07 20:16:26 --> Language Class Initialized
INFO - 2024-02-07 20:16:26 --> Loader Class Initialized
INFO - 2024-02-07 20:16:26 --> Helper loaded: url_helper
INFO - 2024-02-07 20:16:26 --> Helper loaded: file_helper
INFO - 2024-02-07 20:16:26 --> Helper loaded: form_helper
INFO - 2024-02-07 20:16:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:16:26 --> Controller Class Initialized
INFO - 2024-02-07 20:16:26 --> Form Validation Class Initialized
INFO - 2024-02-07 20:16:26 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:16:26 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:16:26 --> Config Class Initialized
INFO - 2024-02-07 20:16:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:16:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:16:26 --> Utf8 Class Initialized
INFO - 2024-02-07 20:16:26 --> URI Class Initialized
INFO - 2024-02-07 20:16:26 --> Router Class Initialized
INFO - 2024-02-07 20:16:26 --> Output Class Initialized
INFO - 2024-02-07 20:16:26 --> Security Class Initialized
DEBUG - 2024-02-07 20:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:16:26 --> Input Class Initialized
INFO - 2024-02-07 20:16:26 --> Language Class Initialized
INFO - 2024-02-07 20:16:26 --> Loader Class Initialized
INFO - 2024-02-07 20:16:26 --> Helper loaded: url_helper
INFO - 2024-02-07 20:16:26 --> Helper loaded: file_helper
INFO - 2024-02-07 20:16:26 --> Helper loaded: form_helper
INFO - 2024-02-07 20:16:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:16:26 --> Controller Class Initialized
INFO - 2024-02-07 20:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:16:26 --> Final output sent to browser
DEBUG - 2024-02-07 20:16:26 --> Total execution time: 0.0329
ERROR - 2024-02-07 20:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:16:31 --> Config Class Initialized
INFO - 2024-02-07 20:16:31 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:16:31 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:16:31 --> Utf8 Class Initialized
INFO - 2024-02-07 20:16:31 --> URI Class Initialized
INFO - 2024-02-07 20:16:31 --> Router Class Initialized
INFO - 2024-02-07 20:16:31 --> Output Class Initialized
INFO - 2024-02-07 20:16:31 --> Security Class Initialized
DEBUG - 2024-02-07 20:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:16:31 --> Input Class Initialized
INFO - 2024-02-07 20:16:31 --> Language Class Initialized
INFO - 2024-02-07 20:16:31 --> Loader Class Initialized
INFO - 2024-02-07 20:16:31 --> Helper loaded: url_helper
INFO - 2024-02-07 20:16:31 --> Helper loaded: file_helper
INFO - 2024-02-07 20:16:31 --> Helper loaded: form_helper
INFO - 2024-02-07 20:16:31 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:16:31 --> Controller Class Initialized
INFO - 2024-02-07 20:16:31 --> Form Validation Class Initialized
INFO - 2024-02-07 20:16:31 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:16:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:16:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:16:31 --> Final output sent to browser
DEBUG - 2024-02-07 20:16:31 --> Total execution time: 0.0372
ERROR - 2024-02-07 20:16:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:16:34 --> Config Class Initialized
INFO - 2024-02-07 20:16:34 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:16:34 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:16:34 --> Utf8 Class Initialized
INFO - 2024-02-07 20:16:34 --> URI Class Initialized
INFO - 2024-02-07 20:16:34 --> Router Class Initialized
INFO - 2024-02-07 20:16:34 --> Output Class Initialized
INFO - 2024-02-07 20:16:34 --> Security Class Initialized
DEBUG - 2024-02-07 20:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:16:34 --> Input Class Initialized
INFO - 2024-02-07 20:16:34 --> Language Class Initialized
INFO - 2024-02-07 20:16:34 --> Loader Class Initialized
INFO - 2024-02-07 20:16:34 --> Helper loaded: url_helper
INFO - 2024-02-07 20:16:34 --> Helper loaded: file_helper
INFO - 2024-02-07 20:16:34 --> Helper loaded: form_helper
INFO - 2024-02-07 20:16:34 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:16:34 --> Controller Class Initialized
INFO - 2024-02-07 20:16:34 --> Form Validation Class Initialized
INFO - 2024-02-07 20:16:34 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:16:34 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:17:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:17:16 --> Config Class Initialized
INFO - 2024-02-07 20:17:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:17:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:17:16 --> Utf8 Class Initialized
INFO - 2024-02-07 20:17:16 --> URI Class Initialized
INFO - 2024-02-07 20:17:16 --> Router Class Initialized
INFO - 2024-02-07 20:17:16 --> Output Class Initialized
INFO - 2024-02-07 20:17:16 --> Security Class Initialized
DEBUG - 2024-02-07 20:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:17:16 --> Input Class Initialized
INFO - 2024-02-07 20:17:16 --> Language Class Initialized
INFO - 2024-02-07 20:17:16 --> Loader Class Initialized
INFO - 2024-02-07 20:17:16 --> Helper loaded: url_helper
INFO - 2024-02-07 20:17:16 --> Helper loaded: file_helper
INFO - 2024-02-07 20:17:16 --> Helper loaded: form_helper
INFO - 2024-02-07 20:17:16 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:17:16 --> Controller Class Initialized
INFO - 2024-02-07 20:17:16 --> Form Validation Class Initialized
INFO - 2024-02-07 20:17:16 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:17:16 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:17:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:17:22 --> Config Class Initialized
INFO - 2024-02-07 20:17:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:17:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:17:22 --> Utf8 Class Initialized
INFO - 2024-02-07 20:17:22 --> URI Class Initialized
INFO - 2024-02-07 20:17:22 --> Router Class Initialized
INFO - 2024-02-07 20:17:22 --> Output Class Initialized
INFO - 2024-02-07 20:17:22 --> Security Class Initialized
DEBUG - 2024-02-07 20:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:17:22 --> Input Class Initialized
INFO - 2024-02-07 20:17:22 --> Language Class Initialized
INFO - 2024-02-07 20:17:22 --> Loader Class Initialized
INFO - 2024-02-07 20:17:22 --> Helper loaded: url_helper
INFO - 2024-02-07 20:17:22 --> Helper loaded: file_helper
INFO - 2024-02-07 20:17:22 --> Helper loaded: form_helper
INFO - 2024-02-07 20:17:22 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:17:22 --> Controller Class Initialized
INFO - 2024-02-07 20:17:22 --> Form Validation Class Initialized
INFO - 2024-02-07 20:17:22 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:17:22 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:17:25 --> Config Class Initialized
INFO - 2024-02-07 20:17:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:17:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:17:25 --> Utf8 Class Initialized
INFO - 2024-02-07 20:17:25 --> URI Class Initialized
INFO - 2024-02-07 20:17:25 --> Router Class Initialized
INFO - 2024-02-07 20:17:25 --> Output Class Initialized
INFO - 2024-02-07 20:17:25 --> Security Class Initialized
DEBUG - 2024-02-07 20:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:17:25 --> Input Class Initialized
INFO - 2024-02-07 20:17:25 --> Language Class Initialized
INFO - 2024-02-07 20:17:25 --> Loader Class Initialized
INFO - 2024-02-07 20:17:25 --> Helper loaded: url_helper
INFO - 2024-02-07 20:17:25 --> Helper loaded: file_helper
INFO - 2024-02-07 20:17:25 --> Helper loaded: form_helper
INFO - 2024-02-07 20:17:25 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:17:25 --> Controller Class Initialized
INFO - 2024-02-07 20:17:25 --> Form Validation Class Initialized
INFO - 2024-02-07 20:17:25 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:17:25 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:17:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:17:29 --> Config Class Initialized
INFO - 2024-02-07 20:17:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:17:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:17:29 --> Utf8 Class Initialized
INFO - 2024-02-07 20:17:29 --> URI Class Initialized
INFO - 2024-02-07 20:17:29 --> Router Class Initialized
INFO - 2024-02-07 20:17:29 --> Output Class Initialized
INFO - 2024-02-07 20:17:29 --> Security Class Initialized
DEBUG - 2024-02-07 20:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:17:29 --> Input Class Initialized
INFO - 2024-02-07 20:17:29 --> Language Class Initialized
INFO - 2024-02-07 20:17:29 --> Loader Class Initialized
INFO - 2024-02-07 20:17:29 --> Helper loaded: url_helper
INFO - 2024-02-07 20:17:29 --> Helper loaded: file_helper
INFO - 2024-02-07 20:17:29 --> Helper loaded: form_helper
INFO - 2024-02-07 20:17:29 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:17:29 --> Controller Class Initialized
INFO - 2024-02-07 20:17:29 --> Form Validation Class Initialized
INFO - 2024-02-07 20:17:29 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:17:29 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:18:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:18:29 --> Config Class Initialized
INFO - 2024-02-07 20:18:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:18:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:18:29 --> Utf8 Class Initialized
INFO - 2024-02-07 20:18:29 --> URI Class Initialized
INFO - 2024-02-07 20:18:29 --> Router Class Initialized
INFO - 2024-02-07 20:18:29 --> Output Class Initialized
INFO - 2024-02-07 20:18:29 --> Security Class Initialized
DEBUG - 2024-02-07 20:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:18:29 --> Input Class Initialized
INFO - 2024-02-07 20:18:29 --> Language Class Initialized
INFO - 2024-02-07 20:18:29 --> Loader Class Initialized
INFO - 2024-02-07 20:18:29 --> Helper loaded: url_helper
INFO - 2024-02-07 20:18:29 --> Helper loaded: file_helper
INFO - 2024-02-07 20:18:29 --> Helper loaded: form_helper
INFO - 2024-02-07 20:18:29 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:18:29 --> Controller Class Initialized
INFO - 2024-02-07 20:18:29 --> Form Validation Class Initialized
INFO - 2024-02-07 20:18:29 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:18:29 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:18:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:18:35 --> Config Class Initialized
INFO - 2024-02-07 20:18:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:18:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:18:35 --> Utf8 Class Initialized
INFO - 2024-02-07 20:18:35 --> URI Class Initialized
INFO - 2024-02-07 20:18:35 --> Router Class Initialized
INFO - 2024-02-07 20:18:35 --> Output Class Initialized
INFO - 2024-02-07 20:18:35 --> Security Class Initialized
DEBUG - 2024-02-07 20:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:18:35 --> Input Class Initialized
INFO - 2024-02-07 20:18:35 --> Language Class Initialized
INFO - 2024-02-07 20:18:35 --> Loader Class Initialized
INFO - 2024-02-07 20:18:35 --> Helper loaded: url_helper
INFO - 2024-02-07 20:18:35 --> Helper loaded: file_helper
INFO - 2024-02-07 20:18:35 --> Helper loaded: form_helper
INFO - 2024-02-07 20:18:35 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:18:35 --> Controller Class Initialized
INFO - 2024-02-07 20:18:35 --> Form Validation Class Initialized
INFO - 2024-02-07 20:18:35 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:18:35 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:20:23 --> Config Class Initialized
INFO - 2024-02-07 20:20:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:20:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:20:23 --> Utf8 Class Initialized
INFO - 2024-02-07 20:20:23 --> URI Class Initialized
INFO - 2024-02-07 20:20:23 --> Router Class Initialized
INFO - 2024-02-07 20:20:23 --> Output Class Initialized
INFO - 2024-02-07 20:20:23 --> Security Class Initialized
DEBUG - 2024-02-07 20:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:20:23 --> Input Class Initialized
INFO - 2024-02-07 20:20:23 --> Language Class Initialized
INFO - 2024-02-07 20:20:23 --> Loader Class Initialized
INFO - 2024-02-07 20:20:23 --> Helper loaded: url_helper
INFO - 2024-02-07 20:20:23 --> Helper loaded: file_helper
INFO - 2024-02-07 20:20:23 --> Helper loaded: form_helper
INFO - 2024-02-07 20:20:23 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:20:23 --> Controller Class Initialized
INFO - 2024-02-07 20:20:23 --> Form Validation Class Initialized
INFO - 2024-02-07 20:20:23 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:20:23 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:20:23 --> Config Class Initialized
INFO - 2024-02-07 20:20:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:20:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:20:23 --> Utf8 Class Initialized
INFO - 2024-02-07 20:20:23 --> URI Class Initialized
INFO - 2024-02-07 20:20:23 --> Router Class Initialized
INFO - 2024-02-07 20:20:23 --> Output Class Initialized
INFO - 2024-02-07 20:20:23 --> Security Class Initialized
DEBUG - 2024-02-07 20:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:20:23 --> Input Class Initialized
INFO - 2024-02-07 20:20:23 --> Language Class Initialized
INFO - 2024-02-07 20:20:23 --> Loader Class Initialized
INFO - 2024-02-07 20:20:23 --> Helper loaded: url_helper
INFO - 2024-02-07 20:20:23 --> Helper loaded: file_helper
INFO - 2024-02-07 20:20:23 --> Helper loaded: form_helper
INFO - 2024-02-07 20:20:23 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:20:23 --> Controller Class Initialized
INFO - 2024-02-07 20:20:23 --> Form Validation Class Initialized
INFO - 2024-02-07 20:20:23 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:20:23 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:20:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:20:24 --> Config Class Initialized
INFO - 2024-02-07 20:20:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:20:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:20:24 --> Utf8 Class Initialized
INFO - 2024-02-07 20:20:24 --> URI Class Initialized
INFO - 2024-02-07 20:20:24 --> Router Class Initialized
INFO - 2024-02-07 20:20:24 --> Output Class Initialized
INFO - 2024-02-07 20:20:24 --> Security Class Initialized
DEBUG - 2024-02-07 20:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:20:24 --> Input Class Initialized
INFO - 2024-02-07 20:20:24 --> Language Class Initialized
INFO - 2024-02-07 20:20:24 --> Loader Class Initialized
INFO - 2024-02-07 20:20:24 --> Helper loaded: url_helper
INFO - 2024-02-07 20:20:24 --> Helper loaded: file_helper
INFO - 2024-02-07 20:20:24 --> Helper loaded: form_helper
INFO - 2024-02-07 20:20:24 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:20:24 --> Controller Class Initialized
INFO - 2024-02-07 20:20:24 --> Form Validation Class Initialized
INFO - 2024-02-07 20:20:24 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:20:24 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:20:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:20:24 --> Config Class Initialized
INFO - 2024-02-07 20:20:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:20:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:20:24 --> Utf8 Class Initialized
INFO - 2024-02-07 20:20:24 --> URI Class Initialized
INFO - 2024-02-07 20:20:24 --> Router Class Initialized
INFO - 2024-02-07 20:20:24 --> Output Class Initialized
INFO - 2024-02-07 20:20:24 --> Security Class Initialized
DEBUG - 2024-02-07 20:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:20:24 --> Input Class Initialized
INFO - 2024-02-07 20:20:24 --> Language Class Initialized
INFO - 2024-02-07 20:20:24 --> Loader Class Initialized
INFO - 2024-02-07 20:20:24 --> Helper loaded: url_helper
INFO - 2024-02-07 20:20:24 --> Helper loaded: file_helper
INFO - 2024-02-07 20:20:24 --> Helper loaded: form_helper
INFO - 2024-02-07 20:20:24 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:20:24 --> Controller Class Initialized
INFO - 2024-02-07 20:20:24 --> Form Validation Class Initialized
INFO - 2024-02-07 20:20:24 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:20:24 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:20:42 --> Config Class Initialized
INFO - 2024-02-07 20:20:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:20:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:20:42 --> Utf8 Class Initialized
INFO - 2024-02-07 20:20:42 --> URI Class Initialized
INFO - 2024-02-07 20:20:42 --> Router Class Initialized
INFO - 2024-02-07 20:20:42 --> Output Class Initialized
INFO - 2024-02-07 20:20:42 --> Security Class Initialized
DEBUG - 2024-02-07 20:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:20:42 --> Input Class Initialized
INFO - 2024-02-07 20:20:42 --> Language Class Initialized
INFO - 2024-02-07 20:20:42 --> Loader Class Initialized
INFO - 2024-02-07 20:20:42 --> Helper loaded: url_helper
INFO - 2024-02-07 20:20:42 --> Helper loaded: file_helper
INFO - 2024-02-07 20:20:42 --> Helper loaded: form_helper
INFO - 2024-02-07 20:20:42 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:20:42 --> Controller Class Initialized
INFO - 2024-02-07 20:20:42 --> Form Validation Class Initialized
INFO - 2024-02-07 20:20:42 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:20:42 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:21:14 --> Config Class Initialized
INFO - 2024-02-07 20:21:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:21:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:21:14 --> Utf8 Class Initialized
INFO - 2024-02-07 20:21:14 --> URI Class Initialized
INFO - 2024-02-07 20:21:14 --> Router Class Initialized
INFO - 2024-02-07 20:21:14 --> Output Class Initialized
INFO - 2024-02-07 20:21:14 --> Security Class Initialized
DEBUG - 2024-02-07 20:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:21:14 --> Input Class Initialized
INFO - 2024-02-07 20:21:14 --> Language Class Initialized
INFO - 2024-02-07 20:21:14 --> Loader Class Initialized
INFO - 2024-02-07 20:21:14 --> Helper loaded: url_helper
INFO - 2024-02-07 20:21:14 --> Helper loaded: file_helper
INFO - 2024-02-07 20:21:14 --> Helper loaded: form_helper
INFO - 2024-02-07 20:21:14 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:21:14 --> Controller Class Initialized
INFO - 2024-02-07 20:21:14 --> Form Validation Class Initialized
INFO - 2024-02-07 20:21:14 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:21:14 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:21:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:21:34 --> Config Class Initialized
INFO - 2024-02-07 20:21:34 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:21:34 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:21:34 --> Utf8 Class Initialized
INFO - 2024-02-07 20:21:34 --> URI Class Initialized
INFO - 2024-02-07 20:21:34 --> Router Class Initialized
INFO - 2024-02-07 20:21:34 --> Output Class Initialized
INFO - 2024-02-07 20:21:34 --> Security Class Initialized
DEBUG - 2024-02-07 20:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:21:34 --> Input Class Initialized
INFO - 2024-02-07 20:21:34 --> Language Class Initialized
INFO - 2024-02-07 20:21:34 --> Loader Class Initialized
INFO - 2024-02-07 20:21:34 --> Helper loaded: url_helper
INFO - 2024-02-07 20:21:34 --> Helper loaded: file_helper
INFO - 2024-02-07 20:21:34 --> Helper loaded: form_helper
INFO - 2024-02-07 20:21:34 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:21:34 --> Controller Class Initialized
INFO - 2024-02-07 20:21:34 --> Form Validation Class Initialized
INFO - 2024-02-07 20:21:34 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:21:34 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:21:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:21:34 --> Config Class Initialized
INFO - 2024-02-07 20:21:34 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:21:34 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:21:34 --> Utf8 Class Initialized
INFO - 2024-02-07 20:21:34 --> URI Class Initialized
INFO - 2024-02-07 20:21:34 --> Router Class Initialized
INFO - 2024-02-07 20:21:34 --> Output Class Initialized
INFO - 2024-02-07 20:21:34 --> Security Class Initialized
DEBUG - 2024-02-07 20:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:21:34 --> Input Class Initialized
INFO - 2024-02-07 20:21:34 --> Language Class Initialized
INFO - 2024-02-07 20:21:34 --> Loader Class Initialized
INFO - 2024-02-07 20:21:34 --> Helper loaded: url_helper
INFO - 2024-02-07 20:21:34 --> Helper loaded: file_helper
INFO - 2024-02-07 20:21:34 --> Helper loaded: form_helper
INFO - 2024-02-07 20:21:34 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:21:34 --> Controller Class Initialized
INFO - 2024-02-07 20:21:34 --> Form Validation Class Initialized
INFO - 2024-02-07 20:21:34 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:21:34 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:21:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:21:44 --> Config Class Initialized
INFO - 2024-02-07 20:21:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:21:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:21:44 --> Utf8 Class Initialized
INFO - 2024-02-07 20:21:44 --> URI Class Initialized
INFO - 2024-02-07 20:21:44 --> Router Class Initialized
INFO - 2024-02-07 20:21:44 --> Output Class Initialized
INFO - 2024-02-07 20:21:44 --> Security Class Initialized
DEBUG - 2024-02-07 20:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:21:44 --> Input Class Initialized
INFO - 2024-02-07 20:21:44 --> Language Class Initialized
INFO - 2024-02-07 20:21:44 --> Loader Class Initialized
INFO - 2024-02-07 20:21:44 --> Helper loaded: url_helper
INFO - 2024-02-07 20:21:44 --> Helper loaded: file_helper
INFO - 2024-02-07 20:21:44 --> Helper loaded: form_helper
INFO - 2024-02-07 20:21:44 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:21:44 --> Controller Class Initialized
INFO - 2024-02-07 20:21:44 --> Form Validation Class Initialized
INFO - 2024-02-07 20:21:44 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:21:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:21:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:21:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:21:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:21:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:21:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:21:44 --> Final output sent to browser
DEBUG - 2024-02-07 20:21:44 --> Total execution time: 0.0301
ERROR - 2024-02-07 20:21:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:21:44 --> Config Class Initialized
INFO - 2024-02-07 20:21:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:21:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:21:44 --> Utf8 Class Initialized
INFO - 2024-02-07 20:21:44 --> URI Class Initialized
INFO - 2024-02-07 20:21:44 --> Router Class Initialized
INFO - 2024-02-07 20:21:44 --> Output Class Initialized
INFO - 2024-02-07 20:21:44 --> Security Class Initialized
DEBUG - 2024-02-07 20:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:21:44 --> Input Class Initialized
INFO - 2024-02-07 20:21:44 --> Language Class Initialized
INFO - 2024-02-07 20:21:44 --> Loader Class Initialized
INFO - 2024-02-07 20:21:44 --> Helper loaded: url_helper
INFO - 2024-02-07 20:21:44 --> Helper loaded: file_helper
INFO - 2024-02-07 20:21:44 --> Helper loaded: form_helper
INFO - 2024-02-07 20:21:44 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:21:44 --> Controller Class Initialized
ERROR - 2024-02-07 20:21:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:21:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:21:44 --> Final output sent to browser
DEBUG - 2024-02-07 20:21:44 --> Total execution time: 0.0301
INFO - 2024-02-07 20:21:44 --> Config Class Initialized
INFO - 2024-02-07 20:21:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:21:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:21:44 --> Utf8 Class Initialized
INFO - 2024-02-07 20:21:44 --> URI Class Initialized
INFO - 2024-02-07 20:21:44 --> Router Class Initialized
INFO - 2024-02-07 20:21:44 --> Output Class Initialized
INFO - 2024-02-07 20:21:44 --> Security Class Initialized
DEBUG - 2024-02-07 20:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:21:44 --> Input Class Initialized
INFO - 2024-02-07 20:21:44 --> Language Class Initialized
INFO - 2024-02-07 20:21:44 --> Loader Class Initialized
INFO - 2024-02-07 20:21:44 --> Helper loaded: url_helper
INFO - 2024-02-07 20:21:44 --> Helper loaded: file_helper
INFO - 2024-02-07 20:21:44 --> Helper loaded: form_helper
INFO - 2024-02-07 20:21:44 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:21:44 --> Controller Class Initialized
INFO - 2024-02-07 20:21:44 --> Form Validation Class Initialized
INFO - 2024-02-07 20:21:44 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:21:44 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:22:17 --> Config Class Initialized
INFO - 2024-02-07 20:22:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:22:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:22:17 --> Utf8 Class Initialized
INFO - 2024-02-07 20:22:17 --> URI Class Initialized
INFO - 2024-02-07 20:22:17 --> Router Class Initialized
INFO - 2024-02-07 20:22:17 --> Output Class Initialized
INFO - 2024-02-07 20:22:17 --> Security Class Initialized
DEBUG - 2024-02-07 20:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:22:17 --> Input Class Initialized
INFO - 2024-02-07 20:22:17 --> Language Class Initialized
INFO - 2024-02-07 20:22:17 --> Loader Class Initialized
INFO - 2024-02-07 20:22:17 --> Helper loaded: url_helper
INFO - 2024-02-07 20:22:17 --> Helper loaded: file_helper
INFO - 2024-02-07 20:22:17 --> Helper loaded: form_helper
INFO - 2024-02-07 20:22:17 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:22:17 --> Controller Class Initialized
INFO - 2024-02-07 20:22:17 --> Form Validation Class Initialized
INFO - 2024-02-07 20:22:17 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:22:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:22:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:22:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:22:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:22:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:22:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:22:17 --> Final output sent to browser
DEBUG - 2024-02-07 20:22:17 --> Total execution time: 0.0292
ERROR - 2024-02-07 20:22:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-07 20:22:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:22:18 --> Config Class Initialized
INFO - 2024-02-07 20:22:18 --> Hooks Class Initialized
INFO - 2024-02-07 20:22:18 --> Config Class Initialized
INFO - 2024-02-07 20:22:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:22:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:22:18 --> Utf8 Class Initialized
DEBUG - 2024-02-07 20:22:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:22:18 --> Utf8 Class Initialized
INFO - 2024-02-07 20:22:18 --> URI Class Initialized
INFO - 2024-02-07 20:22:18 --> URI Class Initialized
INFO - 2024-02-07 20:22:18 --> Router Class Initialized
INFO - 2024-02-07 20:22:18 --> Router Class Initialized
INFO - 2024-02-07 20:22:18 --> Output Class Initialized
INFO - 2024-02-07 20:22:18 --> Output Class Initialized
INFO - 2024-02-07 20:22:18 --> Security Class Initialized
INFO - 2024-02-07 20:22:18 --> Security Class Initialized
DEBUG - 2024-02-07 20:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:22:18 --> Input Class Initialized
DEBUG - 2024-02-07 20:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:22:18 --> Input Class Initialized
INFO - 2024-02-07 20:22:18 --> Language Class Initialized
INFO - 2024-02-07 20:22:18 --> Language Class Initialized
INFO - 2024-02-07 20:22:18 --> Loader Class Initialized
INFO - 2024-02-07 20:22:18 --> Loader Class Initialized
INFO - 2024-02-07 20:22:18 --> Helper loaded: url_helper
INFO - 2024-02-07 20:22:18 --> Helper loaded: url_helper
INFO - 2024-02-07 20:22:18 --> Helper loaded: file_helper
INFO - 2024-02-07 20:22:18 --> Helper loaded: file_helper
INFO - 2024-02-07 20:22:18 --> Helper loaded: form_helper
INFO - 2024-02-07 20:22:18 --> Helper loaded: form_helper
INFO - 2024-02-07 20:22:18 --> Database Driver Class Initialized
INFO - 2024-02-07 20:22:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:22:18 --> Controller Class Initialized
INFO - 2024-02-07 20:22:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:22:18 --> Final output sent to browser
DEBUG - 2024-02-07 20:22:18 --> Total execution time: 0.0249
DEBUG - 2024-02-07 20:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:22:18 --> Controller Class Initialized
INFO - 2024-02-07 20:22:18 --> Form Validation Class Initialized
INFO - 2024-02-07 20:22:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:22:18 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:23:09 --> Config Class Initialized
INFO - 2024-02-07 20:23:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:23:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:23:09 --> Utf8 Class Initialized
INFO - 2024-02-07 20:23:09 --> URI Class Initialized
INFO - 2024-02-07 20:23:09 --> Router Class Initialized
INFO - 2024-02-07 20:23:09 --> Output Class Initialized
INFO - 2024-02-07 20:23:09 --> Security Class Initialized
DEBUG - 2024-02-07 20:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:23:09 --> Input Class Initialized
INFO - 2024-02-07 20:23:09 --> Language Class Initialized
INFO - 2024-02-07 20:23:09 --> Loader Class Initialized
INFO - 2024-02-07 20:23:09 --> Helper loaded: url_helper
INFO - 2024-02-07 20:23:09 --> Helper loaded: file_helper
INFO - 2024-02-07 20:23:09 --> Helper loaded: form_helper
INFO - 2024-02-07 20:23:09 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:23:09 --> Controller Class Initialized
INFO - 2024-02-07 20:23:09 --> Form Validation Class Initialized
INFO - 2024-02-07 20:23:09 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:23:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:23:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:23:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:23:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:23:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:23:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:23:09 --> Final output sent to browser
DEBUG - 2024-02-07 20:23:09 --> Total execution time: 0.0262
ERROR - 2024-02-07 20:23:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:23:10 --> Config Class Initialized
INFO - 2024-02-07 20:23:10 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:23:10 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:23:10 --> Utf8 Class Initialized
INFO - 2024-02-07 20:23:10 --> URI Class Initialized
INFO - 2024-02-07 20:23:10 --> Router Class Initialized
INFO - 2024-02-07 20:23:10 --> Output Class Initialized
INFO - 2024-02-07 20:23:10 --> Security Class Initialized
DEBUG - 2024-02-07 20:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:23:10 --> Input Class Initialized
INFO - 2024-02-07 20:23:10 --> Language Class Initialized
INFO - 2024-02-07 20:23:10 --> Loader Class Initialized
INFO - 2024-02-07 20:23:10 --> Helper loaded: url_helper
INFO - 2024-02-07 20:23:10 --> Helper loaded: file_helper
INFO - 2024-02-07 20:23:10 --> Helper loaded: form_helper
INFO - 2024-02-07 20:23:10 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:23:10 --> Controller Class Initialized
INFO - 2024-02-07 20:23:10 --> Form Validation Class Initialized
INFO - 2024-02-07 20:23:10 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:23:10 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:23:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:23:10 --> Config Class Initialized
INFO - 2024-02-07 20:23:10 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:23:10 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:23:10 --> Utf8 Class Initialized
INFO - 2024-02-07 20:23:10 --> URI Class Initialized
INFO - 2024-02-07 20:23:10 --> Router Class Initialized
INFO - 2024-02-07 20:23:10 --> Output Class Initialized
INFO - 2024-02-07 20:23:10 --> Security Class Initialized
DEBUG - 2024-02-07 20:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:23:10 --> Input Class Initialized
INFO - 2024-02-07 20:23:10 --> Language Class Initialized
INFO - 2024-02-07 20:23:10 --> Loader Class Initialized
INFO - 2024-02-07 20:23:10 --> Helper loaded: url_helper
INFO - 2024-02-07 20:23:10 --> Helper loaded: file_helper
INFO - 2024-02-07 20:23:10 --> Helper loaded: form_helper
INFO - 2024-02-07 20:23:10 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:23:10 --> Controller Class Initialized
INFO - 2024-02-07 20:23:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:23:10 --> Final output sent to browser
DEBUG - 2024-02-07 20:23:10 --> Total execution time: 0.0323
ERROR - 2024-02-07 20:23:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:23:16 --> Config Class Initialized
INFO - 2024-02-07 20:23:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:23:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:23:16 --> Utf8 Class Initialized
INFO - 2024-02-07 20:23:16 --> URI Class Initialized
INFO - 2024-02-07 20:23:16 --> Router Class Initialized
INFO - 2024-02-07 20:23:16 --> Output Class Initialized
INFO - 2024-02-07 20:23:16 --> Security Class Initialized
DEBUG - 2024-02-07 20:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:23:16 --> Input Class Initialized
INFO - 2024-02-07 20:23:16 --> Language Class Initialized
INFO - 2024-02-07 20:23:16 --> Loader Class Initialized
INFO - 2024-02-07 20:23:16 --> Helper loaded: url_helper
INFO - 2024-02-07 20:23:16 --> Helper loaded: file_helper
INFO - 2024-02-07 20:23:16 --> Helper loaded: form_helper
INFO - 2024-02-07 20:23:16 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:23:16 --> Controller Class Initialized
INFO - 2024-02-07 20:23:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:23:16 --> Final output sent to browser
DEBUG - 2024-02-07 20:23:16 --> Total execution time: 0.0269
ERROR - 2024-02-07 20:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:24:32 --> Config Class Initialized
INFO - 2024-02-07 20:24:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:24:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:24:32 --> Utf8 Class Initialized
INFO - 2024-02-07 20:24:32 --> URI Class Initialized
INFO - 2024-02-07 20:24:32 --> Router Class Initialized
INFO - 2024-02-07 20:24:32 --> Output Class Initialized
INFO - 2024-02-07 20:24:32 --> Security Class Initialized
DEBUG - 2024-02-07 20:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:24:32 --> Input Class Initialized
INFO - 2024-02-07 20:24:32 --> Language Class Initialized
INFO - 2024-02-07 20:24:32 --> Loader Class Initialized
INFO - 2024-02-07 20:24:32 --> Helper loaded: url_helper
INFO - 2024-02-07 20:24:32 --> Helper loaded: file_helper
INFO - 2024-02-07 20:24:32 --> Helper loaded: form_helper
INFO - 2024-02-07 20:24:32 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:24:32 --> Controller Class Initialized
INFO - 2024-02-07 20:24:32 --> Form Validation Class Initialized
INFO - 2024-02-07 20:24:32 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:24:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:24:32 --> Final output sent to browser
DEBUG - 2024-02-07 20:24:32 --> Total execution time: 0.0282
ERROR - 2024-02-07 20:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:24:32 --> Config Class Initialized
INFO - 2024-02-07 20:24:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:24:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:24:32 --> Utf8 Class Initialized
INFO - 2024-02-07 20:24:32 --> URI Class Initialized
INFO - 2024-02-07 20:24:32 --> Router Class Initialized
INFO - 2024-02-07 20:24:32 --> Output Class Initialized
INFO - 2024-02-07 20:24:32 --> Security Class Initialized
DEBUG - 2024-02-07 20:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:24:32 --> Input Class Initialized
INFO - 2024-02-07 20:24:32 --> Language Class Initialized
INFO - 2024-02-07 20:24:32 --> Loader Class Initialized
INFO - 2024-02-07 20:24:32 --> Helper loaded: url_helper
INFO - 2024-02-07 20:24:32 --> Helper loaded: file_helper
INFO - 2024-02-07 20:24:32 --> Helper loaded: form_helper
INFO - 2024-02-07 20:24:32 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:24:32 --> Controller Class Initialized
INFO - 2024-02-07 20:24:32 --> Form Validation Class Initialized
INFO - 2024-02-07 20:24:32 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:24:32 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:24:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:24:33 --> Config Class Initialized
INFO - 2024-02-07 20:24:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:24:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:24:33 --> Utf8 Class Initialized
INFO - 2024-02-07 20:24:33 --> URI Class Initialized
INFO - 2024-02-07 20:24:33 --> Router Class Initialized
INFO - 2024-02-07 20:24:33 --> Output Class Initialized
INFO - 2024-02-07 20:24:33 --> Security Class Initialized
DEBUG - 2024-02-07 20:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:24:33 --> Input Class Initialized
INFO - 2024-02-07 20:24:33 --> Language Class Initialized
INFO - 2024-02-07 20:24:33 --> Loader Class Initialized
INFO - 2024-02-07 20:24:33 --> Helper loaded: url_helper
INFO - 2024-02-07 20:24:33 --> Helper loaded: file_helper
INFO - 2024-02-07 20:24:33 --> Helper loaded: form_helper
INFO - 2024-02-07 20:24:33 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:24:33 --> Controller Class Initialized
INFO - 2024-02-07 20:24:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:24:33 --> Final output sent to browser
DEBUG - 2024-02-07 20:24:33 --> Total execution time: 0.0319
ERROR - 2024-02-07 20:24:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:24:38 --> Config Class Initialized
INFO - 2024-02-07 20:24:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:24:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:24:38 --> Utf8 Class Initialized
INFO - 2024-02-07 20:24:38 --> URI Class Initialized
INFO - 2024-02-07 20:24:38 --> Router Class Initialized
INFO - 2024-02-07 20:24:38 --> Output Class Initialized
INFO - 2024-02-07 20:24:38 --> Security Class Initialized
DEBUG - 2024-02-07 20:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:24:38 --> Input Class Initialized
INFO - 2024-02-07 20:24:38 --> Language Class Initialized
INFO - 2024-02-07 20:24:38 --> Loader Class Initialized
INFO - 2024-02-07 20:24:38 --> Helper loaded: url_helper
INFO - 2024-02-07 20:24:38 --> Helper loaded: file_helper
INFO - 2024-02-07 20:24:38 --> Helper loaded: form_helper
INFO - 2024-02-07 20:24:38 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:24:38 --> Controller Class Initialized
INFO - 2024-02-07 20:24:38 --> Form Validation Class Initialized
INFO - 2024-02-07 20:24:38 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:24:38 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:24:38 --> Severity: Notice --> Undefined property: UserMaster::$userMastre D:\xampp\htdocs\sscy\application\controllers\app\UserMaster.php 59
ERROR - 2024-02-07 20:24:38 --> Severity: error --> Exception: Call to a member function getUser() on null D:\xampp\htdocs\sscy\application\controllers\app\UserMaster.php 59
ERROR - 2024-02-07 20:25:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:25:08 --> Config Class Initialized
INFO - 2024-02-07 20:25:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:25:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:25:08 --> Utf8 Class Initialized
INFO - 2024-02-07 20:25:08 --> URI Class Initialized
INFO - 2024-02-07 20:25:08 --> Router Class Initialized
INFO - 2024-02-07 20:25:08 --> Output Class Initialized
INFO - 2024-02-07 20:25:08 --> Security Class Initialized
DEBUG - 2024-02-07 20:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:25:08 --> Input Class Initialized
INFO - 2024-02-07 20:25:08 --> Language Class Initialized
INFO - 2024-02-07 20:25:08 --> Loader Class Initialized
INFO - 2024-02-07 20:25:08 --> Helper loaded: url_helper
INFO - 2024-02-07 20:25:08 --> Helper loaded: file_helper
INFO - 2024-02-07 20:25:08 --> Helper loaded: form_helper
INFO - 2024-02-07 20:25:08 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:25:08 --> Controller Class Initialized
INFO - 2024-02-07 20:25:08 --> Form Validation Class Initialized
INFO - 2024-02-07 20:25:08 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:25:08 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:25:08 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\sscy\application\models\UserMasterModel.php 68
INFO - 2024-02-07 20:25:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:25:08 --> Final output sent to browser
DEBUG - 2024-02-07 20:25:08 --> Total execution time: 0.0327
ERROR - 2024-02-07 20:25:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:25:21 --> Config Class Initialized
INFO - 2024-02-07 20:25:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:25:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:25:21 --> Utf8 Class Initialized
INFO - 2024-02-07 20:25:21 --> URI Class Initialized
INFO - 2024-02-07 20:25:21 --> Router Class Initialized
INFO - 2024-02-07 20:25:21 --> Output Class Initialized
INFO - 2024-02-07 20:25:21 --> Security Class Initialized
DEBUG - 2024-02-07 20:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:25:21 --> Input Class Initialized
INFO - 2024-02-07 20:25:21 --> Language Class Initialized
INFO - 2024-02-07 20:25:21 --> Loader Class Initialized
INFO - 2024-02-07 20:25:21 --> Helper loaded: url_helper
INFO - 2024-02-07 20:25:21 --> Helper loaded: file_helper
INFO - 2024-02-07 20:25:21 --> Helper loaded: form_helper
INFO - 2024-02-07 20:25:21 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:25:21 --> Controller Class Initialized
INFO - 2024-02-07 20:25:21 --> Form Validation Class Initialized
INFO - 2024-02-07 20:25:21 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:25:21 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:25:21 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\sscy\application\models\UserMasterModel.php 68
INFO - 2024-02-07 20:25:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:25:21 --> Final output sent to browser
DEBUG - 2024-02-07 20:25:21 --> Total execution time: 0.0336
ERROR - 2024-02-07 20:26:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:26:48 --> Config Class Initialized
INFO - 2024-02-07 20:26:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:26:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:26:48 --> Utf8 Class Initialized
INFO - 2024-02-07 20:26:48 --> URI Class Initialized
INFO - 2024-02-07 20:26:48 --> Router Class Initialized
INFO - 2024-02-07 20:26:48 --> Output Class Initialized
INFO - 2024-02-07 20:26:48 --> Security Class Initialized
DEBUG - 2024-02-07 20:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:26:48 --> Input Class Initialized
INFO - 2024-02-07 20:26:48 --> Language Class Initialized
INFO - 2024-02-07 20:26:48 --> Loader Class Initialized
INFO - 2024-02-07 20:26:48 --> Helper loaded: url_helper
INFO - 2024-02-07 20:26:48 --> Helper loaded: file_helper
INFO - 2024-02-07 20:26:48 --> Helper loaded: form_helper
INFO - 2024-02-07 20:26:48 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:26:48 --> Controller Class Initialized
INFO - 2024-02-07 20:26:48 --> Form Validation Class Initialized
INFO - 2024-02-07 20:26:48 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:26:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:26:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:26:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:26:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:26:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:26:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:26:48 --> Final output sent to browser
DEBUG - 2024-02-07 20:26:48 --> Total execution time: 0.0485
ERROR - 2024-02-07 20:26:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:26:48 --> Config Class Initialized
INFO - 2024-02-07 20:26:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:26:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:26:48 --> Utf8 Class Initialized
INFO - 2024-02-07 20:26:48 --> URI Class Initialized
INFO - 2024-02-07 20:26:48 --> Router Class Initialized
INFO - 2024-02-07 20:26:48 --> Output Class Initialized
INFO - 2024-02-07 20:26:48 --> Security Class Initialized
DEBUG - 2024-02-07 20:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:26:48 --> Input Class Initialized
INFO - 2024-02-07 20:26:48 --> Language Class Initialized
INFO - 2024-02-07 20:26:48 --> Loader Class Initialized
INFO - 2024-02-07 20:26:48 --> Helper loaded: url_helper
INFO - 2024-02-07 20:26:48 --> Helper loaded: file_helper
INFO - 2024-02-07 20:26:48 --> Helper loaded: form_helper
INFO - 2024-02-07 20:26:48 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:26:48 --> Controller Class Initialized
INFO - 2024-02-07 20:26:48 --> Form Validation Class Initialized
INFO - 2024-02-07 20:26:48 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:26:48 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:26:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:26:48 --> Config Class Initialized
INFO - 2024-02-07 20:26:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:26:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:26:48 --> Utf8 Class Initialized
INFO - 2024-02-07 20:26:48 --> URI Class Initialized
INFO - 2024-02-07 20:26:48 --> Router Class Initialized
INFO - 2024-02-07 20:26:48 --> Output Class Initialized
INFO - 2024-02-07 20:26:48 --> Security Class Initialized
DEBUG - 2024-02-07 20:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:26:48 --> Input Class Initialized
INFO - 2024-02-07 20:26:48 --> Language Class Initialized
INFO - 2024-02-07 20:26:48 --> Loader Class Initialized
INFO - 2024-02-07 20:26:48 --> Helper loaded: url_helper
INFO - 2024-02-07 20:26:48 --> Helper loaded: file_helper
INFO - 2024-02-07 20:26:48 --> Helper loaded: form_helper
INFO - 2024-02-07 20:26:48 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:26:48 --> Controller Class Initialized
INFO - 2024-02-07 20:26:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:26:48 --> Final output sent to browser
DEBUG - 2024-02-07 20:26:48 --> Total execution time: 0.0250
ERROR - 2024-02-07 20:26:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:26:54 --> Config Class Initialized
INFO - 2024-02-07 20:26:54 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:26:54 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:26:54 --> Utf8 Class Initialized
INFO - 2024-02-07 20:26:54 --> URI Class Initialized
INFO - 2024-02-07 20:26:54 --> Router Class Initialized
INFO - 2024-02-07 20:26:54 --> Output Class Initialized
INFO - 2024-02-07 20:26:54 --> Security Class Initialized
DEBUG - 2024-02-07 20:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:26:54 --> Input Class Initialized
INFO - 2024-02-07 20:26:54 --> Language Class Initialized
INFO - 2024-02-07 20:26:54 --> Loader Class Initialized
INFO - 2024-02-07 20:26:54 --> Helper loaded: url_helper
INFO - 2024-02-07 20:26:54 --> Helper loaded: file_helper
INFO - 2024-02-07 20:26:54 --> Helper loaded: form_helper
INFO - 2024-02-07 20:26:54 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:26:54 --> Controller Class Initialized
INFO - 2024-02-07 20:26:54 --> Form Validation Class Initialized
INFO - 2024-02-07 20:26:54 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:26:54 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:26:54 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\sscy\application\models\UserMasterModel.php 68
INFO - 2024-02-07 20:26:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:26:54 --> Final output sent to browser
DEBUG - 2024-02-07 20:26:54 --> Total execution time: 0.0390
ERROR - 2024-02-07 20:28:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:28:13 --> Config Class Initialized
INFO - 2024-02-07 20:28:13 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:28:13 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:28:13 --> Utf8 Class Initialized
INFO - 2024-02-07 20:28:13 --> URI Class Initialized
INFO - 2024-02-07 20:28:13 --> Router Class Initialized
INFO - 2024-02-07 20:28:13 --> Output Class Initialized
INFO - 2024-02-07 20:28:13 --> Security Class Initialized
DEBUG - 2024-02-07 20:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:28:13 --> Input Class Initialized
INFO - 2024-02-07 20:28:13 --> Language Class Initialized
INFO - 2024-02-07 20:28:13 --> Loader Class Initialized
INFO - 2024-02-07 20:28:13 --> Helper loaded: url_helper
INFO - 2024-02-07 20:28:13 --> Helper loaded: file_helper
INFO - 2024-02-07 20:28:13 --> Helper loaded: form_helper
INFO - 2024-02-07 20:28:13 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:28:13 --> Controller Class Initialized
INFO - 2024-02-07 20:28:13 --> Form Validation Class Initialized
INFO - 2024-02-07 20:28:13 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:28:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:28:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:28:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:28:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:28:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:28:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:28:13 --> Final output sent to browser
DEBUG - 2024-02-07 20:28:13 --> Total execution time: 0.0270
ERROR - 2024-02-07 20:28:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:28:14 --> Config Class Initialized
INFO - 2024-02-07 20:28:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:28:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:28:14 --> Utf8 Class Initialized
INFO - 2024-02-07 20:28:14 --> URI Class Initialized
INFO - 2024-02-07 20:28:14 --> Router Class Initialized
INFO - 2024-02-07 20:28:14 --> Output Class Initialized
INFO - 2024-02-07 20:28:14 --> Security Class Initialized
DEBUG - 2024-02-07 20:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:28:14 --> Input Class Initialized
INFO - 2024-02-07 20:28:14 --> Language Class Initialized
INFO - 2024-02-07 20:28:14 --> Loader Class Initialized
INFO - 2024-02-07 20:28:14 --> Helper loaded: url_helper
INFO - 2024-02-07 20:28:14 --> Helper loaded: file_helper
INFO - 2024-02-07 20:28:14 --> Helper loaded: form_helper
INFO - 2024-02-07 20:28:14 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:28:14 --> Controller Class Initialized
INFO - 2024-02-07 20:28:14 --> Form Validation Class Initialized
INFO - 2024-02-07 20:28:14 --> Model "MasterModel" initialized
ERROR - 2024-02-07 20:28:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:28:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:28:14 --> Config Class Initialized
INFO - 2024-02-07 20:28:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:28:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:28:14 --> Utf8 Class Initialized
INFO - 2024-02-07 20:28:14 --> URI Class Initialized
INFO - 2024-02-07 20:28:14 --> Router Class Initialized
INFO - 2024-02-07 20:28:14 --> Output Class Initialized
INFO - 2024-02-07 20:28:14 --> Security Class Initialized
DEBUG - 2024-02-07 20:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:28:14 --> Input Class Initialized
INFO - 2024-02-07 20:28:14 --> Language Class Initialized
INFO - 2024-02-07 20:28:14 --> Loader Class Initialized
INFO - 2024-02-07 20:28:14 --> Helper loaded: url_helper
INFO - 2024-02-07 20:28:14 --> Helper loaded: file_helper
INFO - 2024-02-07 20:28:14 --> Helper loaded: form_helper
INFO - 2024-02-07 20:28:14 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:28:14 --> Controller Class Initialized
INFO - 2024-02-07 20:28:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:28:14 --> Final output sent to browser
DEBUG - 2024-02-07 20:28:14 --> Total execution time: 0.0228
ERROR - 2024-02-07 20:28:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:28:20 --> Config Class Initialized
INFO - 2024-02-07 20:28:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:28:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:28:20 --> Utf8 Class Initialized
INFO - 2024-02-07 20:28:20 --> URI Class Initialized
INFO - 2024-02-07 20:28:20 --> Router Class Initialized
INFO - 2024-02-07 20:28:20 --> Output Class Initialized
INFO - 2024-02-07 20:28:20 --> Security Class Initialized
DEBUG - 2024-02-07 20:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:28:20 --> Input Class Initialized
INFO - 2024-02-07 20:28:20 --> Language Class Initialized
INFO - 2024-02-07 20:28:20 --> Loader Class Initialized
INFO - 2024-02-07 20:28:20 --> Helper loaded: url_helper
INFO - 2024-02-07 20:28:20 --> Helper loaded: file_helper
INFO - 2024-02-07 20:28:20 --> Helper loaded: form_helper
INFO - 2024-02-07 20:28:20 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:28:20 --> Controller Class Initialized
INFO - 2024-02-07 20:28:20 --> Form Validation Class Initialized
INFO - 2024-02-07 20:28:20 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:28:20 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:28:20 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\sscy\application\models\UserMasterModel.php 68
INFO - 2024-02-07 20:28:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:28:20 --> Final output sent to browser
DEBUG - 2024-02-07 20:28:20 --> Total execution time: 0.0339
ERROR - 2024-02-07 20:28:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:28:50 --> Config Class Initialized
INFO - 2024-02-07 20:28:50 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:28:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:28:50 --> Utf8 Class Initialized
INFO - 2024-02-07 20:28:50 --> URI Class Initialized
INFO - 2024-02-07 20:28:50 --> Router Class Initialized
INFO - 2024-02-07 20:28:50 --> Output Class Initialized
INFO - 2024-02-07 20:28:50 --> Security Class Initialized
DEBUG - 2024-02-07 20:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:28:50 --> Input Class Initialized
INFO - 2024-02-07 20:28:50 --> Language Class Initialized
INFO - 2024-02-07 20:28:50 --> Loader Class Initialized
INFO - 2024-02-07 20:28:50 --> Helper loaded: url_helper
INFO - 2024-02-07 20:28:50 --> Helper loaded: file_helper
INFO - 2024-02-07 20:28:50 --> Helper loaded: form_helper
INFO - 2024-02-07 20:28:50 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:28:50 --> Controller Class Initialized
INFO - 2024-02-07 20:28:50 --> Form Validation Class Initialized
INFO - 2024-02-07 20:28:50 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:28:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:28:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:28:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:28:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:28:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:28:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:28:50 --> Final output sent to browser
DEBUG - 2024-02-07 20:28:50 --> Total execution time: 0.0285
ERROR - 2024-02-07 20:28:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:28:51 --> Config Class Initialized
INFO - 2024-02-07 20:28:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:28:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:28:51 --> Utf8 Class Initialized
INFO - 2024-02-07 20:28:51 --> URI Class Initialized
INFO - 2024-02-07 20:28:51 --> Router Class Initialized
INFO - 2024-02-07 20:28:51 --> Output Class Initialized
INFO - 2024-02-07 20:28:51 --> Security Class Initialized
DEBUG - 2024-02-07 20:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:28:51 --> Input Class Initialized
INFO - 2024-02-07 20:28:51 --> Language Class Initialized
INFO - 2024-02-07 20:28:51 --> Loader Class Initialized
INFO - 2024-02-07 20:28:51 --> Helper loaded: url_helper
INFO - 2024-02-07 20:28:51 --> Helper loaded: file_helper
INFO - 2024-02-07 20:28:51 --> Helper loaded: form_helper
INFO - 2024-02-07 20:28:51 --> Database Driver Class Initialized
ERROR - 2024-02-07 20:28:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:28:51 --> Config Class Initialized
INFO - 2024-02-07 20:28:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:28:51 --> Controller Class Initialized
INFO - 2024-02-07 20:28:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:28:51 --> Final output sent to browser
DEBUG - 2024-02-07 20:28:51 --> Total execution time: 0.0271
DEBUG - 2024-02-07 20:28:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:28:51 --> Utf8 Class Initialized
INFO - 2024-02-07 20:28:51 --> URI Class Initialized
INFO - 2024-02-07 20:28:51 --> Router Class Initialized
INFO - 2024-02-07 20:28:51 --> Output Class Initialized
INFO - 2024-02-07 20:28:51 --> Security Class Initialized
DEBUG - 2024-02-07 20:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:28:51 --> Input Class Initialized
INFO - 2024-02-07 20:28:51 --> Language Class Initialized
INFO - 2024-02-07 20:28:51 --> Loader Class Initialized
INFO - 2024-02-07 20:28:51 --> Helper loaded: url_helper
INFO - 2024-02-07 20:28:51 --> Helper loaded: file_helper
INFO - 2024-02-07 20:28:51 --> Helper loaded: form_helper
INFO - 2024-02-07 20:28:51 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:28:51 --> Controller Class Initialized
INFO - 2024-02-07 20:28:51 --> Form Validation Class Initialized
INFO - 2024-02-07 20:28:51 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:28:51 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:28:56 --> Config Class Initialized
INFO - 2024-02-07 20:28:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:28:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:28:56 --> Utf8 Class Initialized
INFO - 2024-02-07 20:28:56 --> URI Class Initialized
INFO - 2024-02-07 20:28:56 --> Router Class Initialized
INFO - 2024-02-07 20:28:56 --> Output Class Initialized
INFO - 2024-02-07 20:28:56 --> Security Class Initialized
DEBUG - 2024-02-07 20:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:28:56 --> Input Class Initialized
INFO - 2024-02-07 20:28:56 --> Language Class Initialized
INFO - 2024-02-07 20:28:56 --> Loader Class Initialized
INFO - 2024-02-07 20:28:56 --> Helper loaded: url_helper
INFO - 2024-02-07 20:28:56 --> Helper loaded: file_helper
INFO - 2024-02-07 20:28:56 --> Helper loaded: form_helper
INFO - 2024-02-07 20:28:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:28:56 --> Controller Class Initialized
INFO - 2024-02-07 20:28:56 --> Form Validation Class Initialized
INFO - 2024-02-07 20:28:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:28:56 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:28:56 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\sscy\application\models\UserMasterModel.php 68
INFO - 2024-02-07 20:28:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:28:56 --> Final output sent to browser
DEBUG - 2024-02-07 20:28:56 --> Total execution time: 0.0350
ERROR - 2024-02-07 20:29:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:29:49 --> Config Class Initialized
INFO - 2024-02-07 20:29:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:29:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:29:49 --> Utf8 Class Initialized
INFO - 2024-02-07 20:29:49 --> URI Class Initialized
INFO - 2024-02-07 20:29:49 --> Router Class Initialized
INFO - 2024-02-07 20:29:49 --> Output Class Initialized
INFO - 2024-02-07 20:29:49 --> Security Class Initialized
DEBUG - 2024-02-07 20:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:29:49 --> Input Class Initialized
INFO - 2024-02-07 20:29:49 --> Language Class Initialized
INFO - 2024-02-07 20:29:49 --> Loader Class Initialized
INFO - 2024-02-07 20:29:49 --> Helper loaded: url_helper
INFO - 2024-02-07 20:29:49 --> Helper loaded: file_helper
INFO - 2024-02-07 20:29:49 --> Helper loaded: form_helper
INFO - 2024-02-07 20:29:49 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:29:49 --> Controller Class Initialized
INFO - 2024-02-07 20:29:49 --> Form Validation Class Initialized
INFO - 2024-02-07 20:29:49 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:29:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:29:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:29:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:29:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:29:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:29:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:29:49 --> Final output sent to browser
DEBUG - 2024-02-07 20:29:49 --> Total execution time: 0.0356
ERROR - 2024-02-07 20:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:29:50 --> Config Class Initialized
INFO - 2024-02-07 20:29:50 --> Hooks Class Initialized
ERROR - 2024-02-07 20:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:29:50 --> Config Class Initialized
INFO - 2024-02-07 20:29:50 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:29:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:29:50 --> Utf8 Class Initialized
DEBUG - 2024-02-07 20:29:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:29:50 --> Utf8 Class Initialized
INFO - 2024-02-07 20:29:50 --> URI Class Initialized
INFO - 2024-02-07 20:29:50 --> URI Class Initialized
INFO - 2024-02-07 20:29:50 --> Router Class Initialized
INFO - 2024-02-07 20:29:50 --> Router Class Initialized
INFO - 2024-02-07 20:29:50 --> Output Class Initialized
INFO - 2024-02-07 20:29:50 --> Output Class Initialized
INFO - 2024-02-07 20:29:50 --> Security Class Initialized
INFO - 2024-02-07 20:29:50 --> Security Class Initialized
DEBUG - 2024-02-07 20:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:29:50 --> Input Class Initialized
DEBUG - 2024-02-07 20:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:29:50 --> Input Class Initialized
INFO - 2024-02-07 20:29:50 --> Language Class Initialized
INFO - 2024-02-07 20:29:50 --> Language Class Initialized
INFO - 2024-02-07 20:29:50 --> Loader Class Initialized
INFO - 2024-02-07 20:29:50 --> Loader Class Initialized
INFO - 2024-02-07 20:29:50 --> Helper loaded: url_helper
INFO - 2024-02-07 20:29:50 --> Helper loaded: url_helper
INFO - 2024-02-07 20:29:50 --> Helper loaded: file_helper
INFO - 2024-02-07 20:29:50 --> Helper loaded: file_helper
INFO - 2024-02-07 20:29:50 --> Helper loaded: form_helper
INFO - 2024-02-07 20:29:50 --> Helper loaded: form_helper
INFO - 2024-02-07 20:29:50 --> Database Driver Class Initialized
INFO - 2024-02-07 20:29:50 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:29:50 --> Controller Class Initialized
DEBUG - 2024-02-07 20:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:29:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:29:50 --> Final output sent to browser
DEBUG - 2024-02-07 20:29:50 --> Total execution time: 0.0246
INFO - 2024-02-07 20:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:29:50 --> Controller Class Initialized
INFO - 2024-02-07 20:29:50 --> Form Validation Class Initialized
INFO - 2024-02-07 20:29:50 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:29:50 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:29:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:29:56 --> Config Class Initialized
INFO - 2024-02-07 20:29:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:29:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:29:56 --> Utf8 Class Initialized
INFO - 2024-02-07 20:29:56 --> URI Class Initialized
INFO - 2024-02-07 20:29:56 --> Router Class Initialized
INFO - 2024-02-07 20:29:56 --> Output Class Initialized
INFO - 2024-02-07 20:29:56 --> Security Class Initialized
DEBUG - 2024-02-07 20:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:29:56 --> Input Class Initialized
INFO - 2024-02-07 20:29:56 --> Language Class Initialized
INFO - 2024-02-07 20:29:56 --> Loader Class Initialized
INFO - 2024-02-07 20:29:56 --> Helper loaded: url_helper
INFO - 2024-02-07 20:29:56 --> Helper loaded: file_helper
INFO - 2024-02-07 20:29:56 --> Helper loaded: form_helper
INFO - 2024-02-07 20:29:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:29:56 --> Controller Class Initialized
INFO - 2024-02-07 20:29:56 --> Form Validation Class Initialized
INFO - 2024-02-07 20:29:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:29:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:29:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:29:56 --> Final output sent to browser
DEBUG - 2024-02-07 20:29:56 --> Total execution time: 0.0307
ERROR - 2024-02-07 20:30:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:30:47 --> Config Class Initialized
INFO - 2024-02-07 20:30:47 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:30:47 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:30:47 --> Utf8 Class Initialized
INFO - 2024-02-07 20:30:47 --> URI Class Initialized
INFO - 2024-02-07 20:30:47 --> Router Class Initialized
INFO - 2024-02-07 20:30:47 --> Output Class Initialized
INFO - 2024-02-07 20:30:47 --> Security Class Initialized
DEBUG - 2024-02-07 20:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:30:47 --> Input Class Initialized
INFO - 2024-02-07 20:30:47 --> Language Class Initialized
INFO - 2024-02-07 20:30:47 --> Loader Class Initialized
INFO - 2024-02-07 20:30:47 --> Helper loaded: url_helper
INFO - 2024-02-07 20:30:47 --> Helper loaded: file_helper
INFO - 2024-02-07 20:30:47 --> Helper loaded: form_helper
INFO - 2024-02-07 20:30:47 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:30:47 --> Controller Class Initialized
INFO - 2024-02-07 20:30:47 --> Form Validation Class Initialized
INFO - 2024-02-07 20:30:47 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:30:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:30:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:30:47 --> Final output sent to browser
DEBUG - 2024-02-07 20:30:47 --> Total execution time: 0.0455
ERROR - 2024-02-07 20:31:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:31:02 --> Config Class Initialized
INFO - 2024-02-07 20:31:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:31:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:31:02 --> Utf8 Class Initialized
INFO - 2024-02-07 20:31:02 --> URI Class Initialized
INFO - 2024-02-07 20:31:02 --> Router Class Initialized
INFO - 2024-02-07 20:31:02 --> Output Class Initialized
INFO - 2024-02-07 20:31:02 --> Security Class Initialized
DEBUG - 2024-02-07 20:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:31:02 --> Input Class Initialized
INFO - 2024-02-07 20:31:02 --> Language Class Initialized
INFO - 2024-02-07 20:31:02 --> Loader Class Initialized
INFO - 2024-02-07 20:31:02 --> Helper loaded: url_helper
INFO - 2024-02-07 20:31:02 --> Helper loaded: file_helper
INFO - 2024-02-07 20:31:02 --> Helper loaded: form_helper
INFO - 2024-02-07 20:31:02 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:31:02 --> Controller Class Initialized
INFO - 2024-02-07 20:31:02 --> Form Validation Class Initialized
INFO - 2024-02-07 20:31:02 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:31:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:31:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:31:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:31:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:31:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:31:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:31:02 --> Final output sent to browser
DEBUG - 2024-02-07 20:31:02 --> Total execution time: 0.0345
ERROR - 2024-02-07 20:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:31:03 --> Config Class Initialized
INFO - 2024-02-07 20:31:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:31:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:31:03 --> Utf8 Class Initialized
INFO - 2024-02-07 20:31:03 --> URI Class Initialized
INFO - 2024-02-07 20:31:03 --> Router Class Initialized
INFO - 2024-02-07 20:31:03 --> Output Class Initialized
INFO - 2024-02-07 20:31:03 --> Security Class Initialized
DEBUG - 2024-02-07 20:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:31:03 --> Input Class Initialized
INFO - 2024-02-07 20:31:03 --> Language Class Initialized
INFO - 2024-02-07 20:31:03 --> Loader Class Initialized
INFO - 2024-02-07 20:31:03 --> Helper loaded: url_helper
INFO - 2024-02-07 20:31:03 --> Helper loaded: file_helper
INFO - 2024-02-07 20:31:03 --> Helper loaded: form_helper
INFO - 2024-02-07 20:31:03 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:31:03 --> Controller Class Initialized
INFO - 2024-02-07 20:31:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:31:03 --> Final output sent to browser
DEBUG - 2024-02-07 20:31:03 --> Total execution time: 0.0238
ERROR - 2024-02-07 20:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:31:03 --> Config Class Initialized
INFO - 2024-02-07 20:31:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:31:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:31:03 --> Utf8 Class Initialized
INFO - 2024-02-07 20:31:03 --> URI Class Initialized
INFO - 2024-02-07 20:31:03 --> Router Class Initialized
INFO - 2024-02-07 20:31:03 --> Output Class Initialized
INFO - 2024-02-07 20:31:03 --> Security Class Initialized
DEBUG - 2024-02-07 20:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:31:03 --> Input Class Initialized
INFO - 2024-02-07 20:31:03 --> Language Class Initialized
INFO - 2024-02-07 20:31:03 --> Loader Class Initialized
INFO - 2024-02-07 20:31:03 --> Helper loaded: url_helper
INFO - 2024-02-07 20:31:03 --> Helper loaded: file_helper
INFO - 2024-02-07 20:31:03 --> Helper loaded: form_helper
INFO - 2024-02-07 20:31:03 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:31:03 --> Controller Class Initialized
INFO - 2024-02-07 20:31:03 --> Form Validation Class Initialized
INFO - 2024-02-07 20:31:03 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:31:03 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:31:08 --> Config Class Initialized
INFO - 2024-02-07 20:31:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:31:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:31:08 --> Utf8 Class Initialized
INFO - 2024-02-07 20:31:08 --> URI Class Initialized
INFO - 2024-02-07 20:31:08 --> Router Class Initialized
INFO - 2024-02-07 20:31:08 --> Output Class Initialized
INFO - 2024-02-07 20:31:08 --> Security Class Initialized
DEBUG - 2024-02-07 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:31:08 --> Input Class Initialized
INFO - 2024-02-07 20:31:08 --> Language Class Initialized
INFO - 2024-02-07 20:31:08 --> Loader Class Initialized
INFO - 2024-02-07 20:31:08 --> Helper loaded: url_helper
INFO - 2024-02-07 20:31:08 --> Helper loaded: file_helper
INFO - 2024-02-07 20:31:08 --> Helper loaded: form_helper
INFO - 2024-02-07 20:31:08 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:31:08 --> Controller Class Initialized
INFO - 2024-02-07 20:31:08 --> Form Validation Class Initialized
INFO - 2024-02-07 20:31:08 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:31:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:31:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:31:08 --> Final output sent to browser
DEBUG - 2024-02-07 20:31:08 --> Total execution time: 0.0387
ERROR - 2024-02-07 20:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:31:15 --> Config Class Initialized
INFO - 2024-02-07 20:31:15 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:31:15 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:31:15 --> Utf8 Class Initialized
INFO - 2024-02-07 20:31:15 --> URI Class Initialized
INFO - 2024-02-07 20:31:15 --> Router Class Initialized
INFO - 2024-02-07 20:31:15 --> Output Class Initialized
INFO - 2024-02-07 20:31:15 --> Security Class Initialized
DEBUG - 2024-02-07 20:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:31:15 --> Input Class Initialized
INFO - 2024-02-07 20:31:15 --> Language Class Initialized
INFO - 2024-02-07 20:31:15 --> Loader Class Initialized
INFO - 2024-02-07 20:31:15 --> Helper loaded: url_helper
INFO - 2024-02-07 20:31:15 --> Helper loaded: file_helper
INFO - 2024-02-07 20:31:15 --> Helper loaded: form_helper
INFO - 2024-02-07 20:31:15 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:31:15 --> Controller Class Initialized
INFO - 2024-02-07 20:31:15 --> Form Validation Class Initialized
INFO - 2024-02-07 20:31:15 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:31:15 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:31:15 --> Config Class Initialized
INFO - 2024-02-07 20:31:15 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:31:15 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:31:15 --> Utf8 Class Initialized
INFO - 2024-02-07 20:31:15 --> URI Class Initialized
INFO - 2024-02-07 20:31:15 --> Router Class Initialized
INFO - 2024-02-07 20:31:15 --> Output Class Initialized
INFO - 2024-02-07 20:31:15 --> Security Class Initialized
DEBUG - 2024-02-07 20:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:31:15 --> Input Class Initialized
INFO - 2024-02-07 20:31:15 --> Language Class Initialized
INFO - 2024-02-07 20:31:15 --> Loader Class Initialized
INFO - 2024-02-07 20:31:15 --> Helper loaded: url_helper
INFO - 2024-02-07 20:31:15 --> Helper loaded: file_helper
INFO - 2024-02-07 20:31:15 --> Helper loaded: form_helper
INFO - 2024-02-07 20:31:15 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:31:15 --> Controller Class Initialized
INFO - 2024-02-07 20:31:15 --> Form Validation Class Initialized
INFO - 2024-02-07 20:31:15 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:31:15 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:31:53 --> Config Class Initialized
INFO - 2024-02-07 20:31:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:31:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:31:53 --> Utf8 Class Initialized
INFO - 2024-02-07 20:31:53 --> URI Class Initialized
INFO - 2024-02-07 20:31:53 --> Router Class Initialized
INFO - 2024-02-07 20:31:53 --> Output Class Initialized
INFO - 2024-02-07 20:31:53 --> Security Class Initialized
DEBUG - 2024-02-07 20:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:31:53 --> Input Class Initialized
INFO - 2024-02-07 20:31:53 --> Language Class Initialized
INFO - 2024-02-07 20:31:53 --> Loader Class Initialized
INFO - 2024-02-07 20:31:53 --> Helper loaded: url_helper
INFO - 2024-02-07 20:31:53 --> Helper loaded: file_helper
INFO - 2024-02-07 20:31:53 --> Helper loaded: form_helper
INFO - 2024-02-07 20:31:53 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:31:53 --> Controller Class Initialized
INFO - 2024-02-07 20:31:53 --> Form Validation Class Initialized
INFO - 2024-02-07 20:31:53 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:31:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:31:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:31:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:31:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:31:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:31:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:31:53 --> Final output sent to browser
DEBUG - 2024-02-07 20:31:53 --> Total execution time: 0.0296
ERROR - 2024-02-07 20:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:31:53 --> Config Class Initialized
INFO - 2024-02-07 20:31:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:31:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:31:53 --> Utf8 Class Initialized
INFO - 2024-02-07 20:31:53 --> URI Class Initialized
INFO - 2024-02-07 20:31:53 --> Router Class Initialized
INFO - 2024-02-07 20:31:53 --> Output Class Initialized
INFO - 2024-02-07 20:31:53 --> Security Class Initialized
DEBUG - 2024-02-07 20:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:31:53 --> Input Class Initialized
INFO - 2024-02-07 20:31:53 --> Language Class Initialized
INFO - 2024-02-07 20:31:53 --> Loader Class Initialized
INFO - 2024-02-07 20:31:53 --> Helper loaded: url_helper
INFO - 2024-02-07 20:31:53 --> Helper loaded: file_helper
INFO - 2024-02-07 20:31:53 --> Helper loaded: form_helper
INFO - 2024-02-07 20:31:53 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:31:53 --> Controller Class Initialized
INFO - 2024-02-07 20:31:53 --> Form Validation Class Initialized
INFO - 2024-02-07 20:31:53 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:31:53 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:31:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:31:54 --> Config Class Initialized
INFO - 2024-02-07 20:31:54 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:31:54 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:31:54 --> Utf8 Class Initialized
INFO - 2024-02-07 20:31:54 --> URI Class Initialized
INFO - 2024-02-07 20:31:54 --> Router Class Initialized
INFO - 2024-02-07 20:31:54 --> Output Class Initialized
INFO - 2024-02-07 20:31:54 --> Security Class Initialized
DEBUG - 2024-02-07 20:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:31:54 --> Input Class Initialized
INFO - 2024-02-07 20:31:54 --> Language Class Initialized
INFO - 2024-02-07 20:31:54 --> Loader Class Initialized
INFO - 2024-02-07 20:31:54 --> Helper loaded: url_helper
INFO - 2024-02-07 20:31:54 --> Helper loaded: file_helper
INFO - 2024-02-07 20:31:54 --> Helper loaded: form_helper
INFO - 2024-02-07 20:31:54 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:31:54 --> Controller Class Initialized
INFO - 2024-02-07 20:31:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:31:54 --> Final output sent to browser
DEBUG - 2024-02-07 20:31:54 --> Total execution time: 0.0314
ERROR - 2024-02-07 20:31:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:31:59 --> Config Class Initialized
INFO - 2024-02-07 20:31:59 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:31:59 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:31:59 --> Utf8 Class Initialized
INFO - 2024-02-07 20:31:59 --> URI Class Initialized
INFO - 2024-02-07 20:31:59 --> Router Class Initialized
INFO - 2024-02-07 20:31:59 --> Output Class Initialized
INFO - 2024-02-07 20:31:59 --> Security Class Initialized
DEBUG - 2024-02-07 20:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:31:59 --> Input Class Initialized
INFO - 2024-02-07 20:31:59 --> Language Class Initialized
INFO - 2024-02-07 20:31:59 --> Loader Class Initialized
INFO - 2024-02-07 20:31:59 --> Helper loaded: url_helper
INFO - 2024-02-07 20:31:59 --> Helper loaded: file_helper
INFO - 2024-02-07 20:31:59 --> Helper loaded: form_helper
INFO - 2024-02-07 20:31:59 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:31:59 --> Controller Class Initialized
INFO - 2024-02-07 20:31:59 --> Form Validation Class Initialized
INFO - 2024-02-07 20:31:59 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:31:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:31:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:31:59 --> Final output sent to browser
DEBUG - 2024-02-07 20:31:59 --> Total execution time: 0.0340
ERROR - 2024-02-07 20:32:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:32:17 --> Config Class Initialized
INFO - 2024-02-07 20:32:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:32:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:32:17 --> Utf8 Class Initialized
INFO - 2024-02-07 20:32:17 --> URI Class Initialized
INFO - 2024-02-07 20:32:17 --> Router Class Initialized
INFO - 2024-02-07 20:32:17 --> Output Class Initialized
INFO - 2024-02-07 20:32:17 --> Security Class Initialized
DEBUG - 2024-02-07 20:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:32:17 --> Input Class Initialized
INFO - 2024-02-07 20:32:17 --> Language Class Initialized
INFO - 2024-02-07 20:32:17 --> Loader Class Initialized
INFO - 2024-02-07 20:32:17 --> Helper loaded: url_helper
INFO - 2024-02-07 20:32:17 --> Helper loaded: file_helper
INFO - 2024-02-07 20:32:17 --> Helper loaded: form_helper
INFO - 2024-02-07 20:32:17 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:32:17 --> Controller Class Initialized
INFO - 2024-02-07 20:32:17 --> Form Validation Class Initialized
INFO - 2024-02-07 20:32:17 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:32:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:32:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:32:17 --> Final output sent to browser
DEBUG - 2024-02-07 20:32:17 --> Total execution time: 0.0328
ERROR - 2024-02-07 20:32:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:32:20 --> Config Class Initialized
INFO - 2024-02-07 20:32:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:32:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:32:20 --> Utf8 Class Initialized
INFO - 2024-02-07 20:32:20 --> URI Class Initialized
INFO - 2024-02-07 20:32:20 --> Router Class Initialized
INFO - 2024-02-07 20:32:20 --> Output Class Initialized
INFO - 2024-02-07 20:32:20 --> Security Class Initialized
DEBUG - 2024-02-07 20:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:32:20 --> Input Class Initialized
INFO - 2024-02-07 20:32:20 --> Language Class Initialized
INFO - 2024-02-07 20:32:20 --> Loader Class Initialized
INFO - 2024-02-07 20:32:20 --> Helper loaded: url_helper
INFO - 2024-02-07 20:32:20 --> Helper loaded: file_helper
INFO - 2024-02-07 20:32:20 --> Helper loaded: form_helper
INFO - 2024-02-07 20:32:20 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:32:20 --> Controller Class Initialized
INFO - 2024-02-07 20:32:20 --> Form Validation Class Initialized
INFO - 2024-02-07 20:32:20 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:32:20 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:32:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:32:20 --> Config Class Initialized
INFO - 2024-02-07 20:32:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:32:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:32:20 --> Utf8 Class Initialized
INFO - 2024-02-07 20:32:20 --> URI Class Initialized
INFO - 2024-02-07 20:32:20 --> Router Class Initialized
INFO - 2024-02-07 20:32:20 --> Output Class Initialized
INFO - 2024-02-07 20:32:20 --> Security Class Initialized
DEBUG - 2024-02-07 20:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:32:20 --> Input Class Initialized
INFO - 2024-02-07 20:32:20 --> Language Class Initialized
INFO - 2024-02-07 20:32:20 --> Loader Class Initialized
INFO - 2024-02-07 20:32:20 --> Helper loaded: url_helper
INFO - 2024-02-07 20:32:20 --> Helper loaded: file_helper
INFO - 2024-02-07 20:32:20 --> Helper loaded: form_helper
INFO - 2024-02-07 20:32:20 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:32:20 --> Controller Class Initialized
INFO - 2024-02-07 20:32:20 --> Form Validation Class Initialized
INFO - 2024-02-07 20:32:20 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:32:20 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:32:25 --> Config Class Initialized
INFO - 2024-02-07 20:32:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:32:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:32:25 --> Utf8 Class Initialized
INFO - 2024-02-07 20:32:25 --> URI Class Initialized
INFO - 2024-02-07 20:32:25 --> Router Class Initialized
INFO - 2024-02-07 20:32:25 --> Output Class Initialized
INFO - 2024-02-07 20:32:25 --> Security Class Initialized
DEBUG - 2024-02-07 20:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:32:25 --> Input Class Initialized
INFO - 2024-02-07 20:32:25 --> Language Class Initialized
INFO - 2024-02-07 20:32:25 --> Loader Class Initialized
INFO - 2024-02-07 20:32:25 --> Helper loaded: url_helper
INFO - 2024-02-07 20:32:25 --> Helper loaded: file_helper
INFO - 2024-02-07 20:32:25 --> Helper loaded: form_helper
INFO - 2024-02-07 20:32:25 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:32:25 --> Controller Class Initialized
INFO - 2024-02-07 20:32:25 --> Form Validation Class Initialized
INFO - 2024-02-07 20:32:25 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:32:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:32:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:32:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:32:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:32:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:32:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:32:25 --> Final output sent to browser
DEBUG - 2024-02-07 20:32:25 --> Total execution time: 0.0286
ERROR - 2024-02-07 20:32:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:32:26 --> Config Class Initialized
INFO - 2024-02-07 20:32:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:32:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:32:26 --> Utf8 Class Initialized
INFO - 2024-02-07 20:32:26 --> URI Class Initialized
INFO - 2024-02-07 20:32:26 --> Router Class Initialized
INFO - 2024-02-07 20:32:26 --> Output Class Initialized
INFO - 2024-02-07 20:32:26 --> Security Class Initialized
DEBUG - 2024-02-07 20:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:32:26 --> Input Class Initialized
INFO - 2024-02-07 20:32:26 --> Language Class Initialized
INFO - 2024-02-07 20:32:26 --> Loader Class Initialized
INFO - 2024-02-07 20:32:26 --> Helper loaded: url_helper
INFO - 2024-02-07 20:32:26 --> Helper loaded: file_helper
INFO - 2024-02-07 20:32:26 --> Helper loaded: form_helper
INFO - 2024-02-07 20:32:26 --> Database Driver Class Initialized
ERROR - 2024-02-07 20:32:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2024-02-07 20:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:32:26 --> Controller Class Initialized
INFO - 2024-02-07 20:32:26 --> Config Class Initialized
INFO - 2024-02-07 20:32:26 --> Hooks Class Initialized
INFO - 2024-02-07 20:32:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:32:26 --> Final output sent to browser
DEBUG - 2024-02-07 20:32:26 --> Total execution time: 0.0315
DEBUG - 2024-02-07 20:32:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:32:26 --> Utf8 Class Initialized
INFO - 2024-02-07 20:32:26 --> URI Class Initialized
INFO - 2024-02-07 20:32:26 --> Router Class Initialized
INFO - 2024-02-07 20:32:26 --> Output Class Initialized
INFO - 2024-02-07 20:32:26 --> Security Class Initialized
DEBUG - 2024-02-07 20:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:32:26 --> Input Class Initialized
INFO - 2024-02-07 20:32:26 --> Language Class Initialized
INFO - 2024-02-07 20:32:26 --> Loader Class Initialized
INFO - 2024-02-07 20:32:26 --> Helper loaded: url_helper
INFO - 2024-02-07 20:32:26 --> Helper loaded: file_helper
INFO - 2024-02-07 20:32:26 --> Helper loaded: form_helper
INFO - 2024-02-07 20:32:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:32:26 --> Controller Class Initialized
INFO - 2024-02-07 20:32:26 --> Form Validation Class Initialized
INFO - 2024-02-07 20:32:26 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:32:26 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:32:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:32:33 --> Config Class Initialized
INFO - 2024-02-07 20:32:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:32:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:32:33 --> Utf8 Class Initialized
INFO - 2024-02-07 20:32:33 --> URI Class Initialized
INFO - 2024-02-07 20:32:33 --> Router Class Initialized
INFO - 2024-02-07 20:32:33 --> Output Class Initialized
INFO - 2024-02-07 20:32:33 --> Security Class Initialized
DEBUG - 2024-02-07 20:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:32:33 --> Input Class Initialized
INFO - 2024-02-07 20:32:33 --> Language Class Initialized
INFO - 2024-02-07 20:32:33 --> Loader Class Initialized
INFO - 2024-02-07 20:32:33 --> Helper loaded: url_helper
INFO - 2024-02-07 20:32:33 --> Helper loaded: file_helper
INFO - 2024-02-07 20:32:33 --> Helper loaded: form_helper
INFO - 2024-02-07 20:32:33 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:32:33 --> Controller Class Initialized
INFO - 2024-02-07 20:32:33 --> Form Validation Class Initialized
INFO - 2024-02-07 20:32:33 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:32:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:32:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:32:33 --> Final output sent to browser
DEBUG - 2024-02-07 20:32:33 --> Total execution time: 0.0286
ERROR - 2024-02-07 20:32:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:32:35 --> Config Class Initialized
INFO - 2024-02-07 20:32:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:32:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:32:35 --> Utf8 Class Initialized
INFO - 2024-02-07 20:32:35 --> URI Class Initialized
INFO - 2024-02-07 20:32:35 --> Router Class Initialized
INFO - 2024-02-07 20:32:35 --> Output Class Initialized
INFO - 2024-02-07 20:32:35 --> Security Class Initialized
DEBUG - 2024-02-07 20:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:32:35 --> Input Class Initialized
INFO - 2024-02-07 20:32:35 --> Language Class Initialized
INFO - 2024-02-07 20:32:35 --> Loader Class Initialized
INFO - 2024-02-07 20:32:35 --> Helper loaded: url_helper
INFO - 2024-02-07 20:32:35 --> Helper loaded: file_helper
INFO - 2024-02-07 20:32:35 --> Helper loaded: form_helper
INFO - 2024-02-07 20:32:35 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:32:35 --> Controller Class Initialized
INFO - 2024-02-07 20:32:35 --> Form Validation Class Initialized
INFO - 2024-02-07 20:32:35 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:32:35 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:32:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:32:35 --> Config Class Initialized
INFO - 2024-02-07 20:32:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:32:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:32:35 --> Utf8 Class Initialized
INFO - 2024-02-07 20:32:35 --> URI Class Initialized
INFO - 2024-02-07 20:32:35 --> Router Class Initialized
INFO - 2024-02-07 20:32:35 --> Output Class Initialized
INFO - 2024-02-07 20:32:35 --> Security Class Initialized
DEBUG - 2024-02-07 20:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:32:35 --> Input Class Initialized
INFO - 2024-02-07 20:32:35 --> Language Class Initialized
INFO - 2024-02-07 20:32:35 --> Loader Class Initialized
INFO - 2024-02-07 20:32:35 --> Helper loaded: url_helper
INFO - 2024-02-07 20:32:35 --> Helper loaded: file_helper
INFO - 2024-02-07 20:32:35 --> Helper loaded: form_helper
INFO - 2024-02-07 20:32:35 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:32:35 --> Controller Class Initialized
INFO - 2024-02-07 20:32:35 --> Form Validation Class Initialized
INFO - 2024-02-07 20:32:35 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:32:35 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:33:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:33:04 --> Config Class Initialized
INFO - 2024-02-07 20:33:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:33:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:33:04 --> Utf8 Class Initialized
INFO - 2024-02-07 20:33:04 --> URI Class Initialized
INFO - 2024-02-07 20:33:04 --> Router Class Initialized
INFO - 2024-02-07 20:33:04 --> Output Class Initialized
INFO - 2024-02-07 20:33:04 --> Security Class Initialized
DEBUG - 2024-02-07 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:33:04 --> Input Class Initialized
INFO - 2024-02-07 20:33:04 --> Language Class Initialized
INFO - 2024-02-07 20:33:04 --> Loader Class Initialized
INFO - 2024-02-07 20:33:04 --> Helper loaded: url_helper
INFO - 2024-02-07 20:33:04 --> Helper loaded: file_helper
INFO - 2024-02-07 20:33:04 --> Helper loaded: form_helper
INFO - 2024-02-07 20:33:04 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:33:04 --> Controller Class Initialized
INFO - 2024-02-07 20:33:04 --> Form Validation Class Initialized
INFO - 2024-02-07 20:33:04 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:33:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:33:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:33:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:33:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:33:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:33:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:33:04 --> Final output sent to browser
DEBUG - 2024-02-07 20:33:04 --> Total execution time: 0.0331
ERROR - 2024-02-07 20:33:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:33:04 --> Config Class Initialized
INFO - 2024-02-07 20:33:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:33:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:33:04 --> Utf8 Class Initialized
INFO - 2024-02-07 20:33:04 --> URI Class Initialized
INFO - 2024-02-07 20:33:04 --> Router Class Initialized
INFO - 2024-02-07 20:33:04 --> Output Class Initialized
INFO - 2024-02-07 20:33:04 --> Security Class Initialized
DEBUG - 2024-02-07 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:33:04 --> Input Class Initialized
INFO - 2024-02-07 20:33:04 --> Language Class Initialized
INFO - 2024-02-07 20:33:04 --> Loader Class Initialized
INFO - 2024-02-07 20:33:04 --> Helper loaded: url_helper
INFO - 2024-02-07 20:33:04 --> Helper loaded: file_helper
INFO - 2024-02-07 20:33:04 --> Helper loaded: form_helper
INFO - 2024-02-07 20:33:04 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:33:04 --> Controller Class Initialized
INFO - 2024-02-07 20:33:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:33:04 --> Final output sent to browser
DEBUG - 2024-02-07 20:33:04 --> Total execution time: 0.0252
ERROR - 2024-02-07 20:33:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:33:04 --> Config Class Initialized
INFO - 2024-02-07 20:33:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:33:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:33:04 --> Utf8 Class Initialized
INFO - 2024-02-07 20:33:04 --> URI Class Initialized
INFO - 2024-02-07 20:33:04 --> Router Class Initialized
INFO - 2024-02-07 20:33:04 --> Output Class Initialized
INFO - 2024-02-07 20:33:04 --> Security Class Initialized
DEBUG - 2024-02-07 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:33:04 --> Input Class Initialized
INFO - 2024-02-07 20:33:04 --> Language Class Initialized
INFO - 2024-02-07 20:33:04 --> Loader Class Initialized
INFO - 2024-02-07 20:33:04 --> Helper loaded: url_helper
INFO - 2024-02-07 20:33:04 --> Helper loaded: file_helper
INFO - 2024-02-07 20:33:04 --> Helper loaded: form_helper
INFO - 2024-02-07 20:33:04 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:33:04 --> Controller Class Initialized
INFO - 2024-02-07 20:33:04 --> Form Validation Class Initialized
INFO - 2024-02-07 20:33:04 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:33:04 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:33:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:33:09 --> Config Class Initialized
INFO - 2024-02-07 20:33:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:33:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:33:09 --> Utf8 Class Initialized
INFO - 2024-02-07 20:33:09 --> URI Class Initialized
INFO - 2024-02-07 20:33:09 --> Router Class Initialized
INFO - 2024-02-07 20:33:09 --> Output Class Initialized
INFO - 2024-02-07 20:33:09 --> Security Class Initialized
DEBUG - 2024-02-07 20:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:33:09 --> Input Class Initialized
INFO - 2024-02-07 20:33:09 --> Language Class Initialized
INFO - 2024-02-07 20:33:09 --> Loader Class Initialized
INFO - 2024-02-07 20:33:09 --> Helper loaded: url_helper
INFO - 2024-02-07 20:33:09 --> Helper loaded: file_helper
INFO - 2024-02-07 20:33:09 --> Helper loaded: form_helper
INFO - 2024-02-07 20:33:09 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:33:09 --> Controller Class Initialized
INFO - 2024-02-07 20:33:09 --> Form Validation Class Initialized
INFO - 2024-02-07 20:33:09 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:33:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:33:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:33:09 --> Final output sent to browser
DEBUG - 2024-02-07 20:33:09 --> Total execution time: 0.0278
ERROR - 2024-02-07 20:33:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:33:12 --> Config Class Initialized
INFO - 2024-02-07 20:33:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:33:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:33:12 --> Utf8 Class Initialized
INFO - 2024-02-07 20:33:12 --> URI Class Initialized
INFO - 2024-02-07 20:33:12 --> Router Class Initialized
INFO - 2024-02-07 20:33:12 --> Output Class Initialized
INFO - 2024-02-07 20:33:12 --> Security Class Initialized
DEBUG - 2024-02-07 20:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:33:12 --> Input Class Initialized
INFO - 2024-02-07 20:33:12 --> Language Class Initialized
INFO - 2024-02-07 20:33:12 --> Loader Class Initialized
INFO - 2024-02-07 20:33:12 --> Helper loaded: url_helper
INFO - 2024-02-07 20:33:12 --> Helper loaded: file_helper
INFO - 2024-02-07 20:33:12 --> Helper loaded: form_helper
INFO - 2024-02-07 20:33:12 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:33:12 --> Controller Class Initialized
INFO - 2024-02-07 20:33:12 --> Form Validation Class Initialized
INFO - 2024-02-07 20:33:12 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:33:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:33:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:33:12 --> Config Class Initialized
INFO - 2024-02-07 20:33:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:33:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:33:12 --> Utf8 Class Initialized
INFO - 2024-02-07 20:33:12 --> URI Class Initialized
INFO - 2024-02-07 20:33:12 --> Router Class Initialized
INFO - 2024-02-07 20:33:12 --> Output Class Initialized
INFO - 2024-02-07 20:33:12 --> Security Class Initialized
DEBUG - 2024-02-07 20:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:33:12 --> Input Class Initialized
INFO - 2024-02-07 20:33:12 --> Language Class Initialized
INFO - 2024-02-07 20:33:12 --> Loader Class Initialized
INFO - 2024-02-07 20:33:12 --> Helper loaded: url_helper
INFO - 2024-02-07 20:33:12 --> Helper loaded: file_helper
INFO - 2024-02-07 20:33:12 --> Helper loaded: form_helper
INFO - 2024-02-07 20:33:12 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:33:12 --> Controller Class Initialized
INFO - 2024-02-07 20:33:12 --> Form Validation Class Initialized
INFO - 2024-02-07 20:33:12 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:33:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:34:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:34:45 --> Config Class Initialized
INFO - 2024-02-07 20:34:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:34:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:34:45 --> Utf8 Class Initialized
INFO - 2024-02-07 20:34:45 --> URI Class Initialized
INFO - 2024-02-07 20:34:45 --> Router Class Initialized
INFO - 2024-02-07 20:34:45 --> Output Class Initialized
INFO - 2024-02-07 20:34:45 --> Security Class Initialized
DEBUG - 2024-02-07 20:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:34:45 --> Input Class Initialized
INFO - 2024-02-07 20:34:45 --> Language Class Initialized
INFO - 2024-02-07 20:34:45 --> Loader Class Initialized
INFO - 2024-02-07 20:34:45 --> Helper loaded: url_helper
INFO - 2024-02-07 20:34:45 --> Helper loaded: file_helper
INFO - 2024-02-07 20:34:45 --> Helper loaded: form_helper
INFO - 2024-02-07 20:34:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:34:45 --> Controller Class Initialized
INFO - 2024-02-07 20:34:45 --> Form Validation Class Initialized
INFO - 2024-02-07 20:34:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:34:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:34:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:34:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:34:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:34:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:34:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:34:45 --> Final output sent to browser
DEBUG - 2024-02-07 20:34:45 --> Total execution time: 0.0316
ERROR - 2024-02-07 20:34:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:34:45 --> Config Class Initialized
INFO - 2024-02-07 20:34:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:34:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:34:45 --> Utf8 Class Initialized
INFO - 2024-02-07 20:34:45 --> URI Class Initialized
INFO - 2024-02-07 20:34:45 --> Router Class Initialized
INFO - 2024-02-07 20:34:45 --> Output Class Initialized
INFO - 2024-02-07 20:34:45 --> Security Class Initialized
DEBUG - 2024-02-07 20:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:34:45 --> Input Class Initialized
INFO - 2024-02-07 20:34:45 --> Language Class Initialized
INFO - 2024-02-07 20:34:45 --> Loader Class Initialized
INFO - 2024-02-07 20:34:45 --> Helper loaded: url_helper
INFO - 2024-02-07 20:34:45 --> Helper loaded: file_helper
INFO - 2024-02-07 20:34:45 --> Helper loaded: form_helper
INFO - 2024-02-07 20:34:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:34:45 --> Controller Class Initialized
INFO - 2024-02-07 20:34:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:34:45 --> Final output sent to browser
DEBUG - 2024-02-07 20:34:45 --> Total execution time: 0.0363
ERROR - 2024-02-07 20:34:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:34:45 --> Config Class Initialized
INFO - 2024-02-07 20:34:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:34:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:34:45 --> Utf8 Class Initialized
INFO - 2024-02-07 20:34:45 --> URI Class Initialized
INFO - 2024-02-07 20:34:45 --> Router Class Initialized
INFO - 2024-02-07 20:34:45 --> Output Class Initialized
INFO - 2024-02-07 20:34:45 --> Security Class Initialized
DEBUG - 2024-02-07 20:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:34:45 --> Input Class Initialized
INFO - 2024-02-07 20:34:45 --> Language Class Initialized
INFO - 2024-02-07 20:34:45 --> Loader Class Initialized
INFO - 2024-02-07 20:34:45 --> Helper loaded: url_helper
INFO - 2024-02-07 20:34:45 --> Helper loaded: file_helper
INFO - 2024-02-07 20:34:45 --> Helper loaded: form_helper
INFO - 2024-02-07 20:34:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:34:45 --> Controller Class Initialized
INFO - 2024-02-07 20:34:45 --> Form Validation Class Initialized
INFO - 2024-02-07 20:34:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:34:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:34:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:34:50 --> Config Class Initialized
INFO - 2024-02-07 20:34:50 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:34:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:34:50 --> Utf8 Class Initialized
INFO - 2024-02-07 20:34:50 --> URI Class Initialized
INFO - 2024-02-07 20:34:50 --> Router Class Initialized
INFO - 2024-02-07 20:34:50 --> Output Class Initialized
INFO - 2024-02-07 20:34:50 --> Security Class Initialized
DEBUG - 2024-02-07 20:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:34:50 --> Input Class Initialized
INFO - 2024-02-07 20:34:50 --> Language Class Initialized
INFO - 2024-02-07 20:34:50 --> Loader Class Initialized
INFO - 2024-02-07 20:34:50 --> Helper loaded: url_helper
INFO - 2024-02-07 20:34:50 --> Helper loaded: file_helper
INFO - 2024-02-07 20:34:50 --> Helper loaded: form_helper
INFO - 2024-02-07 20:34:50 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:34:50 --> Controller Class Initialized
INFO - 2024-02-07 20:34:50 --> Form Validation Class Initialized
INFO - 2024-02-07 20:34:50 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:34:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:34:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:34:50 --> Final output sent to browser
DEBUG - 2024-02-07 20:34:50 --> Total execution time: 0.0324
ERROR - 2024-02-07 20:34:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:34:55 --> Config Class Initialized
INFO - 2024-02-07 20:34:55 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:34:55 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:34:55 --> Utf8 Class Initialized
INFO - 2024-02-07 20:34:55 --> URI Class Initialized
INFO - 2024-02-07 20:34:55 --> Router Class Initialized
INFO - 2024-02-07 20:34:55 --> Output Class Initialized
INFO - 2024-02-07 20:34:55 --> Security Class Initialized
DEBUG - 2024-02-07 20:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:34:55 --> Input Class Initialized
INFO - 2024-02-07 20:34:55 --> Language Class Initialized
INFO - 2024-02-07 20:34:55 --> Loader Class Initialized
INFO - 2024-02-07 20:34:55 --> Helper loaded: url_helper
INFO - 2024-02-07 20:34:55 --> Helper loaded: file_helper
INFO - 2024-02-07 20:34:55 --> Helper loaded: form_helper
INFO - 2024-02-07 20:34:55 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:34:55 --> Controller Class Initialized
INFO - 2024-02-07 20:34:55 --> Form Validation Class Initialized
INFO - 2024-02-07 20:34:55 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:34:55 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:34:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:34:55 --> Config Class Initialized
INFO - 2024-02-07 20:34:55 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:34:55 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:34:55 --> Utf8 Class Initialized
INFO - 2024-02-07 20:34:55 --> URI Class Initialized
INFO - 2024-02-07 20:34:55 --> Router Class Initialized
INFO - 2024-02-07 20:34:55 --> Output Class Initialized
INFO - 2024-02-07 20:34:55 --> Security Class Initialized
DEBUG - 2024-02-07 20:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:34:55 --> Input Class Initialized
INFO - 2024-02-07 20:34:55 --> Language Class Initialized
INFO - 2024-02-07 20:34:55 --> Loader Class Initialized
INFO - 2024-02-07 20:34:55 --> Helper loaded: url_helper
INFO - 2024-02-07 20:34:55 --> Helper loaded: file_helper
INFO - 2024-02-07 20:34:55 --> Helper loaded: form_helper
INFO - 2024-02-07 20:34:55 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:34:55 --> Controller Class Initialized
INFO - 2024-02-07 20:34:55 --> Form Validation Class Initialized
INFO - 2024-02-07 20:34:55 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:34:55 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:41:28 --> Config Class Initialized
INFO - 2024-02-07 20:41:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:41:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:41:28 --> Utf8 Class Initialized
INFO - 2024-02-07 20:41:28 --> URI Class Initialized
INFO - 2024-02-07 20:41:28 --> Router Class Initialized
INFO - 2024-02-07 20:41:28 --> Output Class Initialized
INFO - 2024-02-07 20:41:28 --> Security Class Initialized
DEBUG - 2024-02-07 20:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:41:28 --> Input Class Initialized
INFO - 2024-02-07 20:41:28 --> Language Class Initialized
INFO - 2024-02-07 20:41:28 --> Loader Class Initialized
INFO - 2024-02-07 20:41:28 --> Helper loaded: url_helper
INFO - 2024-02-07 20:41:28 --> Helper loaded: file_helper
INFO - 2024-02-07 20:41:28 --> Helper loaded: form_helper
INFO - 2024-02-07 20:41:28 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:41:28 --> Controller Class Initialized
INFO - 2024-02-07 20:41:28 --> Form Validation Class Initialized
INFO - 2024-02-07 20:41:28 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:41:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:41:28 --> Final output sent to browser
DEBUG - 2024-02-07 20:41:28 --> Total execution time: 0.0306
ERROR - 2024-02-07 20:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:41:28 --> Config Class Initialized
INFO - 2024-02-07 20:41:28 --> Hooks Class Initialized
ERROR - 2024-02-07 20:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:41:28 --> Config Class Initialized
DEBUG - 2024-02-07 20:41:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:41:28 --> Hooks Class Initialized
INFO - 2024-02-07 20:41:28 --> Utf8 Class Initialized
INFO - 2024-02-07 20:41:28 --> URI Class Initialized
DEBUG - 2024-02-07 20:41:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:41:28 --> Utf8 Class Initialized
INFO - 2024-02-07 20:41:28 --> Router Class Initialized
INFO - 2024-02-07 20:41:28 --> URI Class Initialized
INFO - 2024-02-07 20:41:28 --> Output Class Initialized
INFO - 2024-02-07 20:41:28 --> Router Class Initialized
INFO - 2024-02-07 20:41:28 --> Security Class Initialized
INFO - 2024-02-07 20:41:28 --> Output Class Initialized
DEBUG - 2024-02-07 20:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:41:28 --> Input Class Initialized
INFO - 2024-02-07 20:41:28 --> Language Class Initialized
INFO - 2024-02-07 20:41:28 --> Security Class Initialized
DEBUG - 2024-02-07 20:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:41:28 --> Input Class Initialized
INFO - 2024-02-07 20:41:28 --> Loader Class Initialized
INFO - 2024-02-07 20:41:28 --> Language Class Initialized
INFO - 2024-02-07 20:41:28 --> Helper loaded: url_helper
INFO - 2024-02-07 20:41:28 --> Helper loaded: file_helper
INFO - 2024-02-07 20:41:28 --> Loader Class Initialized
INFO - 2024-02-07 20:41:28 --> Helper loaded: form_helper
INFO - 2024-02-07 20:41:28 --> Helper loaded: url_helper
INFO - 2024-02-07 20:41:28 --> Helper loaded: file_helper
INFO - 2024-02-07 20:41:28 --> Helper loaded: form_helper
INFO - 2024-02-07 20:41:28 --> Database Driver Class Initialized
INFO - 2024-02-07 20:41:28 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:41:28 --> Controller Class Initialized
INFO - 2024-02-07 20:41:28 --> Form Validation Class Initialized
DEBUG - 2024-02-07 20:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:41:28 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:41:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:41:28 --> Controller Class Initialized
INFO - 2024-02-07 20:41:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:41:28 --> Final output sent to browser
DEBUG - 2024-02-07 20:41:28 --> Total execution time: 0.0311
ERROR - 2024-02-07 20:41:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:41:32 --> Config Class Initialized
INFO - 2024-02-07 20:41:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:41:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:41:32 --> Utf8 Class Initialized
INFO - 2024-02-07 20:41:32 --> URI Class Initialized
INFO - 2024-02-07 20:41:32 --> Router Class Initialized
INFO - 2024-02-07 20:41:32 --> Output Class Initialized
INFO - 2024-02-07 20:41:32 --> Security Class Initialized
DEBUG - 2024-02-07 20:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:41:32 --> Input Class Initialized
INFO - 2024-02-07 20:41:32 --> Language Class Initialized
INFO - 2024-02-07 20:41:32 --> Loader Class Initialized
INFO - 2024-02-07 20:41:32 --> Helper loaded: url_helper
INFO - 2024-02-07 20:41:32 --> Helper loaded: file_helper
INFO - 2024-02-07 20:41:32 --> Helper loaded: form_helper
INFO - 2024-02-07 20:41:32 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:41:32 --> Controller Class Initialized
INFO - 2024-02-07 20:41:32 --> Form Validation Class Initialized
INFO - 2024-02-07 20:41:32 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:41:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:41:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:41:32 --> Final output sent to browser
DEBUG - 2024-02-07 20:41:32 --> Total execution time: 0.0272
ERROR - 2024-02-07 20:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:41:34 --> Config Class Initialized
INFO - 2024-02-07 20:41:34 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:41:34 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:41:34 --> Utf8 Class Initialized
INFO - 2024-02-07 20:41:34 --> URI Class Initialized
INFO - 2024-02-07 20:41:34 --> Router Class Initialized
INFO - 2024-02-07 20:41:34 --> Output Class Initialized
INFO - 2024-02-07 20:41:34 --> Security Class Initialized
DEBUG - 2024-02-07 20:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:41:34 --> Input Class Initialized
INFO - 2024-02-07 20:41:34 --> Language Class Initialized
INFO - 2024-02-07 20:41:34 --> Loader Class Initialized
INFO - 2024-02-07 20:41:34 --> Helper loaded: url_helper
INFO - 2024-02-07 20:41:34 --> Helper loaded: file_helper
INFO - 2024-02-07 20:41:34 --> Helper loaded: form_helper
INFO - 2024-02-07 20:41:34 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:41:34 --> Controller Class Initialized
INFO - 2024-02-07 20:41:34 --> Form Validation Class Initialized
INFO - 2024-02-07 20:41:34 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:41:34 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:41:34 --> Config Class Initialized
INFO - 2024-02-07 20:41:34 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:41:34 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:41:34 --> Utf8 Class Initialized
INFO - 2024-02-07 20:41:34 --> URI Class Initialized
INFO - 2024-02-07 20:41:34 --> Router Class Initialized
INFO - 2024-02-07 20:41:34 --> Output Class Initialized
INFO - 2024-02-07 20:41:34 --> Security Class Initialized
DEBUG - 2024-02-07 20:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:41:34 --> Input Class Initialized
INFO - 2024-02-07 20:41:34 --> Language Class Initialized
INFO - 2024-02-07 20:41:34 --> Loader Class Initialized
INFO - 2024-02-07 20:41:34 --> Helper loaded: url_helper
INFO - 2024-02-07 20:41:34 --> Helper loaded: file_helper
INFO - 2024-02-07 20:41:34 --> Helper loaded: form_helper
INFO - 2024-02-07 20:41:34 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:41:34 --> Controller Class Initialized
INFO - 2024-02-07 20:41:34 --> Form Validation Class Initialized
INFO - 2024-02-07 20:41:34 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:41:34 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:41:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:41:40 --> Config Class Initialized
INFO - 2024-02-07 20:41:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:41:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:41:40 --> Utf8 Class Initialized
INFO - 2024-02-07 20:41:40 --> URI Class Initialized
INFO - 2024-02-07 20:41:40 --> Router Class Initialized
INFO - 2024-02-07 20:41:40 --> Output Class Initialized
INFO - 2024-02-07 20:41:40 --> Security Class Initialized
DEBUG - 2024-02-07 20:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:41:40 --> Input Class Initialized
INFO - 2024-02-07 20:41:40 --> Language Class Initialized
INFO - 2024-02-07 20:41:40 --> Loader Class Initialized
INFO - 2024-02-07 20:41:40 --> Helper loaded: url_helper
INFO - 2024-02-07 20:41:40 --> Helper loaded: file_helper
INFO - 2024-02-07 20:41:40 --> Helper loaded: form_helper
INFO - 2024-02-07 20:41:40 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:41:40 --> Controller Class Initialized
INFO - 2024-02-07 20:41:40 --> Form Validation Class Initialized
INFO - 2024-02-07 20:41:40 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:41:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:41:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:41:40 --> Final output sent to browser
DEBUG - 2024-02-07 20:41:40 --> Total execution time: 0.0323
ERROR - 2024-02-07 20:41:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:41:42 --> Config Class Initialized
INFO - 2024-02-07 20:41:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:41:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:41:42 --> Utf8 Class Initialized
INFO - 2024-02-07 20:41:42 --> URI Class Initialized
INFO - 2024-02-07 20:41:42 --> Router Class Initialized
INFO - 2024-02-07 20:41:43 --> Output Class Initialized
INFO - 2024-02-07 20:41:43 --> Security Class Initialized
DEBUG - 2024-02-07 20:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:41:43 --> Input Class Initialized
INFO - 2024-02-07 20:41:43 --> Language Class Initialized
INFO - 2024-02-07 20:41:43 --> Loader Class Initialized
INFO - 2024-02-07 20:41:43 --> Helper loaded: url_helper
INFO - 2024-02-07 20:41:43 --> Helper loaded: file_helper
INFO - 2024-02-07 20:41:43 --> Helper loaded: form_helper
INFO - 2024-02-07 20:41:43 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:41:43 --> Controller Class Initialized
INFO - 2024-02-07 20:41:43 --> Form Validation Class Initialized
INFO - 2024-02-07 20:41:43 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:41:43 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:41:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:41:46 --> Config Class Initialized
INFO - 2024-02-07 20:41:46 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:41:46 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:41:46 --> Utf8 Class Initialized
INFO - 2024-02-07 20:41:46 --> URI Class Initialized
INFO - 2024-02-07 20:41:46 --> Router Class Initialized
INFO - 2024-02-07 20:41:46 --> Output Class Initialized
INFO - 2024-02-07 20:41:46 --> Security Class Initialized
DEBUG - 2024-02-07 20:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:41:46 --> Input Class Initialized
INFO - 2024-02-07 20:41:46 --> Language Class Initialized
INFO - 2024-02-07 20:41:46 --> Loader Class Initialized
INFO - 2024-02-07 20:41:46 --> Helper loaded: url_helper
INFO - 2024-02-07 20:41:46 --> Helper loaded: file_helper
INFO - 2024-02-07 20:41:46 --> Helper loaded: form_helper
INFO - 2024-02-07 20:41:46 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:41:46 --> Controller Class Initialized
INFO - 2024-02-07 20:41:46 --> Form Validation Class Initialized
INFO - 2024-02-07 20:41:46 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:41:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:41:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:41:46 --> Final output sent to browser
DEBUG - 2024-02-07 20:41:46 --> Total execution time: 0.0341
ERROR - 2024-02-07 20:41:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:41:49 --> Config Class Initialized
INFO - 2024-02-07 20:41:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:41:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:41:49 --> Utf8 Class Initialized
INFO - 2024-02-07 20:41:49 --> URI Class Initialized
INFO - 2024-02-07 20:41:49 --> Router Class Initialized
INFO - 2024-02-07 20:41:49 --> Output Class Initialized
INFO - 2024-02-07 20:41:49 --> Security Class Initialized
DEBUG - 2024-02-07 20:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:41:49 --> Input Class Initialized
INFO - 2024-02-07 20:41:49 --> Language Class Initialized
INFO - 2024-02-07 20:41:49 --> Loader Class Initialized
INFO - 2024-02-07 20:41:49 --> Helper loaded: url_helper
INFO - 2024-02-07 20:41:49 --> Helper loaded: file_helper
INFO - 2024-02-07 20:41:49 --> Helper loaded: form_helper
INFO - 2024-02-07 20:41:49 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:41:49 --> Controller Class Initialized
INFO - 2024-02-07 20:41:49 --> Form Validation Class Initialized
INFO - 2024-02-07 20:41:49 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:41:49 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:41:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:41:49 --> Config Class Initialized
INFO - 2024-02-07 20:41:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:41:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:41:49 --> Utf8 Class Initialized
INFO - 2024-02-07 20:41:49 --> URI Class Initialized
INFO - 2024-02-07 20:41:49 --> Router Class Initialized
INFO - 2024-02-07 20:41:49 --> Output Class Initialized
INFO - 2024-02-07 20:41:49 --> Security Class Initialized
DEBUG - 2024-02-07 20:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:41:49 --> Input Class Initialized
INFO - 2024-02-07 20:41:49 --> Language Class Initialized
INFO - 2024-02-07 20:41:49 --> Loader Class Initialized
INFO - 2024-02-07 20:41:49 --> Helper loaded: url_helper
INFO - 2024-02-07 20:41:49 --> Helper loaded: file_helper
INFO - 2024-02-07 20:41:49 --> Helper loaded: form_helper
INFO - 2024-02-07 20:41:49 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:41:49 --> Controller Class Initialized
INFO - 2024-02-07 20:41:49 --> Form Validation Class Initialized
INFO - 2024-02-07 20:41:49 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:41:49 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:42:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:42:24 --> Config Class Initialized
INFO - 2024-02-07 20:42:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:42:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:42:24 --> Utf8 Class Initialized
INFO - 2024-02-07 20:42:24 --> URI Class Initialized
INFO - 2024-02-07 20:42:24 --> Router Class Initialized
INFO - 2024-02-07 20:42:24 --> Output Class Initialized
INFO - 2024-02-07 20:42:24 --> Security Class Initialized
DEBUG - 2024-02-07 20:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:42:24 --> Input Class Initialized
INFO - 2024-02-07 20:42:24 --> Language Class Initialized
INFO - 2024-02-07 20:42:24 --> Loader Class Initialized
INFO - 2024-02-07 20:42:24 --> Helper loaded: url_helper
INFO - 2024-02-07 20:42:24 --> Helper loaded: file_helper
INFO - 2024-02-07 20:42:24 --> Helper loaded: form_helper
INFO - 2024-02-07 20:42:24 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:42:24 --> Controller Class Initialized
INFO - 2024-02-07 20:42:24 --> Form Validation Class Initialized
INFO - 2024-02-07 20:42:24 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:42:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:42:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:42:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:42:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:42:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:42:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:42:24 --> Final output sent to browser
DEBUG - 2024-02-07 20:42:24 --> Total execution time: 0.0249
ERROR - 2024-02-07 20:42:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-07 20:42:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:42:24 --> Config Class Initialized
INFO - 2024-02-07 20:42:24 --> Hooks Class Initialized
INFO - 2024-02-07 20:42:24 --> Config Class Initialized
INFO - 2024-02-07 20:42:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:42:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:42:24 --> Utf8 Class Initialized
DEBUG - 2024-02-07 20:42:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:42:24 --> Utf8 Class Initialized
INFO - 2024-02-07 20:42:24 --> URI Class Initialized
INFO - 2024-02-07 20:42:24 --> URI Class Initialized
INFO - 2024-02-07 20:42:24 --> Router Class Initialized
INFO - 2024-02-07 20:42:24 --> Router Class Initialized
INFO - 2024-02-07 20:42:24 --> Output Class Initialized
INFO - 2024-02-07 20:42:24 --> Output Class Initialized
INFO - 2024-02-07 20:42:24 --> Security Class Initialized
INFO - 2024-02-07 20:42:24 --> Security Class Initialized
DEBUG - 2024-02-07 20:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:42:24 --> Input Class Initialized
DEBUG - 2024-02-07 20:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:42:24 --> Input Class Initialized
INFO - 2024-02-07 20:42:24 --> Language Class Initialized
INFO - 2024-02-07 20:42:24 --> Language Class Initialized
INFO - 2024-02-07 20:42:24 --> Loader Class Initialized
INFO - 2024-02-07 20:42:24 --> Loader Class Initialized
INFO - 2024-02-07 20:42:24 --> Helper loaded: url_helper
INFO - 2024-02-07 20:42:24 --> Helper loaded: file_helper
INFO - 2024-02-07 20:42:24 --> Helper loaded: url_helper
INFO - 2024-02-07 20:42:24 --> Helper loaded: file_helper
INFO - 2024-02-07 20:42:24 --> Helper loaded: form_helper
INFO - 2024-02-07 20:42:24 --> Helper loaded: form_helper
INFO - 2024-02-07 20:42:24 --> Database Driver Class Initialized
INFO - 2024-02-07 20:42:24 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 20:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:42:24 --> Controller Class Initialized
INFO - 2024-02-07 20:42:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:42:24 --> Final output sent to browser
DEBUG - 2024-02-07 20:42:24 --> Total execution time: 0.0198
INFO - 2024-02-07 20:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:42:24 --> Controller Class Initialized
INFO - 2024-02-07 20:42:24 --> Form Validation Class Initialized
INFO - 2024-02-07 20:42:24 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:42:24 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:42:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:42:28 --> Config Class Initialized
INFO - 2024-02-07 20:42:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:42:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:42:28 --> Utf8 Class Initialized
INFO - 2024-02-07 20:42:28 --> URI Class Initialized
INFO - 2024-02-07 20:42:28 --> Router Class Initialized
INFO - 2024-02-07 20:42:28 --> Output Class Initialized
INFO - 2024-02-07 20:42:28 --> Security Class Initialized
DEBUG - 2024-02-07 20:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:42:28 --> Input Class Initialized
INFO - 2024-02-07 20:42:28 --> Language Class Initialized
INFO - 2024-02-07 20:42:28 --> Loader Class Initialized
INFO - 2024-02-07 20:42:28 --> Helper loaded: url_helper
INFO - 2024-02-07 20:42:28 --> Helper loaded: file_helper
INFO - 2024-02-07 20:42:28 --> Helper loaded: form_helper
INFO - 2024-02-07 20:42:28 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:42:28 --> Controller Class Initialized
INFO - 2024-02-07 20:42:28 --> Form Validation Class Initialized
INFO - 2024-02-07 20:42:28 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:42:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:42:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:42:28 --> Final output sent to browser
DEBUG - 2024-02-07 20:42:28 --> Total execution time: 0.0344
ERROR - 2024-02-07 20:42:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:42:30 --> Config Class Initialized
INFO - 2024-02-07 20:42:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:42:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:42:30 --> Utf8 Class Initialized
INFO - 2024-02-07 20:42:30 --> URI Class Initialized
INFO - 2024-02-07 20:42:30 --> Router Class Initialized
INFO - 2024-02-07 20:42:30 --> Output Class Initialized
INFO - 2024-02-07 20:42:30 --> Security Class Initialized
DEBUG - 2024-02-07 20:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:42:30 --> Input Class Initialized
INFO - 2024-02-07 20:42:30 --> Language Class Initialized
INFO - 2024-02-07 20:42:30 --> Loader Class Initialized
INFO - 2024-02-07 20:42:30 --> Helper loaded: url_helper
INFO - 2024-02-07 20:42:30 --> Helper loaded: file_helper
INFO - 2024-02-07 20:42:30 --> Helper loaded: form_helper
INFO - 2024-02-07 20:42:30 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:42:30 --> Controller Class Initialized
INFO - 2024-02-07 20:42:30 --> Form Validation Class Initialized
INFO - 2024-02-07 20:42:30 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:42:30 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:42:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:42:30 --> Config Class Initialized
INFO - 2024-02-07 20:42:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:42:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:42:30 --> Utf8 Class Initialized
INFO - 2024-02-07 20:42:30 --> URI Class Initialized
INFO - 2024-02-07 20:42:30 --> Router Class Initialized
INFO - 2024-02-07 20:42:30 --> Output Class Initialized
INFO - 2024-02-07 20:42:30 --> Security Class Initialized
DEBUG - 2024-02-07 20:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:42:30 --> Input Class Initialized
INFO - 2024-02-07 20:42:30 --> Language Class Initialized
INFO - 2024-02-07 20:42:30 --> Loader Class Initialized
INFO - 2024-02-07 20:42:30 --> Helper loaded: url_helper
INFO - 2024-02-07 20:42:30 --> Helper loaded: file_helper
INFO - 2024-02-07 20:42:30 --> Helper loaded: form_helper
INFO - 2024-02-07 20:42:30 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:42:30 --> Controller Class Initialized
INFO - 2024-02-07 20:42:30 --> Form Validation Class Initialized
INFO - 2024-02-07 20:42:30 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:42:30 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:42:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:42:56 --> Config Class Initialized
INFO - 2024-02-07 20:42:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:42:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:42:56 --> Utf8 Class Initialized
INFO - 2024-02-07 20:42:56 --> URI Class Initialized
INFO - 2024-02-07 20:42:56 --> Router Class Initialized
INFO - 2024-02-07 20:42:56 --> Output Class Initialized
INFO - 2024-02-07 20:42:56 --> Security Class Initialized
DEBUG - 2024-02-07 20:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:42:56 --> Input Class Initialized
INFO - 2024-02-07 20:42:56 --> Language Class Initialized
INFO - 2024-02-07 20:42:56 --> Loader Class Initialized
INFO - 2024-02-07 20:42:56 --> Helper loaded: url_helper
INFO - 2024-02-07 20:42:56 --> Helper loaded: file_helper
INFO - 2024-02-07 20:42:56 --> Helper loaded: form_helper
INFO - 2024-02-07 20:42:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:42:56 --> Controller Class Initialized
INFO - 2024-02-07 20:42:56 --> Form Validation Class Initialized
INFO - 2024-02-07 20:42:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:42:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:42:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:42:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:42:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:42:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:42:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:42:56 --> Final output sent to browser
DEBUG - 2024-02-07 20:42:56 --> Total execution time: 0.0293
ERROR - 2024-02-07 20:42:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:42:56 --> Config Class Initialized
INFO - 2024-02-07 20:42:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:42:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:42:56 --> Utf8 Class Initialized
INFO - 2024-02-07 20:42:56 --> URI Class Initialized
INFO - 2024-02-07 20:42:56 --> Router Class Initialized
INFO - 2024-02-07 20:42:56 --> Output Class Initialized
INFO - 2024-02-07 20:42:56 --> Security Class Initialized
DEBUG - 2024-02-07 20:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:42:56 --> Input Class Initialized
INFO - 2024-02-07 20:42:56 --> Language Class Initialized
INFO - 2024-02-07 20:42:56 --> Loader Class Initialized
INFO - 2024-02-07 20:42:56 --> Helper loaded: url_helper
INFO - 2024-02-07 20:42:56 --> Helper loaded: file_helper
INFO - 2024-02-07 20:42:56 --> Helper loaded: form_helper
INFO - 2024-02-07 20:42:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:42:56 --> Controller Class Initialized
INFO - 2024-02-07 20:42:56 --> Form Validation Class Initialized
INFO - 2024-02-07 20:42:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:42:56 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:42:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:42:57 --> Config Class Initialized
INFO - 2024-02-07 20:42:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:42:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:42:57 --> Utf8 Class Initialized
INFO - 2024-02-07 20:42:57 --> URI Class Initialized
INFO - 2024-02-07 20:42:57 --> Router Class Initialized
INFO - 2024-02-07 20:42:57 --> Output Class Initialized
INFO - 2024-02-07 20:42:57 --> Security Class Initialized
DEBUG - 2024-02-07 20:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:42:57 --> Input Class Initialized
INFO - 2024-02-07 20:42:57 --> Language Class Initialized
INFO - 2024-02-07 20:42:57 --> Loader Class Initialized
INFO - 2024-02-07 20:42:57 --> Helper loaded: url_helper
INFO - 2024-02-07 20:42:57 --> Helper loaded: file_helper
INFO - 2024-02-07 20:42:57 --> Helper loaded: form_helper
INFO - 2024-02-07 20:42:57 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:42:57 --> Controller Class Initialized
INFO - 2024-02-07 20:42:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:42:57 --> Final output sent to browser
DEBUG - 2024-02-07 20:42:57 --> Total execution time: 0.0256
ERROR - 2024-02-07 20:43:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:00 --> Config Class Initialized
INFO - 2024-02-07 20:43:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:00 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:00 --> URI Class Initialized
INFO - 2024-02-07 20:43:00 --> Router Class Initialized
INFO - 2024-02-07 20:43:00 --> Output Class Initialized
INFO - 2024-02-07 20:43:00 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:00 --> Input Class Initialized
INFO - 2024-02-07 20:43:00 --> Language Class Initialized
INFO - 2024-02-07 20:43:00 --> Loader Class Initialized
INFO - 2024-02-07 20:43:00 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:00 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:00 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:00 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:00 --> Controller Class Initialized
INFO - 2024-02-07 20:43:00 --> Form Validation Class Initialized
INFO - 2024-02-07 20:43:00 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:43:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:43:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:43:00 --> Final output sent to browser
DEBUG - 2024-02-07 20:43:00 --> Total execution time: 0.0372
ERROR - 2024-02-07 20:43:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:02 --> Config Class Initialized
INFO - 2024-02-07 20:43:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:02 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:02 --> URI Class Initialized
INFO - 2024-02-07 20:43:02 --> Router Class Initialized
INFO - 2024-02-07 20:43:02 --> Output Class Initialized
INFO - 2024-02-07 20:43:02 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:02 --> Input Class Initialized
INFO - 2024-02-07 20:43:02 --> Language Class Initialized
INFO - 2024-02-07 20:43:02 --> Loader Class Initialized
INFO - 2024-02-07 20:43:02 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:02 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:02 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:02 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:02 --> Controller Class Initialized
INFO - 2024-02-07 20:43:02 --> Form Validation Class Initialized
INFO - 2024-02-07 20:43:02 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:43:02 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:43:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:02 --> Config Class Initialized
INFO - 2024-02-07 20:43:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:02 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:02 --> URI Class Initialized
INFO - 2024-02-07 20:43:02 --> Router Class Initialized
INFO - 2024-02-07 20:43:02 --> Output Class Initialized
INFO - 2024-02-07 20:43:02 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:02 --> Input Class Initialized
INFO - 2024-02-07 20:43:02 --> Language Class Initialized
INFO - 2024-02-07 20:43:02 --> Loader Class Initialized
INFO - 2024-02-07 20:43:02 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:02 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:02 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:02 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:02 --> Controller Class Initialized
INFO - 2024-02-07 20:43:02 --> Form Validation Class Initialized
INFO - 2024-02-07 20:43:02 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:43:02 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:43:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:08 --> Config Class Initialized
INFO - 2024-02-07 20:43:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:08 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:08 --> URI Class Initialized
INFO - 2024-02-07 20:43:08 --> Router Class Initialized
INFO - 2024-02-07 20:43:08 --> Output Class Initialized
INFO - 2024-02-07 20:43:08 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:08 --> Input Class Initialized
INFO - 2024-02-07 20:43:08 --> Language Class Initialized
INFO - 2024-02-07 20:43:08 --> Loader Class Initialized
INFO - 2024-02-07 20:43:08 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:08 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:08 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:08 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:08 --> Controller Class Initialized
INFO - 2024-02-07 20:43:08 --> Form Validation Class Initialized
INFO - 2024-02-07 20:43:08 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:43:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:43:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:43:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:43:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:43:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:43:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:43:08 --> Final output sent to browser
DEBUG - 2024-02-07 20:43:08 --> Total execution time: 0.0363
ERROR - 2024-02-07 20:43:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:08 --> Config Class Initialized
INFO - 2024-02-07 20:43:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:08 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:08 --> URI Class Initialized
INFO - 2024-02-07 20:43:08 --> Router Class Initialized
INFO - 2024-02-07 20:43:08 --> Output Class Initialized
INFO - 2024-02-07 20:43:08 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:08 --> Input Class Initialized
INFO - 2024-02-07 20:43:08 --> Language Class Initialized
INFO - 2024-02-07 20:43:08 --> Loader Class Initialized
INFO - 2024-02-07 20:43:08 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:08 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:08 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:08 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:08 --> Controller Class Initialized
INFO - 2024-02-07 20:43:08 --> Form Validation Class Initialized
INFO - 2024-02-07 20:43:08 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:43:08 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:43:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:08 --> Config Class Initialized
INFO - 2024-02-07 20:43:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:08 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:08 --> URI Class Initialized
INFO - 2024-02-07 20:43:08 --> Router Class Initialized
INFO - 2024-02-07 20:43:08 --> Output Class Initialized
INFO - 2024-02-07 20:43:08 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:08 --> Input Class Initialized
INFO - 2024-02-07 20:43:08 --> Language Class Initialized
INFO - 2024-02-07 20:43:08 --> Loader Class Initialized
INFO - 2024-02-07 20:43:08 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:08 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:08 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:08 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:08 --> Controller Class Initialized
INFO - 2024-02-07 20:43:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:43:08 --> Final output sent to browser
DEBUG - 2024-02-07 20:43:08 --> Total execution time: 0.0462
ERROR - 2024-02-07 20:43:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:11 --> Config Class Initialized
INFO - 2024-02-07 20:43:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:11 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:11 --> URI Class Initialized
INFO - 2024-02-07 20:43:11 --> Router Class Initialized
INFO - 2024-02-07 20:43:11 --> Output Class Initialized
INFO - 2024-02-07 20:43:11 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:11 --> Input Class Initialized
INFO - 2024-02-07 20:43:11 --> Language Class Initialized
INFO - 2024-02-07 20:43:11 --> Loader Class Initialized
INFO - 2024-02-07 20:43:11 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:11 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:11 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:11 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:11 --> Controller Class Initialized
INFO - 2024-02-07 20:43:11 --> Form Validation Class Initialized
INFO - 2024-02-07 20:43:11 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:43:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:43:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:43:11 --> Final output sent to browser
DEBUG - 2024-02-07 20:43:11 --> Total execution time: 0.0266
ERROR - 2024-02-07 20:43:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:13 --> Config Class Initialized
INFO - 2024-02-07 20:43:13 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:13 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:13 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:13 --> URI Class Initialized
INFO - 2024-02-07 20:43:13 --> Router Class Initialized
INFO - 2024-02-07 20:43:13 --> Output Class Initialized
INFO - 2024-02-07 20:43:13 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:13 --> Input Class Initialized
INFO - 2024-02-07 20:43:13 --> Language Class Initialized
INFO - 2024-02-07 20:43:13 --> Loader Class Initialized
INFO - 2024-02-07 20:43:13 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:13 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:13 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:13 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:13 --> Controller Class Initialized
INFO - 2024-02-07 20:43:13 --> Form Validation Class Initialized
INFO - 2024-02-07 20:43:13 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:43:13 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:43:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:13 --> Config Class Initialized
INFO - 2024-02-07 20:43:13 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:13 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:13 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:13 --> URI Class Initialized
INFO - 2024-02-07 20:43:13 --> Router Class Initialized
INFO - 2024-02-07 20:43:13 --> Output Class Initialized
INFO - 2024-02-07 20:43:13 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:13 --> Input Class Initialized
INFO - 2024-02-07 20:43:13 --> Language Class Initialized
INFO - 2024-02-07 20:43:13 --> Loader Class Initialized
INFO - 2024-02-07 20:43:13 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:13 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:13 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:13 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:13 --> Controller Class Initialized
INFO - 2024-02-07 20:43:13 --> Form Validation Class Initialized
INFO - 2024-02-07 20:43:13 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:43:13 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:43:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:30 --> Config Class Initialized
INFO - 2024-02-07 20:43:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:30 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:30 --> URI Class Initialized
INFO - 2024-02-07 20:43:30 --> Router Class Initialized
INFO - 2024-02-07 20:43:30 --> Output Class Initialized
INFO - 2024-02-07 20:43:30 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:30 --> Input Class Initialized
INFO - 2024-02-07 20:43:30 --> Language Class Initialized
INFO - 2024-02-07 20:43:30 --> Loader Class Initialized
INFO - 2024-02-07 20:43:30 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:30 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:30 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:30 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:30 --> Controller Class Initialized
INFO - 2024-02-07 20:43:30 --> Form Validation Class Initialized
INFO - 2024-02-07 20:43:30 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:43:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:43:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:43:30 --> Final output sent to browser
DEBUG - 2024-02-07 20:43:30 --> Total execution time: 0.0279
ERROR - 2024-02-07 20:43:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:35 --> Config Class Initialized
INFO - 2024-02-07 20:43:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:35 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:35 --> URI Class Initialized
INFO - 2024-02-07 20:43:35 --> Router Class Initialized
INFO - 2024-02-07 20:43:35 --> Output Class Initialized
INFO - 2024-02-07 20:43:35 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:35 --> Input Class Initialized
INFO - 2024-02-07 20:43:35 --> Language Class Initialized
INFO - 2024-02-07 20:43:35 --> Loader Class Initialized
INFO - 2024-02-07 20:43:35 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:35 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:35 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:35 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:35 --> Controller Class Initialized
INFO - 2024-02-07 20:43:35 --> Form Validation Class Initialized
INFO - 2024-02-07 20:43:35 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:43:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:43:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:43:35 --> Final output sent to browser
DEBUG - 2024-02-07 20:43:35 --> Total execution time: 0.0281
ERROR - 2024-02-07 20:43:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:37 --> Config Class Initialized
INFO - 2024-02-07 20:43:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:37 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:37 --> URI Class Initialized
INFO - 2024-02-07 20:43:37 --> Router Class Initialized
INFO - 2024-02-07 20:43:37 --> Output Class Initialized
INFO - 2024-02-07 20:43:37 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:37 --> Input Class Initialized
INFO - 2024-02-07 20:43:37 --> Language Class Initialized
INFO - 2024-02-07 20:43:37 --> Loader Class Initialized
INFO - 2024-02-07 20:43:37 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:37 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:37 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:37 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:37 --> Controller Class Initialized
INFO - 2024-02-07 20:43:37 --> Form Validation Class Initialized
INFO - 2024-02-07 20:43:37 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:43:37 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:43:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:43:37 --> Config Class Initialized
INFO - 2024-02-07 20:43:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:43:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:43:37 --> Utf8 Class Initialized
INFO - 2024-02-07 20:43:37 --> URI Class Initialized
INFO - 2024-02-07 20:43:37 --> Router Class Initialized
INFO - 2024-02-07 20:43:37 --> Output Class Initialized
INFO - 2024-02-07 20:43:37 --> Security Class Initialized
DEBUG - 2024-02-07 20:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:43:37 --> Input Class Initialized
INFO - 2024-02-07 20:43:37 --> Language Class Initialized
INFO - 2024-02-07 20:43:37 --> Loader Class Initialized
INFO - 2024-02-07 20:43:37 --> Helper loaded: url_helper
INFO - 2024-02-07 20:43:37 --> Helper loaded: file_helper
INFO - 2024-02-07 20:43:37 --> Helper loaded: form_helper
INFO - 2024-02-07 20:43:37 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:43:37 --> Controller Class Initialized
INFO - 2024-02-07 20:43:37 --> Form Validation Class Initialized
INFO - 2024-02-07 20:43:37 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:43:37 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:44:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:44:11 --> Config Class Initialized
INFO - 2024-02-07 20:44:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:44:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:44:11 --> Utf8 Class Initialized
INFO - 2024-02-07 20:44:11 --> URI Class Initialized
INFO - 2024-02-07 20:44:11 --> Router Class Initialized
INFO - 2024-02-07 20:44:11 --> Output Class Initialized
INFO - 2024-02-07 20:44:11 --> Security Class Initialized
DEBUG - 2024-02-07 20:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:44:11 --> Input Class Initialized
INFO - 2024-02-07 20:44:11 --> Language Class Initialized
INFO - 2024-02-07 20:44:11 --> Loader Class Initialized
INFO - 2024-02-07 20:44:11 --> Helper loaded: url_helper
INFO - 2024-02-07 20:44:11 --> Helper loaded: file_helper
INFO - 2024-02-07 20:44:11 --> Helper loaded: form_helper
INFO - 2024-02-07 20:44:11 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:44:11 --> Controller Class Initialized
INFO - 2024-02-07 20:44:11 --> Form Validation Class Initialized
INFO - 2024-02-07 20:44:11 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:44:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:44:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:44:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:44:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:44:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:44:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:44:11 --> Final output sent to browser
DEBUG - 2024-02-07 20:44:11 --> Total execution time: 0.0318
ERROR - 2024-02-07 20:44:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-07 20:44:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:44:12 --> Config Class Initialized
INFO - 2024-02-07 20:44:12 --> Hooks Class Initialized
INFO - 2024-02-07 20:44:12 --> Config Class Initialized
INFO - 2024-02-07 20:44:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:44:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:44:12 --> Utf8 Class Initialized
DEBUG - 2024-02-07 20:44:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:44:12 --> Utf8 Class Initialized
INFO - 2024-02-07 20:44:12 --> URI Class Initialized
INFO - 2024-02-07 20:44:12 --> URI Class Initialized
INFO - 2024-02-07 20:44:12 --> Router Class Initialized
INFO - 2024-02-07 20:44:12 --> Router Class Initialized
INFO - 2024-02-07 20:44:12 --> Output Class Initialized
INFO - 2024-02-07 20:44:12 --> Output Class Initialized
INFO - 2024-02-07 20:44:12 --> Security Class Initialized
INFO - 2024-02-07 20:44:12 --> Security Class Initialized
DEBUG - 2024-02-07 20:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:44:12 --> Input Class Initialized
INFO - 2024-02-07 20:44:12 --> Language Class Initialized
DEBUG - 2024-02-07 20:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:44:12 --> Input Class Initialized
INFO - 2024-02-07 20:44:12 --> Language Class Initialized
INFO - 2024-02-07 20:44:12 --> Loader Class Initialized
INFO - 2024-02-07 20:44:12 --> Loader Class Initialized
INFO - 2024-02-07 20:44:12 --> Helper loaded: url_helper
INFO - 2024-02-07 20:44:12 --> Helper loaded: file_helper
INFO - 2024-02-07 20:44:12 --> Helper loaded: url_helper
INFO - 2024-02-07 20:44:12 --> Helper loaded: file_helper
INFO - 2024-02-07 20:44:12 --> Helper loaded: form_helper
INFO - 2024-02-07 20:44:12 --> Helper loaded: form_helper
INFO - 2024-02-07 20:44:12 --> Database Driver Class Initialized
INFO - 2024-02-07 20:44:12 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:44:12 --> Controller Class Initialized
DEBUG - 2024-02-07 20:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:44:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:44:12 --> Final output sent to browser
DEBUG - 2024-02-07 20:44:12 --> Total execution time: 0.0262
INFO - 2024-02-07 20:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:44:12 --> Controller Class Initialized
INFO - 2024-02-07 20:44:12 --> Form Validation Class Initialized
INFO - 2024-02-07 20:44:12 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:44:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:44:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:44:15 --> Config Class Initialized
INFO - 2024-02-07 20:44:15 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:44:15 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:44:15 --> Utf8 Class Initialized
INFO - 2024-02-07 20:44:15 --> URI Class Initialized
INFO - 2024-02-07 20:44:15 --> Router Class Initialized
INFO - 2024-02-07 20:44:15 --> Output Class Initialized
INFO - 2024-02-07 20:44:15 --> Security Class Initialized
DEBUG - 2024-02-07 20:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:44:15 --> Input Class Initialized
INFO - 2024-02-07 20:44:15 --> Language Class Initialized
INFO - 2024-02-07 20:44:15 --> Loader Class Initialized
INFO - 2024-02-07 20:44:15 --> Helper loaded: url_helper
INFO - 2024-02-07 20:44:15 --> Helper loaded: file_helper
INFO - 2024-02-07 20:44:15 --> Helper loaded: form_helper
INFO - 2024-02-07 20:44:15 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:44:15 --> Controller Class Initialized
INFO - 2024-02-07 20:44:15 --> Form Validation Class Initialized
INFO - 2024-02-07 20:44:15 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:44:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:44:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 20:44:15 --> Final output sent to browser
DEBUG - 2024-02-07 20:44:15 --> Total execution time: 0.0291
ERROR - 2024-02-07 20:44:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:44:17 --> Config Class Initialized
INFO - 2024-02-07 20:44:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:44:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:44:17 --> Utf8 Class Initialized
INFO - 2024-02-07 20:44:17 --> URI Class Initialized
INFO - 2024-02-07 20:44:17 --> Router Class Initialized
INFO - 2024-02-07 20:44:17 --> Output Class Initialized
INFO - 2024-02-07 20:44:17 --> Security Class Initialized
DEBUG - 2024-02-07 20:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:44:17 --> Input Class Initialized
INFO - 2024-02-07 20:44:17 --> Language Class Initialized
INFO - 2024-02-07 20:44:17 --> Loader Class Initialized
INFO - 2024-02-07 20:44:17 --> Helper loaded: url_helper
INFO - 2024-02-07 20:44:17 --> Helper loaded: file_helper
INFO - 2024-02-07 20:44:17 --> Helper loaded: form_helper
INFO - 2024-02-07 20:44:17 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:44:17 --> Controller Class Initialized
INFO - 2024-02-07 20:44:17 --> Form Validation Class Initialized
INFO - 2024-02-07 20:44:17 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:44:17 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:44:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:44:17 --> Config Class Initialized
INFO - 2024-02-07 20:44:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:44:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:44:17 --> Utf8 Class Initialized
INFO - 2024-02-07 20:44:17 --> URI Class Initialized
INFO - 2024-02-07 20:44:17 --> Router Class Initialized
INFO - 2024-02-07 20:44:17 --> Output Class Initialized
INFO - 2024-02-07 20:44:17 --> Security Class Initialized
DEBUG - 2024-02-07 20:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:44:17 --> Input Class Initialized
INFO - 2024-02-07 20:44:17 --> Language Class Initialized
INFO - 2024-02-07 20:44:17 --> Loader Class Initialized
INFO - 2024-02-07 20:44:17 --> Helper loaded: url_helper
INFO - 2024-02-07 20:44:17 --> Helper loaded: file_helper
INFO - 2024-02-07 20:44:17 --> Helper loaded: form_helper
INFO - 2024-02-07 20:44:17 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:44:17 --> Controller Class Initialized
INFO - 2024-02-07 20:44:17 --> Form Validation Class Initialized
INFO - 2024-02-07 20:44:17 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:44:17 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:58:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:58:43 --> Config Class Initialized
INFO - 2024-02-07 20:58:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:58:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:58:43 --> Utf8 Class Initialized
INFO - 2024-02-07 20:58:43 --> URI Class Initialized
INFO - 2024-02-07 20:58:43 --> Router Class Initialized
INFO - 2024-02-07 20:58:43 --> Output Class Initialized
INFO - 2024-02-07 20:58:43 --> Security Class Initialized
DEBUG - 2024-02-07 20:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:58:43 --> Input Class Initialized
INFO - 2024-02-07 20:58:43 --> Language Class Initialized
INFO - 2024-02-07 20:58:43 --> Loader Class Initialized
INFO - 2024-02-07 20:58:43 --> Helper loaded: url_helper
INFO - 2024-02-07 20:58:43 --> Helper loaded: file_helper
INFO - 2024-02-07 20:58:43 --> Helper loaded: form_helper
INFO - 2024-02-07 20:58:43 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:58:43 --> Controller Class Initialized
INFO - 2024-02-07 20:58:43 --> Form Validation Class Initialized
INFO - 2024-02-07 20:58:43 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:58:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:58:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:58:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:58:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:58:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:58:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:58:43 --> Final output sent to browser
DEBUG - 2024-02-07 20:58:43 --> Total execution time: 0.0345
ERROR - 2024-02-07 20:58:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:58:43 --> Config Class Initialized
INFO - 2024-02-07 20:58:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:58:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:58:43 --> Utf8 Class Initialized
INFO - 2024-02-07 20:58:43 --> URI Class Initialized
INFO - 2024-02-07 20:58:43 --> Router Class Initialized
INFO - 2024-02-07 20:58:43 --> Output Class Initialized
INFO - 2024-02-07 20:58:43 --> Security Class Initialized
DEBUG - 2024-02-07 20:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:58:43 --> Input Class Initialized
INFO - 2024-02-07 20:58:43 --> Language Class Initialized
INFO - 2024-02-07 20:58:43 --> Loader Class Initialized
INFO - 2024-02-07 20:58:43 --> Helper loaded: url_helper
INFO - 2024-02-07 20:58:43 --> Helper loaded: file_helper
INFO - 2024-02-07 20:58:43 --> Helper loaded: form_helper
ERROR - 2024-02-07 20:58:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:58:43 --> Database Driver Class Initialized
INFO - 2024-02-07 20:58:43 --> Config Class Initialized
INFO - 2024-02-07 20:58:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:58:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:58:43 --> Utf8 Class Initialized
DEBUG - 2024-02-07 20:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:58:43 --> URI Class Initialized
INFO - 2024-02-07 20:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:58:43 --> Controller Class Initialized
INFO - 2024-02-07 20:58:43 --> Router Class Initialized
INFO - 2024-02-07 20:58:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:58:43 --> Final output sent to browser
DEBUG - 2024-02-07 20:58:43 --> Total execution time: 0.0304
INFO - 2024-02-07 20:58:43 --> Output Class Initialized
INFO - 2024-02-07 20:58:43 --> Security Class Initialized
DEBUG - 2024-02-07 20:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:58:43 --> Input Class Initialized
INFO - 2024-02-07 20:58:43 --> Language Class Initialized
INFO - 2024-02-07 20:58:43 --> Loader Class Initialized
INFO - 2024-02-07 20:58:43 --> Helper loaded: url_helper
INFO - 2024-02-07 20:58:43 --> Helper loaded: file_helper
INFO - 2024-02-07 20:58:43 --> Helper loaded: form_helper
INFO - 2024-02-07 20:58:43 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:58:43 --> Controller Class Initialized
INFO - 2024-02-07 20:58:43 --> Form Validation Class Initialized
INFO - 2024-02-07 20:58:43 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:58:43 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 20:59:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:59:01 --> Config Class Initialized
INFO - 2024-02-07 20:59:01 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:59:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:59:01 --> Utf8 Class Initialized
INFO - 2024-02-07 20:59:01 --> URI Class Initialized
INFO - 2024-02-07 20:59:01 --> Router Class Initialized
INFO - 2024-02-07 20:59:01 --> Output Class Initialized
INFO - 2024-02-07 20:59:01 --> Security Class Initialized
DEBUG - 2024-02-07 20:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:59:01 --> Input Class Initialized
INFO - 2024-02-07 20:59:01 --> Language Class Initialized
INFO - 2024-02-07 20:59:01 --> Loader Class Initialized
INFO - 2024-02-07 20:59:01 --> Helper loaded: url_helper
INFO - 2024-02-07 20:59:01 --> Helper loaded: file_helper
INFO - 2024-02-07 20:59:01 --> Helper loaded: form_helper
INFO - 2024-02-07 20:59:01 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:59:01 --> Controller Class Initialized
INFO - 2024-02-07 20:59:01 --> Form Validation Class Initialized
INFO - 2024-02-07 20:59:01 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:59:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 20:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 20:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 20:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 20:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 20:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 20:59:01 --> Final output sent to browser
DEBUG - 2024-02-07 20:59:01 --> Total execution time: 0.0285
ERROR - 2024-02-07 20:59:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:59:01 --> Config Class Initialized
INFO - 2024-02-07 20:59:01 --> Hooks Class Initialized
DEBUG - 2024-02-07 20:59:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:59:01 --> Utf8 Class Initialized
INFO - 2024-02-07 20:59:01 --> URI Class Initialized
INFO - 2024-02-07 20:59:01 --> Router Class Initialized
INFO - 2024-02-07 20:59:01 --> Output Class Initialized
INFO - 2024-02-07 20:59:01 --> Security Class Initialized
DEBUG - 2024-02-07 20:59:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 20:59:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 20:59:01 --> Input Class Initialized
INFO - 2024-02-07 20:59:01 --> Language Class Initialized
INFO - 2024-02-07 20:59:01 --> Config Class Initialized
INFO - 2024-02-07 20:59:01 --> Hooks Class Initialized
INFO - 2024-02-07 20:59:01 --> Loader Class Initialized
INFO - 2024-02-07 20:59:01 --> Helper loaded: url_helper
INFO - 2024-02-07 20:59:01 --> Helper loaded: file_helper
DEBUG - 2024-02-07 20:59:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 20:59:01 --> Utf8 Class Initialized
INFO - 2024-02-07 20:59:01 --> Helper loaded: form_helper
INFO - 2024-02-07 20:59:01 --> URI Class Initialized
INFO - 2024-02-07 20:59:01 --> Router Class Initialized
INFO - 2024-02-07 20:59:01 --> Output Class Initialized
INFO - 2024-02-07 20:59:01 --> Database Driver Class Initialized
INFO - 2024-02-07 20:59:01 --> Security Class Initialized
DEBUG - 2024-02-07 20:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 20:59:01 --> Input Class Initialized
INFO - 2024-02-07 20:59:01 --> Language Class Initialized
DEBUG - 2024-02-07 20:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:59:01 --> Loader Class Initialized
INFO - 2024-02-07 20:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:59:01 --> Controller Class Initialized
INFO - 2024-02-07 20:59:01 --> Helper loaded: url_helper
INFO - 2024-02-07 20:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 20:59:01 --> Final output sent to browser
DEBUG - 2024-02-07 20:59:01 --> Total execution time: 0.0203
INFO - 2024-02-07 20:59:01 --> Helper loaded: file_helper
INFO - 2024-02-07 20:59:01 --> Helper loaded: form_helper
INFO - 2024-02-07 20:59:01 --> Database Driver Class Initialized
DEBUG - 2024-02-07 20:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 20:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 20:59:01 --> Controller Class Initialized
INFO - 2024-02-07 20:59:01 --> Form Validation Class Initialized
INFO - 2024-02-07 20:59:01 --> Model "MasterModel" initialized
INFO - 2024-02-07 20:59:01 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:03:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:03:10 --> Config Class Initialized
INFO - 2024-02-07 21:03:10 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:03:10 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:03:10 --> Utf8 Class Initialized
INFO - 2024-02-07 21:03:10 --> URI Class Initialized
INFO - 2024-02-07 21:03:10 --> Router Class Initialized
INFO - 2024-02-07 21:03:10 --> Output Class Initialized
INFO - 2024-02-07 21:03:10 --> Security Class Initialized
DEBUG - 2024-02-07 21:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:03:10 --> Input Class Initialized
INFO - 2024-02-07 21:03:10 --> Language Class Initialized
INFO - 2024-02-07 21:03:10 --> Loader Class Initialized
INFO - 2024-02-07 21:03:10 --> Helper loaded: url_helper
INFO - 2024-02-07 21:03:10 --> Helper loaded: file_helper
INFO - 2024-02-07 21:03:11 --> Helper loaded: form_helper
INFO - 2024-02-07 21:03:11 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:03:11 --> Controller Class Initialized
INFO - 2024-02-07 21:03:11 --> Form Validation Class Initialized
INFO - 2024-02-07 21:03:11 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:03:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:03:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:03:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:03:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:03:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:03:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:03:11 --> Final output sent to browser
DEBUG - 2024-02-07 21:03:11 --> Total execution time: 0.0314
ERROR - 2024-02-07 21:03:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:03:11 --> Config Class Initialized
INFO - 2024-02-07 21:03:11 --> Hooks Class Initialized
ERROR - 2024-02-07 21:03:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2024-02-07 21:03:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:03:11 --> Utf8 Class Initialized
INFO - 2024-02-07 21:03:11 --> URI Class Initialized
INFO - 2024-02-07 21:03:11 --> Config Class Initialized
INFO - 2024-02-07 21:03:11 --> Hooks Class Initialized
INFO - 2024-02-07 21:03:11 --> Router Class Initialized
INFO - 2024-02-07 21:03:11 --> Output Class Initialized
DEBUG - 2024-02-07 21:03:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:03:11 --> Utf8 Class Initialized
INFO - 2024-02-07 21:03:11 --> Security Class Initialized
INFO - 2024-02-07 21:03:11 --> URI Class Initialized
DEBUG - 2024-02-07 21:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:03:11 --> Input Class Initialized
INFO - 2024-02-07 21:03:11 --> Router Class Initialized
INFO - 2024-02-07 21:03:11 --> Language Class Initialized
INFO - 2024-02-07 21:03:11 --> Loader Class Initialized
INFO - 2024-02-07 21:03:11 --> Output Class Initialized
INFO - 2024-02-07 21:03:11 --> Helper loaded: url_helper
INFO - 2024-02-07 21:03:11 --> Helper loaded: file_helper
INFO - 2024-02-07 21:03:11 --> Helper loaded: form_helper
INFO - 2024-02-07 21:03:11 --> Security Class Initialized
INFO - 2024-02-07 21:03:11 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:03:11 --> Input Class Initialized
INFO - 2024-02-07 21:03:11 --> Language Class Initialized
INFO - 2024-02-07 21:03:11 --> Loader Class Initialized
DEBUG - 2024-02-07 21:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:03:11 --> Helper loaded: url_helper
INFO - 2024-02-07 21:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:03:11 --> Controller Class Initialized
INFO - 2024-02-07 21:03:11 --> Helper loaded: file_helper
INFO - 2024-02-07 21:03:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:03:11 --> Final output sent to browser
DEBUG - 2024-02-07 21:03:11 --> Total execution time: 0.0343
INFO - 2024-02-07 21:03:11 --> Helper loaded: form_helper
INFO - 2024-02-07 21:03:11 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:03:11 --> Controller Class Initialized
INFO - 2024-02-07 21:03:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:03:11 --> Final output sent to browser
DEBUG - 2024-02-07 21:03:11 --> Total execution time: 0.0424
ERROR - 2024-02-07 21:03:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:03:11 --> Config Class Initialized
INFO - 2024-02-07 21:03:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:03:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:03:11 --> Utf8 Class Initialized
INFO - 2024-02-07 21:03:11 --> URI Class Initialized
INFO - 2024-02-07 21:03:11 --> Router Class Initialized
INFO - 2024-02-07 21:03:11 --> Output Class Initialized
INFO - 2024-02-07 21:03:11 --> Security Class Initialized
DEBUG - 2024-02-07 21:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:03:11 --> Input Class Initialized
INFO - 2024-02-07 21:03:11 --> Language Class Initialized
INFO - 2024-02-07 21:03:11 --> Loader Class Initialized
INFO - 2024-02-07 21:03:11 --> Helper loaded: url_helper
INFO - 2024-02-07 21:03:11 --> Helper loaded: file_helper
INFO - 2024-02-07 21:03:11 --> Helper loaded: form_helper
INFO - 2024-02-07 21:03:11 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:03:11 --> Controller Class Initialized
INFO - 2024-02-07 21:03:11 --> Form Validation Class Initialized
INFO - 2024-02-07 21:03:11 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:03:11 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:03:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:03:11 --> Config Class Initialized
INFO - 2024-02-07 21:03:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:03:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:03:11 --> Utf8 Class Initialized
INFO - 2024-02-07 21:03:11 --> URI Class Initialized
INFO - 2024-02-07 21:03:11 --> Router Class Initialized
INFO - 2024-02-07 21:03:11 --> Output Class Initialized
INFO - 2024-02-07 21:03:11 --> Security Class Initialized
DEBUG - 2024-02-07 21:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:03:11 --> Input Class Initialized
INFO - 2024-02-07 21:03:11 --> Language Class Initialized
INFO - 2024-02-07 21:03:11 --> Loader Class Initialized
INFO - 2024-02-07 21:03:11 --> Helper loaded: url_helper
INFO - 2024-02-07 21:03:11 --> Helper loaded: file_helper
INFO - 2024-02-07 21:03:11 --> Helper loaded: form_helper
INFO - 2024-02-07 21:03:11 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:03:11 --> Controller Class Initialized
INFO - 2024-02-07 21:03:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:03:11 --> Final output sent to browser
DEBUG - 2024-02-07 21:03:11 --> Total execution time: 0.0385
ERROR - 2024-02-07 21:04:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:04:45 --> Config Class Initialized
INFO - 2024-02-07 21:04:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:04:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:04:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:04:45 --> URI Class Initialized
INFO - 2024-02-07 21:04:45 --> Router Class Initialized
INFO - 2024-02-07 21:04:45 --> Output Class Initialized
INFO - 2024-02-07 21:04:45 --> Security Class Initialized
DEBUG - 2024-02-07 21:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:04:45 --> Input Class Initialized
INFO - 2024-02-07 21:04:45 --> Language Class Initialized
INFO - 2024-02-07 21:04:45 --> Loader Class Initialized
INFO - 2024-02-07 21:04:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:04:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:04:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:04:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:04:45 --> Controller Class Initialized
INFO - 2024-02-07 21:04:45 --> Form Validation Class Initialized
INFO - 2024-02-07 21:04:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:04:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:04:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:04:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:04:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:04:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:04:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:04:45 --> Final output sent to browser
DEBUG - 2024-02-07 21:04:45 --> Total execution time: 0.0281
ERROR - 2024-02-07 21:04:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-07 21:04:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:04:45 --> Config Class Initialized
INFO - 2024-02-07 21:04:45 --> Hooks Class Initialized
INFO - 2024-02-07 21:04:45 --> Config Class Initialized
INFO - 2024-02-07 21:04:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:04:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:04:45 --> Utf8 Class Initialized
DEBUG - 2024-02-07 21:04:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:04:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:04:45 --> URI Class Initialized
INFO - 2024-02-07 21:04:45 --> URI Class Initialized
INFO - 2024-02-07 21:04:45 --> Router Class Initialized
INFO - 2024-02-07 21:04:45 --> Router Class Initialized
INFO - 2024-02-07 21:04:45 --> Output Class Initialized
INFO - 2024-02-07 21:04:45 --> Security Class Initialized
INFO - 2024-02-07 21:04:45 --> Output Class Initialized
DEBUG - 2024-02-07 21:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:04:45 --> Security Class Initialized
INFO - 2024-02-07 21:04:45 --> Input Class Initialized
INFO - 2024-02-07 21:04:45 --> Language Class Initialized
DEBUG - 2024-02-07 21:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:04:45 --> Input Class Initialized
INFO - 2024-02-07 21:04:45 --> Language Class Initialized
INFO - 2024-02-07 21:04:45 --> Loader Class Initialized
INFO - 2024-02-07 21:04:45 --> Loader Class Initialized
INFO - 2024-02-07 21:04:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:04:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:04:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:04:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:04:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:04:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:04:45 --> Database Driver Class Initialized
INFO - 2024-02-07 21:04:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 21:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:04:45 --> Controller Class Initialized
INFO - 2024-02-07 21:04:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:04:45 --> Final output sent to browser
DEBUG - 2024-02-07 21:04:45 --> Total execution time: 0.0338
INFO - 2024-02-07 21:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:04:45 --> Controller Class Initialized
INFO - 2024-02-07 21:04:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:04:45 --> Final output sent to browser
DEBUG - 2024-02-07 21:04:45 --> Total execution time: 0.0454
ERROR - 2024-02-07 21:04:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:04:45 --> Config Class Initialized
INFO - 2024-02-07 21:04:45 --> Hooks Class Initialized
ERROR - 2024-02-07 21:04:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2024-02-07 21:04:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:04:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:04:45 --> Config Class Initialized
INFO - 2024-02-07 21:04:45 --> URI Class Initialized
INFO - 2024-02-07 21:04:45 --> Hooks Class Initialized
INFO - 2024-02-07 21:04:45 --> Router Class Initialized
DEBUG - 2024-02-07 21:04:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:04:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:04:45 --> Output Class Initialized
INFO - 2024-02-07 21:04:45 --> Security Class Initialized
INFO - 2024-02-07 21:04:45 --> URI Class Initialized
DEBUG - 2024-02-07 21:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:04:45 --> Input Class Initialized
INFO - 2024-02-07 21:04:45 --> Router Class Initialized
INFO - 2024-02-07 21:04:45 --> Language Class Initialized
INFO - 2024-02-07 21:04:45 --> Output Class Initialized
INFO - 2024-02-07 21:04:45 --> Security Class Initialized
INFO - 2024-02-07 21:04:45 --> Loader Class Initialized
DEBUG - 2024-02-07 21:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:04:45 --> Input Class Initialized
INFO - 2024-02-07 21:04:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:04:45 --> Language Class Initialized
INFO - 2024-02-07 21:04:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:04:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:04:45 --> Loader Class Initialized
INFO - 2024-02-07 21:04:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:04:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:04:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:04:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:04:45 --> Controller Class Initialized
INFO - 2024-02-07 21:04:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:04:45 --> Final output sent to browser
DEBUG - 2024-02-07 21:04:45 --> Total execution time: 0.0268
INFO - 2024-02-07 21:04:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:04:45 --> Controller Class Initialized
INFO - 2024-02-07 21:04:45 --> Form Validation Class Initialized
INFO - 2024-02-07 21:04:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:04:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:11 --> Config Class Initialized
INFO - 2024-02-07 21:06:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:11 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:11 --> URI Class Initialized
INFO - 2024-02-07 21:06:11 --> Router Class Initialized
INFO - 2024-02-07 21:06:11 --> Output Class Initialized
INFO - 2024-02-07 21:06:11 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:11 --> Input Class Initialized
INFO - 2024-02-07 21:06:11 --> Language Class Initialized
INFO - 2024-02-07 21:06:11 --> Loader Class Initialized
INFO - 2024-02-07 21:06:11 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:11 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:11 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:11 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:11 --> Controller Class Initialized
INFO - 2024-02-07 21:06:11 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:11 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:06:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:06:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:06:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:06:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:06:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:06:11 --> Final output sent to browser
DEBUG - 2024-02-07 21:06:11 --> Total execution time: 0.0293
ERROR - 2024-02-07 21:06:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:12 --> Config Class Initialized
INFO - 2024-02-07 21:06:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:12 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:12 --> URI Class Initialized
INFO - 2024-02-07 21:06:12 --> Router Class Initialized
INFO - 2024-02-07 21:06:12 --> Output Class Initialized
INFO - 2024-02-07 21:06:12 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:12 --> Input Class Initialized
INFO - 2024-02-07 21:06:12 --> Language Class Initialized
INFO - 2024-02-07 21:06:12 --> Loader Class Initialized
INFO - 2024-02-07 21:06:12 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:12 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:12 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:12 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:12 --> Controller Class Initialized
INFO - 2024-02-07 21:06:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:06:12 --> Final output sent to browser
DEBUG - 2024-02-07 21:06:12 --> Total execution time: 0.0276
ERROR - 2024-02-07 21:06:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:12 --> Config Class Initialized
INFO - 2024-02-07 21:06:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:12 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:12 --> URI Class Initialized
INFO - 2024-02-07 21:06:12 --> Router Class Initialized
INFO - 2024-02-07 21:06:12 --> Output Class Initialized
INFO - 2024-02-07 21:06:12 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:12 --> Input Class Initialized
INFO - 2024-02-07 21:06:12 --> Language Class Initialized
INFO - 2024-02-07 21:06:12 --> Loader Class Initialized
INFO - 2024-02-07 21:06:12 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:12 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:12 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:12 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:12 --> Controller Class Initialized
INFO - 2024-02-07 21:06:12 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:12 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:17 --> Config Class Initialized
INFO - 2024-02-07 21:06:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:17 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:17 --> URI Class Initialized
INFO - 2024-02-07 21:06:17 --> Router Class Initialized
INFO - 2024-02-07 21:06:17 --> Output Class Initialized
INFO - 2024-02-07 21:06:17 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:17 --> Input Class Initialized
INFO - 2024-02-07 21:06:17 --> Language Class Initialized
INFO - 2024-02-07 21:06:17 --> Loader Class Initialized
INFO - 2024-02-07 21:06:17 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:17 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:17 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:17 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:17 --> Controller Class Initialized
INFO - 2024-02-07 21:06:17 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:17 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:06:17 --> Final output sent to browser
DEBUG - 2024-02-07 21:06:17 --> Total execution time: 0.0382
ERROR - 2024-02-07 21:06:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:18 --> Config Class Initialized
INFO - 2024-02-07 21:06:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:18 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:18 --> URI Class Initialized
INFO - 2024-02-07 21:06:18 --> Router Class Initialized
INFO - 2024-02-07 21:06:18 --> Output Class Initialized
INFO - 2024-02-07 21:06:18 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:18 --> Input Class Initialized
INFO - 2024-02-07 21:06:18 --> Language Class Initialized
INFO - 2024-02-07 21:06:18 --> Loader Class Initialized
INFO - 2024-02-07 21:06:18 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:18 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:18 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:18 --> Controller Class Initialized
INFO - 2024-02-07 21:06:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:06:18 --> Final output sent to browser
DEBUG - 2024-02-07 21:06:18 --> Total execution time: 0.0278
ERROR - 2024-02-07 21:06:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:18 --> Config Class Initialized
INFO - 2024-02-07 21:06:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:18 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:18 --> URI Class Initialized
INFO - 2024-02-07 21:06:18 --> Router Class Initialized
INFO - 2024-02-07 21:06:18 --> Output Class Initialized
INFO - 2024-02-07 21:06:18 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:18 --> Input Class Initialized
INFO - 2024-02-07 21:06:18 --> Language Class Initialized
INFO - 2024-02-07 21:06:18 --> Loader Class Initialized
INFO - 2024-02-07 21:06:18 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:18 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:18 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:18 --> Controller Class Initialized
INFO - 2024-02-07 21:06:18 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:18 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:25 --> Config Class Initialized
INFO - 2024-02-07 21:06:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:25 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:25 --> URI Class Initialized
INFO - 2024-02-07 21:06:25 --> Router Class Initialized
INFO - 2024-02-07 21:06:25 --> Output Class Initialized
INFO - 2024-02-07 21:06:25 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:25 --> Input Class Initialized
INFO - 2024-02-07 21:06:25 --> Language Class Initialized
INFO - 2024-02-07 21:06:25 --> Loader Class Initialized
INFO - 2024-02-07 21:06:25 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:25 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:25 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:25 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:25 --> Controller Class Initialized
INFO - 2024-02-07 21:06:25 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:25 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:06:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 21:06:25 --> Final output sent to browser
DEBUG - 2024-02-07 21:06:25 --> Total execution time: 0.0309
ERROR - 2024-02-07 21:06:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:26 --> Config Class Initialized
INFO - 2024-02-07 21:06:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:26 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:26 --> URI Class Initialized
INFO - 2024-02-07 21:06:26 --> Router Class Initialized
INFO - 2024-02-07 21:06:26 --> Output Class Initialized
INFO - 2024-02-07 21:06:26 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:26 --> Input Class Initialized
INFO - 2024-02-07 21:06:26 --> Language Class Initialized
INFO - 2024-02-07 21:06:26 --> Loader Class Initialized
INFO - 2024-02-07 21:06:26 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:26 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:26 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:26 --> Controller Class Initialized
INFO - 2024-02-07 21:06:26 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:26 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:26 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:26 --> Config Class Initialized
INFO - 2024-02-07 21:06:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:26 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:26 --> URI Class Initialized
INFO - 2024-02-07 21:06:26 --> Router Class Initialized
INFO - 2024-02-07 21:06:26 --> Output Class Initialized
INFO - 2024-02-07 21:06:26 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:26 --> Input Class Initialized
INFO - 2024-02-07 21:06:26 --> Language Class Initialized
INFO - 2024-02-07 21:06:26 --> Loader Class Initialized
INFO - 2024-02-07 21:06:26 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:26 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:26 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:26 --> Controller Class Initialized
INFO - 2024-02-07 21:06:26 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:26 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:26 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:33 --> Config Class Initialized
INFO - 2024-02-07 21:06:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:33 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:33 --> URI Class Initialized
INFO - 2024-02-07 21:06:33 --> Router Class Initialized
INFO - 2024-02-07 21:06:33 --> Output Class Initialized
INFO - 2024-02-07 21:06:33 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:33 --> Input Class Initialized
INFO - 2024-02-07 21:06:33 --> Language Class Initialized
INFO - 2024-02-07 21:06:33 --> Loader Class Initialized
INFO - 2024-02-07 21:06:33 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:33 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:33 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:33 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:33 --> Controller Class Initialized
INFO - 2024-02-07 21:06:33 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:33 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:06:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 21:06:33 --> Final output sent to browser
DEBUG - 2024-02-07 21:06:33 --> Total execution time: 0.0391
ERROR - 2024-02-07 21:06:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:34 --> Config Class Initialized
INFO - 2024-02-07 21:06:34 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:34 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:34 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:34 --> URI Class Initialized
INFO - 2024-02-07 21:06:34 --> Router Class Initialized
INFO - 2024-02-07 21:06:34 --> Output Class Initialized
INFO - 2024-02-07 21:06:34 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:34 --> Input Class Initialized
INFO - 2024-02-07 21:06:34 --> Language Class Initialized
INFO - 2024-02-07 21:06:34 --> Loader Class Initialized
INFO - 2024-02-07 21:06:34 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:34 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:34 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:34 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:34 --> Controller Class Initialized
INFO - 2024-02-07 21:06:34 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:34 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:34 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:39 --> Config Class Initialized
INFO - 2024-02-07 21:06:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:39 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:39 --> URI Class Initialized
INFO - 2024-02-07 21:06:39 --> Router Class Initialized
INFO - 2024-02-07 21:06:39 --> Output Class Initialized
INFO - 2024-02-07 21:06:39 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:39 --> Input Class Initialized
INFO - 2024-02-07 21:06:39 --> Language Class Initialized
INFO - 2024-02-07 21:06:39 --> Loader Class Initialized
INFO - 2024-02-07 21:06:39 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:39 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:39 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:39 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:39 --> Controller Class Initialized
INFO - 2024-02-07 21:06:39 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:39 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:39 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:40 --> Config Class Initialized
INFO - 2024-02-07 21:06:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:40 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:40 --> URI Class Initialized
INFO - 2024-02-07 21:06:40 --> Router Class Initialized
INFO - 2024-02-07 21:06:40 --> Output Class Initialized
INFO - 2024-02-07 21:06:40 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:40 --> Input Class Initialized
INFO - 2024-02-07 21:06:40 --> Language Class Initialized
INFO - 2024-02-07 21:06:40 --> Loader Class Initialized
INFO - 2024-02-07 21:06:40 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:40 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:40 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:40 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:40 --> Controller Class Initialized
INFO - 2024-02-07 21:06:40 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:40 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:40 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:40 --> Config Class Initialized
INFO - 2024-02-07 21:06:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:40 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:40 --> URI Class Initialized
INFO - 2024-02-07 21:06:40 --> Router Class Initialized
INFO - 2024-02-07 21:06:40 --> Output Class Initialized
INFO - 2024-02-07 21:06:40 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:40 --> Input Class Initialized
INFO - 2024-02-07 21:06:40 --> Language Class Initialized
INFO - 2024-02-07 21:06:40 --> Loader Class Initialized
INFO - 2024-02-07 21:06:40 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:40 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:40 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:40 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:40 --> Controller Class Initialized
INFO - 2024-02-07 21:06:40 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:40 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:40 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:41 --> Config Class Initialized
INFO - 2024-02-07 21:06:41 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:41 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:41 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:41 --> URI Class Initialized
INFO - 2024-02-07 21:06:41 --> Router Class Initialized
INFO - 2024-02-07 21:06:41 --> Output Class Initialized
INFO - 2024-02-07 21:06:41 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:41 --> Input Class Initialized
INFO - 2024-02-07 21:06:41 --> Language Class Initialized
INFO - 2024-02-07 21:06:41 --> Loader Class Initialized
INFO - 2024-02-07 21:06:41 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:41 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:41 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:41 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:41 --> Controller Class Initialized
INFO - 2024-02-07 21:06:41 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:41 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:41 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:42 --> Config Class Initialized
INFO - 2024-02-07 21:06:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:42 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:42 --> URI Class Initialized
INFO - 2024-02-07 21:06:42 --> Router Class Initialized
INFO - 2024-02-07 21:06:42 --> Output Class Initialized
INFO - 2024-02-07 21:06:42 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:42 --> Input Class Initialized
INFO - 2024-02-07 21:06:42 --> Language Class Initialized
INFO - 2024-02-07 21:06:42 --> Loader Class Initialized
INFO - 2024-02-07 21:06:42 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:42 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:42 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:42 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:42 --> Controller Class Initialized
INFO - 2024-02-07 21:06:42 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:42 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:42 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:42 --> Config Class Initialized
INFO - 2024-02-07 21:06:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:42 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:42 --> URI Class Initialized
INFO - 2024-02-07 21:06:42 --> Router Class Initialized
INFO - 2024-02-07 21:06:42 --> Output Class Initialized
INFO - 2024-02-07 21:06:42 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:42 --> Input Class Initialized
INFO - 2024-02-07 21:06:42 --> Language Class Initialized
INFO - 2024-02-07 21:06:42 --> Loader Class Initialized
INFO - 2024-02-07 21:06:42 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:42 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:42 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:42 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:42 --> Controller Class Initialized
INFO - 2024-02-07 21:06:42 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:42 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:42 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:43 --> Config Class Initialized
INFO - 2024-02-07 21:06:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:43 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:43 --> URI Class Initialized
INFO - 2024-02-07 21:06:43 --> Router Class Initialized
INFO - 2024-02-07 21:06:43 --> Output Class Initialized
INFO - 2024-02-07 21:06:43 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:43 --> Input Class Initialized
INFO - 2024-02-07 21:06:43 --> Language Class Initialized
INFO - 2024-02-07 21:06:43 --> Loader Class Initialized
INFO - 2024-02-07 21:06:43 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:43 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:43 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:43 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:43 --> Controller Class Initialized
INFO - 2024-02-07 21:06:43 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:43 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:43 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:43 --> Config Class Initialized
INFO - 2024-02-07 21:06:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:43 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:43 --> URI Class Initialized
INFO - 2024-02-07 21:06:43 --> Router Class Initialized
INFO - 2024-02-07 21:06:43 --> Output Class Initialized
INFO - 2024-02-07 21:06:43 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:43 --> Input Class Initialized
INFO - 2024-02-07 21:06:43 --> Language Class Initialized
INFO - 2024-02-07 21:06:43 --> Loader Class Initialized
INFO - 2024-02-07 21:06:43 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:43 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:43 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:43 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:43 --> Controller Class Initialized
INFO - 2024-02-07 21:06:43 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:43 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:43 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:43 --> Config Class Initialized
INFO - 2024-02-07 21:06:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:43 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:43 --> URI Class Initialized
INFO - 2024-02-07 21:06:43 --> Router Class Initialized
INFO - 2024-02-07 21:06:43 --> Output Class Initialized
INFO - 2024-02-07 21:06:43 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:43 --> Input Class Initialized
INFO - 2024-02-07 21:06:43 --> Language Class Initialized
INFO - 2024-02-07 21:06:43 --> Loader Class Initialized
INFO - 2024-02-07 21:06:43 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:43 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:43 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:43 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:43 --> Controller Class Initialized
INFO - 2024-02-07 21:06:43 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:43 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:43 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:43 --> Config Class Initialized
INFO - 2024-02-07 21:06:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:43 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:43 --> URI Class Initialized
INFO - 2024-02-07 21:06:43 --> Router Class Initialized
INFO - 2024-02-07 21:06:43 --> Output Class Initialized
INFO - 2024-02-07 21:06:43 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:43 --> Input Class Initialized
INFO - 2024-02-07 21:06:43 --> Language Class Initialized
INFO - 2024-02-07 21:06:43 --> Loader Class Initialized
INFO - 2024-02-07 21:06:43 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:43 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:43 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:43 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:43 --> Controller Class Initialized
INFO - 2024-02-07 21:06:43 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:43 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:43 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:44 --> Config Class Initialized
INFO - 2024-02-07 21:06:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:44 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:44 --> URI Class Initialized
INFO - 2024-02-07 21:06:44 --> Router Class Initialized
INFO - 2024-02-07 21:06:44 --> Output Class Initialized
INFO - 2024-02-07 21:06:44 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:44 --> Input Class Initialized
INFO - 2024-02-07 21:06:44 --> Language Class Initialized
INFO - 2024-02-07 21:06:44 --> Loader Class Initialized
INFO - 2024-02-07 21:06:44 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:44 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:44 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:44 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:44 --> Controller Class Initialized
INFO - 2024-02-07 21:06:44 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:44 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:44 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:44 --> Config Class Initialized
INFO - 2024-02-07 21:06:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:44 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:44 --> URI Class Initialized
INFO - 2024-02-07 21:06:44 --> Router Class Initialized
INFO - 2024-02-07 21:06:44 --> Output Class Initialized
INFO - 2024-02-07 21:06:44 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:44 --> Input Class Initialized
INFO - 2024-02-07 21:06:44 --> Language Class Initialized
INFO - 2024-02-07 21:06:44 --> Loader Class Initialized
INFO - 2024-02-07 21:06:44 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:44 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:44 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:44 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:44 --> Controller Class Initialized
INFO - 2024-02-07 21:06:44 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:44 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:44 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:44 --> Config Class Initialized
INFO - 2024-02-07 21:06:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:44 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:44 --> URI Class Initialized
INFO - 2024-02-07 21:06:44 --> Router Class Initialized
INFO - 2024-02-07 21:06:44 --> Output Class Initialized
INFO - 2024-02-07 21:06:44 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:44 --> Input Class Initialized
INFO - 2024-02-07 21:06:44 --> Language Class Initialized
INFO - 2024-02-07 21:06:44 --> Loader Class Initialized
INFO - 2024-02-07 21:06:44 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:44 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:44 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:44 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:44 --> Controller Class Initialized
INFO - 2024-02-07 21:06:44 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:44 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:44 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:44 --> Config Class Initialized
INFO - 2024-02-07 21:06:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:44 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:44 --> URI Class Initialized
INFO - 2024-02-07 21:06:44 --> Router Class Initialized
INFO - 2024-02-07 21:06:44 --> Output Class Initialized
INFO - 2024-02-07 21:06:44 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:44 --> Input Class Initialized
INFO - 2024-02-07 21:06:44 --> Language Class Initialized
INFO - 2024-02-07 21:06:44 --> Loader Class Initialized
INFO - 2024-02-07 21:06:44 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:44 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:44 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:44 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:44 --> Controller Class Initialized
INFO - 2024-02-07 21:06:44 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:44 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:44 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:44 --> Config Class Initialized
INFO - 2024-02-07 21:06:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:44 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:44 --> URI Class Initialized
INFO - 2024-02-07 21:06:44 --> Router Class Initialized
INFO - 2024-02-07 21:06:44 --> Output Class Initialized
INFO - 2024-02-07 21:06:44 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:44 --> Input Class Initialized
INFO - 2024-02-07 21:06:44 --> Language Class Initialized
INFO - 2024-02-07 21:06:44 --> Loader Class Initialized
INFO - 2024-02-07 21:06:44 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:44 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:44 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:44 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:44 --> Controller Class Initialized
INFO - 2024-02-07 21:06:44 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:44 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:44 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:44 --> Config Class Initialized
INFO - 2024-02-07 21:06:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:44 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:44 --> URI Class Initialized
INFO - 2024-02-07 21:06:44 --> Router Class Initialized
INFO - 2024-02-07 21:06:44 --> Output Class Initialized
INFO - 2024-02-07 21:06:44 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:44 --> Input Class Initialized
INFO - 2024-02-07 21:06:44 --> Language Class Initialized
INFO - 2024-02-07 21:06:44 --> Loader Class Initialized
INFO - 2024-02-07 21:06:44 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:44 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:44 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:44 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:44 --> Controller Class Initialized
INFO - 2024-02-07 21:06:44 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:44 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:44 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:45 --> Config Class Initialized
INFO - 2024-02-07 21:06:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:45 --> URI Class Initialized
INFO - 2024-02-07 21:06:45 --> Router Class Initialized
INFO - 2024-02-07 21:06:45 --> Output Class Initialized
INFO - 2024-02-07 21:06:45 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:45 --> Input Class Initialized
INFO - 2024-02-07 21:06:45 --> Language Class Initialized
INFO - 2024-02-07 21:06:45 --> Loader Class Initialized
INFO - 2024-02-07 21:06:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:45 --> Controller Class Initialized
INFO - 2024-02-07 21:06:45 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:45 --> Config Class Initialized
INFO - 2024-02-07 21:06:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:45 --> URI Class Initialized
INFO - 2024-02-07 21:06:45 --> Router Class Initialized
INFO - 2024-02-07 21:06:45 --> Output Class Initialized
INFO - 2024-02-07 21:06:45 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:45 --> Input Class Initialized
INFO - 2024-02-07 21:06:45 --> Language Class Initialized
INFO - 2024-02-07 21:06:45 --> Loader Class Initialized
INFO - 2024-02-07 21:06:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:45 --> Controller Class Initialized
INFO - 2024-02-07 21:06:45 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:45 --> Config Class Initialized
INFO - 2024-02-07 21:06:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:45 --> URI Class Initialized
INFO - 2024-02-07 21:06:45 --> Router Class Initialized
INFO - 2024-02-07 21:06:45 --> Output Class Initialized
INFO - 2024-02-07 21:06:45 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:45 --> Input Class Initialized
INFO - 2024-02-07 21:06:45 --> Language Class Initialized
INFO - 2024-02-07 21:06:45 --> Loader Class Initialized
INFO - 2024-02-07 21:06:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:45 --> Controller Class Initialized
INFO - 2024-02-07 21:06:45 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:45 --> Config Class Initialized
INFO - 2024-02-07 21:06:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:45 --> URI Class Initialized
INFO - 2024-02-07 21:06:45 --> Router Class Initialized
INFO - 2024-02-07 21:06:45 --> Output Class Initialized
INFO - 2024-02-07 21:06:45 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:45 --> Input Class Initialized
INFO - 2024-02-07 21:06:45 --> Language Class Initialized
INFO - 2024-02-07 21:06:45 --> Loader Class Initialized
INFO - 2024-02-07 21:06:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:45 --> Controller Class Initialized
INFO - 2024-02-07 21:06:45 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:45 --> Config Class Initialized
INFO - 2024-02-07 21:06:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:45 --> URI Class Initialized
INFO - 2024-02-07 21:06:45 --> Router Class Initialized
INFO - 2024-02-07 21:06:45 --> Output Class Initialized
INFO - 2024-02-07 21:06:45 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:45 --> Input Class Initialized
INFO - 2024-02-07 21:06:45 --> Language Class Initialized
INFO - 2024-02-07 21:06:45 --> Loader Class Initialized
INFO - 2024-02-07 21:06:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:45 --> Controller Class Initialized
INFO - 2024-02-07 21:06:45 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:46 --> Config Class Initialized
INFO - 2024-02-07 21:06:46 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:46 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:46 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:46 --> URI Class Initialized
INFO - 2024-02-07 21:06:46 --> Router Class Initialized
INFO - 2024-02-07 21:06:46 --> Output Class Initialized
INFO - 2024-02-07 21:06:46 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:46 --> Input Class Initialized
INFO - 2024-02-07 21:06:46 --> Language Class Initialized
INFO - 2024-02-07 21:06:46 --> Loader Class Initialized
INFO - 2024-02-07 21:06:46 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:46 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:46 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:46 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:46 --> Controller Class Initialized
INFO - 2024-02-07 21:06:46 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:46 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:46 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:46 --> Config Class Initialized
INFO - 2024-02-07 21:06:46 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:46 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:46 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:46 --> URI Class Initialized
INFO - 2024-02-07 21:06:46 --> Router Class Initialized
INFO - 2024-02-07 21:06:46 --> Output Class Initialized
INFO - 2024-02-07 21:06:46 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:46 --> Input Class Initialized
INFO - 2024-02-07 21:06:46 --> Language Class Initialized
INFO - 2024-02-07 21:06:46 --> Loader Class Initialized
INFO - 2024-02-07 21:06:46 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:46 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:46 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:46 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:46 --> Controller Class Initialized
INFO - 2024-02-07 21:06:46 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:46 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:46 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:46 --> Config Class Initialized
INFO - 2024-02-07 21:06:46 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:46 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:46 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:46 --> URI Class Initialized
INFO - 2024-02-07 21:06:46 --> Router Class Initialized
INFO - 2024-02-07 21:06:46 --> Output Class Initialized
INFO - 2024-02-07 21:06:46 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:46 --> Input Class Initialized
INFO - 2024-02-07 21:06:46 --> Language Class Initialized
INFO - 2024-02-07 21:06:46 --> Loader Class Initialized
INFO - 2024-02-07 21:06:46 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:46 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:46 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:46 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:46 --> Controller Class Initialized
INFO - 2024-02-07 21:06:46 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:46 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:46 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:46 --> Config Class Initialized
INFO - 2024-02-07 21:06:46 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:46 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:46 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:46 --> URI Class Initialized
INFO - 2024-02-07 21:06:46 --> Router Class Initialized
INFO - 2024-02-07 21:06:46 --> Output Class Initialized
INFO - 2024-02-07 21:06:46 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:46 --> Input Class Initialized
INFO - 2024-02-07 21:06:46 --> Language Class Initialized
INFO - 2024-02-07 21:06:46 --> Loader Class Initialized
INFO - 2024-02-07 21:06:46 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:46 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:46 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:46 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:46 --> Controller Class Initialized
INFO - 2024-02-07 21:06:46 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:46 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:46 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:06:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:06:46 --> Config Class Initialized
INFO - 2024-02-07 21:06:46 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:06:46 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:06:46 --> Utf8 Class Initialized
INFO - 2024-02-07 21:06:46 --> URI Class Initialized
INFO - 2024-02-07 21:06:46 --> Router Class Initialized
INFO - 2024-02-07 21:06:46 --> Output Class Initialized
INFO - 2024-02-07 21:06:46 --> Security Class Initialized
DEBUG - 2024-02-07 21:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:06:46 --> Input Class Initialized
INFO - 2024-02-07 21:06:46 --> Language Class Initialized
INFO - 2024-02-07 21:06:46 --> Loader Class Initialized
INFO - 2024-02-07 21:06:46 --> Helper loaded: url_helper
INFO - 2024-02-07 21:06:46 --> Helper loaded: file_helper
INFO - 2024-02-07 21:06:46 --> Helper loaded: form_helper
INFO - 2024-02-07 21:06:46 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:06:46 --> Controller Class Initialized
INFO - 2024-02-07 21:06:46 --> Form Validation Class Initialized
INFO - 2024-02-07 21:06:46 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:06:46 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:07:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:07:04 --> Config Class Initialized
INFO - 2024-02-07 21:07:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:07:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:07:04 --> Utf8 Class Initialized
INFO - 2024-02-07 21:07:04 --> URI Class Initialized
INFO - 2024-02-07 21:07:04 --> Router Class Initialized
INFO - 2024-02-07 21:07:04 --> Output Class Initialized
INFO - 2024-02-07 21:07:04 --> Security Class Initialized
DEBUG - 2024-02-07 21:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:07:04 --> Input Class Initialized
INFO - 2024-02-07 21:07:04 --> Language Class Initialized
INFO - 2024-02-07 21:07:04 --> Loader Class Initialized
INFO - 2024-02-07 21:07:04 --> Helper loaded: url_helper
INFO - 2024-02-07 21:07:04 --> Helper loaded: file_helper
INFO - 2024-02-07 21:07:04 --> Helper loaded: form_helper
INFO - 2024-02-07 21:07:04 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:07:04 --> Controller Class Initialized
INFO - 2024-02-07 21:07:04 --> Form Validation Class Initialized
INFO - 2024-02-07 21:07:04 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:07:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:07:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:07:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:07:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:07:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:07:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:07:04 --> Final output sent to browser
DEBUG - 2024-02-07 21:07:04 --> Total execution time: 0.0321
ERROR - 2024-02-07 21:07:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:07:04 --> Config Class Initialized
INFO - 2024-02-07 21:07:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:07:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:07:04 --> Utf8 Class Initialized
INFO - 2024-02-07 21:07:04 --> URI Class Initialized
INFO - 2024-02-07 21:07:04 --> Router Class Initialized
INFO - 2024-02-07 21:07:04 --> Output Class Initialized
INFO - 2024-02-07 21:07:04 --> Security Class Initialized
DEBUG - 2024-02-07 21:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:07:04 --> Input Class Initialized
INFO - 2024-02-07 21:07:04 --> Language Class Initialized
INFO - 2024-02-07 21:07:04 --> Loader Class Initialized
INFO - 2024-02-07 21:07:04 --> Helper loaded: url_helper
INFO - 2024-02-07 21:07:04 --> Helper loaded: file_helper
INFO - 2024-02-07 21:07:04 --> Helper loaded: form_helper
INFO - 2024-02-07 21:07:04 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:07:04 --> Controller Class Initialized
INFO - 2024-02-07 21:07:04 --> Form Validation Class Initialized
INFO - 2024-02-07 21:07:04 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:07:04 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:07:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:07:04 --> Config Class Initialized
INFO - 2024-02-07 21:07:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:07:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:07:04 --> Utf8 Class Initialized
INFO - 2024-02-07 21:07:04 --> URI Class Initialized
INFO - 2024-02-07 21:07:04 --> Router Class Initialized
INFO - 2024-02-07 21:07:04 --> Output Class Initialized
INFO - 2024-02-07 21:07:04 --> Security Class Initialized
DEBUG - 2024-02-07 21:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:07:04 --> Input Class Initialized
INFO - 2024-02-07 21:07:04 --> Language Class Initialized
INFO - 2024-02-07 21:07:04 --> Loader Class Initialized
INFO - 2024-02-07 21:07:04 --> Helper loaded: url_helper
INFO - 2024-02-07 21:07:04 --> Helper loaded: file_helper
INFO - 2024-02-07 21:07:04 --> Helper loaded: form_helper
INFO - 2024-02-07 21:07:04 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:07:04 --> Controller Class Initialized
INFO - 2024-02-07 21:07:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:07:04 --> Final output sent to browser
DEBUG - 2024-02-07 21:07:04 --> Total execution time: 0.0282
ERROR - 2024-02-07 21:07:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:07:16 --> Config Class Initialized
INFO - 2024-02-07 21:07:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:07:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:07:16 --> Utf8 Class Initialized
INFO - 2024-02-07 21:07:16 --> URI Class Initialized
INFO - 2024-02-07 21:07:16 --> Router Class Initialized
INFO - 2024-02-07 21:07:16 --> Output Class Initialized
INFO - 2024-02-07 21:07:16 --> Security Class Initialized
DEBUG - 2024-02-07 21:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:07:16 --> Input Class Initialized
INFO - 2024-02-07 21:07:16 --> Language Class Initialized
INFO - 2024-02-07 21:07:16 --> Loader Class Initialized
INFO - 2024-02-07 21:07:16 --> Helper loaded: url_helper
INFO - 2024-02-07 21:07:16 --> Helper loaded: file_helper
INFO - 2024-02-07 21:07:16 --> Helper loaded: form_helper
INFO - 2024-02-07 21:07:16 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:07:16 --> Controller Class Initialized
INFO - 2024-02-07 21:07:16 --> Form Validation Class Initialized
INFO - 2024-02-07 21:07:16 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:07:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:07:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:07:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:07:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:07:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:07:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:07:16 --> Final output sent to browser
DEBUG - 2024-02-07 21:07:16 --> Total execution time: 0.0310
ERROR - 2024-02-07 21:07:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:07:16 --> Config Class Initialized
INFO - 2024-02-07 21:07:16 --> Hooks Class Initialized
ERROR - 2024-02-07 21:07:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2024-02-07 21:07:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:07:16 --> Config Class Initialized
INFO - 2024-02-07 21:07:16 --> Utf8 Class Initialized
INFO - 2024-02-07 21:07:16 --> Hooks Class Initialized
INFO - 2024-02-07 21:07:16 --> URI Class Initialized
INFO - 2024-02-07 21:07:16 --> Router Class Initialized
DEBUG - 2024-02-07 21:07:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:07:16 --> Utf8 Class Initialized
INFO - 2024-02-07 21:07:16 --> Output Class Initialized
INFO - 2024-02-07 21:07:16 --> URI Class Initialized
INFO - 2024-02-07 21:07:16 --> Security Class Initialized
INFO - 2024-02-07 21:07:16 --> Router Class Initialized
DEBUG - 2024-02-07 21:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:07:16 --> Input Class Initialized
INFO - 2024-02-07 21:07:16 --> Language Class Initialized
INFO - 2024-02-07 21:07:16 --> Output Class Initialized
INFO - 2024-02-07 21:07:16 --> Loader Class Initialized
INFO - 2024-02-07 21:07:16 --> Security Class Initialized
INFO - 2024-02-07 21:07:16 --> Helper loaded: url_helper
DEBUG - 2024-02-07 21:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:07:16 --> Input Class Initialized
INFO - 2024-02-07 21:07:16 --> Helper loaded: file_helper
INFO - 2024-02-07 21:07:16 --> Language Class Initialized
INFO - 2024-02-07 21:07:16 --> Helper loaded: form_helper
INFO - 2024-02-07 21:07:16 --> Loader Class Initialized
INFO - 2024-02-07 21:07:16 --> Helper loaded: url_helper
INFO - 2024-02-07 21:07:16 --> Helper loaded: file_helper
INFO - 2024-02-07 21:07:16 --> Helper loaded: form_helper
INFO - 2024-02-07 21:07:16 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:07:16 --> Controller Class Initialized
INFO - 2024-02-07 21:07:16 --> Database Driver Class Initialized
INFO - 2024-02-07 21:07:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:07:16 --> Final output sent to browser
DEBUG - 2024-02-07 21:07:16 --> Total execution time: 0.0281
DEBUG - 2024-02-07 21:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:07:16 --> Controller Class Initialized
INFO - 2024-02-07 21:07:16 --> Form Validation Class Initialized
INFO - 2024-02-07 21:07:16 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:07:16 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:07:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:07:49 --> Config Class Initialized
INFO - 2024-02-07 21:07:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:07:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:07:49 --> Utf8 Class Initialized
INFO - 2024-02-07 21:07:49 --> URI Class Initialized
INFO - 2024-02-07 21:07:49 --> Router Class Initialized
INFO - 2024-02-07 21:07:49 --> Output Class Initialized
INFO - 2024-02-07 21:07:49 --> Security Class Initialized
DEBUG - 2024-02-07 21:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:07:49 --> Input Class Initialized
INFO - 2024-02-07 21:07:49 --> Language Class Initialized
INFO - 2024-02-07 21:07:49 --> Loader Class Initialized
INFO - 2024-02-07 21:07:49 --> Helper loaded: url_helper
INFO - 2024-02-07 21:07:49 --> Helper loaded: file_helper
INFO - 2024-02-07 21:07:49 --> Helper loaded: form_helper
INFO - 2024-02-07 21:07:49 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:07:49 --> Controller Class Initialized
INFO - 2024-02-07 21:07:49 --> Form Validation Class Initialized
INFO - 2024-02-07 21:07:49 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:07:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:07:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:07:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:07:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:07:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:07:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:07:49 --> Final output sent to browser
DEBUG - 2024-02-07 21:07:49 --> Total execution time: 0.0311
ERROR - 2024-02-07 21:07:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:07:49 --> Config Class Initialized
INFO - 2024-02-07 21:07:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:07:49 --> UTF-8 Support Enabled
ERROR - 2024-02-07 21:07:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:07:49 --> Utf8 Class Initialized
INFO - 2024-02-07 21:07:49 --> URI Class Initialized
INFO - 2024-02-07 21:07:49 --> Config Class Initialized
INFO - 2024-02-07 21:07:49 --> Hooks Class Initialized
INFO - 2024-02-07 21:07:49 --> Router Class Initialized
DEBUG - 2024-02-07 21:07:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:07:49 --> Utf8 Class Initialized
INFO - 2024-02-07 21:07:49 --> Output Class Initialized
INFO - 2024-02-07 21:07:49 --> URI Class Initialized
INFO - 2024-02-07 21:07:49 --> Security Class Initialized
INFO - 2024-02-07 21:07:49 --> Router Class Initialized
DEBUG - 2024-02-07 21:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:07:49 --> Input Class Initialized
INFO - 2024-02-07 21:07:49 --> Output Class Initialized
INFO - 2024-02-07 21:07:49 --> Language Class Initialized
INFO - 2024-02-07 21:07:49 --> Security Class Initialized
DEBUG - 2024-02-07 21:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:07:49 --> Loader Class Initialized
INFO - 2024-02-07 21:07:49 --> Input Class Initialized
INFO - 2024-02-07 21:07:49 --> Language Class Initialized
INFO - 2024-02-07 21:07:49 --> Helper loaded: url_helper
INFO - 2024-02-07 21:07:49 --> Helper loaded: file_helper
INFO - 2024-02-07 21:07:49 --> Loader Class Initialized
INFO - 2024-02-07 21:07:49 --> Helper loaded: form_helper
INFO - 2024-02-07 21:07:49 --> Helper loaded: url_helper
INFO - 2024-02-07 21:07:49 --> Helper loaded: file_helper
INFO - 2024-02-07 21:07:49 --> Helper loaded: form_helper
INFO - 2024-02-07 21:07:49 --> Database Driver Class Initialized
INFO - 2024-02-07 21:07:49 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:07:49 --> Controller Class Initialized
DEBUG - 2024-02-07 21:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:07:49 --> Form Validation Class Initialized
INFO - 2024-02-07 21:07:49 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:07:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:07:49 --> Controller Class Initialized
INFO - 2024-02-07 21:07:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:07:49 --> Final output sent to browser
DEBUG - 2024-02-07 21:07:49 --> Total execution time: 0.0315
ERROR - 2024-02-07 21:10:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:10:22 --> Config Class Initialized
INFO - 2024-02-07 21:10:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:10:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:10:22 --> Utf8 Class Initialized
INFO - 2024-02-07 21:10:22 --> URI Class Initialized
INFO - 2024-02-07 21:10:22 --> Router Class Initialized
INFO - 2024-02-07 21:10:22 --> Output Class Initialized
INFO - 2024-02-07 21:10:22 --> Security Class Initialized
DEBUG - 2024-02-07 21:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:10:22 --> Input Class Initialized
INFO - 2024-02-07 21:10:22 --> Language Class Initialized
INFO - 2024-02-07 21:10:22 --> Loader Class Initialized
INFO - 2024-02-07 21:10:22 --> Helper loaded: url_helper
INFO - 2024-02-07 21:10:22 --> Helper loaded: file_helper
INFO - 2024-02-07 21:10:22 --> Helper loaded: form_helper
INFO - 2024-02-07 21:10:22 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:10:22 --> Controller Class Initialized
INFO - 2024-02-07 21:10:22 --> Form Validation Class Initialized
INFO - 2024-02-07 21:10:22 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:10:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:10:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:10:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:10:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:10:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:10:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:10:22 --> Final output sent to browser
DEBUG - 2024-02-07 21:10:22 --> Total execution time: 0.0310
ERROR - 2024-02-07 21:10:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:10:23 --> Config Class Initialized
INFO - 2024-02-07 21:10:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:10:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:10:23 --> Utf8 Class Initialized
INFO - 2024-02-07 21:10:23 --> URI Class Initialized
INFO - 2024-02-07 21:10:23 --> Router Class Initialized
INFO - 2024-02-07 21:10:23 --> Output Class Initialized
INFO - 2024-02-07 21:10:23 --> Security Class Initialized
DEBUG - 2024-02-07 21:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:10:23 --> Input Class Initialized
INFO - 2024-02-07 21:10:23 --> Language Class Initialized
INFO - 2024-02-07 21:10:23 --> Loader Class Initialized
INFO - 2024-02-07 21:10:23 --> Helper loaded: url_helper
INFO - 2024-02-07 21:10:23 --> Helper loaded: file_helper
INFO - 2024-02-07 21:10:23 --> Helper loaded: form_helper
ERROR - 2024-02-07 21:10:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:10:23 --> Config Class Initialized
INFO - 2024-02-07 21:10:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:10:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:10:23 --> Utf8 Class Initialized
INFO - 2024-02-07 21:10:23 --> Database Driver Class Initialized
INFO - 2024-02-07 21:10:23 --> URI Class Initialized
INFO - 2024-02-07 21:10:23 --> Router Class Initialized
INFO - 2024-02-07 21:10:23 --> Output Class Initialized
DEBUG - 2024-02-07 21:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:10:23 --> Security Class Initialized
INFO - 2024-02-07 21:10:23 --> Controller Class Initialized
DEBUG - 2024-02-07 21:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:10:23 --> Input Class Initialized
INFO - 2024-02-07 21:10:23 --> Language Class Initialized
INFO - 2024-02-07 21:10:23 --> Form Validation Class Initialized
INFO - 2024-02-07 21:10:23 --> Loader Class Initialized
INFO - 2024-02-07 21:10:23 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:10:23 --> Helper loaded: url_helper
INFO - 2024-02-07 21:10:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:10:23 --> Helper loaded: file_helper
INFO - 2024-02-07 21:10:23 --> Helper loaded: form_helper
INFO - 2024-02-07 21:10:23 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:10:23 --> Controller Class Initialized
INFO - 2024-02-07 21:10:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:10:23 --> Final output sent to browser
DEBUG - 2024-02-07 21:10:23 --> Total execution time: 0.0242
ERROR - 2024-02-07 21:10:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:10:27 --> Config Class Initialized
INFO - 2024-02-07 21:10:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:10:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:10:27 --> Utf8 Class Initialized
INFO - 2024-02-07 21:10:27 --> URI Class Initialized
INFO - 2024-02-07 21:10:27 --> Router Class Initialized
INFO - 2024-02-07 21:10:27 --> Output Class Initialized
INFO - 2024-02-07 21:10:27 --> Security Class Initialized
DEBUG - 2024-02-07 21:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:10:27 --> Input Class Initialized
INFO - 2024-02-07 21:10:27 --> Language Class Initialized
INFO - 2024-02-07 21:10:27 --> Loader Class Initialized
INFO - 2024-02-07 21:10:27 --> Helper loaded: url_helper
INFO - 2024-02-07 21:10:27 --> Helper loaded: file_helper
INFO - 2024-02-07 21:10:27 --> Helper loaded: form_helper
INFO - 2024-02-07 21:10:27 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:10:27 --> Controller Class Initialized
INFO - 2024-02-07 21:10:27 --> Form Validation Class Initialized
INFO - 2024-02-07 21:10:27 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:10:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:10:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:10:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:10:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:10:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:10:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:10:27 --> Final output sent to browser
DEBUG - 2024-02-07 21:10:27 --> Total execution time: 0.0368
ERROR - 2024-02-07 21:10:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:10:27 --> Config Class Initialized
INFO - 2024-02-07 21:10:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:10:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:10:27 --> Utf8 Class Initialized
INFO - 2024-02-07 21:10:27 --> URI Class Initialized
INFO - 2024-02-07 21:10:27 --> Router Class Initialized
INFO - 2024-02-07 21:10:27 --> Output Class Initialized
INFO - 2024-02-07 21:10:27 --> Security Class Initialized
DEBUG - 2024-02-07 21:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:10:27 --> Input Class Initialized
INFO - 2024-02-07 21:10:27 --> Language Class Initialized
INFO - 2024-02-07 21:10:27 --> Loader Class Initialized
INFO - 2024-02-07 21:10:27 --> Helper loaded: url_helper
INFO - 2024-02-07 21:10:27 --> Helper loaded: file_helper
INFO - 2024-02-07 21:10:27 --> Helper loaded: form_helper
INFO - 2024-02-07 21:10:27 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:10:27 --> Controller Class Initialized
INFO - 2024-02-07 21:10:27 --> Form Validation Class Initialized
INFO - 2024-02-07 21:10:27 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:10:27 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:10:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:10:28 --> Config Class Initialized
INFO - 2024-02-07 21:10:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:10:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:10:28 --> Utf8 Class Initialized
INFO - 2024-02-07 21:10:28 --> URI Class Initialized
INFO - 2024-02-07 21:10:28 --> Router Class Initialized
INFO - 2024-02-07 21:10:28 --> Output Class Initialized
INFO - 2024-02-07 21:10:28 --> Security Class Initialized
DEBUG - 2024-02-07 21:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:10:28 --> Input Class Initialized
INFO - 2024-02-07 21:10:28 --> Language Class Initialized
INFO - 2024-02-07 21:10:28 --> Loader Class Initialized
INFO - 2024-02-07 21:10:28 --> Helper loaded: url_helper
INFO - 2024-02-07 21:10:28 --> Helper loaded: file_helper
INFO - 2024-02-07 21:10:28 --> Helper loaded: form_helper
INFO - 2024-02-07 21:10:28 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:10:28 --> Controller Class Initialized
INFO - 2024-02-07 21:10:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:10:28 --> Final output sent to browser
DEBUG - 2024-02-07 21:10:28 --> Total execution time: 0.0380
ERROR - 2024-02-07 21:12:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:12:45 --> Config Class Initialized
INFO - 2024-02-07 21:12:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:12:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:12:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:12:45 --> URI Class Initialized
INFO - 2024-02-07 21:12:45 --> Router Class Initialized
INFO - 2024-02-07 21:12:45 --> Output Class Initialized
INFO - 2024-02-07 21:12:45 --> Security Class Initialized
DEBUG - 2024-02-07 21:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:12:45 --> Input Class Initialized
INFO - 2024-02-07 21:12:45 --> Language Class Initialized
INFO - 2024-02-07 21:12:45 --> Loader Class Initialized
INFO - 2024-02-07 21:12:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:12:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:12:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:12:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:12:45 --> Controller Class Initialized
INFO - 2024-02-07 21:12:45 --> Form Validation Class Initialized
INFO - 2024-02-07 21:12:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:12:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:12:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:12:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:12:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:12:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:12:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:12:45 --> Final output sent to browser
DEBUG - 2024-02-07 21:12:45 --> Total execution time: 0.0408
ERROR - 2024-02-07 21:12:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:12:45 --> Config Class Initialized
ERROR - 2024-02-07 21:12:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:12:45 --> Hooks Class Initialized
INFO - 2024-02-07 21:12:45 --> Config Class Initialized
INFO - 2024-02-07 21:12:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:12:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:12:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:12:45 --> URI Class Initialized
INFO - 2024-02-07 21:12:45 --> Router Class Initialized
DEBUG - 2024-02-07 21:12:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:12:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:12:45 --> Output Class Initialized
INFO - 2024-02-07 21:12:45 --> URI Class Initialized
INFO - 2024-02-07 21:12:45 --> Security Class Initialized
INFO - 2024-02-07 21:12:45 --> Router Class Initialized
DEBUG - 2024-02-07 21:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:12:45 --> Input Class Initialized
INFO - 2024-02-07 21:12:45 --> Language Class Initialized
INFO - 2024-02-07 21:12:45 --> Output Class Initialized
INFO - 2024-02-07 21:12:45 --> Loader Class Initialized
INFO - 2024-02-07 21:12:45 --> Security Class Initialized
INFO - 2024-02-07 21:12:45 --> Helper loaded: url_helper
DEBUG - 2024-02-07 21:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:12:45 --> Input Class Initialized
INFO - 2024-02-07 21:12:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:12:45 --> Language Class Initialized
INFO - 2024-02-07 21:12:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:12:45 --> Loader Class Initialized
INFO - 2024-02-07 21:12:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:12:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:12:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:12:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:12:45 --> Controller Class Initialized
INFO - 2024-02-07 21:12:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:12:45 --> Final output sent to browser
DEBUG - 2024-02-07 21:12:45 --> Total execution time: 0.0212
INFO - 2024-02-07 21:12:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:12:45 --> Controller Class Initialized
INFO - 2024-02-07 21:12:45 --> Form Validation Class Initialized
INFO - 2024-02-07 21:12:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:12:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:12:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:12:48 --> Config Class Initialized
INFO - 2024-02-07 21:12:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:12:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:12:48 --> Utf8 Class Initialized
INFO - 2024-02-07 21:12:48 --> URI Class Initialized
INFO - 2024-02-07 21:12:48 --> Router Class Initialized
INFO - 2024-02-07 21:12:48 --> Output Class Initialized
INFO - 2024-02-07 21:12:48 --> Security Class Initialized
DEBUG - 2024-02-07 21:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:12:48 --> Input Class Initialized
INFO - 2024-02-07 21:12:48 --> Language Class Initialized
INFO - 2024-02-07 21:12:48 --> Loader Class Initialized
INFO - 2024-02-07 21:12:48 --> Helper loaded: url_helper
INFO - 2024-02-07 21:12:48 --> Helper loaded: file_helper
INFO - 2024-02-07 21:12:48 --> Helper loaded: form_helper
INFO - 2024-02-07 21:12:48 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:12:48 --> Controller Class Initialized
INFO - 2024-02-07 21:12:48 --> Form Validation Class Initialized
INFO - 2024-02-07 21:12:48 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:12:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:12:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 21:12:48 --> Final output sent to browser
DEBUG - 2024-02-07 21:12:48 --> Total execution time: 0.0274
ERROR - 2024-02-07 21:12:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:12:53 --> Config Class Initialized
INFO - 2024-02-07 21:12:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:12:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:12:53 --> Utf8 Class Initialized
INFO - 2024-02-07 21:12:53 --> URI Class Initialized
INFO - 2024-02-07 21:12:53 --> Router Class Initialized
INFO - 2024-02-07 21:12:53 --> Output Class Initialized
INFO - 2024-02-07 21:12:53 --> Security Class Initialized
DEBUG - 2024-02-07 21:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:12:53 --> Input Class Initialized
INFO - 2024-02-07 21:12:53 --> Language Class Initialized
INFO - 2024-02-07 21:12:53 --> Loader Class Initialized
INFO - 2024-02-07 21:12:53 --> Helper loaded: url_helper
INFO - 2024-02-07 21:12:53 --> Helper loaded: file_helper
INFO - 2024-02-07 21:12:53 --> Helper loaded: form_helper
INFO - 2024-02-07 21:12:53 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:12:53 --> Controller Class Initialized
INFO - 2024-02-07 21:12:53 --> Form Validation Class Initialized
INFO - 2024-02-07 21:12:53 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:12:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:12:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 21:12:53 --> Final output sent to browser
DEBUG - 2024-02-07 21:12:53 --> Total execution time: 0.0249
ERROR - 2024-02-07 21:13:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:13:00 --> Config Class Initialized
INFO - 2024-02-07 21:13:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:13:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:13:00 --> Utf8 Class Initialized
INFO - 2024-02-07 21:13:00 --> URI Class Initialized
INFO - 2024-02-07 21:13:00 --> Router Class Initialized
INFO - 2024-02-07 21:13:00 --> Output Class Initialized
INFO - 2024-02-07 21:13:00 --> Security Class Initialized
DEBUG - 2024-02-07 21:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:13:00 --> Input Class Initialized
INFO - 2024-02-07 21:13:00 --> Language Class Initialized
INFO - 2024-02-07 21:13:00 --> Loader Class Initialized
INFO - 2024-02-07 21:13:00 --> Helper loaded: url_helper
INFO - 2024-02-07 21:13:00 --> Helper loaded: file_helper
INFO - 2024-02-07 21:13:00 --> Helper loaded: form_helper
INFO - 2024-02-07 21:13:00 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:13:00 --> Controller Class Initialized
INFO - 2024-02-07 21:13:00 --> Form Validation Class Initialized
INFO - 2024-02-07 21:13:00 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:13:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:13:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 21:13:00 --> Final output sent to browser
DEBUG - 2024-02-07 21:13:00 --> Total execution time: 0.0333
ERROR - 2024-02-07 21:13:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:13:17 --> Config Class Initialized
INFO - 2024-02-07 21:13:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:13:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:13:17 --> Utf8 Class Initialized
INFO - 2024-02-07 21:13:17 --> URI Class Initialized
INFO - 2024-02-07 21:13:17 --> Router Class Initialized
INFO - 2024-02-07 21:13:17 --> Output Class Initialized
INFO - 2024-02-07 21:13:17 --> Security Class Initialized
DEBUG - 2024-02-07 21:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:13:17 --> Input Class Initialized
INFO - 2024-02-07 21:13:17 --> Language Class Initialized
INFO - 2024-02-07 21:13:17 --> Loader Class Initialized
INFO - 2024-02-07 21:13:17 --> Helper loaded: url_helper
INFO - 2024-02-07 21:13:17 --> Helper loaded: file_helper
INFO - 2024-02-07 21:13:17 --> Helper loaded: form_helper
INFO - 2024-02-07 21:13:17 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:13:17 --> Controller Class Initialized
INFO - 2024-02-07 21:13:17 --> Form Validation Class Initialized
INFO - 2024-02-07 21:13:17 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:13:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:13:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:13:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:13:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:13:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:13:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:13:17 --> Final output sent to browser
DEBUG - 2024-02-07 21:13:17 --> Total execution time: 0.0333
ERROR - 2024-02-07 21:13:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-07 21:13:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:13:18 --> Config Class Initialized
INFO - 2024-02-07 21:13:18 --> Hooks Class Initialized
INFO - 2024-02-07 21:13:18 --> Config Class Initialized
INFO - 2024-02-07 21:13:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:13:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:13:18 --> Utf8 Class Initialized
DEBUG - 2024-02-07 21:13:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:13:18 --> Utf8 Class Initialized
INFO - 2024-02-07 21:13:18 --> URI Class Initialized
INFO - 2024-02-07 21:13:18 --> URI Class Initialized
INFO - 2024-02-07 21:13:18 --> Router Class Initialized
INFO - 2024-02-07 21:13:18 --> Router Class Initialized
INFO - 2024-02-07 21:13:18 --> Output Class Initialized
INFO - 2024-02-07 21:13:18 --> Output Class Initialized
INFO - 2024-02-07 21:13:18 --> Security Class Initialized
INFO - 2024-02-07 21:13:18 --> Security Class Initialized
DEBUG - 2024-02-07 21:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 21:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:13:18 --> Input Class Initialized
INFO - 2024-02-07 21:13:18 --> Input Class Initialized
INFO - 2024-02-07 21:13:18 --> Language Class Initialized
INFO - 2024-02-07 21:13:18 --> Language Class Initialized
INFO - 2024-02-07 21:13:18 --> Loader Class Initialized
INFO - 2024-02-07 21:13:18 --> Loader Class Initialized
INFO - 2024-02-07 21:13:18 --> Helper loaded: url_helper
INFO - 2024-02-07 21:13:18 --> Helper loaded: url_helper
INFO - 2024-02-07 21:13:18 --> Helper loaded: file_helper
INFO - 2024-02-07 21:13:18 --> Helper loaded: file_helper
INFO - 2024-02-07 21:13:18 --> Helper loaded: form_helper
INFO - 2024-02-07 21:13:18 --> Helper loaded: form_helper
INFO - 2024-02-07 21:13:18 --> Database Driver Class Initialized
INFO - 2024-02-07 21:13:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:13:18 --> Controller Class Initialized
INFO - 2024-02-07 21:13:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:13:18 --> Final output sent to browser
DEBUG - 2024-02-07 21:13:18 --> Total execution time: 0.0228
DEBUG - 2024-02-07 21:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:13:18 --> Controller Class Initialized
INFO - 2024-02-07 21:13:18 --> Form Validation Class Initialized
INFO - 2024-02-07 21:13:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:13:18 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:13:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:13:23 --> Config Class Initialized
INFO - 2024-02-07 21:13:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:13:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:13:23 --> Utf8 Class Initialized
INFO - 2024-02-07 21:13:23 --> URI Class Initialized
INFO - 2024-02-07 21:13:23 --> Router Class Initialized
INFO - 2024-02-07 21:13:23 --> Output Class Initialized
INFO - 2024-02-07 21:13:23 --> Security Class Initialized
DEBUG - 2024-02-07 21:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:13:23 --> Input Class Initialized
INFO - 2024-02-07 21:13:23 --> Language Class Initialized
INFO - 2024-02-07 21:13:23 --> Loader Class Initialized
INFO - 2024-02-07 21:13:23 --> Helper loaded: url_helper
INFO - 2024-02-07 21:13:23 --> Helper loaded: file_helper
INFO - 2024-02-07 21:13:23 --> Helper loaded: form_helper
INFO - 2024-02-07 21:13:23 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:13:23 --> Controller Class Initialized
INFO - 2024-02-07 21:13:23 --> Form Validation Class Initialized
INFO - 2024-02-07 21:13:23 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:13:23 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:13:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:13:27 --> Config Class Initialized
INFO - 2024-02-07 21:13:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:13:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:13:27 --> Utf8 Class Initialized
INFO - 2024-02-07 21:13:27 --> URI Class Initialized
INFO - 2024-02-07 21:13:27 --> Router Class Initialized
INFO - 2024-02-07 21:13:27 --> Output Class Initialized
INFO - 2024-02-07 21:13:27 --> Security Class Initialized
DEBUG - 2024-02-07 21:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:13:27 --> Input Class Initialized
INFO - 2024-02-07 21:13:27 --> Language Class Initialized
INFO - 2024-02-07 21:13:27 --> Loader Class Initialized
INFO - 2024-02-07 21:13:27 --> Helper loaded: url_helper
INFO - 2024-02-07 21:13:27 --> Helper loaded: file_helper
INFO - 2024-02-07 21:13:27 --> Helper loaded: form_helper
INFO - 2024-02-07 21:13:27 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:13:27 --> Controller Class Initialized
INFO - 2024-02-07 21:13:27 --> Form Validation Class Initialized
INFO - 2024-02-07 21:13:27 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:13:27 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:13:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:13:32 --> Config Class Initialized
INFO - 2024-02-07 21:13:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:13:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:13:32 --> Utf8 Class Initialized
INFO - 2024-02-07 21:13:32 --> URI Class Initialized
INFO - 2024-02-07 21:13:32 --> Router Class Initialized
INFO - 2024-02-07 21:13:32 --> Output Class Initialized
INFO - 2024-02-07 21:13:32 --> Security Class Initialized
DEBUG - 2024-02-07 21:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:13:32 --> Input Class Initialized
INFO - 2024-02-07 21:13:32 --> Language Class Initialized
INFO - 2024-02-07 21:13:32 --> Loader Class Initialized
INFO - 2024-02-07 21:13:32 --> Helper loaded: url_helper
INFO - 2024-02-07 21:13:32 --> Helper loaded: file_helper
INFO - 2024-02-07 21:13:32 --> Helper loaded: form_helper
INFO - 2024-02-07 21:13:32 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:13:32 --> Controller Class Initialized
INFO - 2024-02-07 21:13:32 --> Form Validation Class Initialized
INFO - 2024-02-07 21:13:32 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:13:32 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:13:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:13:36 --> Config Class Initialized
INFO - 2024-02-07 21:13:36 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:13:36 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:13:36 --> Utf8 Class Initialized
INFO - 2024-02-07 21:13:36 --> URI Class Initialized
INFO - 2024-02-07 21:13:36 --> Router Class Initialized
INFO - 2024-02-07 21:13:36 --> Output Class Initialized
INFO - 2024-02-07 21:13:36 --> Security Class Initialized
DEBUG - 2024-02-07 21:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:13:36 --> Input Class Initialized
INFO - 2024-02-07 21:13:36 --> Language Class Initialized
INFO - 2024-02-07 21:13:36 --> Loader Class Initialized
INFO - 2024-02-07 21:13:36 --> Helper loaded: url_helper
INFO - 2024-02-07 21:13:36 --> Helper loaded: file_helper
INFO - 2024-02-07 21:13:36 --> Helper loaded: form_helper
INFO - 2024-02-07 21:13:36 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:13:36 --> Controller Class Initialized
INFO - 2024-02-07 21:13:36 --> Form Validation Class Initialized
INFO - 2024-02-07 21:13:36 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:13:36 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:13:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:13:39 --> Config Class Initialized
INFO - 2024-02-07 21:13:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:13:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:13:39 --> Utf8 Class Initialized
INFO - 2024-02-07 21:13:39 --> URI Class Initialized
INFO - 2024-02-07 21:13:39 --> Router Class Initialized
INFO - 2024-02-07 21:13:39 --> Output Class Initialized
INFO - 2024-02-07 21:13:39 --> Security Class Initialized
DEBUG - 2024-02-07 21:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:13:39 --> Input Class Initialized
INFO - 2024-02-07 21:13:39 --> Language Class Initialized
INFO - 2024-02-07 21:13:39 --> Loader Class Initialized
INFO - 2024-02-07 21:13:39 --> Helper loaded: url_helper
INFO - 2024-02-07 21:13:39 --> Helper loaded: file_helper
INFO - 2024-02-07 21:13:39 --> Helper loaded: form_helper
INFO - 2024-02-07 21:13:39 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:13:39 --> Controller Class Initialized
INFO - 2024-02-07 21:13:39 --> Form Validation Class Initialized
INFO - 2024-02-07 21:13:39 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:13:39 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:13:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:13:44 --> Config Class Initialized
INFO - 2024-02-07 21:13:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:13:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:13:44 --> Utf8 Class Initialized
INFO - 2024-02-07 21:13:44 --> URI Class Initialized
INFO - 2024-02-07 21:13:44 --> Router Class Initialized
INFO - 2024-02-07 21:13:44 --> Output Class Initialized
INFO - 2024-02-07 21:13:44 --> Security Class Initialized
DEBUG - 2024-02-07 21:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:13:44 --> Input Class Initialized
INFO - 2024-02-07 21:13:44 --> Language Class Initialized
INFO - 2024-02-07 21:13:44 --> Loader Class Initialized
INFO - 2024-02-07 21:13:44 --> Helper loaded: url_helper
INFO - 2024-02-07 21:13:44 --> Helper loaded: file_helper
INFO - 2024-02-07 21:13:44 --> Helper loaded: form_helper
INFO - 2024-02-07 21:13:44 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:13:44 --> Controller Class Initialized
INFO - 2024-02-07 21:13:44 --> Form Validation Class Initialized
INFO - 2024-02-07 21:13:44 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:13:44 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:14:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:14:07 --> Config Class Initialized
INFO - 2024-02-07 21:14:07 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:14:07 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:14:07 --> Utf8 Class Initialized
INFO - 2024-02-07 21:14:07 --> URI Class Initialized
INFO - 2024-02-07 21:14:07 --> Router Class Initialized
INFO - 2024-02-07 21:14:07 --> Output Class Initialized
INFO - 2024-02-07 21:14:07 --> Security Class Initialized
DEBUG - 2024-02-07 21:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:14:07 --> Input Class Initialized
INFO - 2024-02-07 21:14:07 --> Language Class Initialized
INFO - 2024-02-07 21:14:07 --> Loader Class Initialized
INFO - 2024-02-07 21:14:07 --> Helper loaded: url_helper
INFO - 2024-02-07 21:14:07 --> Helper loaded: file_helper
INFO - 2024-02-07 21:14:07 --> Helper loaded: form_helper
INFO - 2024-02-07 21:14:07 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:14:07 --> Controller Class Initialized
INFO - 2024-02-07 21:14:07 --> Form Validation Class Initialized
INFO - 2024-02-07 21:14:07 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:14:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:14:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 21:14:07 --> Final output sent to browser
DEBUG - 2024-02-07 21:14:07 --> Total execution time: 0.0320
ERROR - 2024-02-07 21:14:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:14:11 --> Config Class Initialized
INFO - 2024-02-07 21:14:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:14:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:14:11 --> Utf8 Class Initialized
INFO - 2024-02-07 21:14:11 --> URI Class Initialized
INFO - 2024-02-07 21:14:11 --> Router Class Initialized
INFO - 2024-02-07 21:14:11 --> Output Class Initialized
INFO - 2024-02-07 21:14:11 --> Security Class Initialized
DEBUG - 2024-02-07 21:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:14:11 --> Input Class Initialized
INFO - 2024-02-07 21:14:11 --> Language Class Initialized
INFO - 2024-02-07 21:14:11 --> Loader Class Initialized
INFO - 2024-02-07 21:14:11 --> Helper loaded: url_helper
INFO - 2024-02-07 21:14:11 --> Helper loaded: file_helper
INFO - 2024-02-07 21:14:11 --> Helper loaded: form_helper
INFO - 2024-02-07 21:14:11 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:14:11 --> Controller Class Initialized
INFO - 2024-02-07 21:14:11 --> Form Validation Class Initialized
INFO - 2024-02-07 21:14:11 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:14:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:14:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 21:14:11 --> Final output sent to browser
DEBUG - 2024-02-07 21:14:11 --> Total execution time: 0.0315
ERROR - 2024-02-07 21:15:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:15:27 --> Config Class Initialized
INFO - 2024-02-07 21:15:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:15:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:15:27 --> Utf8 Class Initialized
INFO - 2024-02-07 21:15:27 --> URI Class Initialized
INFO - 2024-02-07 21:15:27 --> Router Class Initialized
INFO - 2024-02-07 21:15:27 --> Output Class Initialized
INFO - 2024-02-07 21:15:27 --> Security Class Initialized
DEBUG - 2024-02-07 21:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:15:27 --> Input Class Initialized
INFO - 2024-02-07 21:15:27 --> Language Class Initialized
INFO - 2024-02-07 21:15:27 --> Loader Class Initialized
INFO - 2024-02-07 21:15:27 --> Helper loaded: url_helper
INFO - 2024-02-07 21:15:27 --> Helper loaded: file_helper
INFO - 2024-02-07 21:15:27 --> Helper loaded: form_helper
INFO - 2024-02-07 21:15:27 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:15:27 --> Controller Class Initialized
INFO - 2024-02-07 21:15:27 --> Form Validation Class Initialized
INFO - 2024-02-07 21:15:27 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:15:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:15:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:15:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:15:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:15:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:15:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:15:27 --> Final output sent to browser
DEBUG - 2024-02-07 21:15:27 --> Total execution time: 0.0307
ERROR - 2024-02-07 21:15:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:15:28 --> Config Class Initialized
INFO - 2024-02-07 21:15:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:15:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:15:28 --> Utf8 Class Initialized
INFO - 2024-02-07 21:15:28 --> URI Class Initialized
INFO - 2024-02-07 21:15:28 --> Router Class Initialized
INFO - 2024-02-07 21:15:28 --> Output Class Initialized
INFO - 2024-02-07 21:15:28 --> Security Class Initialized
DEBUG - 2024-02-07 21:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:15:28 --> Input Class Initialized
INFO - 2024-02-07 21:15:28 --> Language Class Initialized
INFO - 2024-02-07 21:15:28 --> Loader Class Initialized
INFO - 2024-02-07 21:15:28 --> Helper loaded: url_helper
INFO - 2024-02-07 21:15:28 --> Helper loaded: file_helper
INFO - 2024-02-07 21:15:28 --> Helper loaded: form_helper
INFO - 2024-02-07 21:15:28 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:15:28 --> Controller Class Initialized
INFO - 2024-02-07 21:15:28 --> Form Validation Class Initialized
INFO - 2024-02-07 21:15:28 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:15:28 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:15:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:15:28 --> Config Class Initialized
INFO - 2024-02-07 21:15:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:15:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:15:28 --> Utf8 Class Initialized
INFO - 2024-02-07 21:15:28 --> URI Class Initialized
INFO - 2024-02-07 21:15:28 --> Router Class Initialized
INFO - 2024-02-07 21:15:28 --> Output Class Initialized
INFO - 2024-02-07 21:15:28 --> Security Class Initialized
DEBUG - 2024-02-07 21:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:15:28 --> Input Class Initialized
INFO - 2024-02-07 21:15:28 --> Language Class Initialized
INFO - 2024-02-07 21:15:28 --> Loader Class Initialized
INFO - 2024-02-07 21:15:28 --> Helper loaded: url_helper
INFO - 2024-02-07 21:15:28 --> Helper loaded: file_helper
INFO - 2024-02-07 21:15:28 --> Helper loaded: form_helper
INFO - 2024-02-07 21:15:28 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:15:28 --> Controller Class Initialized
INFO - 2024-02-07 21:15:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:15:28 --> Final output sent to browser
DEBUG - 2024-02-07 21:15:28 --> Total execution time: 0.0263
ERROR - 2024-02-07 21:15:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:15:31 --> Config Class Initialized
INFO - 2024-02-07 21:15:31 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:15:31 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:15:31 --> Utf8 Class Initialized
INFO - 2024-02-07 21:15:31 --> URI Class Initialized
INFO - 2024-02-07 21:15:31 --> Router Class Initialized
INFO - 2024-02-07 21:15:31 --> Output Class Initialized
INFO - 2024-02-07 21:15:31 --> Security Class Initialized
DEBUG - 2024-02-07 21:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:15:31 --> Input Class Initialized
INFO - 2024-02-07 21:15:31 --> Language Class Initialized
INFO - 2024-02-07 21:15:31 --> Loader Class Initialized
INFO - 2024-02-07 21:15:31 --> Helper loaded: url_helper
INFO - 2024-02-07 21:15:31 --> Helper loaded: file_helper
INFO - 2024-02-07 21:15:31 --> Helper loaded: form_helper
INFO - 2024-02-07 21:15:31 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:15:31 --> Controller Class Initialized
INFO - 2024-02-07 21:15:31 --> Form Validation Class Initialized
INFO - 2024-02-07 21:15:31 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:15:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:15:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 21:15:31 --> Final output sent to browser
DEBUG - 2024-02-07 21:15:31 --> Total execution time: 0.0356
ERROR - 2024-02-07 21:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:16:03 --> Config Class Initialized
INFO - 2024-02-07 21:16:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:16:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:16:03 --> Utf8 Class Initialized
INFO - 2024-02-07 21:16:03 --> URI Class Initialized
INFO - 2024-02-07 21:16:03 --> Router Class Initialized
INFO - 2024-02-07 21:16:03 --> Output Class Initialized
INFO - 2024-02-07 21:16:03 --> Security Class Initialized
DEBUG - 2024-02-07 21:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:16:03 --> Input Class Initialized
INFO - 2024-02-07 21:16:03 --> Language Class Initialized
INFO - 2024-02-07 21:16:03 --> Loader Class Initialized
INFO - 2024-02-07 21:16:03 --> Helper loaded: url_helper
INFO - 2024-02-07 21:16:03 --> Helper loaded: file_helper
INFO - 2024-02-07 21:16:03 --> Helper loaded: form_helper
INFO - 2024-02-07 21:16:03 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:16:03 --> Controller Class Initialized
INFO - 2024-02-07 21:16:03 --> Form Validation Class Initialized
INFO - 2024-02-07 21:16:03 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:16:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:16:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:16:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:16:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:16:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:16:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:16:03 --> Final output sent to browser
DEBUG - 2024-02-07 21:16:03 --> Total execution time: 0.0333
ERROR - 2024-02-07 21:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:16:03 --> Config Class Initialized
INFO - 2024-02-07 21:16:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:16:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:16:03 --> Utf8 Class Initialized
INFO - 2024-02-07 21:16:03 --> URI Class Initialized
INFO - 2024-02-07 21:16:03 --> Router Class Initialized
INFO - 2024-02-07 21:16:03 --> Output Class Initialized
INFO - 2024-02-07 21:16:03 --> Security Class Initialized
DEBUG - 2024-02-07 21:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:16:03 --> Input Class Initialized
INFO - 2024-02-07 21:16:03 --> Language Class Initialized
INFO - 2024-02-07 21:16:03 --> Loader Class Initialized
INFO - 2024-02-07 21:16:03 --> Helper loaded: url_helper
INFO - 2024-02-07 21:16:03 --> Helper loaded: file_helper
INFO - 2024-02-07 21:16:03 --> Helper loaded: form_helper
INFO - 2024-02-07 21:16:03 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:16:03 --> Controller Class Initialized
INFO - 2024-02-07 21:16:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:16:03 --> Final output sent to browser
DEBUG - 2024-02-07 21:16:03 --> Total execution time: 0.0293
ERROR - 2024-02-07 21:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:16:03 --> Config Class Initialized
INFO - 2024-02-07 21:16:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:16:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:16:03 --> Utf8 Class Initialized
INFO - 2024-02-07 21:16:03 --> URI Class Initialized
INFO - 2024-02-07 21:16:03 --> Router Class Initialized
INFO - 2024-02-07 21:16:03 --> Output Class Initialized
INFO - 2024-02-07 21:16:03 --> Security Class Initialized
DEBUG - 2024-02-07 21:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:16:03 --> Input Class Initialized
INFO - 2024-02-07 21:16:03 --> Language Class Initialized
INFO - 2024-02-07 21:16:03 --> Loader Class Initialized
INFO - 2024-02-07 21:16:03 --> Helper loaded: url_helper
INFO - 2024-02-07 21:16:03 --> Helper loaded: file_helper
INFO - 2024-02-07 21:16:03 --> Helper loaded: form_helper
INFO - 2024-02-07 21:16:03 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:16:03 --> Controller Class Initialized
INFO - 2024-02-07 21:16:03 --> Form Validation Class Initialized
INFO - 2024-02-07 21:16:03 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:16:03 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:17:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:17:05 --> Config Class Initialized
INFO - 2024-02-07 21:17:05 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:17:05 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:17:05 --> Utf8 Class Initialized
INFO - 2024-02-07 21:17:05 --> URI Class Initialized
INFO - 2024-02-07 21:17:05 --> Router Class Initialized
INFO - 2024-02-07 21:17:05 --> Output Class Initialized
INFO - 2024-02-07 21:17:05 --> Security Class Initialized
DEBUG - 2024-02-07 21:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:17:05 --> Input Class Initialized
INFO - 2024-02-07 21:17:05 --> Language Class Initialized
INFO - 2024-02-07 21:17:05 --> Loader Class Initialized
INFO - 2024-02-07 21:17:05 --> Helper loaded: url_helper
INFO - 2024-02-07 21:17:05 --> Helper loaded: file_helper
INFO - 2024-02-07 21:17:05 --> Helper loaded: form_helper
INFO - 2024-02-07 21:17:05 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:17:05 --> Controller Class Initialized
INFO - 2024-02-07 21:17:05 --> Form Validation Class Initialized
INFO - 2024-02-07 21:17:05 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:17:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:17:05 --> Final output sent to browser
DEBUG - 2024-02-07 21:17:05 --> Total execution time: 0.0356
ERROR - 2024-02-07 21:17:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:17:07 --> Config Class Initialized
INFO - 2024-02-07 21:17:07 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:17:07 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:17:07 --> Utf8 Class Initialized
INFO - 2024-02-07 21:17:07 --> URI Class Initialized
INFO - 2024-02-07 21:17:07 --> Router Class Initialized
INFO - 2024-02-07 21:17:07 --> Output Class Initialized
INFO - 2024-02-07 21:17:07 --> Security Class Initialized
DEBUG - 2024-02-07 21:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:17:07 --> Input Class Initialized
INFO - 2024-02-07 21:17:07 --> Language Class Initialized
INFO - 2024-02-07 21:17:07 --> Loader Class Initialized
INFO - 2024-02-07 21:17:07 --> Helper loaded: url_helper
INFO - 2024-02-07 21:17:07 --> Helper loaded: file_helper
INFO - 2024-02-07 21:17:07 --> Helper loaded: form_helper
INFO - 2024-02-07 21:17:07 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:17:07 --> Controller Class Initialized
INFO - 2024-02-07 21:17:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:17:07 --> Final output sent to browser
DEBUG - 2024-02-07 21:17:07 --> Total execution time: 0.0197
ERROR - 2024-02-07 21:17:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:17:07 --> Config Class Initialized
INFO - 2024-02-07 21:17:07 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:17:07 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:17:07 --> Utf8 Class Initialized
INFO - 2024-02-07 21:17:07 --> URI Class Initialized
INFO - 2024-02-07 21:17:07 --> Router Class Initialized
INFO - 2024-02-07 21:17:07 --> Output Class Initialized
INFO - 2024-02-07 21:17:07 --> Security Class Initialized
DEBUG - 2024-02-07 21:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:17:07 --> Input Class Initialized
INFO - 2024-02-07 21:17:07 --> Language Class Initialized
INFO - 2024-02-07 21:17:07 --> Loader Class Initialized
INFO - 2024-02-07 21:17:07 --> Helper loaded: url_helper
INFO - 2024-02-07 21:17:07 --> Helper loaded: file_helper
INFO - 2024-02-07 21:17:07 --> Helper loaded: form_helper
INFO - 2024-02-07 21:17:07 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:17:07 --> Controller Class Initialized
INFO - 2024-02-07 21:17:07 --> Form Validation Class Initialized
INFO - 2024-02-07 21:17:07 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:17:07 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:18:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:18:51 --> Config Class Initialized
INFO - 2024-02-07 21:18:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:18:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:18:51 --> Utf8 Class Initialized
INFO - 2024-02-07 21:18:51 --> URI Class Initialized
INFO - 2024-02-07 21:18:51 --> Router Class Initialized
INFO - 2024-02-07 21:18:51 --> Output Class Initialized
INFO - 2024-02-07 21:18:51 --> Security Class Initialized
DEBUG - 2024-02-07 21:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:18:51 --> Input Class Initialized
INFO - 2024-02-07 21:18:51 --> Language Class Initialized
INFO - 2024-02-07 21:18:51 --> Loader Class Initialized
INFO - 2024-02-07 21:18:51 --> Helper loaded: url_helper
INFO - 2024-02-07 21:18:51 --> Helper loaded: file_helper
INFO - 2024-02-07 21:18:51 --> Helper loaded: form_helper
INFO - 2024-02-07 21:18:51 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:18:51 --> Controller Class Initialized
INFO - 2024-02-07 21:18:51 --> Form Validation Class Initialized
INFO - 2024-02-07 21:18:51 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:18:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:18:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:18:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:18:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:18:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:18:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:18:51 --> Final output sent to browser
DEBUG - 2024-02-07 21:18:51 --> Total execution time: 0.0319
ERROR - 2024-02-07 21:18:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:18:52 --> Config Class Initialized
INFO - 2024-02-07 21:18:52 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:18:52 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:18:52 --> Utf8 Class Initialized
INFO - 2024-02-07 21:18:52 --> URI Class Initialized
INFO - 2024-02-07 21:18:52 --> Router Class Initialized
INFO - 2024-02-07 21:18:52 --> Output Class Initialized
INFO - 2024-02-07 21:18:52 --> Security Class Initialized
DEBUG - 2024-02-07 21:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:18:52 --> Input Class Initialized
INFO - 2024-02-07 21:18:52 --> Language Class Initialized
INFO - 2024-02-07 21:18:52 --> Loader Class Initialized
INFO - 2024-02-07 21:18:52 --> Helper loaded: url_helper
INFO - 2024-02-07 21:18:52 --> Helper loaded: file_helper
INFO - 2024-02-07 21:18:52 --> Helper loaded: form_helper
INFO - 2024-02-07 21:18:52 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:18:52 --> Controller Class Initialized
INFO - 2024-02-07 21:18:52 --> Form Validation Class Initialized
INFO - 2024-02-07 21:18:52 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:18:52 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:18:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:18:53 --> Config Class Initialized
INFO - 2024-02-07 21:18:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:18:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:18:53 --> Utf8 Class Initialized
INFO - 2024-02-07 21:18:53 --> URI Class Initialized
INFO - 2024-02-07 21:18:53 --> Router Class Initialized
INFO - 2024-02-07 21:18:53 --> Output Class Initialized
INFO - 2024-02-07 21:18:53 --> Security Class Initialized
DEBUG - 2024-02-07 21:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:18:53 --> Input Class Initialized
INFO - 2024-02-07 21:18:53 --> Language Class Initialized
INFO - 2024-02-07 21:18:53 --> Loader Class Initialized
INFO - 2024-02-07 21:18:53 --> Helper loaded: url_helper
INFO - 2024-02-07 21:18:53 --> Helper loaded: file_helper
INFO - 2024-02-07 21:18:53 --> Helper loaded: form_helper
INFO - 2024-02-07 21:18:53 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:18:53 --> Controller Class Initialized
INFO - 2024-02-07 21:18:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:18:53 --> Final output sent to browser
DEBUG - 2024-02-07 21:18:53 --> Total execution time: 0.0181
ERROR - 2024-02-07 21:19:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:16 --> Config Class Initialized
INFO - 2024-02-07 21:19:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:16 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:16 --> URI Class Initialized
INFO - 2024-02-07 21:19:16 --> Router Class Initialized
INFO - 2024-02-07 21:19:16 --> Output Class Initialized
INFO - 2024-02-07 21:19:16 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:16 --> Input Class Initialized
INFO - 2024-02-07 21:19:16 --> Language Class Initialized
INFO - 2024-02-07 21:19:16 --> Loader Class Initialized
INFO - 2024-02-07 21:19:16 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:16 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:16 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:16 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:16 --> Controller Class Initialized
INFO - 2024-02-07 21:19:16 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:16 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:19:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:19:16 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:16 --> Total execution time: 0.0410
ERROR - 2024-02-07 21:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:17 --> Config Class Initialized
INFO - 2024-02-07 21:19:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:17 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:17 --> URI Class Initialized
INFO - 2024-02-07 21:19:17 --> Router Class Initialized
INFO - 2024-02-07 21:19:17 --> Output Class Initialized
INFO - 2024-02-07 21:19:17 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:17 --> Input Class Initialized
INFO - 2024-02-07 21:19:17 --> Language Class Initialized
INFO - 2024-02-07 21:19:17 --> Loader Class Initialized
INFO - 2024-02-07 21:19:17 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:17 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:17 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:17 --> Database Driver Class Initialized
ERROR - 2024-02-07 21:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:17 --> Config Class Initialized
INFO - 2024-02-07 21:19:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 21:19:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:17 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:17 --> Controller Class Initialized
INFO - 2024-02-07 21:19:17 --> URI Class Initialized
INFO - 2024-02-07 21:19:17 --> Router Class Initialized
INFO - 2024-02-07 21:19:17 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:17 --> Output Class Initialized
INFO - 2024-02-07 21:19:17 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:17 --> Security Class Initialized
INFO - 2024-02-07 21:19:17 --> Model "UserMasterModel" initialized
DEBUG - 2024-02-07 21:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:17 --> Input Class Initialized
INFO - 2024-02-07 21:19:17 --> Language Class Initialized
INFO - 2024-02-07 21:19:17 --> Loader Class Initialized
INFO - 2024-02-07 21:19:17 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:17 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:17 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:17 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:17 --> Controller Class Initialized
INFO - 2024-02-07 21:19:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:19:17 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:17 --> Total execution time: 0.0256
ERROR - 2024-02-07 21:19:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:26 --> Config Class Initialized
INFO - 2024-02-07 21:19:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:26 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:26 --> URI Class Initialized
INFO - 2024-02-07 21:19:26 --> Router Class Initialized
INFO - 2024-02-07 21:19:26 --> Output Class Initialized
INFO - 2024-02-07 21:19:26 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:26 --> Input Class Initialized
INFO - 2024-02-07 21:19:26 --> Language Class Initialized
INFO - 2024-02-07 21:19:26 --> Loader Class Initialized
INFO - 2024-02-07 21:19:26 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:26 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:26 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:26 --> Controller Class Initialized
INFO - 2024-02-07 21:19:26 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:26 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:19:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:19:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:19:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:19:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:19:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:19:26 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:26 --> Total execution time: 0.0356
ERROR - 2024-02-07 21:19:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:26 --> Config Class Initialized
INFO - 2024-02-07 21:19:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:26 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:26 --> URI Class Initialized
INFO - 2024-02-07 21:19:26 --> Router Class Initialized
INFO - 2024-02-07 21:19:26 --> Output Class Initialized
INFO - 2024-02-07 21:19:26 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:26 --> Input Class Initialized
INFO - 2024-02-07 21:19:26 --> Language Class Initialized
INFO - 2024-02-07 21:19:26 --> Loader Class Initialized
INFO - 2024-02-07 21:19:26 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:26 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:26 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:26 --> Controller Class Initialized
INFO - 2024-02-07 21:19:26 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:26 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:26 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:19:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:26 --> Config Class Initialized
INFO - 2024-02-07 21:19:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:26 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:26 --> URI Class Initialized
INFO - 2024-02-07 21:19:26 --> Router Class Initialized
INFO - 2024-02-07 21:19:26 --> Output Class Initialized
INFO - 2024-02-07 21:19:26 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:26 --> Input Class Initialized
INFO - 2024-02-07 21:19:26 --> Language Class Initialized
INFO - 2024-02-07 21:19:26 --> Loader Class Initialized
INFO - 2024-02-07 21:19:26 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:26 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:26 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:26 --> Controller Class Initialized
INFO - 2024-02-07 21:19:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:19:26 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:26 --> Total execution time: 0.0238
ERROR - 2024-02-07 21:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:38 --> Config Class Initialized
INFO - 2024-02-07 21:19:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:38 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:38 --> URI Class Initialized
INFO - 2024-02-07 21:19:38 --> Router Class Initialized
INFO - 2024-02-07 21:19:38 --> Output Class Initialized
INFO - 2024-02-07 21:19:38 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:38 --> Input Class Initialized
INFO - 2024-02-07 21:19:38 --> Language Class Initialized
INFO - 2024-02-07 21:19:38 --> Loader Class Initialized
INFO - 2024-02-07 21:19:38 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:38 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:38 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:38 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:38 --> Controller Class Initialized
INFO - 2024-02-07 21:19:38 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:38 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:19:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:19:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:19:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:19:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:19:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:19:38 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:38 --> Total execution time: 0.0273
ERROR - 2024-02-07 21:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-07 21:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:39 --> Config Class Initialized
INFO - 2024-02-07 21:19:39 --> Hooks Class Initialized
INFO - 2024-02-07 21:19:39 --> Config Class Initialized
INFO - 2024-02-07 21:19:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:39 --> Utf8 Class Initialized
DEBUG - 2024-02-07 21:19:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:39 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:39 --> URI Class Initialized
INFO - 2024-02-07 21:19:39 --> URI Class Initialized
INFO - 2024-02-07 21:19:39 --> Router Class Initialized
INFO - 2024-02-07 21:19:39 --> Router Class Initialized
INFO - 2024-02-07 21:19:39 --> Output Class Initialized
INFO - 2024-02-07 21:19:39 --> Output Class Initialized
INFO - 2024-02-07 21:19:39 --> Security Class Initialized
INFO - 2024-02-07 21:19:39 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:39 --> Input Class Initialized
DEBUG - 2024-02-07 21:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:39 --> Input Class Initialized
INFO - 2024-02-07 21:19:39 --> Language Class Initialized
INFO - 2024-02-07 21:19:39 --> Language Class Initialized
INFO - 2024-02-07 21:19:39 --> Loader Class Initialized
INFO - 2024-02-07 21:19:39 --> Loader Class Initialized
INFO - 2024-02-07 21:19:39 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:39 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:39 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:39 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:39 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:39 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:39 --> Database Driver Class Initialized
INFO - 2024-02-07 21:19:39 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 21:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:39 --> Controller Class Initialized
INFO - 2024-02-07 21:19:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:19:39 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:39 --> Total execution time: 0.0231
INFO - 2024-02-07 21:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:39 --> Controller Class Initialized
INFO - 2024-02-07 21:19:39 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:39 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:39 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:45 --> Config Class Initialized
INFO - 2024-02-07 21:19:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:45 --> URI Class Initialized
INFO - 2024-02-07 21:19:45 --> Router Class Initialized
INFO - 2024-02-07 21:19:45 --> Output Class Initialized
INFO - 2024-02-07 21:19:45 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:45 --> Input Class Initialized
INFO - 2024-02-07 21:19:45 --> Language Class Initialized
INFO - 2024-02-07 21:19:45 --> Loader Class Initialized
INFO - 2024-02-07 21:19:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:45 --> Controller Class Initialized
INFO - 2024-02-07 21:19:45 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:19:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:19:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:19:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:19:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:19:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:19:45 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:45 --> Total execution time: 0.0230
ERROR - 2024-02-07 21:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-07 21:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:45 --> Config Class Initialized
INFO - 2024-02-07 21:19:45 --> Hooks Class Initialized
INFO - 2024-02-07 21:19:45 --> Config Class Initialized
INFO - 2024-02-07 21:19:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:45 --> Utf8 Class Initialized
DEBUG - 2024-02-07 21:19:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:45 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:45 --> URI Class Initialized
INFO - 2024-02-07 21:19:45 --> URI Class Initialized
INFO - 2024-02-07 21:19:45 --> Router Class Initialized
INFO - 2024-02-07 21:19:45 --> Router Class Initialized
INFO - 2024-02-07 21:19:45 --> Output Class Initialized
INFO - 2024-02-07 21:19:45 --> Output Class Initialized
INFO - 2024-02-07 21:19:45 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:45 --> Input Class Initialized
INFO - 2024-02-07 21:19:45 --> Security Class Initialized
INFO - 2024-02-07 21:19:45 --> Language Class Initialized
DEBUG - 2024-02-07 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:45 --> Input Class Initialized
INFO - 2024-02-07 21:19:45 --> Language Class Initialized
INFO - 2024-02-07 21:19:45 --> Loader Class Initialized
INFO - 2024-02-07 21:19:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:45 --> Loader Class Initialized
INFO - 2024-02-07 21:19:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:45 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:45 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:45 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:45 --> Database Driver Class Initialized
INFO - 2024-02-07 21:19:45 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:45 --> Controller Class Initialized
INFO - 2024-02-07 21:19:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:19:45 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:45 --> Total execution time: 0.0169
DEBUG - 2024-02-07 21:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:45 --> Controller Class Initialized
INFO - 2024-02-07 21:19:45 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:45 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:54 --> Config Class Initialized
INFO - 2024-02-07 21:19:54 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:54 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:54 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:54 --> URI Class Initialized
INFO - 2024-02-07 21:19:54 --> Router Class Initialized
INFO - 2024-02-07 21:19:54 --> Output Class Initialized
INFO - 2024-02-07 21:19:54 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:54 --> Input Class Initialized
INFO - 2024-02-07 21:19:54 --> Language Class Initialized
INFO - 2024-02-07 21:19:54 --> Loader Class Initialized
INFO - 2024-02-07 21:19:54 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:54 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:54 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:54 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:54 --> Controller Class Initialized
INFO - 2024-02-07 21:19:54 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:54 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:19:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:19:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:19:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:19:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:19:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:19:54 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:54 --> Total execution time: 0.0315
ERROR - 2024-02-07 21:19:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-07 21:19:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:55 --> Config Class Initialized
INFO - 2024-02-07 21:19:55 --> Config Class Initialized
INFO - 2024-02-07 21:19:55 --> Hooks Class Initialized
INFO - 2024-02-07 21:19:55 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 21:19:55 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:55 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:55 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:55 --> URI Class Initialized
INFO - 2024-02-07 21:19:55 --> URI Class Initialized
INFO - 2024-02-07 21:19:55 --> Router Class Initialized
INFO - 2024-02-07 21:19:55 --> Router Class Initialized
INFO - 2024-02-07 21:19:55 --> Output Class Initialized
INFO - 2024-02-07 21:19:55 --> Output Class Initialized
INFO - 2024-02-07 21:19:55 --> Security Class Initialized
INFO - 2024-02-07 21:19:55 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 21:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:55 --> Input Class Initialized
INFO - 2024-02-07 21:19:55 --> Input Class Initialized
INFO - 2024-02-07 21:19:55 --> Language Class Initialized
INFO - 2024-02-07 21:19:55 --> Language Class Initialized
INFO - 2024-02-07 21:19:55 --> Loader Class Initialized
INFO - 2024-02-07 21:19:55 --> Loader Class Initialized
INFO - 2024-02-07 21:19:55 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:55 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:55 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:55 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:55 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:55 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:55 --> Database Driver Class Initialized
INFO - 2024-02-07 21:19:55 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:55 --> Controller Class Initialized
DEBUG - 2024-02-07 21:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:55 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:55 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:55 --> Controller Class Initialized
INFO - 2024-02-07 21:19:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:19:55 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:55 --> Total execution time: 0.0290
ERROR - 2024-02-07 21:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:57 --> Config Class Initialized
INFO - 2024-02-07 21:19:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:57 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:57 --> URI Class Initialized
INFO - 2024-02-07 21:19:57 --> Router Class Initialized
INFO - 2024-02-07 21:19:57 --> Output Class Initialized
INFO - 2024-02-07 21:19:57 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:57 --> Input Class Initialized
INFO - 2024-02-07 21:19:57 --> Language Class Initialized
INFO - 2024-02-07 21:19:57 --> Loader Class Initialized
INFO - 2024-02-07 21:19:57 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:57 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:57 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:57 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:57 --> Controller Class Initialized
INFO - 2024-02-07 21:19:57 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:19:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:19:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:19:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:19:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:19:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:19:57 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:57 --> Total execution time: 0.0353
ERROR - 2024-02-07 21:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:57 --> Config Class Initialized
INFO - 2024-02-07 21:19:57 --> Hooks Class Initialized
ERROR - 2024-02-07 21:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2024-02-07 21:19:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:57 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:57 --> Config Class Initialized
INFO - 2024-02-07 21:19:57 --> Hooks Class Initialized
INFO - 2024-02-07 21:19:57 --> URI Class Initialized
INFO - 2024-02-07 21:19:57 --> Router Class Initialized
DEBUG - 2024-02-07 21:19:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:57 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:57 --> URI Class Initialized
INFO - 2024-02-07 21:19:57 --> Output Class Initialized
INFO - 2024-02-07 21:19:57 --> Router Class Initialized
INFO - 2024-02-07 21:19:57 --> Security Class Initialized
INFO - 2024-02-07 21:19:57 --> Output Class Initialized
DEBUG - 2024-02-07 21:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:57 --> Input Class Initialized
INFO - 2024-02-07 21:19:57 --> Language Class Initialized
INFO - 2024-02-07 21:19:57 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:57 --> Input Class Initialized
INFO - 2024-02-07 21:19:57 --> Loader Class Initialized
INFO - 2024-02-07 21:19:57 --> Language Class Initialized
INFO - 2024-02-07 21:19:57 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:57 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:57 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:57 --> Loader Class Initialized
INFO - 2024-02-07 21:19:57 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:57 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:57 --> Database Driver Class Initialized
INFO - 2024-02-07 21:19:57 --> Helper loaded: form_helper
DEBUG - 2024-02-07 21:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:57 --> Database Driver Class Initialized
INFO - 2024-02-07 21:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:57 --> Controller Class Initialized
INFO - 2024-02-07 21:19:57 --> Form Validation Class Initialized
DEBUG - 2024-02-07 21:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:57 --> Controller Class Initialized
INFO - 2024-02-07 21:19:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:19:57 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:57 --> Total execution time: 0.0309
ERROR - 2024-02-07 21:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:58 --> Config Class Initialized
INFO - 2024-02-07 21:19:58 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:58 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:58 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:58 --> URI Class Initialized
INFO - 2024-02-07 21:19:58 --> Router Class Initialized
INFO - 2024-02-07 21:19:58 --> Output Class Initialized
INFO - 2024-02-07 21:19:58 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:58 --> Input Class Initialized
INFO - 2024-02-07 21:19:58 --> Language Class Initialized
INFO - 2024-02-07 21:19:58 --> Loader Class Initialized
INFO - 2024-02-07 21:19:58 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:58 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:58 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:58 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:58 --> Controller Class Initialized
INFO - 2024-02-07 21:19:58 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:58 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:19:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:19:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:19:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:19:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:19:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:19:58 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:58 --> Total execution time: 0.0377
ERROR - 2024-02-07 21:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:58 --> Config Class Initialized
INFO - 2024-02-07 21:19:58 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:58 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:58 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:58 --> URI Class Initialized
INFO - 2024-02-07 21:19:58 --> Router Class Initialized
INFO - 2024-02-07 21:19:58 --> Output Class Initialized
INFO - 2024-02-07 21:19:58 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:58 --> Input Class Initialized
INFO - 2024-02-07 21:19:58 --> Language Class Initialized
INFO - 2024-02-07 21:19:58 --> Loader Class Initialized
INFO - 2024-02-07 21:19:58 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:58 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:58 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:58 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:58 --> Controller Class Initialized
INFO - 2024-02-07 21:19:58 --> Form Validation Class Initialized
INFO - 2024-02-07 21:19:58 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:19:58 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:19:58 --> Config Class Initialized
INFO - 2024-02-07 21:19:58 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:19:58 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:19:58 --> Utf8 Class Initialized
INFO - 2024-02-07 21:19:58 --> URI Class Initialized
INFO - 2024-02-07 21:19:58 --> Router Class Initialized
INFO - 2024-02-07 21:19:58 --> Output Class Initialized
INFO - 2024-02-07 21:19:58 --> Security Class Initialized
DEBUG - 2024-02-07 21:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:19:58 --> Input Class Initialized
INFO - 2024-02-07 21:19:58 --> Language Class Initialized
INFO - 2024-02-07 21:19:58 --> Loader Class Initialized
INFO - 2024-02-07 21:19:58 --> Helper loaded: url_helper
INFO - 2024-02-07 21:19:58 --> Helper loaded: file_helper
INFO - 2024-02-07 21:19:58 --> Helper loaded: form_helper
INFO - 2024-02-07 21:19:58 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:19:58 --> Controller Class Initialized
INFO - 2024-02-07 21:19:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:19:58 --> Final output sent to browser
DEBUG - 2024-02-07 21:19:58 --> Total execution time: 0.0330
ERROR - 2024-02-07 21:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:20:13 --> Config Class Initialized
INFO - 2024-02-07 21:20:13 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:20:13 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:20:13 --> Utf8 Class Initialized
INFO - 2024-02-07 21:20:13 --> URI Class Initialized
INFO - 2024-02-07 21:20:13 --> Router Class Initialized
INFO - 2024-02-07 21:20:13 --> Output Class Initialized
INFO - 2024-02-07 21:20:13 --> Security Class Initialized
DEBUG - 2024-02-07 21:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:20:13 --> Input Class Initialized
INFO - 2024-02-07 21:20:13 --> Language Class Initialized
INFO - 2024-02-07 21:20:13 --> Loader Class Initialized
INFO - 2024-02-07 21:20:13 --> Helper loaded: url_helper
INFO - 2024-02-07 21:20:13 --> Helper loaded: file_helper
INFO - 2024-02-07 21:20:13 --> Helper loaded: form_helper
INFO - 2024-02-07 21:20:13 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:20:13 --> Controller Class Initialized
INFO - 2024-02-07 21:20:13 --> Form Validation Class Initialized
INFO - 2024-02-07 21:20:13 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:20:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:20:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 21:20:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 21:20:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 21:20:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 21:20:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 21:20:13 --> Final output sent to browser
DEBUG - 2024-02-07 21:20:13 --> Total execution time: 0.0314
ERROR - 2024-02-07 21:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:20:14 --> Config Class Initialized
INFO - 2024-02-07 21:20:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:20:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:20:14 --> Utf8 Class Initialized
INFO - 2024-02-07 21:20:14 --> URI Class Initialized
INFO - 2024-02-07 21:20:14 --> Router Class Initialized
INFO - 2024-02-07 21:20:14 --> Output Class Initialized
INFO - 2024-02-07 21:20:14 --> Security Class Initialized
DEBUG - 2024-02-07 21:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:20:14 --> Input Class Initialized
INFO - 2024-02-07 21:20:14 --> Language Class Initialized
ERROR - 2024-02-07 21:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:20:14 --> Config Class Initialized
INFO - 2024-02-07 21:20:14 --> Hooks Class Initialized
INFO - 2024-02-07 21:20:14 --> Loader Class Initialized
INFO - 2024-02-07 21:20:14 --> Helper loaded: url_helper
INFO - 2024-02-07 21:20:14 --> Helper loaded: file_helper
INFO - 2024-02-07 21:20:14 --> Helper loaded: form_helper
DEBUG - 2024-02-07 21:20:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:20:14 --> Utf8 Class Initialized
INFO - 2024-02-07 21:20:14 --> URI Class Initialized
INFO - 2024-02-07 21:20:14 --> Router Class Initialized
INFO - 2024-02-07 21:20:14 --> Database Driver Class Initialized
INFO - 2024-02-07 21:20:14 --> Output Class Initialized
INFO - 2024-02-07 21:20:14 --> Security Class Initialized
DEBUG - 2024-02-07 21:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:20:14 --> Input Class Initialized
INFO - 2024-02-07 21:20:14 --> Language Class Initialized
DEBUG - 2024-02-07 21:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:20:14 --> Controller Class Initialized
INFO - 2024-02-07 21:20:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 21:20:14 --> Final output sent to browser
DEBUG - 2024-02-07 21:20:14 --> Total execution time: 0.0239
INFO - 2024-02-07 21:20:14 --> Loader Class Initialized
INFO - 2024-02-07 21:20:14 --> Helper loaded: url_helper
INFO - 2024-02-07 21:20:14 --> Helper loaded: file_helper
INFO - 2024-02-07 21:20:14 --> Helper loaded: form_helper
INFO - 2024-02-07 21:20:14 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:20:14 --> Controller Class Initialized
INFO - 2024-02-07 21:20:14 --> Form Validation Class Initialized
INFO - 2024-02-07 21:20:14 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:20:14 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 21:20:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:20:18 --> Config Class Initialized
INFO - 2024-02-07 21:20:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:20:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:20:18 --> Utf8 Class Initialized
INFO - 2024-02-07 21:20:18 --> URI Class Initialized
INFO - 2024-02-07 21:20:18 --> Router Class Initialized
INFO - 2024-02-07 21:20:18 --> Output Class Initialized
INFO - 2024-02-07 21:20:18 --> Security Class Initialized
DEBUG - 2024-02-07 21:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:20:18 --> Input Class Initialized
INFO - 2024-02-07 21:20:18 --> Language Class Initialized
INFO - 2024-02-07 21:20:18 --> Loader Class Initialized
INFO - 2024-02-07 21:20:18 --> Helper loaded: url_helper
INFO - 2024-02-07 21:20:18 --> Helper loaded: file_helper
INFO - 2024-02-07 21:20:18 --> Helper loaded: form_helper
INFO - 2024-02-07 21:20:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:20:18 --> Controller Class Initialized
INFO - 2024-02-07 21:20:18 --> Form Validation Class Initialized
INFO - 2024-02-07 21:20:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:20:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 21:20:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 21:20:18 --> Final output sent to browser
DEBUG - 2024-02-07 21:20:18 --> Total execution time: 0.0370
ERROR - 2024-02-07 21:20:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 21:20:21 --> Config Class Initialized
INFO - 2024-02-07 21:20:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 21:20:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 21:20:21 --> Utf8 Class Initialized
INFO - 2024-02-07 21:20:21 --> URI Class Initialized
INFO - 2024-02-07 21:20:21 --> Router Class Initialized
INFO - 2024-02-07 21:20:21 --> Output Class Initialized
INFO - 2024-02-07 21:20:21 --> Security Class Initialized
DEBUG - 2024-02-07 21:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 21:20:21 --> Input Class Initialized
INFO - 2024-02-07 21:20:21 --> Language Class Initialized
INFO - 2024-02-07 21:20:21 --> Loader Class Initialized
INFO - 2024-02-07 21:20:21 --> Helper loaded: url_helper
INFO - 2024-02-07 21:20:21 --> Helper loaded: file_helper
INFO - 2024-02-07 21:20:21 --> Helper loaded: form_helper
INFO - 2024-02-07 21:20:21 --> Database Driver Class Initialized
DEBUG - 2024-02-07 21:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 21:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 21:20:21 --> Controller Class Initialized
INFO - 2024-02-07 21:20:21 --> Form Validation Class Initialized
INFO - 2024-02-07 21:20:21 --> Model "MasterModel" initialized
INFO - 2024-02-07 21:20:21 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:04:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:04:19 --> Config Class Initialized
INFO - 2024-02-07 22:04:19 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:04:19 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:04:19 --> Utf8 Class Initialized
INFO - 2024-02-07 22:04:19 --> URI Class Initialized
INFO - 2024-02-07 22:04:19 --> Router Class Initialized
INFO - 2024-02-07 22:04:19 --> Output Class Initialized
INFO - 2024-02-07 22:04:19 --> Security Class Initialized
DEBUG - 2024-02-07 22:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:04:19 --> Input Class Initialized
INFO - 2024-02-07 22:04:19 --> Language Class Initialized
INFO - 2024-02-07 22:04:19 --> Loader Class Initialized
INFO - 2024-02-07 22:04:19 --> Helper loaded: url_helper
INFO - 2024-02-07 22:04:19 --> Helper loaded: file_helper
INFO - 2024-02-07 22:04:19 --> Helper loaded: form_helper
INFO - 2024-02-07 22:04:19 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:04:19 --> Controller Class Initialized
INFO - 2024-02-07 22:04:19 --> Form Validation Class Initialized
INFO - 2024-02-07 22:04:19 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:04:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:04:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:04:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:04:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:04:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:04:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:04:19 --> Final output sent to browser
DEBUG - 2024-02-07 22:04:19 --> Total execution time: 0.0366
ERROR - 2024-02-07 22:04:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:04:19 --> Config Class Initialized
INFO - 2024-02-07 22:04:19 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:04:19 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:04:19 --> Utf8 Class Initialized
INFO - 2024-02-07 22:04:19 --> URI Class Initialized
INFO - 2024-02-07 22:04:19 --> Router Class Initialized
INFO - 2024-02-07 22:04:19 --> Output Class Initialized
INFO - 2024-02-07 22:04:19 --> Security Class Initialized
DEBUG - 2024-02-07 22:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:04:19 --> Input Class Initialized
INFO - 2024-02-07 22:04:19 --> Language Class Initialized
INFO - 2024-02-07 22:04:19 --> Loader Class Initialized
INFO - 2024-02-07 22:04:19 --> Helper loaded: url_helper
INFO - 2024-02-07 22:04:19 --> Helper loaded: file_helper
INFO - 2024-02-07 22:04:19 --> Helper loaded: form_helper
INFO - 2024-02-07 22:04:19 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:04:19 --> Controller Class Initialized
INFO - 2024-02-07 22:04:19 --> Form Validation Class Initialized
INFO - 2024-02-07 22:04:19 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:04:19 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:04:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:04:20 --> Config Class Initialized
INFO - 2024-02-07 22:04:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:04:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:04:20 --> Utf8 Class Initialized
INFO - 2024-02-07 22:04:20 --> URI Class Initialized
INFO - 2024-02-07 22:04:20 --> Router Class Initialized
INFO - 2024-02-07 22:04:20 --> Output Class Initialized
INFO - 2024-02-07 22:04:20 --> Security Class Initialized
DEBUG - 2024-02-07 22:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:04:20 --> Input Class Initialized
INFO - 2024-02-07 22:04:20 --> Language Class Initialized
INFO - 2024-02-07 22:04:20 --> Loader Class Initialized
INFO - 2024-02-07 22:04:20 --> Helper loaded: url_helper
INFO - 2024-02-07 22:04:20 --> Helper loaded: file_helper
INFO - 2024-02-07 22:04:20 --> Helper loaded: form_helper
INFO - 2024-02-07 22:04:20 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:04:20 --> Controller Class Initialized
INFO - 2024-02-07 22:04:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:04:20 --> Final output sent to browser
DEBUG - 2024-02-07 22:04:20 --> Total execution time: 0.0227
ERROR - 2024-02-07 22:04:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:04:28 --> Config Class Initialized
INFO - 2024-02-07 22:04:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:04:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:04:28 --> Utf8 Class Initialized
INFO - 2024-02-07 22:04:28 --> URI Class Initialized
INFO - 2024-02-07 22:04:28 --> Router Class Initialized
INFO - 2024-02-07 22:04:28 --> Output Class Initialized
INFO - 2024-02-07 22:04:28 --> Security Class Initialized
DEBUG - 2024-02-07 22:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:04:28 --> Input Class Initialized
INFO - 2024-02-07 22:04:28 --> Language Class Initialized
INFO - 2024-02-07 22:04:28 --> Loader Class Initialized
INFO - 2024-02-07 22:04:28 --> Helper loaded: url_helper
INFO - 2024-02-07 22:04:28 --> Helper loaded: file_helper
INFO - 2024-02-07 22:04:28 --> Helper loaded: form_helper
INFO - 2024-02-07 22:04:28 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:04:28 --> Controller Class Initialized
INFO - 2024-02-07 22:04:28 --> Form Validation Class Initialized
INFO - 2024-02-07 22:04:28 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:04:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:04:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-07 22:04:28 --> Final output sent to browser
DEBUG - 2024-02-07 22:04:28 --> Total execution time: 0.0304
ERROR - 2024-02-07 22:04:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:04:31 --> Config Class Initialized
INFO - 2024-02-07 22:04:31 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:04:31 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:04:31 --> Utf8 Class Initialized
INFO - 2024-02-07 22:04:31 --> URI Class Initialized
INFO - 2024-02-07 22:04:31 --> Router Class Initialized
INFO - 2024-02-07 22:04:31 --> Output Class Initialized
INFO - 2024-02-07 22:04:31 --> Security Class Initialized
DEBUG - 2024-02-07 22:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:04:31 --> Input Class Initialized
INFO - 2024-02-07 22:04:31 --> Language Class Initialized
INFO - 2024-02-07 22:04:31 --> Loader Class Initialized
INFO - 2024-02-07 22:04:31 --> Helper loaded: url_helper
INFO - 2024-02-07 22:04:31 --> Helper loaded: file_helper
INFO - 2024-02-07 22:04:31 --> Helper loaded: form_helper
INFO - 2024-02-07 22:04:31 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:04:31 --> Controller Class Initialized
INFO - 2024-02-07 22:04:31 --> Form Validation Class Initialized
INFO - 2024-02-07 22:04:31 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:04:31 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:04:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:04:31 --> Config Class Initialized
INFO - 2024-02-07 22:04:31 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:04:31 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:04:31 --> Utf8 Class Initialized
INFO - 2024-02-07 22:04:31 --> URI Class Initialized
INFO - 2024-02-07 22:04:31 --> Router Class Initialized
INFO - 2024-02-07 22:04:31 --> Output Class Initialized
INFO - 2024-02-07 22:04:31 --> Security Class Initialized
DEBUG - 2024-02-07 22:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:04:31 --> Input Class Initialized
INFO - 2024-02-07 22:04:31 --> Language Class Initialized
INFO - 2024-02-07 22:04:31 --> Loader Class Initialized
INFO - 2024-02-07 22:04:31 --> Helper loaded: url_helper
INFO - 2024-02-07 22:04:31 --> Helper loaded: file_helper
INFO - 2024-02-07 22:04:31 --> Helper loaded: form_helper
INFO - 2024-02-07 22:04:31 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:04:31 --> Controller Class Initialized
INFO - 2024-02-07 22:04:31 --> Form Validation Class Initialized
INFO - 2024-02-07 22:04:31 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:04:31 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:05:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:05:30 --> Config Class Initialized
INFO - 2024-02-07 22:05:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:05:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:05:30 --> Utf8 Class Initialized
INFO - 2024-02-07 22:05:30 --> URI Class Initialized
INFO - 2024-02-07 22:05:30 --> Router Class Initialized
INFO - 2024-02-07 22:05:30 --> Output Class Initialized
INFO - 2024-02-07 22:05:30 --> Security Class Initialized
DEBUG - 2024-02-07 22:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:05:30 --> Input Class Initialized
INFO - 2024-02-07 22:05:30 --> Language Class Initialized
INFO - 2024-02-07 22:05:30 --> Loader Class Initialized
INFO - 2024-02-07 22:05:30 --> Helper loaded: url_helper
INFO - 2024-02-07 22:05:30 --> Helper loaded: file_helper
INFO - 2024-02-07 22:05:30 --> Helper loaded: form_helper
INFO - 2024-02-07 22:05:30 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:05:30 --> Controller Class Initialized
INFO - 2024-02-07 22:05:30 --> Form Validation Class Initialized
INFO - 2024-02-07 22:05:30 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:05:30 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:05:30 --> Severity: Notice --> Undefined property: UserMaster::$brandMaster D:\xampp\htdocs\sscy\application\controllers\app\UserMaster.php 68
ERROR - 2024-02-07 22:05:30 --> Severity: error --> Exception: Call to a member function delete() on null D:\xampp\htdocs\sscy\application\controllers\app\UserMaster.php 68
ERROR - 2024-02-07 22:05:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:05:54 --> Config Class Initialized
INFO - 2024-02-07 22:05:54 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:05:54 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:05:54 --> Utf8 Class Initialized
INFO - 2024-02-07 22:05:54 --> URI Class Initialized
INFO - 2024-02-07 22:05:54 --> Router Class Initialized
INFO - 2024-02-07 22:05:54 --> Output Class Initialized
INFO - 2024-02-07 22:05:54 --> Security Class Initialized
DEBUG - 2024-02-07 22:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:05:54 --> Input Class Initialized
INFO - 2024-02-07 22:05:54 --> Language Class Initialized
INFO - 2024-02-07 22:05:54 --> Loader Class Initialized
INFO - 2024-02-07 22:05:54 --> Helper loaded: url_helper
INFO - 2024-02-07 22:05:54 --> Helper loaded: file_helper
INFO - 2024-02-07 22:05:54 --> Helper loaded: form_helper
INFO - 2024-02-07 22:05:54 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:05:54 --> Controller Class Initialized
INFO - 2024-02-07 22:05:54 --> Form Validation Class Initialized
INFO - 2024-02-07 22:05:54 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:05:54 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:05:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:05:54 --> Config Class Initialized
INFO - 2024-02-07 22:05:54 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:05:54 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:05:54 --> Utf8 Class Initialized
INFO - 2024-02-07 22:05:54 --> URI Class Initialized
INFO - 2024-02-07 22:05:54 --> Router Class Initialized
INFO - 2024-02-07 22:05:54 --> Output Class Initialized
INFO - 2024-02-07 22:05:54 --> Security Class Initialized
DEBUG - 2024-02-07 22:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:05:54 --> Input Class Initialized
INFO - 2024-02-07 22:05:54 --> Language Class Initialized
INFO - 2024-02-07 22:05:54 --> Loader Class Initialized
INFO - 2024-02-07 22:05:54 --> Helper loaded: url_helper
INFO - 2024-02-07 22:05:54 --> Helper loaded: file_helper
INFO - 2024-02-07 22:05:54 --> Helper loaded: form_helper
INFO - 2024-02-07 22:05:54 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:05:54 --> Controller Class Initialized
INFO - 2024-02-07 22:05:54 --> Form Validation Class Initialized
INFO - 2024-02-07 22:05:54 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:05:54 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:06:30 --> Config Class Initialized
INFO - 2024-02-07 22:06:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:06:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:06:30 --> Utf8 Class Initialized
INFO - 2024-02-07 22:06:30 --> URI Class Initialized
INFO - 2024-02-07 22:06:30 --> Router Class Initialized
INFO - 2024-02-07 22:06:30 --> Output Class Initialized
INFO - 2024-02-07 22:06:30 --> Security Class Initialized
DEBUG - 2024-02-07 22:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:06:30 --> Input Class Initialized
INFO - 2024-02-07 22:06:30 --> Language Class Initialized
INFO - 2024-02-07 22:06:30 --> Loader Class Initialized
INFO - 2024-02-07 22:06:30 --> Helper loaded: url_helper
INFO - 2024-02-07 22:06:30 --> Helper loaded: file_helper
INFO - 2024-02-07 22:06:30 --> Helper loaded: form_helper
INFO - 2024-02-07 22:06:30 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:06:30 --> Controller Class Initialized
INFO - 2024-02-07 22:06:30 --> Form Validation Class Initialized
INFO - 2024-02-07 22:06:30 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:06:30 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:06:30 --> Config Class Initialized
INFO - 2024-02-07 22:06:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:06:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:06:30 --> Utf8 Class Initialized
INFO - 2024-02-07 22:06:30 --> URI Class Initialized
INFO - 2024-02-07 22:06:30 --> Router Class Initialized
INFO - 2024-02-07 22:06:30 --> Output Class Initialized
INFO - 2024-02-07 22:06:30 --> Security Class Initialized
DEBUG - 2024-02-07 22:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:06:30 --> Input Class Initialized
INFO - 2024-02-07 22:06:30 --> Language Class Initialized
INFO - 2024-02-07 22:06:30 --> Loader Class Initialized
INFO - 2024-02-07 22:06:30 --> Helper loaded: url_helper
INFO - 2024-02-07 22:06:30 --> Helper loaded: file_helper
INFO - 2024-02-07 22:06:30 --> Helper loaded: form_helper
INFO - 2024-02-07 22:06:30 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:06:30 --> Controller Class Initialized
INFO - 2024-02-07 22:06:30 --> Form Validation Class Initialized
INFO - 2024-02-07 22:06:30 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:06:30 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:10:57 --> Config Class Initialized
INFO - 2024-02-07 22:10:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:10:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:10:57 --> Utf8 Class Initialized
INFO - 2024-02-07 22:10:57 --> URI Class Initialized
INFO - 2024-02-07 22:10:57 --> Router Class Initialized
INFO - 2024-02-07 22:10:57 --> Output Class Initialized
INFO - 2024-02-07 22:10:57 --> Security Class Initialized
DEBUG - 2024-02-07 22:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:10:57 --> Input Class Initialized
INFO - 2024-02-07 22:10:57 --> Language Class Initialized
INFO - 2024-02-07 22:10:57 --> Loader Class Initialized
INFO - 2024-02-07 22:10:57 --> Helper loaded: url_helper
INFO - 2024-02-07 22:10:57 --> Helper loaded: file_helper
INFO - 2024-02-07 22:10:57 --> Helper loaded: form_helper
INFO - 2024-02-07 22:10:57 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:10:57 --> Controller Class Initialized
INFO - 2024-02-07 22:10:57 --> Form Validation Class Initialized
INFO - 2024-02-07 22:10:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:10:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:10:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:10:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:10:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:10:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:10:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:10:57 --> Final output sent to browser
DEBUG - 2024-02-07 22:10:57 --> Total execution time: 0.0391
ERROR - 2024-02-07 22:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:10:57 --> Config Class Initialized
INFO - 2024-02-07 22:10:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:10:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:10:57 --> Utf8 Class Initialized
INFO - 2024-02-07 22:10:57 --> URI Class Initialized
INFO - 2024-02-07 22:10:57 --> Router Class Initialized
INFO - 2024-02-07 22:10:57 --> Output Class Initialized
INFO - 2024-02-07 22:10:57 --> Security Class Initialized
DEBUG - 2024-02-07 22:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:10:57 --> Input Class Initialized
INFO - 2024-02-07 22:10:57 --> Language Class Initialized
ERROR - 2024-02-07 22:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:10:57 --> Config Class Initialized
INFO - 2024-02-07 22:10:57 --> Hooks Class Initialized
INFO - 2024-02-07 22:10:57 --> Loader Class Initialized
INFO - 2024-02-07 22:10:57 --> Helper loaded: url_helper
DEBUG - 2024-02-07 22:10:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:10:57 --> Utf8 Class Initialized
INFO - 2024-02-07 22:10:57 --> Helper loaded: file_helper
INFO - 2024-02-07 22:10:57 --> URI Class Initialized
INFO - 2024-02-07 22:10:57 --> Helper loaded: form_helper
INFO - 2024-02-07 22:10:57 --> Router Class Initialized
INFO - 2024-02-07 22:10:57 --> Output Class Initialized
INFO - 2024-02-07 22:10:57 --> Security Class Initialized
DEBUG - 2024-02-07 22:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:10:57 --> Input Class Initialized
INFO - 2024-02-07 22:10:57 --> Language Class Initialized
INFO - 2024-02-07 22:10:57 --> Database Driver Class Initialized
INFO - 2024-02-07 22:10:57 --> Loader Class Initialized
INFO - 2024-02-07 22:10:57 --> Helper loaded: url_helper
INFO - 2024-02-07 22:10:57 --> Helper loaded: file_helper
INFO - 2024-02-07 22:10:57 --> Helper loaded: form_helper
DEBUG - 2024-02-07 22:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:10:57 --> Controller Class Initialized
INFO - 2024-02-07 22:10:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:10:57 --> Final output sent to browser
DEBUG - 2024-02-07 22:10:57 --> Total execution time: 0.0239
INFO - 2024-02-07 22:10:57 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:10:57 --> Controller Class Initialized
INFO - 2024-02-07 22:10:57 --> Form Validation Class Initialized
INFO - 2024-02-07 22:10:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:10:57 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:11:08 --> Config Class Initialized
INFO - 2024-02-07 22:11:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:11:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:11:08 --> Utf8 Class Initialized
INFO - 2024-02-07 22:11:08 --> URI Class Initialized
INFO - 2024-02-07 22:11:08 --> Router Class Initialized
INFO - 2024-02-07 22:11:08 --> Output Class Initialized
INFO - 2024-02-07 22:11:08 --> Security Class Initialized
DEBUG - 2024-02-07 22:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:11:08 --> Input Class Initialized
INFO - 2024-02-07 22:11:08 --> Language Class Initialized
INFO - 2024-02-07 22:11:08 --> Loader Class Initialized
INFO - 2024-02-07 22:11:08 --> Helper loaded: url_helper
INFO - 2024-02-07 22:11:08 --> Helper loaded: file_helper
INFO - 2024-02-07 22:11:08 --> Helper loaded: form_helper
INFO - 2024-02-07 22:11:08 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:11:08 --> Controller Class Initialized
INFO - 2024-02-07 22:11:08 --> Form Validation Class Initialized
INFO - 2024-02-07 22:11:08 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:11:08 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:11:08 --> Config Class Initialized
INFO - 2024-02-07 22:11:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:11:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:11:08 --> Utf8 Class Initialized
INFO - 2024-02-07 22:11:08 --> URI Class Initialized
INFO - 2024-02-07 22:11:08 --> Router Class Initialized
INFO - 2024-02-07 22:11:08 --> Output Class Initialized
INFO - 2024-02-07 22:11:08 --> Security Class Initialized
DEBUG - 2024-02-07 22:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:11:08 --> Input Class Initialized
INFO - 2024-02-07 22:11:08 --> Language Class Initialized
INFO - 2024-02-07 22:11:08 --> Loader Class Initialized
INFO - 2024-02-07 22:11:08 --> Helper loaded: url_helper
INFO - 2024-02-07 22:11:08 --> Helper loaded: file_helper
INFO - 2024-02-07 22:11:08 --> Helper loaded: form_helper
INFO - 2024-02-07 22:11:08 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:11:08 --> Controller Class Initialized
INFO - 2024-02-07 22:11:08 --> Form Validation Class Initialized
INFO - 2024-02-07 22:11:08 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:11:08 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:11:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:11:12 --> Config Class Initialized
INFO - 2024-02-07 22:11:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:11:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:11:12 --> Utf8 Class Initialized
INFO - 2024-02-07 22:11:12 --> URI Class Initialized
INFO - 2024-02-07 22:11:12 --> Router Class Initialized
INFO - 2024-02-07 22:11:12 --> Output Class Initialized
INFO - 2024-02-07 22:11:12 --> Security Class Initialized
DEBUG - 2024-02-07 22:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:11:12 --> Input Class Initialized
INFO - 2024-02-07 22:11:12 --> Language Class Initialized
INFO - 2024-02-07 22:11:12 --> Loader Class Initialized
INFO - 2024-02-07 22:11:12 --> Helper loaded: url_helper
INFO - 2024-02-07 22:11:12 --> Helper loaded: file_helper
INFO - 2024-02-07 22:11:12 --> Helper loaded: form_helper
INFO - 2024-02-07 22:11:12 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:11:12 --> Controller Class Initialized
INFO - 2024-02-07 22:11:12 --> Form Validation Class Initialized
INFO - 2024-02-07 22:11:12 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:11:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:11:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:11:15 --> Config Class Initialized
INFO - 2024-02-07 22:11:15 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:11:15 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:11:15 --> Utf8 Class Initialized
INFO - 2024-02-07 22:11:15 --> URI Class Initialized
INFO - 2024-02-07 22:11:15 --> Router Class Initialized
INFO - 2024-02-07 22:11:15 --> Output Class Initialized
INFO - 2024-02-07 22:11:15 --> Security Class Initialized
DEBUG - 2024-02-07 22:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:11:15 --> Input Class Initialized
INFO - 2024-02-07 22:11:15 --> Language Class Initialized
INFO - 2024-02-07 22:11:15 --> Loader Class Initialized
INFO - 2024-02-07 22:11:15 --> Helper loaded: url_helper
INFO - 2024-02-07 22:11:15 --> Helper loaded: file_helper
INFO - 2024-02-07 22:11:15 --> Helper loaded: form_helper
INFO - 2024-02-07 22:11:15 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:11:15 --> Controller Class Initialized
INFO - 2024-02-07 22:11:15 --> Form Validation Class Initialized
INFO - 2024-02-07 22:11:15 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:11:15 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:20:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:20:00 --> Config Class Initialized
INFO - 2024-02-07 22:20:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:20:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:20:00 --> Utf8 Class Initialized
INFO - 2024-02-07 22:20:00 --> URI Class Initialized
INFO - 2024-02-07 22:20:00 --> Router Class Initialized
INFO - 2024-02-07 22:20:00 --> Output Class Initialized
INFO - 2024-02-07 22:20:00 --> Security Class Initialized
DEBUG - 2024-02-07 22:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:20:00 --> Input Class Initialized
INFO - 2024-02-07 22:20:00 --> Language Class Initialized
INFO - 2024-02-07 22:20:00 --> Loader Class Initialized
INFO - 2024-02-07 22:20:00 --> Helper loaded: url_helper
INFO - 2024-02-07 22:20:00 --> Helper loaded: file_helper
INFO - 2024-02-07 22:20:00 --> Helper loaded: form_helper
INFO - 2024-02-07 22:20:00 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:20:00 --> Controller Class Initialized
INFO - 2024-02-07 22:20:00 --> Form Validation Class Initialized
INFO - 2024-02-07 22:20:00 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:20:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:20:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:20:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:20:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:20:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:20:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:20:00 --> Final output sent to browser
DEBUG - 2024-02-07 22:20:00 --> Total execution time: 0.0354
ERROR - 2024-02-07 22:20:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:20:00 --> Config Class Initialized
INFO - 2024-02-07 22:20:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:20:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:20:00 --> Utf8 Class Initialized
INFO - 2024-02-07 22:20:00 --> URI Class Initialized
INFO - 2024-02-07 22:20:00 --> Router Class Initialized
INFO - 2024-02-07 22:20:00 --> Output Class Initialized
INFO - 2024-02-07 22:20:00 --> Security Class Initialized
DEBUG - 2024-02-07 22:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:20:00 --> Input Class Initialized
INFO - 2024-02-07 22:20:00 --> Language Class Initialized
INFO - 2024-02-07 22:20:00 --> Loader Class Initialized
INFO - 2024-02-07 22:20:00 --> Helper loaded: url_helper
INFO - 2024-02-07 22:20:00 --> Helper loaded: file_helper
INFO - 2024-02-07 22:20:00 --> Helper loaded: form_helper
INFO - 2024-02-07 22:20:00 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:20:00 --> Controller Class Initialized
INFO - 2024-02-07 22:20:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:20:00 --> Final output sent to browser
DEBUG - 2024-02-07 22:20:00 --> Total execution time: 0.0359
ERROR - 2024-02-07 22:20:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:20:00 --> Config Class Initialized
INFO - 2024-02-07 22:20:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:20:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:20:00 --> Utf8 Class Initialized
INFO - 2024-02-07 22:20:00 --> URI Class Initialized
INFO - 2024-02-07 22:20:00 --> Router Class Initialized
INFO - 2024-02-07 22:20:00 --> Output Class Initialized
INFO - 2024-02-07 22:20:00 --> Security Class Initialized
DEBUG - 2024-02-07 22:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:20:00 --> Input Class Initialized
INFO - 2024-02-07 22:20:00 --> Language Class Initialized
INFO - 2024-02-07 22:20:00 --> Loader Class Initialized
INFO - 2024-02-07 22:20:00 --> Helper loaded: url_helper
INFO - 2024-02-07 22:20:00 --> Helper loaded: file_helper
INFO - 2024-02-07 22:20:00 --> Helper loaded: form_helper
INFO - 2024-02-07 22:20:00 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:20:00 --> Controller Class Initialized
INFO - 2024-02-07 22:20:00 --> Form Validation Class Initialized
INFO - 2024-02-07 22:20:00 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:20:00 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:20:29 --> Config Class Initialized
INFO - 2024-02-07 22:20:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:20:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:20:29 --> Utf8 Class Initialized
INFO - 2024-02-07 22:20:29 --> URI Class Initialized
INFO - 2024-02-07 22:20:29 --> Router Class Initialized
INFO - 2024-02-07 22:20:29 --> Output Class Initialized
INFO - 2024-02-07 22:20:29 --> Security Class Initialized
DEBUG - 2024-02-07 22:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:20:29 --> Input Class Initialized
INFO - 2024-02-07 22:20:29 --> Language Class Initialized
INFO - 2024-02-07 22:20:29 --> Loader Class Initialized
INFO - 2024-02-07 22:20:29 --> Helper loaded: url_helper
INFO - 2024-02-07 22:20:29 --> Helper loaded: file_helper
INFO - 2024-02-07 22:20:29 --> Helper loaded: form_helper
INFO - 2024-02-07 22:20:29 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:20:29 --> Controller Class Initialized
INFO - 2024-02-07 22:20:29 --> Form Validation Class Initialized
INFO - 2024-02-07 22:20:29 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:20:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:20:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:20:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:20:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:20:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:20:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:20:29 --> Final output sent to browser
DEBUG - 2024-02-07 22:20:29 --> Total execution time: 0.0209
ERROR - 2024-02-07 22:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:20:29 --> Config Class Initialized
INFO - 2024-02-07 22:20:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:20:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:20:29 --> Utf8 Class Initialized
INFO - 2024-02-07 22:20:29 --> URI Class Initialized
INFO - 2024-02-07 22:20:29 --> Router Class Initialized
INFO - 2024-02-07 22:20:29 --> Output Class Initialized
INFO - 2024-02-07 22:20:29 --> Security Class Initialized
DEBUG - 2024-02-07 22:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:20:29 --> Input Class Initialized
INFO - 2024-02-07 22:20:29 --> Language Class Initialized
INFO - 2024-02-07 22:20:30 --> Loader Class Initialized
INFO - 2024-02-07 22:20:30 --> Helper loaded: url_helper
INFO - 2024-02-07 22:20:30 --> Helper loaded: file_helper
INFO - 2024-02-07 22:20:30 --> Helper loaded: form_helper
INFO - 2024-02-07 22:20:30 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:20:30 --> Controller Class Initialized
INFO - 2024-02-07 22:20:30 --> Form Validation Class Initialized
INFO - 2024-02-07 22:20:30 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:20:30 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:20:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:20:30 --> Config Class Initialized
INFO - 2024-02-07 22:20:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:20:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:20:30 --> Utf8 Class Initialized
INFO - 2024-02-07 22:20:30 --> URI Class Initialized
INFO - 2024-02-07 22:20:30 --> Router Class Initialized
INFO - 2024-02-07 22:20:30 --> Output Class Initialized
INFO - 2024-02-07 22:20:30 --> Security Class Initialized
DEBUG - 2024-02-07 22:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:20:30 --> Input Class Initialized
INFO - 2024-02-07 22:20:30 --> Language Class Initialized
INFO - 2024-02-07 22:20:30 --> Loader Class Initialized
INFO - 2024-02-07 22:20:30 --> Helper loaded: url_helper
INFO - 2024-02-07 22:20:30 --> Helper loaded: file_helper
INFO - 2024-02-07 22:20:30 --> Helper loaded: form_helper
INFO - 2024-02-07 22:20:30 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:20:30 --> Controller Class Initialized
INFO - 2024-02-07 22:20:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:20:30 --> Final output sent to browser
DEBUG - 2024-02-07 22:20:30 --> Total execution time: 0.0280
ERROR - 2024-02-07 22:20:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:20:51 --> Config Class Initialized
INFO - 2024-02-07 22:20:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:20:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:20:51 --> Utf8 Class Initialized
INFO - 2024-02-07 22:20:51 --> URI Class Initialized
INFO - 2024-02-07 22:20:51 --> Router Class Initialized
INFO - 2024-02-07 22:20:51 --> Output Class Initialized
INFO - 2024-02-07 22:20:51 --> Security Class Initialized
DEBUG - 2024-02-07 22:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:20:51 --> Input Class Initialized
INFO - 2024-02-07 22:20:51 --> Language Class Initialized
INFO - 2024-02-07 22:20:51 --> Loader Class Initialized
INFO - 2024-02-07 22:20:51 --> Helper loaded: url_helper
INFO - 2024-02-07 22:20:51 --> Helper loaded: file_helper
INFO - 2024-02-07 22:20:51 --> Helper loaded: form_helper
INFO - 2024-02-07 22:20:51 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:20:51 --> Controller Class Initialized
INFO - 2024-02-07 22:20:51 --> Form Validation Class Initialized
INFO - 2024-02-07 22:20:51 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:20:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:20:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:20:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:20:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:20:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:20:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:20:51 --> Final output sent to browser
DEBUG - 2024-02-07 22:20:51 --> Total execution time: 0.0342
ERROR - 2024-02-07 22:20:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:20:51 --> Config Class Initialized
INFO - 2024-02-07 22:20:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:20:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:20:51 --> Utf8 Class Initialized
INFO - 2024-02-07 22:20:51 --> URI Class Initialized
INFO - 2024-02-07 22:20:51 --> Router Class Initialized
INFO - 2024-02-07 22:20:51 --> Output Class Initialized
INFO - 2024-02-07 22:20:51 --> Security Class Initialized
DEBUG - 2024-02-07 22:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:20:51 --> Input Class Initialized
INFO - 2024-02-07 22:20:51 --> Language Class Initialized
INFO - 2024-02-07 22:20:51 --> Loader Class Initialized
INFO - 2024-02-07 22:20:51 --> Helper loaded: url_helper
INFO - 2024-02-07 22:20:51 --> Helper loaded: file_helper
INFO - 2024-02-07 22:20:51 --> Helper loaded: form_helper
INFO - 2024-02-07 22:20:51 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:20:51 --> Controller Class Initialized
INFO - 2024-02-07 22:20:51 --> Form Validation Class Initialized
INFO - 2024-02-07 22:20:51 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:20:51 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:20:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:20:51 --> Config Class Initialized
INFO - 2024-02-07 22:20:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:20:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:20:51 --> Utf8 Class Initialized
INFO - 2024-02-07 22:20:51 --> URI Class Initialized
INFO - 2024-02-07 22:20:51 --> Router Class Initialized
INFO - 2024-02-07 22:20:51 --> Output Class Initialized
INFO - 2024-02-07 22:20:51 --> Security Class Initialized
DEBUG - 2024-02-07 22:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:20:51 --> Input Class Initialized
INFO - 2024-02-07 22:20:51 --> Language Class Initialized
INFO - 2024-02-07 22:20:51 --> Loader Class Initialized
INFO - 2024-02-07 22:20:51 --> Helper loaded: url_helper
INFO - 2024-02-07 22:20:51 --> Helper loaded: file_helper
INFO - 2024-02-07 22:20:51 --> Helper loaded: form_helper
INFO - 2024-02-07 22:20:51 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:20:51 --> Controller Class Initialized
INFO - 2024-02-07 22:20:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:20:51 --> Final output sent to browser
DEBUG - 2024-02-07 22:20:51 --> Total execution time: 0.0469
ERROR - 2024-02-07 22:20:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:20:59 --> Config Class Initialized
INFO - 2024-02-07 22:20:59 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:20:59 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:20:59 --> Utf8 Class Initialized
INFO - 2024-02-07 22:20:59 --> URI Class Initialized
INFO - 2024-02-07 22:20:59 --> Router Class Initialized
INFO - 2024-02-07 22:20:59 --> Output Class Initialized
INFO - 2024-02-07 22:20:59 --> Security Class Initialized
DEBUG - 2024-02-07 22:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:20:59 --> Input Class Initialized
INFO - 2024-02-07 22:20:59 --> Language Class Initialized
INFO - 2024-02-07 22:20:59 --> Loader Class Initialized
INFO - 2024-02-07 22:20:59 --> Helper loaded: url_helper
INFO - 2024-02-07 22:20:59 --> Helper loaded: file_helper
INFO - 2024-02-07 22:20:59 --> Helper loaded: form_helper
INFO - 2024-02-07 22:20:59 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:20:59 --> Controller Class Initialized
INFO - 2024-02-07 22:20:59 --> Form Validation Class Initialized
INFO - 2024-02-07 22:20:59 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:20:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:20:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:20:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:20:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:20:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:20:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:20:59 --> Final output sent to browser
DEBUG - 2024-02-07 22:20:59 --> Total execution time: 0.0383
ERROR - 2024-02-07 22:20:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:20:59 --> Config Class Initialized
INFO - 2024-02-07 22:20:59 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:20:59 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:20:59 --> Utf8 Class Initialized
INFO - 2024-02-07 22:20:59 --> URI Class Initialized
INFO - 2024-02-07 22:20:59 --> Router Class Initialized
INFO - 2024-02-07 22:20:59 --> Output Class Initialized
INFO - 2024-02-07 22:20:59 --> Security Class Initialized
DEBUG - 2024-02-07 22:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:20:59 --> Input Class Initialized
INFO - 2024-02-07 22:20:59 --> Language Class Initialized
INFO - 2024-02-07 22:20:59 --> Loader Class Initialized
INFO - 2024-02-07 22:20:59 --> Helper loaded: url_helper
INFO - 2024-02-07 22:20:59 --> Helper loaded: file_helper
INFO - 2024-02-07 22:20:59 --> Helper loaded: form_helper
INFO - 2024-02-07 22:20:59 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:20:59 --> Controller Class Initialized
INFO - 2024-02-07 22:20:59 --> Form Validation Class Initialized
INFO - 2024-02-07 22:20:59 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:20:59 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:20:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:20:59 --> Config Class Initialized
INFO - 2024-02-07 22:20:59 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:20:59 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:20:59 --> Utf8 Class Initialized
INFO - 2024-02-07 22:20:59 --> URI Class Initialized
INFO - 2024-02-07 22:20:59 --> Router Class Initialized
INFO - 2024-02-07 22:20:59 --> Output Class Initialized
INFO - 2024-02-07 22:20:59 --> Security Class Initialized
DEBUG - 2024-02-07 22:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:20:59 --> Input Class Initialized
INFO - 2024-02-07 22:20:59 --> Language Class Initialized
INFO - 2024-02-07 22:20:59 --> Loader Class Initialized
INFO - 2024-02-07 22:20:59 --> Helper loaded: url_helper
INFO - 2024-02-07 22:20:59 --> Helper loaded: file_helper
INFO - 2024-02-07 22:20:59 --> Helper loaded: form_helper
INFO - 2024-02-07 22:20:59 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:20:59 --> Controller Class Initialized
INFO - 2024-02-07 22:20:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:20:59 --> Final output sent to browser
DEBUG - 2024-02-07 22:20:59 --> Total execution time: 0.0351
ERROR - 2024-02-07 22:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:21:09 --> Config Class Initialized
INFO - 2024-02-07 22:21:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:21:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:21:09 --> Utf8 Class Initialized
INFO - 2024-02-07 22:21:09 --> URI Class Initialized
INFO - 2024-02-07 22:21:09 --> Router Class Initialized
INFO - 2024-02-07 22:21:09 --> Output Class Initialized
INFO - 2024-02-07 22:21:09 --> Security Class Initialized
DEBUG - 2024-02-07 22:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:21:09 --> Input Class Initialized
INFO - 2024-02-07 22:21:09 --> Language Class Initialized
INFO - 2024-02-07 22:21:09 --> Loader Class Initialized
INFO - 2024-02-07 22:21:09 --> Helper loaded: url_helper
INFO - 2024-02-07 22:21:09 --> Helper loaded: file_helper
INFO - 2024-02-07 22:21:09 --> Helper loaded: form_helper
INFO - 2024-02-07 22:21:09 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:21:09 --> Controller Class Initialized
INFO - 2024-02-07 22:21:09 --> Form Validation Class Initialized
INFO - 2024-02-07 22:21:09 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:21:09 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:21:09 --> Config Class Initialized
INFO - 2024-02-07 22:21:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:21:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:21:09 --> Utf8 Class Initialized
INFO - 2024-02-07 22:21:09 --> URI Class Initialized
INFO - 2024-02-07 22:21:09 --> Router Class Initialized
INFO - 2024-02-07 22:21:09 --> Output Class Initialized
INFO - 2024-02-07 22:21:09 --> Security Class Initialized
DEBUG - 2024-02-07 22:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:21:09 --> Input Class Initialized
INFO - 2024-02-07 22:21:09 --> Language Class Initialized
INFO - 2024-02-07 22:21:09 --> Loader Class Initialized
INFO - 2024-02-07 22:21:09 --> Helper loaded: url_helper
INFO - 2024-02-07 22:21:09 --> Helper loaded: file_helper
INFO - 2024-02-07 22:21:09 --> Helper loaded: form_helper
INFO - 2024-02-07 22:21:09 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:21:09 --> Controller Class Initialized
INFO - 2024-02-07 22:21:09 --> Form Validation Class Initialized
INFO - 2024-02-07 22:21:09 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:21:09 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:21:13 --> Config Class Initialized
INFO - 2024-02-07 22:21:13 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:21:13 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:21:13 --> Utf8 Class Initialized
INFO - 2024-02-07 22:21:13 --> URI Class Initialized
INFO - 2024-02-07 22:21:13 --> Router Class Initialized
INFO - 2024-02-07 22:21:13 --> Output Class Initialized
INFO - 2024-02-07 22:21:13 --> Security Class Initialized
DEBUG - 2024-02-07 22:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:21:13 --> Input Class Initialized
INFO - 2024-02-07 22:21:13 --> Language Class Initialized
INFO - 2024-02-07 22:21:13 --> Loader Class Initialized
INFO - 2024-02-07 22:21:13 --> Helper loaded: url_helper
INFO - 2024-02-07 22:21:13 --> Helper loaded: file_helper
INFO - 2024-02-07 22:21:13 --> Helper loaded: form_helper
INFO - 2024-02-07 22:21:13 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:21:13 --> Controller Class Initialized
INFO - 2024-02-07 22:21:13 --> Form Validation Class Initialized
INFO - 2024-02-07 22:21:13 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:21:13 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:21:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:21:17 --> Config Class Initialized
INFO - 2024-02-07 22:21:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:21:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:21:17 --> Utf8 Class Initialized
INFO - 2024-02-07 22:21:17 --> URI Class Initialized
INFO - 2024-02-07 22:21:17 --> Router Class Initialized
INFO - 2024-02-07 22:21:17 --> Output Class Initialized
INFO - 2024-02-07 22:21:17 --> Security Class Initialized
DEBUG - 2024-02-07 22:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:21:17 --> Input Class Initialized
INFO - 2024-02-07 22:21:17 --> Language Class Initialized
INFO - 2024-02-07 22:21:17 --> Loader Class Initialized
INFO - 2024-02-07 22:21:17 --> Helper loaded: url_helper
INFO - 2024-02-07 22:21:17 --> Helper loaded: file_helper
INFO - 2024-02-07 22:21:17 --> Helper loaded: form_helper
INFO - 2024-02-07 22:21:17 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:21:17 --> Controller Class Initialized
INFO - 2024-02-07 22:21:17 --> Form Validation Class Initialized
INFO - 2024-02-07 22:21:17 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:21:17 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:21:25 --> Config Class Initialized
INFO - 2024-02-07 22:21:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:21:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:21:25 --> Utf8 Class Initialized
INFO - 2024-02-07 22:21:25 --> URI Class Initialized
INFO - 2024-02-07 22:21:25 --> Router Class Initialized
INFO - 2024-02-07 22:21:25 --> Output Class Initialized
INFO - 2024-02-07 22:21:25 --> Security Class Initialized
DEBUG - 2024-02-07 22:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:21:25 --> Input Class Initialized
INFO - 2024-02-07 22:21:25 --> Language Class Initialized
INFO - 2024-02-07 22:21:25 --> Loader Class Initialized
INFO - 2024-02-07 22:21:25 --> Helper loaded: url_helper
INFO - 2024-02-07 22:21:25 --> Helper loaded: file_helper
INFO - 2024-02-07 22:21:25 --> Helper loaded: form_helper
INFO - 2024-02-07 22:21:25 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:21:25 --> Controller Class Initialized
INFO - 2024-02-07 22:21:25 --> Form Validation Class Initialized
INFO - 2024-02-07 22:21:25 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:21:25 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:21:25 --> Config Class Initialized
INFO - 2024-02-07 22:21:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:21:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:21:25 --> Utf8 Class Initialized
INFO - 2024-02-07 22:21:25 --> URI Class Initialized
INFO - 2024-02-07 22:21:25 --> Router Class Initialized
INFO - 2024-02-07 22:21:25 --> Output Class Initialized
INFO - 2024-02-07 22:21:25 --> Security Class Initialized
DEBUG - 2024-02-07 22:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:21:25 --> Input Class Initialized
INFO - 2024-02-07 22:21:25 --> Language Class Initialized
INFO - 2024-02-07 22:21:25 --> Loader Class Initialized
INFO - 2024-02-07 22:21:25 --> Helper loaded: url_helper
INFO - 2024-02-07 22:21:25 --> Helper loaded: file_helper
INFO - 2024-02-07 22:21:25 --> Helper loaded: form_helper
INFO - 2024-02-07 22:21:25 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:21:25 --> Controller Class Initialized
INFO - 2024-02-07 22:21:25 --> Form Validation Class Initialized
INFO - 2024-02-07 22:21:25 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:21:25 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:22:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:22:00 --> Config Class Initialized
INFO - 2024-02-07 22:22:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:22:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:22:00 --> Utf8 Class Initialized
INFO - 2024-02-07 22:22:00 --> URI Class Initialized
INFO - 2024-02-07 22:22:00 --> Router Class Initialized
INFO - 2024-02-07 22:22:00 --> Output Class Initialized
INFO - 2024-02-07 22:22:00 --> Security Class Initialized
DEBUG - 2024-02-07 22:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:22:00 --> Input Class Initialized
INFO - 2024-02-07 22:22:00 --> Language Class Initialized
INFO - 2024-02-07 22:22:00 --> Loader Class Initialized
INFO - 2024-02-07 22:22:00 --> Helper loaded: url_helper
INFO - 2024-02-07 22:22:00 --> Helper loaded: file_helper
INFO - 2024-02-07 22:22:00 --> Helper loaded: form_helper
INFO - 2024-02-07 22:22:00 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:22:00 --> Controller Class Initialized
INFO - 2024-02-07 22:22:00 --> Form Validation Class Initialized
INFO - 2024-02-07 22:22:00 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:22:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:22:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:22:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:22:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:22:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:22:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:22:00 --> Final output sent to browser
DEBUG - 2024-02-07 22:22:00 --> Total execution time: 0.0482
ERROR - 2024-02-07 22:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-07 22:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:22:01 --> Config Class Initialized
INFO - 2024-02-07 22:22:01 --> Hooks Class Initialized
INFO - 2024-02-07 22:22:01 --> Config Class Initialized
INFO - 2024-02-07 22:22:01 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:22:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 22:22:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:22:01 --> Utf8 Class Initialized
INFO - 2024-02-07 22:22:01 --> Utf8 Class Initialized
INFO - 2024-02-07 22:22:01 --> URI Class Initialized
INFO - 2024-02-07 22:22:01 --> URI Class Initialized
INFO - 2024-02-07 22:22:01 --> Router Class Initialized
INFO - 2024-02-07 22:22:01 --> Router Class Initialized
INFO - 2024-02-07 22:22:01 --> Output Class Initialized
INFO - 2024-02-07 22:22:01 --> Output Class Initialized
INFO - 2024-02-07 22:22:01 --> Security Class Initialized
INFO - 2024-02-07 22:22:01 --> Security Class Initialized
DEBUG - 2024-02-07 22:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:22:01 --> Input Class Initialized
INFO - 2024-02-07 22:22:01 --> Language Class Initialized
DEBUG - 2024-02-07 22:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:22:01 --> Input Class Initialized
INFO - 2024-02-07 22:22:01 --> Language Class Initialized
INFO - 2024-02-07 22:22:01 --> Loader Class Initialized
INFO - 2024-02-07 22:22:01 --> Loader Class Initialized
INFO - 2024-02-07 22:22:01 --> Helper loaded: url_helper
INFO - 2024-02-07 22:22:01 --> Helper loaded: file_helper
INFO - 2024-02-07 22:22:01 --> Helper loaded: url_helper
INFO - 2024-02-07 22:22:01 --> Helper loaded: file_helper
INFO - 2024-02-07 22:22:01 --> Helper loaded: form_helper
INFO - 2024-02-07 22:22:01 --> Helper loaded: form_helper
INFO - 2024-02-07 22:22:01 --> Database Driver Class Initialized
INFO - 2024-02-07 22:22:01 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:22:01 --> Controller Class Initialized
DEBUG - 2024-02-07 22:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:22:01 --> Form Validation Class Initialized
INFO - 2024-02-07 22:22:01 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:22:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:22:01 --> Controller Class Initialized
INFO - 2024-02-07 22:22:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:22:01 --> Final output sent to browser
DEBUG - 2024-02-07 22:22:01 --> Total execution time: 0.0601
ERROR - 2024-02-07 22:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:22:12 --> Config Class Initialized
INFO - 2024-02-07 22:22:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:22:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:22:12 --> Utf8 Class Initialized
INFO - 2024-02-07 22:22:12 --> URI Class Initialized
INFO - 2024-02-07 22:22:12 --> Router Class Initialized
INFO - 2024-02-07 22:22:12 --> Output Class Initialized
INFO - 2024-02-07 22:22:12 --> Security Class Initialized
DEBUG - 2024-02-07 22:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:22:12 --> Input Class Initialized
INFO - 2024-02-07 22:22:12 --> Language Class Initialized
INFO - 2024-02-07 22:22:12 --> Loader Class Initialized
INFO - 2024-02-07 22:22:12 --> Helper loaded: url_helper
INFO - 2024-02-07 22:22:12 --> Helper loaded: file_helper
INFO - 2024-02-07 22:22:12 --> Helper loaded: form_helper
INFO - 2024-02-07 22:22:12 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:22:12 --> Controller Class Initialized
INFO - 2024-02-07 22:22:12 --> Form Validation Class Initialized
INFO - 2024-02-07 22:22:12 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:22:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:22:12 --> Config Class Initialized
INFO - 2024-02-07 22:22:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:22:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:22:12 --> Utf8 Class Initialized
INFO - 2024-02-07 22:22:12 --> URI Class Initialized
INFO - 2024-02-07 22:22:12 --> Router Class Initialized
INFO - 2024-02-07 22:22:12 --> Output Class Initialized
INFO - 2024-02-07 22:22:12 --> Security Class Initialized
DEBUG - 2024-02-07 22:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:22:12 --> Input Class Initialized
INFO - 2024-02-07 22:22:12 --> Language Class Initialized
INFO - 2024-02-07 22:22:12 --> Loader Class Initialized
INFO - 2024-02-07 22:22:12 --> Helper loaded: url_helper
INFO - 2024-02-07 22:22:12 --> Helper loaded: file_helper
INFO - 2024-02-07 22:22:12 --> Helper loaded: form_helper
INFO - 2024-02-07 22:22:12 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:22:12 --> Controller Class Initialized
INFO - 2024-02-07 22:22:12 --> Form Validation Class Initialized
INFO - 2024-02-07 22:22:12 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:22:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:22:55 --> Config Class Initialized
INFO - 2024-02-07 22:22:55 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:22:55 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:22:55 --> Utf8 Class Initialized
INFO - 2024-02-07 22:22:55 --> URI Class Initialized
INFO - 2024-02-07 22:22:55 --> Router Class Initialized
INFO - 2024-02-07 22:22:55 --> Output Class Initialized
INFO - 2024-02-07 22:22:55 --> Security Class Initialized
DEBUG - 2024-02-07 22:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:22:55 --> Input Class Initialized
INFO - 2024-02-07 22:22:55 --> Language Class Initialized
INFO - 2024-02-07 22:22:55 --> Loader Class Initialized
INFO - 2024-02-07 22:22:55 --> Helper loaded: url_helper
INFO - 2024-02-07 22:22:55 --> Helper loaded: file_helper
INFO - 2024-02-07 22:22:55 --> Helper loaded: form_helper
INFO - 2024-02-07 22:22:55 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:22:55 --> Controller Class Initialized
INFO - 2024-02-07 22:22:55 --> Form Validation Class Initialized
INFO - 2024-02-07 22:22:55 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:22:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:22:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:22:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:22:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:22:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:22:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:22:55 --> Final output sent to browser
DEBUG - 2024-02-07 22:22:55 --> Total execution time: 0.0361
ERROR - 2024-02-07 22:22:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:22:56 --> Config Class Initialized
INFO - 2024-02-07 22:22:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:22:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:22:56 --> Utf8 Class Initialized
INFO - 2024-02-07 22:22:56 --> URI Class Initialized
INFO - 2024-02-07 22:22:56 --> Router Class Initialized
INFO - 2024-02-07 22:22:56 --> Output Class Initialized
INFO - 2024-02-07 22:22:56 --> Security Class Initialized
DEBUG - 2024-02-07 22:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:22:56 --> Input Class Initialized
INFO - 2024-02-07 22:22:56 --> Language Class Initialized
INFO - 2024-02-07 22:22:56 --> Loader Class Initialized
INFO - 2024-02-07 22:22:56 --> Helper loaded: url_helper
INFO - 2024-02-07 22:22:56 --> Helper loaded: file_helper
INFO - 2024-02-07 22:22:56 --> Helper loaded: form_helper
INFO - 2024-02-07 22:22:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:22:56 --> Controller Class Initialized
INFO - 2024-02-07 22:22:56 --> Form Validation Class Initialized
INFO - 2024-02-07 22:22:56 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:22:56 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:22:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:22:56 --> Config Class Initialized
INFO - 2024-02-07 22:22:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:22:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:22:56 --> Utf8 Class Initialized
INFO - 2024-02-07 22:22:56 --> URI Class Initialized
INFO - 2024-02-07 22:22:56 --> Router Class Initialized
INFO - 2024-02-07 22:22:56 --> Output Class Initialized
INFO - 2024-02-07 22:22:56 --> Security Class Initialized
DEBUG - 2024-02-07 22:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:22:56 --> Input Class Initialized
INFO - 2024-02-07 22:22:56 --> Language Class Initialized
INFO - 2024-02-07 22:22:56 --> Loader Class Initialized
INFO - 2024-02-07 22:22:56 --> Helper loaded: url_helper
INFO - 2024-02-07 22:22:56 --> Helper loaded: file_helper
INFO - 2024-02-07 22:22:56 --> Helper loaded: form_helper
INFO - 2024-02-07 22:22:56 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:22:56 --> Controller Class Initialized
INFO - 2024-02-07 22:22:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:22:56 --> Final output sent to browser
DEBUG - 2024-02-07 22:22:56 --> Total execution time: 0.0500
ERROR - 2024-02-07 22:23:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:23:02 --> Config Class Initialized
INFO - 2024-02-07 22:23:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:23:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:23:02 --> Utf8 Class Initialized
INFO - 2024-02-07 22:23:02 --> URI Class Initialized
INFO - 2024-02-07 22:23:02 --> Router Class Initialized
INFO - 2024-02-07 22:23:02 --> Output Class Initialized
INFO - 2024-02-07 22:23:02 --> Security Class Initialized
DEBUG - 2024-02-07 22:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:23:02 --> Input Class Initialized
INFO - 2024-02-07 22:23:02 --> Language Class Initialized
INFO - 2024-02-07 22:23:02 --> Loader Class Initialized
INFO - 2024-02-07 22:23:02 --> Helper loaded: url_helper
INFO - 2024-02-07 22:23:02 --> Helper loaded: file_helper
INFO - 2024-02-07 22:23:02 --> Helper loaded: form_helper
INFO - 2024-02-07 22:23:02 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:23:02 --> Controller Class Initialized
INFO - 2024-02-07 22:23:02 --> Form Validation Class Initialized
INFO - 2024-02-07 22:23:02 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:23:02 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:23:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:23:02 --> Config Class Initialized
INFO - 2024-02-07 22:23:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:23:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:23:02 --> Utf8 Class Initialized
INFO - 2024-02-07 22:23:02 --> URI Class Initialized
INFO - 2024-02-07 22:23:02 --> Router Class Initialized
INFO - 2024-02-07 22:23:02 --> Output Class Initialized
INFO - 2024-02-07 22:23:02 --> Security Class Initialized
DEBUG - 2024-02-07 22:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:23:02 --> Input Class Initialized
INFO - 2024-02-07 22:23:02 --> Language Class Initialized
INFO - 2024-02-07 22:23:02 --> Loader Class Initialized
INFO - 2024-02-07 22:23:02 --> Helper loaded: url_helper
INFO - 2024-02-07 22:23:02 --> Helper loaded: file_helper
INFO - 2024-02-07 22:23:02 --> Helper loaded: form_helper
INFO - 2024-02-07 22:23:02 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:23:02 --> Controller Class Initialized
INFO - 2024-02-07 22:23:02 --> Form Validation Class Initialized
INFO - 2024-02-07 22:23:02 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:23:02 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:23:29 --> Config Class Initialized
INFO - 2024-02-07 22:23:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:23:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:23:29 --> Utf8 Class Initialized
INFO - 2024-02-07 22:23:29 --> URI Class Initialized
INFO - 2024-02-07 22:23:29 --> Router Class Initialized
INFO - 2024-02-07 22:23:29 --> Output Class Initialized
INFO - 2024-02-07 22:23:29 --> Security Class Initialized
DEBUG - 2024-02-07 22:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:23:29 --> Input Class Initialized
INFO - 2024-02-07 22:23:29 --> Language Class Initialized
INFO - 2024-02-07 22:23:29 --> Loader Class Initialized
INFO - 2024-02-07 22:23:29 --> Helper loaded: url_helper
INFO - 2024-02-07 22:23:29 --> Helper loaded: file_helper
INFO - 2024-02-07 22:23:29 --> Helper loaded: form_helper
INFO - 2024-02-07 22:23:29 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:23:29 --> Controller Class Initialized
INFO - 2024-02-07 22:23:29 --> Form Validation Class Initialized
INFO - 2024-02-07 22:23:29 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:23:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:23:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:23:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:23:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:23:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:23:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:23:29 --> Final output sent to browser
DEBUG - 2024-02-07 22:23:29 --> Total execution time: 0.0504
ERROR - 2024-02-07 22:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:23:29 --> Config Class Initialized
INFO - 2024-02-07 22:23:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:23:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:23:29 --> Utf8 Class Initialized
INFO - 2024-02-07 22:23:29 --> URI Class Initialized
INFO - 2024-02-07 22:23:29 --> Router Class Initialized
INFO - 2024-02-07 22:23:29 --> Output Class Initialized
INFO - 2024-02-07 22:23:29 --> Security Class Initialized
DEBUG - 2024-02-07 22:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:23:29 --> Input Class Initialized
INFO - 2024-02-07 22:23:29 --> Language Class Initialized
INFO - 2024-02-07 22:23:29 --> Loader Class Initialized
INFO - 2024-02-07 22:23:29 --> Helper loaded: url_helper
INFO - 2024-02-07 22:23:29 --> Helper loaded: file_helper
INFO - 2024-02-07 22:23:29 --> Helper loaded: form_helper
INFO - 2024-02-07 22:23:29 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:23:29 --> Controller Class Initialized
INFO - 2024-02-07 22:23:29 --> Form Validation Class Initialized
INFO - 2024-02-07 22:23:29 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:23:29 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:23:29 --> Config Class Initialized
INFO - 2024-02-07 22:23:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:23:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:23:29 --> Utf8 Class Initialized
INFO - 2024-02-07 22:23:29 --> URI Class Initialized
INFO - 2024-02-07 22:23:29 --> Router Class Initialized
INFO - 2024-02-07 22:23:29 --> Output Class Initialized
INFO - 2024-02-07 22:23:29 --> Security Class Initialized
DEBUG - 2024-02-07 22:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:23:29 --> Input Class Initialized
INFO - 2024-02-07 22:23:29 --> Language Class Initialized
INFO - 2024-02-07 22:23:29 --> Loader Class Initialized
INFO - 2024-02-07 22:23:29 --> Helper loaded: url_helper
INFO - 2024-02-07 22:23:29 --> Helper loaded: file_helper
INFO - 2024-02-07 22:23:29 --> Helper loaded: form_helper
INFO - 2024-02-07 22:23:30 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:23:30 --> Controller Class Initialized
INFO - 2024-02-07 22:23:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:23:30 --> Final output sent to browser
DEBUG - 2024-02-07 22:23:30 --> Total execution time: 0.0382
ERROR - 2024-02-07 22:23:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:23:47 --> Config Class Initialized
INFO - 2024-02-07 22:23:47 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:23:47 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:23:47 --> Utf8 Class Initialized
INFO - 2024-02-07 22:23:47 --> URI Class Initialized
INFO - 2024-02-07 22:23:47 --> Router Class Initialized
INFO - 2024-02-07 22:23:47 --> Output Class Initialized
INFO - 2024-02-07 22:23:47 --> Security Class Initialized
DEBUG - 2024-02-07 22:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:23:47 --> Input Class Initialized
INFO - 2024-02-07 22:23:47 --> Language Class Initialized
INFO - 2024-02-07 22:23:47 --> Loader Class Initialized
INFO - 2024-02-07 22:23:47 --> Helper loaded: url_helper
INFO - 2024-02-07 22:23:47 --> Helper loaded: file_helper
INFO - 2024-02-07 22:23:47 --> Helper loaded: form_helper
INFO - 2024-02-07 22:23:47 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:23:47 --> Controller Class Initialized
INFO - 2024-02-07 22:23:47 --> Form Validation Class Initialized
INFO - 2024-02-07 22:23:47 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:23:47 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:23:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:23:47 --> Config Class Initialized
INFO - 2024-02-07 22:23:47 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:23:47 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:23:47 --> Utf8 Class Initialized
INFO - 2024-02-07 22:23:47 --> URI Class Initialized
INFO - 2024-02-07 22:23:47 --> Router Class Initialized
INFO - 2024-02-07 22:23:47 --> Output Class Initialized
INFO - 2024-02-07 22:23:47 --> Security Class Initialized
DEBUG - 2024-02-07 22:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:23:47 --> Input Class Initialized
INFO - 2024-02-07 22:23:47 --> Language Class Initialized
INFO - 2024-02-07 22:23:47 --> Loader Class Initialized
INFO - 2024-02-07 22:23:47 --> Helper loaded: url_helper
INFO - 2024-02-07 22:23:47 --> Helper loaded: file_helper
INFO - 2024-02-07 22:23:47 --> Helper loaded: form_helper
INFO - 2024-02-07 22:23:47 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:23:47 --> Controller Class Initialized
INFO - 2024-02-07 22:23:47 --> Form Validation Class Initialized
INFO - 2024-02-07 22:23:47 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:23:47 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:24:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:24:16 --> Config Class Initialized
INFO - 2024-02-07 22:24:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:24:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:24:16 --> Utf8 Class Initialized
INFO - 2024-02-07 22:24:16 --> URI Class Initialized
INFO - 2024-02-07 22:24:16 --> Router Class Initialized
INFO - 2024-02-07 22:24:16 --> Output Class Initialized
INFO - 2024-02-07 22:24:16 --> Security Class Initialized
DEBUG - 2024-02-07 22:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:24:16 --> Input Class Initialized
INFO - 2024-02-07 22:24:16 --> Language Class Initialized
INFO - 2024-02-07 22:24:16 --> Loader Class Initialized
INFO - 2024-02-07 22:24:16 --> Helper loaded: url_helper
INFO - 2024-02-07 22:24:16 --> Helper loaded: file_helper
INFO - 2024-02-07 22:24:16 --> Helper loaded: form_helper
INFO - 2024-02-07 22:24:16 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:24:16 --> Controller Class Initialized
INFO - 2024-02-07 22:24:16 --> Form Validation Class Initialized
INFO - 2024-02-07 22:24:16 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:24:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:24:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:24:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:24:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:24:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:24:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:24:16 --> Final output sent to browser
DEBUG - 2024-02-07 22:24:16 --> Total execution time: 0.0469
ERROR - 2024-02-07 22:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:24:17 --> Config Class Initialized
INFO - 2024-02-07 22:24:17 --> Hooks Class Initialized
ERROR - 2024-02-07 22:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2024-02-07 22:24:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:24:17 --> Utf8 Class Initialized
INFO - 2024-02-07 22:24:17 --> Config Class Initialized
INFO - 2024-02-07 22:24:17 --> Hooks Class Initialized
INFO - 2024-02-07 22:24:17 --> URI Class Initialized
INFO - 2024-02-07 22:24:17 --> Router Class Initialized
DEBUG - 2024-02-07 22:24:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:24:17 --> Utf8 Class Initialized
INFO - 2024-02-07 22:24:17 --> URI Class Initialized
INFO - 2024-02-07 22:24:17 --> Output Class Initialized
INFO - 2024-02-07 22:24:17 --> Router Class Initialized
INFO - 2024-02-07 22:24:17 --> Security Class Initialized
INFO - 2024-02-07 22:24:17 --> Output Class Initialized
DEBUG - 2024-02-07 22:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:24:17 --> Input Class Initialized
INFO - 2024-02-07 22:24:17 --> Language Class Initialized
INFO - 2024-02-07 22:24:17 --> Security Class Initialized
DEBUG - 2024-02-07 22:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:24:17 --> Input Class Initialized
INFO - 2024-02-07 22:24:17 --> Language Class Initialized
INFO - 2024-02-07 22:24:17 --> Loader Class Initialized
INFO - 2024-02-07 22:24:17 --> Loader Class Initialized
INFO - 2024-02-07 22:24:17 --> Helper loaded: url_helper
INFO - 2024-02-07 22:24:17 --> Helper loaded: url_helper
INFO - 2024-02-07 22:24:17 --> Helper loaded: file_helper
INFO - 2024-02-07 22:24:17 --> Helper loaded: file_helper
INFO - 2024-02-07 22:24:17 --> Helper loaded: form_helper
INFO - 2024-02-07 22:24:17 --> Helper loaded: form_helper
INFO - 2024-02-07 22:24:17 --> Database Driver Class Initialized
INFO - 2024-02-07 22:24:17 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:24:17 --> Controller Class Initialized
DEBUG - 2024-02-07 22:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:24:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:24:17 --> Final output sent to browser
DEBUG - 2024-02-07 22:24:17 --> Total execution time: 0.0306
INFO - 2024-02-07 22:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:24:17 --> Controller Class Initialized
INFO - 2024-02-07 22:24:17 --> Form Validation Class Initialized
INFO - 2024-02-07 22:24:17 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:24:17 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:24:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:24:25 --> Config Class Initialized
INFO - 2024-02-07 22:24:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:24:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:24:25 --> Utf8 Class Initialized
INFO - 2024-02-07 22:24:25 --> URI Class Initialized
INFO - 2024-02-07 22:24:25 --> Router Class Initialized
INFO - 2024-02-07 22:24:25 --> Output Class Initialized
INFO - 2024-02-07 22:24:25 --> Security Class Initialized
DEBUG - 2024-02-07 22:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:24:25 --> Input Class Initialized
INFO - 2024-02-07 22:24:25 --> Language Class Initialized
INFO - 2024-02-07 22:24:25 --> Loader Class Initialized
INFO - 2024-02-07 22:24:25 --> Helper loaded: url_helper
INFO - 2024-02-07 22:24:25 --> Helper loaded: file_helper
INFO - 2024-02-07 22:24:25 --> Helper loaded: form_helper
INFO - 2024-02-07 22:24:25 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:24:25 --> Controller Class Initialized
INFO - 2024-02-07 22:24:25 --> Form Validation Class Initialized
INFO - 2024-02-07 22:24:25 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:24:25 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:24:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:24:25 --> Config Class Initialized
INFO - 2024-02-07 22:24:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:24:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:24:25 --> Utf8 Class Initialized
INFO - 2024-02-07 22:24:25 --> URI Class Initialized
INFO - 2024-02-07 22:24:25 --> Router Class Initialized
INFO - 2024-02-07 22:24:25 --> Output Class Initialized
INFO - 2024-02-07 22:24:25 --> Security Class Initialized
DEBUG - 2024-02-07 22:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:24:25 --> Input Class Initialized
INFO - 2024-02-07 22:24:25 --> Language Class Initialized
INFO - 2024-02-07 22:24:25 --> Loader Class Initialized
INFO - 2024-02-07 22:24:25 --> Helper loaded: url_helper
INFO - 2024-02-07 22:24:25 --> Helper loaded: file_helper
INFO - 2024-02-07 22:24:25 --> Helper loaded: form_helper
INFO - 2024-02-07 22:24:25 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:24:25 --> Controller Class Initialized
INFO - 2024-02-07 22:24:25 --> Form Validation Class Initialized
INFO - 2024-02-07 22:24:25 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:24:25 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:25:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:25:06 --> Config Class Initialized
INFO - 2024-02-07 22:25:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:25:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:25:06 --> Utf8 Class Initialized
INFO - 2024-02-07 22:25:06 --> URI Class Initialized
INFO - 2024-02-07 22:25:06 --> Router Class Initialized
INFO - 2024-02-07 22:25:06 --> Output Class Initialized
INFO - 2024-02-07 22:25:06 --> Security Class Initialized
DEBUG - 2024-02-07 22:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:25:06 --> Input Class Initialized
INFO - 2024-02-07 22:25:06 --> Language Class Initialized
INFO - 2024-02-07 22:25:06 --> Loader Class Initialized
INFO - 2024-02-07 22:25:06 --> Helper loaded: url_helper
INFO - 2024-02-07 22:25:06 --> Helper loaded: file_helper
INFO - 2024-02-07 22:25:06 --> Helper loaded: form_helper
INFO - 2024-02-07 22:25:06 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:25:06 --> Controller Class Initialized
INFO - 2024-02-07 22:25:06 --> Form Validation Class Initialized
INFO - 2024-02-07 22:25:06 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:25:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:25:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:25:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:25:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:25:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:25:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:25:06 --> Final output sent to browser
DEBUG - 2024-02-07 22:25:06 --> Total execution time: 0.0557
ERROR - 2024-02-07 22:25:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:25:06 --> Config Class Initialized
INFO - 2024-02-07 22:25:06 --> Hooks Class Initialized
ERROR - 2024-02-07 22:25:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2024-02-07 22:25:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:25:06 --> Utf8 Class Initialized
INFO - 2024-02-07 22:25:06 --> URI Class Initialized
INFO - 2024-02-07 22:25:06 --> Config Class Initialized
INFO - 2024-02-07 22:25:06 --> Hooks Class Initialized
INFO - 2024-02-07 22:25:06 --> Router Class Initialized
INFO - 2024-02-07 22:25:06 --> Output Class Initialized
DEBUG - 2024-02-07 22:25:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:25:06 --> Utf8 Class Initialized
INFO - 2024-02-07 22:25:06 --> URI Class Initialized
INFO - 2024-02-07 22:25:06 --> Security Class Initialized
DEBUG - 2024-02-07 22:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:25:06 --> Router Class Initialized
INFO - 2024-02-07 22:25:06 --> Input Class Initialized
INFO - 2024-02-07 22:25:06 --> Language Class Initialized
INFO - 2024-02-07 22:25:06 --> Output Class Initialized
INFO - 2024-02-07 22:25:06 --> Security Class Initialized
INFO - 2024-02-07 22:25:06 --> Loader Class Initialized
DEBUG - 2024-02-07 22:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:25:06 --> Input Class Initialized
INFO - 2024-02-07 22:25:06 --> Language Class Initialized
INFO - 2024-02-07 22:25:06 --> Helper loaded: url_helper
INFO - 2024-02-07 22:25:06 --> Helper loaded: file_helper
INFO - 2024-02-07 22:25:06 --> Helper loaded: form_helper
INFO - 2024-02-07 22:25:06 --> Loader Class Initialized
INFO - 2024-02-07 22:25:06 --> Helper loaded: url_helper
INFO - 2024-02-07 22:25:06 --> Helper loaded: file_helper
INFO - 2024-02-07 22:25:06 --> Helper loaded: form_helper
INFO - 2024-02-07 22:25:06 --> Database Driver Class Initialized
INFO - 2024-02-07 22:25:06 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 22:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:25:06 --> Controller Class Initialized
INFO - 2024-02-07 22:25:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:25:06 --> Final output sent to browser
DEBUG - 2024-02-07 22:25:06 --> Total execution time: 0.0251
INFO - 2024-02-07 22:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:25:06 --> Controller Class Initialized
INFO - 2024-02-07 22:25:06 --> Form Validation Class Initialized
INFO - 2024-02-07 22:25:06 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:25:06 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:25:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:25:14 --> Config Class Initialized
INFO - 2024-02-07 22:25:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:25:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:25:14 --> Utf8 Class Initialized
INFO - 2024-02-07 22:25:14 --> URI Class Initialized
INFO - 2024-02-07 22:25:14 --> Router Class Initialized
INFO - 2024-02-07 22:25:14 --> Output Class Initialized
INFO - 2024-02-07 22:25:14 --> Security Class Initialized
DEBUG - 2024-02-07 22:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:25:14 --> Input Class Initialized
INFO - 2024-02-07 22:25:14 --> Language Class Initialized
INFO - 2024-02-07 22:25:14 --> Loader Class Initialized
INFO - 2024-02-07 22:25:14 --> Helper loaded: url_helper
INFO - 2024-02-07 22:25:14 --> Helper loaded: file_helper
INFO - 2024-02-07 22:25:14 --> Helper loaded: form_helper
INFO - 2024-02-07 22:25:14 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:25:14 --> Controller Class Initialized
INFO - 2024-02-07 22:25:14 --> Form Validation Class Initialized
INFO - 2024-02-07 22:25:14 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:25:14 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:25:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:25:14 --> Config Class Initialized
INFO - 2024-02-07 22:25:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:25:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:25:14 --> Utf8 Class Initialized
INFO - 2024-02-07 22:25:14 --> URI Class Initialized
INFO - 2024-02-07 22:25:14 --> Router Class Initialized
INFO - 2024-02-07 22:25:14 --> Output Class Initialized
INFO - 2024-02-07 22:25:14 --> Security Class Initialized
DEBUG - 2024-02-07 22:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:25:14 --> Input Class Initialized
INFO - 2024-02-07 22:25:14 --> Language Class Initialized
INFO - 2024-02-07 22:25:14 --> Loader Class Initialized
INFO - 2024-02-07 22:25:14 --> Helper loaded: url_helper
INFO - 2024-02-07 22:25:14 --> Helper loaded: file_helper
INFO - 2024-02-07 22:25:14 --> Helper loaded: form_helper
INFO - 2024-02-07 22:25:14 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:25:14 --> Controller Class Initialized
INFO - 2024-02-07 22:25:14 --> Form Validation Class Initialized
INFO - 2024-02-07 22:25:14 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:25:14 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:25:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:25:42 --> Config Class Initialized
INFO - 2024-02-07 22:25:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:25:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:25:42 --> Utf8 Class Initialized
INFO - 2024-02-07 22:25:42 --> URI Class Initialized
INFO - 2024-02-07 22:25:42 --> Router Class Initialized
INFO - 2024-02-07 22:25:42 --> Output Class Initialized
INFO - 2024-02-07 22:25:42 --> Security Class Initialized
DEBUG - 2024-02-07 22:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:25:42 --> Input Class Initialized
INFO - 2024-02-07 22:25:42 --> Language Class Initialized
INFO - 2024-02-07 22:25:42 --> Loader Class Initialized
INFO - 2024-02-07 22:25:42 --> Helper loaded: url_helper
INFO - 2024-02-07 22:25:42 --> Helper loaded: file_helper
INFO - 2024-02-07 22:25:42 --> Helper loaded: form_helper
INFO - 2024-02-07 22:25:42 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:25:42 --> Controller Class Initialized
INFO - 2024-02-07 22:25:42 --> Form Validation Class Initialized
INFO - 2024-02-07 22:25:43 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:25:43 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:26:00 --> Config Class Initialized
INFO - 2024-02-07 22:26:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:26:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:26:00 --> Utf8 Class Initialized
INFO - 2024-02-07 22:26:00 --> URI Class Initialized
INFO - 2024-02-07 22:26:00 --> Router Class Initialized
INFO - 2024-02-07 22:26:00 --> Output Class Initialized
INFO - 2024-02-07 22:26:00 --> Security Class Initialized
DEBUG - 2024-02-07 22:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:26:00 --> Input Class Initialized
INFO - 2024-02-07 22:26:00 --> Language Class Initialized
INFO - 2024-02-07 22:26:00 --> Loader Class Initialized
INFO - 2024-02-07 22:26:00 --> Helper loaded: url_helper
INFO - 2024-02-07 22:26:00 --> Helper loaded: file_helper
INFO - 2024-02-07 22:26:00 --> Helper loaded: form_helper
INFO - 2024-02-07 22:26:00 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:26:00 --> Controller Class Initialized
INFO - 2024-02-07 22:26:00 --> Form Validation Class Initialized
INFO - 2024-02-07 22:26:00 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:26:00 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:26:00 --> Config Class Initialized
INFO - 2024-02-07 22:26:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:26:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:26:00 --> Utf8 Class Initialized
INFO - 2024-02-07 22:26:00 --> URI Class Initialized
INFO - 2024-02-07 22:26:00 --> Router Class Initialized
INFO - 2024-02-07 22:26:00 --> Output Class Initialized
INFO - 2024-02-07 22:26:00 --> Security Class Initialized
DEBUG - 2024-02-07 22:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:26:00 --> Input Class Initialized
INFO - 2024-02-07 22:26:00 --> Language Class Initialized
INFO - 2024-02-07 22:26:00 --> Loader Class Initialized
INFO - 2024-02-07 22:26:00 --> Helper loaded: url_helper
INFO - 2024-02-07 22:26:00 --> Helper loaded: file_helper
INFO - 2024-02-07 22:26:00 --> Helper loaded: form_helper
INFO - 2024-02-07 22:26:00 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:26:00 --> Controller Class Initialized
INFO - 2024-02-07 22:26:00 --> Form Validation Class Initialized
INFO - 2024-02-07 22:26:00 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:26:00 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:26:06 --> Config Class Initialized
INFO - 2024-02-07 22:26:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:26:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:26:06 --> Utf8 Class Initialized
INFO - 2024-02-07 22:26:06 --> URI Class Initialized
INFO - 2024-02-07 22:26:06 --> Router Class Initialized
INFO - 2024-02-07 22:26:06 --> Output Class Initialized
INFO - 2024-02-07 22:26:06 --> Security Class Initialized
DEBUG - 2024-02-07 22:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:26:06 --> Input Class Initialized
INFO - 2024-02-07 22:26:06 --> Language Class Initialized
INFO - 2024-02-07 22:26:06 --> Loader Class Initialized
INFO - 2024-02-07 22:26:06 --> Helper loaded: url_helper
INFO - 2024-02-07 22:26:06 --> Helper loaded: file_helper
INFO - 2024-02-07 22:26:06 --> Helper loaded: form_helper
INFO - 2024-02-07 22:26:06 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:26:06 --> Controller Class Initialized
INFO - 2024-02-07 22:26:06 --> Form Validation Class Initialized
INFO - 2024-02-07 22:26:06 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:26:06 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:26:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:26:55 --> Config Class Initialized
INFO - 2024-02-07 22:26:55 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:26:55 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:26:55 --> Utf8 Class Initialized
INFO - 2024-02-07 22:26:55 --> URI Class Initialized
INFO - 2024-02-07 22:26:55 --> Router Class Initialized
INFO - 2024-02-07 22:26:55 --> Output Class Initialized
INFO - 2024-02-07 22:26:55 --> Security Class Initialized
DEBUG - 2024-02-07 22:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:26:55 --> Input Class Initialized
INFO - 2024-02-07 22:26:55 --> Language Class Initialized
INFO - 2024-02-07 22:26:55 --> Loader Class Initialized
INFO - 2024-02-07 22:26:55 --> Helper loaded: url_helper
INFO - 2024-02-07 22:26:55 --> Helper loaded: file_helper
INFO - 2024-02-07 22:26:55 --> Helper loaded: form_helper
INFO - 2024-02-07 22:26:55 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:26:55 --> Controller Class Initialized
INFO - 2024-02-07 22:26:55 --> Form Validation Class Initialized
INFO - 2024-02-07 22:26:55 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:26:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:26:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:26:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:26:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:26:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:26:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:26:55 --> Final output sent to browser
DEBUG - 2024-02-07 22:26:55 --> Total execution time: 0.0488
ERROR - 2024-02-07 22:26:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:26:57 --> Config Class Initialized
INFO - 2024-02-07 22:26:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:26:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:26:57 --> Utf8 Class Initialized
INFO - 2024-02-07 22:26:57 --> URI Class Initialized
INFO - 2024-02-07 22:26:57 --> Router Class Initialized
ERROR - 2024-02-07 22:26:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:26:57 --> Output Class Initialized
INFO - 2024-02-07 22:26:57 --> Config Class Initialized
INFO - 2024-02-07 22:26:57 --> Hooks Class Initialized
INFO - 2024-02-07 22:26:57 --> Security Class Initialized
DEBUG - 2024-02-07 22:26:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:26:57 --> Utf8 Class Initialized
DEBUG - 2024-02-07 22:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:26:57 --> Input Class Initialized
INFO - 2024-02-07 22:26:57 --> URI Class Initialized
INFO - 2024-02-07 22:26:57 --> Language Class Initialized
INFO - 2024-02-07 22:26:57 --> Router Class Initialized
INFO - 2024-02-07 22:26:57 --> Output Class Initialized
INFO - 2024-02-07 22:26:57 --> Loader Class Initialized
INFO - 2024-02-07 22:26:57 --> Security Class Initialized
INFO - 2024-02-07 22:26:57 --> Helper loaded: url_helper
INFO - 2024-02-07 22:26:57 --> Helper loaded: file_helper
DEBUG - 2024-02-07 22:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:26:57 --> Input Class Initialized
INFO - 2024-02-07 22:26:57 --> Language Class Initialized
INFO - 2024-02-07 22:26:57 --> Helper loaded: form_helper
INFO - 2024-02-07 22:26:57 --> Loader Class Initialized
INFO - 2024-02-07 22:26:57 --> Helper loaded: url_helper
INFO - 2024-02-07 22:26:57 --> Helper loaded: file_helper
INFO - 2024-02-07 22:26:57 --> Database Driver Class Initialized
INFO - 2024-02-07 22:26:57 --> Helper loaded: form_helper
DEBUG - 2024-02-07 22:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:26:57 --> Controller Class Initialized
INFO - 2024-02-07 22:26:57 --> Database Driver Class Initialized
INFO - 2024-02-07 22:26:57 --> Form Validation Class Initialized
INFO - 2024-02-07 22:26:57 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:26:57 --> Model "UserMasterModel" initialized
DEBUG - 2024-02-07 22:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:26:57 --> Controller Class Initialized
INFO - 2024-02-07 22:26:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:26:57 --> Final output sent to browser
DEBUG - 2024-02-07 22:26:57 --> Total execution time: 0.0391
ERROR - 2024-02-07 22:27:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:27:03 --> Config Class Initialized
INFO - 2024-02-07 22:27:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:27:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:27:03 --> Utf8 Class Initialized
INFO - 2024-02-07 22:27:03 --> URI Class Initialized
INFO - 2024-02-07 22:27:03 --> Router Class Initialized
INFO - 2024-02-07 22:27:03 --> Output Class Initialized
INFO - 2024-02-07 22:27:03 --> Security Class Initialized
DEBUG - 2024-02-07 22:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:27:03 --> Input Class Initialized
INFO - 2024-02-07 22:27:03 --> Language Class Initialized
INFO - 2024-02-07 22:27:03 --> Loader Class Initialized
INFO - 2024-02-07 22:27:03 --> Helper loaded: url_helper
INFO - 2024-02-07 22:27:03 --> Helper loaded: file_helper
INFO - 2024-02-07 22:27:03 --> Helper loaded: form_helper
INFO - 2024-02-07 22:27:03 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:27:03 --> Controller Class Initialized
INFO - 2024-02-07 22:27:03 --> Form Validation Class Initialized
INFO - 2024-02-07 22:27:03 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:27:03 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:27:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:27:03 --> Config Class Initialized
INFO - 2024-02-07 22:27:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:27:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:27:03 --> Utf8 Class Initialized
INFO - 2024-02-07 22:27:03 --> URI Class Initialized
INFO - 2024-02-07 22:27:03 --> Router Class Initialized
INFO - 2024-02-07 22:27:03 --> Output Class Initialized
INFO - 2024-02-07 22:27:03 --> Security Class Initialized
DEBUG - 2024-02-07 22:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:27:03 --> Input Class Initialized
INFO - 2024-02-07 22:27:03 --> Language Class Initialized
INFO - 2024-02-07 22:27:03 --> Loader Class Initialized
INFO - 2024-02-07 22:27:03 --> Helper loaded: url_helper
INFO - 2024-02-07 22:27:03 --> Helper loaded: file_helper
INFO - 2024-02-07 22:27:03 --> Helper loaded: form_helper
INFO - 2024-02-07 22:27:03 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:27:03 --> Controller Class Initialized
INFO - 2024-02-07 22:27:03 --> Form Validation Class Initialized
INFO - 2024-02-07 22:27:03 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:27:03 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:27:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:27:51 --> Config Class Initialized
INFO - 2024-02-07 22:27:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:27:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:27:51 --> Utf8 Class Initialized
INFO - 2024-02-07 22:27:51 --> URI Class Initialized
INFO - 2024-02-07 22:27:51 --> Router Class Initialized
INFO - 2024-02-07 22:27:51 --> Output Class Initialized
INFO - 2024-02-07 22:27:51 --> Security Class Initialized
DEBUG - 2024-02-07 22:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:27:51 --> Input Class Initialized
INFO - 2024-02-07 22:27:51 --> Language Class Initialized
INFO - 2024-02-07 22:27:51 --> Loader Class Initialized
INFO - 2024-02-07 22:27:51 --> Helper loaded: url_helper
INFO - 2024-02-07 22:27:51 --> Helper loaded: file_helper
INFO - 2024-02-07 22:27:51 --> Helper loaded: form_helper
INFO - 2024-02-07 22:27:51 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:27:51 --> Controller Class Initialized
INFO - 2024-02-07 22:27:51 --> Form Validation Class Initialized
INFO - 2024-02-07 22:27:51 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:27:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-07 22:27:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-07 22:27:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-07 22:27:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-07 22:27:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-07 22:27:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-07 22:27:51 --> Final output sent to browser
DEBUG - 2024-02-07 22:27:51 --> Total execution time: 0.0430
ERROR - 2024-02-07 22:27:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:27:51 --> Config Class Initialized
INFO - 2024-02-07 22:27:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:27:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:27:51 --> Utf8 Class Initialized
INFO - 2024-02-07 22:27:51 --> URI Class Initialized
INFO - 2024-02-07 22:27:51 --> Router Class Initialized
INFO - 2024-02-07 22:27:51 --> Output Class Initialized
INFO - 2024-02-07 22:27:51 --> Security Class Initialized
DEBUG - 2024-02-07 22:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:27:51 --> Input Class Initialized
INFO - 2024-02-07 22:27:51 --> Language Class Initialized
INFO - 2024-02-07 22:27:51 --> Loader Class Initialized
INFO - 2024-02-07 22:27:51 --> Helper loaded: url_helper
INFO - 2024-02-07 22:27:51 --> Helper loaded: file_helper
ERROR - 2024-02-07 22:27:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:27:51 --> Helper loaded: form_helper
INFO - 2024-02-07 22:27:51 --> Config Class Initialized
INFO - 2024-02-07 22:27:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:27:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:27:51 --> Utf8 Class Initialized
INFO - 2024-02-07 22:27:51 --> URI Class Initialized
INFO - 2024-02-07 22:27:51 --> Router Class Initialized
INFO - 2024-02-07 22:27:51 --> Database Driver Class Initialized
INFO - 2024-02-07 22:27:51 --> Output Class Initialized
INFO - 2024-02-07 22:27:51 --> Security Class Initialized
DEBUG - 2024-02-07 22:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:27:51 --> Input Class Initialized
DEBUG - 2024-02-07 22:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:27:51 --> Language Class Initialized
INFO - 2024-02-07 22:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:27:51 --> Controller Class Initialized
INFO - 2024-02-07 22:27:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-07 22:27:51 --> Final output sent to browser
DEBUG - 2024-02-07 22:27:51 --> Total execution time: 0.0279
INFO - 2024-02-07 22:27:51 --> Loader Class Initialized
INFO - 2024-02-07 22:27:51 --> Helper loaded: url_helper
INFO - 2024-02-07 22:27:51 --> Helper loaded: file_helper
INFO - 2024-02-07 22:27:51 --> Helper loaded: form_helper
INFO - 2024-02-07 22:27:51 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:27:51 --> Controller Class Initialized
INFO - 2024-02-07 22:27:51 --> Form Validation Class Initialized
INFO - 2024-02-07 22:27:51 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:27:51 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:28:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:28:04 --> Config Class Initialized
INFO - 2024-02-07 22:28:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:28:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:28:04 --> Utf8 Class Initialized
INFO - 2024-02-07 22:28:04 --> URI Class Initialized
INFO - 2024-02-07 22:28:04 --> Router Class Initialized
INFO - 2024-02-07 22:28:04 --> Output Class Initialized
INFO - 2024-02-07 22:28:04 --> Security Class Initialized
DEBUG - 2024-02-07 22:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:28:04 --> Input Class Initialized
INFO - 2024-02-07 22:28:04 --> Language Class Initialized
INFO - 2024-02-07 22:28:04 --> Loader Class Initialized
INFO - 2024-02-07 22:28:04 --> Helper loaded: url_helper
INFO - 2024-02-07 22:28:04 --> Helper loaded: file_helper
INFO - 2024-02-07 22:28:04 --> Helper loaded: form_helper
INFO - 2024-02-07 22:28:04 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:28:04 --> Controller Class Initialized
INFO - 2024-02-07 22:28:04 --> Form Validation Class Initialized
INFO - 2024-02-07 22:28:04 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:28:04 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:28:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:28:04 --> Config Class Initialized
INFO - 2024-02-07 22:28:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:28:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:28:04 --> Utf8 Class Initialized
INFO - 2024-02-07 22:28:04 --> URI Class Initialized
INFO - 2024-02-07 22:28:04 --> Router Class Initialized
INFO - 2024-02-07 22:28:04 --> Output Class Initialized
INFO - 2024-02-07 22:28:04 --> Security Class Initialized
DEBUG - 2024-02-07 22:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:28:04 --> Input Class Initialized
INFO - 2024-02-07 22:28:04 --> Language Class Initialized
INFO - 2024-02-07 22:28:04 --> Loader Class Initialized
INFO - 2024-02-07 22:28:04 --> Helper loaded: url_helper
INFO - 2024-02-07 22:28:04 --> Helper loaded: file_helper
INFO - 2024-02-07 22:28:04 --> Helper loaded: form_helper
INFO - 2024-02-07 22:28:04 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:28:04 --> Controller Class Initialized
INFO - 2024-02-07 22:28:04 --> Form Validation Class Initialized
INFO - 2024-02-07 22:28:04 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:28:04 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:28:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:28:08 --> Config Class Initialized
INFO - 2024-02-07 22:28:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:28:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:28:08 --> Utf8 Class Initialized
INFO - 2024-02-07 22:28:08 --> URI Class Initialized
INFO - 2024-02-07 22:28:08 --> Router Class Initialized
INFO - 2024-02-07 22:28:08 --> Output Class Initialized
INFO - 2024-02-07 22:28:08 --> Security Class Initialized
DEBUG - 2024-02-07 22:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:28:08 --> Input Class Initialized
INFO - 2024-02-07 22:28:08 --> Language Class Initialized
INFO - 2024-02-07 22:28:08 --> Loader Class Initialized
INFO - 2024-02-07 22:28:08 --> Helper loaded: url_helper
INFO - 2024-02-07 22:28:08 --> Helper loaded: file_helper
INFO - 2024-02-07 22:28:08 --> Helper loaded: form_helper
INFO - 2024-02-07 22:28:08 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:28:08 --> Controller Class Initialized
INFO - 2024-02-07 22:28:08 --> Form Validation Class Initialized
INFO - 2024-02-07 22:28:08 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:28:08 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:28:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:28:18 --> Config Class Initialized
INFO - 2024-02-07 22:28:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:28:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:28:18 --> Utf8 Class Initialized
INFO - 2024-02-07 22:28:18 --> URI Class Initialized
INFO - 2024-02-07 22:28:18 --> Router Class Initialized
INFO - 2024-02-07 22:28:18 --> Output Class Initialized
INFO - 2024-02-07 22:28:18 --> Security Class Initialized
DEBUG - 2024-02-07 22:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:28:18 --> Input Class Initialized
INFO - 2024-02-07 22:28:18 --> Language Class Initialized
INFO - 2024-02-07 22:28:18 --> Loader Class Initialized
INFO - 2024-02-07 22:28:18 --> Helper loaded: url_helper
INFO - 2024-02-07 22:28:18 --> Helper loaded: file_helper
INFO - 2024-02-07 22:28:18 --> Helper loaded: form_helper
INFO - 2024-02-07 22:28:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:28:18 --> Controller Class Initialized
INFO - 2024-02-07 22:28:18 --> Form Validation Class Initialized
INFO - 2024-02-07 22:28:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:28:18 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:28:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:28:18 --> Config Class Initialized
INFO - 2024-02-07 22:28:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:28:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:28:18 --> Utf8 Class Initialized
INFO - 2024-02-07 22:28:18 --> URI Class Initialized
INFO - 2024-02-07 22:28:18 --> Router Class Initialized
INFO - 2024-02-07 22:28:18 --> Output Class Initialized
INFO - 2024-02-07 22:28:18 --> Security Class Initialized
DEBUG - 2024-02-07 22:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:28:18 --> Input Class Initialized
INFO - 2024-02-07 22:28:18 --> Language Class Initialized
INFO - 2024-02-07 22:28:18 --> Loader Class Initialized
INFO - 2024-02-07 22:28:18 --> Helper loaded: url_helper
INFO - 2024-02-07 22:28:18 --> Helper loaded: file_helper
INFO - 2024-02-07 22:28:18 --> Helper loaded: form_helper
INFO - 2024-02-07 22:28:18 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:28:18 --> Controller Class Initialized
INFO - 2024-02-07 22:28:18 --> Form Validation Class Initialized
INFO - 2024-02-07 22:28:18 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:28:18 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:28:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:28:24 --> Config Class Initialized
INFO - 2024-02-07 22:28:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:28:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:28:24 --> Utf8 Class Initialized
INFO - 2024-02-07 22:28:24 --> URI Class Initialized
INFO - 2024-02-07 22:28:24 --> Router Class Initialized
INFO - 2024-02-07 22:28:24 --> Output Class Initialized
INFO - 2024-02-07 22:28:24 --> Security Class Initialized
DEBUG - 2024-02-07 22:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:28:24 --> Input Class Initialized
INFO - 2024-02-07 22:28:24 --> Language Class Initialized
INFO - 2024-02-07 22:28:24 --> Loader Class Initialized
INFO - 2024-02-07 22:28:24 --> Helper loaded: url_helper
INFO - 2024-02-07 22:28:24 --> Helper loaded: file_helper
INFO - 2024-02-07 22:28:24 --> Helper loaded: form_helper
INFO - 2024-02-07 22:28:24 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:28:24 --> Controller Class Initialized
INFO - 2024-02-07 22:28:24 --> Form Validation Class Initialized
INFO - 2024-02-07 22:28:24 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:28:24 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:28:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:28:24 --> Config Class Initialized
INFO - 2024-02-07 22:28:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:28:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:28:24 --> Utf8 Class Initialized
INFO - 2024-02-07 22:28:24 --> URI Class Initialized
INFO - 2024-02-07 22:28:24 --> Router Class Initialized
INFO - 2024-02-07 22:28:24 --> Output Class Initialized
INFO - 2024-02-07 22:28:24 --> Security Class Initialized
DEBUG - 2024-02-07 22:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:28:24 --> Input Class Initialized
INFO - 2024-02-07 22:28:24 --> Language Class Initialized
INFO - 2024-02-07 22:28:24 --> Loader Class Initialized
INFO - 2024-02-07 22:28:24 --> Helper loaded: url_helper
INFO - 2024-02-07 22:28:24 --> Helper loaded: file_helper
INFO - 2024-02-07 22:28:24 --> Helper loaded: form_helper
INFO - 2024-02-07 22:28:24 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:28:24 --> Controller Class Initialized
INFO - 2024-02-07 22:28:24 --> Form Validation Class Initialized
INFO - 2024-02-07 22:28:24 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:28:24 --> Model "UserMasterModel" initialized
ERROR - 2024-02-07 22:28:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-07 22:28:26 --> Config Class Initialized
INFO - 2024-02-07 22:28:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 22:28:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 22:28:26 --> Utf8 Class Initialized
INFO - 2024-02-07 22:28:26 --> URI Class Initialized
INFO - 2024-02-07 22:28:26 --> Router Class Initialized
INFO - 2024-02-07 22:28:26 --> Output Class Initialized
INFO - 2024-02-07 22:28:26 --> Security Class Initialized
DEBUG - 2024-02-07 22:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 22:28:26 --> Input Class Initialized
INFO - 2024-02-07 22:28:26 --> Language Class Initialized
INFO - 2024-02-07 22:28:26 --> Loader Class Initialized
INFO - 2024-02-07 22:28:26 --> Helper loaded: url_helper
INFO - 2024-02-07 22:28:26 --> Helper loaded: file_helper
INFO - 2024-02-07 22:28:26 --> Helper loaded: form_helper
INFO - 2024-02-07 22:28:26 --> Database Driver Class Initialized
DEBUG - 2024-02-07 22:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-07 22:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 22:28:26 --> Controller Class Initialized
INFO - 2024-02-07 22:28:26 --> Form Validation Class Initialized
INFO - 2024-02-07 22:28:26 --> Model "MasterModel" initialized
INFO - 2024-02-07 22:28:26 --> Model "UserMasterModel" initialized
