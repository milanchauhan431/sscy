<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-15 11:42:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 11:42:46 --> Config Class Initialized
INFO - 2024-02-15 11:42:46 --> Hooks Class Initialized
DEBUG - 2024-02-15 11:42:46 --> UTF-8 Support Enabled
INFO - 2024-02-15 11:42:46 --> Utf8 Class Initialized
INFO - 2024-02-15 11:42:46 --> URI Class Initialized
INFO - 2024-02-15 11:42:46 --> Router Class Initialized
INFO - 2024-02-15 11:42:46 --> Output Class Initialized
INFO - 2024-02-15 11:42:46 --> Security Class Initialized
DEBUG - 2024-02-15 11:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 11:42:46 --> Input Class Initialized
INFO - 2024-02-15 11:42:46 --> Language Class Initialized
INFO - 2024-02-15 11:42:46 --> Loader Class Initialized
INFO - 2024-02-15 11:42:46 --> Helper loaded: url_helper
INFO - 2024-02-15 11:42:46 --> Helper loaded: file_helper
INFO - 2024-02-15 11:42:46 --> Helper loaded: form_helper
INFO - 2024-02-15 11:42:46 --> Database Driver Class Initialized
DEBUG - 2024-02-15 11:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 11:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 11:42:46 --> Controller Class Initialized
INFO - 2024-02-15 11:42:46 --> Model "LoginModel" initialized
INFO - 2024-02-15 11:42:46 --> Form Validation Class Initialized
ERROR - 2024-02-15 11:42:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 11:42:46 --> Config Class Initialized
INFO - 2024-02-15 11:42:46 --> Hooks Class Initialized
DEBUG - 2024-02-15 11:42:46 --> UTF-8 Support Enabled
INFO - 2024-02-15 11:42:46 --> Utf8 Class Initialized
INFO - 2024-02-15 11:42:46 --> URI Class Initialized
INFO - 2024-02-15 11:42:46 --> Router Class Initialized
INFO - 2024-02-15 11:42:46 --> Output Class Initialized
INFO - 2024-02-15 11:42:46 --> Security Class Initialized
DEBUG - 2024-02-15 11:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 11:42:46 --> Input Class Initialized
INFO - 2024-02-15 11:42:46 --> Language Class Initialized
INFO - 2024-02-15 11:42:46 --> Loader Class Initialized
INFO - 2024-02-15 11:42:46 --> Helper loaded: url_helper
INFO - 2024-02-15 11:42:46 --> Helper loaded: file_helper
INFO - 2024-02-15 11:42:46 --> Helper loaded: form_helper
INFO - 2024-02-15 11:42:46 --> Database Driver Class Initialized
DEBUG - 2024-02-15 11:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 11:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 11:42:46 --> Controller Class Initialized
INFO - 2024-02-15 11:42:46 --> Form Validation Class Initialized
INFO - 2024-02-15 11:42:46 --> Model "MasterModel" initialized
INFO - 2024-02-15 11:42:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 11:42:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 11:42:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 11:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 11:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-15 11:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 11:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 11:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 11:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-15 11:42:46 --> Final output sent to browser
DEBUG - 2024-02-15 11:42:46 --> Total execution time: 0.0293
ERROR - 2024-02-15 18:29:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:29:59 --> Config Class Initialized
INFO - 2024-02-15 18:29:59 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:29:59 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:29:59 --> Utf8 Class Initialized
INFO - 2024-02-15 18:29:59 --> URI Class Initialized
INFO - 2024-02-15 18:29:59 --> Router Class Initialized
INFO - 2024-02-15 18:29:59 --> Output Class Initialized
INFO - 2024-02-15 18:29:59 --> Security Class Initialized
DEBUG - 2024-02-15 18:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:29:59 --> Input Class Initialized
INFO - 2024-02-15 18:29:59 --> Language Class Initialized
INFO - 2024-02-15 18:29:59 --> Loader Class Initialized
INFO - 2024-02-15 18:29:59 --> Helper loaded: url_helper
INFO - 2024-02-15 18:29:59 --> Helper loaded: file_helper
INFO - 2024-02-15 18:29:59 --> Helper loaded: form_helper
INFO - 2024-02-15 18:29:59 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:29:59 --> Controller Class Initialized
INFO - 2024-02-15 18:29:59 --> Model "LoginModel" initialized
INFO - 2024-02-15 18:29:59 --> Form Validation Class Initialized
ERROR - 2024-02-15 18:29:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:29:59 --> Config Class Initialized
INFO - 2024-02-15 18:29:59 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:29:59 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:29:59 --> Utf8 Class Initialized
INFO - 2024-02-15 18:29:59 --> URI Class Initialized
INFO - 2024-02-15 18:29:59 --> Router Class Initialized
INFO - 2024-02-15 18:29:59 --> Output Class Initialized
INFO - 2024-02-15 18:29:59 --> Security Class Initialized
DEBUG - 2024-02-15 18:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:29:59 --> Input Class Initialized
INFO - 2024-02-15 18:29:59 --> Language Class Initialized
INFO - 2024-02-15 18:29:59 --> Loader Class Initialized
INFO - 2024-02-15 18:29:59 --> Helper loaded: url_helper
INFO - 2024-02-15 18:29:59 --> Helper loaded: file_helper
INFO - 2024-02-15 18:29:59 --> Helper loaded: form_helper
INFO - 2024-02-15 18:29:59 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:29:59 --> Controller Class Initialized
INFO - 2024-02-15 18:29:59 --> Form Validation Class Initialized
INFO - 2024-02-15 18:29:59 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:29:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:29:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:29:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:29:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:29:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-15 18:29:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:29:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:29:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:29:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-15 18:29:59 --> Final output sent to browser
DEBUG - 2024-02-15 18:29:59 --> Total execution time: 0.0179
ERROR - 2024-02-15 18:30:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:30:09 --> Config Class Initialized
INFO - 2024-02-15 18:30:09 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:30:09 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:30:09 --> Utf8 Class Initialized
INFO - 2024-02-15 18:30:09 --> URI Class Initialized
INFO - 2024-02-15 18:30:09 --> Router Class Initialized
INFO - 2024-02-15 18:30:09 --> Output Class Initialized
INFO - 2024-02-15 18:30:09 --> Security Class Initialized
DEBUG - 2024-02-15 18:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:30:09 --> Input Class Initialized
INFO - 2024-02-15 18:30:09 --> Language Class Initialized
INFO - 2024-02-15 18:30:09 --> Loader Class Initialized
INFO - 2024-02-15 18:30:09 --> Helper loaded: url_helper
INFO - 2024-02-15 18:30:09 --> Helper loaded: file_helper
INFO - 2024-02-15 18:30:09 --> Helper loaded: form_helper
INFO - 2024-02-15 18:30:09 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:30:09 --> Controller Class Initialized
INFO - 2024-02-15 18:30:09 --> Model "LoginModel" initialized
INFO - 2024-02-15 18:30:09 --> Form Validation Class Initialized
ERROR - 2024-02-15 18:30:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:30:09 --> Config Class Initialized
INFO - 2024-02-15 18:30:09 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:30:09 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:30:09 --> Utf8 Class Initialized
INFO - 2024-02-15 18:30:09 --> URI Class Initialized
INFO - 2024-02-15 18:30:09 --> Router Class Initialized
INFO - 2024-02-15 18:30:09 --> Output Class Initialized
INFO - 2024-02-15 18:30:09 --> Security Class Initialized
DEBUG - 2024-02-15 18:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:30:09 --> Input Class Initialized
INFO - 2024-02-15 18:30:09 --> Language Class Initialized
INFO - 2024-02-15 18:30:09 --> Loader Class Initialized
INFO - 2024-02-15 18:30:09 --> Helper loaded: url_helper
INFO - 2024-02-15 18:30:09 --> Helper loaded: file_helper
INFO - 2024-02-15 18:30:09 --> Helper loaded: form_helper
INFO - 2024-02-15 18:30:09 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:30:09 --> Controller Class Initialized
INFO - 2024-02-15 18:30:09 --> Model "LoginModel" initialized
INFO - 2024-02-15 18:30:09 --> Form Validation Class Initialized
INFO - 2024-02-15 18:30:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-15 18:30:09 --> Final output sent to browser
DEBUG - 2024-02-15 18:30:09 --> Total execution time: 0.0258
ERROR - 2024-02-15 18:30:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:30:11 --> Config Class Initialized
INFO - 2024-02-15 18:30:11 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:30:11 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:30:11 --> Utf8 Class Initialized
INFO - 2024-02-15 18:30:11 --> URI Class Initialized
INFO - 2024-02-15 18:30:11 --> Router Class Initialized
INFO - 2024-02-15 18:30:11 --> Output Class Initialized
INFO - 2024-02-15 18:30:11 --> Security Class Initialized
DEBUG - 2024-02-15 18:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:30:11 --> Input Class Initialized
INFO - 2024-02-15 18:30:11 --> Language Class Initialized
INFO - 2024-02-15 18:30:11 --> Loader Class Initialized
INFO - 2024-02-15 18:30:11 --> Helper loaded: url_helper
INFO - 2024-02-15 18:30:11 --> Helper loaded: file_helper
INFO - 2024-02-15 18:30:11 --> Helper loaded: form_helper
INFO - 2024-02-15 18:30:11 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:30:11 --> Controller Class Initialized
INFO - 2024-02-15 18:30:11 --> Model "LoginModel" initialized
INFO - 2024-02-15 18:30:11 --> Form Validation Class Initialized
INFO - 2024-02-15 18:30:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-15 18:30:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:30:11 --> Config Class Initialized
INFO - 2024-02-15 18:30:11 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:30:11 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:30:11 --> Utf8 Class Initialized
INFO - 2024-02-15 18:30:11 --> URI Class Initialized
INFO - 2024-02-15 18:30:11 --> Router Class Initialized
INFO - 2024-02-15 18:30:11 --> Output Class Initialized
INFO - 2024-02-15 18:30:11 --> Security Class Initialized
DEBUG - 2024-02-15 18:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:30:11 --> Input Class Initialized
INFO - 2024-02-15 18:30:11 --> Language Class Initialized
INFO - 2024-02-15 18:30:11 --> Loader Class Initialized
INFO - 2024-02-15 18:30:11 --> Helper loaded: url_helper
INFO - 2024-02-15 18:30:11 --> Helper loaded: file_helper
INFO - 2024-02-15 18:30:11 --> Helper loaded: form_helper
INFO - 2024-02-15 18:30:11 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:30:11 --> Controller Class Initialized
INFO - 2024-02-15 18:30:11 --> Form Validation Class Initialized
INFO - 2024-02-15 18:30:11 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:30:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:30:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:30:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:30:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:30:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-15 18:30:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:30:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:30:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:30:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-15 18:30:11 --> Final output sent to browser
DEBUG - 2024-02-15 18:30:11 --> Total execution time: 0.0247
ERROR - 2024-02-15 18:30:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:30:14 --> Config Class Initialized
INFO - 2024-02-15 18:30:14 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:30:14 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:30:14 --> Utf8 Class Initialized
INFO - 2024-02-15 18:30:14 --> URI Class Initialized
INFO - 2024-02-15 18:30:14 --> Router Class Initialized
INFO - 2024-02-15 18:30:14 --> Output Class Initialized
INFO - 2024-02-15 18:30:14 --> Security Class Initialized
DEBUG - 2024-02-15 18:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:30:14 --> Input Class Initialized
INFO - 2024-02-15 18:30:14 --> Language Class Initialized
INFO - 2024-02-15 18:30:14 --> Loader Class Initialized
INFO - 2024-02-15 18:30:14 --> Helper loaded: url_helper
INFO - 2024-02-15 18:30:14 --> Helper loaded: file_helper
INFO - 2024-02-15 18:30:14 --> Helper loaded: form_helper
INFO - 2024-02-15 18:30:14 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:30:14 --> Controller Class Initialized
INFO - 2024-02-15 18:30:14 --> Form Validation Class Initialized
INFO - 2024-02-15 18:30:14 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:30:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:30:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:30:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-15 18:30:14 --> Final output sent to browser
DEBUG - 2024-02-15 18:30:14 --> Total execution time: 0.0295
ERROR - 2024-02-15 18:30:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:30:14 --> Config Class Initialized
INFO - 2024-02-15 18:30:14 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:30:14 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:30:14 --> Utf8 Class Initialized
INFO - 2024-02-15 18:30:14 --> URI Class Initialized
INFO - 2024-02-15 18:30:14 --> Router Class Initialized
INFO - 2024-02-15 18:30:14 --> Output Class Initialized
INFO - 2024-02-15 18:30:14 --> Security Class Initialized
DEBUG - 2024-02-15 18:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:30:14 --> Input Class Initialized
INFO - 2024-02-15 18:30:14 --> Language Class Initialized
INFO - 2024-02-15 18:30:14 --> Loader Class Initialized
INFO - 2024-02-15 18:30:14 --> Helper loaded: url_helper
INFO - 2024-02-15 18:30:14 --> Helper loaded: file_helper
INFO - 2024-02-15 18:30:14 --> Helper loaded: form_helper
INFO - 2024-02-15 18:30:14 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:30:14 --> Controller Class Initialized
INFO - 2024-02-15 18:30:14 --> Form Validation Class Initialized
INFO - 2024-02-15 18:30:14 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:30:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:30:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:30:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 18:30:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:30:16 --> Config Class Initialized
INFO - 2024-02-15 18:30:16 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:30:16 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:30:16 --> Utf8 Class Initialized
INFO - 2024-02-15 18:30:16 --> URI Class Initialized
INFO - 2024-02-15 18:30:16 --> Router Class Initialized
INFO - 2024-02-15 18:30:16 --> Output Class Initialized
INFO - 2024-02-15 18:30:16 --> Security Class Initialized
DEBUG - 2024-02-15 18:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:30:16 --> Input Class Initialized
INFO - 2024-02-15 18:30:16 --> Language Class Initialized
INFO - 2024-02-15 18:30:16 --> Loader Class Initialized
INFO - 2024-02-15 18:30:16 --> Helper loaded: url_helper
INFO - 2024-02-15 18:30:16 --> Helper loaded: file_helper
INFO - 2024-02-15 18:30:16 --> Helper loaded: form_helper
INFO - 2024-02-15 18:30:16 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:30:16 --> Controller Class Initialized
INFO - 2024-02-15 18:30:16 --> Form Validation Class Initialized
INFO - 2024-02-15 18:30:16 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:30:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:30:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:30:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:30:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:30:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:30:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:30:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:30:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 18:30:16 --> Final output sent to browser
DEBUG - 2024-02-15 18:30:16 --> Total execution time: 0.0359
ERROR - 2024-02-15 18:30:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:30:16 --> Config Class Initialized
INFO - 2024-02-15 18:30:16 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:30:16 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:30:16 --> Utf8 Class Initialized
INFO - 2024-02-15 18:30:16 --> URI Class Initialized
INFO - 2024-02-15 18:30:16 --> Router Class Initialized
INFO - 2024-02-15 18:30:16 --> Output Class Initialized
INFO - 2024-02-15 18:30:16 --> Security Class Initialized
DEBUG - 2024-02-15 18:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:30:16 --> Input Class Initialized
INFO - 2024-02-15 18:30:16 --> Language Class Initialized
INFO - 2024-02-15 18:30:16 --> Loader Class Initialized
INFO - 2024-02-15 18:30:16 --> Helper loaded: url_helper
INFO - 2024-02-15 18:30:16 --> Helper loaded: file_helper
INFO - 2024-02-15 18:30:16 --> Helper loaded: form_helper
INFO - 2024-02-15 18:30:16 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:30:16 --> Controller Class Initialized
INFO - 2024-02-15 18:30:16 --> Form Validation Class Initialized
INFO - 2024-02-15 18:30:16 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:30:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:30:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:30:16 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 18:30:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:30:29 --> Config Class Initialized
INFO - 2024-02-15 18:30:29 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:30:29 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:30:29 --> Utf8 Class Initialized
INFO - 2024-02-15 18:30:29 --> URI Class Initialized
INFO - 2024-02-15 18:30:29 --> Router Class Initialized
INFO - 2024-02-15 18:30:29 --> Output Class Initialized
INFO - 2024-02-15 18:30:29 --> Security Class Initialized
DEBUG - 2024-02-15 18:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:30:29 --> Input Class Initialized
INFO - 2024-02-15 18:30:29 --> Language Class Initialized
INFO - 2024-02-15 18:30:29 --> Loader Class Initialized
INFO - 2024-02-15 18:30:29 --> Helper loaded: url_helper
INFO - 2024-02-15 18:30:29 --> Helper loaded: file_helper
INFO - 2024-02-15 18:30:29 --> Helper loaded: form_helper
INFO - 2024-02-15 18:30:29 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:30:29 --> Controller Class Initialized
INFO - 2024-02-15 18:30:29 --> Form Validation Class Initialized
INFO - 2024-02-15 18:30:29 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:30:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:30:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:30:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:30:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 18:30:29 --> Final output sent to browser
DEBUG - 2024-02-15 18:30:29 --> Total execution time: 0.0278
ERROR - 2024-02-15 18:32:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:32:48 --> Config Class Initialized
INFO - 2024-02-15 18:32:48 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:32:48 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:32:48 --> Utf8 Class Initialized
INFO - 2024-02-15 18:32:48 --> URI Class Initialized
INFO - 2024-02-15 18:32:48 --> Router Class Initialized
INFO - 2024-02-15 18:32:48 --> Output Class Initialized
INFO - 2024-02-15 18:32:48 --> Security Class Initialized
DEBUG - 2024-02-15 18:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:32:48 --> Input Class Initialized
INFO - 2024-02-15 18:32:48 --> Language Class Initialized
INFO - 2024-02-15 18:32:48 --> Loader Class Initialized
INFO - 2024-02-15 18:32:48 --> Helper loaded: url_helper
INFO - 2024-02-15 18:32:48 --> Helper loaded: file_helper
INFO - 2024-02-15 18:32:48 --> Helper loaded: form_helper
INFO - 2024-02-15 18:32:48 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:32:48 --> Controller Class Initialized
INFO - 2024-02-15 18:32:48 --> Model "LoginModel" initialized
INFO - 2024-02-15 18:32:48 --> Form Validation Class Initialized
ERROR - 2024-02-15 18:32:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:32:48 --> Config Class Initialized
INFO - 2024-02-15 18:32:48 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:32:48 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:32:48 --> Utf8 Class Initialized
INFO - 2024-02-15 18:32:48 --> URI Class Initialized
INFO - 2024-02-15 18:32:48 --> Router Class Initialized
INFO - 2024-02-15 18:32:48 --> Output Class Initialized
INFO - 2024-02-15 18:32:48 --> Security Class Initialized
DEBUG - 2024-02-15 18:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:32:48 --> Input Class Initialized
INFO - 2024-02-15 18:32:48 --> Language Class Initialized
INFO - 2024-02-15 18:32:48 --> Loader Class Initialized
INFO - 2024-02-15 18:32:48 --> Helper loaded: url_helper
INFO - 2024-02-15 18:32:48 --> Helper loaded: file_helper
INFO - 2024-02-15 18:32:48 --> Helper loaded: form_helper
INFO - 2024-02-15 18:32:48 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:32:48 --> Controller Class Initialized
INFO - 2024-02-15 18:32:48 --> Form Validation Class Initialized
INFO - 2024-02-15 18:32:48 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:32:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:32:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:32:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:32:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:32:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-15 18:32:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:32:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:32:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:32:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-15 18:32:48 --> Final output sent to browser
DEBUG - 2024-02-15 18:32:48 --> Total execution time: 0.0273
ERROR - 2024-02-15 18:35:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:35:38 --> Config Class Initialized
INFO - 2024-02-15 18:35:38 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:35:38 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:35:38 --> Utf8 Class Initialized
INFO - 2024-02-15 18:35:38 --> URI Class Initialized
INFO - 2024-02-15 18:35:38 --> Router Class Initialized
INFO - 2024-02-15 18:35:38 --> Output Class Initialized
INFO - 2024-02-15 18:35:38 --> Security Class Initialized
DEBUG - 2024-02-15 18:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:35:38 --> Input Class Initialized
INFO - 2024-02-15 18:35:38 --> Language Class Initialized
INFO - 2024-02-15 18:35:38 --> Loader Class Initialized
INFO - 2024-02-15 18:35:38 --> Helper loaded: url_helper
INFO - 2024-02-15 18:35:38 --> Helper loaded: file_helper
INFO - 2024-02-15 18:35:38 --> Helper loaded: form_helper
INFO - 2024-02-15 18:35:38 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:35:38 --> Controller Class Initialized
INFO - 2024-02-15 18:35:38 --> Form Validation Class Initialized
INFO - 2024-02-15 18:35:38 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:35:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:35:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:35:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:35:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:35:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:35:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:35:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:35:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 18:35:38 --> Final output sent to browser
DEBUG - 2024-02-15 18:35:38 --> Total execution time: 0.0395
ERROR - 2024-02-15 18:35:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:35:39 --> Config Class Initialized
INFO - 2024-02-15 18:35:39 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:35:39 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:35:39 --> Utf8 Class Initialized
INFO - 2024-02-15 18:35:39 --> URI Class Initialized
INFO - 2024-02-15 18:35:39 --> Router Class Initialized
INFO - 2024-02-15 18:35:39 --> Output Class Initialized
INFO - 2024-02-15 18:35:39 --> Security Class Initialized
DEBUG - 2024-02-15 18:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:35:39 --> Input Class Initialized
INFO - 2024-02-15 18:35:39 --> Language Class Initialized
INFO - 2024-02-15 18:35:39 --> Loader Class Initialized
INFO - 2024-02-15 18:35:39 --> Helper loaded: url_helper
INFO - 2024-02-15 18:35:39 --> Helper loaded: file_helper
INFO - 2024-02-15 18:35:39 --> Helper loaded: form_helper
INFO - 2024-02-15 18:35:39 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:35:39 --> Controller Class Initialized
INFO - 2024-02-15 18:35:39 --> Form Validation Class Initialized
INFO - 2024-02-15 18:35:39 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:35:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:35:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:35:39 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 18:35:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:35:40 --> Config Class Initialized
INFO - 2024-02-15 18:35:40 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:35:40 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:35:40 --> Utf8 Class Initialized
INFO - 2024-02-15 18:35:40 --> URI Class Initialized
INFO - 2024-02-15 18:35:40 --> Router Class Initialized
INFO - 2024-02-15 18:35:41 --> Output Class Initialized
INFO - 2024-02-15 18:35:41 --> Security Class Initialized
DEBUG - 2024-02-15 18:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:35:41 --> Input Class Initialized
INFO - 2024-02-15 18:35:41 --> Language Class Initialized
INFO - 2024-02-15 18:35:41 --> Loader Class Initialized
INFO - 2024-02-15 18:35:41 --> Helper loaded: url_helper
INFO - 2024-02-15 18:35:41 --> Helper loaded: file_helper
INFO - 2024-02-15 18:35:41 --> Helper loaded: form_helper
INFO - 2024-02-15 18:35:41 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:35:41 --> Controller Class Initialized
INFO - 2024-02-15 18:35:41 --> Form Validation Class Initialized
INFO - 2024-02-15 18:35:41 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:35:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:35:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:35:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:35:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 18:35:41 --> Final output sent to browser
DEBUG - 2024-02-15 18:35:41 --> Total execution time: 0.0242
ERROR - 2024-02-15 18:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:35:45 --> Config Class Initialized
INFO - 2024-02-15 18:35:45 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:35:45 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:35:45 --> Utf8 Class Initialized
INFO - 2024-02-15 18:35:45 --> URI Class Initialized
INFO - 2024-02-15 18:35:45 --> Router Class Initialized
INFO - 2024-02-15 18:35:45 --> Output Class Initialized
INFO - 2024-02-15 18:35:45 --> Security Class Initialized
DEBUG - 2024-02-15 18:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:35:45 --> Input Class Initialized
INFO - 2024-02-15 18:35:45 --> Language Class Initialized
INFO - 2024-02-15 18:35:45 --> Loader Class Initialized
INFO - 2024-02-15 18:35:45 --> Helper loaded: url_helper
INFO - 2024-02-15 18:35:45 --> Helper loaded: file_helper
INFO - 2024-02-15 18:35:45 --> Helper loaded: form_helper
INFO - 2024-02-15 18:35:45 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:35:45 --> Controller Class Initialized
INFO - 2024-02-15 18:35:45 --> Form Validation Class Initialized
INFO - 2024-02-15 18:35:45 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:35:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:35:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:35:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:35:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:35:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:35:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:35:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:35:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 18:35:45 --> Final output sent to browser
DEBUG - 2024-02-15 18:35:45 --> Total execution time: 0.0343
ERROR - 2024-02-15 18:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:35:45 --> Config Class Initialized
INFO - 2024-02-15 18:35:45 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:35:45 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:35:45 --> Utf8 Class Initialized
INFO - 2024-02-15 18:35:45 --> URI Class Initialized
INFO - 2024-02-15 18:35:45 --> Router Class Initialized
INFO - 2024-02-15 18:35:45 --> Output Class Initialized
INFO - 2024-02-15 18:35:45 --> Security Class Initialized
DEBUG - 2024-02-15 18:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:35:45 --> Input Class Initialized
INFO - 2024-02-15 18:35:45 --> Language Class Initialized
INFO - 2024-02-15 18:35:45 --> Loader Class Initialized
INFO - 2024-02-15 18:35:45 --> Helper loaded: url_helper
INFO - 2024-02-15 18:35:45 --> Helper loaded: file_helper
INFO - 2024-02-15 18:35:45 --> Helper loaded: form_helper
INFO - 2024-02-15 18:35:45 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:35:45 --> Controller Class Initialized
INFO - 2024-02-15 18:35:45 --> Form Validation Class Initialized
INFO - 2024-02-15 18:35:45 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:35:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:35:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:35:45 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 18:35:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:35:48 --> Config Class Initialized
INFO - 2024-02-15 18:35:48 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:35:48 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:35:48 --> Utf8 Class Initialized
INFO - 2024-02-15 18:35:48 --> URI Class Initialized
INFO - 2024-02-15 18:35:48 --> Router Class Initialized
INFO - 2024-02-15 18:35:48 --> Output Class Initialized
INFO - 2024-02-15 18:35:48 --> Security Class Initialized
DEBUG - 2024-02-15 18:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:35:48 --> Input Class Initialized
INFO - 2024-02-15 18:35:48 --> Language Class Initialized
INFO - 2024-02-15 18:35:48 --> Loader Class Initialized
INFO - 2024-02-15 18:35:48 --> Helper loaded: url_helper
INFO - 2024-02-15 18:35:48 --> Helper loaded: file_helper
INFO - 2024-02-15 18:35:48 --> Helper loaded: form_helper
INFO - 2024-02-15 18:35:48 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:35:48 --> Controller Class Initialized
INFO - 2024-02-15 18:35:48 --> Form Validation Class Initialized
INFO - 2024-02-15 18:35:48 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:35:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:35:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:35:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:35:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 18:35:48 --> Final output sent to browser
DEBUG - 2024-02-15 18:35:48 --> Total execution time: 0.0297
ERROR - 2024-02-15 18:37:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:37:20 --> Config Class Initialized
INFO - 2024-02-15 18:37:20 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:37:20 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:37:20 --> Utf8 Class Initialized
INFO - 2024-02-15 18:37:20 --> URI Class Initialized
INFO - 2024-02-15 18:37:20 --> Router Class Initialized
INFO - 2024-02-15 18:37:20 --> Output Class Initialized
INFO - 2024-02-15 18:37:20 --> Security Class Initialized
DEBUG - 2024-02-15 18:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:37:20 --> Input Class Initialized
INFO - 2024-02-15 18:37:20 --> Language Class Initialized
INFO - 2024-02-15 18:37:20 --> Loader Class Initialized
INFO - 2024-02-15 18:37:20 --> Helper loaded: url_helper
INFO - 2024-02-15 18:37:20 --> Helper loaded: file_helper
INFO - 2024-02-15 18:37:20 --> Helper loaded: form_helper
INFO - 2024-02-15 18:37:20 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:37:20 --> Controller Class Initialized
INFO - 2024-02-15 18:37:20 --> Form Validation Class Initialized
INFO - 2024-02-15 18:37:20 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:37:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:37:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:37:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:37:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:37:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:37:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:37:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:37:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 18:37:20 --> Final output sent to browser
DEBUG - 2024-02-15 18:37:20 --> Total execution time: 0.0289
ERROR - 2024-02-15 18:37:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:37:20 --> Config Class Initialized
INFO - 2024-02-15 18:37:20 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:37:20 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:37:20 --> Utf8 Class Initialized
INFO - 2024-02-15 18:37:20 --> URI Class Initialized
INFO - 2024-02-15 18:37:20 --> Router Class Initialized
INFO - 2024-02-15 18:37:20 --> Output Class Initialized
INFO - 2024-02-15 18:37:20 --> Security Class Initialized
DEBUG - 2024-02-15 18:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:37:20 --> Input Class Initialized
INFO - 2024-02-15 18:37:20 --> Language Class Initialized
INFO - 2024-02-15 18:37:20 --> Loader Class Initialized
INFO - 2024-02-15 18:37:20 --> Helper loaded: url_helper
INFO - 2024-02-15 18:37:20 --> Helper loaded: file_helper
INFO - 2024-02-15 18:37:20 --> Helper loaded: form_helper
INFO - 2024-02-15 18:37:20 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:37:20 --> Controller Class Initialized
INFO - 2024-02-15 18:37:20 --> Form Validation Class Initialized
INFO - 2024-02-15 18:37:20 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:37:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:37:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:37:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 18:37:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:37:22 --> Config Class Initialized
INFO - 2024-02-15 18:37:22 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:37:22 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:37:22 --> Utf8 Class Initialized
INFO - 2024-02-15 18:37:22 --> URI Class Initialized
INFO - 2024-02-15 18:37:22 --> Router Class Initialized
INFO - 2024-02-15 18:37:22 --> Output Class Initialized
INFO - 2024-02-15 18:37:22 --> Security Class Initialized
DEBUG - 2024-02-15 18:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:37:22 --> Input Class Initialized
INFO - 2024-02-15 18:37:22 --> Language Class Initialized
INFO - 2024-02-15 18:37:22 --> Loader Class Initialized
INFO - 2024-02-15 18:37:22 --> Helper loaded: url_helper
INFO - 2024-02-15 18:37:22 --> Helper loaded: file_helper
INFO - 2024-02-15 18:37:22 --> Helper loaded: form_helper
INFO - 2024-02-15 18:37:22 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:37:22 --> Controller Class Initialized
INFO - 2024-02-15 18:37:22 --> Form Validation Class Initialized
INFO - 2024-02-15 18:37:22 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:37:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:37:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:37:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:37:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 18:37:22 --> Final output sent to browser
DEBUG - 2024-02-15 18:37:22 --> Total execution time: 0.0219
ERROR - 2024-02-15 18:41:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:41:55 --> Config Class Initialized
INFO - 2024-02-15 18:41:55 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:41:55 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:41:55 --> Utf8 Class Initialized
INFO - 2024-02-15 18:41:55 --> URI Class Initialized
INFO - 2024-02-15 18:41:55 --> Router Class Initialized
INFO - 2024-02-15 18:41:55 --> Output Class Initialized
INFO - 2024-02-15 18:41:55 --> Security Class Initialized
DEBUG - 2024-02-15 18:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:41:55 --> Input Class Initialized
INFO - 2024-02-15 18:41:55 --> Language Class Initialized
INFO - 2024-02-15 18:41:55 --> Loader Class Initialized
INFO - 2024-02-15 18:41:55 --> Helper loaded: url_helper
INFO - 2024-02-15 18:41:55 --> Helper loaded: file_helper
INFO - 2024-02-15 18:41:55 --> Helper loaded: form_helper
INFO - 2024-02-15 18:41:55 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:41:55 --> Controller Class Initialized
INFO - 2024-02-15 18:41:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 18:41:55 --> Final output sent to browser
DEBUG - 2024-02-15 18:41:55 --> Total execution time: 0.0321
ERROR - 2024-02-15 18:43:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:43:03 --> Config Class Initialized
INFO - 2024-02-15 18:43:03 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:43:03 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:43:03 --> Utf8 Class Initialized
INFO - 2024-02-15 18:43:03 --> URI Class Initialized
INFO - 2024-02-15 18:43:03 --> Router Class Initialized
INFO - 2024-02-15 18:43:03 --> Output Class Initialized
INFO - 2024-02-15 18:43:03 --> Security Class Initialized
DEBUG - 2024-02-15 18:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:43:03 --> Input Class Initialized
INFO - 2024-02-15 18:43:03 --> Language Class Initialized
INFO - 2024-02-15 18:43:03 --> Loader Class Initialized
INFO - 2024-02-15 18:43:03 --> Helper loaded: url_helper
INFO - 2024-02-15 18:43:03 --> Helper loaded: file_helper
INFO - 2024-02-15 18:43:03 --> Helper loaded: form_helper
INFO - 2024-02-15 18:43:03 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:43:03 --> Controller Class Initialized
INFO - 2024-02-15 18:43:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 18:43:03 --> Final output sent to browser
DEBUG - 2024-02-15 18:43:03 --> Total execution time: 0.0351
ERROR - 2024-02-15 18:43:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:43:09 --> Config Class Initialized
INFO - 2024-02-15 18:43:09 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:43:09 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:43:09 --> Utf8 Class Initialized
INFO - 2024-02-15 18:43:09 --> URI Class Initialized
INFO - 2024-02-15 18:43:09 --> Router Class Initialized
INFO - 2024-02-15 18:43:09 --> Output Class Initialized
INFO - 2024-02-15 18:43:09 --> Security Class Initialized
DEBUG - 2024-02-15 18:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:43:09 --> Input Class Initialized
INFO - 2024-02-15 18:43:09 --> Language Class Initialized
INFO - 2024-02-15 18:43:09 --> Loader Class Initialized
INFO - 2024-02-15 18:43:09 --> Helper loaded: url_helper
INFO - 2024-02-15 18:43:09 --> Helper loaded: file_helper
INFO - 2024-02-15 18:43:09 --> Helper loaded: form_helper
INFO - 2024-02-15 18:43:09 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:43:09 --> Controller Class Initialized
INFO - 2024-02-15 18:43:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 18:43:09 --> Final output sent to browser
DEBUG - 2024-02-15 18:43:09 --> Total execution time: 0.0241
ERROR - 2024-02-15 18:43:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:43:09 --> Config Class Initialized
INFO - 2024-02-15 18:43:09 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:43:09 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:43:09 --> Utf8 Class Initialized
INFO - 2024-02-15 18:43:09 --> URI Class Initialized
INFO - 2024-02-15 18:43:09 --> Router Class Initialized
INFO - 2024-02-15 18:43:09 --> Output Class Initialized
INFO - 2024-02-15 18:43:09 --> Security Class Initialized
DEBUG - 2024-02-15 18:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:43:09 --> Input Class Initialized
INFO - 2024-02-15 18:43:09 --> Language Class Initialized
INFO - 2024-02-15 18:43:09 --> Loader Class Initialized
INFO - 2024-02-15 18:43:09 --> Helper loaded: url_helper
INFO - 2024-02-15 18:43:09 --> Helper loaded: file_helper
INFO - 2024-02-15 18:43:09 --> Helper loaded: form_helper
INFO - 2024-02-15 18:43:09 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:43:09 --> Controller Class Initialized
INFO - 2024-02-15 18:43:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 18:43:09 --> Final output sent to browser
DEBUG - 2024-02-15 18:43:09 --> Total execution time: 0.0307
ERROR - 2024-02-15 18:43:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:43:14 --> Config Class Initialized
INFO - 2024-02-15 18:43:14 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:43:15 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:43:15 --> Utf8 Class Initialized
INFO - 2024-02-15 18:43:15 --> URI Class Initialized
INFO - 2024-02-15 18:43:15 --> Router Class Initialized
INFO - 2024-02-15 18:43:15 --> Output Class Initialized
INFO - 2024-02-15 18:43:15 --> Security Class Initialized
DEBUG - 2024-02-15 18:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:43:15 --> Input Class Initialized
INFO - 2024-02-15 18:43:15 --> Language Class Initialized
INFO - 2024-02-15 18:43:15 --> Loader Class Initialized
INFO - 2024-02-15 18:43:15 --> Helper loaded: url_helper
INFO - 2024-02-15 18:43:15 --> Helper loaded: file_helper
INFO - 2024-02-15 18:43:15 --> Helper loaded: form_helper
INFO - 2024-02-15 18:43:15 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:43:15 --> Controller Class Initialized
INFO - 2024-02-15 18:43:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 18:43:15 --> Final output sent to browser
DEBUG - 2024-02-15 18:43:15 --> Total execution time: 0.0419
ERROR - 2024-02-15 18:43:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:43:15 --> Config Class Initialized
INFO - 2024-02-15 18:43:15 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:43:15 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:43:15 --> Utf8 Class Initialized
INFO - 2024-02-15 18:43:15 --> URI Class Initialized
INFO - 2024-02-15 18:43:15 --> Router Class Initialized
INFO - 2024-02-15 18:43:15 --> Output Class Initialized
INFO - 2024-02-15 18:43:15 --> Security Class Initialized
DEBUG - 2024-02-15 18:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:43:15 --> Input Class Initialized
INFO - 2024-02-15 18:43:15 --> Language Class Initialized
INFO - 2024-02-15 18:43:15 --> Loader Class Initialized
INFO - 2024-02-15 18:43:15 --> Helper loaded: url_helper
INFO - 2024-02-15 18:43:15 --> Helper loaded: file_helper
INFO - 2024-02-15 18:43:15 --> Helper loaded: form_helper
INFO - 2024-02-15 18:43:15 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:43:15 --> Controller Class Initialized
INFO - 2024-02-15 18:43:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 18:43:15 --> Final output sent to browser
DEBUG - 2024-02-15 18:43:15 --> Total execution time: 0.0244
ERROR - 2024-02-15 18:43:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:43:21 --> Config Class Initialized
INFO - 2024-02-15 18:43:21 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:43:21 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:43:21 --> Utf8 Class Initialized
INFO - 2024-02-15 18:43:21 --> URI Class Initialized
INFO - 2024-02-15 18:43:21 --> Router Class Initialized
INFO - 2024-02-15 18:43:21 --> Output Class Initialized
INFO - 2024-02-15 18:43:21 --> Security Class Initialized
DEBUG - 2024-02-15 18:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:43:21 --> Input Class Initialized
INFO - 2024-02-15 18:43:21 --> Language Class Initialized
INFO - 2024-02-15 18:43:21 --> Loader Class Initialized
INFO - 2024-02-15 18:43:21 --> Helper loaded: url_helper
INFO - 2024-02-15 18:43:21 --> Helper loaded: file_helper
INFO - 2024-02-15 18:43:21 --> Helper loaded: form_helper
INFO - 2024-02-15 18:43:21 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:43:21 --> Controller Class Initialized
INFO - 2024-02-15 18:43:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 18:43:21 --> Final output sent to browser
DEBUG - 2024-02-15 18:43:21 --> Total execution time: 0.0201
ERROR - 2024-02-15 18:43:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:43:22 --> Config Class Initialized
INFO - 2024-02-15 18:43:22 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:43:22 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:43:22 --> Utf8 Class Initialized
INFO - 2024-02-15 18:43:22 --> URI Class Initialized
INFO - 2024-02-15 18:43:22 --> Router Class Initialized
INFO - 2024-02-15 18:43:22 --> Output Class Initialized
INFO - 2024-02-15 18:43:22 --> Security Class Initialized
DEBUG - 2024-02-15 18:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:43:22 --> Input Class Initialized
INFO - 2024-02-15 18:43:22 --> Language Class Initialized
INFO - 2024-02-15 18:43:22 --> Loader Class Initialized
INFO - 2024-02-15 18:43:22 --> Helper loaded: url_helper
INFO - 2024-02-15 18:43:22 --> Helper loaded: file_helper
INFO - 2024-02-15 18:43:22 --> Helper loaded: form_helper
INFO - 2024-02-15 18:43:22 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:43:22 --> Controller Class Initialized
INFO - 2024-02-15 18:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 18:43:22 --> Final output sent to browser
DEBUG - 2024-02-15 18:43:22 --> Total execution time: 0.0344
ERROR - 2024-02-15 18:43:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:43:26 --> Config Class Initialized
INFO - 2024-02-15 18:43:26 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:43:26 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:43:26 --> Utf8 Class Initialized
INFO - 2024-02-15 18:43:26 --> URI Class Initialized
INFO - 2024-02-15 18:43:26 --> Router Class Initialized
INFO - 2024-02-15 18:43:26 --> Output Class Initialized
INFO - 2024-02-15 18:43:26 --> Security Class Initialized
DEBUG - 2024-02-15 18:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:43:26 --> Input Class Initialized
INFO - 2024-02-15 18:43:26 --> Language Class Initialized
INFO - 2024-02-15 18:43:26 --> Loader Class Initialized
INFO - 2024-02-15 18:43:26 --> Helper loaded: url_helper
INFO - 2024-02-15 18:43:26 --> Helper loaded: file_helper
INFO - 2024-02-15 18:43:26 --> Helper loaded: form_helper
INFO - 2024-02-15 18:43:26 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:43:26 --> Controller Class Initialized
INFO - 2024-02-15 18:43:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 18:43:26 --> Final output sent to browser
DEBUG - 2024-02-15 18:43:26 --> Total execution time: 0.0251
ERROR - 2024-02-15 18:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:43:27 --> Config Class Initialized
INFO - 2024-02-15 18:43:27 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:43:27 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:43:27 --> Utf8 Class Initialized
INFO - 2024-02-15 18:43:27 --> URI Class Initialized
INFO - 2024-02-15 18:43:27 --> Router Class Initialized
INFO - 2024-02-15 18:43:27 --> Output Class Initialized
INFO - 2024-02-15 18:43:27 --> Security Class Initialized
DEBUG - 2024-02-15 18:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:43:27 --> Input Class Initialized
INFO - 2024-02-15 18:43:27 --> Language Class Initialized
INFO - 2024-02-15 18:43:27 --> Loader Class Initialized
INFO - 2024-02-15 18:43:27 --> Helper loaded: url_helper
INFO - 2024-02-15 18:43:27 --> Helper loaded: file_helper
INFO - 2024-02-15 18:43:27 --> Helper loaded: form_helper
INFO - 2024-02-15 18:43:27 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:43:27 --> Controller Class Initialized
INFO - 2024-02-15 18:43:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 18:43:27 --> Final output sent to browser
DEBUG - 2024-02-15 18:43:27 --> Total execution time: 0.0229
ERROR - 2024-02-15 18:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:43:27 --> Config Class Initialized
INFO - 2024-02-15 18:43:27 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:43:27 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:43:27 --> Utf8 Class Initialized
INFO - 2024-02-15 18:43:27 --> URI Class Initialized
INFO - 2024-02-15 18:43:27 --> Router Class Initialized
INFO - 2024-02-15 18:43:27 --> Output Class Initialized
INFO - 2024-02-15 18:43:27 --> Security Class Initialized
DEBUG - 2024-02-15 18:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:43:27 --> Input Class Initialized
INFO - 2024-02-15 18:43:27 --> Language Class Initialized
INFO - 2024-02-15 18:43:27 --> Loader Class Initialized
INFO - 2024-02-15 18:43:27 --> Helper loaded: url_helper
INFO - 2024-02-15 18:43:27 --> Helper loaded: file_helper
INFO - 2024-02-15 18:43:27 --> Helper loaded: form_helper
INFO - 2024-02-15 18:43:27 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:43:27 --> Controller Class Initialized
INFO - 2024-02-15 18:43:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 18:43:27 --> Final output sent to browser
DEBUG - 2024-02-15 18:43:27 --> Total execution time: 0.0241
ERROR - 2024-02-15 18:43:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:43:59 --> Config Class Initialized
INFO - 2024-02-15 18:43:59 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:43:59 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:43:59 --> Utf8 Class Initialized
INFO - 2024-02-15 18:43:59 --> URI Class Initialized
INFO - 2024-02-15 18:43:59 --> Router Class Initialized
INFO - 2024-02-15 18:43:59 --> Output Class Initialized
INFO - 2024-02-15 18:43:59 --> Security Class Initialized
DEBUG - 2024-02-15 18:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:43:59 --> Input Class Initialized
INFO - 2024-02-15 18:43:59 --> Language Class Initialized
INFO - 2024-02-15 18:43:59 --> Loader Class Initialized
INFO - 2024-02-15 18:43:59 --> Helper loaded: url_helper
INFO - 2024-02-15 18:43:59 --> Helper loaded: file_helper
INFO - 2024-02-15 18:43:59 --> Helper loaded: form_helper
INFO - 2024-02-15 18:43:59 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:43:59 --> Controller Class Initialized
INFO - 2024-02-15 18:43:59 --> Form Validation Class Initialized
INFO - 2024-02-15 18:43:59 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:43:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:43:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:43:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:43:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:43:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:43:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:43:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:43:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 18:43:59 --> Final output sent to browser
DEBUG - 2024-02-15 18:43:59 --> Total execution time: 0.0381
ERROR - 2024-02-15 18:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:44:00 --> Config Class Initialized
INFO - 2024-02-15 18:44:00 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:44:00 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:44:00 --> Utf8 Class Initialized
INFO - 2024-02-15 18:44:00 --> URI Class Initialized
INFO - 2024-02-15 18:44:00 --> Router Class Initialized
INFO - 2024-02-15 18:44:00 --> Output Class Initialized
INFO - 2024-02-15 18:44:00 --> Security Class Initialized
DEBUG - 2024-02-15 18:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:44:00 --> Input Class Initialized
INFO - 2024-02-15 18:44:00 --> Language Class Initialized
INFO - 2024-02-15 18:44:00 --> Loader Class Initialized
INFO - 2024-02-15 18:44:00 --> Helper loaded: url_helper
INFO - 2024-02-15 18:44:00 --> Helper loaded: file_helper
INFO - 2024-02-15 18:44:00 --> Helper loaded: form_helper
INFO - 2024-02-15 18:44:00 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:44:00 --> Controller Class Initialized
INFO - 2024-02-15 18:44:00 --> Form Validation Class Initialized
INFO - 2024-02-15 18:44:00 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:44:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:44:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:44:00 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 18:44:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:44:03 --> Config Class Initialized
INFO - 2024-02-15 18:44:03 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:44:03 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:44:03 --> Utf8 Class Initialized
INFO - 2024-02-15 18:44:03 --> URI Class Initialized
INFO - 2024-02-15 18:44:03 --> Router Class Initialized
INFO - 2024-02-15 18:44:03 --> Output Class Initialized
INFO - 2024-02-15 18:44:03 --> Security Class Initialized
DEBUG - 2024-02-15 18:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:44:03 --> Input Class Initialized
INFO - 2024-02-15 18:44:03 --> Language Class Initialized
INFO - 2024-02-15 18:44:03 --> Loader Class Initialized
INFO - 2024-02-15 18:44:03 --> Helper loaded: url_helper
INFO - 2024-02-15 18:44:03 --> Helper loaded: file_helper
INFO - 2024-02-15 18:44:03 --> Helper loaded: form_helper
INFO - 2024-02-15 18:44:03 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:44:03 --> Controller Class Initialized
INFO - 2024-02-15 18:44:03 --> Form Validation Class Initialized
INFO - 2024-02-15 18:44:03 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:44:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:44:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:44:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:44:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 18:44:03 --> Final output sent to browser
DEBUG - 2024-02-15 18:44:03 --> Total execution time: 0.0417
ERROR - 2024-02-15 18:44:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:44:52 --> Config Class Initialized
INFO - 2024-02-15 18:44:52 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:44:52 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:44:52 --> Utf8 Class Initialized
INFO - 2024-02-15 18:44:52 --> URI Class Initialized
INFO - 2024-02-15 18:44:52 --> Router Class Initialized
INFO - 2024-02-15 18:44:52 --> Output Class Initialized
INFO - 2024-02-15 18:44:52 --> Security Class Initialized
DEBUG - 2024-02-15 18:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:44:52 --> Input Class Initialized
INFO - 2024-02-15 18:44:52 --> Language Class Initialized
INFO - 2024-02-15 18:44:52 --> Loader Class Initialized
INFO - 2024-02-15 18:44:52 --> Helper loaded: url_helper
INFO - 2024-02-15 18:44:52 --> Helper loaded: file_helper
INFO - 2024-02-15 18:44:52 --> Helper loaded: form_helper
INFO - 2024-02-15 18:44:52 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:44:52 --> Controller Class Initialized
INFO - 2024-02-15 18:44:52 --> Form Validation Class Initialized
INFO - 2024-02-15 18:44:52 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:44:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:44:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:44:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:44:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:44:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:44:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:44:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:44:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 18:44:52 --> Final output sent to browser
DEBUG - 2024-02-15 18:44:52 --> Total execution time: 0.0301
ERROR - 2024-02-15 18:44:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:44:52 --> Config Class Initialized
INFO - 2024-02-15 18:44:52 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:44:52 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:44:52 --> Utf8 Class Initialized
INFO - 2024-02-15 18:44:52 --> URI Class Initialized
INFO - 2024-02-15 18:44:52 --> Router Class Initialized
INFO - 2024-02-15 18:44:52 --> Output Class Initialized
INFO - 2024-02-15 18:44:52 --> Security Class Initialized
DEBUG - 2024-02-15 18:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:44:52 --> Input Class Initialized
INFO - 2024-02-15 18:44:52 --> Language Class Initialized
INFO - 2024-02-15 18:44:52 --> Loader Class Initialized
INFO - 2024-02-15 18:44:52 --> Helper loaded: url_helper
INFO - 2024-02-15 18:44:52 --> Helper loaded: file_helper
INFO - 2024-02-15 18:44:52 --> Helper loaded: form_helper
INFO - 2024-02-15 18:44:52 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:44:52 --> Controller Class Initialized
INFO - 2024-02-15 18:44:52 --> Form Validation Class Initialized
INFO - 2024-02-15 18:44:52 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:44:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:44:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:44:52 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 18:44:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:44:55 --> Config Class Initialized
INFO - 2024-02-15 18:44:55 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:44:55 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:44:55 --> Utf8 Class Initialized
INFO - 2024-02-15 18:44:55 --> URI Class Initialized
INFO - 2024-02-15 18:44:55 --> Router Class Initialized
INFO - 2024-02-15 18:44:55 --> Output Class Initialized
INFO - 2024-02-15 18:44:55 --> Security Class Initialized
DEBUG - 2024-02-15 18:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:44:55 --> Input Class Initialized
INFO - 2024-02-15 18:44:55 --> Language Class Initialized
INFO - 2024-02-15 18:44:55 --> Loader Class Initialized
INFO - 2024-02-15 18:44:55 --> Helper loaded: url_helper
INFO - 2024-02-15 18:44:55 --> Helper loaded: file_helper
INFO - 2024-02-15 18:44:55 --> Helper loaded: form_helper
INFO - 2024-02-15 18:44:55 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:44:55 --> Controller Class Initialized
INFO - 2024-02-15 18:44:55 --> Form Validation Class Initialized
INFO - 2024-02-15 18:44:55 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:44:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:44:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:44:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:44:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 18:44:55 --> Final output sent to browser
DEBUG - 2024-02-15 18:44:55 --> Total execution time: 0.0286
ERROR - 2024-02-15 18:48:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:48:06 --> Config Class Initialized
INFO - 2024-02-15 18:48:06 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:48:06 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:48:06 --> Utf8 Class Initialized
INFO - 2024-02-15 18:48:06 --> URI Class Initialized
INFO - 2024-02-15 18:48:06 --> Router Class Initialized
INFO - 2024-02-15 18:48:06 --> Output Class Initialized
INFO - 2024-02-15 18:48:06 --> Security Class Initialized
DEBUG - 2024-02-15 18:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:48:06 --> Input Class Initialized
INFO - 2024-02-15 18:48:06 --> Language Class Initialized
INFO - 2024-02-15 18:48:06 --> Loader Class Initialized
INFO - 2024-02-15 18:48:06 --> Helper loaded: url_helper
INFO - 2024-02-15 18:48:06 --> Helper loaded: file_helper
INFO - 2024-02-15 18:48:06 --> Helper loaded: form_helper
INFO - 2024-02-15 18:48:06 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:48:06 --> Controller Class Initialized
INFO - 2024-02-15 18:48:06 --> Form Validation Class Initialized
INFO - 2024-02-15 18:48:06 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:48:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:48:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:48:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:48:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:48:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:48:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:48:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:48:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 18:48:06 --> Final output sent to browser
DEBUG - 2024-02-15 18:48:06 --> Total execution time: 0.0318
ERROR - 2024-02-15 18:48:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:48:06 --> Config Class Initialized
INFO - 2024-02-15 18:48:06 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:48:06 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:48:06 --> Utf8 Class Initialized
INFO - 2024-02-15 18:48:06 --> URI Class Initialized
INFO - 2024-02-15 18:48:06 --> Router Class Initialized
INFO - 2024-02-15 18:48:06 --> Output Class Initialized
INFO - 2024-02-15 18:48:06 --> Security Class Initialized
DEBUG - 2024-02-15 18:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:48:06 --> Input Class Initialized
INFO - 2024-02-15 18:48:06 --> Language Class Initialized
INFO - 2024-02-15 18:48:06 --> Loader Class Initialized
INFO - 2024-02-15 18:48:06 --> Helper loaded: url_helper
INFO - 2024-02-15 18:48:06 --> Helper loaded: file_helper
INFO - 2024-02-15 18:48:06 --> Helper loaded: form_helper
INFO - 2024-02-15 18:48:06 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:48:06 --> Controller Class Initialized
INFO - 2024-02-15 18:48:06 --> Form Validation Class Initialized
INFO - 2024-02-15 18:48:06 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:48:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:48:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:48:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 18:48:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:48:08 --> Config Class Initialized
INFO - 2024-02-15 18:48:08 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:48:08 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:48:08 --> Utf8 Class Initialized
INFO - 2024-02-15 18:48:08 --> URI Class Initialized
INFO - 2024-02-15 18:48:08 --> Router Class Initialized
INFO - 2024-02-15 18:48:08 --> Output Class Initialized
INFO - 2024-02-15 18:48:08 --> Security Class Initialized
DEBUG - 2024-02-15 18:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:48:08 --> Input Class Initialized
INFO - 2024-02-15 18:48:08 --> Language Class Initialized
INFO - 2024-02-15 18:48:08 --> Loader Class Initialized
INFO - 2024-02-15 18:48:08 --> Helper loaded: url_helper
INFO - 2024-02-15 18:48:08 --> Helper loaded: file_helper
INFO - 2024-02-15 18:48:08 --> Helper loaded: form_helper
INFO - 2024-02-15 18:48:08 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:48:08 --> Controller Class Initialized
INFO - 2024-02-15 18:48:08 --> Form Validation Class Initialized
INFO - 2024-02-15 18:48:08 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:48:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:48:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:48:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:48:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 18:48:08 --> Final output sent to browser
DEBUG - 2024-02-15 18:48:08 --> Total execution time: 0.0356
ERROR - 2024-02-15 18:49:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:49:21 --> Config Class Initialized
INFO - 2024-02-15 18:49:21 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:49:21 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:49:21 --> Utf8 Class Initialized
INFO - 2024-02-15 18:49:21 --> URI Class Initialized
INFO - 2024-02-15 18:49:21 --> Router Class Initialized
INFO - 2024-02-15 18:49:21 --> Output Class Initialized
INFO - 2024-02-15 18:49:21 --> Security Class Initialized
DEBUG - 2024-02-15 18:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:49:21 --> Input Class Initialized
INFO - 2024-02-15 18:49:21 --> Language Class Initialized
INFO - 2024-02-15 18:49:21 --> Loader Class Initialized
INFO - 2024-02-15 18:49:21 --> Helper loaded: url_helper
INFO - 2024-02-15 18:49:21 --> Helper loaded: file_helper
INFO - 2024-02-15 18:49:21 --> Helper loaded: form_helper
INFO - 2024-02-15 18:49:21 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:49:21 --> Controller Class Initialized
INFO - 2024-02-15 18:49:21 --> Form Validation Class Initialized
INFO - 2024-02-15 18:49:21 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:49:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:49:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:49:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:49:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:49:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:49:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:49:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:49:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 18:49:21 --> Final output sent to browser
DEBUG - 2024-02-15 18:49:21 --> Total execution time: 0.0286
ERROR - 2024-02-15 18:49:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:49:22 --> Config Class Initialized
INFO - 2024-02-15 18:49:22 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:49:22 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:49:22 --> Utf8 Class Initialized
INFO - 2024-02-15 18:49:22 --> URI Class Initialized
INFO - 2024-02-15 18:49:22 --> Router Class Initialized
INFO - 2024-02-15 18:49:22 --> Output Class Initialized
INFO - 2024-02-15 18:49:22 --> Security Class Initialized
DEBUG - 2024-02-15 18:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:49:22 --> Input Class Initialized
INFO - 2024-02-15 18:49:22 --> Language Class Initialized
INFO - 2024-02-15 18:49:22 --> Loader Class Initialized
INFO - 2024-02-15 18:49:22 --> Helper loaded: url_helper
INFO - 2024-02-15 18:49:22 --> Helper loaded: file_helper
INFO - 2024-02-15 18:49:22 --> Helper loaded: form_helper
INFO - 2024-02-15 18:49:22 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:49:22 --> Controller Class Initialized
INFO - 2024-02-15 18:49:22 --> Form Validation Class Initialized
INFO - 2024-02-15 18:49:22 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:49:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:49:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:49:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:49:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:49:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:49:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:49:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:49:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 18:49:22 --> Final output sent to browser
DEBUG - 2024-02-15 18:49:22 --> Total execution time: 0.0238
ERROR - 2024-02-15 18:49:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:49:22 --> Config Class Initialized
INFO - 2024-02-15 18:49:22 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:49:22 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:49:22 --> Utf8 Class Initialized
INFO - 2024-02-15 18:49:22 --> URI Class Initialized
INFO - 2024-02-15 18:49:22 --> Router Class Initialized
INFO - 2024-02-15 18:49:22 --> Output Class Initialized
INFO - 2024-02-15 18:49:22 --> Security Class Initialized
DEBUG - 2024-02-15 18:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:49:22 --> Input Class Initialized
INFO - 2024-02-15 18:49:22 --> Language Class Initialized
INFO - 2024-02-15 18:49:22 --> Loader Class Initialized
INFO - 2024-02-15 18:49:22 --> Helper loaded: url_helper
INFO - 2024-02-15 18:49:22 --> Helper loaded: file_helper
INFO - 2024-02-15 18:49:22 --> Helper loaded: form_helper
INFO - 2024-02-15 18:49:22 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:49:23 --> Controller Class Initialized
INFO - 2024-02-15 18:49:23 --> Form Validation Class Initialized
INFO - 2024-02-15 18:49:23 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:49:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:49:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:49:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 18:49:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:49:25 --> Config Class Initialized
INFO - 2024-02-15 18:49:25 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:49:25 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:49:25 --> Utf8 Class Initialized
INFO - 2024-02-15 18:49:25 --> URI Class Initialized
INFO - 2024-02-15 18:49:25 --> Router Class Initialized
INFO - 2024-02-15 18:49:25 --> Output Class Initialized
INFO - 2024-02-15 18:49:25 --> Security Class Initialized
DEBUG - 2024-02-15 18:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:49:25 --> Input Class Initialized
INFO - 2024-02-15 18:49:25 --> Language Class Initialized
INFO - 2024-02-15 18:49:25 --> Loader Class Initialized
INFO - 2024-02-15 18:49:25 --> Helper loaded: url_helper
INFO - 2024-02-15 18:49:25 --> Helper loaded: file_helper
INFO - 2024-02-15 18:49:25 --> Helper loaded: form_helper
INFO - 2024-02-15 18:49:25 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:49:25 --> Controller Class Initialized
INFO - 2024-02-15 18:49:25 --> Form Validation Class Initialized
INFO - 2024-02-15 18:49:25 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:49:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:49:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:49:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:49:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 18:49:25 --> Final output sent to browser
DEBUG - 2024-02-15 18:49:25 --> Total execution time: 0.0368
ERROR - 2024-02-15 18:50:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:50:23 --> Config Class Initialized
INFO - 2024-02-15 18:50:23 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:50:23 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:50:23 --> Utf8 Class Initialized
INFO - 2024-02-15 18:50:23 --> URI Class Initialized
INFO - 2024-02-15 18:50:23 --> Router Class Initialized
INFO - 2024-02-15 18:50:23 --> Output Class Initialized
INFO - 2024-02-15 18:50:23 --> Security Class Initialized
DEBUG - 2024-02-15 18:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:50:23 --> Input Class Initialized
INFO - 2024-02-15 18:50:23 --> Language Class Initialized
INFO - 2024-02-15 18:50:23 --> Loader Class Initialized
INFO - 2024-02-15 18:50:23 --> Helper loaded: url_helper
INFO - 2024-02-15 18:50:23 --> Helper loaded: file_helper
INFO - 2024-02-15 18:50:23 --> Helper loaded: form_helper
INFO - 2024-02-15 18:50:23 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:50:23 --> Controller Class Initialized
INFO - 2024-02-15 18:50:23 --> Form Validation Class Initialized
INFO - 2024-02-15 18:50:23 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:50:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:50:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:50:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:50:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 18:50:23 --> Final output sent to browser
DEBUG - 2024-02-15 18:50:23 --> Total execution time: 0.0445
ERROR - 2024-02-15 18:53:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:53:06 --> Config Class Initialized
INFO - 2024-02-15 18:53:06 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:53:06 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:53:06 --> Utf8 Class Initialized
INFO - 2024-02-15 18:53:06 --> URI Class Initialized
INFO - 2024-02-15 18:53:06 --> Router Class Initialized
INFO - 2024-02-15 18:53:06 --> Output Class Initialized
INFO - 2024-02-15 18:53:06 --> Security Class Initialized
DEBUG - 2024-02-15 18:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:53:06 --> Input Class Initialized
INFO - 2024-02-15 18:53:06 --> Language Class Initialized
INFO - 2024-02-15 18:53:06 --> Loader Class Initialized
INFO - 2024-02-15 18:53:06 --> Helper loaded: url_helper
INFO - 2024-02-15 18:53:06 --> Helper loaded: file_helper
INFO - 2024-02-15 18:53:06 --> Helper loaded: form_helper
INFO - 2024-02-15 18:53:06 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:53:06 --> Controller Class Initialized
INFO - 2024-02-15 18:53:06 --> Form Validation Class Initialized
INFO - 2024-02-15 18:53:06 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:53:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:53:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:53:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:53:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:53:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:53:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:53:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:53:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 18:53:06 --> Final output sent to browser
DEBUG - 2024-02-15 18:53:06 --> Total execution time: 0.0287
ERROR - 2024-02-15 18:53:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:53:06 --> Config Class Initialized
INFO - 2024-02-15 18:53:06 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:53:06 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:53:06 --> Utf8 Class Initialized
INFO - 2024-02-15 18:53:06 --> URI Class Initialized
INFO - 2024-02-15 18:53:06 --> Router Class Initialized
INFO - 2024-02-15 18:53:06 --> Output Class Initialized
INFO - 2024-02-15 18:53:06 --> Security Class Initialized
DEBUG - 2024-02-15 18:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:53:06 --> Input Class Initialized
INFO - 2024-02-15 18:53:06 --> Language Class Initialized
INFO - 2024-02-15 18:53:06 --> Loader Class Initialized
INFO - 2024-02-15 18:53:06 --> Helper loaded: url_helper
INFO - 2024-02-15 18:53:06 --> Helper loaded: file_helper
INFO - 2024-02-15 18:53:06 --> Helper loaded: form_helper
INFO - 2024-02-15 18:53:06 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:53:06 --> Controller Class Initialized
INFO - 2024-02-15 18:53:06 --> Form Validation Class Initialized
INFO - 2024-02-15 18:53:06 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:53:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:53:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:53:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 18:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:53:44 --> Config Class Initialized
INFO - 2024-02-15 18:53:44 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:53:44 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:53:44 --> Utf8 Class Initialized
INFO - 2024-02-15 18:53:44 --> URI Class Initialized
INFO - 2024-02-15 18:53:44 --> Router Class Initialized
INFO - 2024-02-15 18:53:44 --> Output Class Initialized
INFO - 2024-02-15 18:53:44 --> Security Class Initialized
DEBUG - 2024-02-15 18:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:53:44 --> Input Class Initialized
INFO - 2024-02-15 18:53:44 --> Language Class Initialized
INFO - 2024-02-15 18:53:44 --> Loader Class Initialized
INFO - 2024-02-15 18:53:44 --> Helper loaded: url_helper
INFO - 2024-02-15 18:53:44 --> Helper loaded: file_helper
INFO - 2024-02-15 18:53:44 --> Helper loaded: form_helper
INFO - 2024-02-15 18:53:44 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:53:44 --> Controller Class Initialized
INFO - 2024-02-15 18:53:44 --> Form Validation Class Initialized
INFO - 2024-02-15 18:53:44 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:53:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:53:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:53:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:53:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:53:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:53:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:53:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:53:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 18:53:44 --> Final output sent to browser
DEBUG - 2024-02-15 18:53:44 --> Total execution time: 0.0279
ERROR - 2024-02-15 18:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:53:44 --> Config Class Initialized
INFO - 2024-02-15 18:53:44 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:53:44 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:53:44 --> Utf8 Class Initialized
INFO - 2024-02-15 18:53:44 --> URI Class Initialized
INFO - 2024-02-15 18:53:44 --> Router Class Initialized
INFO - 2024-02-15 18:53:44 --> Output Class Initialized
INFO - 2024-02-15 18:53:44 --> Security Class Initialized
DEBUG - 2024-02-15 18:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:53:44 --> Input Class Initialized
INFO - 2024-02-15 18:53:44 --> Language Class Initialized
INFO - 2024-02-15 18:53:44 --> Loader Class Initialized
INFO - 2024-02-15 18:53:44 --> Helper loaded: url_helper
INFO - 2024-02-15 18:53:44 --> Helper loaded: file_helper
INFO - 2024-02-15 18:53:44 --> Helper loaded: form_helper
INFO - 2024-02-15 18:53:44 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:53:44 --> Controller Class Initialized
INFO - 2024-02-15 18:53:44 --> Form Validation Class Initialized
INFO - 2024-02-15 18:53:44 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:53:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:53:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:53:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 18:53:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:53:48 --> Config Class Initialized
INFO - 2024-02-15 18:53:48 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:53:48 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:53:48 --> Utf8 Class Initialized
INFO - 2024-02-15 18:53:48 --> URI Class Initialized
INFO - 2024-02-15 18:53:48 --> Router Class Initialized
INFO - 2024-02-15 18:53:48 --> Output Class Initialized
INFO - 2024-02-15 18:53:48 --> Security Class Initialized
DEBUG - 2024-02-15 18:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:53:48 --> Input Class Initialized
INFO - 2024-02-15 18:53:48 --> Language Class Initialized
INFO - 2024-02-15 18:53:48 --> Loader Class Initialized
INFO - 2024-02-15 18:53:48 --> Helper loaded: url_helper
INFO - 2024-02-15 18:53:48 --> Helper loaded: file_helper
INFO - 2024-02-15 18:53:48 --> Helper loaded: form_helper
INFO - 2024-02-15 18:53:48 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:53:48 --> Controller Class Initialized
INFO - 2024-02-15 18:53:48 --> Form Validation Class Initialized
INFO - 2024-02-15 18:53:48 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:53:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:53:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:53:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:53:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 18:53:48 --> Final output sent to browser
DEBUG - 2024-02-15 18:53:48 --> Total execution time: 0.0395
ERROR - 2024-02-15 18:57:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:57:00 --> Config Class Initialized
INFO - 2024-02-15 18:57:00 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:57:00 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:57:00 --> Utf8 Class Initialized
INFO - 2024-02-15 18:57:00 --> URI Class Initialized
INFO - 2024-02-15 18:57:00 --> Router Class Initialized
INFO - 2024-02-15 18:57:00 --> Output Class Initialized
INFO - 2024-02-15 18:57:00 --> Security Class Initialized
DEBUG - 2024-02-15 18:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:57:00 --> Input Class Initialized
INFO - 2024-02-15 18:57:00 --> Language Class Initialized
INFO - 2024-02-15 18:57:00 --> Loader Class Initialized
INFO - 2024-02-15 18:57:00 --> Helper loaded: url_helper
INFO - 2024-02-15 18:57:00 --> Helper loaded: file_helper
INFO - 2024-02-15 18:57:00 --> Helper loaded: form_helper
INFO - 2024-02-15 18:57:00 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:57:00 --> Controller Class Initialized
INFO - 2024-02-15 18:57:00 --> Form Validation Class Initialized
INFO - 2024-02-15 18:57:00 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:57:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:57:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:57:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:57:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 18:57:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 18:57:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 18:57:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 18:57:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 18:57:00 --> Final output sent to browser
DEBUG - 2024-02-15 18:57:00 --> Total execution time: 0.0358
ERROR - 2024-02-15 18:57:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:57:01 --> Config Class Initialized
INFO - 2024-02-15 18:57:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:57:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:57:01 --> Utf8 Class Initialized
INFO - 2024-02-15 18:57:01 --> URI Class Initialized
INFO - 2024-02-15 18:57:01 --> Router Class Initialized
INFO - 2024-02-15 18:57:01 --> Output Class Initialized
INFO - 2024-02-15 18:57:01 --> Security Class Initialized
DEBUG - 2024-02-15 18:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:57:01 --> Input Class Initialized
INFO - 2024-02-15 18:57:01 --> Language Class Initialized
INFO - 2024-02-15 18:57:01 --> Loader Class Initialized
INFO - 2024-02-15 18:57:01 --> Helper loaded: url_helper
INFO - 2024-02-15 18:57:01 --> Helper loaded: file_helper
INFO - 2024-02-15 18:57:01 --> Helper loaded: form_helper
INFO - 2024-02-15 18:57:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:57:01 --> Controller Class Initialized
INFO - 2024-02-15 18:57:01 --> Form Validation Class Initialized
INFO - 2024-02-15 18:57:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:57:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:57:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:57:01 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 18:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 18:57:04 --> Config Class Initialized
INFO - 2024-02-15 18:57:04 --> Hooks Class Initialized
DEBUG - 2024-02-15 18:57:04 --> UTF-8 Support Enabled
INFO - 2024-02-15 18:57:04 --> Utf8 Class Initialized
INFO - 2024-02-15 18:57:04 --> URI Class Initialized
INFO - 2024-02-15 18:57:04 --> Router Class Initialized
INFO - 2024-02-15 18:57:04 --> Output Class Initialized
INFO - 2024-02-15 18:57:04 --> Security Class Initialized
DEBUG - 2024-02-15 18:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 18:57:04 --> Input Class Initialized
INFO - 2024-02-15 18:57:04 --> Language Class Initialized
INFO - 2024-02-15 18:57:04 --> Loader Class Initialized
INFO - 2024-02-15 18:57:04 --> Helper loaded: url_helper
INFO - 2024-02-15 18:57:04 --> Helper loaded: file_helper
INFO - 2024-02-15 18:57:04 --> Helper loaded: form_helper
INFO - 2024-02-15 18:57:04 --> Database Driver Class Initialized
DEBUG - 2024-02-15 18:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 18:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 18:57:04 --> Controller Class Initialized
INFO - 2024-02-15 18:57:04 --> Form Validation Class Initialized
INFO - 2024-02-15 18:57:04 --> Model "MasterModel" initialized
INFO - 2024-02-15 18:57:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 18:57:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 18:57:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 18:57:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 18:57:04 --> Final output sent to browser
DEBUG - 2024-02-15 18:57:04 --> Total execution time: 0.0349
ERROR - 2024-02-15 19:01:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:01:43 --> Config Class Initialized
INFO - 2024-02-15 19:01:43 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:01:43 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:01:43 --> Utf8 Class Initialized
INFO - 2024-02-15 19:01:43 --> URI Class Initialized
INFO - 2024-02-15 19:01:43 --> Router Class Initialized
INFO - 2024-02-15 19:01:43 --> Output Class Initialized
INFO - 2024-02-15 19:01:43 --> Security Class Initialized
DEBUG - 2024-02-15 19:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:01:43 --> Input Class Initialized
INFO - 2024-02-15 19:01:43 --> Language Class Initialized
INFO - 2024-02-15 19:01:43 --> Loader Class Initialized
INFO - 2024-02-15 19:01:43 --> Helper loaded: url_helper
INFO - 2024-02-15 19:01:43 --> Helper loaded: file_helper
INFO - 2024-02-15 19:01:43 --> Helper loaded: form_helper
INFO - 2024-02-15 19:01:43 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:01:43 --> Controller Class Initialized
INFO - 2024-02-15 19:01:43 --> Form Validation Class Initialized
INFO - 2024-02-15 19:01:43 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:01:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:01:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:01:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:01:43 --> Final output sent to browser
DEBUG - 2024-02-15 19:01:43 --> Total execution time: 0.0360
ERROR - 2024-02-15 19:01:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:01:43 --> Config Class Initialized
INFO - 2024-02-15 19:01:43 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:01:43 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:01:43 --> Utf8 Class Initialized
INFO - 2024-02-15 19:01:43 --> URI Class Initialized
INFO - 2024-02-15 19:01:43 --> Router Class Initialized
INFO - 2024-02-15 19:01:43 --> Output Class Initialized
INFO - 2024-02-15 19:01:43 --> Security Class Initialized
DEBUG - 2024-02-15 19:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:01:43 --> Input Class Initialized
INFO - 2024-02-15 19:01:43 --> Language Class Initialized
INFO - 2024-02-15 19:01:43 --> Loader Class Initialized
INFO - 2024-02-15 19:01:43 --> Helper loaded: url_helper
INFO - 2024-02-15 19:01:43 --> Helper loaded: file_helper
INFO - 2024-02-15 19:01:43 --> Helper loaded: form_helper
INFO - 2024-02-15 19:01:43 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:01:43 --> Controller Class Initialized
INFO - 2024-02-15 19:01:43 --> Form Validation Class Initialized
INFO - 2024-02-15 19:01:43 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:01:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:01:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:01:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:01:43 --> Final output sent to browser
DEBUG - 2024-02-15 19:01:43 --> Total execution time: 0.0301
ERROR - 2024-02-15 19:01:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:01:43 --> Config Class Initialized
INFO - 2024-02-15 19:01:43 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:01:43 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:01:43 --> Utf8 Class Initialized
INFO - 2024-02-15 19:01:43 --> URI Class Initialized
INFO - 2024-02-15 19:01:43 --> Router Class Initialized
INFO - 2024-02-15 19:01:43 --> Output Class Initialized
INFO - 2024-02-15 19:01:43 --> Security Class Initialized
DEBUG - 2024-02-15 19:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:01:43 --> Input Class Initialized
INFO - 2024-02-15 19:01:43 --> Language Class Initialized
INFO - 2024-02-15 19:01:43 --> Loader Class Initialized
INFO - 2024-02-15 19:01:43 --> Helper loaded: url_helper
INFO - 2024-02-15 19:01:43 --> Helper loaded: file_helper
INFO - 2024-02-15 19:01:43 --> Helper loaded: form_helper
INFO - 2024-02-15 19:01:43 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:01:43 --> Controller Class Initialized
ERROR - 2024-02-15 19:01:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:01:43 --> Config Class Initialized
INFO - 2024-02-15 19:01:43 --> Hooks Class Initialized
INFO - 2024-02-15 19:01:43 --> Form Validation Class Initialized
DEBUG - 2024-02-15 19:01:43 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:01:43 --> Utf8 Class Initialized
INFO - 2024-02-15 19:01:43 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:01:43 --> URI Class Initialized
INFO - 2024-02-15 19:01:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:01:43 --> Router Class Initialized
INFO - 2024-02-15 19:01:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:01:43 --> Output Class Initialized
INFO - 2024-02-15 19:01:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:01:43 --> Security Class Initialized
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
DEBUG - 2024-02-15 19:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:01:43 --> Input Class Initialized
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:01:43 --> Language Class Initialized
INFO - 2024-02-15 19:01:43 --> Final output sent to browser
DEBUG - 2024-02-15 19:01:43 --> Total execution time: 0.0305
INFO - 2024-02-15 19:01:43 --> Loader Class Initialized
INFO - 2024-02-15 19:01:43 --> Helper loaded: url_helper
INFO - 2024-02-15 19:01:43 --> Helper loaded: file_helper
INFO - 2024-02-15 19:01:43 --> Helper loaded: form_helper
INFO - 2024-02-15 19:01:43 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:01:43 --> Controller Class Initialized
INFO - 2024-02-15 19:01:43 --> Form Validation Class Initialized
INFO - 2024-02-15 19:01:43 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:01:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:01:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:01:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:01:43 --> Final output sent to browser
DEBUG - 2024-02-15 19:01:43 --> Total execution time: 0.0263
ERROR - 2024-02-15 19:01:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:01:43 --> Config Class Initialized
INFO - 2024-02-15 19:01:43 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:01:43 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:01:43 --> Utf8 Class Initialized
INFO - 2024-02-15 19:01:43 --> URI Class Initialized
INFO - 2024-02-15 19:01:43 --> Router Class Initialized
INFO - 2024-02-15 19:01:43 --> Output Class Initialized
INFO - 2024-02-15 19:01:43 --> Security Class Initialized
DEBUG - 2024-02-15 19:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:01:43 --> Input Class Initialized
INFO - 2024-02-15 19:01:43 --> Language Class Initialized
INFO - 2024-02-15 19:01:43 --> Loader Class Initialized
INFO - 2024-02-15 19:01:43 --> Helper loaded: url_helper
INFO - 2024-02-15 19:01:43 --> Helper loaded: file_helper
INFO - 2024-02-15 19:01:43 --> Helper loaded: form_helper
INFO - 2024-02-15 19:01:43 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:01:43 --> Controller Class Initialized
INFO - 2024-02-15 19:01:43 --> Form Validation Class Initialized
INFO - 2024-02-15 19:01:43 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:01:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:01:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:01:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:01:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:01:43 --> Final output sent to browser
DEBUG - 2024-02-15 19:01:43 --> Total execution time: 0.0341
ERROR - 2024-02-15 19:01:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:01:44 --> Config Class Initialized
INFO - 2024-02-15 19:01:44 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:01:44 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:01:44 --> Utf8 Class Initialized
INFO - 2024-02-15 19:01:44 --> URI Class Initialized
INFO - 2024-02-15 19:01:44 --> Router Class Initialized
INFO - 2024-02-15 19:01:44 --> Output Class Initialized
INFO - 2024-02-15 19:01:44 --> Security Class Initialized
DEBUG - 2024-02-15 19:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:01:44 --> Input Class Initialized
INFO - 2024-02-15 19:01:44 --> Language Class Initialized
INFO - 2024-02-15 19:01:44 --> Loader Class Initialized
INFO - 2024-02-15 19:01:44 --> Helper loaded: url_helper
INFO - 2024-02-15 19:01:44 --> Helper loaded: file_helper
INFO - 2024-02-15 19:01:44 --> Helper loaded: form_helper
INFO - 2024-02-15 19:01:44 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:01:44 --> Controller Class Initialized
INFO - 2024-02-15 19:01:44 --> Form Validation Class Initialized
INFO - 2024-02-15 19:01:44 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:01:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:01:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:01:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:01:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:01:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:01:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:01:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:01:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:01:44 --> Final output sent to browser
DEBUG - 2024-02-15 19:01:44 --> Total execution time: 0.0365
ERROR - 2024-02-15 19:01:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:01:44 --> Config Class Initialized
INFO - 2024-02-15 19:01:44 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:01:44 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:01:44 --> Utf8 Class Initialized
INFO - 2024-02-15 19:01:44 --> URI Class Initialized
INFO - 2024-02-15 19:01:44 --> Router Class Initialized
INFO - 2024-02-15 19:01:44 --> Output Class Initialized
INFO - 2024-02-15 19:01:44 --> Security Class Initialized
DEBUG - 2024-02-15 19:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:01:44 --> Input Class Initialized
INFO - 2024-02-15 19:01:44 --> Language Class Initialized
INFO - 2024-02-15 19:01:44 --> Loader Class Initialized
INFO - 2024-02-15 19:01:44 --> Helper loaded: url_helper
INFO - 2024-02-15 19:01:44 --> Helper loaded: file_helper
INFO - 2024-02-15 19:01:44 --> Helper loaded: form_helper
INFO - 2024-02-15 19:01:44 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:01:44 --> Controller Class Initialized
INFO - 2024-02-15 19:01:44 --> Form Validation Class Initialized
INFO - 2024-02-15 19:01:44 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:01:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:01:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:01:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:01:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:01:44 --> Config Class Initialized
INFO - 2024-02-15 19:01:44 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:01:44 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:01:44 --> Utf8 Class Initialized
INFO - 2024-02-15 19:01:44 --> URI Class Initialized
INFO - 2024-02-15 19:01:44 --> Router Class Initialized
INFO - 2024-02-15 19:01:44 --> Output Class Initialized
INFO - 2024-02-15 19:01:44 --> Security Class Initialized
DEBUG - 2024-02-15 19:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:01:44 --> Input Class Initialized
INFO - 2024-02-15 19:01:44 --> Language Class Initialized
INFO - 2024-02-15 19:01:44 --> Loader Class Initialized
INFO - 2024-02-15 19:01:44 --> Helper loaded: url_helper
INFO - 2024-02-15 19:01:44 --> Helper loaded: file_helper
INFO - 2024-02-15 19:01:44 --> Helper loaded: form_helper
INFO - 2024-02-15 19:01:44 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:01:44 --> Controller Class Initialized
INFO - 2024-02-15 19:01:44 --> Form Validation Class Initialized
INFO - 2024-02-15 19:01:44 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:01:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:01:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:01:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:01:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:01:46 --> Config Class Initialized
INFO - 2024-02-15 19:01:46 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:01:46 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:01:46 --> Utf8 Class Initialized
INFO - 2024-02-15 19:01:46 --> URI Class Initialized
INFO - 2024-02-15 19:01:46 --> Router Class Initialized
INFO - 2024-02-15 19:01:46 --> Output Class Initialized
INFO - 2024-02-15 19:01:46 --> Security Class Initialized
DEBUG - 2024-02-15 19:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:01:46 --> Input Class Initialized
INFO - 2024-02-15 19:01:46 --> Language Class Initialized
INFO - 2024-02-15 19:01:46 --> Loader Class Initialized
INFO - 2024-02-15 19:01:46 --> Helper loaded: url_helper
INFO - 2024-02-15 19:01:46 --> Helper loaded: file_helper
INFO - 2024-02-15 19:01:46 --> Helper loaded: form_helper
INFO - 2024-02-15 19:01:46 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:01:46 --> Controller Class Initialized
INFO - 2024-02-15 19:01:46 --> Form Validation Class Initialized
INFO - 2024-02-15 19:01:46 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:01:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:01:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:01:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:01:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 19:01:46 --> Final output sent to browser
DEBUG - 2024-02-15 19:01:46 --> Total execution time: 0.0395
ERROR - 2024-02-15 19:03:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:03:55 --> Config Class Initialized
INFO - 2024-02-15 19:03:55 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:03:55 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:03:55 --> Utf8 Class Initialized
INFO - 2024-02-15 19:03:55 --> URI Class Initialized
INFO - 2024-02-15 19:03:55 --> Router Class Initialized
INFO - 2024-02-15 19:03:55 --> Output Class Initialized
INFO - 2024-02-15 19:03:55 --> Security Class Initialized
DEBUG - 2024-02-15 19:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:03:55 --> Input Class Initialized
INFO - 2024-02-15 19:03:55 --> Language Class Initialized
INFO - 2024-02-15 19:03:55 --> Loader Class Initialized
INFO - 2024-02-15 19:03:55 --> Helper loaded: url_helper
INFO - 2024-02-15 19:03:55 --> Helper loaded: file_helper
INFO - 2024-02-15 19:03:55 --> Helper loaded: form_helper
INFO - 2024-02-15 19:03:55 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:03:55 --> Controller Class Initialized
INFO - 2024-02-15 19:03:55 --> Form Validation Class Initialized
INFO - 2024-02-15 19:03:55 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:03:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:03:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:03:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:03:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:03:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:03:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:03:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:03:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:03:55 --> Final output sent to browser
DEBUG - 2024-02-15 19:03:55 --> Total execution time: 0.0352
ERROR - 2024-02-15 19:03:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:03:56 --> Config Class Initialized
INFO - 2024-02-15 19:03:56 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:03:56 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:03:56 --> Utf8 Class Initialized
INFO - 2024-02-15 19:03:56 --> URI Class Initialized
INFO - 2024-02-15 19:03:56 --> Router Class Initialized
INFO - 2024-02-15 19:03:56 --> Output Class Initialized
INFO - 2024-02-15 19:03:56 --> Security Class Initialized
DEBUG - 2024-02-15 19:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:03:56 --> Input Class Initialized
INFO - 2024-02-15 19:03:56 --> Language Class Initialized
INFO - 2024-02-15 19:03:56 --> Loader Class Initialized
INFO - 2024-02-15 19:03:56 --> Helper loaded: url_helper
INFO - 2024-02-15 19:03:56 --> Helper loaded: file_helper
INFO - 2024-02-15 19:03:56 --> Helper loaded: form_helper
INFO - 2024-02-15 19:03:56 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:03:56 --> Controller Class Initialized
INFO - 2024-02-15 19:03:56 --> Form Validation Class Initialized
INFO - 2024-02-15 19:03:56 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:03:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:03:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:03:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:03:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:03:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:03:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:03:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:03:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:03:56 --> Final output sent to browser
DEBUG - 2024-02-15 19:03:56 --> Total execution time: 0.0278
ERROR - 2024-02-15 19:03:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:03:58 --> Config Class Initialized
INFO - 2024-02-15 19:03:58 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:03:58 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:03:58 --> Utf8 Class Initialized
INFO - 2024-02-15 19:03:58 --> URI Class Initialized
INFO - 2024-02-15 19:03:58 --> Router Class Initialized
INFO - 2024-02-15 19:03:58 --> Output Class Initialized
INFO - 2024-02-15 19:03:58 --> Security Class Initialized
DEBUG - 2024-02-15 19:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:03:58 --> Input Class Initialized
INFO - 2024-02-15 19:03:58 --> Language Class Initialized
INFO - 2024-02-15 19:03:58 --> Loader Class Initialized
INFO - 2024-02-15 19:03:58 --> Helper loaded: url_helper
INFO - 2024-02-15 19:03:58 --> Helper loaded: file_helper
INFO - 2024-02-15 19:03:58 --> Helper loaded: form_helper
INFO - 2024-02-15 19:03:58 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:03:58 --> Controller Class Initialized
INFO - 2024-02-15 19:03:58 --> Form Validation Class Initialized
INFO - 2024-02-15 19:03:58 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:03:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:03:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:03:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:03:59 --> Config Class Initialized
INFO - 2024-02-15 19:03:59 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:03:59 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:03:59 --> Utf8 Class Initialized
INFO - 2024-02-15 19:03:59 --> URI Class Initialized
INFO - 2024-02-15 19:03:59 --> Router Class Initialized
INFO - 2024-02-15 19:03:59 --> Output Class Initialized
INFO - 2024-02-15 19:03:59 --> Security Class Initialized
DEBUG - 2024-02-15 19:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:03:59 --> Input Class Initialized
INFO - 2024-02-15 19:03:59 --> Language Class Initialized
INFO - 2024-02-15 19:03:59 --> Loader Class Initialized
INFO - 2024-02-15 19:03:59 --> Helper loaded: url_helper
INFO - 2024-02-15 19:03:59 --> Helper loaded: file_helper
INFO - 2024-02-15 19:03:59 --> Helper loaded: form_helper
INFO - 2024-02-15 19:03:59 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:03:59 --> Controller Class Initialized
INFO - 2024-02-15 19:03:59 --> Form Validation Class Initialized
INFO - 2024-02-15 19:03:59 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:03:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:03:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:03:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:03:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 19:03:59 --> Final output sent to browser
DEBUG - 2024-02-15 19:03:59 --> Total execution time: 0.0214
ERROR - 2024-02-15 19:04:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:04:00 --> Config Class Initialized
INFO - 2024-02-15 19:04:00 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:04:00 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:04:00 --> Utf8 Class Initialized
INFO - 2024-02-15 19:04:00 --> URI Class Initialized
INFO - 2024-02-15 19:04:00 --> Router Class Initialized
INFO - 2024-02-15 19:04:00 --> Output Class Initialized
INFO - 2024-02-15 19:04:00 --> Security Class Initialized
DEBUG - 2024-02-15 19:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:04:00 --> Input Class Initialized
INFO - 2024-02-15 19:04:00 --> Language Class Initialized
INFO - 2024-02-15 19:04:00 --> Loader Class Initialized
INFO - 2024-02-15 19:04:00 --> Helper loaded: url_helper
INFO - 2024-02-15 19:04:00 --> Helper loaded: file_helper
INFO - 2024-02-15 19:04:00 --> Helper loaded: form_helper
INFO - 2024-02-15 19:04:00 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:04:00 --> Controller Class Initialized
INFO - 2024-02-15 19:04:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 19:04:00 --> Final output sent to browser
DEBUG - 2024-02-15 19:04:00 --> Total execution time: 0.0169
ERROR - 2024-02-15 19:06:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:06:33 --> Config Class Initialized
INFO - 2024-02-15 19:06:33 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:06:33 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:06:33 --> Utf8 Class Initialized
INFO - 2024-02-15 19:06:33 --> URI Class Initialized
INFO - 2024-02-15 19:06:33 --> Router Class Initialized
INFO - 2024-02-15 19:06:33 --> Output Class Initialized
INFO - 2024-02-15 19:06:33 --> Security Class Initialized
DEBUG - 2024-02-15 19:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:06:33 --> Input Class Initialized
INFO - 2024-02-15 19:06:33 --> Language Class Initialized
INFO - 2024-02-15 19:06:33 --> Loader Class Initialized
INFO - 2024-02-15 19:06:33 --> Helper loaded: url_helper
INFO - 2024-02-15 19:06:33 --> Helper loaded: file_helper
INFO - 2024-02-15 19:06:33 --> Helper loaded: form_helper
INFO - 2024-02-15 19:06:33 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:06:33 --> Controller Class Initialized
INFO - 2024-02-15 19:06:33 --> Form Validation Class Initialized
INFO - 2024-02-15 19:06:33 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:06:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:06:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:06:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:06:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:06:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:06:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:06:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:06:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:06:33 --> Final output sent to browser
DEBUG - 2024-02-15 19:06:33 --> Total execution time: 0.0342
ERROR - 2024-02-15 19:06:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:06:34 --> Config Class Initialized
INFO - 2024-02-15 19:06:34 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:06:34 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:06:34 --> Utf8 Class Initialized
INFO - 2024-02-15 19:06:34 --> URI Class Initialized
INFO - 2024-02-15 19:06:34 --> Router Class Initialized
INFO - 2024-02-15 19:06:34 --> Output Class Initialized
INFO - 2024-02-15 19:06:34 --> Security Class Initialized
DEBUG - 2024-02-15 19:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:06:34 --> Input Class Initialized
INFO - 2024-02-15 19:06:34 --> Language Class Initialized
INFO - 2024-02-15 19:06:34 --> Loader Class Initialized
INFO - 2024-02-15 19:06:34 --> Helper loaded: url_helper
INFO - 2024-02-15 19:06:34 --> Helper loaded: file_helper
INFO - 2024-02-15 19:06:34 --> Helper loaded: form_helper
INFO - 2024-02-15 19:06:34 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:06:34 --> Controller Class Initialized
INFO - 2024-02-15 19:06:34 --> Form Validation Class Initialized
INFO - 2024-02-15 19:06:34 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:06:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:06:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:06:34 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:06:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:06:36 --> Config Class Initialized
INFO - 2024-02-15 19:06:36 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:06:36 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:06:36 --> Utf8 Class Initialized
INFO - 2024-02-15 19:06:36 --> URI Class Initialized
INFO - 2024-02-15 19:06:36 --> Router Class Initialized
INFO - 2024-02-15 19:06:36 --> Output Class Initialized
INFO - 2024-02-15 19:06:36 --> Security Class Initialized
DEBUG - 2024-02-15 19:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:06:36 --> Input Class Initialized
INFO - 2024-02-15 19:06:36 --> Language Class Initialized
INFO - 2024-02-15 19:06:36 --> Loader Class Initialized
INFO - 2024-02-15 19:06:36 --> Helper loaded: url_helper
INFO - 2024-02-15 19:06:36 --> Helper loaded: file_helper
INFO - 2024-02-15 19:06:36 --> Helper loaded: form_helper
INFO - 2024-02-15 19:06:36 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:06:36 --> Controller Class Initialized
INFO - 2024-02-15 19:06:36 --> Form Validation Class Initialized
INFO - 2024-02-15 19:06:36 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:06:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:06:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:06:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:06:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 19:06:36 --> Final output sent to browser
DEBUG - 2024-02-15 19:06:36 --> Total execution time: 0.0251
ERROR - 2024-02-15 19:06:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:06:36 --> Config Class Initialized
INFO - 2024-02-15 19:06:36 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:06:36 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:06:36 --> Utf8 Class Initialized
INFO - 2024-02-15 19:06:36 --> URI Class Initialized
INFO - 2024-02-15 19:06:36 --> Router Class Initialized
INFO - 2024-02-15 19:06:36 --> Output Class Initialized
INFO - 2024-02-15 19:06:36 --> Security Class Initialized
DEBUG - 2024-02-15 19:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:06:36 --> Input Class Initialized
INFO - 2024-02-15 19:06:36 --> Language Class Initialized
INFO - 2024-02-15 19:06:36 --> Loader Class Initialized
INFO - 2024-02-15 19:06:36 --> Helper loaded: url_helper
INFO - 2024-02-15 19:06:36 --> Helper loaded: file_helper
INFO - 2024-02-15 19:06:36 --> Helper loaded: form_helper
INFO - 2024-02-15 19:06:36 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:06:36 --> Controller Class Initialized
INFO - 2024-02-15 19:06:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 19:06:36 --> Final output sent to browser
DEBUG - 2024-02-15 19:06:36 --> Total execution time: 0.0255
ERROR - 2024-02-15 19:07:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:07:13 --> Config Class Initialized
INFO - 2024-02-15 19:07:13 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:07:13 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:07:13 --> Utf8 Class Initialized
INFO - 2024-02-15 19:07:13 --> URI Class Initialized
INFO - 2024-02-15 19:07:13 --> Router Class Initialized
INFO - 2024-02-15 19:07:13 --> Output Class Initialized
INFO - 2024-02-15 19:07:13 --> Security Class Initialized
DEBUG - 2024-02-15 19:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:07:13 --> Input Class Initialized
INFO - 2024-02-15 19:07:13 --> Language Class Initialized
INFO - 2024-02-15 19:07:13 --> Loader Class Initialized
INFO - 2024-02-15 19:07:13 --> Helper loaded: url_helper
INFO - 2024-02-15 19:07:13 --> Helper loaded: file_helper
INFO - 2024-02-15 19:07:13 --> Helper loaded: form_helper
INFO - 2024-02-15 19:07:13 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:07:13 --> Controller Class Initialized
INFO - 2024-02-15 19:07:13 --> Form Validation Class Initialized
INFO - 2024-02-15 19:07:13 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:07:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:07:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:07:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:07:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:07:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:07:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:07:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:07:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:07:13 --> Final output sent to browser
DEBUG - 2024-02-15 19:07:13 --> Total execution time: 0.0273
ERROR - 2024-02-15 19:07:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:07:14 --> Config Class Initialized
INFO - 2024-02-15 19:07:14 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:07:14 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:07:14 --> Utf8 Class Initialized
INFO - 2024-02-15 19:07:14 --> URI Class Initialized
INFO - 2024-02-15 19:07:14 --> Router Class Initialized
INFO - 2024-02-15 19:07:14 --> Output Class Initialized
INFO - 2024-02-15 19:07:14 --> Security Class Initialized
DEBUG - 2024-02-15 19:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:07:14 --> Input Class Initialized
INFO - 2024-02-15 19:07:14 --> Language Class Initialized
INFO - 2024-02-15 19:07:14 --> Loader Class Initialized
INFO - 2024-02-15 19:07:14 --> Helper loaded: url_helper
INFO - 2024-02-15 19:07:14 --> Helper loaded: file_helper
INFO - 2024-02-15 19:07:14 --> Helper loaded: form_helper
INFO - 2024-02-15 19:07:14 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:07:14 --> Controller Class Initialized
INFO - 2024-02-15 19:07:14 --> Form Validation Class Initialized
INFO - 2024-02-15 19:07:14 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:07:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:07:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:07:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:07:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:07:17 --> Config Class Initialized
INFO - 2024-02-15 19:07:17 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:07:17 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:07:17 --> Utf8 Class Initialized
INFO - 2024-02-15 19:07:17 --> URI Class Initialized
INFO - 2024-02-15 19:07:17 --> Router Class Initialized
INFO - 2024-02-15 19:07:17 --> Output Class Initialized
INFO - 2024-02-15 19:07:17 --> Security Class Initialized
DEBUG - 2024-02-15 19:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:07:17 --> Input Class Initialized
INFO - 2024-02-15 19:07:17 --> Language Class Initialized
INFO - 2024-02-15 19:07:17 --> Loader Class Initialized
INFO - 2024-02-15 19:07:17 --> Helper loaded: url_helper
INFO - 2024-02-15 19:07:17 --> Helper loaded: file_helper
INFO - 2024-02-15 19:07:17 --> Helper loaded: form_helper
INFO - 2024-02-15 19:07:17 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:07:17 --> Controller Class Initialized
INFO - 2024-02-15 19:07:17 --> Form Validation Class Initialized
INFO - 2024-02-15 19:07:17 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:07:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:07:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:07:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:07:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 19:07:17 --> Final output sent to browser
DEBUG - 2024-02-15 19:07:17 --> Total execution time: 0.0377
ERROR - 2024-02-15 19:08:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:08:59 --> Config Class Initialized
INFO - 2024-02-15 19:08:59 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:08:59 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:08:59 --> Utf8 Class Initialized
INFO - 2024-02-15 19:08:59 --> URI Class Initialized
INFO - 2024-02-15 19:08:59 --> Router Class Initialized
INFO - 2024-02-15 19:08:59 --> Output Class Initialized
INFO - 2024-02-15 19:08:59 --> Security Class Initialized
DEBUG - 2024-02-15 19:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:08:59 --> Input Class Initialized
INFO - 2024-02-15 19:08:59 --> Language Class Initialized
INFO - 2024-02-15 19:08:59 --> Loader Class Initialized
INFO - 2024-02-15 19:08:59 --> Helper loaded: url_helper
INFO - 2024-02-15 19:08:59 --> Helper loaded: file_helper
INFO - 2024-02-15 19:08:59 --> Helper loaded: form_helper
INFO - 2024-02-15 19:08:59 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:08:59 --> Controller Class Initialized
INFO - 2024-02-15 19:08:59 --> Form Validation Class Initialized
INFO - 2024-02-15 19:08:59 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:08:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:08:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:08:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:08:59 --> Final output sent to browser
DEBUG - 2024-02-15 19:08:59 --> Total execution time: 0.0368
ERROR - 2024-02-15 19:09:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:09:01 --> Config Class Initialized
INFO - 2024-02-15 19:09:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:09:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:09:01 --> Utf8 Class Initialized
INFO - 2024-02-15 19:09:01 --> URI Class Initialized
INFO - 2024-02-15 19:09:01 --> Router Class Initialized
INFO - 2024-02-15 19:09:01 --> Output Class Initialized
INFO - 2024-02-15 19:09:01 --> Security Class Initialized
DEBUG - 2024-02-15 19:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:09:01 --> Input Class Initialized
INFO - 2024-02-15 19:09:01 --> Language Class Initialized
INFO - 2024-02-15 19:09:01 --> Loader Class Initialized
INFO - 2024-02-15 19:09:01 --> Helper loaded: url_helper
INFO - 2024-02-15 19:09:01 --> Helper loaded: file_helper
INFO - 2024-02-15 19:09:01 --> Helper loaded: form_helper
INFO - 2024-02-15 19:09:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:09:01 --> Controller Class Initialized
INFO - 2024-02-15 19:09:01 --> Form Validation Class Initialized
INFO - 2024-02-15 19:09:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:09:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:09:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:09:01 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:09:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:09:02 --> Config Class Initialized
INFO - 2024-02-15 19:09:02 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:09:02 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:09:02 --> Utf8 Class Initialized
INFO - 2024-02-15 19:09:02 --> URI Class Initialized
INFO - 2024-02-15 19:09:02 --> Router Class Initialized
INFO - 2024-02-15 19:09:02 --> Output Class Initialized
INFO - 2024-02-15 19:09:02 --> Security Class Initialized
DEBUG - 2024-02-15 19:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:09:02 --> Input Class Initialized
INFO - 2024-02-15 19:09:02 --> Language Class Initialized
INFO - 2024-02-15 19:09:02 --> Loader Class Initialized
INFO - 2024-02-15 19:09:02 --> Helper loaded: url_helper
INFO - 2024-02-15 19:09:02 --> Helper loaded: file_helper
INFO - 2024-02-15 19:09:02 --> Helper loaded: form_helper
INFO - 2024-02-15 19:09:02 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:09:02 --> Controller Class Initialized
INFO - 2024-02-15 19:09:02 --> Form Validation Class Initialized
INFO - 2024-02-15 19:09:02 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:09:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:09:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:09:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:09:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 19:09:02 --> Final output sent to browser
DEBUG - 2024-02-15 19:09:02 --> Total execution time: 0.0365
ERROR - 2024-02-15 19:11:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:11:22 --> Config Class Initialized
INFO - 2024-02-15 19:11:22 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:11:22 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:11:22 --> Utf8 Class Initialized
INFO - 2024-02-15 19:11:22 --> URI Class Initialized
INFO - 2024-02-15 19:11:22 --> Router Class Initialized
INFO - 2024-02-15 19:11:22 --> Output Class Initialized
INFO - 2024-02-15 19:11:22 --> Security Class Initialized
DEBUG - 2024-02-15 19:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:11:22 --> Input Class Initialized
INFO - 2024-02-15 19:11:22 --> Language Class Initialized
INFO - 2024-02-15 19:11:22 --> Loader Class Initialized
INFO - 2024-02-15 19:11:22 --> Helper loaded: url_helper
INFO - 2024-02-15 19:11:22 --> Helper loaded: file_helper
INFO - 2024-02-15 19:11:22 --> Helper loaded: form_helper
INFO - 2024-02-15 19:11:22 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:11:22 --> Controller Class Initialized
INFO - 2024-02-15 19:11:22 --> Form Validation Class Initialized
INFO - 2024-02-15 19:11:22 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:11:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:11:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:11:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:11:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:11:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:11:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:11:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:11:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:11:22 --> Final output sent to browser
DEBUG - 2024-02-15 19:11:22 --> Total execution time: 0.0296
ERROR - 2024-02-15 19:11:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:11:22 --> Config Class Initialized
INFO - 2024-02-15 19:11:22 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:11:22 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:11:22 --> Utf8 Class Initialized
INFO - 2024-02-15 19:11:22 --> URI Class Initialized
INFO - 2024-02-15 19:11:22 --> Router Class Initialized
INFO - 2024-02-15 19:11:22 --> Output Class Initialized
INFO - 2024-02-15 19:11:22 --> Security Class Initialized
DEBUG - 2024-02-15 19:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:11:22 --> Input Class Initialized
INFO - 2024-02-15 19:11:22 --> Language Class Initialized
INFO - 2024-02-15 19:11:22 --> Loader Class Initialized
INFO - 2024-02-15 19:11:22 --> Helper loaded: url_helper
INFO - 2024-02-15 19:11:22 --> Helper loaded: file_helper
INFO - 2024-02-15 19:11:22 --> Helper loaded: form_helper
INFO - 2024-02-15 19:11:22 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:11:22 --> Controller Class Initialized
INFO - 2024-02-15 19:11:22 --> Form Validation Class Initialized
INFO - 2024-02-15 19:11:22 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:11:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:11:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:11:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:11:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:11:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:11:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:11:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:11:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:11:22 --> Final output sent to browser
DEBUG - 2024-02-15 19:11:22 --> Total execution time: 0.0620
ERROR - 2024-02-15 19:11:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:11:23 --> Config Class Initialized
INFO - 2024-02-15 19:11:23 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:11:23 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:11:23 --> Utf8 Class Initialized
INFO - 2024-02-15 19:11:23 --> URI Class Initialized
INFO - 2024-02-15 19:11:23 --> Router Class Initialized
INFO - 2024-02-15 19:11:23 --> Output Class Initialized
INFO - 2024-02-15 19:11:23 --> Security Class Initialized
DEBUG - 2024-02-15 19:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:11:23 --> Input Class Initialized
INFO - 2024-02-15 19:11:23 --> Language Class Initialized
INFO - 2024-02-15 19:11:23 --> Loader Class Initialized
INFO - 2024-02-15 19:11:23 --> Helper loaded: url_helper
INFO - 2024-02-15 19:11:23 --> Helper loaded: file_helper
INFO - 2024-02-15 19:11:23 --> Helper loaded: form_helper
INFO - 2024-02-15 19:11:23 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:11:23 --> Controller Class Initialized
INFO - 2024-02-15 19:11:23 --> Form Validation Class Initialized
INFO - 2024-02-15 19:11:23 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:11:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:11:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:11:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:11:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:11:29 --> Config Class Initialized
INFO - 2024-02-15 19:11:29 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:11:29 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:11:29 --> Utf8 Class Initialized
INFO - 2024-02-15 19:11:29 --> URI Class Initialized
INFO - 2024-02-15 19:11:29 --> Router Class Initialized
INFO - 2024-02-15 19:11:29 --> Output Class Initialized
INFO - 2024-02-15 19:11:29 --> Security Class Initialized
DEBUG - 2024-02-15 19:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:11:29 --> Input Class Initialized
INFO - 2024-02-15 19:11:29 --> Language Class Initialized
INFO - 2024-02-15 19:11:29 --> Loader Class Initialized
INFO - 2024-02-15 19:11:29 --> Helper loaded: url_helper
INFO - 2024-02-15 19:11:29 --> Helper loaded: file_helper
INFO - 2024-02-15 19:11:29 --> Helper loaded: form_helper
INFO - 2024-02-15 19:11:29 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:11:29 --> Controller Class Initialized
INFO - 2024-02-15 19:11:29 --> Form Validation Class Initialized
INFO - 2024-02-15 19:11:29 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:11:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:11:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:11:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:11:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 19:11:29 --> Final output sent to browser
DEBUG - 2024-02-15 19:11:29 --> Total execution time: 0.0374
ERROR - 2024-02-15 19:12:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:12:20 --> Config Class Initialized
INFO - 2024-02-15 19:12:20 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:12:20 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:12:20 --> Utf8 Class Initialized
INFO - 2024-02-15 19:12:20 --> URI Class Initialized
INFO - 2024-02-15 19:12:20 --> Router Class Initialized
INFO - 2024-02-15 19:12:20 --> Output Class Initialized
INFO - 2024-02-15 19:12:20 --> Security Class Initialized
DEBUG - 2024-02-15 19:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:12:20 --> Input Class Initialized
INFO - 2024-02-15 19:12:20 --> Language Class Initialized
INFO - 2024-02-15 19:12:20 --> Loader Class Initialized
INFO - 2024-02-15 19:12:20 --> Helper loaded: url_helper
INFO - 2024-02-15 19:12:20 --> Helper loaded: file_helper
INFO - 2024-02-15 19:12:20 --> Helper loaded: form_helper
INFO - 2024-02-15 19:12:20 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:12:20 --> Controller Class Initialized
INFO - 2024-02-15 19:12:20 --> Form Validation Class Initialized
INFO - 2024-02-15 19:12:20 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:12:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:12:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:12:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:12:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:12:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:12:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:12:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:12:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:12:20 --> Final output sent to browser
DEBUG - 2024-02-15 19:12:20 --> Total execution time: 0.0259
ERROR - 2024-02-15 19:12:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:12:20 --> Config Class Initialized
INFO - 2024-02-15 19:12:20 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:12:20 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:12:20 --> Utf8 Class Initialized
INFO - 2024-02-15 19:12:20 --> URI Class Initialized
INFO - 2024-02-15 19:12:20 --> Router Class Initialized
INFO - 2024-02-15 19:12:20 --> Output Class Initialized
INFO - 2024-02-15 19:12:20 --> Security Class Initialized
DEBUG - 2024-02-15 19:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:12:20 --> Input Class Initialized
INFO - 2024-02-15 19:12:20 --> Language Class Initialized
INFO - 2024-02-15 19:12:20 --> Loader Class Initialized
INFO - 2024-02-15 19:12:20 --> Helper loaded: url_helper
INFO - 2024-02-15 19:12:20 --> Helper loaded: file_helper
INFO - 2024-02-15 19:12:20 --> Helper loaded: form_helper
INFO - 2024-02-15 19:12:20 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:12:20 --> Controller Class Initialized
INFO - 2024-02-15 19:12:20 --> Form Validation Class Initialized
INFO - 2024-02-15 19:12:20 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:12:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:12:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:12:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:12:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:12:23 --> Config Class Initialized
INFO - 2024-02-15 19:12:23 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:12:23 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:12:23 --> Utf8 Class Initialized
INFO - 2024-02-15 19:12:23 --> URI Class Initialized
INFO - 2024-02-15 19:12:23 --> Router Class Initialized
INFO - 2024-02-15 19:12:23 --> Output Class Initialized
INFO - 2024-02-15 19:12:23 --> Security Class Initialized
DEBUG - 2024-02-15 19:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:12:23 --> Input Class Initialized
INFO - 2024-02-15 19:12:23 --> Language Class Initialized
INFO - 2024-02-15 19:12:23 --> Loader Class Initialized
INFO - 2024-02-15 19:12:23 --> Helper loaded: url_helper
INFO - 2024-02-15 19:12:23 --> Helper loaded: file_helper
INFO - 2024-02-15 19:12:23 --> Helper loaded: form_helper
INFO - 2024-02-15 19:12:23 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:12:23 --> Controller Class Initialized
INFO - 2024-02-15 19:12:23 --> Form Validation Class Initialized
INFO - 2024-02-15 19:12:23 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:12:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:12:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:12:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:12:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 19:12:23 --> Final output sent to browser
DEBUG - 2024-02-15 19:12:23 --> Total execution time: 0.0244
ERROR - 2024-02-15 19:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:20:23 --> Config Class Initialized
INFO - 2024-02-15 19:20:23 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:20:23 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:20:23 --> Utf8 Class Initialized
INFO - 2024-02-15 19:20:23 --> URI Class Initialized
INFO - 2024-02-15 19:20:23 --> Router Class Initialized
INFO - 2024-02-15 19:20:23 --> Output Class Initialized
INFO - 2024-02-15 19:20:23 --> Security Class Initialized
DEBUG - 2024-02-15 19:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:20:23 --> Input Class Initialized
INFO - 2024-02-15 19:20:23 --> Language Class Initialized
INFO - 2024-02-15 19:20:23 --> Loader Class Initialized
INFO - 2024-02-15 19:20:23 --> Helper loaded: url_helper
INFO - 2024-02-15 19:20:23 --> Helper loaded: file_helper
INFO - 2024-02-15 19:20:23 --> Helper loaded: form_helper
INFO - 2024-02-15 19:20:23 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:20:23 --> Controller Class Initialized
INFO - 2024-02-15 19:20:23 --> Form Validation Class Initialized
INFO - 2024-02-15 19:20:23 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:20:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:20:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:20:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:20:23 --> Final output sent to browser
DEBUG - 2024-02-15 19:20:23 --> Total execution time: 0.0299
ERROR - 2024-02-15 19:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:20:23 --> Config Class Initialized
INFO - 2024-02-15 19:20:23 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:20:23 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:20:23 --> Utf8 Class Initialized
INFO - 2024-02-15 19:20:23 --> URI Class Initialized
INFO - 2024-02-15 19:20:23 --> Router Class Initialized
INFO - 2024-02-15 19:20:23 --> Output Class Initialized
INFO - 2024-02-15 19:20:23 --> Security Class Initialized
DEBUG - 2024-02-15 19:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:20:23 --> Input Class Initialized
INFO - 2024-02-15 19:20:23 --> Language Class Initialized
INFO - 2024-02-15 19:20:23 --> Loader Class Initialized
INFO - 2024-02-15 19:20:23 --> Helper loaded: url_helper
INFO - 2024-02-15 19:20:23 --> Helper loaded: file_helper
INFO - 2024-02-15 19:20:23 --> Helper loaded: form_helper
INFO - 2024-02-15 19:20:23 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:20:23 --> Controller Class Initialized
INFO - 2024-02-15 19:20:23 --> Form Validation Class Initialized
INFO - 2024-02-15 19:20:23 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:20:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:20:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:20:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:20:23 --> Final output sent to browser
DEBUG - 2024-02-15 19:20:23 --> Total execution time: 0.0296
ERROR - 2024-02-15 19:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:20:25 --> Config Class Initialized
INFO - 2024-02-15 19:20:25 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:20:25 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:20:25 --> Utf8 Class Initialized
INFO - 2024-02-15 19:20:25 --> URI Class Initialized
INFO - 2024-02-15 19:20:25 --> Router Class Initialized
INFO - 2024-02-15 19:20:25 --> Output Class Initialized
INFO - 2024-02-15 19:20:25 --> Security Class Initialized
DEBUG - 2024-02-15 19:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:20:25 --> Input Class Initialized
INFO - 2024-02-15 19:20:25 --> Language Class Initialized
INFO - 2024-02-15 19:20:25 --> Loader Class Initialized
INFO - 2024-02-15 19:20:25 --> Helper loaded: url_helper
INFO - 2024-02-15 19:20:25 --> Helper loaded: file_helper
INFO - 2024-02-15 19:20:25 --> Helper loaded: form_helper
INFO - 2024-02-15 19:20:25 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:20:25 --> Controller Class Initialized
INFO - 2024-02-15 19:20:25 --> Form Validation Class Initialized
INFO - 2024-02-15 19:20:25 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:20:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:20:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:20:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:20:28 --> Config Class Initialized
INFO - 2024-02-15 19:20:28 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:20:28 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:20:28 --> Utf8 Class Initialized
INFO - 2024-02-15 19:20:28 --> URI Class Initialized
INFO - 2024-02-15 19:20:28 --> Router Class Initialized
INFO - 2024-02-15 19:20:28 --> Output Class Initialized
INFO - 2024-02-15 19:20:28 --> Security Class Initialized
DEBUG - 2024-02-15 19:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:20:28 --> Input Class Initialized
INFO - 2024-02-15 19:20:28 --> Language Class Initialized
INFO - 2024-02-15 19:20:28 --> Loader Class Initialized
INFO - 2024-02-15 19:20:28 --> Helper loaded: url_helper
INFO - 2024-02-15 19:20:28 --> Helper loaded: file_helper
INFO - 2024-02-15 19:20:28 --> Helper loaded: form_helper
INFO - 2024-02-15 19:20:28 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:20:28 --> Controller Class Initialized
INFO - 2024-02-15 19:20:28 --> Form Validation Class Initialized
INFO - 2024-02-15 19:20:28 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:20:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:20:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:20:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:20:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 19:20:28 --> Final output sent to browser
DEBUG - 2024-02-15 19:20:28 --> Total execution time: 0.0213
ERROR - 2024-02-15 19:24:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:24:28 --> Config Class Initialized
INFO - 2024-02-15 19:24:28 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:24:28 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:24:28 --> Utf8 Class Initialized
INFO - 2024-02-15 19:24:28 --> URI Class Initialized
INFO - 2024-02-15 19:24:28 --> Router Class Initialized
INFO - 2024-02-15 19:24:28 --> Output Class Initialized
INFO - 2024-02-15 19:24:28 --> Security Class Initialized
DEBUG - 2024-02-15 19:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:24:28 --> Input Class Initialized
INFO - 2024-02-15 19:24:28 --> Language Class Initialized
INFO - 2024-02-15 19:24:28 --> Loader Class Initialized
INFO - 2024-02-15 19:24:28 --> Helper loaded: url_helper
INFO - 2024-02-15 19:24:28 --> Helper loaded: file_helper
INFO - 2024-02-15 19:24:28 --> Helper loaded: form_helper
INFO - 2024-02-15 19:24:28 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:24:28 --> Controller Class Initialized
INFO - 2024-02-15 19:24:28 --> Form Validation Class Initialized
INFO - 2024-02-15 19:24:28 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:24:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:24:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:24:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:24:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:24:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:24:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:24:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:24:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:24:28 --> Final output sent to browser
DEBUG - 2024-02-15 19:24:28 --> Total execution time: 0.0338
ERROR - 2024-02-15 19:24:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:24:29 --> Config Class Initialized
INFO - 2024-02-15 19:24:29 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:24:29 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:24:29 --> Utf8 Class Initialized
INFO - 2024-02-15 19:24:29 --> URI Class Initialized
INFO - 2024-02-15 19:24:29 --> Router Class Initialized
INFO - 2024-02-15 19:24:29 --> Output Class Initialized
INFO - 2024-02-15 19:24:29 --> Security Class Initialized
DEBUG - 2024-02-15 19:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:24:29 --> Input Class Initialized
INFO - 2024-02-15 19:24:29 --> Language Class Initialized
INFO - 2024-02-15 19:24:29 --> Loader Class Initialized
INFO - 2024-02-15 19:24:29 --> Helper loaded: url_helper
INFO - 2024-02-15 19:24:29 --> Helper loaded: file_helper
INFO - 2024-02-15 19:24:29 --> Helper loaded: form_helper
INFO - 2024-02-15 19:24:29 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:24:29 --> Controller Class Initialized
INFO - 2024-02-15 19:24:29 --> Form Validation Class Initialized
INFO - 2024-02-15 19:24:29 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:24:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:24:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:24:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:25:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:25:01 --> Config Class Initialized
INFO - 2024-02-15 19:25:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:25:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:25:01 --> Utf8 Class Initialized
INFO - 2024-02-15 19:25:01 --> URI Class Initialized
INFO - 2024-02-15 19:25:01 --> Router Class Initialized
INFO - 2024-02-15 19:25:01 --> Output Class Initialized
INFO - 2024-02-15 19:25:01 --> Security Class Initialized
DEBUG - 2024-02-15 19:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:25:01 --> Input Class Initialized
INFO - 2024-02-15 19:25:01 --> Language Class Initialized
INFO - 2024-02-15 19:25:01 --> Loader Class Initialized
INFO - 2024-02-15 19:25:01 --> Helper loaded: url_helper
INFO - 2024-02-15 19:25:01 --> Helper loaded: file_helper
INFO - 2024-02-15 19:25:01 --> Helper loaded: form_helper
INFO - 2024-02-15 19:25:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:25:01 --> Controller Class Initialized
INFO - 2024-02-15 19:25:01 --> Form Validation Class Initialized
INFO - 2024-02-15 19:25:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:25:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:25:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:25:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:25:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:25:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:25:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:25:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:25:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:25:01 --> Final output sent to browser
DEBUG - 2024-02-15 19:25:01 --> Total execution time: 0.0274
ERROR - 2024-02-15 19:25:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:25:01 --> Config Class Initialized
INFO - 2024-02-15 19:25:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:25:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:25:01 --> Utf8 Class Initialized
INFO - 2024-02-15 19:25:01 --> URI Class Initialized
INFO - 2024-02-15 19:25:01 --> Router Class Initialized
INFO - 2024-02-15 19:25:01 --> Output Class Initialized
INFO - 2024-02-15 19:25:01 --> Security Class Initialized
DEBUG - 2024-02-15 19:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:25:01 --> Input Class Initialized
INFO - 2024-02-15 19:25:01 --> Language Class Initialized
INFO - 2024-02-15 19:25:01 --> Loader Class Initialized
INFO - 2024-02-15 19:25:01 --> Helper loaded: url_helper
INFO - 2024-02-15 19:25:01 --> Helper loaded: file_helper
INFO - 2024-02-15 19:25:01 --> Helper loaded: form_helper
INFO - 2024-02-15 19:25:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:25:01 --> Controller Class Initialized
INFO - 2024-02-15 19:25:01 --> Form Validation Class Initialized
INFO - 2024-02-15 19:25:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:25:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:25:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:25:01 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:25:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:25:30 --> Config Class Initialized
INFO - 2024-02-15 19:25:30 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:25:30 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:25:30 --> Utf8 Class Initialized
INFO - 2024-02-15 19:25:30 --> URI Class Initialized
INFO - 2024-02-15 19:25:30 --> Router Class Initialized
INFO - 2024-02-15 19:25:30 --> Output Class Initialized
INFO - 2024-02-15 19:25:30 --> Security Class Initialized
DEBUG - 2024-02-15 19:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:25:30 --> Input Class Initialized
INFO - 2024-02-15 19:25:30 --> Language Class Initialized
INFO - 2024-02-15 19:25:30 --> Loader Class Initialized
INFO - 2024-02-15 19:25:30 --> Helper loaded: url_helper
INFO - 2024-02-15 19:25:30 --> Helper loaded: file_helper
INFO - 2024-02-15 19:25:30 --> Helper loaded: form_helper
INFO - 2024-02-15 19:25:30 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:25:30 --> Controller Class Initialized
INFO - 2024-02-15 19:25:30 --> Form Validation Class Initialized
INFO - 2024-02-15 19:25:30 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:25:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:25:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:25:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:25:30 --> Final output sent to browser
DEBUG - 2024-02-15 19:25:30 --> Total execution time: 0.0339
ERROR - 2024-02-15 19:25:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:25:31 --> Config Class Initialized
INFO - 2024-02-15 19:25:31 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:25:31 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:25:31 --> Utf8 Class Initialized
INFO - 2024-02-15 19:25:31 --> URI Class Initialized
INFO - 2024-02-15 19:25:31 --> Router Class Initialized
INFO - 2024-02-15 19:25:31 --> Output Class Initialized
INFO - 2024-02-15 19:25:31 --> Security Class Initialized
DEBUG - 2024-02-15 19:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:25:31 --> Input Class Initialized
INFO - 2024-02-15 19:25:31 --> Language Class Initialized
INFO - 2024-02-15 19:25:31 --> Loader Class Initialized
INFO - 2024-02-15 19:25:31 --> Helper loaded: url_helper
INFO - 2024-02-15 19:25:31 --> Helper loaded: file_helper
INFO - 2024-02-15 19:25:31 --> Helper loaded: form_helper
INFO - 2024-02-15 19:25:31 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:25:31 --> Controller Class Initialized
INFO - 2024-02-15 19:25:31 --> Form Validation Class Initialized
INFO - 2024-02-15 19:25:31 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:25:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:25:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:25:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:26:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:26:28 --> Config Class Initialized
INFO - 2024-02-15 19:26:28 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:26:28 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:26:28 --> Utf8 Class Initialized
INFO - 2024-02-15 19:26:28 --> URI Class Initialized
INFO - 2024-02-15 19:26:28 --> Router Class Initialized
INFO - 2024-02-15 19:26:28 --> Output Class Initialized
INFO - 2024-02-15 19:26:28 --> Security Class Initialized
DEBUG - 2024-02-15 19:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:26:28 --> Input Class Initialized
INFO - 2024-02-15 19:26:28 --> Language Class Initialized
INFO - 2024-02-15 19:26:28 --> Loader Class Initialized
INFO - 2024-02-15 19:26:28 --> Helper loaded: url_helper
INFO - 2024-02-15 19:26:28 --> Helper loaded: file_helper
INFO - 2024-02-15 19:26:28 --> Helper loaded: form_helper
INFO - 2024-02-15 19:26:28 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:26:28 --> Controller Class Initialized
INFO - 2024-02-15 19:26:28 --> Form Validation Class Initialized
INFO - 2024-02-15 19:26:28 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:26:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:26:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:26:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:26:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:26:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:26:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:26:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:26:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:26:28 --> Final output sent to browser
DEBUG - 2024-02-15 19:26:28 --> Total execution time: 0.0303
ERROR - 2024-02-15 19:26:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:26:29 --> Config Class Initialized
INFO - 2024-02-15 19:26:29 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:26:29 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:26:29 --> Utf8 Class Initialized
INFO - 2024-02-15 19:26:29 --> URI Class Initialized
INFO - 2024-02-15 19:26:29 --> Router Class Initialized
INFO - 2024-02-15 19:26:29 --> Output Class Initialized
INFO - 2024-02-15 19:26:29 --> Security Class Initialized
DEBUG - 2024-02-15 19:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:26:29 --> Input Class Initialized
INFO - 2024-02-15 19:26:29 --> Language Class Initialized
INFO - 2024-02-15 19:26:29 --> Loader Class Initialized
INFO - 2024-02-15 19:26:29 --> Helper loaded: url_helper
INFO - 2024-02-15 19:26:29 --> Helper loaded: file_helper
INFO - 2024-02-15 19:26:29 --> Helper loaded: form_helper
INFO - 2024-02-15 19:26:29 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:26:29 --> Controller Class Initialized
INFO - 2024-02-15 19:26:29 --> Form Validation Class Initialized
INFO - 2024-02-15 19:26:29 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:26:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:26:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:26:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:28:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:28:44 --> Config Class Initialized
INFO - 2024-02-15 19:28:44 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:28:44 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:28:44 --> Utf8 Class Initialized
INFO - 2024-02-15 19:28:44 --> URI Class Initialized
INFO - 2024-02-15 19:28:44 --> Router Class Initialized
INFO - 2024-02-15 19:28:44 --> Output Class Initialized
INFO - 2024-02-15 19:28:44 --> Security Class Initialized
DEBUG - 2024-02-15 19:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:28:44 --> Input Class Initialized
INFO - 2024-02-15 19:28:44 --> Language Class Initialized
INFO - 2024-02-15 19:28:44 --> Loader Class Initialized
INFO - 2024-02-15 19:28:44 --> Helper loaded: url_helper
INFO - 2024-02-15 19:28:44 --> Helper loaded: file_helper
INFO - 2024-02-15 19:28:44 --> Helper loaded: form_helper
INFO - 2024-02-15 19:28:44 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:28:44 --> Controller Class Initialized
INFO - 2024-02-15 19:28:44 --> Form Validation Class Initialized
INFO - 2024-02-15 19:28:44 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:28:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:28:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:28:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:28:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:28:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:28:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:28:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:28:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:28:44 --> Final output sent to browser
DEBUG - 2024-02-15 19:28:44 --> Total execution time: 0.0376
ERROR - 2024-02-15 19:28:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:28:44 --> Config Class Initialized
INFO - 2024-02-15 19:28:44 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:28:44 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:28:44 --> Utf8 Class Initialized
INFO - 2024-02-15 19:28:44 --> URI Class Initialized
INFO - 2024-02-15 19:28:44 --> Router Class Initialized
INFO - 2024-02-15 19:28:44 --> Output Class Initialized
INFO - 2024-02-15 19:28:44 --> Security Class Initialized
DEBUG - 2024-02-15 19:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:28:44 --> Input Class Initialized
INFO - 2024-02-15 19:28:44 --> Language Class Initialized
INFO - 2024-02-15 19:28:44 --> Loader Class Initialized
INFO - 2024-02-15 19:28:44 --> Helper loaded: url_helper
INFO - 2024-02-15 19:28:44 --> Helper loaded: file_helper
INFO - 2024-02-15 19:28:44 --> Helper loaded: form_helper
INFO - 2024-02-15 19:28:44 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:28:44 --> Controller Class Initialized
INFO - 2024-02-15 19:28:44 --> Form Validation Class Initialized
INFO - 2024-02-15 19:28:44 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:28:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:28:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:28:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:32:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:32:33 --> Config Class Initialized
INFO - 2024-02-15 19:32:33 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:32:33 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:32:33 --> Utf8 Class Initialized
INFO - 2024-02-15 19:32:33 --> URI Class Initialized
INFO - 2024-02-15 19:32:33 --> Router Class Initialized
INFO - 2024-02-15 19:32:33 --> Output Class Initialized
INFO - 2024-02-15 19:32:33 --> Security Class Initialized
DEBUG - 2024-02-15 19:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:32:33 --> Input Class Initialized
INFO - 2024-02-15 19:32:33 --> Language Class Initialized
INFO - 2024-02-15 19:32:33 --> Loader Class Initialized
INFO - 2024-02-15 19:32:33 --> Helper loaded: url_helper
INFO - 2024-02-15 19:32:33 --> Helper loaded: file_helper
INFO - 2024-02-15 19:32:33 --> Helper loaded: form_helper
INFO - 2024-02-15 19:32:33 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:32:33 --> Controller Class Initialized
INFO - 2024-02-15 19:32:33 --> Form Validation Class Initialized
INFO - 2024-02-15 19:32:33 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:32:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:32:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:32:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:32:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:32:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:32:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:32:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:32:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:32:33 --> Final output sent to browser
DEBUG - 2024-02-15 19:32:33 --> Total execution time: 0.0370
ERROR - 2024-02-15 19:32:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:32:34 --> Config Class Initialized
INFO - 2024-02-15 19:32:34 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:32:34 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:32:34 --> Utf8 Class Initialized
INFO - 2024-02-15 19:32:34 --> URI Class Initialized
INFO - 2024-02-15 19:32:34 --> Router Class Initialized
INFO - 2024-02-15 19:32:34 --> Output Class Initialized
INFO - 2024-02-15 19:32:34 --> Security Class Initialized
DEBUG - 2024-02-15 19:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:32:34 --> Input Class Initialized
INFO - 2024-02-15 19:32:34 --> Language Class Initialized
INFO - 2024-02-15 19:32:34 --> Loader Class Initialized
INFO - 2024-02-15 19:32:34 --> Helper loaded: url_helper
INFO - 2024-02-15 19:32:34 --> Helper loaded: file_helper
INFO - 2024-02-15 19:32:34 --> Helper loaded: form_helper
INFO - 2024-02-15 19:32:34 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:32:34 --> Controller Class Initialized
INFO - 2024-02-15 19:32:34 --> Form Validation Class Initialized
INFO - 2024-02-15 19:32:34 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:32:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:32:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:32:34 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:37:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:37:07 --> Config Class Initialized
INFO - 2024-02-15 19:37:07 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:37:07 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:37:07 --> Utf8 Class Initialized
INFO - 2024-02-15 19:37:07 --> URI Class Initialized
INFO - 2024-02-15 19:37:07 --> Router Class Initialized
INFO - 2024-02-15 19:37:07 --> Output Class Initialized
INFO - 2024-02-15 19:37:07 --> Security Class Initialized
DEBUG - 2024-02-15 19:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:37:07 --> Input Class Initialized
INFO - 2024-02-15 19:37:07 --> Language Class Initialized
INFO - 2024-02-15 19:37:07 --> Loader Class Initialized
INFO - 2024-02-15 19:37:07 --> Helper loaded: url_helper
INFO - 2024-02-15 19:37:07 --> Helper loaded: file_helper
INFO - 2024-02-15 19:37:07 --> Helper loaded: form_helper
INFO - 2024-02-15 19:37:07 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:37:07 --> Controller Class Initialized
INFO - 2024-02-15 19:37:07 --> Form Validation Class Initialized
INFO - 2024-02-15 19:37:07 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:37:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:37:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:37:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:37:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:37:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:37:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:37:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:37:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:37:07 --> Final output sent to browser
DEBUG - 2024-02-15 19:37:07 --> Total execution time: 0.0320
ERROR - 2024-02-15 19:37:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:37:08 --> Config Class Initialized
INFO - 2024-02-15 19:37:08 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:37:08 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:37:08 --> Utf8 Class Initialized
INFO - 2024-02-15 19:37:08 --> URI Class Initialized
INFO - 2024-02-15 19:37:08 --> Router Class Initialized
INFO - 2024-02-15 19:37:08 --> Output Class Initialized
INFO - 2024-02-15 19:37:08 --> Security Class Initialized
DEBUG - 2024-02-15 19:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:37:08 --> Input Class Initialized
INFO - 2024-02-15 19:37:08 --> Language Class Initialized
INFO - 2024-02-15 19:37:08 --> Loader Class Initialized
INFO - 2024-02-15 19:37:08 --> Helper loaded: url_helper
INFO - 2024-02-15 19:37:08 --> Helper loaded: file_helper
INFO - 2024-02-15 19:37:08 --> Helper loaded: form_helper
INFO - 2024-02-15 19:37:08 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:37:08 --> Controller Class Initialized
INFO - 2024-02-15 19:37:08 --> Form Validation Class Initialized
INFO - 2024-02-15 19:37:08 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:37:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:37:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:37:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:37:08 --> Final output sent to browser
DEBUG - 2024-02-15 19:37:08 --> Total execution time: 0.0569
ERROR - 2024-02-15 19:37:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:37:08 --> Config Class Initialized
INFO - 2024-02-15 19:37:08 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:37:08 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:37:08 --> Utf8 Class Initialized
INFO - 2024-02-15 19:37:08 --> URI Class Initialized
INFO - 2024-02-15 19:37:08 --> Router Class Initialized
INFO - 2024-02-15 19:37:08 --> Output Class Initialized
INFO - 2024-02-15 19:37:08 --> Security Class Initialized
DEBUG - 2024-02-15 19:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:37:08 --> Input Class Initialized
INFO - 2024-02-15 19:37:08 --> Language Class Initialized
INFO - 2024-02-15 19:37:08 --> Loader Class Initialized
INFO - 2024-02-15 19:37:08 --> Helper loaded: url_helper
INFO - 2024-02-15 19:37:08 --> Helper loaded: file_helper
INFO - 2024-02-15 19:37:08 --> Helper loaded: form_helper
INFO - 2024-02-15 19:37:08 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:37:08 --> Controller Class Initialized
INFO - 2024-02-15 19:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 19:37:08 --> Final output sent to browser
DEBUG - 2024-02-15 19:37:08 --> Total execution time: 0.0179
ERROR - 2024-02-15 19:37:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:37:08 --> Config Class Initialized
INFO - 2024-02-15 19:37:08 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:37:08 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:37:08 --> Utf8 Class Initialized
INFO - 2024-02-15 19:37:08 --> URI Class Initialized
INFO - 2024-02-15 19:37:08 --> Router Class Initialized
INFO - 2024-02-15 19:37:08 --> Output Class Initialized
INFO - 2024-02-15 19:37:08 --> Security Class Initialized
DEBUG - 2024-02-15 19:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:37:08 --> Input Class Initialized
INFO - 2024-02-15 19:37:08 --> Language Class Initialized
INFO - 2024-02-15 19:37:08 --> Loader Class Initialized
INFO - 2024-02-15 19:37:08 --> Helper loaded: url_helper
INFO - 2024-02-15 19:37:08 --> Helper loaded: file_helper
INFO - 2024-02-15 19:37:08 --> Helper loaded: form_helper
INFO - 2024-02-15 19:37:08 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:37:08 --> Controller Class Initialized
INFO - 2024-02-15 19:37:08 --> Form Validation Class Initialized
INFO - 2024-02-15 19:37:08 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:37:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:37:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:37:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:40:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:40:37 --> Config Class Initialized
INFO - 2024-02-15 19:40:37 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:40:37 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:40:37 --> Utf8 Class Initialized
INFO - 2024-02-15 19:40:37 --> URI Class Initialized
INFO - 2024-02-15 19:40:37 --> Router Class Initialized
INFO - 2024-02-15 19:40:37 --> Output Class Initialized
INFO - 2024-02-15 19:40:37 --> Security Class Initialized
DEBUG - 2024-02-15 19:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:40:37 --> Input Class Initialized
INFO - 2024-02-15 19:40:37 --> Language Class Initialized
INFO - 2024-02-15 19:40:37 --> Loader Class Initialized
INFO - 2024-02-15 19:40:37 --> Helper loaded: url_helper
INFO - 2024-02-15 19:40:37 --> Helper loaded: file_helper
INFO - 2024-02-15 19:40:37 --> Helper loaded: form_helper
INFO - 2024-02-15 19:40:37 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:40:37 --> Controller Class Initialized
INFO - 2024-02-15 19:40:37 --> Form Validation Class Initialized
INFO - 2024-02-15 19:40:37 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:40:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:40:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:40:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:40:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:40:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:40:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:40:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:40:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:40:37 --> Final output sent to browser
DEBUG - 2024-02-15 19:40:37 --> Total execution time: 0.0337
ERROR - 2024-02-15 19:40:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:40:38 --> Config Class Initialized
INFO - 2024-02-15 19:40:38 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:40:38 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:40:38 --> Utf8 Class Initialized
INFO - 2024-02-15 19:40:38 --> URI Class Initialized
INFO - 2024-02-15 19:40:38 --> Router Class Initialized
INFO - 2024-02-15 19:40:38 --> Output Class Initialized
INFO - 2024-02-15 19:40:38 --> Security Class Initialized
DEBUG - 2024-02-15 19:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:40:38 --> Input Class Initialized
INFO - 2024-02-15 19:40:38 --> Language Class Initialized
INFO - 2024-02-15 19:40:38 --> Loader Class Initialized
INFO - 2024-02-15 19:40:38 --> Helper loaded: url_helper
INFO - 2024-02-15 19:40:38 --> Helper loaded: file_helper
INFO - 2024-02-15 19:40:38 --> Helper loaded: form_helper
INFO - 2024-02-15 19:40:38 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:40:38 --> Controller Class Initialized
INFO - 2024-02-15 19:40:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 19:40:38 --> Final output sent to browser
DEBUG - 2024-02-15 19:40:38 --> Total execution time: 0.0324
ERROR - 2024-02-15 19:40:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:40:38 --> Config Class Initialized
INFO - 2024-02-15 19:40:38 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:40:38 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:40:38 --> Utf8 Class Initialized
INFO - 2024-02-15 19:40:38 --> URI Class Initialized
INFO - 2024-02-15 19:40:38 --> Router Class Initialized
INFO - 2024-02-15 19:40:38 --> Output Class Initialized
INFO - 2024-02-15 19:40:38 --> Security Class Initialized
DEBUG - 2024-02-15 19:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:40:38 --> Input Class Initialized
INFO - 2024-02-15 19:40:38 --> Language Class Initialized
INFO - 2024-02-15 19:40:38 --> Loader Class Initialized
INFO - 2024-02-15 19:40:38 --> Helper loaded: url_helper
INFO - 2024-02-15 19:40:38 --> Helper loaded: file_helper
INFO - 2024-02-15 19:40:38 --> Helper loaded: form_helper
INFO - 2024-02-15 19:40:38 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:40:38 --> Controller Class Initialized
INFO - 2024-02-15 19:40:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 19:40:38 --> Final output sent to browser
DEBUG - 2024-02-15 19:40:38 --> Total execution time: 0.0217
ERROR - 2024-02-15 19:40:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:40:38 --> Config Class Initialized
INFO - 2024-02-15 19:40:38 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:40:38 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:40:38 --> Utf8 Class Initialized
INFO - 2024-02-15 19:40:38 --> URI Class Initialized
INFO - 2024-02-15 19:40:38 --> Router Class Initialized
INFO - 2024-02-15 19:40:38 --> Output Class Initialized
INFO - 2024-02-15 19:40:38 --> Security Class Initialized
DEBUG - 2024-02-15 19:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:40:38 --> Input Class Initialized
INFO - 2024-02-15 19:40:38 --> Language Class Initialized
INFO - 2024-02-15 19:40:38 --> Loader Class Initialized
INFO - 2024-02-15 19:40:38 --> Helper loaded: url_helper
INFO - 2024-02-15 19:40:38 --> Helper loaded: file_helper
INFO - 2024-02-15 19:40:38 --> Helper loaded: form_helper
INFO - 2024-02-15 19:40:38 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:40:38 --> Controller Class Initialized
INFO - 2024-02-15 19:40:38 --> Form Validation Class Initialized
INFO - 2024-02-15 19:40:38 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:40:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:40:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:40:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:42:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:42:02 --> Config Class Initialized
INFO - 2024-02-15 19:42:02 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:42:02 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:42:02 --> Utf8 Class Initialized
INFO - 2024-02-15 19:42:02 --> URI Class Initialized
INFO - 2024-02-15 19:42:02 --> Router Class Initialized
INFO - 2024-02-15 19:42:02 --> Output Class Initialized
INFO - 2024-02-15 19:42:02 --> Security Class Initialized
DEBUG - 2024-02-15 19:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:42:02 --> Input Class Initialized
INFO - 2024-02-15 19:42:02 --> Language Class Initialized
INFO - 2024-02-15 19:42:02 --> Loader Class Initialized
INFO - 2024-02-15 19:42:02 --> Helper loaded: url_helper
INFO - 2024-02-15 19:42:02 --> Helper loaded: file_helper
INFO - 2024-02-15 19:42:02 --> Helper loaded: form_helper
INFO - 2024-02-15 19:42:02 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:42:02 --> Controller Class Initialized
INFO - 2024-02-15 19:42:02 --> Form Validation Class Initialized
INFO - 2024-02-15 19:42:02 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:42:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:42:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:42:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:42:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:42:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:42:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:42:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:42:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:42:02 --> Final output sent to browser
DEBUG - 2024-02-15 19:42:02 --> Total execution time: 0.0386
ERROR - 2024-02-15 19:42:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:42:03 --> Config Class Initialized
INFO - 2024-02-15 19:42:03 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:42:03 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:42:03 --> Utf8 Class Initialized
INFO - 2024-02-15 19:42:03 --> URI Class Initialized
INFO - 2024-02-15 19:42:03 --> Router Class Initialized
INFO - 2024-02-15 19:42:03 --> Output Class Initialized
INFO - 2024-02-15 19:42:03 --> Security Class Initialized
DEBUG - 2024-02-15 19:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:42:03 --> Input Class Initialized
INFO - 2024-02-15 19:42:03 --> Language Class Initialized
INFO - 2024-02-15 19:42:03 --> Loader Class Initialized
INFO - 2024-02-15 19:42:03 --> Helper loaded: url_helper
INFO - 2024-02-15 19:42:03 --> Helper loaded: file_helper
INFO - 2024-02-15 19:42:03 --> Helper loaded: form_helper
INFO - 2024-02-15 19:42:03 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:42:03 --> Controller Class Initialized
INFO - 2024-02-15 19:42:03 --> Form Validation Class Initialized
INFO - 2024-02-15 19:42:03 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:42:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:42:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:42:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:42:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:42:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:42:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:42:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:42:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:42:03 --> Final output sent to browser
DEBUG - 2024-02-15 19:42:03 --> Total execution time: 0.0389
ERROR - 2024-02-15 19:42:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:42:03 --> Config Class Initialized
INFO - 2024-02-15 19:42:03 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:42:03 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:42:03 --> Utf8 Class Initialized
INFO - 2024-02-15 19:42:03 --> URI Class Initialized
INFO - 2024-02-15 19:42:03 --> Router Class Initialized
INFO - 2024-02-15 19:42:03 --> Output Class Initialized
INFO - 2024-02-15 19:42:03 --> Security Class Initialized
DEBUG - 2024-02-15 19:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:42:03 --> Input Class Initialized
INFO - 2024-02-15 19:42:03 --> Language Class Initialized
INFO - 2024-02-15 19:42:03 --> Loader Class Initialized
INFO - 2024-02-15 19:42:03 --> Helper loaded: url_helper
INFO - 2024-02-15 19:42:03 --> Helper loaded: file_helper
INFO - 2024-02-15 19:42:03 --> Helper loaded: form_helper
INFO - 2024-02-15 19:42:03 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:42:03 --> Controller Class Initialized
INFO - 2024-02-15 19:42:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 19:42:03 --> Final output sent to browser
DEBUG - 2024-02-15 19:42:03 --> Total execution time: 0.0260
ERROR - 2024-02-15 19:42:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:42:04 --> Config Class Initialized
INFO - 2024-02-15 19:42:04 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:42:04 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:42:04 --> Utf8 Class Initialized
INFO - 2024-02-15 19:42:04 --> URI Class Initialized
INFO - 2024-02-15 19:42:04 --> Router Class Initialized
INFO - 2024-02-15 19:42:04 --> Output Class Initialized
INFO - 2024-02-15 19:42:04 --> Security Class Initialized
DEBUG - 2024-02-15 19:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:42:04 --> Input Class Initialized
INFO - 2024-02-15 19:42:04 --> Language Class Initialized
INFO - 2024-02-15 19:42:04 --> Loader Class Initialized
INFO - 2024-02-15 19:42:04 --> Helper loaded: url_helper
INFO - 2024-02-15 19:42:04 --> Helper loaded: file_helper
INFO - 2024-02-15 19:42:04 --> Helper loaded: form_helper
INFO - 2024-02-15 19:42:04 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:42:04 --> Controller Class Initialized
INFO - 2024-02-15 19:42:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 19:42:04 --> Final output sent to browser
DEBUG - 2024-02-15 19:42:04 --> Total execution time: 0.0282
ERROR - 2024-02-15 19:42:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:42:04 --> Config Class Initialized
INFO - 2024-02-15 19:42:04 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:42:04 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:42:04 --> Utf8 Class Initialized
INFO - 2024-02-15 19:42:04 --> URI Class Initialized
INFO - 2024-02-15 19:42:04 --> Router Class Initialized
INFO - 2024-02-15 19:42:04 --> Output Class Initialized
INFO - 2024-02-15 19:42:04 --> Security Class Initialized
DEBUG - 2024-02-15 19:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:42:04 --> Input Class Initialized
INFO - 2024-02-15 19:42:04 --> Language Class Initialized
INFO - 2024-02-15 19:42:04 --> Loader Class Initialized
INFO - 2024-02-15 19:42:04 --> Helper loaded: url_helper
INFO - 2024-02-15 19:42:04 --> Helper loaded: file_helper
INFO - 2024-02-15 19:42:04 --> Helper loaded: form_helper
INFO - 2024-02-15 19:42:04 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:42:04 --> Controller Class Initialized
INFO - 2024-02-15 19:42:04 --> Form Validation Class Initialized
INFO - 2024-02-15 19:42:04 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:42:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:42:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:42:04 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:43:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:43:10 --> Config Class Initialized
INFO - 2024-02-15 19:43:10 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:43:10 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:43:10 --> Utf8 Class Initialized
INFO - 2024-02-15 19:43:10 --> URI Class Initialized
INFO - 2024-02-15 19:43:10 --> Router Class Initialized
INFO - 2024-02-15 19:43:10 --> Output Class Initialized
INFO - 2024-02-15 19:43:10 --> Security Class Initialized
DEBUG - 2024-02-15 19:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:43:10 --> Input Class Initialized
INFO - 2024-02-15 19:43:10 --> Language Class Initialized
INFO - 2024-02-15 19:43:10 --> Loader Class Initialized
INFO - 2024-02-15 19:43:10 --> Helper loaded: url_helper
INFO - 2024-02-15 19:43:10 --> Helper loaded: file_helper
INFO - 2024-02-15 19:43:10 --> Helper loaded: form_helper
INFO - 2024-02-15 19:43:10 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:43:10 --> Controller Class Initialized
INFO - 2024-02-15 19:43:10 --> Form Validation Class Initialized
INFO - 2024-02-15 19:43:10 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:43:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:43:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:43:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:43:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:43:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:43:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:43:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:43:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:43:10 --> Final output sent to browser
DEBUG - 2024-02-15 19:43:10 --> Total execution time: 0.0308
ERROR - 2024-02-15 19:43:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:43:10 --> Config Class Initialized
INFO - 2024-02-15 19:43:10 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:43:10 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:43:10 --> Utf8 Class Initialized
INFO - 2024-02-15 19:43:10 --> URI Class Initialized
INFO - 2024-02-15 19:43:10 --> Router Class Initialized
INFO - 2024-02-15 19:43:10 --> Output Class Initialized
INFO - 2024-02-15 19:43:10 --> Security Class Initialized
DEBUG - 2024-02-15 19:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:43:10 --> Input Class Initialized
INFO - 2024-02-15 19:43:10 --> Language Class Initialized
INFO - 2024-02-15 19:43:10 --> Loader Class Initialized
INFO - 2024-02-15 19:43:10 --> Helper loaded: url_helper
INFO - 2024-02-15 19:43:10 --> Helper loaded: file_helper
INFO - 2024-02-15 19:43:10 --> Helper loaded: form_helper
INFO - 2024-02-15 19:43:10 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:43:10 --> Controller Class Initialized
INFO - 2024-02-15 19:43:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 19:43:10 --> Final output sent to browser
DEBUG - 2024-02-15 19:43:10 --> Total execution time: 0.0307
ERROR - 2024-02-15 19:43:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:43:11 --> Config Class Initialized
INFO - 2024-02-15 19:43:11 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:43:11 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:43:11 --> Utf8 Class Initialized
INFO - 2024-02-15 19:43:11 --> URI Class Initialized
INFO - 2024-02-15 19:43:11 --> Router Class Initialized
INFO - 2024-02-15 19:43:11 --> Output Class Initialized
INFO - 2024-02-15 19:43:11 --> Security Class Initialized
DEBUG - 2024-02-15 19:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:43:11 --> Input Class Initialized
INFO - 2024-02-15 19:43:11 --> Language Class Initialized
INFO - 2024-02-15 19:43:11 --> Loader Class Initialized
INFO - 2024-02-15 19:43:11 --> Helper loaded: url_helper
INFO - 2024-02-15 19:43:11 --> Helper loaded: file_helper
INFO - 2024-02-15 19:43:11 --> Helper loaded: form_helper
INFO - 2024-02-15 19:43:11 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:43:11 --> Controller Class Initialized
INFO - 2024-02-15 19:43:11 --> Form Validation Class Initialized
INFO - 2024-02-15 19:43:11 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:43:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:43:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:43:11 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:44:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:44:11 --> Config Class Initialized
INFO - 2024-02-15 19:44:11 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:44:11 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:44:11 --> Utf8 Class Initialized
INFO - 2024-02-15 19:44:11 --> URI Class Initialized
INFO - 2024-02-15 19:44:11 --> Router Class Initialized
INFO - 2024-02-15 19:44:11 --> Output Class Initialized
INFO - 2024-02-15 19:44:11 --> Security Class Initialized
DEBUG - 2024-02-15 19:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:44:11 --> Input Class Initialized
INFO - 2024-02-15 19:44:11 --> Language Class Initialized
INFO - 2024-02-15 19:44:11 --> Loader Class Initialized
INFO - 2024-02-15 19:44:11 --> Helper loaded: url_helper
INFO - 2024-02-15 19:44:11 --> Helper loaded: file_helper
INFO - 2024-02-15 19:44:11 --> Helper loaded: form_helper
INFO - 2024-02-15 19:44:11 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:44:11 --> Controller Class Initialized
INFO - 2024-02-15 19:44:11 --> Form Validation Class Initialized
INFO - 2024-02-15 19:44:11 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:44:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:44:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:44:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:44:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:44:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:44:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:44:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:44:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:44:11 --> Final output sent to browser
DEBUG - 2024-02-15 19:44:11 --> Total execution time: 0.0321
ERROR - 2024-02-15 19:44:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:44:12 --> Config Class Initialized
INFO - 2024-02-15 19:44:12 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:44:12 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:44:12 --> Utf8 Class Initialized
INFO - 2024-02-15 19:44:12 --> URI Class Initialized
INFO - 2024-02-15 19:44:12 --> Router Class Initialized
INFO - 2024-02-15 19:44:12 --> Output Class Initialized
INFO - 2024-02-15 19:44:12 --> Security Class Initialized
DEBUG - 2024-02-15 19:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:44:12 --> Input Class Initialized
INFO - 2024-02-15 19:44:12 --> Language Class Initialized
INFO - 2024-02-15 19:44:12 --> Loader Class Initialized
INFO - 2024-02-15 19:44:12 --> Helper loaded: url_helper
INFO - 2024-02-15 19:44:12 --> Helper loaded: file_helper
INFO - 2024-02-15 19:44:12 --> Helper loaded: form_helper
INFO - 2024-02-15 19:44:12 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:44:12 --> Controller Class Initialized
INFO - 2024-02-15 19:44:12 --> Form Validation Class Initialized
INFO - 2024-02-15 19:44:12 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:44:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:44:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:44:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:44:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 19:44:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 19:44:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 19:44:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 19:44:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 19:44:12 --> Final output sent to browser
DEBUG - 2024-02-15 19:44:12 --> Total execution time: 0.0450
ERROR - 2024-02-15 19:44:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:44:14 --> Config Class Initialized
INFO - 2024-02-15 19:44:14 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:44:14 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:44:14 --> Utf8 Class Initialized
INFO - 2024-02-15 19:44:14 --> URI Class Initialized
INFO - 2024-02-15 19:44:14 --> Router Class Initialized
INFO - 2024-02-15 19:44:14 --> Output Class Initialized
INFO - 2024-02-15 19:44:14 --> Security Class Initialized
DEBUG - 2024-02-15 19:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:44:14 --> Input Class Initialized
INFO - 2024-02-15 19:44:14 --> Language Class Initialized
INFO - 2024-02-15 19:44:14 --> Loader Class Initialized
INFO - 2024-02-15 19:44:14 --> Helper loaded: url_helper
INFO - 2024-02-15 19:44:14 --> Helper loaded: file_helper
INFO - 2024-02-15 19:44:14 --> Helper loaded: form_helper
INFO - 2024-02-15 19:44:14 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:44:14 --> Controller Class Initialized
INFO - 2024-02-15 19:44:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 19:44:14 --> Final output sent to browser
DEBUG - 2024-02-15 19:44:14 --> Total execution time: 0.0204
ERROR - 2024-02-15 19:44:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:44:14 --> Config Class Initialized
INFO - 2024-02-15 19:44:14 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:44:14 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:44:14 --> Utf8 Class Initialized
INFO - 2024-02-15 19:44:14 --> URI Class Initialized
INFO - 2024-02-15 19:44:14 --> Router Class Initialized
INFO - 2024-02-15 19:44:14 --> Output Class Initialized
INFO - 2024-02-15 19:44:14 --> Security Class Initialized
DEBUG - 2024-02-15 19:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:44:14 --> Input Class Initialized
INFO - 2024-02-15 19:44:14 --> Language Class Initialized
INFO - 2024-02-15 19:44:14 --> Loader Class Initialized
INFO - 2024-02-15 19:44:14 --> Helper loaded: url_helper
INFO - 2024-02-15 19:44:14 --> Helper loaded: file_helper
INFO - 2024-02-15 19:44:14 --> Helper loaded: form_helper
INFO - 2024-02-15 19:44:14 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:44:14 --> Controller Class Initialized
INFO - 2024-02-15 19:44:14 --> Form Validation Class Initialized
INFO - 2024-02-15 19:44:14 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:44:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:44:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:44:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 19:44:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 19:44:30 --> Config Class Initialized
INFO - 2024-02-15 19:44:30 --> Hooks Class Initialized
DEBUG - 2024-02-15 19:44:30 --> UTF-8 Support Enabled
INFO - 2024-02-15 19:44:30 --> Utf8 Class Initialized
INFO - 2024-02-15 19:44:30 --> URI Class Initialized
INFO - 2024-02-15 19:44:30 --> Router Class Initialized
INFO - 2024-02-15 19:44:30 --> Output Class Initialized
INFO - 2024-02-15 19:44:30 --> Security Class Initialized
DEBUG - 2024-02-15 19:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 19:44:30 --> Input Class Initialized
INFO - 2024-02-15 19:44:30 --> Language Class Initialized
INFO - 2024-02-15 19:44:30 --> Loader Class Initialized
INFO - 2024-02-15 19:44:30 --> Helper loaded: url_helper
INFO - 2024-02-15 19:44:30 --> Helper loaded: file_helper
INFO - 2024-02-15 19:44:30 --> Helper loaded: form_helper
INFO - 2024-02-15 19:44:30 --> Database Driver Class Initialized
DEBUG - 2024-02-15 19:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 19:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 19:44:30 --> Controller Class Initialized
INFO - 2024-02-15 19:44:30 --> Form Validation Class Initialized
INFO - 2024-02-15 19:44:30 --> Model "MasterModel" initialized
INFO - 2024-02-15 19:44:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 19:44:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 19:44:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 19:44:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 19:44:30 --> Final output sent to browser
DEBUG - 2024-02-15 19:44:30 --> Total execution time: 0.0339
ERROR - 2024-02-15 20:19:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:19:29 --> Config Class Initialized
INFO - 2024-02-15 20:19:29 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:19:29 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:19:29 --> Utf8 Class Initialized
INFO - 2024-02-15 20:19:29 --> URI Class Initialized
INFO - 2024-02-15 20:19:29 --> Router Class Initialized
INFO - 2024-02-15 20:19:29 --> Output Class Initialized
INFO - 2024-02-15 20:19:29 --> Security Class Initialized
DEBUG - 2024-02-15 20:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:19:29 --> Input Class Initialized
INFO - 2024-02-15 20:19:29 --> Language Class Initialized
INFO - 2024-02-15 20:19:29 --> Loader Class Initialized
INFO - 2024-02-15 20:19:29 --> Helper loaded: url_helper
INFO - 2024-02-15 20:19:29 --> Helper loaded: file_helper
INFO - 2024-02-15 20:19:29 --> Helper loaded: form_helper
INFO - 2024-02-15 20:19:29 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:19:29 --> Controller Class Initialized
INFO - 2024-02-15 20:19:29 --> Form Validation Class Initialized
INFO - 2024-02-15 20:19:29 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:19:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:19:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:19:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:19:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:19:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:19:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:19:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:19:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:19:29 --> Final output sent to browser
DEBUG - 2024-02-15 20:19:29 --> Total execution time: 0.0412
ERROR - 2024-02-15 20:19:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:19:30 --> Config Class Initialized
INFO - 2024-02-15 20:19:30 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:19:30 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:19:30 --> Utf8 Class Initialized
INFO - 2024-02-15 20:19:30 --> URI Class Initialized
INFO - 2024-02-15 20:19:30 --> Router Class Initialized
INFO - 2024-02-15 20:19:30 --> Output Class Initialized
INFO - 2024-02-15 20:19:30 --> Security Class Initialized
DEBUG - 2024-02-15 20:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:19:30 --> Input Class Initialized
INFO - 2024-02-15 20:19:30 --> Language Class Initialized
INFO - 2024-02-15 20:19:30 --> Loader Class Initialized
INFO - 2024-02-15 20:19:30 --> Helper loaded: url_helper
INFO - 2024-02-15 20:19:30 --> Helper loaded: file_helper
INFO - 2024-02-15 20:19:30 --> Helper loaded: form_helper
INFO - 2024-02-15 20:19:30 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:19:30 --> Controller Class Initialized
INFO - 2024-02-15 20:19:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 20:19:30 --> Final output sent to browser
DEBUG - 2024-02-15 20:19:30 --> Total execution time: 0.0339
ERROR - 2024-02-15 20:19:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:19:30 --> Config Class Initialized
INFO - 2024-02-15 20:19:30 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:19:30 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:19:30 --> Utf8 Class Initialized
INFO - 2024-02-15 20:19:30 --> URI Class Initialized
INFO - 2024-02-15 20:19:30 --> Router Class Initialized
INFO - 2024-02-15 20:19:30 --> Output Class Initialized
INFO - 2024-02-15 20:19:30 --> Security Class Initialized
DEBUG - 2024-02-15 20:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:19:30 --> Input Class Initialized
INFO - 2024-02-15 20:19:30 --> Language Class Initialized
INFO - 2024-02-15 20:19:30 --> Loader Class Initialized
INFO - 2024-02-15 20:19:30 --> Helper loaded: url_helper
INFO - 2024-02-15 20:19:30 --> Helper loaded: file_helper
INFO - 2024-02-15 20:19:30 --> Helper loaded: form_helper
INFO - 2024-02-15 20:19:30 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:19:30 --> Controller Class Initialized
INFO - 2024-02-15 20:19:30 --> Form Validation Class Initialized
INFO - 2024-02-15 20:19:30 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:19:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:19:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:19:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:19:45 --> Config Class Initialized
INFO - 2024-02-15 20:19:45 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:19:45 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:19:45 --> Utf8 Class Initialized
INFO - 2024-02-15 20:19:45 --> URI Class Initialized
INFO - 2024-02-15 20:19:45 --> Router Class Initialized
INFO - 2024-02-15 20:19:45 --> Output Class Initialized
INFO - 2024-02-15 20:19:45 --> Security Class Initialized
DEBUG - 2024-02-15 20:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:19:45 --> Input Class Initialized
INFO - 2024-02-15 20:19:45 --> Language Class Initialized
INFO - 2024-02-15 20:19:45 --> Loader Class Initialized
INFO - 2024-02-15 20:19:45 --> Helper loaded: url_helper
INFO - 2024-02-15 20:19:45 --> Helper loaded: file_helper
INFO - 2024-02-15 20:19:45 --> Helper loaded: form_helper
INFO - 2024-02-15 20:19:45 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:19:45 --> Controller Class Initialized
INFO - 2024-02-15 20:19:45 --> Form Validation Class Initialized
INFO - 2024-02-15 20:19:45 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:19:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:19:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:19:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:19:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:19:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:19:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:19:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:19:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:19:45 --> Final output sent to browser
DEBUG - 2024-02-15 20:19:45 --> Total execution time: 0.0451
ERROR - 2024-02-15 20:19:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:19:46 --> Config Class Initialized
INFO - 2024-02-15 20:19:46 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:19:46 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:19:46 --> Utf8 Class Initialized
INFO - 2024-02-15 20:19:46 --> URI Class Initialized
INFO - 2024-02-15 20:19:46 --> Router Class Initialized
INFO - 2024-02-15 20:19:46 --> Output Class Initialized
INFO - 2024-02-15 20:19:46 --> Security Class Initialized
DEBUG - 2024-02-15 20:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:19:46 --> Input Class Initialized
INFO - 2024-02-15 20:19:46 --> Language Class Initialized
INFO - 2024-02-15 20:19:46 --> Loader Class Initialized
INFO - 2024-02-15 20:19:46 --> Helper loaded: url_helper
INFO - 2024-02-15 20:19:46 --> Helper loaded: file_helper
INFO - 2024-02-15 20:19:46 --> Helper loaded: form_helper
INFO - 2024-02-15 20:19:46 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:19:46 --> Controller Class Initialized
INFO - 2024-02-15 20:19:46 --> Form Validation Class Initialized
INFO - 2024-02-15 20:19:46 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:19:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:19:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:19:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:20:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:20:45 --> Config Class Initialized
INFO - 2024-02-15 20:20:45 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:20:45 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:20:45 --> Utf8 Class Initialized
INFO - 2024-02-15 20:20:45 --> URI Class Initialized
INFO - 2024-02-15 20:20:45 --> Router Class Initialized
INFO - 2024-02-15 20:20:45 --> Output Class Initialized
INFO - 2024-02-15 20:20:45 --> Security Class Initialized
DEBUG - 2024-02-15 20:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:20:46 --> Input Class Initialized
INFO - 2024-02-15 20:20:46 --> Language Class Initialized
INFO - 2024-02-15 20:20:46 --> Loader Class Initialized
INFO - 2024-02-15 20:20:46 --> Helper loaded: url_helper
INFO - 2024-02-15 20:20:46 --> Helper loaded: file_helper
INFO - 2024-02-15 20:20:46 --> Helper loaded: form_helper
INFO - 2024-02-15 20:20:46 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:20:46 --> Controller Class Initialized
INFO - 2024-02-15 20:20:46 --> Form Validation Class Initialized
INFO - 2024-02-15 20:20:46 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:20:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:20:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:20:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:20:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:20:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:20:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:20:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:20:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:20:46 --> Final output sent to browser
DEBUG - 2024-02-15 20:20:46 --> Total execution time: 0.0571
ERROR - 2024-02-15 20:20:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:20:46 --> Config Class Initialized
INFO - 2024-02-15 20:20:46 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:20:46 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:20:46 --> Utf8 Class Initialized
INFO - 2024-02-15 20:20:46 --> URI Class Initialized
INFO - 2024-02-15 20:20:46 --> Router Class Initialized
INFO - 2024-02-15 20:20:46 --> Output Class Initialized
INFO - 2024-02-15 20:20:46 --> Security Class Initialized
DEBUG - 2024-02-15 20:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:20:46 --> Input Class Initialized
INFO - 2024-02-15 20:20:46 --> Language Class Initialized
INFO - 2024-02-15 20:20:46 --> Loader Class Initialized
INFO - 2024-02-15 20:20:46 --> Helper loaded: url_helper
INFO - 2024-02-15 20:20:46 --> Helper loaded: file_helper
INFO - 2024-02-15 20:20:46 --> Helper loaded: form_helper
INFO - 2024-02-15 20:20:46 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:20:46 --> Controller Class Initialized
INFO - 2024-02-15 20:20:46 --> Form Validation Class Initialized
INFO - 2024-02-15 20:20:46 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:20:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:20:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:20:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:20:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:20:47 --> Config Class Initialized
INFO - 2024-02-15 20:20:47 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:20:47 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:20:47 --> Utf8 Class Initialized
INFO - 2024-02-15 20:20:47 --> URI Class Initialized
INFO - 2024-02-15 20:20:47 --> Router Class Initialized
INFO - 2024-02-15 20:20:47 --> Output Class Initialized
INFO - 2024-02-15 20:20:47 --> Security Class Initialized
DEBUG - 2024-02-15 20:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:20:47 --> Input Class Initialized
INFO - 2024-02-15 20:20:47 --> Language Class Initialized
INFO - 2024-02-15 20:20:47 --> Loader Class Initialized
INFO - 2024-02-15 20:20:47 --> Helper loaded: url_helper
INFO - 2024-02-15 20:20:47 --> Helper loaded: file_helper
INFO - 2024-02-15 20:20:47 --> Helper loaded: form_helper
INFO - 2024-02-15 20:20:47 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:20:47 --> Controller Class Initialized
INFO - 2024-02-15 20:20:47 --> Form Validation Class Initialized
INFO - 2024-02-15 20:20:47 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:20:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:20:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:20:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:20:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:20:47 --> Final output sent to browser
DEBUG - 2024-02-15 20:20:47 --> Total execution time: 0.0411
ERROR - 2024-02-15 20:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:20:57 --> Config Class Initialized
INFO - 2024-02-15 20:20:57 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:20:57 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:20:57 --> Utf8 Class Initialized
INFO - 2024-02-15 20:20:57 --> URI Class Initialized
INFO - 2024-02-15 20:20:57 --> Router Class Initialized
INFO - 2024-02-15 20:20:57 --> Output Class Initialized
INFO - 2024-02-15 20:20:57 --> Security Class Initialized
DEBUG - 2024-02-15 20:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:20:57 --> Input Class Initialized
INFO - 2024-02-15 20:20:57 --> Language Class Initialized
INFO - 2024-02-15 20:20:57 --> Loader Class Initialized
INFO - 2024-02-15 20:20:57 --> Helper loaded: url_helper
INFO - 2024-02-15 20:20:57 --> Helper loaded: file_helper
INFO - 2024-02-15 20:20:57 --> Helper loaded: form_helper
INFO - 2024-02-15 20:20:58 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:20:58 --> Controller Class Initialized
INFO - 2024-02-15 20:20:58 --> Form Validation Class Initialized
INFO - 2024-02-15 20:20:58 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:20:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:20:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:20:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:20:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:20:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:20:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:20:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:20:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:20:58 --> Final output sent to browser
DEBUG - 2024-02-15 20:20:58 --> Total execution time: 0.0440
ERROR - 2024-02-15 20:20:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:20:58 --> Config Class Initialized
INFO - 2024-02-15 20:20:58 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:20:58 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:20:58 --> Utf8 Class Initialized
INFO - 2024-02-15 20:20:58 --> URI Class Initialized
INFO - 2024-02-15 20:20:58 --> Router Class Initialized
INFO - 2024-02-15 20:20:58 --> Output Class Initialized
INFO - 2024-02-15 20:20:58 --> Security Class Initialized
DEBUG - 2024-02-15 20:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:20:58 --> Input Class Initialized
INFO - 2024-02-15 20:20:58 --> Language Class Initialized
INFO - 2024-02-15 20:20:58 --> Loader Class Initialized
INFO - 2024-02-15 20:20:58 --> Helper loaded: url_helper
INFO - 2024-02-15 20:20:58 --> Helper loaded: file_helper
INFO - 2024-02-15 20:20:58 --> Helper loaded: form_helper
INFO - 2024-02-15 20:20:58 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:20:58 --> Controller Class Initialized
INFO - 2024-02-15 20:20:58 --> Form Validation Class Initialized
INFO - 2024-02-15 20:20:58 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:20:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:20:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:20:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:21:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:21:00 --> Config Class Initialized
INFO - 2024-02-15 20:21:00 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:21:00 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:21:00 --> Utf8 Class Initialized
INFO - 2024-02-15 20:21:00 --> URI Class Initialized
INFO - 2024-02-15 20:21:00 --> Router Class Initialized
INFO - 2024-02-15 20:21:00 --> Output Class Initialized
INFO - 2024-02-15 20:21:00 --> Security Class Initialized
DEBUG - 2024-02-15 20:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:21:00 --> Input Class Initialized
INFO - 2024-02-15 20:21:00 --> Language Class Initialized
INFO - 2024-02-15 20:21:00 --> Loader Class Initialized
INFO - 2024-02-15 20:21:00 --> Helper loaded: url_helper
INFO - 2024-02-15 20:21:00 --> Helper loaded: file_helper
INFO - 2024-02-15 20:21:00 --> Helper loaded: form_helper
INFO - 2024-02-15 20:21:00 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:21:00 --> Controller Class Initialized
INFO - 2024-02-15 20:21:00 --> Form Validation Class Initialized
INFO - 2024-02-15 20:21:00 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:21:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:21:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:21:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:21:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:21:00 --> Final output sent to browser
DEBUG - 2024-02-15 20:21:00 --> Total execution time: 0.0474
ERROR - 2024-02-15 20:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:21:12 --> Config Class Initialized
INFO - 2024-02-15 20:21:12 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:21:12 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:21:12 --> Utf8 Class Initialized
INFO - 2024-02-15 20:21:12 --> URI Class Initialized
INFO - 2024-02-15 20:21:12 --> Router Class Initialized
INFO - 2024-02-15 20:21:12 --> Output Class Initialized
INFO - 2024-02-15 20:21:12 --> Security Class Initialized
DEBUG - 2024-02-15 20:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:21:12 --> Input Class Initialized
INFO - 2024-02-15 20:21:12 --> Language Class Initialized
INFO - 2024-02-15 20:21:12 --> Loader Class Initialized
INFO - 2024-02-15 20:21:12 --> Helper loaded: url_helper
INFO - 2024-02-15 20:21:12 --> Helper loaded: file_helper
INFO - 2024-02-15 20:21:12 --> Helper loaded: form_helper
INFO - 2024-02-15 20:21:12 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:21:12 --> Controller Class Initialized
INFO - 2024-02-15 20:21:12 --> Form Validation Class Initialized
INFO - 2024-02-15 20:21:12 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:21:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:21:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:21:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:21:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:21:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:21:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:21:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:21:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:21:12 --> Final output sent to browser
DEBUG - 2024-02-15 20:21:12 --> Total execution time: 0.0535
ERROR - 2024-02-15 20:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:21:12 --> Config Class Initialized
INFO - 2024-02-15 20:21:12 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:21:12 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:21:12 --> Utf8 Class Initialized
INFO - 2024-02-15 20:21:12 --> URI Class Initialized
INFO - 2024-02-15 20:21:12 --> Router Class Initialized
INFO - 2024-02-15 20:21:12 --> Output Class Initialized
INFO - 2024-02-15 20:21:12 --> Security Class Initialized
DEBUG - 2024-02-15 20:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:21:12 --> Input Class Initialized
INFO - 2024-02-15 20:21:12 --> Language Class Initialized
INFO - 2024-02-15 20:21:12 --> Loader Class Initialized
INFO - 2024-02-15 20:21:12 --> Helper loaded: url_helper
INFO - 2024-02-15 20:21:12 --> Helper loaded: file_helper
INFO - 2024-02-15 20:21:12 --> Helper loaded: form_helper
INFO - 2024-02-15 20:21:12 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:21:12 --> Controller Class Initialized
INFO - 2024-02-15 20:21:12 --> Form Validation Class Initialized
INFO - 2024-02-15 20:21:12 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:21:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:21:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:21:12 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:21:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:21:15 --> Config Class Initialized
INFO - 2024-02-15 20:21:15 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:21:15 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:21:15 --> Utf8 Class Initialized
INFO - 2024-02-15 20:21:15 --> URI Class Initialized
INFO - 2024-02-15 20:21:15 --> Router Class Initialized
INFO - 2024-02-15 20:21:15 --> Output Class Initialized
INFO - 2024-02-15 20:21:15 --> Security Class Initialized
DEBUG - 2024-02-15 20:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:21:15 --> Input Class Initialized
INFO - 2024-02-15 20:21:15 --> Language Class Initialized
INFO - 2024-02-15 20:21:15 --> Loader Class Initialized
INFO - 2024-02-15 20:21:15 --> Helper loaded: url_helper
INFO - 2024-02-15 20:21:15 --> Helper loaded: file_helper
INFO - 2024-02-15 20:21:15 --> Helper loaded: form_helper
INFO - 2024-02-15 20:21:15 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:21:15 --> Controller Class Initialized
INFO - 2024-02-15 20:21:15 --> Form Validation Class Initialized
INFO - 2024-02-15 20:21:15 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:21:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:21:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:21:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:21:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:21:15 --> Final output sent to browser
DEBUG - 2024-02-15 20:21:15 --> Total execution time: 0.0399
ERROR - 2024-02-15 20:21:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:21:37 --> Config Class Initialized
INFO - 2024-02-15 20:21:37 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:21:37 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:21:37 --> Utf8 Class Initialized
INFO - 2024-02-15 20:21:37 --> URI Class Initialized
INFO - 2024-02-15 20:21:37 --> Router Class Initialized
INFO - 2024-02-15 20:21:37 --> Output Class Initialized
INFO - 2024-02-15 20:21:37 --> Security Class Initialized
DEBUG - 2024-02-15 20:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:21:37 --> Input Class Initialized
INFO - 2024-02-15 20:21:37 --> Language Class Initialized
INFO - 2024-02-15 20:21:37 --> Loader Class Initialized
INFO - 2024-02-15 20:21:37 --> Helper loaded: url_helper
INFO - 2024-02-15 20:21:37 --> Helper loaded: file_helper
INFO - 2024-02-15 20:21:37 --> Helper loaded: form_helper
INFO - 2024-02-15 20:21:37 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:21:37 --> Controller Class Initialized
INFO - 2024-02-15 20:21:37 --> Form Validation Class Initialized
INFO - 2024-02-15 20:21:37 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:21:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:21:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:21:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:21:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:21:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:21:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:21:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:21:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:21:37 --> Final output sent to browser
DEBUG - 2024-02-15 20:21:37 --> Total execution time: 0.0492
ERROR - 2024-02-15 20:21:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:21:37 --> Config Class Initialized
INFO - 2024-02-15 20:21:37 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:21:37 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:21:37 --> Utf8 Class Initialized
INFO - 2024-02-15 20:21:37 --> URI Class Initialized
INFO - 2024-02-15 20:21:37 --> Router Class Initialized
INFO - 2024-02-15 20:21:37 --> Output Class Initialized
INFO - 2024-02-15 20:21:37 --> Security Class Initialized
DEBUG - 2024-02-15 20:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:21:37 --> Input Class Initialized
INFO - 2024-02-15 20:21:37 --> Language Class Initialized
INFO - 2024-02-15 20:21:37 --> Loader Class Initialized
INFO - 2024-02-15 20:21:37 --> Helper loaded: url_helper
INFO - 2024-02-15 20:21:37 --> Helper loaded: file_helper
INFO - 2024-02-15 20:21:37 --> Helper loaded: form_helper
INFO - 2024-02-15 20:21:37 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:21:37 --> Controller Class Initialized
INFO - 2024-02-15 20:21:37 --> Form Validation Class Initialized
INFO - 2024-02-15 20:21:37 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:21:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:21:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:21:37 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:21:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:21:39 --> Config Class Initialized
INFO - 2024-02-15 20:21:39 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:21:39 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:21:39 --> Utf8 Class Initialized
INFO - 2024-02-15 20:21:39 --> URI Class Initialized
INFO - 2024-02-15 20:21:39 --> Router Class Initialized
INFO - 2024-02-15 20:21:39 --> Output Class Initialized
INFO - 2024-02-15 20:21:39 --> Security Class Initialized
DEBUG - 2024-02-15 20:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:21:39 --> Input Class Initialized
INFO - 2024-02-15 20:21:39 --> Language Class Initialized
INFO - 2024-02-15 20:21:39 --> Loader Class Initialized
INFO - 2024-02-15 20:21:39 --> Helper loaded: url_helper
INFO - 2024-02-15 20:21:39 --> Helper loaded: file_helper
INFO - 2024-02-15 20:21:39 --> Helper loaded: form_helper
INFO - 2024-02-15 20:21:39 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:21:39 --> Controller Class Initialized
INFO - 2024-02-15 20:21:39 --> Form Validation Class Initialized
INFO - 2024-02-15 20:21:39 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:21:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:21:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:21:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:21:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:21:39 --> Final output sent to browser
DEBUG - 2024-02-15 20:21:39 --> Total execution time: 0.0459
ERROR - 2024-02-15 20:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:21:58 --> Config Class Initialized
INFO - 2024-02-15 20:21:58 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:21:58 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:21:58 --> Utf8 Class Initialized
INFO - 2024-02-15 20:21:58 --> URI Class Initialized
INFO - 2024-02-15 20:21:58 --> Router Class Initialized
INFO - 2024-02-15 20:21:58 --> Output Class Initialized
INFO - 2024-02-15 20:21:58 --> Security Class Initialized
DEBUG - 2024-02-15 20:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:21:58 --> Input Class Initialized
INFO - 2024-02-15 20:21:58 --> Language Class Initialized
INFO - 2024-02-15 20:21:58 --> Loader Class Initialized
INFO - 2024-02-15 20:21:58 --> Helper loaded: url_helper
INFO - 2024-02-15 20:21:58 --> Helper loaded: file_helper
INFO - 2024-02-15 20:21:58 --> Helper loaded: form_helper
INFO - 2024-02-15 20:21:58 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:21:58 --> Controller Class Initialized
INFO - 2024-02-15 20:21:58 --> Form Validation Class Initialized
INFO - 2024-02-15 20:21:58 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:21:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:21:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:21:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:21:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:21:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:21:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:21:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:21:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:21:58 --> Final output sent to browser
DEBUG - 2024-02-15 20:21:58 --> Total execution time: 0.0651
ERROR - 2024-02-15 20:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:21:58 --> Config Class Initialized
INFO - 2024-02-15 20:21:58 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:21:58 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:21:58 --> Utf8 Class Initialized
INFO - 2024-02-15 20:21:58 --> URI Class Initialized
INFO - 2024-02-15 20:21:58 --> Router Class Initialized
INFO - 2024-02-15 20:21:58 --> Output Class Initialized
INFO - 2024-02-15 20:21:58 --> Security Class Initialized
DEBUG - 2024-02-15 20:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:21:58 --> Input Class Initialized
INFO - 2024-02-15 20:21:58 --> Language Class Initialized
INFO - 2024-02-15 20:21:58 --> Loader Class Initialized
INFO - 2024-02-15 20:21:58 --> Helper loaded: url_helper
INFO - 2024-02-15 20:21:58 --> Helper loaded: file_helper
INFO - 2024-02-15 20:21:58 --> Helper loaded: form_helper
INFO - 2024-02-15 20:21:58 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:21:58 --> Controller Class Initialized
INFO - 2024-02-15 20:21:58 --> Form Validation Class Initialized
INFO - 2024-02-15 20:21:58 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:21:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:21:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:21:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:22:01 --> Config Class Initialized
INFO - 2024-02-15 20:22:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:22:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:22:01 --> Utf8 Class Initialized
INFO - 2024-02-15 20:22:01 --> URI Class Initialized
INFO - 2024-02-15 20:22:01 --> Router Class Initialized
INFO - 2024-02-15 20:22:01 --> Output Class Initialized
INFO - 2024-02-15 20:22:01 --> Security Class Initialized
DEBUG - 2024-02-15 20:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:22:01 --> Input Class Initialized
INFO - 2024-02-15 20:22:01 --> Language Class Initialized
INFO - 2024-02-15 20:22:01 --> Loader Class Initialized
INFO - 2024-02-15 20:22:01 --> Helper loaded: url_helper
INFO - 2024-02-15 20:22:01 --> Helper loaded: file_helper
INFO - 2024-02-15 20:22:01 --> Helper loaded: form_helper
INFO - 2024-02-15 20:22:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:22:01 --> Controller Class Initialized
INFO - 2024-02-15 20:22:01 --> Form Validation Class Initialized
INFO - 2024-02-15 20:22:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:22:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:22:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:22:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:22:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:22:01 --> Final output sent to browser
DEBUG - 2024-02-15 20:22:01 --> Total execution time: 0.0457
ERROR - 2024-02-15 20:22:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:22:44 --> Config Class Initialized
INFO - 2024-02-15 20:22:44 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:22:44 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:22:44 --> Utf8 Class Initialized
INFO - 2024-02-15 20:22:44 --> URI Class Initialized
INFO - 2024-02-15 20:22:44 --> Router Class Initialized
INFO - 2024-02-15 20:22:44 --> Output Class Initialized
INFO - 2024-02-15 20:22:44 --> Security Class Initialized
DEBUG - 2024-02-15 20:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:22:44 --> Input Class Initialized
INFO - 2024-02-15 20:22:44 --> Language Class Initialized
INFO - 2024-02-15 20:22:44 --> Loader Class Initialized
INFO - 2024-02-15 20:22:44 --> Helper loaded: url_helper
INFO - 2024-02-15 20:22:44 --> Helper loaded: file_helper
INFO - 2024-02-15 20:22:44 --> Helper loaded: form_helper
INFO - 2024-02-15 20:22:44 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:22:44 --> Controller Class Initialized
INFO - 2024-02-15 20:22:44 --> Form Validation Class Initialized
INFO - 2024-02-15 20:22:44 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:22:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:22:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:22:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:22:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:22:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:22:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:22:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:22:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:22:44 --> Final output sent to browser
DEBUG - 2024-02-15 20:22:44 --> Total execution time: 0.0344
ERROR - 2024-02-15 20:24:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:24:49 --> Config Class Initialized
INFO - 2024-02-15 20:24:49 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:24:49 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:24:49 --> Utf8 Class Initialized
INFO - 2024-02-15 20:24:49 --> URI Class Initialized
INFO - 2024-02-15 20:24:49 --> Router Class Initialized
INFO - 2024-02-15 20:24:49 --> Output Class Initialized
INFO - 2024-02-15 20:24:49 --> Security Class Initialized
DEBUG - 2024-02-15 20:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:24:49 --> Input Class Initialized
INFO - 2024-02-15 20:24:49 --> Language Class Initialized
INFO - 2024-02-15 20:24:49 --> Loader Class Initialized
INFO - 2024-02-15 20:24:49 --> Helper loaded: url_helper
INFO - 2024-02-15 20:24:49 --> Helper loaded: file_helper
INFO - 2024-02-15 20:24:49 --> Helper loaded: form_helper
INFO - 2024-02-15 20:24:49 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:24:49 --> Controller Class Initialized
INFO - 2024-02-15 20:24:49 --> Form Validation Class Initialized
INFO - 2024-02-15 20:24:49 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:24:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:24:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:24:49 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:24:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:24:50 --> Config Class Initialized
INFO - 2024-02-15 20:24:50 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:24:50 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:24:50 --> Utf8 Class Initialized
INFO - 2024-02-15 20:24:50 --> URI Class Initialized
INFO - 2024-02-15 20:24:50 --> Router Class Initialized
INFO - 2024-02-15 20:24:50 --> Output Class Initialized
INFO - 2024-02-15 20:24:50 --> Security Class Initialized
DEBUG - 2024-02-15 20:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:24:50 --> Input Class Initialized
INFO - 2024-02-15 20:24:50 --> Language Class Initialized
INFO - 2024-02-15 20:24:50 --> Loader Class Initialized
INFO - 2024-02-15 20:24:50 --> Helper loaded: url_helper
INFO - 2024-02-15 20:24:50 --> Helper loaded: file_helper
INFO - 2024-02-15 20:24:50 --> Helper loaded: form_helper
INFO - 2024-02-15 20:24:50 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:24:50 --> Controller Class Initialized
INFO - 2024-02-15 20:24:50 --> Form Validation Class Initialized
INFO - 2024-02-15 20:24:50 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:24:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:24:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:24:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:24:50 --> Final output sent to browser
DEBUG - 2024-02-15 20:24:50 --> Total execution time: 0.0541
ERROR - 2024-02-15 20:29:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:29:33 --> Config Class Initialized
INFO - 2024-02-15 20:29:33 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:29:33 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:29:33 --> Utf8 Class Initialized
INFO - 2024-02-15 20:29:33 --> URI Class Initialized
INFO - 2024-02-15 20:29:33 --> Router Class Initialized
INFO - 2024-02-15 20:29:33 --> Output Class Initialized
INFO - 2024-02-15 20:29:33 --> Security Class Initialized
DEBUG - 2024-02-15 20:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:29:33 --> Input Class Initialized
INFO - 2024-02-15 20:29:33 --> Language Class Initialized
INFO - 2024-02-15 20:29:33 --> Loader Class Initialized
INFO - 2024-02-15 20:29:33 --> Helper loaded: url_helper
INFO - 2024-02-15 20:29:33 --> Helper loaded: file_helper
INFO - 2024-02-15 20:29:33 --> Helper loaded: form_helper
INFO - 2024-02-15 20:29:33 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:29:33 --> Controller Class Initialized
INFO - 2024-02-15 20:29:33 --> Form Validation Class Initialized
INFO - 2024-02-15 20:29:33 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:29:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:29:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:29:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:29:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:29:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:29:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:29:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:29:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:29:33 --> Final output sent to browser
DEBUG - 2024-02-15 20:29:33 --> Total execution time: 0.0406
ERROR - 2024-02-15 20:29:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:29:34 --> Config Class Initialized
INFO - 2024-02-15 20:29:34 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:29:34 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:29:34 --> Utf8 Class Initialized
INFO - 2024-02-15 20:29:34 --> URI Class Initialized
INFO - 2024-02-15 20:29:34 --> Router Class Initialized
INFO - 2024-02-15 20:29:34 --> Output Class Initialized
INFO - 2024-02-15 20:29:34 --> Security Class Initialized
DEBUG - 2024-02-15 20:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:29:34 --> Input Class Initialized
INFO - 2024-02-15 20:29:34 --> Language Class Initialized
INFO - 2024-02-15 20:29:34 --> Loader Class Initialized
INFO - 2024-02-15 20:29:34 --> Helper loaded: url_helper
INFO - 2024-02-15 20:29:34 --> Helper loaded: file_helper
INFO - 2024-02-15 20:29:34 --> Helper loaded: form_helper
INFO - 2024-02-15 20:29:34 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:29:34 --> Controller Class Initialized
INFO - 2024-02-15 20:29:34 --> Form Validation Class Initialized
INFO - 2024-02-15 20:29:34 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:29:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:29:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:29:34 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:29:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:29:36 --> Config Class Initialized
INFO - 2024-02-15 20:29:36 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:29:36 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:29:36 --> Utf8 Class Initialized
INFO - 2024-02-15 20:29:36 --> URI Class Initialized
INFO - 2024-02-15 20:29:36 --> Router Class Initialized
INFO - 2024-02-15 20:29:36 --> Output Class Initialized
INFO - 2024-02-15 20:29:36 --> Security Class Initialized
DEBUG - 2024-02-15 20:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:29:36 --> Input Class Initialized
INFO - 2024-02-15 20:29:36 --> Language Class Initialized
INFO - 2024-02-15 20:29:36 --> Loader Class Initialized
INFO - 2024-02-15 20:29:36 --> Helper loaded: url_helper
INFO - 2024-02-15 20:29:36 --> Helper loaded: file_helper
INFO - 2024-02-15 20:29:36 --> Helper loaded: form_helper
INFO - 2024-02-15 20:29:36 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:29:36 --> Controller Class Initialized
INFO - 2024-02-15 20:29:36 --> Form Validation Class Initialized
INFO - 2024-02-15 20:29:36 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:29:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:29:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:29:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:29:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:29:37 --> Final output sent to browser
DEBUG - 2024-02-15 20:29:37 --> Total execution time: 0.0442
ERROR - 2024-02-15 20:31:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:31:05 --> Config Class Initialized
INFO - 2024-02-15 20:31:05 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:31:05 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:31:05 --> Utf8 Class Initialized
INFO - 2024-02-15 20:31:05 --> URI Class Initialized
INFO - 2024-02-15 20:31:05 --> Router Class Initialized
INFO - 2024-02-15 20:31:05 --> Output Class Initialized
INFO - 2024-02-15 20:31:05 --> Security Class Initialized
DEBUG - 2024-02-15 20:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:31:05 --> Input Class Initialized
INFO - 2024-02-15 20:31:05 --> Language Class Initialized
INFO - 2024-02-15 20:31:05 --> Loader Class Initialized
INFO - 2024-02-15 20:31:05 --> Helper loaded: url_helper
INFO - 2024-02-15 20:31:05 --> Helper loaded: file_helper
INFO - 2024-02-15 20:31:05 --> Helper loaded: form_helper
INFO - 2024-02-15 20:31:05 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:31:05 --> Controller Class Initialized
INFO - 2024-02-15 20:31:05 --> Form Validation Class Initialized
INFO - 2024-02-15 20:31:05 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:31:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:31:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:31:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:31:05 --> Final output sent to browser
DEBUG - 2024-02-15 20:31:05 --> Total execution time: 0.0590
ERROR - 2024-02-15 20:31:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:31:06 --> Config Class Initialized
INFO - 2024-02-15 20:31:06 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:31:06 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:31:06 --> Utf8 Class Initialized
INFO - 2024-02-15 20:31:06 --> URI Class Initialized
INFO - 2024-02-15 20:31:06 --> Router Class Initialized
INFO - 2024-02-15 20:31:06 --> Output Class Initialized
INFO - 2024-02-15 20:31:06 --> Security Class Initialized
DEBUG - 2024-02-15 20:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:31:06 --> Input Class Initialized
INFO - 2024-02-15 20:31:06 --> Language Class Initialized
INFO - 2024-02-15 20:31:06 --> Loader Class Initialized
INFO - 2024-02-15 20:31:06 --> Helper loaded: url_helper
INFO - 2024-02-15 20:31:06 --> Helper loaded: file_helper
INFO - 2024-02-15 20:31:06 --> Helper loaded: form_helper
INFO - 2024-02-15 20:31:06 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:31:06 --> Controller Class Initialized
INFO - 2024-02-15 20:31:06 --> Form Validation Class Initialized
INFO - 2024-02-15 20:31:06 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:31:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:31:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:31:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:31:08 --> Config Class Initialized
INFO - 2024-02-15 20:31:08 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:31:08 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:31:08 --> Utf8 Class Initialized
INFO - 2024-02-15 20:31:08 --> URI Class Initialized
INFO - 2024-02-15 20:31:08 --> Router Class Initialized
INFO - 2024-02-15 20:31:08 --> Output Class Initialized
INFO - 2024-02-15 20:31:08 --> Security Class Initialized
DEBUG - 2024-02-15 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:31:08 --> Input Class Initialized
INFO - 2024-02-15 20:31:08 --> Language Class Initialized
INFO - 2024-02-15 20:31:08 --> Loader Class Initialized
INFO - 2024-02-15 20:31:08 --> Helper loaded: url_helper
INFO - 2024-02-15 20:31:08 --> Helper loaded: file_helper
INFO - 2024-02-15 20:31:08 --> Helper loaded: form_helper
INFO - 2024-02-15 20:31:08 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:31:08 --> Controller Class Initialized
INFO - 2024-02-15 20:31:08 --> Form Validation Class Initialized
INFO - 2024-02-15 20:31:08 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:31:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:31:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:31:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:31:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:31:08 --> Final output sent to browser
DEBUG - 2024-02-15 20:31:08 --> Total execution time: 0.0429
ERROR - 2024-02-15 20:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:34:08 --> Config Class Initialized
INFO - 2024-02-15 20:34:08 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:34:08 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:34:08 --> Utf8 Class Initialized
INFO - 2024-02-15 20:34:08 --> URI Class Initialized
INFO - 2024-02-15 20:34:08 --> Router Class Initialized
INFO - 2024-02-15 20:34:08 --> Output Class Initialized
INFO - 2024-02-15 20:34:08 --> Security Class Initialized
DEBUG - 2024-02-15 20:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:34:08 --> Input Class Initialized
INFO - 2024-02-15 20:34:08 --> Language Class Initialized
INFO - 2024-02-15 20:34:08 --> Loader Class Initialized
INFO - 2024-02-15 20:34:08 --> Helper loaded: url_helper
INFO - 2024-02-15 20:34:08 --> Helper loaded: file_helper
INFO - 2024-02-15 20:34:08 --> Helper loaded: form_helper
INFO - 2024-02-15 20:34:08 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:34:08 --> Controller Class Initialized
INFO - 2024-02-15 20:34:08 --> Form Validation Class Initialized
INFO - 2024-02-15 20:34:08 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:34:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:34:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:34:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:34:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:34:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:34:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:34:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:34:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:34:08 --> Final output sent to browser
DEBUG - 2024-02-15 20:34:08 --> Total execution time: 0.0433
ERROR - 2024-02-15 20:34:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:34:09 --> Config Class Initialized
INFO - 2024-02-15 20:34:09 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:34:09 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:34:09 --> Utf8 Class Initialized
INFO - 2024-02-15 20:34:09 --> URI Class Initialized
INFO - 2024-02-15 20:34:09 --> Router Class Initialized
INFO - 2024-02-15 20:34:09 --> Output Class Initialized
INFO - 2024-02-15 20:34:09 --> Security Class Initialized
DEBUG - 2024-02-15 20:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:34:09 --> Input Class Initialized
INFO - 2024-02-15 20:34:09 --> Language Class Initialized
INFO - 2024-02-15 20:34:09 --> Loader Class Initialized
INFO - 2024-02-15 20:34:09 --> Helper loaded: url_helper
INFO - 2024-02-15 20:34:09 --> Helper loaded: file_helper
INFO - 2024-02-15 20:34:09 --> Helper loaded: form_helper
INFO - 2024-02-15 20:34:09 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:34:09 --> Controller Class Initialized
INFO - 2024-02-15 20:34:09 --> Form Validation Class Initialized
INFO - 2024-02-15 20:34:09 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:34:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:34:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:34:09 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:34:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:34:12 --> Config Class Initialized
INFO - 2024-02-15 20:34:12 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:34:12 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:34:12 --> Utf8 Class Initialized
INFO - 2024-02-15 20:34:12 --> URI Class Initialized
INFO - 2024-02-15 20:34:12 --> Router Class Initialized
INFO - 2024-02-15 20:34:12 --> Output Class Initialized
INFO - 2024-02-15 20:34:12 --> Security Class Initialized
DEBUG - 2024-02-15 20:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:34:12 --> Input Class Initialized
INFO - 2024-02-15 20:34:12 --> Language Class Initialized
INFO - 2024-02-15 20:34:12 --> Loader Class Initialized
INFO - 2024-02-15 20:34:12 --> Helper loaded: url_helper
INFO - 2024-02-15 20:34:12 --> Helper loaded: file_helper
INFO - 2024-02-15 20:34:12 --> Helper loaded: form_helper
INFO - 2024-02-15 20:34:12 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:34:12 --> Controller Class Initialized
INFO - 2024-02-15 20:34:12 --> Form Validation Class Initialized
INFO - 2024-02-15 20:34:12 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:34:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:34:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:34:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:34:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:34:12 --> Final output sent to browser
DEBUG - 2024-02-15 20:34:12 --> Total execution time: 0.0422
ERROR - 2024-02-15 20:34:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:34:42 --> Config Class Initialized
INFO - 2024-02-15 20:34:42 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:34:42 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:34:42 --> Utf8 Class Initialized
INFO - 2024-02-15 20:34:42 --> URI Class Initialized
INFO - 2024-02-15 20:34:42 --> Router Class Initialized
INFO - 2024-02-15 20:34:42 --> Output Class Initialized
INFO - 2024-02-15 20:34:42 --> Security Class Initialized
DEBUG - 2024-02-15 20:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:34:42 --> Input Class Initialized
INFO - 2024-02-15 20:34:42 --> Language Class Initialized
INFO - 2024-02-15 20:34:42 --> Loader Class Initialized
INFO - 2024-02-15 20:34:42 --> Helper loaded: url_helper
INFO - 2024-02-15 20:34:42 --> Helper loaded: file_helper
INFO - 2024-02-15 20:34:42 --> Helper loaded: form_helper
INFO - 2024-02-15 20:34:42 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:34:42 --> Controller Class Initialized
INFO - 2024-02-15 20:34:42 --> Form Validation Class Initialized
INFO - 2024-02-15 20:34:42 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:34:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:34:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:34:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:34:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:34:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:34:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:34:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:34:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:34:42 --> Final output sent to browser
DEBUG - 2024-02-15 20:34:42 --> Total execution time: 0.0364
ERROR - 2024-02-15 20:34:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:34:43 --> Config Class Initialized
INFO - 2024-02-15 20:34:43 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:34:43 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:34:43 --> Utf8 Class Initialized
INFO - 2024-02-15 20:34:43 --> URI Class Initialized
INFO - 2024-02-15 20:34:43 --> Router Class Initialized
INFO - 2024-02-15 20:34:43 --> Output Class Initialized
INFO - 2024-02-15 20:34:43 --> Security Class Initialized
DEBUG - 2024-02-15 20:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:34:43 --> Input Class Initialized
INFO - 2024-02-15 20:34:43 --> Language Class Initialized
INFO - 2024-02-15 20:34:43 --> Loader Class Initialized
INFO - 2024-02-15 20:34:43 --> Helper loaded: url_helper
INFO - 2024-02-15 20:34:43 --> Helper loaded: file_helper
INFO - 2024-02-15 20:34:43 --> Helper loaded: form_helper
INFO - 2024-02-15 20:34:43 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:34:43 --> Controller Class Initialized
INFO - 2024-02-15 20:34:43 --> Form Validation Class Initialized
INFO - 2024-02-15 20:34:43 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:34:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:34:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:34:43 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:34:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:34:46 --> Config Class Initialized
INFO - 2024-02-15 20:34:46 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:34:46 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:34:46 --> Utf8 Class Initialized
INFO - 2024-02-15 20:34:46 --> URI Class Initialized
INFO - 2024-02-15 20:34:46 --> Router Class Initialized
INFO - 2024-02-15 20:34:46 --> Output Class Initialized
INFO - 2024-02-15 20:34:46 --> Security Class Initialized
DEBUG - 2024-02-15 20:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:34:46 --> Input Class Initialized
INFO - 2024-02-15 20:34:46 --> Language Class Initialized
INFO - 2024-02-15 20:34:46 --> Loader Class Initialized
INFO - 2024-02-15 20:34:46 --> Helper loaded: url_helper
INFO - 2024-02-15 20:34:46 --> Helper loaded: file_helper
INFO - 2024-02-15 20:34:46 --> Helper loaded: form_helper
INFO - 2024-02-15 20:34:46 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:34:46 --> Controller Class Initialized
INFO - 2024-02-15 20:34:46 --> Form Validation Class Initialized
INFO - 2024-02-15 20:34:46 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:34:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:34:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:34:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:34:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:34:46 --> Final output sent to browser
DEBUG - 2024-02-15 20:34:46 --> Total execution time: 0.0413
ERROR - 2024-02-15 20:36:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:36:10 --> Config Class Initialized
INFO - 2024-02-15 20:36:10 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:36:10 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:36:10 --> Utf8 Class Initialized
INFO - 2024-02-15 20:36:10 --> URI Class Initialized
INFO - 2024-02-15 20:36:10 --> Router Class Initialized
INFO - 2024-02-15 20:36:10 --> Output Class Initialized
INFO - 2024-02-15 20:36:10 --> Security Class Initialized
DEBUG - 2024-02-15 20:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:36:10 --> Input Class Initialized
INFO - 2024-02-15 20:36:10 --> Language Class Initialized
INFO - 2024-02-15 20:36:10 --> Loader Class Initialized
INFO - 2024-02-15 20:36:10 --> Helper loaded: url_helper
INFO - 2024-02-15 20:36:10 --> Helper loaded: file_helper
INFO - 2024-02-15 20:36:10 --> Helper loaded: form_helper
INFO - 2024-02-15 20:36:10 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:36:10 --> Controller Class Initialized
INFO - 2024-02-15 20:36:10 --> Form Validation Class Initialized
INFO - 2024-02-15 20:36:10 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:36:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:36:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:36:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:36:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:36:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:36:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:36:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:36:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:36:10 --> Final output sent to browser
DEBUG - 2024-02-15 20:36:10 --> Total execution time: 0.0505
ERROR - 2024-02-15 20:36:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:36:12 --> Config Class Initialized
INFO - 2024-02-15 20:36:12 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:36:12 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:36:12 --> Utf8 Class Initialized
INFO - 2024-02-15 20:36:12 --> URI Class Initialized
INFO - 2024-02-15 20:36:12 --> Router Class Initialized
INFO - 2024-02-15 20:36:12 --> Output Class Initialized
INFO - 2024-02-15 20:36:12 --> Security Class Initialized
DEBUG - 2024-02-15 20:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:36:12 --> Input Class Initialized
INFO - 2024-02-15 20:36:12 --> Language Class Initialized
INFO - 2024-02-15 20:36:12 --> Loader Class Initialized
INFO - 2024-02-15 20:36:12 --> Helper loaded: url_helper
INFO - 2024-02-15 20:36:12 --> Helper loaded: file_helper
INFO - 2024-02-15 20:36:12 --> Helper loaded: form_helper
INFO - 2024-02-15 20:36:12 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:36:12 --> Controller Class Initialized
INFO - 2024-02-15 20:36:12 --> Form Validation Class Initialized
INFO - 2024-02-15 20:36:12 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:36:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:36:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:36:12 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:36:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:36:14 --> Config Class Initialized
INFO - 2024-02-15 20:36:14 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:36:14 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:36:14 --> Utf8 Class Initialized
INFO - 2024-02-15 20:36:14 --> URI Class Initialized
INFO - 2024-02-15 20:36:14 --> Router Class Initialized
INFO - 2024-02-15 20:36:14 --> Output Class Initialized
INFO - 2024-02-15 20:36:14 --> Security Class Initialized
DEBUG - 2024-02-15 20:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:36:14 --> Input Class Initialized
INFO - 2024-02-15 20:36:14 --> Language Class Initialized
INFO - 2024-02-15 20:36:14 --> Loader Class Initialized
INFO - 2024-02-15 20:36:14 --> Helper loaded: url_helper
INFO - 2024-02-15 20:36:14 --> Helper loaded: file_helper
INFO - 2024-02-15 20:36:14 --> Helper loaded: form_helper
INFO - 2024-02-15 20:36:14 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:36:14 --> Controller Class Initialized
INFO - 2024-02-15 20:36:14 --> Form Validation Class Initialized
INFO - 2024-02-15 20:36:14 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:36:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:36:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:36:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:36:14 --> Final output sent to browser
DEBUG - 2024-02-15 20:36:14 --> Total execution time: 0.0443
ERROR - 2024-02-15 20:38:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:38:17 --> Config Class Initialized
INFO - 2024-02-15 20:38:17 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:38:17 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:38:17 --> Utf8 Class Initialized
INFO - 2024-02-15 20:38:17 --> URI Class Initialized
INFO - 2024-02-15 20:38:17 --> Router Class Initialized
INFO - 2024-02-15 20:38:17 --> Output Class Initialized
INFO - 2024-02-15 20:38:17 --> Security Class Initialized
DEBUG - 2024-02-15 20:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:38:17 --> Input Class Initialized
INFO - 2024-02-15 20:38:17 --> Language Class Initialized
INFO - 2024-02-15 20:38:17 --> Loader Class Initialized
INFO - 2024-02-15 20:38:17 --> Helper loaded: url_helper
INFO - 2024-02-15 20:38:17 --> Helper loaded: file_helper
INFO - 2024-02-15 20:38:17 --> Helper loaded: form_helper
INFO - 2024-02-15 20:38:18 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:38:18 --> Controller Class Initialized
INFO - 2024-02-15 20:38:18 --> Form Validation Class Initialized
INFO - 2024-02-15 20:38:18 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:38:18 --> Final output sent to browser
DEBUG - 2024-02-15 20:38:18 --> Total execution time: 0.0434
ERROR - 2024-02-15 20:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:38:18 --> Config Class Initialized
INFO - 2024-02-15 20:38:18 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:38:18 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:38:18 --> Utf8 Class Initialized
INFO - 2024-02-15 20:38:18 --> URI Class Initialized
INFO - 2024-02-15 20:38:18 --> Router Class Initialized
INFO - 2024-02-15 20:38:18 --> Output Class Initialized
INFO - 2024-02-15 20:38:18 --> Security Class Initialized
DEBUG - 2024-02-15 20:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:38:18 --> Input Class Initialized
INFO - 2024-02-15 20:38:18 --> Language Class Initialized
INFO - 2024-02-15 20:38:18 --> Loader Class Initialized
INFO - 2024-02-15 20:38:18 --> Helper loaded: url_helper
INFO - 2024-02-15 20:38:18 --> Helper loaded: file_helper
INFO - 2024-02-15 20:38:18 --> Helper loaded: form_helper
INFO - 2024-02-15 20:38:18 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:38:18 --> Controller Class Initialized
ERROR - 2024-02-15 20:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:38:18 --> Config Class Initialized
INFO - 2024-02-15 20:38:18 --> Hooks Class Initialized
INFO - 2024-02-15 20:38:18 --> Form Validation Class Initialized
DEBUG - 2024-02-15 20:38:18 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:38:18 --> Utf8 Class Initialized
INFO - 2024-02-15 20:38:18 --> URI Class Initialized
INFO - 2024-02-15 20:38:18 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:38:18 --> Router Class Initialized
INFO - 2024-02-15 20:38:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:38:18 --> Output Class Initialized
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:38:18 --> Final output sent to browser
DEBUG - 2024-02-15 20:38:18 --> Total execution time: 0.0625
INFO - 2024-02-15 20:38:18 --> Security Class Initialized
DEBUG - 2024-02-15 20:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:38:18 --> Input Class Initialized
INFO - 2024-02-15 20:38:18 --> Language Class Initialized
INFO - 2024-02-15 20:38:18 --> Loader Class Initialized
INFO - 2024-02-15 20:38:18 --> Helper loaded: url_helper
INFO - 2024-02-15 20:38:18 --> Helper loaded: file_helper
INFO - 2024-02-15 20:38:18 --> Helper loaded: form_helper
ERROR - 2024-02-15 20:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2024-02-15 20:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:38:18 --> Config Class Initialized
INFO - 2024-02-15 20:38:18 --> Hooks Class Initialized
INFO - 2024-02-15 20:38:18 --> Database Driver Class Initialized
INFO - 2024-02-15 20:38:18 --> Config Class Initialized
INFO - 2024-02-15 20:38:18 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:38:18 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:38:18 --> Utf8 Class Initialized
DEBUG - 2024-02-15 20:38:18 --> UTF-8 Support Enabled
ERROR - 2024-02-15 20:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:38:18 --> Utf8 Class Initialized
INFO - 2024-02-15 20:38:18 --> URI Class Initialized
INFO - 2024-02-15 20:38:18 --> URI Class Initialized
INFO - 2024-02-15 20:38:18 --> Config Class Initialized
INFO - 2024-02-15 20:38:18 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:38:18 --> Router Class Initialized
INFO - 2024-02-15 20:38:18 --> Router Class Initialized
INFO - 2024-02-15 20:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:38:18 --> Controller Class Initialized
INFO - 2024-02-15 20:38:18 --> Output Class Initialized
INFO - 2024-02-15 20:38:18 --> Output Class Initialized
INFO - 2024-02-15 20:38:18 --> Form Validation Class Initialized
DEBUG - 2024-02-15 20:38:18 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:38:18 --> Utf8 Class Initialized
INFO - 2024-02-15 20:38:18 --> Security Class Initialized
INFO - 2024-02-15 20:38:18 --> Security Class Initialized
INFO - 2024-02-15 20:38:18 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:38:18 --> URI Class Initialized
DEBUG - 2024-02-15 20:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:38:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:38:18 --> Input Class Initialized
DEBUG - 2024-02-15 20:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:38:18 --> Input Class Initialized
INFO - 2024-02-15 20:38:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:38:18 --> Language Class Initialized
INFO - 2024-02-15 20:38:18 --> Router Class Initialized
INFO - 2024-02-15 20:38:18 --> Language Class Initialized
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:38:18 --> Final output sent to browser
INFO - 2024-02-15 20:38:18 --> Output Class Initialized
DEBUG - 2024-02-15 20:38:18 --> Total execution time: 0.0688
INFO - 2024-02-15 20:38:18 --> Loader Class Initialized
INFO - 2024-02-15 20:38:18 --> Loader Class Initialized
INFO - 2024-02-15 20:38:18 --> Security Class Initialized
INFO - 2024-02-15 20:38:18 --> Helper loaded: url_helper
INFO - 2024-02-15 20:38:18 --> Helper loaded: file_helper
INFO - 2024-02-15 20:38:18 --> Helper loaded: url_helper
DEBUG - 2024-02-15 20:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:38:18 --> Input Class Initialized
INFO - 2024-02-15 20:38:18 --> Language Class Initialized
INFO - 2024-02-15 20:38:18 --> Helper loaded: file_helper
INFO - 2024-02-15 20:38:18 --> Helper loaded: form_helper
INFO - 2024-02-15 20:38:18 --> Loader Class Initialized
INFO - 2024-02-15 20:38:18 --> Helper loaded: form_helper
INFO - 2024-02-15 20:38:18 --> Helper loaded: url_helper
INFO - 2024-02-15 20:38:18 --> Helper loaded: file_helper
INFO - 2024-02-15 20:38:18 --> Helper loaded: form_helper
INFO - 2024-02-15 20:38:18 --> Database Driver Class Initialized
INFO - 2024-02-15 20:38:18 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:38:18 --> Database Driver Class Initialized
INFO - 2024-02-15 20:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:38:18 --> Controller Class Initialized
INFO - 2024-02-15 20:38:18 --> Form Validation Class Initialized
DEBUG - 2024-02-15 20:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:38:18 --> Model "MasterModel" initialized
DEBUG - 2024-02-15 20:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:38:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:38:18 --> Controller Class Initialized
INFO - 2024-02-15 20:38:18 --> Form Validation Class Initialized
INFO - 2024-02-15 20:38:18 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:38:18 --> Final output sent to browser
DEBUG - 2024-02-15 20:38:18 --> Total execution time: 0.0478
INFO - 2024-02-15 20:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:38:18 --> Controller Class Initialized
INFO - 2024-02-15 20:38:18 --> Form Validation Class Initialized
INFO - 2024-02-15 20:38:18 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:38:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:38:18 --> Final output sent to browser
DEBUG - 2024-02-15 20:38:18 --> Total execution time: 0.0862
ERROR - 2024-02-15 20:38:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:38:19 --> Config Class Initialized
INFO - 2024-02-15 20:38:19 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:38:19 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:38:19 --> Utf8 Class Initialized
INFO - 2024-02-15 20:38:19 --> URI Class Initialized
INFO - 2024-02-15 20:38:19 --> Router Class Initialized
INFO - 2024-02-15 20:38:19 --> Output Class Initialized
INFO - 2024-02-15 20:38:19 --> Security Class Initialized
DEBUG - 2024-02-15 20:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:38:19 --> Input Class Initialized
INFO - 2024-02-15 20:38:19 --> Language Class Initialized
INFO - 2024-02-15 20:38:19 --> Loader Class Initialized
INFO - 2024-02-15 20:38:19 --> Helper loaded: url_helper
INFO - 2024-02-15 20:38:19 --> Helper loaded: file_helper
INFO - 2024-02-15 20:38:19 --> Helper loaded: form_helper
INFO - 2024-02-15 20:38:19 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:38:19 --> Controller Class Initialized
INFO - 2024-02-15 20:38:19 --> Form Validation Class Initialized
INFO - 2024-02-15 20:38:19 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:38:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:38:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:38:19 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:38:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:38:21 --> Config Class Initialized
INFO - 2024-02-15 20:38:21 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:38:21 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:38:21 --> Utf8 Class Initialized
INFO - 2024-02-15 20:38:21 --> URI Class Initialized
INFO - 2024-02-15 20:38:21 --> Router Class Initialized
INFO - 2024-02-15 20:38:21 --> Output Class Initialized
INFO - 2024-02-15 20:38:21 --> Security Class Initialized
DEBUG - 2024-02-15 20:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:38:21 --> Input Class Initialized
INFO - 2024-02-15 20:38:21 --> Language Class Initialized
INFO - 2024-02-15 20:38:21 --> Loader Class Initialized
INFO - 2024-02-15 20:38:21 --> Helper loaded: url_helper
INFO - 2024-02-15 20:38:21 --> Helper loaded: file_helper
INFO - 2024-02-15 20:38:21 --> Helper loaded: form_helper
INFO - 2024-02-15 20:38:21 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:38:21 --> Controller Class Initialized
INFO - 2024-02-15 20:38:21 --> Form Validation Class Initialized
INFO - 2024-02-15 20:38:21 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:38:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:38:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:38:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:38:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:38:21 --> Final output sent to browser
DEBUG - 2024-02-15 20:38:21 --> Total execution time: 0.0430
ERROR - 2024-02-15 20:39:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:39:31 --> Config Class Initialized
INFO - 2024-02-15 20:39:31 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:39:31 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:39:31 --> Utf8 Class Initialized
INFO - 2024-02-15 20:39:31 --> URI Class Initialized
INFO - 2024-02-15 20:39:31 --> Router Class Initialized
INFO - 2024-02-15 20:39:31 --> Output Class Initialized
INFO - 2024-02-15 20:39:31 --> Security Class Initialized
DEBUG - 2024-02-15 20:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:39:31 --> Input Class Initialized
INFO - 2024-02-15 20:39:31 --> Language Class Initialized
INFO - 2024-02-15 20:39:31 --> Loader Class Initialized
INFO - 2024-02-15 20:39:31 --> Helper loaded: url_helper
INFO - 2024-02-15 20:39:31 --> Helper loaded: file_helper
INFO - 2024-02-15 20:39:31 --> Helper loaded: form_helper
INFO - 2024-02-15 20:39:31 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:39:31 --> Controller Class Initialized
INFO - 2024-02-15 20:39:31 --> Form Validation Class Initialized
INFO - 2024-02-15 20:39:31 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:39:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:39:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:39:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:39:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:39:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:39:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:39:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:39:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:39:31 --> Final output sent to browser
DEBUG - 2024-02-15 20:39:31 --> Total execution time: 0.0427
ERROR - 2024-02-15 20:39:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:39:32 --> Config Class Initialized
INFO - 2024-02-15 20:39:32 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:39:32 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:39:32 --> Utf8 Class Initialized
INFO - 2024-02-15 20:39:32 --> URI Class Initialized
INFO - 2024-02-15 20:39:32 --> Router Class Initialized
INFO - 2024-02-15 20:39:32 --> Output Class Initialized
INFO - 2024-02-15 20:39:32 --> Security Class Initialized
DEBUG - 2024-02-15 20:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:39:32 --> Input Class Initialized
INFO - 2024-02-15 20:39:32 --> Language Class Initialized
INFO - 2024-02-15 20:39:32 --> Loader Class Initialized
INFO - 2024-02-15 20:39:32 --> Helper loaded: url_helper
INFO - 2024-02-15 20:39:32 --> Helper loaded: file_helper
INFO - 2024-02-15 20:39:32 --> Helper loaded: form_helper
INFO - 2024-02-15 20:39:32 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:39:32 --> Controller Class Initialized
INFO - 2024-02-15 20:39:32 --> Form Validation Class Initialized
INFO - 2024-02-15 20:39:32 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:39:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:39:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:39:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:39:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:39:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:39:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:39:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:39:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:39:32 --> Final output sent to browser
DEBUG - 2024-02-15 20:39:32 --> Total execution time: 0.0554
ERROR - 2024-02-15 20:39:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:39:34 --> Config Class Initialized
INFO - 2024-02-15 20:39:34 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:39:34 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:39:34 --> Utf8 Class Initialized
INFO - 2024-02-15 20:39:34 --> URI Class Initialized
INFO - 2024-02-15 20:39:34 --> Router Class Initialized
INFO - 2024-02-15 20:39:34 --> Output Class Initialized
INFO - 2024-02-15 20:39:34 --> Security Class Initialized
DEBUG - 2024-02-15 20:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:39:34 --> Input Class Initialized
INFO - 2024-02-15 20:39:34 --> Language Class Initialized
INFO - 2024-02-15 20:39:34 --> Loader Class Initialized
INFO - 2024-02-15 20:39:34 --> Helper loaded: url_helper
INFO - 2024-02-15 20:39:34 --> Helper loaded: file_helper
INFO - 2024-02-15 20:39:34 --> Helper loaded: form_helper
INFO - 2024-02-15 20:39:34 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:39:34 --> Controller Class Initialized
INFO - 2024-02-15 20:39:34 --> Form Validation Class Initialized
INFO - 2024-02-15 20:39:34 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:39:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:39:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:39:34 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:39:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:39:35 --> Config Class Initialized
INFO - 2024-02-15 20:39:35 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:39:35 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:39:35 --> Utf8 Class Initialized
INFO - 2024-02-15 20:39:35 --> URI Class Initialized
INFO - 2024-02-15 20:39:35 --> Router Class Initialized
INFO - 2024-02-15 20:39:35 --> Output Class Initialized
INFO - 2024-02-15 20:39:35 --> Security Class Initialized
DEBUG - 2024-02-15 20:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:39:35 --> Input Class Initialized
INFO - 2024-02-15 20:39:35 --> Language Class Initialized
INFO - 2024-02-15 20:39:35 --> Loader Class Initialized
INFO - 2024-02-15 20:39:35 --> Helper loaded: url_helper
INFO - 2024-02-15 20:39:35 --> Helper loaded: file_helper
INFO - 2024-02-15 20:39:35 --> Helper loaded: form_helper
INFO - 2024-02-15 20:39:35 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:39:35 --> Controller Class Initialized
INFO - 2024-02-15 20:39:35 --> Form Validation Class Initialized
INFO - 2024-02-15 20:39:35 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:39:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:39:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:39:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:39:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:39:35 --> Final output sent to browser
DEBUG - 2024-02-15 20:39:35 --> Total execution time: 0.0354
ERROR - 2024-02-15 20:40:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:40:53 --> Config Class Initialized
INFO - 2024-02-15 20:40:53 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:40:53 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:40:53 --> Utf8 Class Initialized
INFO - 2024-02-15 20:40:53 --> URI Class Initialized
INFO - 2024-02-15 20:40:53 --> Router Class Initialized
INFO - 2024-02-15 20:40:53 --> Output Class Initialized
INFO - 2024-02-15 20:40:53 --> Security Class Initialized
DEBUG - 2024-02-15 20:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:40:53 --> Input Class Initialized
INFO - 2024-02-15 20:40:53 --> Language Class Initialized
INFO - 2024-02-15 20:40:53 --> Loader Class Initialized
INFO - 2024-02-15 20:40:53 --> Helper loaded: url_helper
INFO - 2024-02-15 20:40:53 --> Helper loaded: file_helper
INFO - 2024-02-15 20:40:53 --> Helper loaded: form_helper
INFO - 2024-02-15 20:40:53 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:40:53 --> Controller Class Initialized
INFO - 2024-02-15 20:40:53 --> Form Validation Class Initialized
INFO - 2024-02-15 20:40:53 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:40:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:40:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:40:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:40:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:40:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:40:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:40:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:40:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:40:53 --> Final output sent to browser
DEBUG - 2024-02-15 20:40:53 --> Total execution time: 0.0508
ERROR - 2024-02-15 20:40:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:40:54 --> Config Class Initialized
INFO - 2024-02-15 20:40:54 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:40:54 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:40:54 --> Utf8 Class Initialized
INFO - 2024-02-15 20:40:54 --> URI Class Initialized
INFO - 2024-02-15 20:40:54 --> Router Class Initialized
INFO - 2024-02-15 20:40:54 --> Output Class Initialized
INFO - 2024-02-15 20:40:54 --> Security Class Initialized
DEBUG - 2024-02-15 20:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:40:54 --> Input Class Initialized
INFO - 2024-02-15 20:40:54 --> Language Class Initialized
INFO - 2024-02-15 20:40:54 --> Loader Class Initialized
INFO - 2024-02-15 20:40:54 --> Helper loaded: url_helper
INFO - 2024-02-15 20:40:54 --> Helper loaded: file_helper
INFO - 2024-02-15 20:40:54 --> Helper loaded: form_helper
INFO - 2024-02-15 20:40:54 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:40:54 --> Controller Class Initialized
INFO - 2024-02-15 20:40:54 --> Form Validation Class Initialized
INFO - 2024-02-15 20:40:54 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:40:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:40:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:40:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:40:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:40:57 --> Config Class Initialized
INFO - 2024-02-15 20:40:57 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:40:57 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:40:57 --> Utf8 Class Initialized
INFO - 2024-02-15 20:40:57 --> URI Class Initialized
INFO - 2024-02-15 20:40:57 --> Router Class Initialized
INFO - 2024-02-15 20:40:57 --> Output Class Initialized
INFO - 2024-02-15 20:40:57 --> Security Class Initialized
DEBUG - 2024-02-15 20:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:40:57 --> Input Class Initialized
INFO - 2024-02-15 20:40:57 --> Language Class Initialized
INFO - 2024-02-15 20:40:57 --> Loader Class Initialized
INFO - 2024-02-15 20:40:57 --> Helper loaded: url_helper
INFO - 2024-02-15 20:40:57 --> Helper loaded: file_helper
INFO - 2024-02-15 20:40:57 --> Helper loaded: form_helper
INFO - 2024-02-15 20:40:57 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:40:57 --> Controller Class Initialized
INFO - 2024-02-15 20:40:57 --> Form Validation Class Initialized
INFO - 2024-02-15 20:40:57 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:40:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:40:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:40:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:40:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:40:57 --> Final output sent to browser
DEBUG - 2024-02-15 20:40:57 --> Total execution time: 0.0433
ERROR - 2024-02-15 20:42:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:42:22 --> Config Class Initialized
INFO - 2024-02-15 20:42:22 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:42:22 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:42:22 --> Utf8 Class Initialized
INFO - 2024-02-15 20:42:22 --> URI Class Initialized
INFO - 2024-02-15 20:42:22 --> Router Class Initialized
INFO - 2024-02-15 20:42:22 --> Output Class Initialized
INFO - 2024-02-15 20:42:22 --> Security Class Initialized
DEBUG - 2024-02-15 20:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:42:22 --> Input Class Initialized
INFO - 2024-02-15 20:42:22 --> Language Class Initialized
INFO - 2024-02-15 20:42:22 --> Loader Class Initialized
INFO - 2024-02-15 20:42:22 --> Helper loaded: url_helper
INFO - 2024-02-15 20:42:22 --> Helper loaded: file_helper
INFO - 2024-02-15 20:42:22 --> Helper loaded: form_helper
INFO - 2024-02-15 20:42:22 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:42:22 --> Controller Class Initialized
INFO - 2024-02-15 20:42:22 --> Form Validation Class Initialized
INFO - 2024-02-15 20:42:22 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:42:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:42:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:42:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:42:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:42:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:42:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:42:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:42:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:42:22 --> Final output sent to browser
DEBUG - 2024-02-15 20:42:22 --> Total execution time: 0.0435
ERROR - 2024-02-15 20:42:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:42:23 --> Config Class Initialized
INFO - 2024-02-15 20:42:23 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:42:23 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:42:23 --> Utf8 Class Initialized
INFO - 2024-02-15 20:42:23 --> URI Class Initialized
INFO - 2024-02-15 20:42:23 --> Router Class Initialized
INFO - 2024-02-15 20:42:23 --> Output Class Initialized
INFO - 2024-02-15 20:42:23 --> Security Class Initialized
DEBUG - 2024-02-15 20:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:42:23 --> Input Class Initialized
INFO - 2024-02-15 20:42:23 --> Language Class Initialized
INFO - 2024-02-15 20:42:23 --> Loader Class Initialized
INFO - 2024-02-15 20:42:23 --> Helper loaded: url_helper
INFO - 2024-02-15 20:42:23 --> Helper loaded: file_helper
INFO - 2024-02-15 20:42:23 --> Helper loaded: form_helper
INFO - 2024-02-15 20:42:23 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:42:23 --> Controller Class Initialized
INFO - 2024-02-15 20:42:23 --> Form Validation Class Initialized
INFO - 2024-02-15 20:42:23 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:42:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:42:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:42:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:42:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:42:25 --> Config Class Initialized
INFO - 2024-02-15 20:42:25 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:42:25 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:42:25 --> Utf8 Class Initialized
INFO - 2024-02-15 20:42:25 --> URI Class Initialized
INFO - 2024-02-15 20:42:25 --> Router Class Initialized
INFO - 2024-02-15 20:42:25 --> Output Class Initialized
INFO - 2024-02-15 20:42:25 --> Security Class Initialized
DEBUG - 2024-02-15 20:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:42:25 --> Input Class Initialized
INFO - 2024-02-15 20:42:25 --> Language Class Initialized
INFO - 2024-02-15 20:42:25 --> Loader Class Initialized
INFO - 2024-02-15 20:42:25 --> Helper loaded: url_helper
INFO - 2024-02-15 20:42:25 --> Helper loaded: file_helper
INFO - 2024-02-15 20:42:25 --> Helper loaded: form_helper
INFO - 2024-02-15 20:42:25 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:42:25 --> Controller Class Initialized
INFO - 2024-02-15 20:42:25 --> Form Validation Class Initialized
INFO - 2024-02-15 20:42:25 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:42:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:42:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:42:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:42:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:42:25 --> Final output sent to browser
DEBUG - 2024-02-15 20:42:25 --> Total execution time: 0.0439
ERROR - 2024-02-15 20:46:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:46:22 --> Config Class Initialized
INFO - 2024-02-15 20:46:22 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:46:22 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:46:22 --> Utf8 Class Initialized
INFO - 2024-02-15 20:46:22 --> URI Class Initialized
INFO - 2024-02-15 20:46:22 --> Router Class Initialized
INFO - 2024-02-15 20:46:22 --> Output Class Initialized
INFO - 2024-02-15 20:46:22 --> Security Class Initialized
DEBUG - 2024-02-15 20:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:46:22 --> Input Class Initialized
INFO - 2024-02-15 20:46:22 --> Language Class Initialized
INFO - 2024-02-15 20:46:22 --> Loader Class Initialized
INFO - 2024-02-15 20:46:22 --> Helper loaded: url_helper
INFO - 2024-02-15 20:46:22 --> Helper loaded: file_helper
INFO - 2024-02-15 20:46:22 --> Helper loaded: form_helper
INFO - 2024-02-15 20:46:22 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:46:22 --> Controller Class Initialized
INFO - 2024-02-15 20:46:22 --> Form Validation Class Initialized
INFO - 2024-02-15 20:46:22 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:46:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:46:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:46:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:46:22 --> Final output sent to browser
DEBUG - 2024-02-15 20:46:22 --> Total execution time: 0.0490
ERROR - 2024-02-15 20:46:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:46:23 --> Config Class Initialized
INFO - 2024-02-15 20:46:23 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:46:23 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:46:23 --> Utf8 Class Initialized
INFO - 2024-02-15 20:46:23 --> URI Class Initialized
INFO - 2024-02-15 20:46:23 --> Router Class Initialized
INFO - 2024-02-15 20:46:23 --> Output Class Initialized
INFO - 2024-02-15 20:46:23 --> Security Class Initialized
DEBUG - 2024-02-15 20:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:46:23 --> Input Class Initialized
INFO - 2024-02-15 20:46:23 --> Language Class Initialized
INFO - 2024-02-15 20:46:23 --> Loader Class Initialized
INFO - 2024-02-15 20:46:23 --> Helper loaded: url_helper
INFO - 2024-02-15 20:46:23 --> Helper loaded: file_helper
INFO - 2024-02-15 20:46:23 --> Helper loaded: form_helper
INFO - 2024-02-15 20:46:23 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:46:23 --> Controller Class Initialized
INFO - 2024-02-15 20:46:23 --> Form Validation Class Initialized
INFO - 2024-02-15 20:46:23 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:46:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:46:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:46:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:46:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:46:25 --> Config Class Initialized
INFO - 2024-02-15 20:46:25 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:46:25 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:46:25 --> Utf8 Class Initialized
INFO - 2024-02-15 20:46:25 --> URI Class Initialized
INFO - 2024-02-15 20:46:25 --> Router Class Initialized
INFO - 2024-02-15 20:46:25 --> Output Class Initialized
INFO - 2024-02-15 20:46:25 --> Security Class Initialized
DEBUG - 2024-02-15 20:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:46:25 --> Input Class Initialized
INFO - 2024-02-15 20:46:25 --> Language Class Initialized
INFO - 2024-02-15 20:46:25 --> Loader Class Initialized
INFO - 2024-02-15 20:46:25 --> Helper loaded: url_helper
INFO - 2024-02-15 20:46:25 --> Helper loaded: file_helper
INFO - 2024-02-15 20:46:25 --> Helper loaded: form_helper
INFO - 2024-02-15 20:46:25 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:46:25 --> Controller Class Initialized
INFO - 2024-02-15 20:46:25 --> Form Validation Class Initialized
INFO - 2024-02-15 20:46:25 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:46:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:46:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:46:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:46:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:46:25 --> Final output sent to browser
DEBUG - 2024-02-15 20:46:25 --> Total execution time: 0.0459
ERROR - 2024-02-15 20:47:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:47:13 --> Config Class Initialized
INFO - 2024-02-15 20:47:13 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:47:13 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:47:13 --> Utf8 Class Initialized
INFO - 2024-02-15 20:47:13 --> URI Class Initialized
INFO - 2024-02-15 20:47:13 --> Router Class Initialized
INFO - 2024-02-15 20:47:13 --> Output Class Initialized
INFO - 2024-02-15 20:47:13 --> Security Class Initialized
DEBUG - 2024-02-15 20:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:47:13 --> Input Class Initialized
INFO - 2024-02-15 20:47:13 --> Language Class Initialized
INFO - 2024-02-15 20:47:13 --> Loader Class Initialized
INFO - 2024-02-15 20:47:13 --> Helper loaded: url_helper
INFO - 2024-02-15 20:47:13 --> Helper loaded: file_helper
INFO - 2024-02-15 20:47:13 --> Helper loaded: form_helper
INFO - 2024-02-15 20:47:13 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:47:13 --> Controller Class Initialized
INFO - 2024-02-15 20:47:13 --> Form Validation Class Initialized
INFO - 2024-02-15 20:47:13 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:47:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:47:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:47:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:47:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:47:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:47:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:47:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:47:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:47:13 --> Final output sent to browser
DEBUG - 2024-02-15 20:47:13 --> Total execution time: 0.0342
ERROR - 2024-02-15 20:47:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:47:14 --> Config Class Initialized
INFO - 2024-02-15 20:47:14 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:47:14 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:47:14 --> Utf8 Class Initialized
INFO - 2024-02-15 20:47:14 --> URI Class Initialized
INFO - 2024-02-15 20:47:14 --> Router Class Initialized
INFO - 2024-02-15 20:47:14 --> Output Class Initialized
INFO - 2024-02-15 20:47:14 --> Security Class Initialized
DEBUG - 2024-02-15 20:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:47:14 --> Input Class Initialized
INFO - 2024-02-15 20:47:14 --> Language Class Initialized
INFO - 2024-02-15 20:47:14 --> Loader Class Initialized
INFO - 2024-02-15 20:47:14 --> Helper loaded: url_helper
INFO - 2024-02-15 20:47:14 --> Helper loaded: file_helper
INFO - 2024-02-15 20:47:14 --> Helper loaded: form_helper
INFO - 2024-02-15 20:47:14 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:47:14 --> Controller Class Initialized
INFO - 2024-02-15 20:47:14 --> Form Validation Class Initialized
INFO - 2024-02-15 20:47:14 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:47:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:47:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:47:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:47:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:47:16 --> Config Class Initialized
INFO - 2024-02-15 20:47:16 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:47:16 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:47:16 --> Utf8 Class Initialized
INFO - 2024-02-15 20:47:16 --> URI Class Initialized
INFO - 2024-02-15 20:47:16 --> Router Class Initialized
INFO - 2024-02-15 20:47:16 --> Output Class Initialized
INFO - 2024-02-15 20:47:16 --> Security Class Initialized
DEBUG - 2024-02-15 20:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:47:16 --> Input Class Initialized
INFO - 2024-02-15 20:47:16 --> Language Class Initialized
INFO - 2024-02-15 20:47:16 --> Loader Class Initialized
INFO - 2024-02-15 20:47:16 --> Helper loaded: url_helper
INFO - 2024-02-15 20:47:16 --> Helper loaded: file_helper
INFO - 2024-02-15 20:47:16 --> Helper loaded: form_helper
INFO - 2024-02-15 20:47:16 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:47:16 --> Controller Class Initialized
INFO - 2024-02-15 20:47:16 --> Form Validation Class Initialized
INFO - 2024-02-15 20:47:16 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:47:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:47:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:47:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:47:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:47:16 --> Final output sent to browser
DEBUG - 2024-02-15 20:47:16 --> Total execution time: 0.0423
ERROR - 2024-02-15 20:47:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:47:43 --> Config Class Initialized
INFO - 2024-02-15 20:47:43 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:47:43 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:47:43 --> Utf8 Class Initialized
INFO - 2024-02-15 20:47:43 --> URI Class Initialized
INFO - 2024-02-15 20:47:43 --> Router Class Initialized
INFO - 2024-02-15 20:47:43 --> Output Class Initialized
INFO - 2024-02-15 20:47:43 --> Security Class Initialized
DEBUG - 2024-02-15 20:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:47:43 --> Input Class Initialized
INFO - 2024-02-15 20:47:43 --> Language Class Initialized
INFO - 2024-02-15 20:47:43 --> Loader Class Initialized
INFO - 2024-02-15 20:47:43 --> Helper loaded: url_helper
INFO - 2024-02-15 20:47:43 --> Helper loaded: file_helper
INFO - 2024-02-15 20:47:43 --> Helper loaded: form_helper
INFO - 2024-02-15 20:47:43 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:47:43 --> Controller Class Initialized
INFO - 2024-02-15 20:47:43 --> Form Validation Class Initialized
INFO - 2024-02-15 20:47:43 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:47:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:47:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:47:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:47:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:47:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:47:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:47:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:47:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:47:43 --> Final output sent to browser
DEBUG - 2024-02-15 20:47:43 --> Total execution time: 0.0569
ERROR - 2024-02-15 20:47:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:47:44 --> Config Class Initialized
INFO - 2024-02-15 20:47:44 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:47:44 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:47:44 --> Utf8 Class Initialized
INFO - 2024-02-15 20:47:44 --> URI Class Initialized
INFO - 2024-02-15 20:47:44 --> Router Class Initialized
INFO - 2024-02-15 20:47:44 --> Output Class Initialized
INFO - 2024-02-15 20:47:44 --> Security Class Initialized
DEBUG - 2024-02-15 20:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:47:44 --> Input Class Initialized
INFO - 2024-02-15 20:47:44 --> Language Class Initialized
INFO - 2024-02-15 20:47:44 --> Loader Class Initialized
INFO - 2024-02-15 20:47:44 --> Helper loaded: url_helper
INFO - 2024-02-15 20:47:44 --> Helper loaded: file_helper
INFO - 2024-02-15 20:47:44 --> Helper loaded: form_helper
INFO - 2024-02-15 20:47:44 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:47:44 --> Controller Class Initialized
INFO - 2024-02-15 20:47:44 --> Form Validation Class Initialized
INFO - 2024-02-15 20:47:44 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:47:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:47:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:47:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:47:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:47:46 --> Config Class Initialized
INFO - 2024-02-15 20:47:46 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:47:46 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:47:46 --> Utf8 Class Initialized
INFO - 2024-02-15 20:47:46 --> URI Class Initialized
INFO - 2024-02-15 20:47:46 --> Router Class Initialized
INFO - 2024-02-15 20:47:46 --> Output Class Initialized
INFO - 2024-02-15 20:47:46 --> Security Class Initialized
DEBUG - 2024-02-15 20:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:47:46 --> Input Class Initialized
INFO - 2024-02-15 20:47:46 --> Language Class Initialized
INFO - 2024-02-15 20:47:46 --> Loader Class Initialized
INFO - 2024-02-15 20:47:46 --> Helper loaded: url_helper
INFO - 2024-02-15 20:47:46 --> Helper loaded: file_helper
INFO - 2024-02-15 20:47:46 --> Helper loaded: form_helper
INFO - 2024-02-15 20:47:46 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:47:46 --> Controller Class Initialized
INFO - 2024-02-15 20:47:46 --> Form Validation Class Initialized
INFO - 2024-02-15 20:47:46 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:47:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:47:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:47:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:47:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:47:46 --> Final output sent to browser
DEBUG - 2024-02-15 20:47:46 --> Total execution time: 0.0440
ERROR - 2024-02-15 20:53:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:53:58 --> Config Class Initialized
INFO - 2024-02-15 20:53:58 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:53:58 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:53:58 --> Utf8 Class Initialized
INFO - 2024-02-15 20:53:58 --> URI Class Initialized
INFO - 2024-02-15 20:53:58 --> Router Class Initialized
INFO - 2024-02-15 20:53:58 --> Output Class Initialized
INFO - 2024-02-15 20:53:58 --> Security Class Initialized
DEBUG - 2024-02-15 20:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:53:58 --> Input Class Initialized
INFO - 2024-02-15 20:53:58 --> Language Class Initialized
INFO - 2024-02-15 20:53:58 --> Loader Class Initialized
INFO - 2024-02-15 20:53:58 --> Helper loaded: url_helper
INFO - 2024-02-15 20:53:58 --> Helper loaded: file_helper
INFO - 2024-02-15 20:53:58 --> Helper loaded: form_helper
INFO - 2024-02-15 20:53:58 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:53:58 --> Controller Class Initialized
INFO - 2024-02-15 20:53:58 --> Form Validation Class Initialized
INFO - 2024-02-15 20:53:58 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:53:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:53:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:53:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:53:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:53:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:53:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:53:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:53:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:53:58 --> Final output sent to browser
DEBUG - 2024-02-15 20:53:58 --> Total execution time: 0.0462
ERROR - 2024-02-15 20:53:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:53:59 --> Config Class Initialized
INFO - 2024-02-15 20:53:59 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:53:59 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:53:59 --> Utf8 Class Initialized
INFO - 2024-02-15 20:53:59 --> URI Class Initialized
INFO - 2024-02-15 20:53:59 --> Router Class Initialized
INFO - 2024-02-15 20:53:59 --> Output Class Initialized
INFO - 2024-02-15 20:53:59 --> Security Class Initialized
DEBUG - 2024-02-15 20:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:53:59 --> Input Class Initialized
INFO - 2024-02-15 20:53:59 --> Language Class Initialized
INFO - 2024-02-15 20:53:59 --> Loader Class Initialized
INFO - 2024-02-15 20:53:59 --> Helper loaded: url_helper
INFO - 2024-02-15 20:53:59 --> Helper loaded: file_helper
INFO - 2024-02-15 20:53:59 --> Helper loaded: form_helper
INFO - 2024-02-15 20:53:59 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:53:59 --> Controller Class Initialized
INFO - 2024-02-15 20:53:59 --> Form Validation Class Initialized
INFO - 2024-02-15 20:53:59 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:53:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:53:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:53:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:54:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:54:01 --> Config Class Initialized
INFO - 2024-02-15 20:54:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:54:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:54:01 --> Utf8 Class Initialized
INFO - 2024-02-15 20:54:01 --> URI Class Initialized
INFO - 2024-02-15 20:54:01 --> Router Class Initialized
INFO - 2024-02-15 20:54:01 --> Output Class Initialized
INFO - 2024-02-15 20:54:01 --> Security Class Initialized
DEBUG - 2024-02-15 20:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:54:01 --> Input Class Initialized
INFO - 2024-02-15 20:54:01 --> Language Class Initialized
INFO - 2024-02-15 20:54:01 --> Loader Class Initialized
INFO - 2024-02-15 20:54:01 --> Helper loaded: url_helper
INFO - 2024-02-15 20:54:01 --> Helper loaded: file_helper
INFO - 2024-02-15 20:54:01 --> Helper loaded: form_helper
INFO - 2024-02-15 20:54:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:54:01 --> Controller Class Initialized
INFO - 2024-02-15 20:54:01 --> Form Validation Class Initialized
INFO - 2024-02-15 20:54:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:54:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:54:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:54:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:54:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:54:01 --> Final output sent to browser
DEBUG - 2024-02-15 20:54:01 --> Total execution time: 0.0451
ERROR - 2024-02-15 20:57:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:57:32 --> Config Class Initialized
INFO - 2024-02-15 20:57:32 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:57:32 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:57:32 --> Utf8 Class Initialized
INFO - 2024-02-15 20:57:32 --> URI Class Initialized
INFO - 2024-02-15 20:57:32 --> Router Class Initialized
INFO - 2024-02-15 20:57:32 --> Output Class Initialized
INFO - 2024-02-15 20:57:32 --> Security Class Initialized
DEBUG - 2024-02-15 20:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:57:32 --> Input Class Initialized
INFO - 2024-02-15 20:57:32 --> Language Class Initialized
INFO - 2024-02-15 20:57:32 --> Loader Class Initialized
INFO - 2024-02-15 20:57:32 --> Helper loaded: url_helper
INFO - 2024-02-15 20:57:32 --> Helper loaded: file_helper
INFO - 2024-02-15 20:57:32 --> Helper loaded: form_helper
INFO - 2024-02-15 20:57:32 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:57:32 --> Controller Class Initialized
INFO - 2024-02-15 20:57:32 --> Form Validation Class Initialized
INFO - 2024-02-15 20:57:32 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:57:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:57:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:57:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:57:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 20:57:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 20:57:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 20:57:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 20:57:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 20:57:32 --> Final output sent to browser
DEBUG - 2024-02-15 20:57:32 --> Total execution time: 0.0466
ERROR - 2024-02-15 20:57:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:57:32 --> Config Class Initialized
INFO - 2024-02-15 20:57:32 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:57:32 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:57:32 --> Utf8 Class Initialized
INFO - 2024-02-15 20:57:32 --> URI Class Initialized
INFO - 2024-02-15 20:57:32 --> Router Class Initialized
INFO - 2024-02-15 20:57:32 --> Output Class Initialized
INFO - 2024-02-15 20:57:32 --> Security Class Initialized
DEBUG - 2024-02-15 20:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:57:32 --> Input Class Initialized
INFO - 2024-02-15 20:57:32 --> Language Class Initialized
INFO - 2024-02-15 20:57:32 --> Loader Class Initialized
INFO - 2024-02-15 20:57:32 --> Helper loaded: url_helper
INFO - 2024-02-15 20:57:32 --> Helper loaded: file_helper
INFO - 2024-02-15 20:57:32 --> Helper loaded: form_helper
INFO - 2024-02-15 20:57:32 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:57:32 --> Controller Class Initialized
INFO - 2024-02-15 20:57:32 --> Form Validation Class Initialized
INFO - 2024-02-15 20:57:32 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:57:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:57:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:57:32 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 20:57:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 20:57:35 --> Config Class Initialized
INFO - 2024-02-15 20:57:35 --> Hooks Class Initialized
DEBUG - 2024-02-15 20:57:35 --> UTF-8 Support Enabled
INFO - 2024-02-15 20:57:35 --> Utf8 Class Initialized
INFO - 2024-02-15 20:57:35 --> URI Class Initialized
INFO - 2024-02-15 20:57:35 --> Router Class Initialized
INFO - 2024-02-15 20:57:35 --> Output Class Initialized
INFO - 2024-02-15 20:57:35 --> Security Class Initialized
DEBUG - 2024-02-15 20:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 20:57:35 --> Input Class Initialized
INFO - 2024-02-15 20:57:35 --> Language Class Initialized
INFO - 2024-02-15 20:57:35 --> Loader Class Initialized
INFO - 2024-02-15 20:57:35 --> Helper loaded: url_helper
INFO - 2024-02-15 20:57:35 --> Helper loaded: file_helper
INFO - 2024-02-15 20:57:35 --> Helper loaded: form_helper
INFO - 2024-02-15 20:57:35 --> Database Driver Class Initialized
DEBUG - 2024-02-15 20:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 20:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 20:57:35 --> Controller Class Initialized
INFO - 2024-02-15 20:57:35 --> Form Validation Class Initialized
INFO - 2024-02-15 20:57:35 --> Model "MasterModel" initialized
INFO - 2024-02-15 20:57:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 20:57:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 20:57:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 20:57:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 20:57:35 --> Final output sent to browser
DEBUG - 2024-02-15 20:57:35 --> Total execution time: 0.0446
ERROR - 2024-02-15 21:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:00:58 --> Config Class Initialized
INFO - 2024-02-15 21:00:58 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:00:58 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:00:58 --> Utf8 Class Initialized
INFO - 2024-02-15 21:00:58 --> URI Class Initialized
INFO - 2024-02-15 21:00:58 --> Router Class Initialized
INFO - 2024-02-15 21:00:58 --> Output Class Initialized
INFO - 2024-02-15 21:00:58 --> Security Class Initialized
DEBUG - 2024-02-15 21:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:00:58 --> Input Class Initialized
INFO - 2024-02-15 21:00:58 --> Language Class Initialized
INFO - 2024-02-15 21:00:58 --> Loader Class Initialized
INFO - 2024-02-15 21:00:58 --> Helper loaded: url_helper
INFO - 2024-02-15 21:00:58 --> Helper loaded: file_helper
INFO - 2024-02-15 21:00:58 --> Helper loaded: form_helper
INFO - 2024-02-15 21:00:58 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:00:58 --> Controller Class Initialized
INFO - 2024-02-15 21:00:58 --> Form Validation Class Initialized
INFO - 2024-02-15 21:00:58 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:00:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:00:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:00:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:00:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:00:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:00:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:00:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:00:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:00:58 --> Final output sent to browser
DEBUG - 2024-02-15 21:00:58 --> Total execution time: 0.0520
ERROR - 2024-02-15 21:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:00:58 --> Config Class Initialized
INFO - 2024-02-15 21:00:58 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:00:58 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:00:58 --> Utf8 Class Initialized
INFO - 2024-02-15 21:00:58 --> URI Class Initialized
INFO - 2024-02-15 21:00:58 --> Router Class Initialized
INFO - 2024-02-15 21:00:58 --> Output Class Initialized
INFO - 2024-02-15 21:00:58 --> Security Class Initialized
DEBUG - 2024-02-15 21:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:00:58 --> Input Class Initialized
INFO - 2024-02-15 21:00:58 --> Language Class Initialized
INFO - 2024-02-15 21:00:58 --> Loader Class Initialized
INFO - 2024-02-15 21:00:58 --> Helper loaded: url_helper
INFO - 2024-02-15 21:00:58 --> Helper loaded: file_helper
INFO - 2024-02-15 21:00:58 --> Helper loaded: form_helper
INFO - 2024-02-15 21:00:58 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:00:58 --> Controller Class Initialized
INFO - 2024-02-15 21:00:58 --> Form Validation Class Initialized
INFO - 2024-02-15 21:00:58 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:00:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:00:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:00:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:01:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:01:01 --> Config Class Initialized
INFO - 2024-02-15 21:01:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:01:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:01:01 --> Utf8 Class Initialized
INFO - 2024-02-15 21:01:01 --> URI Class Initialized
INFO - 2024-02-15 21:01:01 --> Router Class Initialized
INFO - 2024-02-15 21:01:01 --> Output Class Initialized
INFO - 2024-02-15 21:01:01 --> Security Class Initialized
DEBUG - 2024-02-15 21:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:01:01 --> Input Class Initialized
INFO - 2024-02-15 21:01:01 --> Language Class Initialized
INFO - 2024-02-15 21:01:01 --> Loader Class Initialized
INFO - 2024-02-15 21:01:01 --> Helper loaded: url_helper
INFO - 2024-02-15 21:01:01 --> Helper loaded: file_helper
INFO - 2024-02-15 21:01:01 --> Helper loaded: form_helper
INFO - 2024-02-15 21:01:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:01:01 --> Controller Class Initialized
INFO - 2024-02-15 21:01:01 --> Form Validation Class Initialized
INFO - 2024-02-15 21:01:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:01:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:01:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:01:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:01:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:01:01 --> Final output sent to browser
DEBUG - 2024-02-15 21:01:01 --> Total execution time: 0.0423
ERROR - 2024-02-15 21:01:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:01:11 --> Config Class Initialized
INFO - 2024-02-15 21:01:11 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:01:11 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:01:11 --> Utf8 Class Initialized
INFO - 2024-02-15 21:01:11 --> URI Class Initialized
INFO - 2024-02-15 21:01:11 --> Router Class Initialized
INFO - 2024-02-15 21:01:11 --> Output Class Initialized
INFO - 2024-02-15 21:01:11 --> Security Class Initialized
DEBUG - 2024-02-15 21:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:01:11 --> Input Class Initialized
INFO - 2024-02-15 21:01:11 --> Language Class Initialized
INFO - 2024-02-15 21:01:11 --> Loader Class Initialized
INFO - 2024-02-15 21:01:11 --> Helper loaded: url_helper
INFO - 2024-02-15 21:01:11 --> Helper loaded: file_helper
INFO - 2024-02-15 21:01:11 --> Helper loaded: form_helper
INFO - 2024-02-15 21:01:11 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:01:11 --> Controller Class Initialized
INFO - 2024-02-15 21:01:11 --> Form Validation Class Initialized
INFO - 2024-02-15 21:01:11 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:01:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:01:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:01:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:01:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:01:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:01:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:01:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:01:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:01:11 --> Final output sent to browser
DEBUG - 2024-02-15 21:01:11 --> Total execution time: 0.0426
ERROR - 2024-02-15 21:01:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:01:11 --> Config Class Initialized
INFO - 2024-02-15 21:01:11 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:01:11 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:01:11 --> Utf8 Class Initialized
INFO - 2024-02-15 21:01:11 --> URI Class Initialized
INFO - 2024-02-15 21:01:11 --> Router Class Initialized
INFO - 2024-02-15 21:01:11 --> Output Class Initialized
INFO - 2024-02-15 21:01:11 --> Security Class Initialized
DEBUG - 2024-02-15 21:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:01:11 --> Input Class Initialized
INFO - 2024-02-15 21:01:11 --> Language Class Initialized
INFO - 2024-02-15 21:01:11 --> Loader Class Initialized
INFO - 2024-02-15 21:01:11 --> Helper loaded: url_helper
INFO - 2024-02-15 21:01:11 --> Helper loaded: file_helper
INFO - 2024-02-15 21:01:11 --> Helper loaded: form_helper
INFO - 2024-02-15 21:01:11 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:01:11 --> Controller Class Initialized
INFO - 2024-02-15 21:01:11 --> Form Validation Class Initialized
INFO - 2024-02-15 21:01:11 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:01:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:01:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:01:11 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:01:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:01:13 --> Config Class Initialized
INFO - 2024-02-15 21:01:13 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:01:13 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:01:13 --> Utf8 Class Initialized
INFO - 2024-02-15 21:01:13 --> URI Class Initialized
INFO - 2024-02-15 21:01:13 --> Router Class Initialized
INFO - 2024-02-15 21:01:13 --> Output Class Initialized
INFO - 2024-02-15 21:01:13 --> Security Class Initialized
DEBUG - 2024-02-15 21:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:01:13 --> Input Class Initialized
INFO - 2024-02-15 21:01:13 --> Language Class Initialized
INFO - 2024-02-15 21:01:13 --> Loader Class Initialized
INFO - 2024-02-15 21:01:13 --> Helper loaded: url_helper
INFO - 2024-02-15 21:01:13 --> Helper loaded: file_helper
INFO - 2024-02-15 21:01:13 --> Helper loaded: form_helper
INFO - 2024-02-15 21:01:13 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:01:13 --> Controller Class Initialized
INFO - 2024-02-15 21:01:13 --> Form Validation Class Initialized
INFO - 2024-02-15 21:01:13 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:01:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:01:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:01:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:01:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:01:13 --> Final output sent to browser
DEBUG - 2024-02-15 21:01:13 --> Total execution time: 0.0446
ERROR - 2024-02-15 21:01:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:01:48 --> Config Class Initialized
INFO - 2024-02-15 21:01:48 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:01:48 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:01:48 --> Utf8 Class Initialized
INFO - 2024-02-15 21:01:48 --> URI Class Initialized
INFO - 2024-02-15 21:01:48 --> Router Class Initialized
INFO - 2024-02-15 21:01:48 --> Output Class Initialized
INFO - 2024-02-15 21:01:48 --> Security Class Initialized
DEBUG - 2024-02-15 21:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:01:48 --> Input Class Initialized
INFO - 2024-02-15 21:01:48 --> Language Class Initialized
INFO - 2024-02-15 21:01:48 --> Loader Class Initialized
INFO - 2024-02-15 21:01:48 --> Helper loaded: url_helper
INFO - 2024-02-15 21:01:48 --> Helper loaded: file_helper
INFO - 2024-02-15 21:01:48 --> Helper loaded: form_helper
INFO - 2024-02-15 21:01:48 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:01:48 --> Controller Class Initialized
INFO - 2024-02-15 21:01:48 --> Form Validation Class Initialized
INFO - 2024-02-15 21:01:48 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:01:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:01:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:01:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:01:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:01:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:01:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:01:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:01:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:01:48 --> Final output sent to browser
DEBUG - 2024-02-15 21:01:48 --> Total execution time: 0.0505
ERROR - 2024-02-15 21:01:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:01:49 --> Config Class Initialized
INFO - 2024-02-15 21:01:49 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:01:49 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:01:49 --> Utf8 Class Initialized
INFO - 2024-02-15 21:01:49 --> URI Class Initialized
INFO - 2024-02-15 21:01:49 --> Router Class Initialized
INFO - 2024-02-15 21:01:49 --> Output Class Initialized
INFO - 2024-02-15 21:01:49 --> Security Class Initialized
DEBUG - 2024-02-15 21:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:01:49 --> Input Class Initialized
INFO - 2024-02-15 21:01:49 --> Language Class Initialized
INFO - 2024-02-15 21:01:49 --> Loader Class Initialized
INFO - 2024-02-15 21:01:49 --> Helper loaded: url_helper
INFO - 2024-02-15 21:01:49 --> Helper loaded: file_helper
INFO - 2024-02-15 21:01:49 --> Helper loaded: form_helper
INFO - 2024-02-15 21:01:49 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:01:49 --> Controller Class Initialized
INFO - 2024-02-15 21:01:49 --> Form Validation Class Initialized
INFO - 2024-02-15 21:01:49 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:01:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:01:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:01:49 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:01:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:01:51 --> Config Class Initialized
INFO - 2024-02-15 21:01:51 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:01:51 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:01:51 --> Utf8 Class Initialized
INFO - 2024-02-15 21:01:51 --> URI Class Initialized
INFO - 2024-02-15 21:01:51 --> Router Class Initialized
INFO - 2024-02-15 21:01:51 --> Output Class Initialized
INFO - 2024-02-15 21:01:51 --> Security Class Initialized
DEBUG - 2024-02-15 21:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:01:51 --> Input Class Initialized
INFO - 2024-02-15 21:01:51 --> Language Class Initialized
INFO - 2024-02-15 21:01:51 --> Loader Class Initialized
INFO - 2024-02-15 21:01:51 --> Helper loaded: url_helper
INFO - 2024-02-15 21:01:51 --> Helper loaded: file_helper
INFO - 2024-02-15 21:01:51 --> Helper loaded: form_helper
INFO - 2024-02-15 21:01:51 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:01:51 --> Controller Class Initialized
INFO - 2024-02-15 21:01:51 --> Form Validation Class Initialized
INFO - 2024-02-15 21:01:51 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:01:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:01:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:01:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:01:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:01:51 --> Final output sent to browser
DEBUG - 2024-02-15 21:01:51 --> Total execution time: 0.0461
ERROR - 2024-02-15 21:02:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:02:11 --> Config Class Initialized
INFO - 2024-02-15 21:02:11 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:02:11 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:02:11 --> Utf8 Class Initialized
INFO - 2024-02-15 21:02:11 --> URI Class Initialized
INFO - 2024-02-15 21:02:11 --> Router Class Initialized
INFO - 2024-02-15 21:02:11 --> Output Class Initialized
INFO - 2024-02-15 21:02:11 --> Security Class Initialized
DEBUG - 2024-02-15 21:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:02:11 --> Input Class Initialized
INFO - 2024-02-15 21:02:11 --> Language Class Initialized
INFO - 2024-02-15 21:02:11 --> Loader Class Initialized
INFO - 2024-02-15 21:02:11 --> Helper loaded: url_helper
INFO - 2024-02-15 21:02:11 --> Helper loaded: file_helper
INFO - 2024-02-15 21:02:11 --> Helper loaded: form_helper
INFO - 2024-02-15 21:02:11 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:02:11 --> Controller Class Initialized
INFO - 2024-02-15 21:02:11 --> Form Validation Class Initialized
INFO - 2024-02-15 21:02:11 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:02:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:02:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:02:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:02:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:02:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:02:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:02:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:02:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:02:11 --> Final output sent to browser
DEBUG - 2024-02-15 21:02:11 --> Total execution time: 0.0510
ERROR - 2024-02-15 21:02:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:02:12 --> Config Class Initialized
INFO - 2024-02-15 21:02:12 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:02:12 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:02:12 --> Utf8 Class Initialized
INFO - 2024-02-15 21:02:12 --> URI Class Initialized
INFO - 2024-02-15 21:02:12 --> Router Class Initialized
INFO - 2024-02-15 21:02:12 --> Output Class Initialized
INFO - 2024-02-15 21:02:12 --> Security Class Initialized
DEBUG - 2024-02-15 21:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:02:12 --> Input Class Initialized
INFO - 2024-02-15 21:02:12 --> Language Class Initialized
INFO - 2024-02-15 21:02:12 --> Loader Class Initialized
INFO - 2024-02-15 21:02:12 --> Helper loaded: url_helper
INFO - 2024-02-15 21:02:12 --> Helper loaded: file_helper
INFO - 2024-02-15 21:02:12 --> Helper loaded: form_helper
INFO - 2024-02-15 21:02:12 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:02:12 --> Controller Class Initialized
INFO - 2024-02-15 21:02:12 --> Form Validation Class Initialized
INFO - 2024-02-15 21:02:12 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:02:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:02:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:02:12 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:02:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:02:15 --> Config Class Initialized
INFO - 2024-02-15 21:02:15 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:02:15 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:02:15 --> Utf8 Class Initialized
INFO - 2024-02-15 21:02:15 --> URI Class Initialized
INFO - 2024-02-15 21:02:15 --> Router Class Initialized
INFO - 2024-02-15 21:02:15 --> Output Class Initialized
INFO - 2024-02-15 21:02:15 --> Security Class Initialized
DEBUG - 2024-02-15 21:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:02:15 --> Input Class Initialized
INFO - 2024-02-15 21:02:15 --> Language Class Initialized
INFO - 2024-02-15 21:02:15 --> Loader Class Initialized
INFO - 2024-02-15 21:02:15 --> Helper loaded: url_helper
INFO - 2024-02-15 21:02:15 --> Helper loaded: file_helper
INFO - 2024-02-15 21:02:15 --> Helper loaded: form_helper
INFO - 2024-02-15 21:02:15 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:02:15 --> Controller Class Initialized
INFO - 2024-02-15 21:02:15 --> Form Validation Class Initialized
INFO - 2024-02-15 21:02:15 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:02:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:02:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:02:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:02:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:02:15 --> Final output sent to browser
DEBUG - 2024-02-15 21:02:15 --> Total execution time: 0.0469
ERROR - 2024-02-15 21:05:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:05:15 --> Config Class Initialized
INFO - 2024-02-15 21:05:15 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:05:15 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:05:15 --> Utf8 Class Initialized
INFO - 2024-02-15 21:05:15 --> URI Class Initialized
INFO - 2024-02-15 21:05:15 --> Router Class Initialized
INFO - 2024-02-15 21:05:15 --> Output Class Initialized
INFO - 2024-02-15 21:05:15 --> Security Class Initialized
DEBUG - 2024-02-15 21:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:05:15 --> Input Class Initialized
INFO - 2024-02-15 21:05:15 --> Language Class Initialized
INFO - 2024-02-15 21:05:15 --> Loader Class Initialized
INFO - 2024-02-15 21:05:15 --> Helper loaded: url_helper
INFO - 2024-02-15 21:05:15 --> Helper loaded: file_helper
INFO - 2024-02-15 21:05:15 --> Helper loaded: form_helper
INFO - 2024-02-15 21:05:15 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:05:15 --> Controller Class Initialized
INFO - 2024-02-15 21:05:15 --> Form Validation Class Initialized
INFO - 2024-02-15 21:05:15 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:05:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:05:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:05:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:05:16 --> Final output sent to browser
DEBUG - 2024-02-15 21:05:16 --> Total execution time: 0.0386
ERROR - 2024-02-15 21:05:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:05:16 --> Config Class Initialized
INFO - 2024-02-15 21:05:16 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:05:16 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:05:16 --> Utf8 Class Initialized
INFO - 2024-02-15 21:05:16 --> URI Class Initialized
INFO - 2024-02-15 21:05:16 --> Router Class Initialized
INFO - 2024-02-15 21:05:16 --> Output Class Initialized
INFO - 2024-02-15 21:05:16 --> Security Class Initialized
DEBUG - 2024-02-15 21:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:05:16 --> Input Class Initialized
INFO - 2024-02-15 21:05:16 --> Language Class Initialized
INFO - 2024-02-15 21:05:16 --> Loader Class Initialized
INFO - 2024-02-15 21:05:16 --> Helper loaded: url_helper
INFO - 2024-02-15 21:05:16 --> Helper loaded: file_helper
INFO - 2024-02-15 21:05:16 --> Helper loaded: form_helper
INFO - 2024-02-15 21:05:16 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:05:16 --> Controller Class Initialized
INFO - 2024-02-15 21:05:16 --> Form Validation Class Initialized
INFO - 2024-02-15 21:05:16 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:05:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:05:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:05:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:05:16 --> Final output sent to browser
DEBUG - 2024-02-15 21:05:16 --> Total execution time: 0.0370
ERROR - 2024-02-15 21:05:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:05:16 --> Config Class Initialized
INFO - 2024-02-15 21:05:16 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:05:16 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:05:16 --> Utf8 Class Initialized
INFO - 2024-02-15 21:05:16 --> URI Class Initialized
INFO - 2024-02-15 21:05:16 --> Router Class Initialized
INFO - 2024-02-15 21:05:16 --> Output Class Initialized
INFO - 2024-02-15 21:05:16 --> Security Class Initialized
DEBUG - 2024-02-15 21:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:05:16 --> Input Class Initialized
INFO - 2024-02-15 21:05:16 --> Language Class Initialized
INFO - 2024-02-15 21:05:16 --> Loader Class Initialized
INFO - 2024-02-15 21:05:16 --> Helper loaded: url_helper
INFO - 2024-02-15 21:05:16 --> Helper loaded: file_helper
INFO - 2024-02-15 21:05:16 --> Helper loaded: form_helper
INFO - 2024-02-15 21:05:16 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:05:16 --> Controller Class Initialized
INFO - 2024-02-15 21:05:16 --> Form Validation Class Initialized
INFO - 2024-02-15 21:05:16 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:05:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:05:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:05:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:05:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:05:16 --> Final output sent to browser
DEBUG - 2024-02-15 21:05:16 --> Total execution time: 0.0312
ERROR - 2024-02-15 21:05:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:05:17 --> Config Class Initialized
INFO - 2024-02-15 21:05:17 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:05:17 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:05:17 --> Utf8 Class Initialized
INFO - 2024-02-15 21:05:17 --> URI Class Initialized
INFO - 2024-02-15 21:05:17 --> Router Class Initialized
INFO - 2024-02-15 21:05:17 --> Output Class Initialized
INFO - 2024-02-15 21:05:17 --> Security Class Initialized
DEBUG - 2024-02-15 21:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:05:17 --> Input Class Initialized
INFO - 2024-02-15 21:05:17 --> Language Class Initialized
INFO - 2024-02-15 21:05:17 --> Loader Class Initialized
INFO - 2024-02-15 21:05:17 --> Helper loaded: url_helper
INFO - 2024-02-15 21:05:17 --> Helper loaded: file_helper
INFO - 2024-02-15 21:05:17 --> Helper loaded: form_helper
INFO - 2024-02-15 21:05:17 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:05:17 --> Controller Class Initialized
INFO - 2024-02-15 21:05:17 --> Form Validation Class Initialized
INFO - 2024-02-15 21:05:17 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:05:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:05:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:05:17 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:06:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:06:06 --> Config Class Initialized
INFO - 2024-02-15 21:06:06 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:06:06 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:06:06 --> Utf8 Class Initialized
INFO - 2024-02-15 21:06:06 --> URI Class Initialized
INFO - 2024-02-15 21:06:06 --> Router Class Initialized
INFO - 2024-02-15 21:06:06 --> Output Class Initialized
INFO - 2024-02-15 21:06:06 --> Security Class Initialized
DEBUG - 2024-02-15 21:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:06:06 --> Input Class Initialized
INFO - 2024-02-15 21:06:06 --> Language Class Initialized
INFO - 2024-02-15 21:06:06 --> Loader Class Initialized
INFO - 2024-02-15 21:06:06 --> Helper loaded: url_helper
INFO - 2024-02-15 21:06:06 --> Helper loaded: file_helper
INFO - 2024-02-15 21:06:06 --> Helper loaded: form_helper
INFO - 2024-02-15 21:06:06 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:06:06 --> Controller Class Initialized
INFO - 2024-02-15 21:06:06 --> Form Validation Class Initialized
INFO - 2024-02-15 21:06:06 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:06:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:06:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:06:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:06:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:06:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:06:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:06:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:06:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:06:06 --> Final output sent to browser
DEBUG - 2024-02-15 21:06:06 --> Total execution time: 0.0448
ERROR - 2024-02-15 21:06:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:06:07 --> Config Class Initialized
INFO - 2024-02-15 21:06:07 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:06:07 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:06:07 --> Utf8 Class Initialized
INFO - 2024-02-15 21:06:07 --> URI Class Initialized
INFO - 2024-02-15 21:06:07 --> Router Class Initialized
INFO - 2024-02-15 21:06:07 --> Output Class Initialized
INFO - 2024-02-15 21:06:07 --> Security Class Initialized
DEBUG - 2024-02-15 21:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:06:07 --> Input Class Initialized
INFO - 2024-02-15 21:06:07 --> Language Class Initialized
INFO - 2024-02-15 21:06:07 --> Loader Class Initialized
INFO - 2024-02-15 21:06:07 --> Helper loaded: url_helper
INFO - 2024-02-15 21:06:07 --> Helper loaded: file_helper
INFO - 2024-02-15 21:06:07 --> Helper loaded: form_helper
INFO - 2024-02-15 21:06:07 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:06:07 --> Controller Class Initialized
INFO - 2024-02-15 21:06:07 --> Form Validation Class Initialized
INFO - 2024-02-15 21:06:07 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:06:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:06:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:06:07 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:06:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:06:10 --> Config Class Initialized
INFO - 2024-02-15 21:06:10 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:06:10 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:06:10 --> Utf8 Class Initialized
INFO - 2024-02-15 21:06:10 --> URI Class Initialized
INFO - 2024-02-15 21:06:10 --> Router Class Initialized
INFO - 2024-02-15 21:06:10 --> Output Class Initialized
INFO - 2024-02-15 21:06:10 --> Security Class Initialized
DEBUG - 2024-02-15 21:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:06:10 --> Input Class Initialized
INFO - 2024-02-15 21:06:10 --> Language Class Initialized
INFO - 2024-02-15 21:06:10 --> Loader Class Initialized
INFO - 2024-02-15 21:06:10 --> Helper loaded: url_helper
INFO - 2024-02-15 21:06:10 --> Helper loaded: file_helper
INFO - 2024-02-15 21:06:10 --> Helper loaded: form_helper
INFO - 2024-02-15 21:06:10 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:06:10 --> Controller Class Initialized
INFO - 2024-02-15 21:06:10 --> Form Validation Class Initialized
INFO - 2024-02-15 21:06:10 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:06:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:06:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:06:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:06:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:06:10 --> Final output sent to browser
DEBUG - 2024-02-15 21:06:10 --> Total execution time: 0.0470
ERROR - 2024-02-15 21:07:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:07:20 --> Config Class Initialized
INFO - 2024-02-15 21:07:20 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:07:20 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:07:20 --> Utf8 Class Initialized
INFO - 2024-02-15 21:07:20 --> URI Class Initialized
INFO - 2024-02-15 21:07:20 --> Router Class Initialized
INFO - 2024-02-15 21:07:20 --> Output Class Initialized
INFO - 2024-02-15 21:07:20 --> Security Class Initialized
DEBUG - 2024-02-15 21:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:07:20 --> Input Class Initialized
INFO - 2024-02-15 21:07:20 --> Language Class Initialized
INFO - 2024-02-15 21:07:20 --> Loader Class Initialized
INFO - 2024-02-15 21:07:20 --> Helper loaded: url_helper
INFO - 2024-02-15 21:07:20 --> Helper loaded: file_helper
INFO - 2024-02-15 21:07:20 --> Helper loaded: form_helper
INFO - 2024-02-15 21:07:20 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:07:20 --> Controller Class Initialized
INFO - 2024-02-15 21:07:20 --> Form Validation Class Initialized
INFO - 2024-02-15 21:07:20 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:07:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:07:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:07:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:07:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:07:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:07:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:07:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:07:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:07:20 --> Final output sent to browser
DEBUG - 2024-02-15 21:07:20 --> Total execution time: 0.0421
ERROR - 2024-02-15 21:07:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:07:21 --> Config Class Initialized
INFO - 2024-02-15 21:07:21 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:07:21 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:07:21 --> Utf8 Class Initialized
INFO - 2024-02-15 21:07:21 --> URI Class Initialized
INFO - 2024-02-15 21:07:21 --> Router Class Initialized
INFO - 2024-02-15 21:07:21 --> Output Class Initialized
INFO - 2024-02-15 21:07:21 --> Security Class Initialized
DEBUG - 2024-02-15 21:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:07:21 --> Input Class Initialized
INFO - 2024-02-15 21:07:21 --> Language Class Initialized
INFO - 2024-02-15 21:07:21 --> Loader Class Initialized
INFO - 2024-02-15 21:07:21 --> Helper loaded: url_helper
INFO - 2024-02-15 21:07:21 --> Helper loaded: file_helper
INFO - 2024-02-15 21:07:21 --> Helper loaded: form_helper
INFO - 2024-02-15 21:07:21 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:07:21 --> Controller Class Initialized
INFO - 2024-02-15 21:07:21 --> Form Validation Class Initialized
INFO - 2024-02-15 21:07:21 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:07:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:07:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:07:21 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:07:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:07:23 --> Config Class Initialized
INFO - 2024-02-15 21:07:23 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:07:23 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:07:23 --> Utf8 Class Initialized
INFO - 2024-02-15 21:07:23 --> URI Class Initialized
INFO - 2024-02-15 21:07:23 --> Router Class Initialized
INFO - 2024-02-15 21:07:23 --> Output Class Initialized
INFO - 2024-02-15 21:07:23 --> Security Class Initialized
DEBUG - 2024-02-15 21:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:07:23 --> Input Class Initialized
INFO - 2024-02-15 21:07:23 --> Language Class Initialized
INFO - 2024-02-15 21:07:23 --> Loader Class Initialized
INFO - 2024-02-15 21:07:23 --> Helper loaded: url_helper
INFO - 2024-02-15 21:07:23 --> Helper loaded: file_helper
INFO - 2024-02-15 21:07:23 --> Helper loaded: form_helper
INFO - 2024-02-15 21:07:23 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:07:23 --> Controller Class Initialized
INFO - 2024-02-15 21:07:23 --> Form Validation Class Initialized
INFO - 2024-02-15 21:07:23 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:07:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:07:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:07:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:07:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:07:23 --> Final output sent to browser
DEBUG - 2024-02-15 21:07:23 --> Total execution time: 0.0461
ERROR - 2024-02-15 21:08:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:08:13 --> Config Class Initialized
INFO - 2024-02-15 21:08:13 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:08:13 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:08:13 --> Utf8 Class Initialized
INFO - 2024-02-15 21:08:13 --> URI Class Initialized
INFO - 2024-02-15 21:08:13 --> Router Class Initialized
INFO - 2024-02-15 21:08:13 --> Output Class Initialized
INFO - 2024-02-15 21:08:13 --> Security Class Initialized
DEBUG - 2024-02-15 21:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:08:13 --> Input Class Initialized
INFO - 2024-02-15 21:08:13 --> Language Class Initialized
INFO - 2024-02-15 21:08:13 --> Loader Class Initialized
INFO - 2024-02-15 21:08:13 --> Helper loaded: url_helper
INFO - 2024-02-15 21:08:13 --> Helper loaded: file_helper
INFO - 2024-02-15 21:08:13 --> Helper loaded: form_helper
INFO - 2024-02-15 21:08:13 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:08:13 --> Controller Class Initialized
INFO - 2024-02-15 21:08:13 --> Form Validation Class Initialized
INFO - 2024-02-15 21:08:13 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:08:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:08:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:08:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:08:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:08:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:08:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:08:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:08:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:08:13 --> Final output sent to browser
DEBUG - 2024-02-15 21:08:13 --> Total execution time: 0.0374
ERROR - 2024-02-15 21:08:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:08:13 --> Config Class Initialized
INFO - 2024-02-15 21:08:13 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:08:13 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:08:13 --> Utf8 Class Initialized
INFO - 2024-02-15 21:08:13 --> URI Class Initialized
INFO - 2024-02-15 21:08:13 --> Router Class Initialized
INFO - 2024-02-15 21:08:13 --> Output Class Initialized
INFO - 2024-02-15 21:08:13 --> Security Class Initialized
DEBUG - 2024-02-15 21:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:08:13 --> Input Class Initialized
INFO - 2024-02-15 21:08:13 --> Language Class Initialized
INFO - 2024-02-15 21:08:13 --> Loader Class Initialized
INFO - 2024-02-15 21:08:13 --> Helper loaded: url_helper
INFO - 2024-02-15 21:08:13 --> Helper loaded: file_helper
INFO - 2024-02-15 21:08:13 --> Helper loaded: form_helper
INFO - 2024-02-15 21:08:13 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:08:13 --> Controller Class Initialized
INFO - 2024-02-15 21:08:13 --> Form Validation Class Initialized
INFO - 2024-02-15 21:08:13 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:08:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:08:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:08:13 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:08:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:08:16 --> Config Class Initialized
INFO - 2024-02-15 21:08:16 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:08:16 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:08:16 --> Utf8 Class Initialized
INFO - 2024-02-15 21:08:16 --> URI Class Initialized
INFO - 2024-02-15 21:08:16 --> Router Class Initialized
INFO - 2024-02-15 21:08:16 --> Output Class Initialized
INFO - 2024-02-15 21:08:16 --> Security Class Initialized
DEBUG - 2024-02-15 21:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:08:16 --> Input Class Initialized
INFO - 2024-02-15 21:08:16 --> Language Class Initialized
INFO - 2024-02-15 21:08:16 --> Loader Class Initialized
INFO - 2024-02-15 21:08:16 --> Helper loaded: url_helper
INFO - 2024-02-15 21:08:16 --> Helper loaded: file_helper
INFO - 2024-02-15 21:08:16 --> Helper loaded: form_helper
INFO - 2024-02-15 21:08:16 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:08:16 --> Controller Class Initialized
INFO - 2024-02-15 21:08:16 --> Form Validation Class Initialized
INFO - 2024-02-15 21:08:16 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:08:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:08:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:08:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:08:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:08:16 --> Final output sent to browser
DEBUG - 2024-02-15 21:08:16 --> Total execution time: 0.0491
ERROR - 2024-02-15 21:08:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:08:37 --> Config Class Initialized
INFO - 2024-02-15 21:08:37 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:08:37 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:08:37 --> Utf8 Class Initialized
INFO - 2024-02-15 21:08:37 --> URI Class Initialized
INFO - 2024-02-15 21:08:37 --> Router Class Initialized
INFO - 2024-02-15 21:08:37 --> Output Class Initialized
INFO - 2024-02-15 21:08:37 --> Security Class Initialized
DEBUG - 2024-02-15 21:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:08:37 --> Input Class Initialized
INFO - 2024-02-15 21:08:37 --> Language Class Initialized
INFO - 2024-02-15 21:08:37 --> Loader Class Initialized
INFO - 2024-02-15 21:08:37 --> Helper loaded: url_helper
INFO - 2024-02-15 21:08:37 --> Helper loaded: file_helper
INFO - 2024-02-15 21:08:37 --> Helper loaded: form_helper
INFO - 2024-02-15 21:08:37 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:08:37 --> Controller Class Initialized
INFO - 2024-02-15 21:08:37 --> Form Validation Class Initialized
INFO - 2024-02-15 21:08:37 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:08:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:08:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:08:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:08:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:08:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:08:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:08:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:08:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:08:37 --> Final output sent to browser
DEBUG - 2024-02-15 21:08:37 --> Total execution time: 0.0488
ERROR - 2024-02-15 21:08:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:08:38 --> Config Class Initialized
INFO - 2024-02-15 21:08:38 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:08:38 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:08:38 --> Utf8 Class Initialized
INFO - 2024-02-15 21:08:38 --> URI Class Initialized
INFO - 2024-02-15 21:08:38 --> Router Class Initialized
INFO - 2024-02-15 21:08:38 --> Output Class Initialized
INFO - 2024-02-15 21:08:38 --> Security Class Initialized
DEBUG - 2024-02-15 21:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:08:38 --> Input Class Initialized
INFO - 2024-02-15 21:08:38 --> Language Class Initialized
INFO - 2024-02-15 21:08:38 --> Loader Class Initialized
INFO - 2024-02-15 21:08:38 --> Helper loaded: url_helper
INFO - 2024-02-15 21:08:38 --> Helper loaded: file_helper
INFO - 2024-02-15 21:08:38 --> Helper loaded: form_helper
INFO - 2024-02-15 21:08:38 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:08:38 --> Controller Class Initialized
INFO - 2024-02-15 21:08:38 --> Form Validation Class Initialized
INFO - 2024-02-15 21:08:38 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:08:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:08:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:08:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:08:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:08:40 --> Config Class Initialized
INFO - 2024-02-15 21:08:40 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:08:40 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:08:40 --> Utf8 Class Initialized
INFO - 2024-02-15 21:08:40 --> URI Class Initialized
INFO - 2024-02-15 21:08:40 --> Router Class Initialized
INFO - 2024-02-15 21:08:40 --> Output Class Initialized
INFO - 2024-02-15 21:08:40 --> Security Class Initialized
DEBUG - 2024-02-15 21:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:08:40 --> Input Class Initialized
INFO - 2024-02-15 21:08:40 --> Language Class Initialized
INFO - 2024-02-15 21:08:40 --> Loader Class Initialized
INFO - 2024-02-15 21:08:40 --> Helper loaded: url_helper
INFO - 2024-02-15 21:08:40 --> Helper loaded: file_helper
INFO - 2024-02-15 21:08:40 --> Helper loaded: form_helper
INFO - 2024-02-15 21:08:40 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:08:40 --> Controller Class Initialized
INFO - 2024-02-15 21:08:40 --> Form Validation Class Initialized
INFO - 2024-02-15 21:08:40 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:08:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:08:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:08:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:08:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:08:40 --> Final output sent to browser
DEBUG - 2024-02-15 21:08:40 --> Total execution time: 0.0437
ERROR - 2024-02-15 21:09:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:09:23 --> Config Class Initialized
INFO - 2024-02-15 21:09:23 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:09:23 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:09:23 --> Utf8 Class Initialized
INFO - 2024-02-15 21:09:23 --> URI Class Initialized
INFO - 2024-02-15 21:09:23 --> Router Class Initialized
INFO - 2024-02-15 21:09:23 --> Output Class Initialized
INFO - 2024-02-15 21:09:23 --> Security Class Initialized
DEBUG - 2024-02-15 21:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:09:23 --> Input Class Initialized
INFO - 2024-02-15 21:09:23 --> Language Class Initialized
INFO - 2024-02-15 21:09:23 --> Loader Class Initialized
INFO - 2024-02-15 21:09:23 --> Helper loaded: url_helper
INFO - 2024-02-15 21:09:23 --> Helper loaded: file_helper
INFO - 2024-02-15 21:09:23 --> Helper loaded: form_helper
INFO - 2024-02-15 21:09:23 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:09:23 --> Controller Class Initialized
INFO - 2024-02-15 21:09:23 --> Form Validation Class Initialized
INFO - 2024-02-15 21:09:23 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:09:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:09:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:09:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:09:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:09:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:09:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:09:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:09:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:09:23 --> Final output sent to browser
DEBUG - 2024-02-15 21:09:23 --> Total execution time: 0.0402
ERROR - 2024-02-15 21:09:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:09:24 --> Config Class Initialized
INFO - 2024-02-15 21:09:24 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:09:24 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:09:24 --> Utf8 Class Initialized
INFO - 2024-02-15 21:09:24 --> URI Class Initialized
INFO - 2024-02-15 21:09:24 --> Router Class Initialized
INFO - 2024-02-15 21:09:24 --> Output Class Initialized
INFO - 2024-02-15 21:09:24 --> Security Class Initialized
DEBUG - 2024-02-15 21:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:09:24 --> Input Class Initialized
INFO - 2024-02-15 21:09:24 --> Language Class Initialized
INFO - 2024-02-15 21:09:24 --> Loader Class Initialized
INFO - 2024-02-15 21:09:24 --> Helper loaded: url_helper
INFO - 2024-02-15 21:09:24 --> Helper loaded: file_helper
INFO - 2024-02-15 21:09:24 --> Helper loaded: form_helper
INFO - 2024-02-15 21:09:24 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:09:24 --> Controller Class Initialized
INFO - 2024-02-15 21:09:24 --> Form Validation Class Initialized
INFO - 2024-02-15 21:09:24 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:09:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:09:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:09:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:09:26 --> Config Class Initialized
INFO - 2024-02-15 21:09:26 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:09:26 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:09:26 --> Utf8 Class Initialized
INFO - 2024-02-15 21:09:26 --> URI Class Initialized
INFO - 2024-02-15 21:09:26 --> Router Class Initialized
INFO - 2024-02-15 21:09:26 --> Output Class Initialized
INFO - 2024-02-15 21:09:26 --> Security Class Initialized
DEBUG - 2024-02-15 21:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:09:26 --> Input Class Initialized
INFO - 2024-02-15 21:09:26 --> Language Class Initialized
INFO - 2024-02-15 21:09:26 --> Loader Class Initialized
INFO - 2024-02-15 21:09:26 --> Helper loaded: url_helper
INFO - 2024-02-15 21:09:26 --> Helper loaded: file_helper
INFO - 2024-02-15 21:09:26 --> Helper loaded: form_helper
INFO - 2024-02-15 21:09:26 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:09:26 --> Controller Class Initialized
INFO - 2024-02-15 21:09:26 --> Form Validation Class Initialized
INFO - 2024-02-15 21:09:26 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:09:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:09:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:09:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:09:26 --> Final output sent to browser
DEBUG - 2024-02-15 21:09:26 --> Total execution time: 0.0419
ERROR - 2024-02-15 21:09:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:09:33 --> Config Class Initialized
INFO - 2024-02-15 21:09:33 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:09:33 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:09:33 --> Utf8 Class Initialized
INFO - 2024-02-15 21:09:33 --> URI Class Initialized
INFO - 2024-02-15 21:09:33 --> Router Class Initialized
INFO - 2024-02-15 21:09:33 --> Output Class Initialized
INFO - 2024-02-15 21:09:33 --> Security Class Initialized
DEBUG - 2024-02-15 21:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:09:33 --> Input Class Initialized
INFO - 2024-02-15 21:09:33 --> Language Class Initialized
INFO - 2024-02-15 21:09:33 --> Loader Class Initialized
INFO - 2024-02-15 21:09:33 --> Helper loaded: url_helper
INFO - 2024-02-15 21:09:33 --> Helper loaded: file_helper
INFO - 2024-02-15 21:09:33 --> Helper loaded: form_helper
INFO - 2024-02-15 21:09:33 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:09:33 --> Controller Class Initialized
INFO - 2024-02-15 21:09:33 --> Form Validation Class Initialized
INFO - 2024-02-15 21:09:33 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:09:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:09:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:09:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:09:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:09:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:09:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:09:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:09:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:09:33 --> Final output sent to browser
DEBUG - 2024-02-15 21:09:33 --> Total execution time: 0.0453
ERROR - 2024-02-15 21:09:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:09:34 --> Config Class Initialized
INFO - 2024-02-15 21:09:34 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:09:34 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:09:34 --> Utf8 Class Initialized
INFO - 2024-02-15 21:09:34 --> URI Class Initialized
INFO - 2024-02-15 21:09:34 --> Router Class Initialized
INFO - 2024-02-15 21:09:34 --> Output Class Initialized
INFO - 2024-02-15 21:09:34 --> Security Class Initialized
DEBUG - 2024-02-15 21:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:09:34 --> Input Class Initialized
INFO - 2024-02-15 21:09:34 --> Language Class Initialized
INFO - 2024-02-15 21:09:34 --> Loader Class Initialized
INFO - 2024-02-15 21:09:34 --> Helper loaded: url_helper
INFO - 2024-02-15 21:09:34 --> Helper loaded: file_helper
INFO - 2024-02-15 21:09:34 --> Helper loaded: form_helper
INFO - 2024-02-15 21:09:34 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:09:34 --> Controller Class Initialized
INFO - 2024-02-15 21:09:34 --> Form Validation Class Initialized
INFO - 2024-02-15 21:09:34 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:09:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:09:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:09:34 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:09:36 --> Config Class Initialized
INFO - 2024-02-15 21:09:36 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:09:36 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:09:36 --> Utf8 Class Initialized
INFO - 2024-02-15 21:09:36 --> URI Class Initialized
INFO - 2024-02-15 21:09:36 --> Router Class Initialized
INFO - 2024-02-15 21:09:36 --> Output Class Initialized
INFO - 2024-02-15 21:09:36 --> Security Class Initialized
DEBUG - 2024-02-15 21:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:09:36 --> Input Class Initialized
INFO - 2024-02-15 21:09:36 --> Language Class Initialized
INFO - 2024-02-15 21:09:36 --> Loader Class Initialized
INFO - 2024-02-15 21:09:36 --> Helper loaded: url_helper
INFO - 2024-02-15 21:09:36 --> Helper loaded: file_helper
INFO - 2024-02-15 21:09:36 --> Helper loaded: form_helper
INFO - 2024-02-15 21:09:36 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:09:36 --> Controller Class Initialized
INFO - 2024-02-15 21:09:36 --> Form Validation Class Initialized
INFO - 2024-02-15 21:09:36 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:09:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:09:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:09:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:09:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:09:36 --> Final output sent to browser
DEBUG - 2024-02-15 21:09:36 --> Total execution time: 0.0468
ERROR - 2024-02-15 21:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:11:03 --> Config Class Initialized
INFO - 2024-02-15 21:11:03 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:11:03 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:11:03 --> Utf8 Class Initialized
INFO - 2024-02-15 21:11:03 --> URI Class Initialized
INFO - 2024-02-15 21:11:03 --> Router Class Initialized
INFO - 2024-02-15 21:11:03 --> Output Class Initialized
INFO - 2024-02-15 21:11:03 --> Security Class Initialized
DEBUG - 2024-02-15 21:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:11:03 --> Input Class Initialized
INFO - 2024-02-15 21:11:03 --> Language Class Initialized
INFO - 2024-02-15 21:11:03 --> Loader Class Initialized
INFO - 2024-02-15 21:11:03 --> Helper loaded: url_helper
INFO - 2024-02-15 21:11:03 --> Helper loaded: file_helper
INFO - 2024-02-15 21:11:03 --> Helper loaded: form_helper
INFO - 2024-02-15 21:11:03 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:11:03 --> Controller Class Initialized
INFO - 2024-02-15 21:11:03 --> Form Validation Class Initialized
INFO - 2024-02-15 21:11:03 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:11:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:11:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:11:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:11:03 --> Final output sent to browser
DEBUG - 2024-02-15 21:11:03 --> Total execution time: 0.0454
ERROR - 2024-02-15 21:11:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:11:04 --> Config Class Initialized
INFO - 2024-02-15 21:11:04 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:11:04 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:11:04 --> Utf8 Class Initialized
INFO - 2024-02-15 21:11:04 --> URI Class Initialized
INFO - 2024-02-15 21:11:04 --> Router Class Initialized
INFO - 2024-02-15 21:11:04 --> Output Class Initialized
INFO - 2024-02-15 21:11:04 --> Security Class Initialized
DEBUG - 2024-02-15 21:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:11:04 --> Input Class Initialized
INFO - 2024-02-15 21:11:04 --> Language Class Initialized
INFO - 2024-02-15 21:11:04 --> Loader Class Initialized
INFO - 2024-02-15 21:11:04 --> Helper loaded: url_helper
INFO - 2024-02-15 21:11:04 --> Helper loaded: file_helper
INFO - 2024-02-15 21:11:04 --> Helper loaded: form_helper
INFO - 2024-02-15 21:11:04 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:11:04 --> Controller Class Initialized
INFO - 2024-02-15 21:11:04 --> Form Validation Class Initialized
INFO - 2024-02-15 21:11:04 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:11:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:11:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:11:04 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:11:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:11:06 --> Config Class Initialized
INFO - 2024-02-15 21:11:06 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:11:06 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:11:06 --> Utf8 Class Initialized
INFO - 2024-02-15 21:11:06 --> URI Class Initialized
INFO - 2024-02-15 21:11:06 --> Router Class Initialized
INFO - 2024-02-15 21:11:06 --> Output Class Initialized
INFO - 2024-02-15 21:11:06 --> Security Class Initialized
DEBUG - 2024-02-15 21:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:11:06 --> Input Class Initialized
INFO - 2024-02-15 21:11:06 --> Language Class Initialized
INFO - 2024-02-15 21:11:06 --> Loader Class Initialized
INFO - 2024-02-15 21:11:06 --> Helper loaded: url_helper
INFO - 2024-02-15 21:11:06 --> Helper loaded: file_helper
INFO - 2024-02-15 21:11:06 --> Helper loaded: form_helper
INFO - 2024-02-15 21:11:06 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:11:06 --> Controller Class Initialized
INFO - 2024-02-15 21:11:06 --> Form Validation Class Initialized
INFO - 2024-02-15 21:11:06 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:11:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:11:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:11:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:11:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:11:06 --> Final output sent to browser
DEBUG - 2024-02-15 21:11:06 --> Total execution time: 0.0419
ERROR - 2024-02-15 21:12:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:12:16 --> Config Class Initialized
INFO - 2024-02-15 21:12:16 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:12:16 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:12:16 --> Utf8 Class Initialized
INFO - 2024-02-15 21:12:16 --> URI Class Initialized
INFO - 2024-02-15 21:12:16 --> Router Class Initialized
INFO - 2024-02-15 21:12:16 --> Output Class Initialized
INFO - 2024-02-15 21:12:16 --> Security Class Initialized
DEBUG - 2024-02-15 21:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:12:16 --> Input Class Initialized
INFO - 2024-02-15 21:12:16 --> Language Class Initialized
INFO - 2024-02-15 21:12:16 --> Loader Class Initialized
INFO - 2024-02-15 21:12:16 --> Helper loaded: url_helper
INFO - 2024-02-15 21:12:16 --> Helper loaded: file_helper
INFO - 2024-02-15 21:12:16 --> Helper loaded: form_helper
INFO - 2024-02-15 21:12:16 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:12:16 --> Controller Class Initialized
INFO - 2024-02-15 21:12:16 --> Form Validation Class Initialized
INFO - 2024-02-15 21:12:16 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:12:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:12:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:12:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:12:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:12:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:12:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:12:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:12:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:12:16 --> Final output sent to browser
DEBUG - 2024-02-15 21:12:16 --> Total execution time: 0.0466
ERROR - 2024-02-15 21:12:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:12:17 --> Config Class Initialized
INFO - 2024-02-15 21:12:17 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:12:17 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:12:17 --> Utf8 Class Initialized
INFO - 2024-02-15 21:12:17 --> URI Class Initialized
INFO - 2024-02-15 21:12:17 --> Router Class Initialized
INFO - 2024-02-15 21:12:17 --> Output Class Initialized
INFO - 2024-02-15 21:12:17 --> Security Class Initialized
DEBUG - 2024-02-15 21:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:12:17 --> Input Class Initialized
INFO - 2024-02-15 21:12:17 --> Language Class Initialized
INFO - 2024-02-15 21:12:17 --> Loader Class Initialized
INFO - 2024-02-15 21:12:17 --> Helper loaded: url_helper
INFO - 2024-02-15 21:12:17 --> Helper loaded: file_helper
INFO - 2024-02-15 21:12:17 --> Helper loaded: form_helper
INFO - 2024-02-15 21:12:17 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:12:17 --> Controller Class Initialized
INFO - 2024-02-15 21:12:17 --> Form Validation Class Initialized
INFO - 2024-02-15 21:12:17 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:12:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:12:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:12:17 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:12:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:12:20 --> Config Class Initialized
INFO - 2024-02-15 21:12:20 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:12:20 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:12:20 --> Utf8 Class Initialized
INFO - 2024-02-15 21:12:20 --> URI Class Initialized
INFO - 2024-02-15 21:12:20 --> Router Class Initialized
INFO - 2024-02-15 21:12:20 --> Output Class Initialized
INFO - 2024-02-15 21:12:20 --> Security Class Initialized
DEBUG - 2024-02-15 21:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:12:20 --> Input Class Initialized
INFO - 2024-02-15 21:12:20 --> Language Class Initialized
INFO - 2024-02-15 21:12:20 --> Loader Class Initialized
INFO - 2024-02-15 21:12:20 --> Helper loaded: url_helper
INFO - 2024-02-15 21:12:20 --> Helper loaded: file_helper
INFO - 2024-02-15 21:12:20 --> Helper loaded: form_helper
INFO - 2024-02-15 21:12:20 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:12:20 --> Controller Class Initialized
INFO - 2024-02-15 21:12:20 --> Form Validation Class Initialized
INFO - 2024-02-15 21:12:20 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:12:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:12:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:12:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:12:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:12:20 --> Final output sent to browser
DEBUG - 2024-02-15 21:12:20 --> Total execution time: 0.0392
ERROR - 2024-02-15 21:12:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:12:53 --> Config Class Initialized
INFO - 2024-02-15 21:12:53 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:12:53 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:12:53 --> Utf8 Class Initialized
INFO - 2024-02-15 21:12:53 --> URI Class Initialized
INFO - 2024-02-15 21:12:53 --> Router Class Initialized
INFO - 2024-02-15 21:12:53 --> Output Class Initialized
INFO - 2024-02-15 21:12:53 --> Security Class Initialized
DEBUG - 2024-02-15 21:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:12:53 --> Input Class Initialized
INFO - 2024-02-15 21:12:53 --> Language Class Initialized
INFO - 2024-02-15 21:12:53 --> Loader Class Initialized
INFO - 2024-02-15 21:12:53 --> Helper loaded: url_helper
INFO - 2024-02-15 21:12:53 --> Helper loaded: file_helper
INFO - 2024-02-15 21:12:53 --> Helper loaded: form_helper
INFO - 2024-02-15 21:12:53 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:12:53 --> Controller Class Initialized
INFO - 2024-02-15 21:12:53 --> Form Validation Class Initialized
INFO - 2024-02-15 21:12:53 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:12:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:12:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:12:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:12:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:12:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:12:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:12:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:12:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:12:53 --> Final output sent to browser
DEBUG - 2024-02-15 21:12:53 --> Total execution time: 0.0470
ERROR - 2024-02-15 21:12:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:12:54 --> Config Class Initialized
INFO - 2024-02-15 21:12:54 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:12:54 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:12:54 --> Utf8 Class Initialized
INFO - 2024-02-15 21:12:54 --> URI Class Initialized
INFO - 2024-02-15 21:12:54 --> Router Class Initialized
INFO - 2024-02-15 21:12:54 --> Output Class Initialized
INFO - 2024-02-15 21:12:54 --> Security Class Initialized
DEBUG - 2024-02-15 21:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:12:54 --> Input Class Initialized
INFO - 2024-02-15 21:12:54 --> Language Class Initialized
INFO - 2024-02-15 21:12:54 --> Loader Class Initialized
INFO - 2024-02-15 21:12:54 --> Helper loaded: url_helper
INFO - 2024-02-15 21:12:54 --> Helper loaded: file_helper
INFO - 2024-02-15 21:12:54 --> Helper loaded: form_helper
INFO - 2024-02-15 21:12:54 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:12:54 --> Controller Class Initialized
INFO - 2024-02-15 21:12:54 --> Form Validation Class Initialized
INFO - 2024-02-15 21:12:54 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:12:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:12:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:12:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:12:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:12:55 --> Config Class Initialized
INFO - 2024-02-15 21:12:55 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:12:55 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:12:55 --> Utf8 Class Initialized
INFO - 2024-02-15 21:12:55 --> URI Class Initialized
INFO - 2024-02-15 21:12:55 --> Router Class Initialized
INFO - 2024-02-15 21:12:55 --> Output Class Initialized
INFO - 2024-02-15 21:12:55 --> Security Class Initialized
DEBUG - 2024-02-15 21:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:12:55 --> Input Class Initialized
INFO - 2024-02-15 21:12:55 --> Language Class Initialized
INFO - 2024-02-15 21:12:55 --> Loader Class Initialized
INFO - 2024-02-15 21:12:55 --> Helper loaded: url_helper
INFO - 2024-02-15 21:12:55 --> Helper loaded: file_helper
INFO - 2024-02-15 21:12:55 --> Helper loaded: form_helper
INFO - 2024-02-15 21:12:55 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:12:55 --> Controller Class Initialized
INFO - 2024-02-15 21:12:55 --> Form Validation Class Initialized
INFO - 2024-02-15 21:12:55 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:12:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:12:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:12:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:12:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:12:55 --> Final output sent to browser
DEBUG - 2024-02-15 21:12:55 --> Total execution time: 0.0419
ERROR - 2024-02-15 21:13:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:13:16 --> Config Class Initialized
INFO - 2024-02-15 21:13:16 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:13:16 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:13:16 --> Utf8 Class Initialized
INFO - 2024-02-15 21:13:16 --> URI Class Initialized
INFO - 2024-02-15 21:13:16 --> Router Class Initialized
INFO - 2024-02-15 21:13:16 --> Output Class Initialized
INFO - 2024-02-15 21:13:16 --> Security Class Initialized
DEBUG - 2024-02-15 21:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:13:16 --> Input Class Initialized
INFO - 2024-02-15 21:13:16 --> Language Class Initialized
INFO - 2024-02-15 21:13:16 --> Loader Class Initialized
INFO - 2024-02-15 21:13:16 --> Helper loaded: url_helper
INFO - 2024-02-15 21:13:16 --> Helper loaded: file_helper
INFO - 2024-02-15 21:13:16 --> Helper loaded: form_helper
INFO - 2024-02-15 21:13:16 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:13:16 --> Controller Class Initialized
INFO - 2024-02-15 21:13:16 --> Form Validation Class Initialized
INFO - 2024-02-15 21:13:16 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:13:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:13:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:13:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:13:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:13:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:13:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:13:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:13:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:13:16 --> Final output sent to browser
DEBUG - 2024-02-15 21:13:16 --> Total execution time: 0.0391
ERROR - 2024-02-15 21:13:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:13:17 --> Config Class Initialized
INFO - 2024-02-15 21:13:17 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:13:17 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:13:17 --> Utf8 Class Initialized
INFO - 2024-02-15 21:13:17 --> URI Class Initialized
INFO - 2024-02-15 21:13:17 --> Router Class Initialized
INFO - 2024-02-15 21:13:17 --> Output Class Initialized
INFO - 2024-02-15 21:13:17 --> Security Class Initialized
DEBUG - 2024-02-15 21:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:13:17 --> Input Class Initialized
INFO - 2024-02-15 21:13:17 --> Language Class Initialized
INFO - 2024-02-15 21:13:17 --> Loader Class Initialized
INFO - 2024-02-15 21:13:17 --> Helper loaded: url_helper
INFO - 2024-02-15 21:13:17 --> Helper loaded: file_helper
INFO - 2024-02-15 21:13:17 --> Helper loaded: form_helper
INFO - 2024-02-15 21:13:17 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:13:17 --> Controller Class Initialized
INFO - 2024-02-15 21:13:17 --> Form Validation Class Initialized
INFO - 2024-02-15 21:13:17 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:13:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:13:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:13:17 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:13:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:13:42 --> Config Class Initialized
INFO - 2024-02-15 21:13:42 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:13:42 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:13:42 --> Utf8 Class Initialized
INFO - 2024-02-15 21:13:42 --> URI Class Initialized
INFO - 2024-02-15 21:13:42 --> Router Class Initialized
INFO - 2024-02-15 21:13:42 --> Output Class Initialized
INFO - 2024-02-15 21:13:42 --> Security Class Initialized
DEBUG - 2024-02-15 21:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:13:42 --> Input Class Initialized
INFO - 2024-02-15 21:13:42 --> Language Class Initialized
INFO - 2024-02-15 21:13:42 --> Loader Class Initialized
INFO - 2024-02-15 21:13:42 --> Helper loaded: url_helper
INFO - 2024-02-15 21:13:42 --> Helper loaded: file_helper
INFO - 2024-02-15 21:13:42 --> Helper loaded: form_helper
INFO - 2024-02-15 21:13:42 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:13:42 --> Controller Class Initialized
INFO - 2024-02-15 21:13:42 --> Form Validation Class Initialized
INFO - 2024-02-15 21:13:42 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:13:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:13:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:13:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:13:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:13:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:13:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:13:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:13:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:13:42 --> Final output sent to browser
DEBUG - 2024-02-15 21:13:42 --> Total execution time: 0.0466
ERROR - 2024-02-15 21:13:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:13:43 --> Config Class Initialized
INFO - 2024-02-15 21:13:43 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:13:43 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:13:43 --> Utf8 Class Initialized
INFO - 2024-02-15 21:13:43 --> URI Class Initialized
INFO - 2024-02-15 21:13:43 --> Router Class Initialized
INFO - 2024-02-15 21:13:43 --> Output Class Initialized
INFO - 2024-02-15 21:13:43 --> Security Class Initialized
DEBUG - 2024-02-15 21:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:13:43 --> Input Class Initialized
INFO - 2024-02-15 21:13:43 --> Language Class Initialized
INFO - 2024-02-15 21:13:43 --> Loader Class Initialized
INFO - 2024-02-15 21:13:43 --> Helper loaded: url_helper
INFO - 2024-02-15 21:13:43 --> Helper loaded: file_helper
INFO - 2024-02-15 21:13:43 --> Helper loaded: form_helper
INFO - 2024-02-15 21:13:43 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:13:43 --> Controller Class Initialized
INFO - 2024-02-15 21:13:43 --> Form Validation Class Initialized
INFO - 2024-02-15 21:13:43 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:13:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:13:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:13:43 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:13:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:13:45 --> Config Class Initialized
INFO - 2024-02-15 21:13:45 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:13:45 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:13:45 --> Utf8 Class Initialized
INFO - 2024-02-15 21:13:45 --> URI Class Initialized
INFO - 2024-02-15 21:13:45 --> Router Class Initialized
INFO - 2024-02-15 21:13:45 --> Output Class Initialized
INFO - 2024-02-15 21:13:45 --> Security Class Initialized
DEBUG - 2024-02-15 21:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:13:45 --> Input Class Initialized
INFO - 2024-02-15 21:13:45 --> Language Class Initialized
INFO - 2024-02-15 21:13:45 --> Loader Class Initialized
INFO - 2024-02-15 21:13:45 --> Helper loaded: url_helper
INFO - 2024-02-15 21:13:45 --> Helper loaded: file_helper
INFO - 2024-02-15 21:13:45 --> Helper loaded: form_helper
INFO - 2024-02-15 21:13:45 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:13:45 --> Controller Class Initialized
INFO - 2024-02-15 21:13:45 --> Form Validation Class Initialized
INFO - 2024-02-15 21:13:45 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:13:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:13:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:13:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:13:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:13:45 --> Final output sent to browser
DEBUG - 2024-02-15 21:13:45 --> Total execution time: 0.0456
ERROR - 2024-02-15 21:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:14:10 --> Config Class Initialized
INFO - 2024-02-15 21:14:10 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:14:10 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:14:10 --> Utf8 Class Initialized
INFO - 2024-02-15 21:14:10 --> URI Class Initialized
INFO - 2024-02-15 21:14:10 --> Router Class Initialized
INFO - 2024-02-15 21:14:10 --> Output Class Initialized
INFO - 2024-02-15 21:14:10 --> Security Class Initialized
DEBUG - 2024-02-15 21:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:14:10 --> Input Class Initialized
INFO - 2024-02-15 21:14:10 --> Language Class Initialized
INFO - 2024-02-15 21:14:11 --> Loader Class Initialized
INFO - 2024-02-15 21:14:11 --> Helper loaded: url_helper
INFO - 2024-02-15 21:14:11 --> Helper loaded: file_helper
INFO - 2024-02-15 21:14:11 --> Helper loaded: form_helper
INFO - 2024-02-15 21:14:11 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:14:11 --> Controller Class Initialized
INFO - 2024-02-15 21:14:11 --> Form Validation Class Initialized
INFO - 2024-02-15 21:14:11 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:14:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:14:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:14:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:14:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:14:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:14:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:14:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:14:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:14:11 --> Final output sent to browser
DEBUG - 2024-02-15 21:14:11 --> Total execution time: 0.0437
ERROR - 2024-02-15 21:14:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:14:11 --> Config Class Initialized
INFO - 2024-02-15 21:14:11 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:14:11 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:14:11 --> Utf8 Class Initialized
INFO - 2024-02-15 21:14:11 --> URI Class Initialized
INFO - 2024-02-15 21:14:11 --> Router Class Initialized
INFO - 2024-02-15 21:14:11 --> Output Class Initialized
INFO - 2024-02-15 21:14:11 --> Security Class Initialized
DEBUG - 2024-02-15 21:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:14:11 --> Input Class Initialized
INFO - 2024-02-15 21:14:11 --> Language Class Initialized
INFO - 2024-02-15 21:14:11 --> Loader Class Initialized
INFO - 2024-02-15 21:14:11 --> Helper loaded: url_helper
INFO - 2024-02-15 21:14:11 --> Helper loaded: file_helper
INFO - 2024-02-15 21:14:11 --> Helper loaded: form_helper
INFO - 2024-02-15 21:14:11 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:14:11 --> Controller Class Initialized
INFO - 2024-02-15 21:14:11 --> Form Validation Class Initialized
INFO - 2024-02-15 21:14:11 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:14:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:14:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:14:11 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:14:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:14:13 --> Config Class Initialized
INFO - 2024-02-15 21:14:13 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:14:13 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:14:13 --> Utf8 Class Initialized
INFO - 2024-02-15 21:14:13 --> URI Class Initialized
INFO - 2024-02-15 21:14:13 --> Router Class Initialized
INFO - 2024-02-15 21:14:13 --> Output Class Initialized
INFO - 2024-02-15 21:14:13 --> Security Class Initialized
DEBUG - 2024-02-15 21:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:14:13 --> Input Class Initialized
INFO - 2024-02-15 21:14:13 --> Language Class Initialized
INFO - 2024-02-15 21:14:13 --> Loader Class Initialized
INFO - 2024-02-15 21:14:13 --> Helper loaded: url_helper
INFO - 2024-02-15 21:14:13 --> Helper loaded: file_helper
INFO - 2024-02-15 21:14:13 --> Helper loaded: form_helper
INFO - 2024-02-15 21:14:13 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:14:13 --> Controller Class Initialized
INFO - 2024-02-15 21:14:13 --> Form Validation Class Initialized
INFO - 2024-02-15 21:14:13 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:14:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:14:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:14:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:14:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:14:13 --> Final output sent to browser
DEBUG - 2024-02-15 21:14:13 --> Total execution time: 0.0343
ERROR - 2024-02-15 21:15:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:15:35 --> Config Class Initialized
INFO - 2024-02-15 21:15:35 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:15:35 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:15:35 --> Utf8 Class Initialized
INFO - 2024-02-15 21:15:35 --> URI Class Initialized
INFO - 2024-02-15 21:15:35 --> Router Class Initialized
INFO - 2024-02-15 21:15:35 --> Output Class Initialized
INFO - 2024-02-15 21:15:35 --> Security Class Initialized
DEBUG - 2024-02-15 21:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:15:35 --> Input Class Initialized
INFO - 2024-02-15 21:15:35 --> Language Class Initialized
INFO - 2024-02-15 21:15:35 --> Loader Class Initialized
INFO - 2024-02-15 21:15:35 --> Helper loaded: url_helper
INFO - 2024-02-15 21:15:35 --> Helper loaded: file_helper
INFO - 2024-02-15 21:15:35 --> Helper loaded: form_helper
INFO - 2024-02-15 21:15:35 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:15:35 --> Controller Class Initialized
INFO - 2024-02-15 21:15:35 --> Form Validation Class Initialized
INFO - 2024-02-15 21:15:35 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:15:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:15:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:15:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:15:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:15:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:15:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:15:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:15:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:15:35 --> Final output sent to browser
DEBUG - 2024-02-15 21:15:35 --> Total execution time: 0.0516
ERROR - 2024-02-15 21:15:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:15:36 --> Config Class Initialized
INFO - 2024-02-15 21:15:36 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:15:36 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:15:36 --> Utf8 Class Initialized
INFO - 2024-02-15 21:15:36 --> URI Class Initialized
INFO - 2024-02-15 21:15:36 --> Router Class Initialized
INFO - 2024-02-15 21:15:36 --> Output Class Initialized
INFO - 2024-02-15 21:15:36 --> Security Class Initialized
DEBUG - 2024-02-15 21:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:15:36 --> Input Class Initialized
INFO - 2024-02-15 21:15:36 --> Language Class Initialized
INFO - 2024-02-15 21:15:36 --> Loader Class Initialized
INFO - 2024-02-15 21:15:36 --> Helper loaded: url_helper
INFO - 2024-02-15 21:15:36 --> Helper loaded: file_helper
INFO - 2024-02-15 21:15:36 --> Helper loaded: form_helper
INFO - 2024-02-15 21:15:36 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:15:36 --> Controller Class Initialized
INFO - 2024-02-15 21:15:36 --> Form Validation Class Initialized
INFO - 2024-02-15 21:15:36 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:15:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:15:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:15:36 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:15:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:15:38 --> Config Class Initialized
INFO - 2024-02-15 21:15:38 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:15:38 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:15:38 --> Utf8 Class Initialized
INFO - 2024-02-15 21:15:38 --> URI Class Initialized
INFO - 2024-02-15 21:15:38 --> Router Class Initialized
INFO - 2024-02-15 21:15:38 --> Output Class Initialized
INFO - 2024-02-15 21:15:38 --> Security Class Initialized
DEBUG - 2024-02-15 21:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:15:38 --> Input Class Initialized
INFO - 2024-02-15 21:15:38 --> Language Class Initialized
INFO - 2024-02-15 21:15:38 --> Loader Class Initialized
INFO - 2024-02-15 21:15:38 --> Helper loaded: url_helper
INFO - 2024-02-15 21:15:38 --> Helper loaded: file_helper
INFO - 2024-02-15 21:15:38 --> Helper loaded: form_helper
INFO - 2024-02-15 21:15:38 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:15:38 --> Controller Class Initialized
INFO - 2024-02-15 21:15:38 --> Form Validation Class Initialized
INFO - 2024-02-15 21:15:38 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:15:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:15:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:15:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:15:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:15:38 --> Final output sent to browser
DEBUG - 2024-02-15 21:15:38 --> Total execution time: 0.0486
ERROR - 2024-02-15 21:16:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:16:00 --> Config Class Initialized
INFO - 2024-02-15 21:16:00 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:16:00 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:16:00 --> Utf8 Class Initialized
INFO - 2024-02-15 21:16:00 --> URI Class Initialized
INFO - 2024-02-15 21:16:00 --> Router Class Initialized
INFO - 2024-02-15 21:16:00 --> Output Class Initialized
INFO - 2024-02-15 21:16:00 --> Security Class Initialized
DEBUG - 2024-02-15 21:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:16:00 --> Input Class Initialized
INFO - 2024-02-15 21:16:00 --> Language Class Initialized
INFO - 2024-02-15 21:16:00 --> Loader Class Initialized
INFO - 2024-02-15 21:16:00 --> Helper loaded: url_helper
INFO - 2024-02-15 21:16:00 --> Helper loaded: file_helper
INFO - 2024-02-15 21:16:00 --> Helper loaded: form_helper
INFO - 2024-02-15 21:16:00 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:16:00 --> Controller Class Initialized
INFO - 2024-02-15 21:16:00 --> Form Validation Class Initialized
INFO - 2024-02-15 21:16:00 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:16:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:16:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:16:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:16:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:16:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:16:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:16:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:16:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:16:00 --> Final output sent to browser
DEBUG - 2024-02-15 21:16:00 --> Total execution time: 0.0523
ERROR - 2024-02-15 21:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:16:01 --> Config Class Initialized
INFO - 2024-02-15 21:16:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:16:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:16:01 --> Utf8 Class Initialized
INFO - 2024-02-15 21:16:01 --> URI Class Initialized
INFO - 2024-02-15 21:16:01 --> Router Class Initialized
INFO - 2024-02-15 21:16:01 --> Output Class Initialized
INFO - 2024-02-15 21:16:01 --> Security Class Initialized
DEBUG - 2024-02-15 21:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:16:01 --> Input Class Initialized
INFO - 2024-02-15 21:16:01 --> Language Class Initialized
INFO - 2024-02-15 21:16:01 --> Loader Class Initialized
INFO - 2024-02-15 21:16:01 --> Helper loaded: url_helper
INFO - 2024-02-15 21:16:01 --> Helper loaded: file_helper
INFO - 2024-02-15 21:16:01 --> Helper loaded: form_helper
INFO - 2024-02-15 21:16:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:16:02 --> Controller Class Initialized
INFO - 2024-02-15 21:16:02 --> Form Validation Class Initialized
INFO - 2024-02-15 21:16:02 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:16:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:16:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:16:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:16:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:16:04 --> Config Class Initialized
INFO - 2024-02-15 21:16:04 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:16:04 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:16:04 --> Utf8 Class Initialized
INFO - 2024-02-15 21:16:04 --> URI Class Initialized
INFO - 2024-02-15 21:16:04 --> Router Class Initialized
INFO - 2024-02-15 21:16:04 --> Output Class Initialized
INFO - 2024-02-15 21:16:04 --> Security Class Initialized
DEBUG - 2024-02-15 21:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:16:04 --> Input Class Initialized
INFO - 2024-02-15 21:16:04 --> Language Class Initialized
INFO - 2024-02-15 21:16:04 --> Loader Class Initialized
INFO - 2024-02-15 21:16:04 --> Helper loaded: url_helper
INFO - 2024-02-15 21:16:04 --> Helper loaded: file_helper
INFO - 2024-02-15 21:16:04 --> Helper loaded: form_helper
INFO - 2024-02-15 21:16:04 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:16:04 --> Controller Class Initialized
INFO - 2024-02-15 21:16:04 --> Form Validation Class Initialized
INFO - 2024-02-15 21:16:04 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:16:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:16:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:16:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:16:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:16:04 --> Final output sent to browser
DEBUG - 2024-02-15 21:16:04 --> Total execution time: 0.0455
ERROR - 2024-02-15 21:16:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:16:35 --> Config Class Initialized
INFO - 2024-02-15 21:16:35 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:16:35 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:16:35 --> Utf8 Class Initialized
INFO - 2024-02-15 21:16:35 --> URI Class Initialized
INFO - 2024-02-15 21:16:35 --> Router Class Initialized
INFO - 2024-02-15 21:16:35 --> Output Class Initialized
INFO - 2024-02-15 21:16:35 --> Security Class Initialized
DEBUG - 2024-02-15 21:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:16:35 --> Input Class Initialized
INFO - 2024-02-15 21:16:35 --> Language Class Initialized
INFO - 2024-02-15 21:16:35 --> Loader Class Initialized
INFO - 2024-02-15 21:16:35 --> Helper loaded: url_helper
INFO - 2024-02-15 21:16:35 --> Helper loaded: file_helper
INFO - 2024-02-15 21:16:35 --> Helper loaded: form_helper
INFO - 2024-02-15 21:16:35 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:16:35 --> Controller Class Initialized
INFO - 2024-02-15 21:16:35 --> Form Validation Class Initialized
INFO - 2024-02-15 21:16:35 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:16:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:16:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:16:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:16:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:16:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:16:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:16:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:16:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:16:35 --> Final output sent to browser
DEBUG - 2024-02-15 21:16:35 --> Total execution time: 0.0452
ERROR - 2024-02-15 21:16:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:16:36 --> Config Class Initialized
INFO - 2024-02-15 21:16:36 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:16:36 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:16:36 --> Utf8 Class Initialized
INFO - 2024-02-15 21:16:36 --> URI Class Initialized
INFO - 2024-02-15 21:16:36 --> Router Class Initialized
INFO - 2024-02-15 21:16:36 --> Output Class Initialized
INFO - 2024-02-15 21:16:36 --> Security Class Initialized
DEBUG - 2024-02-15 21:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:16:36 --> Input Class Initialized
INFO - 2024-02-15 21:16:36 --> Language Class Initialized
INFO - 2024-02-15 21:16:36 --> Loader Class Initialized
INFO - 2024-02-15 21:16:36 --> Helper loaded: url_helper
INFO - 2024-02-15 21:16:36 --> Helper loaded: file_helper
INFO - 2024-02-15 21:16:36 --> Helper loaded: form_helper
INFO - 2024-02-15 21:16:36 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:16:36 --> Controller Class Initialized
INFO - 2024-02-15 21:16:36 --> Form Validation Class Initialized
INFO - 2024-02-15 21:16:36 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:16:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:16:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:16:36 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:16:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:16:38 --> Config Class Initialized
INFO - 2024-02-15 21:16:38 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:16:38 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:16:38 --> Utf8 Class Initialized
INFO - 2024-02-15 21:16:38 --> URI Class Initialized
INFO - 2024-02-15 21:16:38 --> Router Class Initialized
INFO - 2024-02-15 21:16:38 --> Output Class Initialized
INFO - 2024-02-15 21:16:38 --> Security Class Initialized
DEBUG - 2024-02-15 21:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:16:38 --> Input Class Initialized
INFO - 2024-02-15 21:16:38 --> Language Class Initialized
INFO - 2024-02-15 21:16:38 --> Loader Class Initialized
INFO - 2024-02-15 21:16:38 --> Helper loaded: url_helper
INFO - 2024-02-15 21:16:38 --> Helper loaded: file_helper
INFO - 2024-02-15 21:16:38 --> Helper loaded: form_helper
INFO - 2024-02-15 21:16:38 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:16:38 --> Controller Class Initialized
INFO - 2024-02-15 21:16:38 --> Form Validation Class Initialized
INFO - 2024-02-15 21:16:38 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:16:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:16:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:16:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:16:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:16:38 --> Final output sent to browser
DEBUG - 2024-02-15 21:16:38 --> Total execution time: 0.0459
ERROR - 2024-02-15 21:17:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:17:00 --> Config Class Initialized
INFO - 2024-02-15 21:17:00 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:17:00 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:17:00 --> Utf8 Class Initialized
INFO - 2024-02-15 21:17:00 --> URI Class Initialized
INFO - 2024-02-15 21:17:00 --> Router Class Initialized
INFO - 2024-02-15 21:17:00 --> Output Class Initialized
INFO - 2024-02-15 21:17:00 --> Security Class Initialized
DEBUG - 2024-02-15 21:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:17:00 --> Input Class Initialized
INFO - 2024-02-15 21:17:00 --> Language Class Initialized
INFO - 2024-02-15 21:17:00 --> Loader Class Initialized
INFO - 2024-02-15 21:17:00 --> Helper loaded: url_helper
INFO - 2024-02-15 21:17:00 --> Helper loaded: file_helper
INFO - 2024-02-15 21:17:00 --> Helper loaded: form_helper
INFO - 2024-02-15 21:17:00 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:17:00 --> Controller Class Initialized
INFO - 2024-02-15 21:17:00 --> Form Validation Class Initialized
INFO - 2024-02-15 21:17:00 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:17:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:17:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:17:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:17:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:17:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:17:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:17:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:17:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:17:00 --> Final output sent to browser
DEBUG - 2024-02-15 21:17:00 --> Total execution time: 0.0483
ERROR - 2024-02-15 21:17:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:17:00 --> Config Class Initialized
INFO - 2024-02-15 21:17:00 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:17:00 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:17:00 --> Utf8 Class Initialized
INFO - 2024-02-15 21:17:00 --> URI Class Initialized
INFO - 2024-02-15 21:17:00 --> Router Class Initialized
INFO - 2024-02-15 21:17:00 --> Output Class Initialized
INFO - 2024-02-15 21:17:00 --> Security Class Initialized
DEBUG - 2024-02-15 21:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:17:00 --> Input Class Initialized
INFO - 2024-02-15 21:17:00 --> Language Class Initialized
INFO - 2024-02-15 21:17:00 --> Loader Class Initialized
INFO - 2024-02-15 21:17:00 --> Helper loaded: url_helper
INFO - 2024-02-15 21:17:00 --> Helper loaded: file_helper
INFO - 2024-02-15 21:17:00 --> Helper loaded: form_helper
INFO - 2024-02-15 21:17:00 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:17:00 --> Controller Class Initialized
INFO - 2024-02-15 21:17:00 --> Form Validation Class Initialized
INFO - 2024-02-15 21:17:00 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:17:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:17:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:17:00 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:17:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:17:02 --> Config Class Initialized
INFO - 2024-02-15 21:17:02 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:17:02 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:17:02 --> Utf8 Class Initialized
INFO - 2024-02-15 21:17:02 --> URI Class Initialized
INFO - 2024-02-15 21:17:02 --> Router Class Initialized
INFO - 2024-02-15 21:17:02 --> Output Class Initialized
INFO - 2024-02-15 21:17:02 --> Security Class Initialized
DEBUG - 2024-02-15 21:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:17:02 --> Input Class Initialized
INFO - 2024-02-15 21:17:02 --> Language Class Initialized
INFO - 2024-02-15 21:17:02 --> Loader Class Initialized
INFO - 2024-02-15 21:17:02 --> Helper loaded: url_helper
INFO - 2024-02-15 21:17:02 --> Helper loaded: file_helper
INFO - 2024-02-15 21:17:02 --> Helper loaded: form_helper
INFO - 2024-02-15 21:17:02 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:17:02 --> Controller Class Initialized
INFO - 2024-02-15 21:17:02 --> Form Validation Class Initialized
INFO - 2024-02-15 21:17:02 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:17:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:17:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:17:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:17:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:17:02 --> Final output sent to browser
DEBUG - 2024-02-15 21:17:02 --> Total execution time: 0.0464
ERROR - 2024-02-15 21:17:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:17:38 --> Config Class Initialized
INFO - 2024-02-15 21:17:38 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:17:38 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:17:38 --> Utf8 Class Initialized
INFO - 2024-02-15 21:17:38 --> URI Class Initialized
INFO - 2024-02-15 21:17:38 --> Router Class Initialized
INFO - 2024-02-15 21:17:38 --> Output Class Initialized
INFO - 2024-02-15 21:17:38 --> Security Class Initialized
DEBUG - 2024-02-15 21:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:17:38 --> Input Class Initialized
INFO - 2024-02-15 21:17:38 --> Language Class Initialized
INFO - 2024-02-15 21:17:38 --> Loader Class Initialized
INFO - 2024-02-15 21:17:38 --> Helper loaded: url_helper
INFO - 2024-02-15 21:17:38 --> Helper loaded: file_helper
INFO - 2024-02-15 21:17:38 --> Helper loaded: form_helper
INFO - 2024-02-15 21:17:38 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:17:38 --> Controller Class Initialized
INFO - 2024-02-15 21:17:38 --> Form Validation Class Initialized
INFO - 2024-02-15 21:17:38 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:17:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:17:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:17:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:17:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:17:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:17:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:17:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:17:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:17:38 --> Final output sent to browser
DEBUG - 2024-02-15 21:17:38 --> Total execution time: 0.0478
ERROR - 2024-02-15 21:17:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:17:39 --> Config Class Initialized
INFO - 2024-02-15 21:17:39 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:17:39 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:17:39 --> Utf8 Class Initialized
INFO - 2024-02-15 21:17:39 --> URI Class Initialized
INFO - 2024-02-15 21:17:39 --> Router Class Initialized
INFO - 2024-02-15 21:17:39 --> Output Class Initialized
INFO - 2024-02-15 21:17:39 --> Security Class Initialized
DEBUG - 2024-02-15 21:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:17:39 --> Input Class Initialized
INFO - 2024-02-15 21:17:39 --> Language Class Initialized
INFO - 2024-02-15 21:17:39 --> Loader Class Initialized
INFO - 2024-02-15 21:17:39 --> Helper loaded: url_helper
INFO - 2024-02-15 21:17:39 --> Helper loaded: file_helper
INFO - 2024-02-15 21:17:39 --> Helper loaded: form_helper
INFO - 2024-02-15 21:17:39 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:17:39 --> Controller Class Initialized
INFO - 2024-02-15 21:17:39 --> Form Validation Class Initialized
INFO - 2024-02-15 21:17:39 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:17:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:17:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:17:39 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:17:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:17:41 --> Config Class Initialized
INFO - 2024-02-15 21:17:41 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:17:41 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:17:41 --> Utf8 Class Initialized
INFO - 2024-02-15 21:17:41 --> URI Class Initialized
INFO - 2024-02-15 21:17:41 --> Router Class Initialized
INFO - 2024-02-15 21:17:41 --> Output Class Initialized
INFO - 2024-02-15 21:17:41 --> Security Class Initialized
DEBUG - 2024-02-15 21:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:17:41 --> Input Class Initialized
INFO - 2024-02-15 21:17:41 --> Language Class Initialized
INFO - 2024-02-15 21:17:41 --> Loader Class Initialized
INFO - 2024-02-15 21:17:41 --> Helper loaded: url_helper
INFO - 2024-02-15 21:17:41 --> Helper loaded: file_helper
INFO - 2024-02-15 21:17:41 --> Helper loaded: form_helper
INFO - 2024-02-15 21:17:41 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:17:41 --> Controller Class Initialized
INFO - 2024-02-15 21:17:41 --> Form Validation Class Initialized
INFO - 2024-02-15 21:17:41 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:17:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:17:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:17:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:17:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:17:41 --> Final output sent to browser
DEBUG - 2024-02-15 21:17:41 --> Total execution time: 0.0488
ERROR - 2024-02-15 21:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:19:58 --> Config Class Initialized
INFO - 2024-02-15 21:19:58 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:19:58 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:19:58 --> Utf8 Class Initialized
INFO - 2024-02-15 21:19:58 --> URI Class Initialized
INFO - 2024-02-15 21:19:58 --> Router Class Initialized
INFO - 2024-02-15 21:19:58 --> Output Class Initialized
INFO - 2024-02-15 21:19:58 --> Security Class Initialized
DEBUG - 2024-02-15 21:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:19:58 --> Input Class Initialized
INFO - 2024-02-15 21:19:58 --> Language Class Initialized
INFO - 2024-02-15 21:19:58 --> Loader Class Initialized
INFO - 2024-02-15 21:19:58 --> Helper loaded: url_helper
INFO - 2024-02-15 21:19:58 --> Helper loaded: file_helper
INFO - 2024-02-15 21:19:58 --> Helper loaded: form_helper
INFO - 2024-02-15 21:19:58 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:19:58 --> Controller Class Initialized
INFO - 2024-02-15 21:19:58 --> Form Validation Class Initialized
INFO - 2024-02-15 21:19:58 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:19:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:19:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:19:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:19:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:19:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:19:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:19:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:19:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:19:58 --> Final output sent to browser
DEBUG - 2024-02-15 21:19:58 --> Total execution time: 0.0425
ERROR - 2024-02-15 21:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:19:58 --> Config Class Initialized
INFO - 2024-02-15 21:19:58 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:19:58 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:19:58 --> Utf8 Class Initialized
INFO - 2024-02-15 21:19:58 --> URI Class Initialized
INFO - 2024-02-15 21:19:58 --> Router Class Initialized
INFO - 2024-02-15 21:19:58 --> Output Class Initialized
INFO - 2024-02-15 21:19:58 --> Security Class Initialized
DEBUG - 2024-02-15 21:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:19:58 --> Input Class Initialized
INFO - 2024-02-15 21:19:58 --> Language Class Initialized
INFO - 2024-02-15 21:19:58 --> Loader Class Initialized
INFO - 2024-02-15 21:19:58 --> Helper loaded: url_helper
INFO - 2024-02-15 21:19:58 --> Helper loaded: file_helper
INFO - 2024-02-15 21:19:58 --> Helper loaded: form_helper
INFO - 2024-02-15 21:19:58 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:19:58 --> Controller Class Initialized
INFO - 2024-02-15 21:19:58 --> Form Validation Class Initialized
INFO - 2024-02-15 21:19:58 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:19:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:19:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:19:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:20:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:20:00 --> Config Class Initialized
INFO - 2024-02-15 21:20:00 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:20:00 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:20:00 --> Utf8 Class Initialized
INFO - 2024-02-15 21:20:00 --> URI Class Initialized
INFO - 2024-02-15 21:20:00 --> Router Class Initialized
INFO - 2024-02-15 21:20:00 --> Output Class Initialized
INFO - 2024-02-15 21:20:00 --> Security Class Initialized
DEBUG - 2024-02-15 21:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:20:00 --> Input Class Initialized
INFO - 2024-02-15 21:20:00 --> Language Class Initialized
INFO - 2024-02-15 21:20:00 --> Loader Class Initialized
INFO - 2024-02-15 21:20:00 --> Helper loaded: url_helper
INFO - 2024-02-15 21:20:00 --> Helper loaded: file_helper
INFO - 2024-02-15 21:20:00 --> Helper loaded: form_helper
INFO - 2024-02-15 21:20:00 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:20:00 --> Controller Class Initialized
INFO - 2024-02-15 21:20:00 --> Form Validation Class Initialized
INFO - 2024-02-15 21:20:00 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:20:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:20:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:20:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:20:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:20:00 --> Final output sent to browser
DEBUG - 2024-02-15 21:20:00 --> Total execution time: 0.0441
ERROR - 2024-02-15 21:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:21:08 --> Config Class Initialized
INFO - 2024-02-15 21:21:08 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:21:08 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:21:08 --> Utf8 Class Initialized
INFO - 2024-02-15 21:21:08 --> URI Class Initialized
INFO - 2024-02-15 21:21:08 --> Router Class Initialized
INFO - 2024-02-15 21:21:08 --> Output Class Initialized
INFO - 2024-02-15 21:21:08 --> Security Class Initialized
DEBUG - 2024-02-15 21:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:21:08 --> Input Class Initialized
INFO - 2024-02-15 21:21:08 --> Language Class Initialized
INFO - 2024-02-15 21:21:08 --> Loader Class Initialized
INFO - 2024-02-15 21:21:08 --> Helper loaded: url_helper
INFO - 2024-02-15 21:21:08 --> Helper loaded: file_helper
INFO - 2024-02-15 21:21:08 --> Helper loaded: form_helper
INFO - 2024-02-15 21:21:08 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:21:08 --> Controller Class Initialized
INFO - 2024-02-15 21:21:09 --> Form Validation Class Initialized
INFO - 2024-02-15 21:21:09 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:21:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:21:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:21:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:21:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:21:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:21:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:21:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:21:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:21:09 --> Final output sent to browser
DEBUG - 2024-02-15 21:21:09 --> Total execution time: 0.0464
ERROR - 2024-02-15 21:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:21:09 --> Config Class Initialized
INFO - 2024-02-15 21:21:09 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:21:09 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:21:09 --> Utf8 Class Initialized
INFO - 2024-02-15 21:21:09 --> URI Class Initialized
INFO - 2024-02-15 21:21:09 --> Router Class Initialized
INFO - 2024-02-15 21:21:09 --> Output Class Initialized
INFO - 2024-02-15 21:21:09 --> Security Class Initialized
DEBUG - 2024-02-15 21:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:21:09 --> Input Class Initialized
INFO - 2024-02-15 21:21:09 --> Language Class Initialized
INFO - 2024-02-15 21:21:09 --> Loader Class Initialized
INFO - 2024-02-15 21:21:09 --> Helper loaded: url_helper
INFO - 2024-02-15 21:21:09 --> Helper loaded: file_helper
INFO - 2024-02-15 21:21:09 --> Helper loaded: form_helper
INFO - 2024-02-15 21:21:09 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:21:09 --> Controller Class Initialized
INFO - 2024-02-15 21:21:09 --> Form Validation Class Initialized
INFO - 2024-02-15 21:21:09 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:21:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:21:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:21:09 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:21:11 --> Config Class Initialized
INFO - 2024-02-15 21:21:11 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:21:11 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:21:11 --> Utf8 Class Initialized
INFO - 2024-02-15 21:21:11 --> URI Class Initialized
INFO - 2024-02-15 21:21:11 --> Router Class Initialized
INFO - 2024-02-15 21:21:11 --> Output Class Initialized
INFO - 2024-02-15 21:21:11 --> Security Class Initialized
DEBUG - 2024-02-15 21:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:21:11 --> Input Class Initialized
INFO - 2024-02-15 21:21:11 --> Language Class Initialized
INFO - 2024-02-15 21:21:11 --> Loader Class Initialized
INFO - 2024-02-15 21:21:11 --> Helper loaded: url_helper
INFO - 2024-02-15 21:21:11 --> Helper loaded: file_helper
INFO - 2024-02-15 21:21:11 --> Helper loaded: form_helper
INFO - 2024-02-15 21:21:11 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:21:11 --> Controller Class Initialized
INFO - 2024-02-15 21:21:11 --> Form Validation Class Initialized
INFO - 2024-02-15 21:21:11 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:21:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:21:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:21:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:21:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:21:11 --> Final output sent to browser
DEBUG - 2024-02-15 21:21:11 --> Total execution time: 0.0431
ERROR - 2024-02-15 21:22:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:22:40 --> Config Class Initialized
INFO - 2024-02-15 21:22:40 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:22:40 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:22:40 --> Utf8 Class Initialized
INFO - 2024-02-15 21:22:40 --> URI Class Initialized
INFO - 2024-02-15 21:22:40 --> Router Class Initialized
INFO - 2024-02-15 21:22:40 --> Output Class Initialized
INFO - 2024-02-15 21:22:40 --> Security Class Initialized
DEBUG - 2024-02-15 21:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:22:40 --> Input Class Initialized
INFO - 2024-02-15 21:22:40 --> Language Class Initialized
INFO - 2024-02-15 21:22:40 --> Loader Class Initialized
INFO - 2024-02-15 21:22:40 --> Helper loaded: url_helper
INFO - 2024-02-15 21:22:40 --> Helper loaded: file_helper
INFO - 2024-02-15 21:22:40 --> Helper loaded: form_helper
INFO - 2024-02-15 21:22:40 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:22:40 --> Controller Class Initialized
INFO - 2024-02-15 21:22:40 --> Form Validation Class Initialized
INFO - 2024-02-15 21:22:40 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:22:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:22:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:22:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:22:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:22:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:22:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:22:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:22:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:22:40 --> Final output sent to browser
DEBUG - 2024-02-15 21:22:40 --> Total execution time: 0.0491
ERROR - 2024-02-15 21:22:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:22:41 --> Config Class Initialized
INFO - 2024-02-15 21:22:41 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:22:41 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:22:41 --> Utf8 Class Initialized
INFO - 2024-02-15 21:22:41 --> URI Class Initialized
INFO - 2024-02-15 21:22:41 --> Router Class Initialized
INFO - 2024-02-15 21:22:41 --> Output Class Initialized
INFO - 2024-02-15 21:22:41 --> Security Class Initialized
DEBUG - 2024-02-15 21:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:22:41 --> Input Class Initialized
INFO - 2024-02-15 21:22:41 --> Language Class Initialized
INFO - 2024-02-15 21:22:41 --> Loader Class Initialized
INFO - 2024-02-15 21:22:41 --> Helper loaded: url_helper
INFO - 2024-02-15 21:22:41 --> Helper loaded: file_helper
INFO - 2024-02-15 21:22:41 --> Helper loaded: form_helper
INFO - 2024-02-15 21:22:41 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:22:41 --> Controller Class Initialized
INFO - 2024-02-15 21:22:41 --> Form Validation Class Initialized
INFO - 2024-02-15 21:22:41 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:22:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:22:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:22:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:22:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:22:43 --> Config Class Initialized
INFO - 2024-02-15 21:22:43 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:22:43 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:22:43 --> Utf8 Class Initialized
INFO - 2024-02-15 21:22:43 --> URI Class Initialized
INFO - 2024-02-15 21:22:43 --> Router Class Initialized
INFO - 2024-02-15 21:22:43 --> Output Class Initialized
INFO - 2024-02-15 21:22:43 --> Security Class Initialized
DEBUG - 2024-02-15 21:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:22:43 --> Input Class Initialized
INFO - 2024-02-15 21:22:43 --> Language Class Initialized
INFO - 2024-02-15 21:22:43 --> Loader Class Initialized
INFO - 2024-02-15 21:22:43 --> Helper loaded: url_helper
INFO - 2024-02-15 21:22:43 --> Helper loaded: file_helper
INFO - 2024-02-15 21:22:43 --> Helper loaded: form_helper
INFO - 2024-02-15 21:22:43 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:22:43 --> Controller Class Initialized
INFO - 2024-02-15 21:22:43 --> Form Validation Class Initialized
INFO - 2024-02-15 21:22:43 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:22:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:22:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:22:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:22:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:22:43 --> Final output sent to browser
DEBUG - 2024-02-15 21:22:43 --> Total execution time: 0.0409
ERROR - 2024-02-15 21:23:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:23:46 --> Config Class Initialized
INFO - 2024-02-15 21:23:46 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:23:46 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:23:46 --> Utf8 Class Initialized
INFO - 2024-02-15 21:23:46 --> URI Class Initialized
INFO - 2024-02-15 21:23:46 --> Router Class Initialized
INFO - 2024-02-15 21:23:46 --> Output Class Initialized
INFO - 2024-02-15 21:23:46 --> Security Class Initialized
DEBUG - 2024-02-15 21:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:23:46 --> Input Class Initialized
INFO - 2024-02-15 21:23:46 --> Language Class Initialized
INFO - 2024-02-15 21:23:46 --> Loader Class Initialized
INFO - 2024-02-15 21:23:46 --> Helper loaded: url_helper
INFO - 2024-02-15 21:23:46 --> Helper loaded: file_helper
INFO - 2024-02-15 21:23:46 --> Helper loaded: form_helper
INFO - 2024-02-15 21:23:46 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:23:46 --> Controller Class Initialized
INFO - 2024-02-15 21:23:46 --> Form Validation Class Initialized
INFO - 2024-02-15 21:23:46 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:23:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:23:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:23:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:23:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:23:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:23:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:23:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:23:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:23:46 --> Final output sent to browser
DEBUG - 2024-02-15 21:23:46 --> Total execution time: 0.0527
ERROR - 2024-02-15 21:23:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:23:46 --> Config Class Initialized
INFO - 2024-02-15 21:23:46 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:23:46 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:23:46 --> Utf8 Class Initialized
INFO - 2024-02-15 21:23:46 --> URI Class Initialized
INFO - 2024-02-15 21:23:46 --> Router Class Initialized
INFO - 2024-02-15 21:23:46 --> Output Class Initialized
INFO - 2024-02-15 21:23:46 --> Security Class Initialized
DEBUG - 2024-02-15 21:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:23:46 --> Input Class Initialized
INFO - 2024-02-15 21:23:46 --> Language Class Initialized
INFO - 2024-02-15 21:23:46 --> Loader Class Initialized
INFO - 2024-02-15 21:23:46 --> Helper loaded: url_helper
INFO - 2024-02-15 21:23:46 --> Helper loaded: file_helper
INFO - 2024-02-15 21:23:46 --> Helper loaded: form_helper
INFO - 2024-02-15 21:23:46 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:23:46 --> Controller Class Initialized
INFO - 2024-02-15 21:23:46 --> Form Validation Class Initialized
INFO - 2024-02-15 21:23:46 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:23:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:23:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:23:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:23:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:23:48 --> Config Class Initialized
INFO - 2024-02-15 21:23:48 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:23:48 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:23:48 --> Utf8 Class Initialized
INFO - 2024-02-15 21:23:48 --> URI Class Initialized
INFO - 2024-02-15 21:23:48 --> Router Class Initialized
INFO - 2024-02-15 21:23:48 --> Output Class Initialized
INFO - 2024-02-15 21:23:48 --> Security Class Initialized
DEBUG - 2024-02-15 21:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:23:48 --> Input Class Initialized
INFO - 2024-02-15 21:23:48 --> Language Class Initialized
INFO - 2024-02-15 21:23:48 --> Loader Class Initialized
INFO - 2024-02-15 21:23:48 --> Helper loaded: url_helper
INFO - 2024-02-15 21:23:48 --> Helper loaded: file_helper
INFO - 2024-02-15 21:23:48 --> Helper loaded: form_helper
INFO - 2024-02-15 21:23:48 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:23:48 --> Controller Class Initialized
INFO - 2024-02-15 21:23:48 --> Form Validation Class Initialized
INFO - 2024-02-15 21:23:48 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:23:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:23:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:23:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:23:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:23:48 --> Final output sent to browser
DEBUG - 2024-02-15 21:23:48 --> Total execution time: 0.0458
ERROR - 2024-02-15 21:24:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:24:39 --> Config Class Initialized
INFO - 2024-02-15 21:24:39 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:24:39 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:24:39 --> Utf8 Class Initialized
INFO - 2024-02-15 21:24:39 --> URI Class Initialized
INFO - 2024-02-15 21:24:39 --> Router Class Initialized
INFO - 2024-02-15 21:24:39 --> Output Class Initialized
INFO - 2024-02-15 21:24:39 --> Security Class Initialized
DEBUG - 2024-02-15 21:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:24:39 --> Input Class Initialized
INFO - 2024-02-15 21:24:39 --> Language Class Initialized
INFO - 2024-02-15 21:24:39 --> Loader Class Initialized
INFO - 2024-02-15 21:24:39 --> Helper loaded: url_helper
INFO - 2024-02-15 21:24:39 --> Helper loaded: file_helper
INFO - 2024-02-15 21:24:39 --> Helper loaded: form_helper
INFO - 2024-02-15 21:24:39 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:24:39 --> Controller Class Initialized
INFO - 2024-02-15 21:24:39 --> Form Validation Class Initialized
INFO - 2024-02-15 21:24:39 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:24:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:24:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:24:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:24:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 21:24:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 21:24:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 21:24:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 21:24:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 21:24:39 --> Final output sent to browser
DEBUG - 2024-02-15 21:24:39 --> Total execution time: 0.0457
ERROR - 2024-02-15 21:24:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:24:40 --> Config Class Initialized
INFO - 2024-02-15 21:24:40 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:24:40 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:24:40 --> Utf8 Class Initialized
INFO - 2024-02-15 21:24:40 --> URI Class Initialized
INFO - 2024-02-15 21:24:40 --> Router Class Initialized
INFO - 2024-02-15 21:24:40 --> Output Class Initialized
INFO - 2024-02-15 21:24:40 --> Security Class Initialized
DEBUG - 2024-02-15 21:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:24:40 --> Input Class Initialized
INFO - 2024-02-15 21:24:40 --> Language Class Initialized
INFO - 2024-02-15 21:24:40 --> Loader Class Initialized
INFO - 2024-02-15 21:24:40 --> Helper loaded: url_helper
INFO - 2024-02-15 21:24:40 --> Helper loaded: file_helper
INFO - 2024-02-15 21:24:40 --> Helper loaded: form_helper
INFO - 2024-02-15 21:24:40 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:24:40 --> Controller Class Initialized
INFO - 2024-02-15 21:24:40 --> Form Validation Class Initialized
INFO - 2024-02-15 21:24:40 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:24:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:24:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:24:40 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 21:24:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 21:24:42 --> Config Class Initialized
INFO - 2024-02-15 21:24:42 --> Hooks Class Initialized
DEBUG - 2024-02-15 21:24:42 --> UTF-8 Support Enabled
INFO - 2024-02-15 21:24:42 --> Utf8 Class Initialized
INFO - 2024-02-15 21:24:42 --> URI Class Initialized
INFO - 2024-02-15 21:24:42 --> Router Class Initialized
INFO - 2024-02-15 21:24:42 --> Output Class Initialized
INFO - 2024-02-15 21:24:42 --> Security Class Initialized
DEBUG - 2024-02-15 21:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 21:24:42 --> Input Class Initialized
INFO - 2024-02-15 21:24:42 --> Language Class Initialized
INFO - 2024-02-15 21:24:42 --> Loader Class Initialized
INFO - 2024-02-15 21:24:42 --> Helper loaded: url_helper
INFO - 2024-02-15 21:24:42 --> Helper loaded: file_helper
INFO - 2024-02-15 21:24:42 --> Helper loaded: form_helper
INFO - 2024-02-15 21:24:42 --> Database Driver Class Initialized
DEBUG - 2024-02-15 21:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 21:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 21:24:42 --> Controller Class Initialized
INFO - 2024-02-15 21:24:42 --> Form Validation Class Initialized
INFO - 2024-02-15 21:24:42 --> Model "MasterModel" initialized
INFO - 2024-02-15 21:24:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 21:24:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 21:24:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 21:24:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 21:24:42 --> Final output sent to browser
DEBUG - 2024-02-15 21:24:42 --> Total execution time: 0.0466
ERROR - 2024-02-15 23:11:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:11:44 --> Config Class Initialized
INFO - 2024-02-15 23:11:44 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:11:44 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:11:44 --> Utf8 Class Initialized
INFO - 2024-02-15 23:11:44 --> URI Class Initialized
INFO - 2024-02-15 23:11:44 --> Router Class Initialized
INFO - 2024-02-15 23:11:44 --> Output Class Initialized
INFO - 2024-02-15 23:11:44 --> Security Class Initialized
DEBUG - 2024-02-15 23:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:11:44 --> Input Class Initialized
INFO - 2024-02-15 23:11:44 --> Language Class Initialized
INFO - 2024-02-15 23:11:44 --> Loader Class Initialized
INFO - 2024-02-15 23:11:44 --> Helper loaded: url_helper
INFO - 2024-02-15 23:11:44 --> Helper loaded: file_helper
INFO - 2024-02-15 23:11:44 --> Helper loaded: form_helper
INFO - 2024-02-15 23:11:44 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:11:44 --> Controller Class Initialized
INFO - 2024-02-15 23:11:44 --> Form Validation Class Initialized
INFO - 2024-02-15 23:11:44 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:11:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:11:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:11:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:11:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:11:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:11:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:11:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:11:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:11:44 --> Final output sent to browser
DEBUG - 2024-02-15 23:11:44 --> Total execution time: 0.0177
ERROR - 2024-02-15 23:11:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:11:44 --> Config Class Initialized
INFO - 2024-02-15 23:11:44 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:11:44 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:11:44 --> Utf8 Class Initialized
INFO - 2024-02-15 23:11:44 --> URI Class Initialized
INFO - 2024-02-15 23:11:44 --> Router Class Initialized
INFO - 2024-02-15 23:11:44 --> Output Class Initialized
INFO - 2024-02-15 23:11:44 --> Security Class Initialized
DEBUG - 2024-02-15 23:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:11:44 --> Input Class Initialized
INFO - 2024-02-15 23:11:44 --> Language Class Initialized
INFO - 2024-02-15 23:11:44 --> Loader Class Initialized
INFO - 2024-02-15 23:11:44 --> Helper loaded: url_helper
INFO - 2024-02-15 23:11:44 --> Helper loaded: file_helper
INFO - 2024-02-15 23:11:44 --> Helper loaded: form_helper
INFO - 2024-02-15 23:11:44 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:11:44 --> Controller Class Initialized
INFO - 2024-02-15 23:11:44 --> Form Validation Class Initialized
INFO - 2024-02-15 23:11:44 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:11:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:11:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:11:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:11:47 --> Config Class Initialized
INFO - 2024-02-15 23:11:47 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:11:47 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:11:47 --> Utf8 Class Initialized
INFO - 2024-02-15 23:11:47 --> URI Class Initialized
INFO - 2024-02-15 23:11:47 --> Router Class Initialized
INFO - 2024-02-15 23:11:47 --> Output Class Initialized
INFO - 2024-02-15 23:11:47 --> Security Class Initialized
DEBUG - 2024-02-15 23:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:11:47 --> Input Class Initialized
INFO - 2024-02-15 23:11:47 --> Language Class Initialized
INFO - 2024-02-15 23:11:47 --> Loader Class Initialized
INFO - 2024-02-15 23:11:47 --> Helper loaded: url_helper
INFO - 2024-02-15 23:11:47 --> Helper loaded: file_helper
INFO - 2024-02-15 23:11:47 --> Helper loaded: form_helper
INFO - 2024-02-15 23:11:47 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:11:47 --> Controller Class Initialized
INFO - 2024-02-15 23:11:47 --> Form Validation Class Initialized
INFO - 2024-02-15 23:11:47 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:11:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:11:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:11:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:11:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:11:47 --> Final output sent to browser
DEBUG - 2024-02-15 23:11:47 --> Total execution time: 0.0163
ERROR - 2024-02-15 23:12:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:12:16 --> Config Class Initialized
INFO - 2024-02-15 23:12:16 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:12:16 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:12:16 --> Utf8 Class Initialized
INFO - 2024-02-15 23:12:16 --> URI Class Initialized
INFO - 2024-02-15 23:12:16 --> Router Class Initialized
INFO - 2024-02-15 23:12:16 --> Output Class Initialized
INFO - 2024-02-15 23:12:16 --> Security Class Initialized
DEBUG - 2024-02-15 23:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:12:16 --> Input Class Initialized
INFO - 2024-02-15 23:12:16 --> Language Class Initialized
INFO - 2024-02-15 23:12:16 --> Loader Class Initialized
INFO - 2024-02-15 23:12:16 --> Helper loaded: url_helper
INFO - 2024-02-15 23:12:16 --> Helper loaded: file_helper
INFO - 2024-02-15 23:12:16 --> Helper loaded: form_helper
INFO - 2024-02-15 23:12:16 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:12:16 --> Controller Class Initialized
INFO - 2024-02-15 23:12:16 --> Form Validation Class Initialized
INFO - 2024-02-15 23:12:16 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:12:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:12:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:12:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:12:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:12:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:12:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:12:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:12:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:12:16 --> Final output sent to browser
DEBUG - 2024-02-15 23:12:16 --> Total execution time: 0.0196
ERROR - 2024-02-15 23:12:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:12:16 --> Config Class Initialized
INFO - 2024-02-15 23:12:16 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:12:16 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:12:16 --> Utf8 Class Initialized
INFO - 2024-02-15 23:12:16 --> URI Class Initialized
INFO - 2024-02-15 23:12:16 --> Router Class Initialized
INFO - 2024-02-15 23:12:16 --> Output Class Initialized
INFO - 2024-02-15 23:12:16 --> Security Class Initialized
DEBUG - 2024-02-15 23:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:12:16 --> Input Class Initialized
INFO - 2024-02-15 23:12:16 --> Language Class Initialized
INFO - 2024-02-15 23:12:16 --> Loader Class Initialized
INFO - 2024-02-15 23:12:16 --> Helper loaded: url_helper
INFO - 2024-02-15 23:12:16 --> Helper loaded: file_helper
INFO - 2024-02-15 23:12:16 --> Helper loaded: form_helper
INFO - 2024-02-15 23:12:16 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:12:16 --> Controller Class Initialized
INFO - 2024-02-15 23:12:16 --> Form Validation Class Initialized
INFO - 2024-02-15 23:12:16 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:12:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:12:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:12:16 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:12:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:12:19 --> Config Class Initialized
INFO - 2024-02-15 23:12:19 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:12:19 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:12:19 --> Utf8 Class Initialized
INFO - 2024-02-15 23:12:19 --> URI Class Initialized
INFO - 2024-02-15 23:12:19 --> Router Class Initialized
INFO - 2024-02-15 23:12:19 --> Output Class Initialized
INFO - 2024-02-15 23:12:19 --> Security Class Initialized
DEBUG - 2024-02-15 23:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:12:19 --> Input Class Initialized
INFO - 2024-02-15 23:12:19 --> Language Class Initialized
INFO - 2024-02-15 23:12:19 --> Loader Class Initialized
INFO - 2024-02-15 23:12:19 --> Helper loaded: url_helper
INFO - 2024-02-15 23:12:19 --> Helper loaded: file_helper
INFO - 2024-02-15 23:12:19 --> Helper loaded: form_helper
INFO - 2024-02-15 23:12:19 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:12:19 --> Controller Class Initialized
INFO - 2024-02-15 23:12:19 --> Form Validation Class Initialized
INFO - 2024-02-15 23:12:19 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:12:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:12:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:12:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:12:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:12:19 --> Final output sent to browser
DEBUG - 2024-02-15 23:12:19 --> Total execution time: 0.0165
ERROR - 2024-02-15 23:16:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:16:41 --> Config Class Initialized
INFO - 2024-02-15 23:16:41 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:16:41 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:16:41 --> Utf8 Class Initialized
INFO - 2024-02-15 23:16:41 --> URI Class Initialized
INFO - 2024-02-15 23:16:41 --> Router Class Initialized
INFO - 2024-02-15 23:16:41 --> Output Class Initialized
INFO - 2024-02-15 23:16:41 --> Security Class Initialized
DEBUG - 2024-02-15 23:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:16:41 --> Input Class Initialized
INFO - 2024-02-15 23:16:41 --> Language Class Initialized
INFO - 2024-02-15 23:16:41 --> Loader Class Initialized
INFO - 2024-02-15 23:16:41 --> Helper loaded: url_helper
INFO - 2024-02-15 23:16:41 --> Helper loaded: file_helper
INFO - 2024-02-15 23:16:41 --> Helper loaded: form_helper
INFO - 2024-02-15 23:16:41 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:16:41 --> Controller Class Initialized
INFO - 2024-02-15 23:16:41 --> Form Validation Class Initialized
INFO - 2024-02-15 23:16:41 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:16:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:16:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:16:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:16:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:16:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:16:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:16:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:16:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:16:41 --> Final output sent to browser
DEBUG - 2024-02-15 23:16:41 --> Total execution time: 0.0177
ERROR - 2024-02-15 23:16:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:16:41 --> Config Class Initialized
INFO - 2024-02-15 23:16:41 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:16:41 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:16:41 --> Utf8 Class Initialized
INFO - 2024-02-15 23:16:41 --> URI Class Initialized
INFO - 2024-02-15 23:16:41 --> Router Class Initialized
INFO - 2024-02-15 23:16:41 --> Output Class Initialized
INFO - 2024-02-15 23:16:41 --> Security Class Initialized
DEBUG - 2024-02-15 23:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:16:41 --> Input Class Initialized
INFO - 2024-02-15 23:16:41 --> Language Class Initialized
INFO - 2024-02-15 23:16:41 --> Loader Class Initialized
INFO - 2024-02-15 23:16:41 --> Helper loaded: url_helper
INFO - 2024-02-15 23:16:41 --> Helper loaded: file_helper
INFO - 2024-02-15 23:16:41 --> Helper loaded: form_helper
INFO - 2024-02-15 23:16:41 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:16:41 --> Controller Class Initialized
INFO - 2024-02-15 23:16:41 --> Form Validation Class Initialized
INFO - 2024-02-15 23:16:41 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:16:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:16:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:16:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:16:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:16:43 --> Config Class Initialized
INFO - 2024-02-15 23:16:43 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:16:43 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:16:43 --> Utf8 Class Initialized
INFO - 2024-02-15 23:16:43 --> URI Class Initialized
INFO - 2024-02-15 23:16:43 --> Router Class Initialized
INFO - 2024-02-15 23:16:43 --> Output Class Initialized
INFO - 2024-02-15 23:16:43 --> Security Class Initialized
DEBUG - 2024-02-15 23:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:16:43 --> Input Class Initialized
INFO - 2024-02-15 23:16:43 --> Language Class Initialized
INFO - 2024-02-15 23:16:43 --> Loader Class Initialized
INFO - 2024-02-15 23:16:43 --> Helper loaded: url_helper
INFO - 2024-02-15 23:16:43 --> Helper loaded: file_helper
INFO - 2024-02-15 23:16:43 --> Helper loaded: form_helper
INFO - 2024-02-15 23:16:43 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:16:43 --> Controller Class Initialized
INFO - 2024-02-15 23:16:43 --> Form Validation Class Initialized
INFO - 2024-02-15 23:16:43 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:16:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:16:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:16:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:16:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:16:44 --> Final output sent to browser
DEBUG - 2024-02-15 23:16:44 --> Total execution time: 0.0166
ERROR - 2024-02-15 23:17:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:17:27 --> Config Class Initialized
INFO - 2024-02-15 23:17:27 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:17:27 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:17:27 --> Utf8 Class Initialized
INFO - 2024-02-15 23:17:27 --> URI Class Initialized
INFO - 2024-02-15 23:17:27 --> Router Class Initialized
INFO - 2024-02-15 23:17:27 --> Output Class Initialized
INFO - 2024-02-15 23:17:27 --> Security Class Initialized
DEBUG - 2024-02-15 23:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:17:27 --> Input Class Initialized
INFO - 2024-02-15 23:17:27 --> Language Class Initialized
INFO - 2024-02-15 23:17:27 --> Loader Class Initialized
INFO - 2024-02-15 23:17:27 --> Helper loaded: url_helper
INFO - 2024-02-15 23:17:27 --> Helper loaded: file_helper
INFO - 2024-02-15 23:17:27 --> Helper loaded: form_helper
INFO - 2024-02-15 23:17:27 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:17:27 --> Controller Class Initialized
INFO - 2024-02-15 23:17:27 --> Form Validation Class Initialized
INFO - 2024-02-15 23:17:27 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:17:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:17:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:17:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:17:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:17:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:17:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:17:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:17:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:17:27 --> Final output sent to browser
DEBUG - 2024-02-15 23:17:27 --> Total execution time: 0.0162
ERROR - 2024-02-15 23:17:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:17:27 --> Config Class Initialized
INFO - 2024-02-15 23:17:27 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:17:27 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:17:27 --> Utf8 Class Initialized
INFO - 2024-02-15 23:17:27 --> URI Class Initialized
INFO - 2024-02-15 23:17:27 --> Router Class Initialized
INFO - 2024-02-15 23:17:27 --> Output Class Initialized
INFO - 2024-02-15 23:17:27 --> Security Class Initialized
DEBUG - 2024-02-15 23:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:17:27 --> Input Class Initialized
INFO - 2024-02-15 23:17:27 --> Language Class Initialized
INFO - 2024-02-15 23:17:27 --> Loader Class Initialized
INFO - 2024-02-15 23:17:27 --> Helper loaded: url_helper
INFO - 2024-02-15 23:17:27 --> Helper loaded: file_helper
INFO - 2024-02-15 23:17:27 --> Helper loaded: form_helper
INFO - 2024-02-15 23:17:27 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:17:27 --> Controller Class Initialized
INFO - 2024-02-15 23:17:27 --> Form Validation Class Initialized
INFO - 2024-02-15 23:17:27 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:17:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:17:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:17:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:17:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:17:31 --> Config Class Initialized
INFO - 2024-02-15 23:17:31 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:17:31 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:17:31 --> Utf8 Class Initialized
INFO - 2024-02-15 23:17:31 --> URI Class Initialized
INFO - 2024-02-15 23:17:31 --> Router Class Initialized
INFO - 2024-02-15 23:17:31 --> Output Class Initialized
INFO - 2024-02-15 23:17:31 --> Security Class Initialized
DEBUG - 2024-02-15 23:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:17:31 --> Input Class Initialized
INFO - 2024-02-15 23:17:31 --> Language Class Initialized
INFO - 2024-02-15 23:17:31 --> Loader Class Initialized
INFO - 2024-02-15 23:17:31 --> Helper loaded: url_helper
INFO - 2024-02-15 23:17:31 --> Helper loaded: file_helper
INFO - 2024-02-15 23:17:31 --> Helper loaded: form_helper
INFO - 2024-02-15 23:17:31 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:17:31 --> Controller Class Initialized
INFO - 2024-02-15 23:17:31 --> Form Validation Class Initialized
INFO - 2024-02-15 23:17:31 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:17:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:17:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:17:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:17:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:17:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:17:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:17:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:17:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:17:31 --> Final output sent to browser
DEBUG - 2024-02-15 23:17:31 --> Total execution time: 0.0146
ERROR - 2024-02-15 23:17:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:17:31 --> Config Class Initialized
INFO - 2024-02-15 23:17:31 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:17:31 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:17:31 --> Utf8 Class Initialized
INFO - 2024-02-15 23:17:31 --> URI Class Initialized
INFO - 2024-02-15 23:17:31 --> Router Class Initialized
INFO - 2024-02-15 23:17:31 --> Output Class Initialized
INFO - 2024-02-15 23:17:31 --> Security Class Initialized
DEBUG - 2024-02-15 23:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:17:31 --> Input Class Initialized
INFO - 2024-02-15 23:17:31 --> Language Class Initialized
INFO - 2024-02-15 23:17:31 --> Loader Class Initialized
INFO - 2024-02-15 23:17:31 --> Helper loaded: url_helper
INFO - 2024-02-15 23:17:31 --> Helper loaded: file_helper
INFO - 2024-02-15 23:17:31 --> Helper loaded: form_helper
INFO - 2024-02-15 23:17:31 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:17:31 --> Controller Class Initialized
INFO - 2024-02-15 23:17:31 --> Form Validation Class Initialized
INFO - 2024-02-15 23:17:31 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:17:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:17:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:17:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:17:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:17:38 --> Config Class Initialized
INFO - 2024-02-15 23:17:38 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:17:38 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:17:38 --> Utf8 Class Initialized
INFO - 2024-02-15 23:17:38 --> URI Class Initialized
INFO - 2024-02-15 23:17:38 --> Router Class Initialized
INFO - 2024-02-15 23:17:38 --> Output Class Initialized
INFO - 2024-02-15 23:17:38 --> Security Class Initialized
DEBUG - 2024-02-15 23:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:17:38 --> Input Class Initialized
INFO - 2024-02-15 23:17:38 --> Language Class Initialized
INFO - 2024-02-15 23:17:38 --> Loader Class Initialized
INFO - 2024-02-15 23:17:38 --> Helper loaded: url_helper
INFO - 2024-02-15 23:17:38 --> Helper loaded: file_helper
INFO - 2024-02-15 23:17:38 --> Helper loaded: form_helper
INFO - 2024-02-15 23:17:38 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:17:38 --> Controller Class Initialized
INFO - 2024-02-15 23:17:38 --> Form Validation Class Initialized
INFO - 2024-02-15 23:17:38 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:17:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:17:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:17:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:17:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:17:38 --> Final output sent to browser
DEBUG - 2024-02-15 23:17:38 --> Total execution time: 0.0162
ERROR - 2024-02-15 23:19:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:19:15 --> Config Class Initialized
INFO - 2024-02-15 23:19:15 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:19:15 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:19:15 --> Utf8 Class Initialized
INFO - 2024-02-15 23:19:15 --> URI Class Initialized
INFO - 2024-02-15 23:19:15 --> Router Class Initialized
INFO - 2024-02-15 23:19:15 --> Output Class Initialized
INFO - 2024-02-15 23:19:15 --> Security Class Initialized
DEBUG - 2024-02-15 23:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:19:15 --> Input Class Initialized
INFO - 2024-02-15 23:19:15 --> Language Class Initialized
INFO - 2024-02-15 23:19:15 --> Loader Class Initialized
INFO - 2024-02-15 23:19:15 --> Helper loaded: url_helper
INFO - 2024-02-15 23:19:15 --> Helper loaded: file_helper
INFO - 2024-02-15 23:19:15 --> Helper loaded: form_helper
INFO - 2024-02-15 23:19:15 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:19:15 --> Controller Class Initialized
INFO - 2024-02-15 23:19:15 --> Form Validation Class Initialized
INFO - 2024-02-15 23:19:15 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:19:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:19:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:19:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:19:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:19:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:19:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:19:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:19:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:19:15 --> Final output sent to browser
DEBUG - 2024-02-15 23:19:15 --> Total execution time: 0.0152
ERROR - 2024-02-15 23:19:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:19:16 --> Config Class Initialized
INFO - 2024-02-15 23:19:16 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:19:16 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:19:16 --> Utf8 Class Initialized
INFO - 2024-02-15 23:19:16 --> URI Class Initialized
INFO - 2024-02-15 23:19:16 --> Router Class Initialized
INFO - 2024-02-15 23:19:16 --> Output Class Initialized
INFO - 2024-02-15 23:19:16 --> Security Class Initialized
DEBUG - 2024-02-15 23:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:19:16 --> Input Class Initialized
INFO - 2024-02-15 23:19:16 --> Language Class Initialized
INFO - 2024-02-15 23:19:16 --> Loader Class Initialized
INFO - 2024-02-15 23:19:16 --> Helper loaded: url_helper
INFO - 2024-02-15 23:19:16 --> Helper loaded: file_helper
INFO - 2024-02-15 23:19:16 --> Helper loaded: form_helper
INFO - 2024-02-15 23:19:16 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:19:16 --> Controller Class Initialized
INFO - 2024-02-15 23:19:16 --> Form Validation Class Initialized
INFO - 2024-02-15 23:19:16 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:19:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:19:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:19:16 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:19:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:19:18 --> Config Class Initialized
INFO - 2024-02-15 23:19:18 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:19:18 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:19:18 --> Utf8 Class Initialized
INFO - 2024-02-15 23:19:18 --> URI Class Initialized
INFO - 2024-02-15 23:19:18 --> Router Class Initialized
INFO - 2024-02-15 23:19:18 --> Output Class Initialized
INFO - 2024-02-15 23:19:18 --> Security Class Initialized
DEBUG - 2024-02-15 23:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:19:18 --> Input Class Initialized
INFO - 2024-02-15 23:19:18 --> Language Class Initialized
INFO - 2024-02-15 23:19:18 --> Loader Class Initialized
INFO - 2024-02-15 23:19:18 --> Helper loaded: url_helper
INFO - 2024-02-15 23:19:18 --> Helper loaded: file_helper
INFO - 2024-02-15 23:19:18 --> Helper loaded: form_helper
INFO - 2024-02-15 23:19:18 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:19:18 --> Controller Class Initialized
INFO - 2024-02-15 23:19:18 --> Form Validation Class Initialized
INFO - 2024-02-15 23:19:18 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:19:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:19:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:19:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:19:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:19:18 --> Final output sent to browser
DEBUG - 2024-02-15 23:19:18 --> Total execution time: 0.0151
ERROR - 2024-02-15 23:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:22:01 --> Config Class Initialized
INFO - 2024-02-15 23:22:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:22:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:22:01 --> Utf8 Class Initialized
INFO - 2024-02-15 23:22:01 --> URI Class Initialized
INFO - 2024-02-15 23:22:01 --> Router Class Initialized
INFO - 2024-02-15 23:22:01 --> Output Class Initialized
INFO - 2024-02-15 23:22:01 --> Security Class Initialized
DEBUG - 2024-02-15 23:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:22:01 --> Input Class Initialized
INFO - 2024-02-15 23:22:01 --> Language Class Initialized
INFO - 2024-02-15 23:22:01 --> Loader Class Initialized
INFO - 2024-02-15 23:22:01 --> Helper loaded: url_helper
INFO - 2024-02-15 23:22:01 --> Helper loaded: file_helper
INFO - 2024-02-15 23:22:01 --> Helper loaded: form_helper
INFO - 2024-02-15 23:22:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:22:01 --> Controller Class Initialized
INFO - 2024-02-15 23:22:01 --> Form Validation Class Initialized
INFO - 2024-02-15 23:22:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:22:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:22:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:22:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:22:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:22:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:22:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:22:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:22:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:22:01 --> Final output sent to browser
DEBUG - 2024-02-15 23:22:01 --> Total execution time: 0.0135
ERROR - 2024-02-15 23:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:22:01 --> Config Class Initialized
INFO - 2024-02-15 23:22:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:22:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:22:01 --> Utf8 Class Initialized
INFO - 2024-02-15 23:22:01 --> URI Class Initialized
INFO - 2024-02-15 23:22:01 --> Router Class Initialized
INFO - 2024-02-15 23:22:01 --> Output Class Initialized
INFO - 2024-02-15 23:22:01 --> Security Class Initialized
DEBUG - 2024-02-15 23:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:22:01 --> Input Class Initialized
INFO - 2024-02-15 23:22:01 --> Language Class Initialized
INFO - 2024-02-15 23:22:01 --> Loader Class Initialized
INFO - 2024-02-15 23:22:01 --> Helper loaded: url_helper
INFO - 2024-02-15 23:22:01 --> Helper loaded: file_helper
INFO - 2024-02-15 23:22:01 --> Helper loaded: form_helper
INFO - 2024-02-15 23:22:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:22:01 --> Controller Class Initialized
INFO - 2024-02-15 23:22:01 --> Form Validation Class Initialized
INFO - 2024-02-15 23:22:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:22:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:22:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:22:01 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:22:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:22:05 --> Config Class Initialized
INFO - 2024-02-15 23:22:05 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:22:05 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:22:05 --> Utf8 Class Initialized
INFO - 2024-02-15 23:22:05 --> URI Class Initialized
INFO - 2024-02-15 23:22:05 --> Router Class Initialized
INFO - 2024-02-15 23:22:05 --> Output Class Initialized
INFO - 2024-02-15 23:22:05 --> Security Class Initialized
DEBUG - 2024-02-15 23:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:22:05 --> Input Class Initialized
INFO - 2024-02-15 23:22:05 --> Language Class Initialized
INFO - 2024-02-15 23:22:05 --> Loader Class Initialized
INFO - 2024-02-15 23:22:05 --> Helper loaded: url_helper
INFO - 2024-02-15 23:22:05 --> Helper loaded: file_helper
INFO - 2024-02-15 23:22:05 --> Helper loaded: form_helper
INFO - 2024-02-15 23:22:05 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:22:05 --> Controller Class Initialized
INFO - 2024-02-15 23:22:05 --> Form Validation Class Initialized
INFO - 2024-02-15 23:22:05 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:22:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:22:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:22:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:22:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:22:05 --> Final output sent to browser
DEBUG - 2024-02-15 23:22:05 --> Total execution time: 0.0148
ERROR - 2024-02-15 23:22:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:22:57 --> Config Class Initialized
INFO - 2024-02-15 23:22:57 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:22:57 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:22:57 --> Utf8 Class Initialized
INFO - 2024-02-15 23:22:57 --> URI Class Initialized
INFO - 2024-02-15 23:22:57 --> Router Class Initialized
INFO - 2024-02-15 23:22:57 --> Output Class Initialized
INFO - 2024-02-15 23:22:57 --> Security Class Initialized
DEBUG - 2024-02-15 23:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:22:57 --> Input Class Initialized
INFO - 2024-02-15 23:22:57 --> Language Class Initialized
INFO - 2024-02-15 23:22:57 --> Loader Class Initialized
INFO - 2024-02-15 23:22:57 --> Helper loaded: url_helper
INFO - 2024-02-15 23:22:57 --> Helper loaded: file_helper
INFO - 2024-02-15 23:22:57 --> Helper loaded: form_helper
INFO - 2024-02-15 23:22:57 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:22:57 --> Controller Class Initialized
INFO - 2024-02-15 23:22:57 --> Form Validation Class Initialized
INFO - 2024-02-15 23:22:57 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:22:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:22:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:22:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:22:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:22:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:22:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:22:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:22:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:22:57 --> Final output sent to browser
DEBUG - 2024-02-15 23:22:57 --> Total execution time: 0.0163
ERROR - 2024-02-15 23:22:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:22:58 --> Config Class Initialized
INFO - 2024-02-15 23:22:58 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:22:58 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:22:58 --> Utf8 Class Initialized
INFO - 2024-02-15 23:22:58 --> URI Class Initialized
INFO - 2024-02-15 23:22:58 --> Router Class Initialized
INFO - 2024-02-15 23:22:58 --> Output Class Initialized
INFO - 2024-02-15 23:22:58 --> Security Class Initialized
DEBUG - 2024-02-15 23:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:22:58 --> Input Class Initialized
INFO - 2024-02-15 23:22:58 --> Language Class Initialized
INFO - 2024-02-15 23:22:58 --> Loader Class Initialized
INFO - 2024-02-15 23:22:58 --> Helper loaded: url_helper
INFO - 2024-02-15 23:22:58 --> Helper loaded: file_helper
INFO - 2024-02-15 23:22:58 --> Helper loaded: form_helper
INFO - 2024-02-15 23:22:58 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:22:58 --> Controller Class Initialized
INFO - 2024-02-15 23:22:58 --> Form Validation Class Initialized
INFO - 2024-02-15 23:22:58 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:22:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:22:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:22:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:23:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:23:01 --> Config Class Initialized
INFO - 2024-02-15 23:23:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:23:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:23:01 --> Utf8 Class Initialized
INFO - 2024-02-15 23:23:01 --> URI Class Initialized
INFO - 2024-02-15 23:23:01 --> Router Class Initialized
INFO - 2024-02-15 23:23:01 --> Output Class Initialized
INFO - 2024-02-15 23:23:01 --> Security Class Initialized
DEBUG - 2024-02-15 23:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:23:01 --> Input Class Initialized
INFO - 2024-02-15 23:23:01 --> Language Class Initialized
INFO - 2024-02-15 23:23:01 --> Loader Class Initialized
INFO - 2024-02-15 23:23:01 --> Helper loaded: url_helper
INFO - 2024-02-15 23:23:01 --> Helper loaded: file_helper
INFO - 2024-02-15 23:23:01 --> Helper loaded: form_helper
INFO - 2024-02-15 23:23:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:23:01 --> Controller Class Initialized
INFO - 2024-02-15 23:23:01 --> Form Validation Class Initialized
INFO - 2024-02-15 23:23:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:23:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:23:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:23:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:23:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:23:01 --> Final output sent to browser
DEBUG - 2024-02-15 23:23:01 --> Total execution time: 0.0171
ERROR - 2024-02-15 23:23:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:23:04 --> Config Class Initialized
INFO - 2024-02-15 23:23:04 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:23:04 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:23:04 --> Utf8 Class Initialized
INFO - 2024-02-15 23:23:04 --> URI Class Initialized
INFO - 2024-02-15 23:23:04 --> Router Class Initialized
INFO - 2024-02-15 23:23:04 --> Output Class Initialized
INFO - 2024-02-15 23:23:04 --> Security Class Initialized
DEBUG - 2024-02-15 23:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:23:04 --> Input Class Initialized
INFO - 2024-02-15 23:23:04 --> Language Class Initialized
INFO - 2024-02-15 23:23:04 --> Loader Class Initialized
INFO - 2024-02-15 23:23:04 --> Helper loaded: url_helper
INFO - 2024-02-15 23:23:04 --> Helper loaded: file_helper
INFO - 2024-02-15 23:23:04 --> Helper loaded: form_helper
INFO - 2024-02-15 23:23:04 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:23:04 --> Controller Class Initialized
INFO - 2024-02-15 23:23:04 --> Form Validation Class Initialized
INFO - 2024-02-15 23:23:04 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:23:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:23:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:23:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:23:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:23:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:23:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:23:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:23:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:23:04 --> Final output sent to browser
DEBUG - 2024-02-15 23:23:04 --> Total execution time: 0.0156
ERROR - 2024-02-15 23:23:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:23:05 --> Config Class Initialized
INFO - 2024-02-15 23:23:05 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:23:05 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:23:05 --> Utf8 Class Initialized
INFO - 2024-02-15 23:23:05 --> URI Class Initialized
INFO - 2024-02-15 23:23:05 --> Router Class Initialized
INFO - 2024-02-15 23:23:05 --> Output Class Initialized
INFO - 2024-02-15 23:23:05 --> Security Class Initialized
DEBUG - 2024-02-15 23:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:23:05 --> Input Class Initialized
INFO - 2024-02-15 23:23:05 --> Language Class Initialized
INFO - 2024-02-15 23:23:05 --> Loader Class Initialized
INFO - 2024-02-15 23:23:05 --> Helper loaded: url_helper
INFO - 2024-02-15 23:23:05 --> Helper loaded: file_helper
INFO - 2024-02-15 23:23:05 --> Helper loaded: form_helper
INFO - 2024-02-15 23:23:05 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:23:05 --> Controller Class Initialized
INFO - 2024-02-15 23:23:05 --> Form Validation Class Initialized
INFO - 2024-02-15 23:23:05 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:23:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:23:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:23:05 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:23:07 --> Config Class Initialized
INFO - 2024-02-15 23:23:07 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:23:07 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:23:07 --> Utf8 Class Initialized
INFO - 2024-02-15 23:23:07 --> URI Class Initialized
INFO - 2024-02-15 23:23:07 --> Router Class Initialized
INFO - 2024-02-15 23:23:07 --> Output Class Initialized
INFO - 2024-02-15 23:23:07 --> Security Class Initialized
DEBUG - 2024-02-15 23:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:23:07 --> Input Class Initialized
INFO - 2024-02-15 23:23:07 --> Language Class Initialized
INFO - 2024-02-15 23:23:07 --> Loader Class Initialized
INFO - 2024-02-15 23:23:07 --> Helper loaded: url_helper
INFO - 2024-02-15 23:23:07 --> Helper loaded: file_helper
INFO - 2024-02-15 23:23:07 --> Helper loaded: form_helper
INFO - 2024-02-15 23:23:07 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:23:07 --> Controller Class Initialized
INFO - 2024-02-15 23:23:07 --> Form Validation Class Initialized
INFO - 2024-02-15 23:23:07 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:23:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:23:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:23:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:23:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:23:07 --> Final output sent to browser
DEBUG - 2024-02-15 23:23:07 --> Total execution time: 0.0150
ERROR - 2024-02-15 23:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:24:14 --> Config Class Initialized
INFO - 2024-02-15 23:24:14 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:24:14 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:24:14 --> Utf8 Class Initialized
INFO - 2024-02-15 23:24:14 --> URI Class Initialized
INFO - 2024-02-15 23:24:14 --> Router Class Initialized
INFO - 2024-02-15 23:24:14 --> Output Class Initialized
INFO - 2024-02-15 23:24:14 --> Security Class Initialized
DEBUG - 2024-02-15 23:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:24:14 --> Input Class Initialized
INFO - 2024-02-15 23:24:14 --> Language Class Initialized
INFO - 2024-02-15 23:24:14 --> Loader Class Initialized
INFO - 2024-02-15 23:24:14 --> Helper loaded: url_helper
INFO - 2024-02-15 23:24:14 --> Helper loaded: file_helper
INFO - 2024-02-15 23:24:14 --> Helper loaded: form_helper
INFO - 2024-02-15 23:24:14 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:24:14 --> Controller Class Initialized
INFO - 2024-02-15 23:24:14 --> Form Validation Class Initialized
INFO - 2024-02-15 23:24:14 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:24:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:24:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:24:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:24:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:24:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:24:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:24:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:24:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:24:14 --> Final output sent to browser
DEBUG - 2024-02-15 23:24:14 --> Total execution time: 0.0173
ERROR - 2024-02-15 23:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:24:14 --> Config Class Initialized
INFO - 2024-02-15 23:24:14 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:24:14 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:24:14 --> Utf8 Class Initialized
INFO - 2024-02-15 23:24:14 --> URI Class Initialized
INFO - 2024-02-15 23:24:14 --> Router Class Initialized
INFO - 2024-02-15 23:24:14 --> Output Class Initialized
INFO - 2024-02-15 23:24:14 --> Security Class Initialized
DEBUG - 2024-02-15 23:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:24:14 --> Input Class Initialized
INFO - 2024-02-15 23:24:14 --> Language Class Initialized
INFO - 2024-02-15 23:24:14 --> Loader Class Initialized
INFO - 2024-02-15 23:24:14 --> Helper loaded: url_helper
INFO - 2024-02-15 23:24:14 --> Helper loaded: file_helper
INFO - 2024-02-15 23:24:14 --> Helper loaded: form_helper
INFO - 2024-02-15 23:24:14 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:24:14 --> Controller Class Initialized
INFO - 2024-02-15 23:24:14 --> Form Validation Class Initialized
INFO - 2024-02-15 23:24:14 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:24:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:24:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:24:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:24:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:24:18 --> Config Class Initialized
INFO - 2024-02-15 23:24:18 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:24:18 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:24:18 --> Utf8 Class Initialized
INFO - 2024-02-15 23:24:18 --> URI Class Initialized
INFO - 2024-02-15 23:24:18 --> Router Class Initialized
INFO - 2024-02-15 23:24:18 --> Output Class Initialized
INFO - 2024-02-15 23:24:18 --> Security Class Initialized
DEBUG - 2024-02-15 23:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:24:18 --> Input Class Initialized
INFO - 2024-02-15 23:24:18 --> Language Class Initialized
INFO - 2024-02-15 23:24:18 --> Loader Class Initialized
INFO - 2024-02-15 23:24:18 --> Helper loaded: url_helper
INFO - 2024-02-15 23:24:18 --> Helper loaded: file_helper
INFO - 2024-02-15 23:24:18 --> Helper loaded: form_helper
INFO - 2024-02-15 23:24:18 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:24:18 --> Controller Class Initialized
INFO - 2024-02-15 23:24:18 --> Form Validation Class Initialized
INFO - 2024-02-15 23:24:18 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:24:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:24:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:24:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:24:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:24:18 --> Final output sent to browser
DEBUG - 2024-02-15 23:24:18 --> Total execution time: 0.0145
ERROR - 2024-02-15 23:25:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:25:31 --> Config Class Initialized
INFO - 2024-02-15 23:25:31 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:25:31 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:25:31 --> Utf8 Class Initialized
INFO - 2024-02-15 23:25:31 --> URI Class Initialized
INFO - 2024-02-15 23:25:31 --> Router Class Initialized
INFO - 2024-02-15 23:25:31 --> Output Class Initialized
INFO - 2024-02-15 23:25:31 --> Security Class Initialized
DEBUG - 2024-02-15 23:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:25:31 --> Input Class Initialized
INFO - 2024-02-15 23:25:31 --> Language Class Initialized
INFO - 2024-02-15 23:25:31 --> Loader Class Initialized
INFO - 2024-02-15 23:25:31 --> Helper loaded: url_helper
INFO - 2024-02-15 23:25:31 --> Helper loaded: file_helper
INFO - 2024-02-15 23:25:31 --> Helper loaded: form_helper
INFO - 2024-02-15 23:25:31 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:25:31 --> Controller Class Initialized
INFO - 2024-02-15 23:25:31 --> Form Validation Class Initialized
INFO - 2024-02-15 23:25:31 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:25:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:25:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:25:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:25:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:25:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:25:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:25:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:25:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:25:31 --> Final output sent to browser
DEBUG - 2024-02-15 23:25:31 --> Total execution time: 0.0145
ERROR - 2024-02-15 23:25:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:25:32 --> Config Class Initialized
INFO - 2024-02-15 23:25:32 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:25:32 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:25:32 --> Utf8 Class Initialized
INFO - 2024-02-15 23:25:32 --> URI Class Initialized
INFO - 2024-02-15 23:25:32 --> Router Class Initialized
INFO - 2024-02-15 23:25:32 --> Output Class Initialized
INFO - 2024-02-15 23:25:32 --> Security Class Initialized
DEBUG - 2024-02-15 23:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:25:32 --> Input Class Initialized
INFO - 2024-02-15 23:25:32 --> Language Class Initialized
INFO - 2024-02-15 23:25:32 --> Loader Class Initialized
INFO - 2024-02-15 23:25:32 --> Helper loaded: url_helper
INFO - 2024-02-15 23:25:32 --> Helper loaded: file_helper
INFO - 2024-02-15 23:25:32 --> Helper loaded: form_helper
INFO - 2024-02-15 23:25:32 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:25:32 --> Controller Class Initialized
INFO - 2024-02-15 23:25:32 --> Form Validation Class Initialized
INFO - 2024-02-15 23:25:32 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:25:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:25:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:25:32 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:25:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:25:34 --> Config Class Initialized
INFO - 2024-02-15 23:25:34 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:25:34 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:25:34 --> Utf8 Class Initialized
INFO - 2024-02-15 23:25:34 --> URI Class Initialized
INFO - 2024-02-15 23:25:34 --> Router Class Initialized
INFO - 2024-02-15 23:25:34 --> Output Class Initialized
INFO - 2024-02-15 23:25:34 --> Security Class Initialized
DEBUG - 2024-02-15 23:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:25:34 --> Input Class Initialized
INFO - 2024-02-15 23:25:34 --> Language Class Initialized
INFO - 2024-02-15 23:25:34 --> Loader Class Initialized
INFO - 2024-02-15 23:25:34 --> Helper loaded: url_helper
INFO - 2024-02-15 23:25:34 --> Helper loaded: file_helper
INFO - 2024-02-15 23:25:34 --> Helper loaded: form_helper
INFO - 2024-02-15 23:25:34 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:25:34 --> Controller Class Initialized
INFO - 2024-02-15 23:25:34 --> Form Validation Class Initialized
INFO - 2024-02-15 23:25:34 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:25:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:25:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:25:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:25:34 --> Final output sent to browser
DEBUG - 2024-02-15 23:25:34 --> Total execution time: 0.0145
ERROR - 2024-02-15 23:26:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:26:30 --> Config Class Initialized
INFO - 2024-02-15 23:26:30 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:26:30 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:26:30 --> Utf8 Class Initialized
INFO - 2024-02-15 23:26:30 --> URI Class Initialized
INFO - 2024-02-15 23:26:30 --> Router Class Initialized
INFO - 2024-02-15 23:26:30 --> Output Class Initialized
INFO - 2024-02-15 23:26:30 --> Security Class Initialized
DEBUG - 2024-02-15 23:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:26:30 --> Input Class Initialized
INFO - 2024-02-15 23:26:30 --> Language Class Initialized
INFO - 2024-02-15 23:26:30 --> Loader Class Initialized
INFO - 2024-02-15 23:26:30 --> Helper loaded: url_helper
INFO - 2024-02-15 23:26:30 --> Helper loaded: file_helper
INFO - 2024-02-15 23:26:30 --> Helper loaded: form_helper
INFO - 2024-02-15 23:26:30 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:26:30 --> Controller Class Initialized
INFO - 2024-02-15 23:26:30 --> Form Validation Class Initialized
INFO - 2024-02-15 23:26:30 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:26:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:26:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:26:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:26:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:26:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:26:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:26:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:26:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:26:30 --> Final output sent to browser
DEBUG - 2024-02-15 23:26:30 --> Total execution time: 0.0155
ERROR - 2024-02-15 23:26:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:26:31 --> Config Class Initialized
INFO - 2024-02-15 23:26:31 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:26:31 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:26:31 --> Utf8 Class Initialized
INFO - 2024-02-15 23:26:31 --> URI Class Initialized
INFO - 2024-02-15 23:26:31 --> Router Class Initialized
INFO - 2024-02-15 23:26:31 --> Output Class Initialized
INFO - 2024-02-15 23:26:31 --> Security Class Initialized
DEBUG - 2024-02-15 23:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:26:31 --> Input Class Initialized
INFO - 2024-02-15 23:26:31 --> Language Class Initialized
INFO - 2024-02-15 23:26:31 --> Loader Class Initialized
INFO - 2024-02-15 23:26:31 --> Helper loaded: url_helper
INFO - 2024-02-15 23:26:31 --> Helper loaded: file_helper
INFO - 2024-02-15 23:26:31 --> Helper loaded: form_helper
INFO - 2024-02-15 23:26:31 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:26:31 --> Controller Class Initialized
INFO - 2024-02-15 23:26:31 --> Form Validation Class Initialized
INFO - 2024-02-15 23:26:31 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:26:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:26:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:26:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:26:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:26:35 --> Config Class Initialized
INFO - 2024-02-15 23:26:35 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:26:35 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:26:35 --> Utf8 Class Initialized
INFO - 2024-02-15 23:26:35 --> URI Class Initialized
INFO - 2024-02-15 23:26:35 --> Router Class Initialized
INFO - 2024-02-15 23:26:35 --> Output Class Initialized
INFO - 2024-02-15 23:26:35 --> Security Class Initialized
DEBUG - 2024-02-15 23:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:26:35 --> Input Class Initialized
INFO - 2024-02-15 23:26:35 --> Language Class Initialized
INFO - 2024-02-15 23:26:35 --> Loader Class Initialized
INFO - 2024-02-15 23:26:35 --> Helper loaded: url_helper
INFO - 2024-02-15 23:26:35 --> Helper loaded: file_helper
INFO - 2024-02-15 23:26:35 --> Helper loaded: form_helper
INFO - 2024-02-15 23:26:35 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:26:35 --> Controller Class Initialized
INFO - 2024-02-15 23:26:35 --> Form Validation Class Initialized
INFO - 2024-02-15 23:26:35 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:26:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:26:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:26:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:26:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:26:35 --> Final output sent to browser
DEBUG - 2024-02-15 23:26:35 --> Total execution time: 0.0145
ERROR - 2024-02-15 23:29:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:29:02 --> Config Class Initialized
INFO - 2024-02-15 23:29:02 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:29:02 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:29:02 --> Utf8 Class Initialized
INFO - 2024-02-15 23:29:02 --> URI Class Initialized
INFO - 2024-02-15 23:29:02 --> Router Class Initialized
INFO - 2024-02-15 23:29:02 --> Output Class Initialized
INFO - 2024-02-15 23:29:02 --> Security Class Initialized
DEBUG - 2024-02-15 23:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:29:02 --> Input Class Initialized
INFO - 2024-02-15 23:29:02 --> Language Class Initialized
INFO - 2024-02-15 23:29:02 --> Loader Class Initialized
INFO - 2024-02-15 23:29:02 --> Helper loaded: url_helper
INFO - 2024-02-15 23:29:02 --> Helper loaded: file_helper
INFO - 2024-02-15 23:29:02 --> Helper loaded: form_helper
INFO - 2024-02-15 23:29:02 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:29:02 --> Controller Class Initialized
INFO - 2024-02-15 23:29:02 --> Form Validation Class Initialized
INFO - 2024-02-15 23:29:02 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:29:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:29:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:29:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:29:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:29:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:29:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:29:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:29:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:29:02 --> Final output sent to browser
DEBUG - 2024-02-15 23:29:02 --> Total execution time: 0.0165
ERROR - 2024-02-15 23:29:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:29:02 --> Config Class Initialized
INFO - 2024-02-15 23:29:02 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:29:02 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:29:02 --> Utf8 Class Initialized
INFO - 2024-02-15 23:29:02 --> URI Class Initialized
INFO - 2024-02-15 23:29:02 --> Router Class Initialized
INFO - 2024-02-15 23:29:02 --> Output Class Initialized
INFO - 2024-02-15 23:29:02 --> Security Class Initialized
DEBUG - 2024-02-15 23:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:29:02 --> Input Class Initialized
INFO - 2024-02-15 23:29:02 --> Language Class Initialized
INFO - 2024-02-15 23:29:02 --> Loader Class Initialized
INFO - 2024-02-15 23:29:02 --> Helper loaded: url_helper
INFO - 2024-02-15 23:29:02 --> Helper loaded: file_helper
INFO - 2024-02-15 23:29:02 --> Helper loaded: form_helper
INFO - 2024-02-15 23:29:02 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:29:02 --> Controller Class Initialized
INFO - 2024-02-15 23:29:02 --> Form Validation Class Initialized
INFO - 2024-02-15 23:29:02 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:29:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:29:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:29:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:29:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:29:05 --> Config Class Initialized
INFO - 2024-02-15 23:29:05 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:29:05 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:29:05 --> Utf8 Class Initialized
INFO - 2024-02-15 23:29:05 --> URI Class Initialized
INFO - 2024-02-15 23:29:05 --> Router Class Initialized
INFO - 2024-02-15 23:29:05 --> Output Class Initialized
INFO - 2024-02-15 23:29:05 --> Security Class Initialized
DEBUG - 2024-02-15 23:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:29:05 --> Input Class Initialized
INFO - 2024-02-15 23:29:05 --> Language Class Initialized
INFO - 2024-02-15 23:29:05 --> Loader Class Initialized
INFO - 2024-02-15 23:29:05 --> Helper loaded: url_helper
INFO - 2024-02-15 23:29:05 --> Helper loaded: file_helper
INFO - 2024-02-15 23:29:05 --> Helper loaded: form_helper
INFO - 2024-02-15 23:29:05 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:29:05 --> Controller Class Initialized
INFO - 2024-02-15 23:29:05 --> Form Validation Class Initialized
INFO - 2024-02-15 23:29:05 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:29:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:29:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:29:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:29:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:29:05 --> Final output sent to browser
DEBUG - 2024-02-15 23:29:05 --> Total execution time: 0.0173
ERROR - 2024-02-15 23:29:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:29:21 --> Config Class Initialized
INFO - 2024-02-15 23:29:21 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:29:21 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:29:21 --> Utf8 Class Initialized
INFO - 2024-02-15 23:29:21 --> URI Class Initialized
INFO - 2024-02-15 23:29:21 --> Router Class Initialized
INFO - 2024-02-15 23:29:21 --> Output Class Initialized
INFO - 2024-02-15 23:29:21 --> Security Class Initialized
DEBUG - 2024-02-15 23:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:29:21 --> Input Class Initialized
INFO - 2024-02-15 23:29:21 --> Language Class Initialized
INFO - 2024-02-15 23:29:21 --> Loader Class Initialized
INFO - 2024-02-15 23:29:21 --> Helper loaded: url_helper
INFO - 2024-02-15 23:29:21 --> Helper loaded: file_helper
INFO - 2024-02-15 23:29:21 --> Helper loaded: form_helper
INFO - 2024-02-15 23:29:21 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:29:21 --> Controller Class Initialized
INFO - 2024-02-15 23:29:21 --> Form Validation Class Initialized
INFO - 2024-02-15 23:29:21 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:29:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:29:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:29:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:29:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:29:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:29:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:29:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:29:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:29:21 --> Final output sent to browser
DEBUG - 2024-02-15 23:29:21 --> Total execution time: 0.0166
ERROR - 2024-02-15 23:29:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:29:21 --> Config Class Initialized
INFO - 2024-02-15 23:29:21 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:29:21 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:29:21 --> Utf8 Class Initialized
INFO - 2024-02-15 23:29:21 --> URI Class Initialized
INFO - 2024-02-15 23:29:21 --> Router Class Initialized
INFO - 2024-02-15 23:29:21 --> Output Class Initialized
INFO - 2024-02-15 23:29:21 --> Security Class Initialized
DEBUG - 2024-02-15 23:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:29:21 --> Input Class Initialized
INFO - 2024-02-15 23:29:21 --> Language Class Initialized
INFO - 2024-02-15 23:29:21 --> Loader Class Initialized
INFO - 2024-02-15 23:29:21 --> Helper loaded: url_helper
INFO - 2024-02-15 23:29:21 --> Helper loaded: file_helper
INFO - 2024-02-15 23:29:21 --> Helper loaded: form_helper
INFO - 2024-02-15 23:29:21 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:29:21 --> Controller Class Initialized
INFO - 2024-02-15 23:29:21 --> Form Validation Class Initialized
INFO - 2024-02-15 23:29:21 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:29:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:29:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:29:21 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:29:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:29:23 --> Config Class Initialized
INFO - 2024-02-15 23:29:23 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:29:23 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:29:23 --> Utf8 Class Initialized
INFO - 2024-02-15 23:29:23 --> URI Class Initialized
INFO - 2024-02-15 23:29:23 --> Router Class Initialized
INFO - 2024-02-15 23:29:23 --> Output Class Initialized
INFO - 2024-02-15 23:29:23 --> Security Class Initialized
DEBUG - 2024-02-15 23:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:29:23 --> Input Class Initialized
INFO - 2024-02-15 23:29:23 --> Language Class Initialized
INFO - 2024-02-15 23:29:23 --> Loader Class Initialized
INFO - 2024-02-15 23:29:23 --> Helper loaded: url_helper
INFO - 2024-02-15 23:29:23 --> Helper loaded: file_helper
INFO - 2024-02-15 23:29:23 --> Helper loaded: form_helper
INFO - 2024-02-15 23:29:23 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:29:23 --> Controller Class Initialized
INFO - 2024-02-15 23:29:23 --> Form Validation Class Initialized
INFO - 2024-02-15 23:29:23 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:29:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:29:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:29:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:29:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:29:23 --> Final output sent to browser
DEBUG - 2024-02-15 23:29:23 --> Total execution time: 0.0170
ERROR - 2024-02-15 23:31:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:31:32 --> Config Class Initialized
INFO - 2024-02-15 23:31:32 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:31:32 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:31:32 --> Utf8 Class Initialized
INFO - 2024-02-15 23:31:32 --> URI Class Initialized
INFO - 2024-02-15 23:31:32 --> Router Class Initialized
INFO - 2024-02-15 23:31:32 --> Output Class Initialized
INFO - 2024-02-15 23:31:32 --> Security Class Initialized
DEBUG - 2024-02-15 23:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:31:32 --> Input Class Initialized
INFO - 2024-02-15 23:31:32 --> Language Class Initialized
INFO - 2024-02-15 23:31:32 --> Loader Class Initialized
INFO - 2024-02-15 23:31:32 --> Helper loaded: url_helper
INFO - 2024-02-15 23:31:32 --> Helper loaded: file_helper
INFO - 2024-02-15 23:31:32 --> Helper loaded: form_helper
INFO - 2024-02-15 23:31:32 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:31:32 --> Controller Class Initialized
INFO - 2024-02-15 23:31:32 --> Form Validation Class Initialized
INFO - 2024-02-15 23:31:32 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:31:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:31:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:31:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:31:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:31:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:31:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:31:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:31:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:31:32 --> Final output sent to browser
DEBUG - 2024-02-15 23:31:32 --> Total execution time: 0.0192
ERROR - 2024-02-15 23:31:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:31:33 --> Config Class Initialized
INFO - 2024-02-15 23:31:33 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:31:33 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:31:33 --> Utf8 Class Initialized
INFO - 2024-02-15 23:31:33 --> URI Class Initialized
INFO - 2024-02-15 23:31:33 --> Router Class Initialized
INFO - 2024-02-15 23:31:33 --> Output Class Initialized
INFO - 2024-02-15 23:31:33 --> Security Class Initialized
DEBUG - 2024-02-15 23:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:31:33 --> Input Class Initialized
INFO - 2024-02-15 23:31:33 --> Language Class Initialized
INFO - 2024-02-15 23:31:33 --> Loader Class Initialized
INFO - 2024-02-15 23:31:33 --> Helper loaded: url_helper
INFO - 2024-02-15 23:31:33 --> Helper loaded: file_helper
INFO - 2024-02-15 23:31:33 --> Helper loaded: form_helper
INFO - 2024-02-15 23:31:33 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:31:33 --> Controller Class Initialized
INFO - 2024-02-15 23:31:33 --> Form Validation Class Initialized
INFO - 2024-02-15 23:31:33 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:31:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:31:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:31:33 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:31:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:31:36 --> Config Class Initialized
INFO - 2024-02-15 23:31:36 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:31:36 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:31:36 --> Utf8 Class Initialized
INFO - 2024-02-15 23:31:36 --> URI Class Initialized
INFO - 2024-02-15 23:31:36 --> Router Class Initialized
INFO - 2024-02-15 23:31:36 --> Output Class Initialized
INFO - 2024-02-15 23:31:36 --> Security Class Initialized
DEBUG - 2024-02-15 23:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:31:36 --> Input Class Initialized
INFO - 2024-02-15 23:31:36 --> Language Class Initialized
INFO - 2024-02-15 23:31:36 --> Loader Class Initialized
INFO - 2024-02-15 23:31:36 --> Helper loaded: url_helper
INFO - 2024-02-15 23:31:36 --> Helper loaded: file_helper
INFO - 2024-02-15 23:31:36 --> Helper loaded: form_helper
INFO - 2024-02-15 23:31:36 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:31:36 --> Controller Class Initialized
INFO - 2024-02-15 23:31:36 --> Form Validation Class Initialized
INFO - 2024-02-15 23:31:36 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:31:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:31:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:31:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:31:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:31:36 --> Final output sent to browser
DEBUG - 2024-02-15 23:31:36 --> Total execution time: 0.0163
ERROR - 2024-02-15 23:32:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:32:15 --> Config Class Initialized
INFO - 2024-02-15 23:32:15 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:32:15 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:32:15 --> Utf8 Class Initialized
INFO - 2024-02-15 23:32:15 --> URI Class Initialized
INFO - 2024-02-15 23:32:15 --> Router Class Initialized
INFO - 2024-02-15 23:32:15 --> Output Class Initialized
INFO - 2024-02-15 23:32:15 --> Security Class Initialized
DEBUG - 2024-02-15 23:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:32:15 --> Input Class Initialized
INFO - 2024-02-15 23:32:15 --> Language Class Initialized
INFO - 2024-02-15 23:32:15 --> Loader Class Initialized
INFO - 2024-02-15 23:32:15 --> Helper loaded: url_helper
INFO - 2024-02-15 23:32:15 --> Helper loaded: file_helper
INFO - 2024-02-15 23:32:15 --> Helper loaded: form_helper
INFO - 2024-02-15 23:32:15 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:32:15 --> Controller Class Initialized
INFO - 2024-02-15 23:32:15 --> Form Validation Class Initialized
INFO - 2024-02-15 23:32:15 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:32:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:32:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:32:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:32:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:32:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:32:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:32:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:32:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:32:15 --> Final output sent to browser
DEBUG - 2024-02-15 23:32:15 --> Total execution time: 0.0152
ERROR - 2024-02-15 23:32:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:32:15 --> Config Class Initialized
INFO - 2024-02-15 23:32:15 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:32:15 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:32:15 --> Utf8 Class Initialized
INFO - 2024-02-15 23:32:15 --> URI Class Initialized
INFO - 2024-02-15 23:32:15 --> Router Class Initialized
INFO - 2024-02-15 23:32:15 --> Output Class Initialized
INFO - 2024-02-15 23:32:15 --> Security Class Initialized
DEBUG - 2024-02-15 23:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:32:15 --> Input Class Initialized
INFO - 2024-02-15 23:32:15 --> Language Class Initialized
INFO - 2024-02-15 23:32:15 --> Loader Class Initialized
INFO - 2024-02-15 23:32:15 --> Helper loaded: url_helper
INFO - 2024-02-15 23:32:15 --> Helper loaded: file_helper
INFO - 2024-02-15 23:32:15 --> Helper loaded: form_helper
INFO - 2024-02-15 23:32:15 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:32:15 --> Controller Class Initialized
INFO - 2024-02-15 23:32:15 --> Form Validation Class Initialized
INFO - 2024-02-15 23:32:15 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:32:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:32:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:32:15 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:32:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:32:18 --> Config Class Initialized
INFO - 2024-02-15 23:32:18 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:32:18 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:32:18 --> Utf8 Class Initialized
INFO - 2024-02-15 23:32:18 --> URI Class Initialized
INFO - 2024-02-15 23:32:18 --> Router Class Initialized
INFO - 2024-02-15 23:32:18 --> Output Class Initialized
INFO - 2024-02-15 23:32:18 --> Security Class Initialized
DEBUG - 2024-02-15 23:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:32:18 --> Input Class Initialized
INFO - 2024-02-15 23:32:18 --> Language Class Initialized
INFO - 2024-02-15 23:32:18 --> Loader Class Initialized
INFO - 2024-02-15 23:32:18 --> Helper loaded: url_helper
INFO - 2024-02-15 23:32:18 --> Helper loaded: file_helper
INFO - 2024-02-15 23:32:18 --> Helper loaded: form_helper
INFO - 2024-02-15 23:32:18 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:32:18 --> Controller Class Initialized
INFO - 2024-02-15 23:32:18 --> Form Validation Class Initialized
INFO - 2024-02-15 23:32:18 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:32:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:32:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:32:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:32:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:32:18 --> Final output sent to browser
DEBUG - 2024-02-15 23:32:18 --> Total execution time: 0.0179
ERROR - 2024-02-15 23:33:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:33:17 --> Config Class Initialized
INFO - 2024-02-15 23:33:17 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:33:17 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:33:17 --> Utf8 Class Initialized
INFO - 2024-02-15 23:33:17 --> URI Class Initialized
INFO - 2024-02-15 23:33:17 --> Router Class Initialized
INFO - 2024-02-15 23:33:17 --> Output Class Initialized
INFO - 2024-02-15 23:33:17 --> Security Class Initialized
DEBUG - 2024-02-15 23:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:33:17 --> Input Class Initialized
INFO - 2024-02-15 23:33:17 --> Language Class Initialized
INFO - 2024-02-15 23:33:17 --> Loader Class Initialized
INFO - 2024-02-15 23:33:17 --> Helper loaded: url_helper
INFO - 2024-02-15 23:33:17 --> Helper loaded: file_helper
INFO - 2024-02-15 23:33:17 --> Helper loaded: form_helper
INFO - 2024-02-15 23:33:17 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:33:17 --> Controller Class Initialized
INFO - 2024-02-15 23:33:17 --> Form Validation Class Initialized
INFO - 2024-02-15 23:33:17 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:33:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:33:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:33:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:33:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:33:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:33:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:33:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:33:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:33:17 --> Final output sent to browser
DEBUG - 2024-02-15 23:33:17 --> Total execution time: 0.0152
ERROR - 2024-02-15 23:33:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:33:17 --> Config Class Initialized
INFO - 2024-02-15 23:33:17 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:33:17 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:33:17 --> Utf8 Class Initialized
INFO - 2024-02-15 23:33:17 --> URI Class Initialized
INFO - 2024-02-15 23:33:17 --> Router Class Initialized
INFO - 2024-02-15 23:33:17 --> Output Class Initialized
INFO - 2024-02-15 23:33:17 --> Security Class Initialized
DEBUG - 2024-02-15 23:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:33:17 --> Input Class Initialized
INFO - 2024-02-15 23:33:17 --> Language Class Initialized
INFO - 2024-02-15 23:33:17 --> Loader Class Initialized
INFO - 2024-02-15 23:33:17 --> Helper loaded: url_helper
INFO - 2024-02-15 23:33:17 --> Helper loaded: file_helper
INFO - 2024-02-15 23:33:17 --> Helper loaded: form_helper
INFO - 2024-02-15 23:33:17 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:33:17 --> Controller Class Initialized
INFO - 2024-02-15 23:33:17 --> Form Validation Class Initialized
INFO - 2024-02-15 23:33:17 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:33:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:33:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:33:17 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:33:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:33:20 --> Config Class Initialized
INFO - 2024-02-15 23:33:20 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:33:20 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:33:20 --> Utf8 Class Initialized
INFO - 2024-02-15 23:33:20 --> URI Class Initialized
INFO - 2024-02-15 23:33:20 --> Router Class Initialized
INFO - 2024-02-15 23:33:20 --> Output Class Initialized
INFO - 2024-02-15 23:33:20 --> Security Class Initialized
DEBUG - 2024-02-15 23:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:33:20 --> Input Class Initialized
INFO - 2024-02-15 23:33:20 --> Language Class Initialized
INFO - 2024-02-15 23:33:20 --> Loader Class Initialized
INFO - 2024-02-15 23:33:20 --> Helper loaded: url_helper
INFO - 2024-02-15 23:33:20 --> Helper loaded: file_helper
INFO - 2024-02-15 23:33:20 --> Helper loaded: form_helper
INFO - 2024-02-15 23:33:20 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:33:20 --> Controller Class Initialized
INFO - 2024-02-15 23:33:20 --> Form Validation Class Initialized
INFO - 2024-02-15 23:33:20 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:33:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:33:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:33:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:33:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:33:20 --> Final output sent to browser
DEBUG - 2024-02-15 23:33:20 --> Total execution time: 0.0153
ERROR - 2024-02-15 23:34:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:34:01 --> Config Class Initialized
INFO - 2024-02-15 23:34:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:34:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:34:01 --> Utf8 Class Initialized
INFO - 2024-02-15 23:34:01 --> URI Class Initialized
INFO - 2024-02-15 23:34:01 --> Router Class Initialized
INFO - 2024-02-15 23:34:01 --> Output Class Initialized
INFO - 2024-02-15 23:34:01 --> Security Class Initialized
DEBUG - 2024-02-15 23:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:34:01 --> Input Class Initialized
INFO - 2024-02-15 23:34:01 --> Language Class Initialized
INFO - 2024-02-15 23:34:01 --> Loader Class Initialized
INFO - 2024-02-15 23:34:01 --> Helper loaded: url_helper
INFO - 2024-02-15 23:34:01 --> Helper loaded: file_helper
INFO - 2024-02-15 23:34:01 --> Helper loaded: form_helper
INFO - 2024-02-15 23:34:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:34:01 --> Controller Class Initialized
INFO - 2024-02-15 23:34:01 --> Form Validation Class Initialized
INFO - 2024-02-15 23:34:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:34:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:34:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:34:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:34:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:34:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:34:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:34:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:34:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:34:01 --> Final output sent to browser
DEBUG - 2024-02-15 23:34:01 --> Total execution time: 0.0140
ERROR - 2024-02-15 23:34:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:34:01 --> Config Class Initialized
INFO - 2024-02-15 23:34:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:34:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:34:01 --> Utf8 Class Initialized
INFO - 2024-02-15 23:34:01 --> URI Class Initialized
INFO - 2024-02-15 23:34:01 --> Router Class Initialized
INFO - 2024-02-15 23:34:01 --> Output Class Initialized
INFO - 2024-02-15 23:34:01 --> Security Class Initialized
DEBUG - 2024-02-15 23:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:34:01 --> Input Class Initialized
INFO - 2024-02-15 23:34:01 --> Language Class Initialized
INFO - 2024-02-15 23:34:01 --> Loader Class Initialized
INFO - 2024-02-15 23:34:01 --> Helper loaded: url_helper
INFO - 2024-02-15 23:34:01 --> Helper loaded: file_helper
INFO - 2024-02-15 23:34:01 --> Helper loaded: form_helper
INFO - 2024-02-15 23:34:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:34:01 --> Controller Class Initialized
INFO - 2024-02-15 23:34:01 --> Form Validation Class Initialized
INFO - 2024-02-15 23:34:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:34:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:34:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:34:01 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:34:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:34:04 --> Config Class Initialized
INFO - 2024-02-15 23:34:04 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:34:04 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:34:04 --> Utf8 Class Initialized
INFO - 2024-02-15 23:34:04 --> URI Class Initialized
INFO - 2024-02-15 23:34:04 --> Router Class Initialized
INFO - 2024-02-15 23:34:04 --> Output Class Initialized
INFO - 2024-02-15 23:34:04 --> Security Class Initialized
DEBUG - 2024-02-15 23:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:34:04 --> Input Class Initialized
INFO - 2024-02-15 23:34:04 --> Language Class Initialized
INFO - 2024-02-15 23:34:04 --> Loader Class Initialized
INFO - 2024-02-15 23:34:04 --> Helper loaded: url_helper
INFO - 2024-02-15 23:34:04 --> Helper loaded: file_helper
INFO - 2024-02-15 23:34:04 --> Helper loaded: form_helper
INFO - 2024-02-15 23:34:04 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:34:04 --> Controller Class Initialized
INFO - 2024-02-15 23:34:04 --> Form Validation Class Initialized
INFO - 2024-02-15 23:34:04 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:34:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:34:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:34:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:34:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:34:04 --> Final output sent to browser
DEBUG - 2024-02-15 23:34:04 --> Total execution time: 0.0168
ERROR - 2024-02-15 23:36:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:36:02 --> Config Class Initialized
INFO - 2024-02-15 23:36:02 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:36:02 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:36:02 --> Utf8 Class Initialized
INFO - 2024-02-15 23:36:02 --> URI Class Initialized
INFO - 2024-02-15 23:36:02 --> Router Class Initialized
INFO - 2024-02-15 23:36:02 --> Output Class Initialized
INFO - 2024-02-15 23:36:02 --> Security Class Initialized
DEBUG - 2024-02-15 23:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:36:02 --> Input Class Initialized
INFO - 2024-02-15 23:36:02 --> Language Class Initialized
INFO - 2024-02-15 23:36:02 --> Loader Class Initialized
INFO - 2024-02-15 23:36:02 --> Helper loaded: url_helper
INFO - 2024-02-15 23:36:02 --> Helper loaded: file_helper
INFO - 2024-02-15 23:36:02 --> Helper loaded: form_helper
INFO - 2024-02-15 23:36:02 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:36:02 --> Controller Class Initialized
INFO - 2024-02-15 23:36:02 --> Form Validation Class Initialized
INFO - 2024-02-15 23:36:02 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:36:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:36:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:36:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:36:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:36:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:36:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:36:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:36:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:36:02 --> Final output sent to browser
DEBUG - 2024-02-15 23:36:02 --> Total execution time: 0.0179
ERROR - 2024-02-15 23:36:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:36:02 --> Config Class Initialized
INFO - 2024-02-15 23:36:02 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:36:02 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:36:02 --> Utf8 Class Initialized
INFO - 2024-02-15 23:36:02 --> URI Class Initialized
INFO - 2024-02-15 23:36:02 --> Router Class Initialized
INFO - 2024-02-15 23:36:02 --> Output Class Initialized
INFO - 2024-02-15 23:36:02 --> Security Class Initialized
DEBUG - 2024-02-15 23:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:36:02 --> Input Class Initialized
INFO - 2024-02-15 23:36:02 --> Language Class Initialized
INFO - 2024-02-15 23:36:02 --> Loader Class Initialized
INFO - 2024-02-15 23:36:02 --> Helper loaded: url_helper
INFO - 2024-02-15 23:36:02 --> Helper loaded: file_helper
INFO - 2024-02-15 23:36:02 --> Helper loaded: form_helper
INFO - 2024-02-15 23:36:02 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:36:02 --> Controller Class Initialized
INFO - 2024-02-15 23:36:02 --> Form Validation Class Initialized
INFO - 2024-02-15 23:36:02 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:36:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:36:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:36:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:36:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:36:05 --> Config Class Initialized
INFO - 2024-02-15 23:36:05 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:36:05 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:36:05 --> Utf8 Class Initialized
INFO - 2024-02-15 23:36:05 --> URI Class Initialized
INFO - 2024-02-15 23:36:05 --> Router Class Initialized
INFO - 2024-02-15 23:36:05 --> Output Class Initialized
INFO - 2024-02-15 23:36:05 --> Security Class Initialized
DEBUG - 2024-02-15 23:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:36:05 --> Input Class Initialized
INFO - 2024-02-15 23:36:05 --> Language Class Initialized
INFO - 2024-02-15 23:36:05 --> Loader Class Initialized
INFO - 2024-02-15 23:36:05 --> Helper loaded: url_helper
INFO - 2024-02-15 23:36:05 --> Helper loaded: file_helper
INFO - 2024-02-15 23:36:05 --> Helper loaded: form_helper
INFO - 2024-02-15 23:36:05 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:36:05 --> Controller Class Initialized
INFO - 2024-02-15 23:36:05 --> Form Validation Class Initialized
INFO - 2024-02-15 23:36:05 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:36:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:36:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:36:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:36:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:36:05 --> Final output sent to browser
DEBUG - 2024-02-15 23:36:05 --> Total execution time: 0.0152
ERROR - 2024-02-15 23:36:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:36:52 --> Config Class Initialized
INFO - 2024-02-15 23:36:52 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:36:52 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:36:52 --> Utf8 Class Initialized
INFO - 2024-02-15 23:36:52 --> URI Class Initialized
INFO - 2024-02-15 23:36:52 --> Router Class Initialized
INFO - 2024-02-15 23:36:52 --> Output Class Initialized
INFO - 2024-02-15 23:36:52 --> Security Class Initialized
DEBUG - 2024-02-15 23:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:36:52 --> Input Class Initialized
INFO - 2024-02-15 23:36:52 --> Language Class Initialized
INFO - 2024-02-15 23:36:52 --> Loader Class Initialized
INFO - 2024-02-15 23:36:52 --> Helper loaded: url_helper
INFO - 2024-02-15 23:36:52 --> Helper loaded: file_helper
INFO - 2024-02-15 23:36:52 --> Helper loaded: form_helper
INFO - 2024-02-15 23:36:52 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:36:52 --> Controller Class Initialized
INFO - 2024-02-15 23:36:52 --> Form Validation Class Initialized
INFO - 2024-02-15 23:36:52 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:36:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:36:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:36:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:36:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:36:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:36:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:36:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:36:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:36:52 --> Final output sent to browser
DEBUG - 2024-02-15 23:36:52 --> Total execution time: 0.0169
ERROR - 2024-02-15 23:36:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:36:53 --> Config Class Initialized
INFO - 2024-02-15 23:36:53 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:36:53 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:36:53 --> Utf8 Class Initialized
INFO - 2024-02-15 23:36:53 --> URI Class Initialized
INFO - 2024-02-15 23:36:53 --> Router Class Initialized
INFO - 2024-02-15 23:36:53 --> Output Class Initialized
INFO - 2024-02-15 23:36:53 --> Security Class Initialized
DEBUG - 2024-02-15 23:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:36:53 --> Input Class Initialized
INFO - 2024-02-15 23:36:53 --> Language Class Initialized
INFO - 2024-02-15 23:36:53 --> Loader Class Initialized
INFO - 2024-02-15 23:36:53 --> Helper loaded: url_helper
INFO - 2024-02-15 23:36:53 --> Helper loaded: file_helper
INFO - 2024-02-15 23:36:53 --> Helper loaded: form_helper
INFO - 2024-02-15 23:36:53 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:36:53 --> Controller Class Initialized
INFO - 2024-02-15 23:36:53 --> Form Validation Class Initialized
INFO - 2024-02-15 23:36:53 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:36:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:36:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:36:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:36:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:36:55 --> Config Class Initialized
INFO - 2024-02-15 23:36:55 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:36:55 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:36:55 --> Utf8 Class Initialized
INFO - 2024-02-15 23:36:55 --> URI Class Initialized
INFO - 2024-02-15 23:36:55 --> Router Class Initialized
INFO - 2024-02-15 23:36:55 --> Output Class Initialized
INFO - 2024-02-15 23:36:55 --> Security Class Initialized
DEBUG - 2024-02-15 23:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:36:55 --> Input Class Initialized
INFO - 2024-02-15 23:36:55 --> Language Class Initialized
INFO - 2024-02-15 23:36:55 --> Loader Class Initialized
INFO - 2024-02-15 23:36:55 --> Helper loaded: url_helper
INFO - 2024-02-15 23:36:55 --> Helper loaded: file_helper
INFO - 2024-02-15 23:36:55 --> Helper loaded: form_helper
INFO - 2024-02-15 23:36:55 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:36:55 --> Controller Class Initialized
INFO - 2024-02-15 23:36:55 --> Form Validation Class Initialized
INFO - 2024-02-15 23:36:55 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:36:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:36:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:36:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:36:55 --> Final output sent to browser
DEBUG - 2024-02-15 23:36:55 --> Total execution time: 0.0278
ERROR - 2024-02-15 23:38:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:38:01 --> Config Class Initialized
INFO - 2024-02-15 23:38:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:38:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:38:01 --> Utf8 Class Initialized
INFO - 2024-02-15 23:38:01 --> URI Class Initialized
INFO - 2024-02-15 23:38:01 --> Router Class Initialized
INFO - 2024-02-15 23:38:01 --> Output Class Initialized
INFO - 2024-02-15 23:38:01 --> Security Class Initialized
DEBUG - 2024-02-15 23:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:38:01 --> Input Class Initialized
INFO - 2024-02-15 23:38:01 --> Language Class Initialized
INFO - 2024-02-15 23:38:01 --> Loader Class Initialized
INFO - 2024-02-15 23:38:01 --> Helper loaded: url_helper
INFO - 2024-02-15 23:38:01 --> Helper loaded: file_helper
INFO - 2024-02-15 23:38:01 --> Helper loaded: form_helper
INFO - 2024-02-15 23:38:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:38:01 --> Controller Class Initialized
INFO - 2024-02-15 23:38:01 --> Form Validation Class Initialized
INFO - 2024-02-15 23:38:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:38:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:38:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:38:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:38:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:38:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:38:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:38:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:38:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:38:01 --> Final output sent to browser
DEBUG - 2024-02-15 23:38:01 --> Total execution time: 0.0165
ERROR - 2024-02-15 23:38:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:38:01 --> Config Class Initialized
INFO - 2024-02-15 23:38:01 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:38:01 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:38:01 --> Utf8 Class Initialized
INFO - 2024-02-15 23:38:01 --> URI Class Initialized
INFO - 2024-02-15 23:38:01 --> Router Class Initialized
INFO - 2024-02-15 23:38:01 --> Output Class Initialized
INFO - 2024-02-15 23:38:01 --> Security Class Initialized
DEBUG - 2024-02-15 23:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:38:01 --> Input Class Initialized
INFO - 2024-02-15 23:38:01 --> Language Class Initialized
INFO - 2024-02-15 23:38:01 --> Loader Class Initialized
INFO - 2024-02-15 23:38:01 --> Helper loaded: url_helper
INFO - 2024-02-15 23:38:01 --> Helper loaded: file_helper
INFO - 2024-02-15 23:38:01 --> Helper loaded: form_helper
INFO - 2024-02-15 23:38:01 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:38:01 --> Controller Class Initialized
INFO - 2024-02-15 23:38:01 --> Form Validation Class Initialized
INFO - 2024-02-15 23:38:01 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:38:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:38:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:38:01 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:38:03 --> Config Class Initialized
INFO - 2024-02-15 23:38:03 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:38:03 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:38:03 --> Utf8 Class Initialized
INFO - 2024-02-15 23:38:03 --> URI Class Initialized
INFO - 2024-02-15 23:38:03 --> Router Class Initialized
INFO - 2024-02-15 23:38:03 --> Output Class Initialized
INFO - 2024-02-15 23:38:03 --> Security Class Initialized
DEBUG - 2024-02-15 23:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:38:03 --> Input Class Initialized
INFO - 2024-02-15 23:38:03 --> Language Class Initialized
INFO - 2024-02-15 23:38:03 --> Loader Class Initialized
INFO - 2024-02-15 23:38:03 --> Helper loaded: url_helper
INFO - 2024-02-15 23:38:03 --> Helper loaded: file_helper
INFO - 2024-02-15 23:38:03 --> Helper loaded: form_helper
INFO - 2024-02-15 23:38:03 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:38:03 --> Controller Class Initialized
INFO - 2024-02-15 23:38:03 --> Form Validation Class Initialized
INFO - 2024-02-15 23:38:03 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:38:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:38:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:38:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:38:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:38:03 --> Final output sent to browser
DEBUG - 2024-02-15 23:38:03 --> Total execution time: 0.0144
ERROR - 2024-02-15 23:39:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:39:35 --> Config Class Initialized
INFO - 2024-02-15 23:39:35 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:39:35 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:39:35 --> Utf8 Class Initialized
INFO - 2024-02-15 23:39:35 --> URI Class Initialized
INFO - 2024-02-15 23:39:35 --> Router Class Initialized
INFO - 2024-02-15 23:39:35 --> Output Class Initialized
INFO - 2024-02-15 23:39:35 --> Security Class Initialized
DEBUG - 2024-02-15 23:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:39:35 --> Input Class Initialized
INFO - 2024-02-15 23:39:35 --> Language Class Initialized
INFO - 2024-02-15 23:39:35 --> Loader Class Initialized
INFO - 2024-02-15 23:39:35 --> Helper loaded: url_helper
INFO - 2024-02-15 23:39:35 --> Helper loaded: file_helper
INFO - 2024-02-15 23:39:35 --> Helper loaded: form_helper
INFO - 2024-02-15 23:39:35 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:39:35 --> Controller Class Initialized
INFO - 2024-02-15 23:39:35 --> Form Validation Class Initialized
INFO - 2024-02-15 23:39:35 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:39:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:39:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:39:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:39:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:39:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:39:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:39:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:39:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:39:35 --> Final output sent to browser
DEBUG - 2024-02-15 23:39:35 --> Total execution time: 0.0153
ERROR - 2024-02-15 23:39:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:39:35 --> Config Class Initialized
INFO - 2024-02-15 23:39:35 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:39:35 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:39:35 --> Utf8 Class Initialized
INFO - 2024-02-15 23:39:35 --> URI Class Initialized
INFO - 2024-02-15 23:39:35 --> Router Class Initialized
INFO - 2024-02-15 23:39:35 --> Output Class Initialized
INFO - 2024-02-15 23:39:35 --> Security Class Initialized
DEBUG - 2024-02-15 23:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:39:35 --> Input Class Initialized
INFO - 2024-02-15 23:39:35 --> Language Class Initialized
INFO - 2024-02-15 23:39:35 --> Loader Class Initialized
INFO - 2024-02-15 23:39:35 --> Helper loaded: url_helper
INFO - 2024-02-15 23:39:35 --> Helper loaded: file_helper
INFO - 2024-02-15 23:39:35 --> Helper loaded: form_helper
INFO - 2024-02-15 23:39:35 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:39:35 --> Controller Class Initialized
INFO - 2024-02-15 23:39:35 --> Form Validation Class Initialized
INFO - 2024-02-15 23:39:35 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:39:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:39:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:39:35 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:39:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:39:38 --> Config Class Initialized
INFO - 2024-02-15 23:39:38 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:39:38 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:39:38 --> Utf8 Class Initialized
INFO - 2024-02-15 23:39:38 --> URI Class Initialized
INFO - 2024-02-15 23:39:38 --> Router Class Initialized
INFO - 2024-02-15 23:39:38 --> Output Class Initialized
INFO - 2024-02-15 23:39:38 --> Security Class Initialized
DEBUG - 2024-02-15 23:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:39:38 --> Input Class Initialized
INFO - 2024-02-15 23:39:38 --> Language Class Initialized
INFO - 2024-02-15 23:39:38 --> Loader Class Initialized
INFO - 2024-02-15 23:39:38 --> Helper loaded: url_helper
INFO - 2024-02-15 23:39:38 --> Helper loaded: file_helper
INFO - 2024-02-15 23:39:38 --> Helper loaded: form_helper
INFO - 2024-02-15 23:39:38 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:39:38 --> Controller Class Initialized
INFO - 2024-02-15 23:39:38 --> Form Validation Class Initialized
INFO - 2024-02-15 23:39:38 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:39:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:39:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:39:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:39:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:39:38 --> Final output sent to browser
DEBUG - 2024-02-15 23:39:38 --> Total execution time: 0.0157
ERROR - 2024-02-15 23:41:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:41:54 --> Config Class Initialized
INFO - 2024-02-15 23:41:54 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:41:54 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:41:54 --> Utf8 Class Initialized
INFO - 2024-02-15 23:41:54 --> URI Class Initialized
INFO - 2024-02-15 23:41:54 --> Router Class Initialized
INFO - 2024-02-15 23:41:54 --> Output Class Initialized
INFO - 2024-02-15 23:41:54 --> Security Class Initialized
DEBUG - 2024-02-15 23:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:41:54 --> Input Class Initialized
INFO - 2024-02-15 23:41:54 --> Language Class Initialized
INFO - 2024-02-15 23:41:54 --> Loader Class Initialized
INFO - 2024-02-15 23:41:54 --> Helper loaded: url_helper
INFO - 2024-02-15 23:41:54 --> Helper loaded: file_helper
INFO - 2024-02-15 23:41:54 --> Helper loaded: form_helper
INFO - 2024-02-15 23:41:54 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:41:54 --> Controller Class Initialized
INFO - 2024-02-15 23:41:54 --> Form Validation Class Initialized
INFO - 2024-02-15 23:41:54 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:41:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:41:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:41:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:41:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:41:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:41:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:41:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:41:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:41:54 --> Final output sent to browser
DEBUG - 2024-02-15 23:41:54 --> Total execution time: 0.0152
ERROR - 2024-02-15 23:41:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:41:54 --> Config Class Initialized
INFO - 2024-02-15 23:41:54 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:41:54 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:41:54 --> Utf8 Class Initialized
INFO - 2024-02-15 23:41:54 --> URI Class Initialized
INFO - 2024-02-15 23:41:54 --> Router Class Initialized
INFO - 2024-02-15 23:41:54 --> Output Class Initialized
INFO - 2024-02-15 23:41:54 --> Security Class Initialized
DEBUG - 2024-02-15 23:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:41:54 --> Input Class Initialized
INFO - 2024-02-15 23:41:54 --> Language Class Initialized
INFO - 2024-02-15 23:41:54 --> Loader Class Initialized
INFO - 2024-02-15 23:41:54 --> Helper loaded: url_helper
INFO - 2024-02-15 23:41:55 --> Helper loaded: file_helper
INFO - 2024-02-15 23:41:55 --> Helper loaded: form_helper
INFO - 2024-02-15 23:41:55 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:41:55 --> Controller Class Initialized
INFO - 2024-02-15 23:41:55 --> Form Validation Class Initialized
INFO - 2024-02-15 23:41:55 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:41:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:41:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:41:55 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:41:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:41:57 --> Config Class Initialized
INFO - 2024-02-15 23:41:57 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:41:57 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:41:57 --> Utf8 Class Initialized
INFO - 2024-02-15 23:41:57 --> URI Class Initialized
INFO - 2024-02-15 23:41:57 --> Router Class Initialized
INFO - 2024-02-15 23:41:57 --> Output Class Initialized
INFO - 2024-02-15 23:41:57 --> Security Class Initialized
DEBUG - 2024-02-15 23:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:41:57 --> Input Class Initialized
INFO - 2024-02-15 23:41:57 --> Language Class Initialized
INFO - 2024-02-15 23:41:57 --> Loader Class Initialized
INFO - 2024-02-15 23:41:57 --> Helper loaded: url_helper
INFO - 2024-02-15 23:41:57 --> Helper loaded: file_helper
INFO - 2024-02-15 23:41:57 --> Helper loaded: form_helper
INFO - 2024-02-15 23:41:57 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:41:57 --> Controller Class Initialized
INFO - 2024-02-15 23:41:57 --> Form Validation Class Initialized
INFO - 2024-02-15 23:41:57 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:41:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:41:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:41:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:41:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:41:57 --> Final output sent to browser
DEBUG - 2024-02-15 23:41:57 --> Total execution time: 0.0167
ERROR - 2024-02-15 23:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:43:25 --> Config Class Initialized
INFO - 2024-02-15 23:43:25 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:43:25 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:43:25 --> Utf8 Class Initialized
INFO - 2024-02-15 23:43:25 --> URI Class Initialized
INFO - 2024-02-15 23:43:25 --> Router Class Initialized
INFO - 2024-02-15 23:43:25 --> Output Class Initialized
INFO - 2024-02-15 23:43:25 --> Security Class Initialized
DEBUG - 2024-02-15 23:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:43:25 --> Input Class Initialized
INFO - 2024-02-15 23:43:25 --> Language Class Initialized
INFO - 2024-02-15 23:43:25 --> Loader Class Initialized
INFO - 2024-02-15 23:43:25 --> Helper loaded: url_helper
INFO - 2024-02-15 23:43:25 --> Helper loaded: file_helper
INFO - 2024-02-15 23:43:25 --> Helper loaded: form_helper
INFO - 2024-02-15 23:43:25 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:43:25 --> Controller Class Initialized
INFO - 2024-02-15 23:43:25 --> Form Validation Class Initialized
INFO - 2024-02-15 23:43:25 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:43:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:43:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:43:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:43:25 --> Final output sent to browser
DEBUG - 2024-02-15 23:43:25 --> Total execution time: 0.0195
ERROR - 2024-02-15 23:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:43:25 --> Config Class Initialized
INFO - 2024-02-15 23:43:25 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:43:25 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:43:25 --> Utf8 Class Initialized
INFO - 2024-02-15 23:43:25 --> URI Class Initialized
INFO - 2024-02-15 23:43:25 --> Router Class Initialized
INFO - 2024-02-15 23:43:25 --> Output Class Initialized
INFO - 2024-02-15 23:43:25 --> Security Class Initialized
DEBUG - 2024-02-15 23:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:43:25 --> Input Class Initialized
INFO - 2024-02-15 23:43:25 --> Language Class Initialized
INFO - 2024-02-15 23:43:25 --> Loader Class Initialized
INFO - 2024-02-15 23:43:25 --> Helper loaded: url_helper
INFO - 2024-02-15 23:43:25 --> Helper loaded: file_helper
INFO - 2024-02-15 23:43:25 --> Helper loaded: form_helper
INFO - 2024-02-15 23:43:25 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:43:25 --> Controller Class Initialized
INFO - 2024-02-15 23:43:25 --> Form Validation Class Initialized
INFO - 2024-02-15 23:43:25 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:43:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:43:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:43:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:43:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:43:28 --> Config Class Initialized
INFO - 2024-02-15 23:43:28 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:43:28 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:43:28 --> Utf8 Class Initialized
INFO - 2024-02-15 23:43:28 --> URI Class Initialized
INFO - 2024-02-15 23:43:28 --> Router Class Initialized
INFO - 2024-02-15 23:43:28 --> Output Class Initialized
INFO - 2024-02-15 23:43:28 --> Security Class Initialized
DEBUG - 2024-02-15 23:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:43:28 --> Input Class Initialized
INFO - 2024-02-15 23:43:28 --> Language Class Initialized
INFO - 2024-02-15 23:43:28 --> Loader Class Initialized
INFO - 2024-02-15 23:43:28 --> Helper loaded: url_helper
INFO - 2024-02-15 23:43:28 --> Helper loaded: file_helper
INFO - 2024-02-15 23:43:28 --> Helper loaded: form_helper
INFO - 2024-02-15 23:43:28 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:43:28 --> Controller Class Initialized
INFO - 2024-02-15 23:43:28 --> Form Validation Class Initialized
INFO - 2024-02-15 23:43:28 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:43:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:43:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:43:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:43:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:43:28 --> Final output sent to browser
DEBUG - 2024-02-15 23:43:28 --> Total execution time: 0.0159
ERROR - 2024-02-15 23:44:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:44:17 --> Config Class Initialized
INFO - 2024-02-15 23:44:17 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:44:17 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:44:17 --> Utf8 Class Initialized
INFO - 2024-02-15 23:44:17 --> URI Class Initialized
INFO - 2024-02-15 23:44:17 --> Router Class Initialized
INFO - 2024-02-15 23:44:17 --> Output Class Initialized
INFO - 2024-02-15 23:44:17 --> Security Class Initialized
DEBUG - 2024-02-15 23:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:44:17 --> Input Class Initialized
INFO - 2024-02-15 23:44:17 --> Language Class Initialized
INFO - 2024-02-15 23:44:17 --> Loader Class Initialized
INFO - 2024-02-15 23:44:17 --> Helper loaded: url_helper
INFO - 2024-02-15 23:44:17 --> Helper loaded: file_helper
INFO - 2024-02-15 23:44:17 --> Helper loaded: form_helper
INFO - 2024-02-15 23:44:17 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:44:17 --> Controller Class Initialized
INFO - 2024-02-15 23:44:17 --> Form Validation Class Initialized
INFO - 2024-02-15 23:44:17 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:44:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:44:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:44:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:44:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:44:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:44:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:44:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:44:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:44:17 --> Final output sent to browser
DEBUG - 2024-02-15 23:44:17 --> Total execution time: 0.0150
ERROR - 2024-02-15 23:44:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:44:17 --> Config Class Initialized
INFO - 2024-02-15 23:44:17 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:44:17 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:44:17 --> Utf8 Class Initialized
INFO - 2024-02-15 23:44:17 --> URI Class Initialized
INFO - 2024-02-15 23:44:17 --> Router Class Initialized
INFO - 2024-02-15 23:44:17 --> Output Class Initialized
INFO - 2024-02-15 23:44:17 --> Security Class Initialized
DEBUG - 2024-02-15 23:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:44:17 --> Input Class Initialized
INFO - 2024-02-15 23:44:17 --> Language Class Initialized
INFO - 2024-02-15 23:44:17 --> Loader Class Initialized
INFO - 2024-02-15 23:44:17 --> Helper loaded: url_helper
INFO - 2024-02-15 23:44:17 --> Helper loaded: file_helper
INFO - 2024-02-15 23:44:17 --> Helper loaded: form_helper
INFO - 2024-02-15 23:44:17 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:44:17 --> Controller Class Initialized
INFO - 2024-02-15 23:44:17 --> Form Validation Class Initialized
INFO - 2024-02-15 23:44:17 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:44:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:44:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:44:17 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:44:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:44:20 --> Config Class Initialized
INFO - 2024-02-15 23:44:20 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:44:20 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:44:20 --> Utf8 Class Initialized
INFO - 2024-02-15 23:44:20 --> URI Class Initialized
INFO - 2024-02-15 23:44:20 --> Router Class Initialized
INFO - 2024-02-15 23:44:20 --> Output Class Initialized
INFO - 2024-02-15 23:44:20 --> Security Class Initialized
DEBUG - 2024-02-15 23:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:44:20 --> Input Class Initialized
INFO - 2024-02-15 23:44:20 --> Language Class Initialized
INFO - 2024-02-15 23:44:20 --> Loader Class Initialized
INFO - 2024-02-15 23:44:20 --> Helper loaded: url_helper
INFO - 2024-02-15 23:44:20 --> Helper loaded: file_helper
INFO - 2024-02-15 23:44:20 --> Helper loaded: form_helper
INFO - 2024-02-15 23:44:20 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:44:20 --> Controller Class Initialized
INFO - 2024-02-15 23:44:20 --> Form Validation Class Initialized
INFO - 2024-02-15 23:44:20 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:44:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:44:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:44:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:44:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:44:20 --> Final output sent to browser
DEBUG - 2024-02-15 23:44:20 --> Total execution time: 0.0161
ERROR - 2024-02-15 23:45:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:45:30 --> Config Class Initialized
INFO - 2024-02-15 23:45:30 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:45:30 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:45:30 --> Utf8 Class Initialized
INFO - 2024-02-15 23:45:30 --> URI Class Initialized
INFO - 2024-02-15 23:45:30 --> Router Class Initialized
INFO - 2024-02-15 23:45:30 --> Output Class Initialized
INFO - 2024-02-15 23:45:30 --> Security Class Initialized
DEBUG - 2024-02-15 23:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:45:30 --> Input Class Initialized
INFO - 2024-02-15 23:45:30 --> Language Class Initialized
INFO - 2024-02-15 23:45:30 --> Loader Class Initialized
INFO - 2024-02-15 23:45:30 --> Helper loaded: url_helper
INFO - 2024-02-15 23:45:30 --> Helper loaded: file_helper
INFO - 2024-02-15 23:45:30 --> Helper loaded: form_helper
INFO - 2024-02-15 23:45:30 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:45:30 --> Controller Class Initialized
INFO - 2024-02-15 23:45:30 --> Form Validation Class Initialized
INFO - 2024-02-15 23:45:30 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:45:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:45:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:45:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:45:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:45:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:45:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:45:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:45:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-15 23:45:30 --> Final output sent to browser
DEBUG - 2024-02-15 23:45:30 --> Total execution time: 0.0153
ERROR - 2024-02-15 23:45:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:45:30 --> Config Class Initialized
INFO - 2024-02-15 23:45:30 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:45:30 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:45:30 --> Utf8 Class Initialized
INFO - 2024-02-15 23:45:30 --> URI Class Initialized
INFO - 2024-02-15 23:45:30 --> Router Class Initialized
INFO - 2024-02-15 23:45:30 --> Output Class Initialized
INFO - 2024-02-15 23:45:30 --> Security Class Initialized
DEBUG - 2024-02-15 23:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:45:30 --> Input Class Initialized
INFO - 2024-02-15 23:45:30 --> Language Class Initialized
INFO - 2024-02-15 23:45:30 --> Loader Class Initialized
INFO - 2024-02-15 23:45:30 --> Helper loaded: url_helper
INFO - 2024-02-15 23:45:30 --> Helper loaded: file_helper
INFO - 2024-02-15 23:45:30 --> Helper loaded: form_helper
INFO - 2024-02-15 23:45:30 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:45:30 --> Controller Class Initialized
INFO - 2024-02-15 23:45:30 --> Form Validation Class Initialized
INFO - 2024-02-15 23:45:30 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:45:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:45:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:45:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:45:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:45:34 --> Config Class Initialized
INFO - 2024-02-15 23:45:34 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:45:34 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:45:34 --> Utf8 Class Initialized
INFO - 2024-02-15 23:45:34 --> URI Class Initialized
INFO - 2024-02-15 23:45:34 --> Router Class Initialized
INFO - 2024-02-15 23:45:34 --> Output Class Initialized
INFO - 2024-02-15 23:45:34 --> Security Class Initialized
DEBUG - 2024-02-15 23:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:45:34 --> Input Class Initialized
INFO - 2024-02-15 23:45:34 --> Language Class Initialized
INFO - 2024-02-15 23:45:34 --> Loader Class Initialized
INFO - 2024-02-15 23:45:34 --> Helper loaded: url_helper
INFO - 2024-02-15 23:45:34 --> Helper loaded: file_helper
INFO - 2024-02-15 23:45:34 --> Helper loaded: form_helper
INFO - 2024-02-15 23:45:34 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:45:34 --> Controller Class Initialized
INFO - 2024-02-15 23:45:34 --> Form Validation Class Initialized
INFO - 2024-02-15 23:45:34 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:45:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:45:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:45:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:45:34 --> Final output sent to browser
DEBUG - 2024-02-15 23:45:34 --> Total execution time: 0.0164
ERROR - 2024-02-15 23:46:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:46:22 --> Config Class Initialized
INFO - 2024-02-15 23:46:22 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:46:22 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:46:22 --> Utf8 Class Initialized
INFO - 2024-02-15 23:46:22 --> URI Class Initialized
INFO - 2024-02-15 23:46:22 --> Router Class Initialized
INFO - 2024-02-15 23:46:22 --> Output Class Initialized
INFO - 2024-02-15 23:46:22 --> Security Class Initialized
DEBUG - 2024-02-15 23:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:46:22 --> Input Class Initialized
INFO - 2024-02-15 23:46:22 --> Language Class Initialized
INFO - 2024-02-15 23:46:22 --> Loader Class Initialized
INFO - 2024-02-15 23:46:22 --> Helper loaded: url_helper
INFO - 2024-02-15 23:46:22 --> Helper loaded: file_helper
INFO - 2024-02-15 23:46:22 --> Helper loaded: form_helper
INFO - 2024-02-15 23:46:22 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:46:22 --> Controller Class Initialized
INFO - 2024-02-15 23:46:22 --> Form Validation Class Initialized
INFO - 2024-02-15 23:46:22 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:46:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:46:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:46:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-15 23:46:22 --> Final output sent to browser
DEBUG - 2024-02-15 23:46:22 --> Total execution time: 0.0208
ERROR - 2024-02-15 23:46:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:46:44 --> Config Class Initialized
INFO - 2024-02-15 23:46:44 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:46:44 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:46:44 --> Utf8 Class Initialized
INFO - 2024-02-15 23:46:44 --> URI Class Initialized
INFO - 2024-02-15 23:46:44 --> Router Class Initialized
INFO - 2024-02-15 23:46:44 --> Output Class Initialized
INFO - 2024-02-15 23:46:44 --> Security Class Initialized
DEBUG - 2024-02-15 23:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:46:44 --> Input Class Initialized
INFO - 2024-02-15 23:46:44 --> Language Class Initialized
INFO - 2024-02-15 23:46:44 --> Loader Class Initialized
INFO - 2024-02-15 23:46:44 --> Helper loaded: url_helper
INFO - 2024-02-15 23:46:44 --> Helper loaded: file_helper
INFO - 2024-02-15 23:46:44 --> Helper loaded: form_helper
INFO - 2024-02-15 23:46:44 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:46:44 --> Controller Class Initialized
INFO - 2024-02-15 23:46:44 --> Form Validation Class Initialized
INFO - 2024-02-15 23:46:44 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:46:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:46:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:46:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:47:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:02 --> Config Class Initialized
INFO - 2024-02-15 23:47:02 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:02 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:02 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:02 --> URI Class Initialized
INFO - 2024-02-15 23:47:02 --> Router Class Initialized
INFO - 2024-02-15 23:47:02 --> Output Class Initialized
INFO - 2024-02-15 23:47:02 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:02 --> Input Class Initialized
INFO - 2024-02-15 23:47:02 --> Language Class Initialized
INFO - 2024-02-15 23:47:02 --> Loader Class Initialized
INFO - 2024-02-15 23:47:02 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:02 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:02 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:02 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:02 --> Controller Class Initialized
INFO - 2024-02-15 23:47:02 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:02 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:47:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:47:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:47:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:47:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:47:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-15 23:47:02 --> Final output sent to browser
DEBUG - 2024-02-15 23:47:02 --> Total execution time: 0.0151
ERROR - 2024-02-15 23:47:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:02 --> Config Class Initialized
INFO - 2024-02-15 23:47:02 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:02 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:02 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:02 --> URI Class Initialized
INFO - 2024-02-15 23:47:02 --> Router Class Initialized
INFO - 2024-02-15 23:47:02 --> Output Class Initialized
INFO - 2024-02-15 23:47:02 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:02 --> Input Class Initialized
INFO - 2024-02-15 23:47:02 --> Language Class Initialized
INFO - 2024-02-15 23:47:02 --> Loader Class Initialized
INFO - 2024-02-15 23:47:02 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:02 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:02 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:02 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:02 --> Controller Class Initialized
INFO - 2024-02-15 23:47:02 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:02 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:47:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:04 --> Config Class Initialized
INFO - 2024-02-15 23:47:04 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:04 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:04 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:04 --> URI Class Initialized
INFO - 2024-02-15 23:47:04 --> Router Class Initialized
INFO - 2024-02-15 23:47:04 --> Output Class Initialized
INFO - 2024-02-15 23:47:04 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:04 --> Input Class Initialized
INFO - 2024-02-15 23:47:04 --> Language Class Initialized
INFO - 2024-02-15 23:47:04 --> Loader Class Initialized
INFO - 2024-02-15 23:47:04 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:04 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:04 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:04 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:04 --> Controller Class Initialized
INFO - 2024-02-15 23:47:04 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:04 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:04 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:47:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:07 --> Config Class Initialized
INFO - 2024-02-15 23:47:07 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:07 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:07 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:07 --> URI Class Initialized
INFO - 2024-02-15 23:47:07 --> Router Class Initialized
INFO - 2024-02-15 23:47:07 --> Output Class Initialized
INFO - 2024-02-15 23:47:07 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:07 --> Input Class Initialized
INFO - 2024-02-15 23:47:07 --> Language Class Initialized
INFO - 2024-02-15 23:47:07 --> Loader Class Initialized
INFO - 2024-02-15 23:47:07 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:07 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:07 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:07 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:07 --> Controller Class Initialized
INFO - 2024-02-15 23:47:07 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:07 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:07 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:47:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:10 --> Config Class Initialized
INFO - 2024-02-15 23:47:10 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:10 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:10 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:10 --> URI Class Initialized
INFO - 2024-02-15 23:47:10 --> Router Class Initialized
INFO - 2024-02-15 23:47:10 --> Output Class Initialized
INFO - 2024-02-15 23:47:10 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:10 --> Input Class Initialized
INFO - 2024-02-15 23:47:10 --> Language Class Initialized
INFO - 2024-02-15 23:47:10 --> Loader Class Initialized
INFO - 2024-02-15 23:47:10 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:10 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:10 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:10 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:10 --> Controller Class Initialized
INFO - 2024-02-15 23:47:10 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:10 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:10 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:47:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:14 --> Config Class Initialized
INFO - 2024-02-15 23:47:14 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:14 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:14 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:14 --> URI Class Initialized
INFO - 2024-02-15 23:47:14 --> Router Class Initialized
INFO - 2024-02-15 23:47:14 --> Output Class Initialized
INFO - 2024-02-15 23:47:14 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:14 --> Input Class Initialized
INFO - 2024-02-15 23:47:14 --> Language Class Initialized
INFO - 2024-02-15 23:47:14 --> Loader Class Initialized
INFO - 2024-02-15 23:47:14 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:14 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:14 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:14 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:14 --> Controller Class Initialized
INFO - 2024-02-15 23:47:14 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:14 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:47:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:24 --> Config Class Initialized
INFO - 2024-02-15 23:47:24 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:24 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:24 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:24 --> URI Class Initialized
INFO - 2024-02-15 23:47:24 --> Router Class Initialized
INFO - 2024-02-15 23:47:24 --> Output Class Initialized
INFO - 2024-02-15 23:47:24 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:24 --> Input Class Initialized
INFO - 2024-02-15 23:47:24 --> Language Class Initialized
INFO - 2024-02-15 23:47:24 --> Loader Class Initialized
INFO - 2024-02-15 23:47:24 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:24 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:24 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:24 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:24 --> Controller Class Initialized
INFO - 2024-02-15 23:47:24 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:24 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:47:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:27 --> Config Class Initialized
INFO - 2024-02-15 23:47:27 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:27 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:27 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:27 --> URI Class Initialized
INFO - 2024-02-15 23:47:27 --> Router Class Initialized
INFO - 2024-02-15 23:47:27 --> Output Class Initialized
INFO - 2024-02-15 23:47:27 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:27 --> Input Class Initialized
INFO - 2024-02-15 23:47:27 --> Language Class Initialized
INFO - 2024-02-15 23:47:27 --> Loader Class Initialized
INFO - 2024-02-15 23:47:27 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:27 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:27 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:27 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:27 --> Controller Class Initialized
INFO - 2024-02-15 23:47:27 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:27 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:47:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:30 --> Config Class Initialized
INFO - 2024-02-15 23:47:30 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:30 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:30 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:30 --> URI Class Initialized
INFO - 2024-02-15 23:47:30 --> Router Class Initialized
INFO - 2024-02-15 23:47:30 --> Output Class Initialized
INFO - 2024-02-15 23:47:30 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:30 --> Input Class Initialized
INFO - 2024-02-15 23:47:30 --> Language Class Initialized
INFO - 2024-02-15 23:47:30 --> Loader Class Initialized
INFO - 2024-02-15 23:47:30 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:30 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:30 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:30 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:30 --> Controller Class Initialized
INFO - 2024-02-15 23:47:30 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:30 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:32 --> Config Class Initialized
INFO - 2024-02-15 23:47:32 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:32 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:32 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:32 --> URI Class Initialized
INFO - 2024-02-15 23:47:32 --> Router Class Initialized
INFO - 2024-02-15 23:47:32 --> Output Class Initialized
INFO - 2024-02-15 23:47:32 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:32 --> Input Class Initialized
INFO - 2024-02-15 23:47:32 --> Language Class Initialized
INFO - 2024-02-15 23:47:32 --> Loader Class Initialized
INFO - 2024-02-15 23:47:32 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:32 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:32 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:32 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:32 --> Controller Class Initialized
INFO - 2024-02-15 23:47:32 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:32 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:32 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:47:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:36 --> Config Class Initialized
INFO - 2024-02-15 23:47:36 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:36 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:36 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:36 --> URI Class Initialized
INFO - 2024-02-15 23:47:36 --> Router Class Initialized
INFO - 2024-02-15 23:47:36 --> Output Class Initialized
INFO - 2024-02-15 23:47:36 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:36 --> Input Class Initialized
INFO - 2024-02-15 23:47:36 --> Language Class Initialized
INFO - 2024-02-15 23:47:36 --> Loader Class Initialized
INFO - 2024-02-15 23:47:36 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:36 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:36 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:36 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:36 --> Controller Class Initialized
INFO - 2024-02-15 23:47:36 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:36 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:36 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-15 23:47:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:40 --> Config Class Initialized
INFO - 2024-02-15 23:47:40 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:40 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:40 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:40 --> URI Class Initialized
INFO - 2024-02-15 23:47:40 --> Router Class Initialized
INFO - 2024-02-15 23:47:40 --> Output Class Initialized
INFO - 2024-02-15 23:47:40 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:40 --> Input Class Initialized
INFO - 2024-02-15 23:47:40 --> Language Class Initialized
INFO - 2024-02-15 23:47:40 --> Loader Class Initialized
INFO - 2024-02-15 23:47:40 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:40 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:40 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:40 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:40 --> Controller Class Initialized
INFO - 2024-02-15 23:47:40 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:40 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:47:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:47:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-15 23:47:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:47:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:47:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:47:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-15 23:47:40 --> Final output sent to browser
DEBUG - 2024-02-15 23:47:40 --> Total execution time: 0.0176
ERROR - 2024-02-15 23:47:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:50 --> Config Class Initialized
INFO - 2024-02-15 23:47:50 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:50 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:50 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:50 --> URI Class Initialized
INFO - 2024-02-15 23:47:50 --> Router Class Initialized
INFO - 2024-02-15 23:47:50 --> Output Class Initialized
INFO - 2024-02-15 23:47:50 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:50 --> Input Class Initialized
INFO - 2024-02-15 23:47:50 --> Language Class Initialized
INFO - 2024-02-15 23:47:50 --> Loader Class Initialized
INFO - 2024-02-15 23:47:50 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:50 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:50 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:50 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:50 --> Controller Class Initialized
INFO - 2024-02-15 23:47:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-15 23:47:50 --> Final output sent to browser
DEBUG - 2024-02-15 23:47:50 --> Total execution time: 0.0148
ERROR - 2024-02-15 23:47:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:53 --> Config Class Initialized
INFO - 2024-02-15 23:47:53 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:53 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:53 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:53 --> URI Class Initialized
INFO - 2024-02-15 23:47:53 --> Router Class Initialized
INFO - 2024-02-15 23:47:53 --> Output Class Initialized
INFO - 2024-02-15 23:47:53 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:53 --> Input Class Initialized
INFO - 2024-02-15 23:47:53 --> Language Class Initialized
INFO - 2024-02-15 23:47:53 --> Loader Class Initialized
INFO - 2024-02-15 23:47:53 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:53 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:53 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:53 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:53 --> Controller Class Initialized
INFO - 2024-02-15 23:47:53 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:53 --> Model "MasterModel" initialized
INFO - 2024-02-15 23:47:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-15 23:47:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-15 23:47:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-15 23:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-15 23:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-15 23:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-15 23:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-15 23:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-15 23:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-15 23:47:53 --> Final output sent to browser
DEBUG - 2024-02-15 23:47:53 --> Total execution time: 0.0236
ERROR - 2024-02-15 23:47:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:59 --> Config Class Initialized
INFO - 2024-02-15 23:47:59 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:59 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:59 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:59 --> URI Class Initialized
INFO - 2024-02-15 23:47:59 --> Router Class Initialized
INFO - 2024-02-15 23:47:59 --> Output Class Initialized
INFO - 2024-02-15 23:47:59 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:59 --> Input Class Initialized
INFO - 2024-02-15 23:47:59 --> Language Class Initialized
INFO - 2024-02-15 23:47:59 --> Loader Class Initialized
INFO - 2024-02-15 23:47:59 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:59 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:59 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:59 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:59 --> Controller Class Initialized
INFO - 2024-02-15 23:47:59 --> Model "LoginModel" initialized
INFO - 2024-02-15 23:47:59 --> Form Validation Class Initialized
ERROR - 2024-02-15 23:47:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-15 23:47:59 --> Config Class Initialized
INFO - 2024-02-15 23:47:59 --> Hooks Class Initialized
DEBUG - 2024-02-15 23:47:59 --> UTF-8 Support Enabled
INFO - 2024-02-15 23:47:59 --> Utf8 Class Initialized
INFO - 2024-02-15 23:47:59 --> URI Class Initialized
INFO - 2024-02-15 23:47:59 --> Router Class Initialized
INFO - 2024-02-15 23:47:59 --> Output Class Initialized
INFO - 2024-02-15 23:47:59 --> Security Class Initialized
DEBUG - 2024-02-15 23:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-15 23:47:59 --> Input Class Initialized
INFO - 2024-02-15 23:47:59 --> Language Class Initialized
INFO - 2024-02-15 23:47:59 --> Loader Class Initialized
INFO - 2024-02-15 23:47:59 --> Helper loaded: url_helper
INFO - 2024-02-15 23:47:59 --> Helper loaded: file_helper
INFO - 2024-02-15 23:47:59 --> Helper loaded: form_helper
INFO - 2024-02-15 23:47:59 --> Database Driver Class Initialized
DEBUG - 2024-02-15 23:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-15 23:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-15 23:47:59 --> Controller Class Initialized
INFO - 2024-02-15 23:47:59 --> Model "LoginModel" initialized
INFO - 2024-02-15 23:47:59 --> Form Validation Class Initialized
INFO - 2024-02-15 23:47:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-15 23:47:59 --> Final output sent to browser
DEBUG - 2024-02-15 23:47:59 --> Total execution time: 0.0163
