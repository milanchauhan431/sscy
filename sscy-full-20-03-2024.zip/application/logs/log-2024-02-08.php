<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-08 11:28:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:28:01 --> Config Class Initialized
INFO - 2024-02-08 11:28:01 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:28:01 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:28:01 --> Utf8 Class Initialized
INFO - 2024-02-08 11:28:01 --> URI Class Initialized
INFO - 2024-02-08 11:28:01 --> Router Class Initialized
INFO - 2024-02-08 11:28:01 --> Output Class Initialized
INFO - 2024-02-08 11:28:01 --> Security Class Initialized
DEBUG - 2024-02-08 11:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:28:01 --> Input Class Initialized
INFO - 2024-02-08 11:28:01 --> Language Class Initialized
INFO - 2024-02-08 11:28:01 --> Loader Class Initialized
INFO - 2024-02-08 11:28:01 --> Helper loaded: url_helper
INFO - 2024-02-08 11:28:01 --> Helper loaded: file_helper
INFO - 2024-02-08 11:28:01 --> Helper loaded: form_helper
INFO - 2024-02-08 11:28:01 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:28:01 --> Controller Class Initialized
INFO - 2024-02-08 11:28:01 --> Model "LoginModel" initialized
INFO - 2024-02-08 11:28:01 --> Form Validation Class Initialized
ERROR - 2024-02-08 11:28:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:28:01 --> Config Class Initialized
INFO - 2024-02-08 11:28:01 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:28:01 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:28:01 --> Utf8 Class Initialized
INFO - 2024-02-08 11:28:01 --> URI Class Initialized
INFO - 2024-02-08 11:28:01 --> Router Class Initialized
INFO - 2024-02-08 11:28:01 --> Output Class Initialized
INFO - 2024-02-08 11:28:01 --> Security Class Initialized
DEBUG - 2024-02-08 11:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:28:01 --> Input Class Initialized
INFO - 2024-02-08 11:28:01 --> Language Class Initialized
INFO - 2024-02-08 11:28:01 --> Loader Class Initialized
INFO - 2024-02-08 11:28:01 --> Helper loaded: url_helper
INFO - 2024-02-08 11:28:01 --> Helper loaded: file_helper
INFO - 2024-02-08 11:28:01 --> Helper loaded: form_helper
INFO - 2024-02-08 11:28:01 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:28:01 --> Controller Class Initialized
INFO - 2024-02-08 11:28:01 --> Form Validation Class Initialized
INFO - 2024-02-08 11:28:01 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:28:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 11:28:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 11:28:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 11:28:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 11:28:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 11:28:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 11:28:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 11:28:01 --> Final output sent to browser
DEBUG - 2024-02-08 11:28:01 --> Total execution time: 0.0262
ERROR - 2024-02-08 11:28:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:28:05 --> Config Class Initialized
INFO - 2024-02-08 11:28:05 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:28:05 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:28:05 --> Utf8 Class Initialized
INFO - 2024-02-08 11:28:05 --> URI Class Initialized
INFO - 2024-02-08 11:28:05 --> Router Class Initialized
INFO - 2024-02-08 11:28:05 --> Output Class Initialized
INFO - 2024-02-08 11:28:05 --> Security Class Initialized
DEBUG - 2024-02-08 11:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:28:05 --> Input Class Initialized
INFO - 2024-02-08 11:28:05 --> Language Class Initialized
INFO - 2024-02-08 11:28:05 --> Loader Class Initialized
INFO - 2024-02-08 11:28:05 --> Helper loaded: url_helper
INFO - 2024-02-08 11:28:05 --> Helper loaded: file_helper
INFO - 2024-02-08 11:28:05 --> Helper loaded: form_helper
INFO - 2024-02-08 11:28:05 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:28:05 --> Controller Class Initialized
INFO - 2024-02-08 11:28:05 --> Form Validation Class Initialized
INFO - 2024-02-08 11:28:05 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:28:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 11:28:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 11:28:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 11:28:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 11:28:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 11:28:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 11:28:05 --> Final output sent to browser
DEBUG - 2024-02-08 11:28:05 --> Total execution time: 0.0631
ERROR - 2024-02-08 11:28:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:28:05 --> Config Class Initialized
INFO - 2024-02-08 11:28:05 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:28:05 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:28:05 --> Utf8 Class Initialized
INFO - 2024-02-08 11:28:05 --> URI Class Initialized
INFO - 2024-02-08 11:28:05 --> Router Class Initialized
INFO - 2024-02-08 11:28:05 --> Output Class Initialized
INFO - 2024-02-08 11:28:05 --> Security Class Initialized
DEBUG - 2024-02-08 11:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:28:05 --> Input Class Initialized
INFO - 2024-02-08 11:28:05 --> Language Class Initialized
INFO - 2024-02-08 11:28:05 --> Loader Class Initialized
INFO - 2024-02-08 11:28:05 --> Helper loaded: url_helper
INFO - 2024-02-08 11:28:05 --> Helper loaded: file_helper
INFO - 2024-02-08 11:28:05 --> Helper loaded: form_helper
INFO - 2024-02-08 11:28:05 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:28:05 --> Controller Class Initialized
INFO - 2024-02-08 11:28:05 --> Form Validation Class Initialized
INFO - 2024-02-08 11:28:05 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:28:05 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 11:29:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:29:21 --> Config Class Initialized
INFO - 2024-02-08 11:29:21 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:29:21 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:29:21 --> Utf8 Class Initialized
INFO - 2024-02-08 11:29:21 --> URI Class Initialized
INFO - 2024-02-08 11:29:21 --> Router Class Initialized
INFO - 2024-02-08 11:29:21 --> Output Class Initialized
INFO - 2024-02-08 11:29:21 --> Security Class Initialized
DEBUG - 2024-02-08 11:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:29:21 --> Input Class Initialized
INFO - 2024-02-08 11:29:21 --> Language Class Initialized
INFO - 2024-02-08 11:29:21 --> Loader Class Initialized
INFO - 2024-02-08 11:29:21 --> Helper loaded: url_helper
INFO - 2024-02-08 11:29:21 --> Helper loaded: file_helper
INFO - 2024-02-08 11:29:21 --> Helper loaded: form_helper
INFO - 2024-02-08 11:29:21 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:29:21 --> Controller Class Initialized
INFO - 2024-02-08 11:29:21 --> Form Validation Class Initialized
INFO - 2024-02-08 11:29:21 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:29:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 11:29:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 11:29:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 11:29:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 11:29:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 11:29:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 11:29:21 --> Final output sent to browser
DEBUG - 2024-02-08 11:29:21 --> Total execution time: 0.0302
ERROR - 2024-02-08 11:29:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:29:21 --> Config Class Initialized
INFO - 2024-02-08 11:29:21 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:29:21 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:29:21 --> Utf8 Class Initialized
INFO - 2024-02-08 11:29:21 --> URI Class Initialized
INFO - 2024-02-08 11:29:21 --> Router Class Initialized
INFO - 2024-02-08 11:29:21 --> Output Class Initialized
INFO - 2024-02-08 11:29:21 --> Security Class Initialized
DEBUG - 2024-02-08 11:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:29:21 --> Input Class Initialized
INFO - 2024-02-08 11:29:21 --> Language Class Initialized
INFO - 2024-02-08 11:29:21 --> Loader Class Initialized
INFO - 2024-02-08 11:29:21 --> Helper loaded: url_helper
INFO - 2024-02-08 11:29:21 --> Helper loaded: file_helper
INFO - 2024-02-08 11:29:21 --> Helper loaded: form_helper
INFO - 2024-02-08 11:29:21 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:29:21 --> Controller Class Initialized
INFO - 2024-02-08 11:29:21 --> Form Validation Class Initialized
INFO - 2024-02-08 11:29:21 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:29:21 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 11:30:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:30:23 --> Config Class Initialized
INFO - 2024-02-08 11:30:23 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:30:23 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:30:23 --> Utf8 Class Initialized
INFO - 2024-02-08 11:30:23 --> URI Class Initialized
INFO - 2024-02-08 11:30:23 --> Router Class Initialized
INFO - 2024-02-08 11:30:23 --> Output Class Initialized
INFO - 2024-02-08 11:30:23 --> Security Class Initialized
DEBUG - 2024-02-08 11:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:30:23 --> Input Class Initialized
INFO - 2024-02-08 11:30:23 --> Language Class Initialized
INFO - 2024-02-08 11:30:23 --> Loader Class Initialized
INFO - 2024-02-08 11:30:23 --> Helper loaded: url_helper
INFO - 2024-02-08 11:30:23 --> Helper loaded: file_helper
INFO - 2024-02-08 11:30:23 --> Helper loaded: form_helper
INFO - 2024-02-08 11:30:23 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:30:23 --> Controller Class Initialized
INFO - 2024-02-08 11:30:23 --> Form Validation Class Initialized
INFO - 2024-02-08 11:30:23 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:30:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 11:30:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 11:30:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 11:30:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 11:30:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 11:30:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 11:30:23 --> Final output sent to browser
DEBUG - 2024-02-08 11:30:23 --> Total execution time: 0.0396
ERROR - 2024-02-08 11:30:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:30:23 --> Config Class Initialized
INFO - 2024-02-08 11:30:23 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:30:23 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:30:23 --> Utf8 Class Initialized
INFO - 2024-02-08 11:30:23 --> URI Class Initialized
INFO - 2024-02-08 11:30:23 --> Router Class Initialized
INFO - 2024-02-08 11:30:23 --> Output Class Initialized
INFO - 2024-02-08 11:30:23 --> Security Class Initialized
DEBUG - 2024-02-08 11:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:30:23 --> Input Class Initialized
INFO - 2024-02-08 11:30:23 --> Language Class Initialized
INFO - 2024-02-08 11:30:23 --> Loader Class Initialized
INFO - 2024-02-08 11:30:23 --> Helper loaded: url_helper
INFO - 2024-02-08 11:30:23 --> Helper loaded: file_helper
INFO - 2024-02-08 11:30:23 --> Helper loaded: form_helper
INFO - 2024-02-08 11:30:23 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:30:23 --> Controller Class Initialized
INFO - 2024-02-08 11:30:23 --> Form Validation Class Initialized
INFO - 2024-02-08 11:30:23 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:30:23 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 11:31:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:31:16 --> Config Class Initialized
INFO - 2024-02-08 11:31:16 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:31:16 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:31:16 --> Utf8 Class Initialized
INFO - 2024-02-08 11:31:16 --> URI Class Initialized
INFO - 2024-02-08 11:31:16 --> Router Class Initialized
INFO - 2024-02-08 11:31:16 --> Output Class Initialized
INFO - 2024-02-08 11:31:16 --> Security Class Initialized
DEBUG - 2024-02-08 11:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:31:16 --> Input Class Initialized
INFO - 2024-02-08 11:31:16 --> Language Class Initialized
INFO - 2024-02-08 11:31:16 --> Loader Class Initialized
INFO - 2024-02-08 11:31:16 --> Helper loaded: url_helper
INFO - 2024-02-08 11:31:16 --> Helper loaded: file_helper
INFO - 2024-02-08 11:31:16 --> Helper loaded: form_helper
INFO - 2024-02-08 11:31:16 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:31:16 --> Controller Class Initialized
INFO - 2024-02-08 11:31:16 --> Form Validation Class Initialized
INFO - 2024-02-08 11:31:16 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:31:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 11:31:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 11:31:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 11:31:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 11:31:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 11:31:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 11:31:16 --> Final output sent to browser
DEBUG - 2024-02-08 11:31:16 --> Total execution time: 0.0371
ERROR - 2024-02-08 11:31:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:31:17 --> Config Class Initialized
INFO - 2024-02-08 11:31:17 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:31:17 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:31:17 --> Utf8 Class Initialized
INFO - 2024-02-08 11:31:17 --> URI Class Initialized
INFO - 2024-02-08 11:31:17 --> Router Class Initialized
INFO - 2024-02-08 11:31:17 --> Output Class Initialized
INFO - 2024-02-08 11:31:17 --> Security Class Initialized
DEBUG - 2024-02-08 11:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:31:17 --> Input Class Initialized
INFO - 2024-02-08 11:31:17 --> Language Class Initialized
INFO - 2024-02-08 11:31:17 --> Loader Class Initialized
INFO - 2024-02-08 11:31:17 --> Helper loaded: url_helper
INFO - 2024-02-08 11:31:17 --> Helper loaded: file_helper
INFO - 2024-02-08 11:31:17 --> Helper loaded: form_helper
INFO - 2024-02-08 11:31:17 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:31:17 --> Controller Class Initialized
INFO - 2024-02-08 11:31:17 --> Form Validation Class Initialized
INFO - 2024-02-08 11:31:17 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:31:17 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 11:33:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:33:10 --> Config Class Initialized
INFO - 2024-02-08 11:33:10 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:33:10 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:33:10 --> Utf8 Class Initialized
INFO - 2024-02-08 11:33:10 --> URI Class Initialized
INFO - 2024-02-08 11:33:10 --> Router Class Initialized
INFO - 2024-02-08 11:33:10 --> Output Class Initialized
INFO - 2024-02-08 11:33:10 --> Security Class Initialized
DEBUG - 2024-02-08 11:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:33:10 --> Input Class Initialized
INFO - 2024-02-08 11:33:10 --> Language Class Initialized
INFO - 2024-02-08 11:33:10 --> Loader Class Initialized
INFO - 2024-02-08 11:33:10 --> Helper loaded: url_helper
INFO - 2024-02-08 11:33:10 --> Helper loaded: file_helper
INFO - 2024-02-08 11:33:10 --> Helper loaded: form_helper
INFO - 2024-02-08 11:33:10 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:33:10 --> Controller Class Initialized
INFO - 2024-02-08 11:33:10 --> Form Validation Class Initialized
INFO - 2024-02-08 11:33:10 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:33:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 11:33:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 11:33:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 11:33:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 11:33:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 11:33:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 11:33:10 --> Final output sent to browser
DEBUG - 2024-02-08 11:33:10 --> Total execution time: 0.0309
ERROR - 2024-02-08 11:33:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:33:10 --> Config Class Initialized
INFO - 2024-02-08 11:33:10 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:33:10 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:33:10 --> Utf8 Class Initialized
INFO - 2024-02-08 11:33:10 --> URI Class Initialized
INFO - 2024-02-08 11:33:10 --> Router Class Initialized
INFO - 2024-02-08 11:33:10 --> Output Class Initialized
INFO - 2024-02-08 11:33:10 --> Security Class Initialized
DEBUG - 2024-02-08 11:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:33:10 --> Input Class Initialized
INFO - 2024-02-08 11:33:10 --> Language Class Initialized
INFO - 2024-02-08 11:33:10 --> Loader Class Initialized
INFO - 2024-02-08 11:33:10 --> Helper loaded: url_helper
INFO - 2024-02-08 11:33:10 --> Helper loaded: file_helper
INFO - 2024-02-08 11:33:10 --> Helper loaded: form_helper
INFO - 2024-02-08 11:33:10 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:33:10 --> Controller Class Initialized
INFO - 2024-02-08 11:33:10 --> Form Validation Class Initialized
INFO - 2024-02-08 11:33:10 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:33:10 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 11:45:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:45:56 --> Config Class Initialized
INFO - 2024-02-08 11:45:56 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:45:56 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:45:56 --> Utf8 Class Initialized
INFO - 2024-02-08 11:45:56 --> URI Class Initialized
INFO - 2024-02-08 11:45:56 --> Router Class Initialized
INFO - 2024-02-08 11:45:56 --> Output Class Initialized
INFO - 2024-02-08 11:45:56 --> Security Class Initialized
DEBUG - 2024-02-08 11:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:45:56 --> Input Class Initialized
INFO - 2024-02-08 11:45:56 --> Language Class Initialized
INFO - 2024-02-08 11:45:56 --> Loader Class Initialized
INFO - 2024-02-08 11:45:56 --> Helper loaded: url_helper
INFO - 2024-02-08 11:45:56 --> Helper loaded: file_helper
INFO - 2024-02-08 11:45:56 --> Helper loaded: form_helper
INFO - 2024-02-08 11:45:56 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:45:56 --> Controller Class Initialized
INFO - 2024-02-08 11:45:56 --> Model "LoginModel" initialized
INFO - 2024-02-08 11:45:56 --> Form Validation Class Initialized
ERROR - 2024-02-08 11:45:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:45:56 --> Config Class Initialized
INFO - 2024-02-08 11:45:56 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:45:56 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:45:56 --> Utf8 Class Initialized
INFO - 2024-02-08 11:45:56 --> URI Class Initialized
INFO - 2024-02-08 11:45:56 --> Router Class Initialized
INFO - 2024-02-08 11:45:56 --> Output Class Initialized
INFO - 2024-02-08 11:45:56 --> Security Class Initialized
DEBUG - 2024-02-08 11:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:45:56 --> Input Class Initialized
INFO - 2024-02-08 11:45:56 --> Language Class Initialized
INFO - 2024-02-08 11:45:56 --> Loader Class Initialized
INFO - 2024-02-08 11:45:56 --> Helper loaded: url_helper
INFO - 2024-02-08 11:45:56 --> Helper loaded: file_helper
INFO - 2024-02-08 11:45:56 --> Helper loaded: form_helper
INFO - 2024-02-08 11:45:56 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:45:57 --> Controller Class Initialized
INFO - 2024-02-08 11:45:57 --> Form Validation Class Initialized
INFO - 2024-02-08 11:45:57 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:45:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 11:45:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 11:45:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 11:45:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 11:45:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 11:45:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 11:45:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 11:45:57 --> Final output sent to browser
DEBUG - 2024-02-08 11:45:57 --> Total execution time: 0.0276
ERROR - 2024-02-08 11:46:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:46:00 --> Config Class Initialized
INFO - 2024-02-08 11:46:00 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:46:00 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:46:00 --> Utf8 Class Initialized
INFO - 2024-02-08 11:46:00 --> URI Class Initialized
INFO - 2024-02-08 11:46:00 --> Router Class Initialized
INFO - 2024-02-08 11:46:00 --> Output Class Initialized
INFO - 2024-02-08 11:46:00 --> Security Class Initialized
DEBUG - 2024-02-08 11:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:46:00 --> Input Class Initialized
INFO - 2024-02-08 11:46:00 --> Language Class Initialized
INFO - 2024-02-08 11:46:00 --> Loader Class Initialized
INFO - 2024-02-08 11:46:00 --> Helper loaded: url_helper
INFO - 2024-02-08 11:46:00 --> Helper loaded: file_helper
INFO - 2024-02-08 11:46:00 --> Helper loaded: form_helper
INFO - 2024-02-08 11:46:00 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:46:00 --> Controller Class Initialized
INFO - 2024-02-08 11:46:00 --> Form Validation Class Initialized
INFO - 2024-02-08 11:46:00 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:46:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 11:46:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 11:46:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 11:46:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 11:46:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 11:46:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 11:46:00 --> Final output sent to browser
DEBUG - 2024-02-08 11:46:00 --> Total execution time: 0.0241
ERROR - 2024-02-08 11:46:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:46:00 --> Config Class Initialized
INFO - 2024-02-08 11:46:00 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:46:00 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:46:00 --> Utf8 Class Initialized
INFO - 2024-02-08 11:46:00 --> URI Class Initialized
INFO - 2024-02-08 11:46:00 --> Router Class Initialized
INFO - 2024-02-08 11:46:00 --> Output Class Initialized
INFO - 2024-02-08 11:46:00 --> Security Class Initialized
DEBUG - 2024-02-08 11:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:46:00 --> Input Class Initialized
INFO - 2024-02-08 11:46:00 --> Language Class Initialized
INFO - 2024-02-08 11:46:00 --> Loader Class Initialized
INFO - 2024-02-08 11:46:00 --> Helper loaded: url_helper
INFO - 2024-02-08 11:46:00 --> Helper loaded: file_helper
INFO - 2024-02-08 11:46:00 --> Helper loaded: form_helper
INFO - 2024-02-08 11:46:00 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:46:00 --> Controller Class Initialized
INFO - 2024-02-08 11:46:00 --> Form Validation Class Initialized
INFO - 2024-02-08 11:46:00 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:46:00 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 11:49:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:49:43 --> Config Class Initialized
INFO - 2024-02-08 11:49:43 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:49:43 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:49:43 --> Utf8 Class Initialized
INFO - 2024-02-08 11:49:43 --> URI Class Initialized
INFO - 2024-02-08 11:49:43 --> Router Class Initialized
INFO - 2024-02-08 11:49:43 --> Output Class Initialized
INFO - 2024-02-08 11:49:43 --> Security Class Initialized
DEBUG - 2024-02-08 11:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:49:43 --> Input Class Initialized
INFO - 2024-02-08 11:49:43 --> Language Class Initialized
INFO - 2024-02-08 11:49:43 --> Loader Class Initialized
INFO - 2024-02-08 11:49:43 --> Helper loaded: url_helper
INFO - 2024-02-08 11:49:43 --> Helper loaded: file_helper
INFO - 2024-02-08 11:49:43 --> Helper loaded: form_helper
INFO - 2024-02-08 11:49:43 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:49:43 --> Controller Class Initialized
INFO - 2024-02-08 11:49:43 --> Form Validation Class Initialized
INFO - 2024-02-08 11:49:43 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:49:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 11:49:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 11:49:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 11:49:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 11:49:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 11:49:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 11:49:43 --> Final output sent to browser
DEBUG - 2024-02-08 11:49:43 --> Total execution time: 0.0393
ERROR - 2024-02-08 11:49:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:49:44 --> Config Class Initialized
INFO - 2024-02-08 11:49:44 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:49:44 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:49:44 --> Utf8 Class Initialized
INFO - 2024-02-08 11:49:44 --> URI Class Initialized
INFO - 2024-02-08 11:49:44 --> Router Class Initialized
INFO - 2024-02-08 11:49:44 --> Output Class Initialized
INFO - 2024-02-08 11:49:44 --> Security Class Initialized
DEBUG - 2024-02-08 11:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:49:44 --> Input Class Initialized
INFO - 2024-02-08 11:49:44 --> Language Class Initialized
INFO - 2024-02-08 11:49:44 --> Loader Class Initialized
INFO - 2024-02-08 11:49:44 --> Helper loaded: url_helper
INFO - 2024-02-08 11:49:44 --> Helper loaded: file_helper
INFO - 2024-02-08 11:49:44 --> Helper loaded: form_helper
INFO - 2024-02-08 11:49:44 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:49:44 --> Controller Class Initialized
INFO - 2024-02-08 11:49:44 --> Form Validation Class Initialized
INFO - 2024-02-08 11:49:44 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:49:44 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 11:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:50:36 --> Config Class Initialized
INFO - 2024-02-08 11:50:36 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:50:36 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:50:36 --> Utf8 Class Initialized
INFO - 2024-02-08 11:50:36 --> URI Class Initialized
INFO - 2024-02-08 11:50:36 --> Router Class Initialized
INFO - 2024-02-08 11:50:36 --> Output Class Initialized
INFO - 2024-02-08 11:50:36 --> Security Class Initialized
DEBUG - 2024-02-08 11:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:50:36 --> Input Class Initialized
INFO - 2024-02-08 11:50:36 --> Language Class Initialized
INFO - 2024-02-08 11:50:36 --> Loader Class Initialized
INFO - 2024-02-08 11:50:36 --> Helper loaded: url_helper
INFO - 2024-02-08 11:50:36 --> Helper loaded: file_helper
INFO - 2024-02-08 11:50:36 --> Helper loaded: form_helper
INFO - 2024-02-08 11:50:36 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:50:36 --> Controller Class Initialized
INFO - 2024-02-08 11:50:36 --> Form Validation Class Initialized
INFO - 2024-02-08 11:50:36 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:50:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 11:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 11:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 11:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 11:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 11:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 11:50:36 --> Final output sent to browser
DEBUG - 2024-02-08 11:50:36 --> Total execution time: 0.0305
ERROR - 2024-02-08 11:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:50:36 --> Config Class Initialized
INFO - 2024-02-08 11:50:36 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:50:36 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:50:36 --> Utf8 Class Initialized
INFO - 2024-02-08 11:50:36 --> URI Class Initialized
INFO - 2024-02-08 11:50:36 --> Router Class Initialized
INFO - 2024-02-08 11:50:36 --> Output Class Initialized
INFO - 2024-02-08 11:50:36 --> Security Class Initialized
DEBUG - 2024-02-08 11:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:50:36 --> Input Class Initialized
INFO - 2024-02-08 11:50:36 --> Language Class Initialized
INFO - 2024-02-08 11:50:36 --> Loader Class Initialized
INFO - 2024-02-08 11:50:36 --> Helper loaded: url_helper
INFO - 2024-02-08 11:50:36 --> Helper loaded: file_helper
INFO - 2024-02-08 11:50:36 --> Helper loaded: form_helper
INFO - 2024-02-08 11:50:36 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:50:36 --> Controller Class Initialized
INFO - 2024-02-08 11:50:36 --> Form Validation Class Initialized
INFO - 2024-02-08 11:50:36 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:50:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 11:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 11:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 11:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 11:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 11:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 11:50:36 --> Final output sent to browser
DEBUG - 2024-02-08 11:50:36 --> Total execution time: 0.0428
ERROR - 2024-02-08 11:50:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:50:37 --> Config Class Initialized
INFO - 2024-02-08 11:50:37 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:50:37 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:50:37 --> Utf8 Class Initialized
INFO - 2024-02-08 11:50:37 --> URI Class Initialized
INFO - 2024-02-08 11:50:37 --> Router Class Initialized
INFO - 2024-02-08 11:50:37 --> Output Class Initialized
INFO - 2024-02-08 11:50:37 --> Security Class Initialized
DEBUG - 2024-02-08 11:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:50:37 --> Input Class Initialized
INFO - 2024-02-08 11:50:37 --> Language Class Initialized
INFO - 2024-02-08 11:50:37 --> Loader Class Initialized
INFO - 2024-02-08 11:50:37 --> Helper loaded: url_helper
INFO - 2024-02-08 11:50:37 --> Helper loaded: file_helper
INFO - 2024-02-08 11:50:37 --> Helper loaded: form_helper
INFO - 2024-02-08 11:50:37 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:50:37 --> Controller Class Initialized
INFO - 2024-02-08 11:50:37 --> Form Validation Class Initialized
INFO - 2024-02-08 11:50:37 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:50:37 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 11:52:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:52:10 --> Config Class Initialized
INFO - 2024-02-08 11:52:10 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:52:10 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:52:10 --> Utf8 Class Initialized
INFO - 2024-02-08 11:52:10 --> URI Class Initialized
INFO - 2024-02-08 11:52:10 --> Router Class Initialized
INFO - 2024-02-08 11:52:10 --> Output Class Initialized
INFO - 2024-02-08 11:52:10 --> Security Class Initialized
DEBUG - 2024-02-08 11:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:52:10 --> Input Class Initialized
INFO - 2024-02-08 11:52:10 --> Language Class Initialized
INFO - 2024-02-08 11:52:10 --> Loader Class Initialized
INFO - 2024-02-08 11:52:10 --> Helper loaded: url_helper
INFO - 2024-02-08 11:52:10 --> Helper loaded: file_helper
INFO - 2024-02-08 11:52:10 --> Helper loaded: form_helper
INFO - 2024-02-08 11:52:10 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:52:10 --> Controller Class Initialized
INFO - 2024-02-08 11:52:10 --> Form Validation Class Initialized
INFO - 2024-02-08 11:52:10 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:52:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 11:52:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 11:52:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 11:52:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 11:52:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 11:52:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 11:52:10 --> Final output sent to browser
DEBUG - 2024-02-08 11:52:10 --> Total execution time: 0.0404
ERROR - 2024-02-08 11:52:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 11:52:11 --> Config Class Initialized
INFO - 2024-02-08 11:52:11 --> Hooks Class Initialized
DEBUG - 2024-02-08 11:52:11 --> UTF-8 Support Enabled
INFO - 2024-02-08 11:52:11 --> Utf8 Class Initialized
INFO - 2024-02-08 11:52:11 --> URI Class Initialized
INFO - 2024-02-08 11:52:11 --> Router Class Initialized
INFO - 2024-02-08 11:52:11 --> Output Class Initialized
INFO - 2024-02-08 11:52:11 --> Security Class Initialized
DEBUG - 2024-02-08 11:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 11:52:11 --> Input Class Initialized
INFO - 2024-02-08 11:52:11 --> Language Class Initialized
INFO - 2024-02-08 11:52:11 --> Loader Class Initialized
INFO - 2024-02-08 11:52:11 --> Helper loaded: url_helper
INFO - 2024-02-08 11:52:11 --> Helper loaded: file_helper
INFO - 2024-02-08 11:52:11 --> Helper loaded: form_helper
INFO - 2024-02-08 11:52:11 --> Database Driver Class Initialized
DEBUG - 2024-02-08 11:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 11:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 11:52:11 --> Controller Class Initialized
INFO - 2024-02-08 11:52:11 --> Form Validation Class Initialized
INFO - 2024-02-08 11:52:11 --> Model "MasterModel" initialized
INFO - 2024-02-08 11:52:11 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 12:12:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:12:12 --> Config Class Initialized
INFO - 2024-02-08 12:12:12 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:12:12 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:12:12 --> Utf8 Class Initialized
INFO - 2024-02-08 12:12:12 --> URI Class Initialized
INFO - 2024-02-08 12:12:12 --> Router Class Initialized
INFO - 2024-02-08 12:12:12 --> Output Class Initialized
INFO - 2024-02-08 12:12:12 --> Security Class Initialized
DEBUG - 2024-02-08 12:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:12:12 --> Input Class Initialized
INFO - 2024-02-08 12:12:12 --> Language Class Initialized
INFO - 2024-02-08 12:12:12 --> Loader Class Initialized
INFO - 2024-02-08 12:12:12 --> Helper loaded: url_helper
INFO - 2024-02-08 12:12:12 --> Helper loaded: file_helper
INFO - 2024-02-08 12:12:12 --> Helper loaded: form_helper
INFO - 2024-02-08 12:12:12 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:12:12 --> Controller Class Initialized
INFO - 2024-02-08 12:12:12 --> Form Validation Class Initialized
INFO - 2024-02-08 12:12:12 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:12:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 12:12:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 12:12:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 12:12:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 12:12:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 12:12:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 12:12:12 --> Final output sent to browser
DEBUG - 2024-02-08 12:12:12 --> Total execution time: 0.0329
ERROR - 2024-02-08 12:12:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:12:13 --> Config Class Initialized
INFO - 2024-02-08 12:12:13 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:12:13 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:12:13 --> Utf8 Class Initialized
INFO - 2024-02-08 12:12:13 --> URI Class Initialized
INFO - 2024-02-08 12:12:13 --> Router Class Initialized
INFO - 2024-02-08 12:12:13 --> Output Class Initialized
INFO - 2024-02-08 12:12:13 --> Security Class Initialized
DEBUG - 2024-02-08 12:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:12:13 --> Input Class Initialized
INFO - 2024-02-08 12:12:13 --> Language Class Initialized
INFO - 2024-02-08 12:12:13 --> Loader Class Initialized
INFO - 2024-02-08 12:12:13 --> Helper loaded: url_helper
INFO - 2024-02-08 12:12:13 --> Helper loaded: file_helper
INFO - 2024-02-08 12:12:13 --> Helper loaded: form_helper
INFO - 2024-02-08 12:12:13 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:12:13 --> Controller Class Initialized
INFO - 2024-02-08 12:12:13 --> Form Validation Class Initialized
INFO - 2024-02-08 12:12:13 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:12:13 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 12:12:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:12:15 --> Config Class Initialized
INFO - 2024-02-08 12:12:15 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:12:15 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:12:15 --> Utf8 Class Initialized
INFO - 2024-02-08 12:12:15 --> URI Class Initialized
INFO - 2024-02-08 12:12:15 --> Router Class Initialized
INFO - 2024-02-08 12:12:15 --> Output Class Initialized
INFO - 2024-02-08 12:12:15 --> Security Class Initialized
DEBUG - 2024-02-08 12:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:12:15 --> Input Class Initialized
INFO - 2024-02-08 12:12:15 --> Language Class Initialized
INFO - 2024-02-08 12:12:15 --> Loader Class Initialized
INFO - 2024-02-08 12:12:15 --> Helper loaded: url_helper
INFO - 2024-02-08 12:12:15 --> Helper loaded: file_helper
INFO - 2024-02-08 12:12:15 --> Helper loaded: form_helper
INFO - 2024-02-08 12:12:15 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:12:15 --> Controller Class Initialized
INFO - 2024-02-08 12:12:15 --> Form Validation Class Initialized
INFO - 2024-02-08 12:12:15 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:12:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 12:12:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 12:12:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 12:12:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 12:12:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 12:12:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 12:12:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 12:12:15 --> Final output sent to browser
DEBUG - 2024-02-08 12:12:15 --> Total execution time: 0.0277
ERROR - 2024-02-08 12:12:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:12:19 --> Config Class Initialized
INFO - 2024-02-08 12:12:19 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:12:19 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:12:19 --> Utf8 Class Initialized
INFO - 2024-02-08 12:12:19 --> URI Class Initialized
INFO - 2024-02-08 12:12:19 --> Router Class Initialized
INFO - 2024-02-08 12:12:19 --> Output Class Initialized
INFO - 2024-02-08 12:12:19 --> Security Class Initialized
DEBUG - 2024-02-08 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:12:19 --> Input Class Initialized
INFO - 2024-02-08 12:12:19 --> Language Class Initialized
INFO - 2024-02-08 12:12:19 --> Loader Class Initialized
INFO - 2024-02-08 12:12:19 --> Helper loaded: url_helper
INFO - 2024-02-08 12:12:19 --> Helper loaded: file_helper
INFO - 2024-02-08 12:12:19 --> Helper loaded: form_helper
INFO - 2024-02-08 12:12:19 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:12:19 --> Controller Class Initialized
INFO - 2024-02-08 12:12:19 --> Form Validation Class Initialized
INFO - 2024-02-08 12:12:19 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:12:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 12:12:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 12:12:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 12:12:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 12:12:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 12:12:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 12:12:19 --> Final output sent to browser
DEBUG - 2024-02-08 12:12:19 --> Total execution time: 0.0329
ERROR - 2024-02-08 12:12:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:12:19 --> Config Class Initialized
INFO - 2024-02-08 12:12:19 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:12:19 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:12:19 --> Utf8 Class Initialized
INFO - 2024-02-08 12:12:19 --> URI Class Initialized
INFO - 2024-02-08 12:12:19 --> Router Class Initialized
INFO - 2024-02-08 12:12:19 --> Output Class Initialized
INFO - 2024-02-08 12:12:19 --> Security Class Initialized
DEBUG - 2024-02-08 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:12:19 --> Input Class Initialized
INFO - 2024-02-08 12:12:19 --> Language Class Initialized
INFO - 2024-02-08 12:12:19 --> Loader Class Initialized
INFO - 2024-02-08 12:12:19 --> Helper loaded: url_helper
INFO - 2024-02-08 12:12:19 --> Helper loaded: file_helper
INFO - 2024-02-08 12:12:19 --> Helper loaded: form_helper
INFO - 2024-02-08 12:12:19 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:12:19 --> Controller Class Initialized
INFO - 2024-02-08 12:12:19 --> Form Validation Class Initialized
INFO - 2024-02-08 12:12:19 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:12:19 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 12:12:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:12:27 --> Config Class Initialized
INFO - 2024-02-08 12:12:27 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:12:27 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:12:27 --> Utf8 Class Initialized
INFO - 2024-02-08 12:12:27 --> URI Class Initialized
INFO - 2024-02-08 12:12:27 --> Router Class Initialized
INFO - 2024-02-08 12:12:27 --> Output Class Initialized
INFO - 2024-02-08 12:12:27 --> Security Class Initialized
DEBUG - 2024-02-08 12:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:12:27 --> Input Class Initialized
INFO - 2024-02-08 12:12:27 --> Language Class Initialized
INFO - 2024-02-08 12:12:27 --> Loader Class Initialized
INFO - 2024-02-08 12:12:27 --> Helper loaded: url_helper
INFO - 2024-02-08 12:12:27 --> Helper loaded: file_helper
INFO - 2024-02-08 12:12:27 --> Helper loaded: form_helper
INFO - 2024-02-08 12:12:27 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:12:27 --> Controller Class Initialized
INFO - 2024-02-08 12:12:27 --> Form Validation Class Initialized
INFO - 2024-02-08 12:12:27 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:12:27 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 12:12:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:12:32 --> Config Class Initialized
INFO - 2024-02-08 12:12:32 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:12:32 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:12:32 --> Utf8 Class Initialized
INFO - 2024-02-08 12:12:32 --> URI Class Initialized
INFO - 2024-02-08 12:12:32 --> Router Class Initialized
INFO - 2024-02-08 12:12:32 --> Output Class Initialized
INFO - 2024-02-08 12:12:32 --> Security Class Initialized
DEBUG - 2024-02-08 12:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:12:32 --> Input Class Initialized
INFO - 2024-02-08 12:12:32 --> Language Class Initialized
INFO - 2024-02-08 12:12:32 --> Loader Class Initialized
INFO - 2024-02-08 12:12:32 --> Helper loaded: url_helper
INFO - 2024-02-08 12:12:32 --> Helper loaded: file_helper
INFO - 2024-02-08 12:12:32 --> Helper loaded: form_helper
INFO - 2024-02-08 12:12:32 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:12:32 --> Controller Class Initialized
INFO - 2024-02-08 12:12:32 --> Form Validation Class Initialized
INFO - 2024-02-08 12:12:32 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:12:32 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 12:12:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:12:36 --> Config Class Initialized
INFO - 2024-02-08 12:12:36 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:12:36 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:12:36 --> Utf8 Class Initialized
INFO - 2024-02-08 12:12:37 --> URI Class Initialized
INFO - 2024-02-08 12:12:37 --> Router Class Initialized
INFO - 2024-02-08 12:12:37 --> Output Class Initialized
INFO - 2024-02-08 12:12:37 --> Security Class Initialized
DEBUG - 2024-02-08 12:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:12:37 --> Input Class Initialized
INFO - 2024-02-08 12:12:37 --> Language Class Initialized
INFO - 2024-02-08 12:12:37 --> Loader Class Initialized
INFO - 2024-02-08 12:12:37 --> Helper loaded: url_helper
INFO - 2024-02-08 12:12:37 --> Helper loaded: file_helper
INFO - 2024-02-08 12:12:37 --> Helper loaded: form_helper
INFO - 2024-02-08 12:12:37 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:12:37 --> Controller Class Initialized
INFO - 2024-02-08 12:12:37 --> Form Validation Class Initialized
INFO - 2024-02-08 12:12:37 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:12:37 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 12:12:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:12:41 --> Config Class Initialized
INFO - 2024-02-08 12:12:41 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:12:41 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:12:41 --> Utf8 Class Initialized
INFO - 2024-02-08 12:12:41 --> URI Class Initialized
INFO - 2024-02-08 12:12:41 --> Router Class Initialized
INFO - 2024-02-08 12:12:41 --> Output Class Initialized
INFO - 2024-02-08 12:12:41 --> Security Class Initialized
DEBUG - 2024-02-08 12:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:12:41 --> Input Class Initialized
INFO - 2024-02-08 12:12:41 --> Language Class Initialized
INFO - 2024-02-08 12:12:41 --> Loader Class Initialized
INFO - 2024-02-08 12:12:41 --> Helper loaded: url_helper
INFO - 2024-02-08 12:12:41 --> Helper loaded: file_helper
INFO - 2024-02-08 12:12:41 --> Helper loaded: form_helper
INFO - 2024-02-08 12:12:41 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:12:41 --> Controller Class Initialized
INFO - 2024-02-08 12:12:41 --> Form Validation Class Initialized
INFO - 2024-02-08 12:12:41 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:12:41 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 12:12:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:12:45 --> Config Class Initialized
INFO - 2024-02-08 12:12:45 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:12:45 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:12:45 --> Utf8 Class Initialized
INFO - 2024-02-08 12:12:45 --> URI Class Initialized
INFO - 2024-02-08 12:12:45 --> Router Class Initialized
INFO - 2024-02-08 12:12:45 --> Output Class Initialized
INFO - 2024-02-08 12:12:45 --> Security Class Initialized
DEBUG - 2024-02-08 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:12:45 --> Input Class Initialized
INFO - 2024-02-08 12:12:45 --> Language Class Initialized
INFO - 2024-02-08 12:12:45 --> Loader Class Initialized
INFO - 2024-02-08 12:12:45 --> Helper loaded: url_helper
INFO - 2024-02-08 12:12:45 --> Helper loaded: file_helper
INFO - 2024-02-08 12:12:45 --> Helper loaded: form_helper
INFO - 2024-02-08 12:12:45 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:12:45 --> Controller Class Initialized
INFO - 2024-02-08 12:12:45 --> Form Validation Class Initialized
INFO - 2024-02-08 12:12:45 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:12:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 12:25:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:25:56 --> Config Class Initialized
INFO - 2024-02-08 12:25:56 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:25:56 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:25:56 --> Utf8 Class Initialized
INFO - 2024-02-08 12:25:56 --> URI Class Initialized
INFO - 2024-02-08 12:25:56 --> Router Class Initialized
INFO - 2024-02-08 12:25:56 --> Output Class Initialized
INFO - 2024-02-08 12:25:56 --> Security Class Initialized
DEBUG - 2024-02-08 12:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:25:56 --> Input Class Initialized
INFO - 2024-02-08 12:25:56 --> Language Class Initialized
INFO - 2024-02-08 12:25:56 --> Loader Class Initialized
INFO - 2024-02-08 12:25:56 --> Helper loaded: url_helper
INFO - 2024-02-08 12:25:56 --> Helper loaded: file_helper
INFO - 2024-02-08 12:25:56 --> Helper loaded: form_helper
INFO - 2024-02-08 12:25:56 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:25:56 --> Controller Class Initialized
INFO - 2024-02-08 12:25:56 --> Model "LoginModel" initialized
INFO - 2024-02-08 12:25:56 --> Form Validation Class Initialized
ERROR - 2024-02-08 12:25:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:25:56 --> Config Class Initialized
INFO - 2024-02-08 12:25:56 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:25:56 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:25:56 --> Utf8 Class Initialized
INFO - 2024-02-08 12:25:56 --> URI Class Initialized
INFO - 2024-02-08 12:25:56 --> Router Class Initialized
INFO - 2024-02-08 12:25:56 --> Output Class Initialized
INFO - 2024-02-08 12:25:56 --> Security Class Initialized
DEBUG - 2024-02-08 12:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:25:56 --> Input Class Initialized
INFO - 2024-02-08 12:25:56 --> Language Class Initialized
INFO - 2024-02-08 12:25:56 --> Loader Class Initialized
INFO - 2024-02-08 12:25:56 --> Helper loaded: url_helper
INFO - 2024-02-08 12:25:56 --> Helper loaded: file_helper
INFO - 2024-02-08 12:25:56 --> Helper loaded: form_helper
INFO - 2024-02-08 12:25:56 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:25:56 --> Controller Class Initialized
INFO - 2024-02-08 12:25:56 --> Form Validation Class Initialized
INFO - 2024-02-08 12:25:56 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:25:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 12:25:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 12:25:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 12:25:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 12:25:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 12:25:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 12:25:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 12:25:56 --> Final output sent to browser
DEBUG - 2024-02-08 12:25:56 --> Total execution time: 0.0241
ERROR - 2024-02-08 12:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:26:06 --> Config Class Initialized
INFO - 2024-02-08 12:26:06 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:26:06 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:26:06 --> Utf8 Class Initialized
INFO - 2024-02-08 12:26:06 --> URI Class Initialized
INFO - 2024-02-08 12:26:06 --> Router Class Initialized
INFO - 2024-02-08 12:26:06 --> Output Class Initialized
INFO - 2024-02-08 12:26:06 --> Security Class Initialized
DEBUG - 2024-02-08 12:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:26:06 --> Input Class Initialized
INFO - 2024-02-08 12:26:06 --> Language Class Initialized
INFO - 2024-02-08 12:26:06 --> Loader Class Initialized
INFO - 2024-02-08 12:26:06 --> Helper loaded: url_helper
INFO - 2024-02-08 12:26:06 --> Helper loaded: file_helper
INFO - 2024-02-08 12:26:06 --> Helper loaded: form_helper
INFO - 2024-02-08 12:26:06 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:26:06 --> Controller Class Initialized
INFO - 2024-02-08 12:26:06 --> Form Validation Class Initialized
INFO - 2024-02-08 12:26:06 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:26:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 12:26:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 12:26:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 12:26:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 12:26:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 12:26:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 12:26:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 12:26:06 --> Final output sent to browser
DEBUG - 2024-02-08 12:26:06 --> Total execution time: 0.0319
ERROR - 2024-02-08 12:26:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:26:45 --> Config Class Initialized
INFO - 2024-02-08 12:26:45 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:26:45 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:26:45 --> Utf8 Class Initialized
INFO - 2024-02-08 12:26:45 --> URI Class Initialized
INFO - 2024-02-08 12:26:45 --> Router Class Initialized
INFO - 2024-02-08 12:26:45 --> Output Class Initialized
INFO - 2024-02-08 12:26:45 --> Security Class Initialized
DEBUG - 2024-02-08 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:26:45 --> Input Class Initialized
INFO - 2024-02-08 12:26:45 --> Language Class Initialized
INFO - 2024-02-08 12:26:45 --> Loader Class Initialized
INFO - 2024-02-08 12:26:45 --> Helper loaded: url_helper
INFO - 2024-02-08 12:26:45 --> Helper loaded: file_helper
INFO - 2024-02-08 12:26:45 --> Helper loaded: form_helper
INFO - 2024-02-08 12:26:45 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:26:45 --> Controller Class Initialized
INFO - 2024-02-08 12:26:45 --> Form Validation Class Initialized
INFO - 2024-02-08 12:26:45 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:26:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 12:26:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 12:26:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 12:26:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 12:26:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 12:26:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 12:26:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 12:26:45 --> Final output sent to browser
DEBUG - 2024-02-08 12:26:45 --> Total execution time: 0.0247
ERROR - 2024-02-08 12:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:26:46 --> Config Class Initialized
INFO - 2024-02-08 12:26:46 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:26:46 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:26:46 --> Utf8 Class Initialized
INFO - 2024-02-08 12:26:46 --> URI Class Initialized
INFO - 2024-02-08 12:26:46 --> Router Class Initialized
INFO - 2024-02-08 12:26:46 --> Output Class Initialized
INFO - 2024-02-08 12:26:46 --> Security Class Initialized
DEBUG - 2024-02-08 12:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:26:46 --> Input Class Initialized
INFO - 2024-02-08 12:26:46 --> Language Class Initialized
INFO - 2024-02-08 12:26:46 --> Loader Class Initialized
INFO - 2024-02-08 12:26:46 --> Helper loaded: url_helper
INFO - 2024-02-08 12:26:46 --> Helper loaded: file_helper
INFO - 2024-02-08 12:26:46 --> Helper loaded: form_helper
INFO - 2024-02-08 12:26:46 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:26:46 --> Controller Class Initialized
INFO - 2024-02-08 12:26:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-08 12:26:46 --> Final output sent to browser
DEBUG - 2024-02-08 12:26:46 --> Total execution time: 0.0361
ERROR - 2024-02-08 12:28:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:28:35 --> Config Class Initialized
INFO - 2024-02-08 12:28:35 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:28:35 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:28:35 --> Utf8 Class Initialized
INFO - 2024-02-08 12:28:35 --> URI Class Initialized
INFO - 2024-02-08 12:28:35 --> Router Class Initialized
INFO - 2024-02-08 12:28:35 --> Output Class Initialized
INFO - 2024-02-08 12:28:35 --> Security Class Initialized
DEBUG - 2024-02-08 12:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:28:35 --> Input Class Initialized
INFO - 2024-02-08 12:28:35 --> Language Class Initialized
INFO - 2024-02-08 12:28:35 --> Loader Class Initialized
INFO - 2024-02-08 12:28:35 --> Helper loaded: url_helper
INFO - 2024-02-08 12:28:35 --> Helper loaded: file_helper
INFO - 2024-02-08 12:28:35 --> Helper loaded: form_helper
INFO - 2024-02-08 12:28:35 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:28:35 --> Controller Class Initialized
INFO - 2024-02-08 12:28:35 --> Form Validation Class Initialized
INFO - 2024-02-08 12:28:35 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:28:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 12:28:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 12:28:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 12:28:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 12:28:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 12:28:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 12:28:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 12:28:35 --> Final output sent to browser
DEBUG - 2024-02-08 12:28:35 --> Total execution time: 0.0307
ERROR - 2024-02-08 12:28:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:28:36 --> Config Class Initialized
INFO - 2024-02-08 12:28:36 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:28:36 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:28:36 --> Utf8 Class Initialized
INFO - 2024-02-08 12:28:36 --> URI Class Initialized
INFO - 2024-02-08 12:28:36 --> Router Class Initialized
INFO - 2024-02-08 12:28:36 --> Output Class Initialized
INFO - 2024-02-08 12:28:36 --> Security Class Initialized
DEBUG - 2024-02-08 12:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:28:36 --> Input Class Initialized
INFO - 2024-02-08 12:28:36 --> Language Class Initialized
INFO - 2024-02-08 12:28:36 --> Loader Class Initialized
INFO - 2024-02-08 12:28:36 --> Helper loaded: url_helper
INFO - 2024-02-08 12:28:36 --> Helper loaded: file_helper
INFO - 2024-02-08 12:28:36 --> Helper loaded: form_helper
INFO - 2024-02-08 12:28:36 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:28:36 --> Controller Class Initialized
INFO - 2024-02-08 12:28:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-08 12:28:36 --> Final output sent to browser
DEBUG - 2024-02-08 12:28:36 --> Total execution time: 0.0339
ERROR - 2024-02-08 12:29:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:29:13 --> Config Class Initialized
INFO - 2024-02-08 12:29:13 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:29:13 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:29:13 --> Utf8 Class Initialized
INFO - 2024-02-08 12:29:13 --> URI Class Initialized
INFO - 2024-02-08 12:29:13 --> Router Class Initialized
INFO - 2024-02-08 12:29:13 --> Output Class Initialized
INFO - 2024-02-08 12:29:13 --> Security Class Initialized
DEBUG - 2024-02-08 12:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:29:13 --> Input Class Initialized
INFO - 2024-02-08 12:29:13 --> Language Class Initialized
INFO - 2024-02-08 12:29:13 --> Loader Class Initialized
INFO - 2024-02-08 12:29:13 --> Helper loaded: url_helper
INFO - 2024-02-08 12:29:13 --> Helper loaded: file_helper
INFO - 2024-02-08 12:29:13 --> Helper loaded: form_helper
INFO - 2024-02-08 12:29:13 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:29:13 --> Controller Class Initialized
INFO - 2024-02-08 12:29:13 --> Form Validation Class Initialized
INFO - 2024-02-08 12:29:13 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:29:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 12:29:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 12:29:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 12:29:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 12:29:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 12:29:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 12:29:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 12:29:13 --> Final output sent to browser
DEBUG - 2024-02-08 12:29:13 --> Total execution time: 0.0281
ERROR - 2024-02-08 12:34:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:34:31 --> Config Class Initialized
INFO - 2024-02-08 12:34:31 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:34:31 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:34:31 --> Utf8 Class Initialized
INFO - 2024-02-08 12:34:31 --> URI Class Initialized
INFO - 2024-02-08 12:34:31 --> Router Class Initialized
INFO - 2024-02-08 12:34:31 --> Output Class Initialized
INFO - 2024-02-08 12:34:31 --> Security Class Initialized
DEBUG - 2024-02-08 12:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:34:31 --> Input Class Initialized
INFO - 2024-02-08 12:34:31 --> Language Class Initialized
INFO - 2024-02-08 12:34:31 --> Loader Class Initialized
INFO - 2024-02-08 12:34:31 --> Helper loaded: url_helper
INFO - 2024-02-08 12:34:31 --> Helper loaded: file_helper
INFO - 2024-02-08 12:34:31 --> Helper loaded: form_helper
INFO - 2024-02-08 12:34:31 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:34:31 --> Controller Class Initialized
INFO - 2024-02-08 12:34:31 --> Form Validation Class Initialized
INFO - 2024-02-08 12:34:31 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:34:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 12:34:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 12:34:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 12:34:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 12:34:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 12:34:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 12:34:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 12:34:31 --> Final output sent to browser
DEBUG - 2024-02-08 12:34:31 --> Total execution time: 0.0237
ERROR - 2024-02-08 12:37:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 12:37:27 --> Config Class Initialized
INFO - 2024-02-08 12:37:27 --> Hooks Class Initialized
DEBUG - 2024-02-08 12:37:27 --> UTF-8 Support Enabled
INFO - 2024-02-08 12:37:27 --> Utf8 Class Initialized
INFO - 2024-02-08 12:37:27 --> URI Class Initialized
INFO - 2024-02-08 12:37:27 --> Router Class Initialized
INFO - 2024-02-08 12:37:27 --> Output Class Initialized
INFO - 2024-02-08 12:37:27 --> Security Class Initialized
DEBUG - 2024-02-08 12:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 12:37:27 --> Input Class Initialized
INFO - 2024-02-08 12:37:27 --> Language Class Initialized
INFO - 2024-02-08 12:37:27 --> Loader Class Initialized
INFO - 2024-02-08 12:37:27 --> Helper loaded: url_helper
INFO - 2024-02-08 12:37:27 --> Helper loaded: file_helper
INFO - 2024-02-08 12:37:27 --> Helper loaded: form_helper
INFO - 2024-02-08 12:37:27 --> Database Driver Class Initialized
DEBUG - 2024-02-08 12:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 12:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 12:37:27 --> Controller Class Initialized
INFO - 2024-02-08 12:37:27 --> Form Validation Class Initialized
INFO - 2024-02-08 12:37:27 --> Model "MasterModel" initialized
INFO - 2024-02-08 12:37:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 12:37:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 12:37:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 12:37:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 12:37:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 12:37:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 12:37:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 12:37:27 --> Final output sent to browser
DEBUG - 2024-02-08 12:37:27 --> Total execution time: 0.0320
ERROR - 2024-02-08 17:01:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:01:45 --> Config Class Initialized
INFO - 2024-02-08 17:01:45 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:01:45 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:01:45 --> Utf8 Class Initialized
INFO - 2024-02-08 17:01:45 --> URI Class Initialized
INFO - 2024-02-08 17:01:45 --> Router Class Initialized
INFO - 2024-02-08 17:01:45 --> Output Class Initialized
INFO - 2024-02-08 17:01:45 --> Security Class Initialized
DEBUG - 2024-02-08 17:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:01:45 --> Input Class Initialized
INFO - 2024-02-08 17:01:45 --> Language Class Initialized
INFO - 2024-02-08 17:01:45 --> Loader Class Initialized
INFO - 2024-02-08 17:01:45 --> Helper loaded: url_helper
INFO - 2024-02-08 17:01:45 --> Helper loaded: file_helper
INFO - 2024-02-08 17:01:45 --> Helper loaded: form_helper
INFO - 2024-02-08 17:01:45 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:01:45 --> Controller Class Initialized
INFO - 2024-02-08 17:01:45 --> Model "LoginModel" initialized
INFO - 2024-02-08 17:01:45 --> Form Validation Class Initialized
ERROR - 2024-02-08 17:01:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:01:45 --> Config Class Initialized
INFO - 2024-02-08 17:01:45 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:01:45 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:01:45 --> Utf8 Class Initialized
INFO - 2024-02-08 17:01:45 --> URI Class Initialized
INFO - 2024-02-08 17:01:45 --> Router Class Initialized
INFO - 2024-02-08 17:01:45 --> Output Class Initialized
INFO - 2024-02-08 17:01:45 --> Security Class Initialized
DEBUG - 2024-02-08 17:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:01:45 --> Input Class Initialized
INFO - 2024-02-08 17:01:45 --> Language Class Initialized
INFO - 2024-02-08 17:01:45 --> Loader Class Initialized
INFO - 2024-02-08 17:01:45 --> Helper loaded: url_helper
INFO - 2024-02-08 17:01:45 --> Helper loaded: file_helper
INFO - 2024-02-08 17:01:45 --> Helper loaded: form_helper
INFO - 2024-02-08 17:01:45 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:01:45 --> Controller Class Initialized
INFO - 2024-02-08 17:01:45 --> Form Validation Class Initialized
INFO - 2024-02-08 17:01:45 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:01:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:01:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:01:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 17:01:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:01:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:01:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:01:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 17:01:45 --> Final output sent to browser
DEBUG - 2024-02-08 17:01:45 --> Total execution time: 0.0212
ERROR - 2024-02-08 17:01:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:01:48 --> Config Class Initialized
INFO - 2024-02-08 17:01:48 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:01:48 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:01:48 --> Utf8 Class Initialized
INFO - 2024-02-08 17:01:48 --> URI Class Initialized
INFO - 2024-02-08 17:01:48 --> Router Class Initialized
INFO - 2024-02-08 17:01:48 --> Output Class Initialized
INFO - 2024-02-08 17:01:48 --> Security Class Initialized
DEBUG - 2024-02-08 17:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:01:48 --> Input Class Initialized
INFO - 2024-02-08 17:01:48 --> Language Class Initialized
INFO - 2024-02-08 17:01:48 --> Loader Class Initialized
INFO - 2024-02-08 17:01:48 --> Helper loaded: url_helper
INFO - 2024-02-08 17:01:48 --> Helper loaded: file_helper
INFO - 2024-02-08 17:01:48 --> Helper loaded: form_helper
INFO - 2024-02-08 17:01:48 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:01:48 --> Controller Class Initialized
INFO - 2024-02-08 17:01:48 --> Form Validation Class Initialized
INFO - 2024-02-08 17:01:48 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:01:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:01:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:01:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:01:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:01:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:01:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:01:48 --> Final output sent to browser
DEBUG - 2024-02-08 17:01:48 --> Total execution time: 0.0259
ERROR - 2024-02-08 17:01:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:01:49 --> Config Class Initialized
INFO - 2024-02-08 17:01:49 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:01:49 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:01:49 --> Utf8 Class Initialized
INFO - 2024-02-08 17:01:49 --> URI Class Initialized
INFO - 2024-02-08 17:01:49 --> Router Class Initialized
INFO - 2024-02-08 17:01:49 --> Output Class Initialized
INFO - 2024-02-08 17:01:49 --> Security Class Initialized
DEBUG - 2024-02-08 17:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:01:49 --> Input Class Initialized
INFO - 2024-02-08 17:01:49 --> Language Class Initialized
INFO - 2024-02-08 17:01:49 --> Loader Class Initialized
INFO - 2024-02-08 17:01:49 --> Helper loaded: url_helper
INFO - 2024-02-08 17:01:49 --> Helper loaded: file_helper
INFO - 2024-02-08 17:01:49 --> Helper loaded: form_helper
INFO - 2024-02-08 17:01:49 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:01:49 --> Controller Class Initialized
INFO - 2024-02-08 17:01:49 --> Form Validation Class Initialized
INFO - 2024-02-08 17:01:49 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:01:49 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:01:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:01:53 --> Config Class Initialized
INFO - 2024-02-08 17:01:53 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:01:53 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:01:53 --> Utf8 Class Initialized
INFO - 2024-02-08 17:01:53 --> URI Class Initialized
INFO - 2024-02-08 17:01:53 --> Router Class Initialized
INFO - 2024-02-08 17:01:53 --> Output Class Initialized
INFO - 2024-02-08 17:01:53 --> Security Class Initialized
DEBUG - 2024-02-08 17:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:01:53 --> Input Class Initialized
INFO - 2024-02-08 17:01:53 --> Language Class Initialized
INFO - 2024-02-08 17:01:53 --> Loader Class Initialized
INFO - 2024-02-08 17:01:53 --> Helper loaded: url_helper
INFO - 2024-02-08 17:01:53 --> Helper loaded: file_helper
INFO - 2024-02-08 17:01:53 --> Helper loaded: form_helper
INFO - 2024-02-08 17:01:53 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:01:53 --> Controller Class Initialized
INFO - 2024-02-08 17:01:53 --> Form Validation Class Initialized
INFO - 2024-02-08 17:01:53 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:01:53 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:01:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:01:53 --> Config Class Initialized
INFO - 2024-02-08 17:01:53 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:01:53 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:01:53 --> Utf8 Class Initialized
INFO - 2024-02-08 17:01:53 --> URI Class Initialized
INFO - 2024-02-08 17:01:53 --> Router Class Initialized
INFO - 2024-02-08 17:01:53 --> Output Class Initialized
INFO - 2024-02-08 17:01:53 --> Security Class Initialized
DEBUG - 2024-02-08 17:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:01:53 --> Input Class Initialized
INFO - 2024-02-08 17:01:53 --> Language Class Initialized
INFO - 2024-02-08 17:01:53 --> Loader Class Initialized
INFO - 2024-02-08 17:01:53 --> Helper loaded: url_helper
INFO - 2024-02-08 17:01:53 --> Helper loaded: file_helper
INFO - 2024-02-08 17:01:53 --> Helper loaded: form_helper
INFO - 2024-02-08 17:01:53 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:01:53 --> Controller Class Initialized
INFO - 2024-02-08 17:01:53 --> Form Validation Class Initialized
INFO - 2024-02-08 17:01:53 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:01:53 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:01:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:01:54 --> Config Class Initialized
INFO - 2024-02-08 17:01:54 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:01:54 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:01:54 --> Utf8 Class Initialized
INFO - 2024-02-08 17:01:54 --> URI Class Initialized
INFO - 2024-02-08 17:01:54 --> Router Class Initialized
INFO - 2024-02-08 17:01:54 --> Output Class Initialized
INFO - 2024-02-08 17:01:54 --> Security Class Initialized
DEBUG - 2024-02-08 17:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:01:54 --> Input Class Initialized
INFO - 2024-02-08 17:01:54 --> Language Class Initialized
INFO - 2024-02-08 17:01:54 --> Loader Class Initialized
INFO - 2024-02-08 17:01:54 --> Helper loaded: url_helper
INFO - 2024-02-08 17:01:54 --> Helper loaded: file_helper
INFO - 2024-02-08 17:01:54 --> Helper loaded: form_helper
INFO - 2024-02-08 17:01:54 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:01:54 --> Controller Class Initialized
INFO - 2024-02-08 17:01:54 --> Form Validation Class Initialized
INFO - 2024-02-08 17:01:54 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:01:54 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:01:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:01:54 --> Config Class Initialized
INFO - 2024-02-08 17:01:54 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:01:54 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:01:54 --> Utf8 Class Initialized
INFO - 2024-02-08 17:01:54 --> URI Class Initialized
INFO - 2024-02-08 17:01:54 --> Router Class Initialized
INFO - 2024-02-08 17:01:54 --> Output Class Initialized
INFO - 2024-02-08 17:01:54 --> Security Class Initialized
DEBUG - 2024-02-08 17:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:01:54 --> Input Class Initialized
INFO - 2024-02-08 17:01:54 --> Language Class Initialized
INFO - 2024-02-08 17:01:54 --> Loader Class Initialized
INFO - 2024-02-08 17:01:54 --> Helper loaded: url_helper
INFO - 2024-02-08 17:01:54 --> Helper loaded: file_helper
INFO - 2024-02-08 17:01:54 --> Helper loaded: form_helper
INFO - 2024-02-08 17:01:54 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:01:54 --> Controller Class Initialized
INFO - 2024-02-08 17:01:54 --> Form Validation Class Initialized
INFO - 2024-02-08 17:01:54 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:01:54 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:01:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:01:54 --> Config Class Initialized
INFO - 2024-02-08 17:01:54 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:01:54 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:01:54 --> Utf8 Class Initialized
INFO - 2024-02-08 17:01:54 --> URI Class Initialized
INFO - 2024-02-08 17:01:54 --> Router Class Initialized
INFO - 2024-02-08 17:01:54 --> Output Class Initialized
INFO - 2024-02-08 17:01:54 --> Security Class Initialized
DEBUG - 2024-02-08 17:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:01:54 --> Input Class Initialized
INFO - 2024-02-08 17:01:54 --> Language Class Initialized
INFO - 2024-02-08 17:01:54 --> Loader Class Initialized
INFO - 2024-02-08 17:01:54 --> Helper loaded: url_helper
INFO - 2024-02-08 17:01:54 --> Helper loaded: file_helper
INFO - 2024-02-08 17:01:54 --> Helper loaded: form_helper
INFO - 2024-02-08 17:01:54 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:01:54 --> Controller Class Initialized
INFO - 2024-02-08 17:01:54 --> Form Validation Class Initialized
INFO - 2024-02-08 17:01:54 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:01:54 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:01:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:01:56 --> Config Class Initialized
INFO - 2024-02-08 17:01:56 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:01:56 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:01:56 --> Utf8 Class Initialized
INFO - 2024-02-08 17:01:56 --> URI Class Initialized
INFO - 2024-02-08 17:01:56 --> Router Class Initialized
INFO - 2024-02-08 17:01:56 --> Output Class Initialized
INFO - 2024-02-08 17:01:56 --> Security Class Initialized
DEBUG - 2024-02-08 17:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:01:56 --> Input Class Initialized
INFO - 2024-02-08 17:01:56 --> Language Class Initialized
INFO - 2024-02-08 17:01:56 --> Loader Class Initialized
INFO - 2024-02-08 17:01:56 --> Helper loaded: url_helper
INFO - 2024-02-08 17:01:56 --> Helper loaded: file_helper
INFO - 2024-02-08 17:01:56 --> Helper loaded: form_helper
INFO - 2024-02-08 17:01:56 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:01:56 --> Controller Class Initialized
INFO - 2024-02-08 17:01:56 --> Form Validation Class Initialized
INFO - 2024-02-08 17:01:56 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:01:56 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:01:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:01:58 --> Config Class Initialized
INFO - 2024-02-08 17:01:58 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:01:58 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:01:58 --> Utf8 Class Initialized
INFO - 2024-02-08 17:01:58 --> URI Class Initialized
INFO - 2024-02-08 17:01:58 --> Router Class Initialized
INFO - 2024-02-08 17:01:58 --> Output Class Initialized
INFO - 2024-02-08 17:01:58 --> Security Class Initialized
DEBUG - 2024-02-08 17:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:01:58 --> Input Class Initialized
INFO - 2024-02-08 17:01:58 --> Language Class Initialized
INFO - 2024-02-08 17:01:58 --> Loader Class Initialized
INFO - 2024-02-08 17:01:58 --> Helper loaded: url_helper
INFO - 2024-02-08 17:01:58 --> Helper loaded: file_helper
INFO - 2024-02-08 17:01:58 --> Helper loaded: form_helper
INFO - 2024-02-08 17:01:58 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:01:58 --> Controller Class Initialized
INFO - 2024-02-08 17:01:58 --> Form Validation Class Initialized
INFO - 2024-02-08 17:01:58 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:01:58 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:01:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:01:58 --> Config Class Initialized
INFO - 2024-02-08 17:01:58 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:01:58 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:01:58 --> Utf8 Class Initialized
INFO - 2024-02-08 17:01:58 --> URI Class Initialized
INFO - 2024-02-08 17:01:58 --> Router Class Initialized
INFO - 2024-02-08 17:01:58 --> Output Class Initialized
INFO - 2024-02-08 17:01:58 --> Security Class Initialized
DEBUG - 2024-02-08 17:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:01:58 --> Input Class Initialized
INFO - 2024-02-08 17:01:58 --> Language Class Initialized
INFO - 2024-02-08 17:01:58 --> Loader Class Initialized
INFO - 2024-02-08 17:01:58 --> Helper loaded: url_helper
INFO - 2024-02-08 17:01:58 --> Helper loaded: file_helper
INFO - 2024-02-08 17:01:58 --> Helper loaded: form_helper
INFO - 2024-02-08 17:01:58 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:01:58 --> Controller Class Initialized
INFO - 2024-02-08 17:01:58 --> Form Validation Class Initialized
INFO - 2024-02-08 17:01:58 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:01:58 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:02:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:02:00 --> Config Class Initialized
INFO - 2024-02-08 17:02:00 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:02:00 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:02:00 --> Utf8 Class Initialized
INFO - 2024-02-08 17:02:00 --> URI Class Initialized
INFO - 2024-02-08 17:02:00 --> Router Class Initialized
INFO - 2024-02-08 17:02:00 --> Output Class Initialized
INFO - 2024-02-08 17:02:00 --> Security Class Initialized
DEBUG - 2024-02-08 17:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:02:00 --> Input Class Initialized
INFO - 2024-02-08 17:02:00 --> Language Class Initialized
INFO - 2024-02-08 17:02:00 --> Loader Class Initialized
INFO - 2024-02-08 17:02:00 --> Helper loaded: url_helper
INFO - 2024-02-08 17:02:00 --> Helper loaded: file_helper
INFO - 2024-02-08 17:02:00 --> Helper loaded: form_helper
INFO - 2024-02-08 17:02:00 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:02:00 --> Controller Class Initialized
INFO - 2024-02-08 17:02:00 --> Form Validation Class Initialized
INFO - 2024-02-08 17:02:00 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:02:00 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:02:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:02:00 --> Config Class Initialized
INFO - 2024-02-08 17:02:00 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:02:00 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:02:00 --> Utf8 Class Initialized
INFO - 2024-02-08 17:02:00 --> URI Class Initialized
INFO - 2024-02-08 17:02:00 --> Router Class Initialized
INFO - 2024-02-08 17:02:00 --> Output Class Initialized
INFO - 2024-02-08 17:02:00 --> Security Class Initialized
DEBUG - 2024-02-08 17:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:02:00 --> Input Class Initialized
INFO - 2024-02-08 17:02:00 --> Language Class Initialized
INFO - 2024-02-08 17:02:00 --> Loader Class Initialized
INFO - 2024-02-08 17:02:00 --> Helper loaded: url_helper
INFO - 2024-02-08 17:02:00 --> Helper loaded: file_helper
INFO - 2024-02-08 17:02:00 --> Helper loaded: form_helper
INFO - 2024-02-08 17:02:00 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:02:00 --> Controller Class Initialized
INFO - 2024-02-08 17:02:00 --> Form Validation Class Initialized
INFO - 2024-02-08 17:02:00 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:02:00 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:02:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:02:06 --> Config Class Initialized
INFO - 2024-02-08 17:02:06 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:02:06 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:02:06 --> Utf8 Class Initialized
INFO - 2024-02-08 17:02:06 --> URI Class Initialized
INFO - 2024-02-08 17:02:06 --> Router Class Initialized
INFO - 2024-02-08 17:02:06 --> Output Class Initialized
INFO - 2024-02-08 17:02:06 --> Security Class Initialized
DEBUG - 2024-02-08 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:02:06 --> Input Class Initialized
INFO - 2024-02-08 17:02:06 --> Language Class Initialized
INFO - 2024-02-08 17:02:06 --> Loader Class Initialized
INFO - 2024-02-08 17:02:06 --> Helper loaded: url_helper
INFO - 2024-02-08 17:02:06 --> Helper loaded: file_helper
INFO - 2024-02-08 17:02:06 --> Helper loaded: form_helper
INFO - 2024-02-08 17:02:06 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:02:06 --> Controller Class Initialized
INFO - 2024-02-08 17:02:06 --> Form Validation Class Initialized
INFO - 2024-02-08 17:02:06 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:02:06 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:02:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:02:12 --> Config Class Initialized
INFO - 2024-02-08 17:02:12 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:02:12 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:02:12 --> Utf8 Class Initialized
INFO - 2024-02-08 17:02:12 --> URI Class Initialized
INFO - 2024-02-08 17:02:12 --> Router Class Initialized
INFO - 2024-02-08 17:02:12 --> Output Class Initialized
INFO - 2024-02-08 17:02:12 --> Security Class Initialized
DEBUG - 2024-02-08 17:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:02:12 --> Input Class Initialized
INFO - 2024-02-08 17:02:12 --> Language Class Initialized
INFO - 2024-02-08 17:02:12 --> Loader Class Initialized
INFO - 2024-02-08 17:02:12 --> Helper loaded: url_helper
INFO - 2024-02-08 17:02:12 --> Helper loaded: file_helper
INFO - 2024-02-08 17:02:12 --> Helper loaded: form_helper
INFO - 2024-02-08 17:02:12 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:02:12 --> Controller Class Initialized
INFO - 2024-02-08 17:02:12 --> Form Validation Class Initialized
INFO - 2024-02-08 17:02:12 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:02:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:02:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:02:18 --> Config Class Initialized
INFO - 2024-02-08 17:02:18 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:02:18 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:02:18 --> Utf8 Class Initialized
INFO - 2024-02-08 17:02:18 --> URI Class Initialized
INFO - 2024-02-08 17:02:18 --> Router Class Initialized
INFO - 2024-02-08 17:02:18 --> Output Class Initialized
INFO - 2024-02-08 17:02:18 --> Security Class Initialized
DEBUG - 2024-02-08 17:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:02:18 --> Input Class Initialized
INFO - 2024-02-08 17:02:18 --> Language Class Initialized
INFO - 2024-02-08 17:02:18 --> Loader Class Initialized
INFO - 2024-02-08 17:02:18 --> Helper loaded: url_helper
INFO - 2024-02-08 17:02:19 --> Helper loaded: file_helper
INFO - 2024-02-08 17:02:19 --> Helper loaded: form_helper
INFO - 2024-02-08 17:02:19 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:02:19 --> Controller Class Initialized
INFO - 2024-02-08 17:02:19 --> Form Validation Class Initialized
INFO - 2024-02-08 17:02:19 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:02:19 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:02:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:02:21 --> Config Class Initialized
INFO - 2024-02-08 17:02:21 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:02:21 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:02:21 --> Utf8 Class Initialized
INFO - 2024-02-08 17:02:21 --> URI Class Initialized
INFO - 2024-02-08 17:02:21 --> Router Class Initialized
INFO - 2024-02-08 17:02:21 --> Output Class Initialized
INFO - 2024-02-08 17:02:21 --> Security Class Initialized
DEBUG - 2024-02-08 17:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:02:21 --> Input Class Initialized
INFO - 2024-02-08 17:02:21 --> Language Class Initialized
INFO - 2024-02-08 17:02:21 --> Loader Class Initialized
INFO - 2024-02-08 17:02:21 --> Helper loaded: url_helper
INFO - 2024-02-08 17:02:21 --> Helper loaded: file_helper
INFO - 2024-02-08 17:02:21 --> Helper loaded: form_helper
INFO - 2024-02-08 17:02:21 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:02:21 --> Controller Class Initialized
INFO - 2024-02-08 17:02:21 --> Form Validation Class Initialized
INFO - 2024-02-08 17:02:21 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:02:21 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:02:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:02:27 --> Config Class Initialized
INFO - 2024-02-08 17:02:27 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:02:27 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:02:27 --> Utf8 Class Initialized
INFO - 2024-02-08 17:02:27 --> URI Class Initialized
INFO - 2024-02-08 17:02:27 --> Router Class Initialized
INFO - 2024-02-08 17:02:27 --> Output Class Initialized
INFO - 2024-02-08 17:02:27 --> Security Class Initialized
DEBUG - 2024-02-08 17:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:02:27 --> Input Class Initialized
INFO - 2024-02-08 17:02:27 --> Language Class Initialized
INFO - 2024-02-08 17:02:27 --> Loader Class Initialized
INFO - 2024-02-08 17:02:27 --> Helper loaded: url_helper
INFO - 2024-02-08 17:02:27 --> Helper loaded: file_helper
INFO - 2024-02-08 17:02:27 --> Helper loaded: form_helper
INFO - 2024-02-08 17:02:27 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:02:27 --> Controller Class Initialized
INFO - 2024-02-08 17:02:27 --> Form Validation Class Initialized
INFO - 2024-02-08 17:02:27 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:02:27 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:02:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:02:31 --> Config Class Initialized
INFO - 2024-02-08 17:02:31 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:02:31 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:02:31 --> Utf8 Class Initialized
INFO - 2024-02-08 17:02:31 --> URI Class Initialized
INFO - 2024-02-08 17:02:31 --> Router Class Initialized
INFO - 2024-02-08 17:02:31 --> Output Class Initialized
INFO - 2024-02-08 17:02:31 --> Security Class Initialized
DEBUG - 2024-02-08 17:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:02:31 --> Input Class Initialized
INFO - 2024-02-08 17:02:31 --> Language Class Initialized
INFO - 2024-02-08 17:02:31 --> Loader Class Initialized
INFO - 2024-02-08 17:02:31 --> Helper loaded: url_helper
INFO - 2024-02-08 17:02:31 --> Helper loaded: file_helper
INFO - 2024-02-08 17:02:31 --> Helper loaded: form_helper
INFO - 2024-02-08 17:02:31 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:02:31 --> Controller Class Initialized
INFO - 2024-02-08 17:02:31 --> Form Validation Class Initialized
INFO - 2024-02-08 17:02:31 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:02:31 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:02:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:02:40 --> Config Class Initialized
INFO - 2024-02-08 17:02:40 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:02:40 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:02:40 --> Utf8 Class Initialized
INFO - 2024-02-08 17:02:40 --> URI Class Initialized
INFO - 2024-02-08 17:02:40 --> Router Class Initialized
INFO - 2024-02-08 17:02:40 --> Output Class Initialized
INFO - 2024-02-08 17:02:40 --> Security Class Initialized
DEBUG - 2024-02-08 17:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:02:40 --> Input Class Initialized
INFO - 2024-02-08 17:02:40 --> Language Class Initialized
INFO - 2024-02-08 17:02:40 --> Loader Class Initialized
INFO - 2024-02-08 17:02:40 --> Helper loaded: url_helper
INFO - 2024-02-08 17:02:40 --> Helper loaded: file_helper
INFO - 2024-02-08 17:02:40 --> Helper loaded: form_helper
INFO - 2024-02-08 17:02:40 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:02:41 --> Controller Class Initialized
INFO - 2024-02-08 17:02:41 --> Form Validation Class Initialized
INFO - 2024-02-08 17:02:41 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:02:41 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:02:42 --> Config Class Initialized
INFO - 2024-02-08 17:02:42 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:02:42 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:02:42 --> Utf8 Class Initialized
INFO - 2024-02-08 17:02:42 --> URI Class Initialized
INFO - 2024-02-08 17:02:42 --> Router Class Initialized
INFO - 2024-02-08 17:02:42 --> Output Class Initialized
INFO - 2024-02-08 17:02:42 --> Security Class Initialized
DEBUG - 2024-02-08 17:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:02:42 --> Input Class Initialized
INFO - 2024-02-08 17:02:42 --> Language Class Initialized
INFO - 2024-02-08 17:02:42 --> Loader Class Initialized
INFO - 2024-02-08 17:02:42 --> Helper loaded: url_helper
INFO - 2024-02-08 17:02:42 --> Helper loaded: file_helper
INFO - 2024-02-08 17:02:42 --> Helper loaded: form_helper
INFO - 2024-02-08 17:02:42 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:02:43 --> Controller Class Initialized
INFO - 2024-02-08 17:02:43 --> Form Validation Class Initialized
INFO - 2024-02-08 17:02:43 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:02:43 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:02:50 --> Config Class Initialized
INFO - 2024-02-08 17:02:50 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:02:50 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:02:50 --> Utf8 Class Initialized
INFO - 2024-02-08 17:02:50 --> URI Class Initialized
INFO - 2024-02-08 17:02:50 --> Router Class Initialized
INFO - 2024-02-08 17:02:50 --> Output Class Initialized
INFO - 2024-02-08 17:02:50 --> Security Class Initialized
DEBUG - 2024-02-08 17:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:02:50 --> Input Class Initialized
INFO - 2024-02-08 17:02:50 --> Language Class Initialized
INFO - 2024-02-08 17:02:50 --> Loader Class Initialized
INFO - 2024-02-08 17:02:50 --> Helper loaded: url_helper
INFO - 2024-02-08 17:02:50 --> Helper loaded: file_helper
INFO - 2024-02-08 17:02:50 --> Helper loaded: form_helper
INFO - 2024-02-08 17:02:50 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:02:50 --> Controller Class Initialized
INFO - 2024-02-08 17:02:50 --> Form Validation Class Initialized
INFO - 2024-02-08 17:02:50 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:02:50 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:02:52 --> Config Class Initialized
INFO - 2024-02-08 17:02:52 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:02:52 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:02:52 --> Utf8 Class Initialized
INFO - 2024-02-08 17:02:52 --> URI Class Initialized
INFO - 2024-02-08 17:02:52 --> Router Class Initialized
INFO - 2024-02-08 17:02:52 --> Output Class Initialized
INFO - 2024-02-08 17:02:52 --> Security Class Initialized
DEBUG - 2024-02-08 17:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:02:52 --> Input Class Initialized
INFO - 2024-02-08 17:02:52 --> Language Class Initialized
INFO - 2024-02-08 17:02:52 --> Loader Class Initialized
INFO - 2024-02-08 17:02:52 --> Helper loaded: url_helper
INFO - 2024-02-08 17:02:52 --> Helper loaded: file_helper
INFO - 2024-02-08 17:02:52 --> Helper loaded: form_helper
INFO - 2024-02-08 17:02:52 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:02:52 --> Controller Class Initialized
INFO - 2024-02-08 17:02:52 --> Form Validation Class Initialized
INFO - 2024-02-08 17:02:52 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:02:52 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:05:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:05:49 --> Config Class Initialized
INFO - 2024-02-08 17:05:49 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:05:49 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:05:49 --> Utf8 Class Initialized
INFO - 2024-02-08 17:05:49 --> URI Class Initialized
INFO - 2024-02-08 17:05:49 --> Router Class Initialized
INFO - 2024-02-08 17:05:49 --> Output Class Initialized
INFO - 2024-02-08 17:05:49 --> Security Class Initialized
DEBUG - 2024-02-08 17:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:05:49 --> Input Class Initialized
INFO - 2024-02-08 17:05:49 --> Language Class Initialized
INFO - 2024-02-08 17:05:49 --> Loader Class Initialized
INFO - 2024-02-08 17:05:49 --> Helper loaded: url_helper
INFO - 2024-02-08 17:05:49 --> Helper loaded: file_helper
INFO - 2024-02-08 17:05:49 --> Helper loaded: form_helper
INFO - 2024-02-08 17:05:49 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:05:49 --> Controller Class Initialized
ERROR - 2024-02-08 17:09:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:09:11 --> Config Class Initialized
INFO - 2024-02-08 17:09:11 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:09:11 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:09:11 --> Utf8 Class Initialized
INFO - 2024-02-08 17:09:11 --> URI Class Initialized
INFO - 2024-02-08 17:09:11 --> Router Class Initialized
INFO - 2024-02-08 17:09:11 --> Output Class Initialized
INFO - 2024-02-08 17:09:11 --> Security Class Initialized
DEBUG - 2024-02-08 17:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:09:11 --> Input Class Initialized
INFO - 2024-02-08 17:09:11 --> Language Class Initialized
INFO - 2024-02-08 17:09:11 --> Loader Class Initialized
INFO - 2024-02-08 17:09:11 --> Helper loaded: url_helper
INFO - 2024-02-08 17:09:11 --> Helper loaded: file_helper
INFO - 2024-02-08 17:09:11 --> Helper loaded: form_helper
INFO - 2024-02-08 17:09:11 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:09:11 --> Controller Class Initialized
INFO - 2024-02-08 17:09:11 --> Form Validation Class Initialized
INFO - 2024-02-08 17:09:11 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:09:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:09:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:09:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:09:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:09:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:09:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:09:11 --> Final output sent to browser
DEBUG - 2024-02-08 17:09:11 --> Total execution time: 0.0299
ERROR - 2024-02-08 17:09:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:09:12 --> Config Class Initialized
INFO - 2024-02-08 17:09:12 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:09:12 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:09:12 --> Utf8 Class Initialized
INFO - 2024-02-08 17:09:12 --> URI Class Initialized
INFO - 2024-02-08 17:09:12 --> Router Class Initialized
INFO - 2024-02-08 17:09:12 --> Output Class Initialized
INFO - 2024-02-08 17:09:12 --> Security Class Initialized
DEBUG - 2024-02-08 17:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:09:12 --> Input Class Initialized
INFO - 2024-02-08 17:09:12 --> Language Class Initialized
INFO - 2024-02-08 17:09:12 --> Loader Class Initialized
INFO - 2024-02-08 17:09:12 --> Helper loaded: url_helper
INFO - 2024-02-08 17:09:12 --> Helper loaded: file_helper
INFO - 2024-02-08 17:09:12 --> Helper loaded: form_helper
INFO - 2024-02-08 17:09:12 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:09:12 --> Controller Class Initialized
INFO - 2024-02-08 17:09:12 --> Form Validation Class Initialized
INFO - 2024-02-08 17:09:12 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:09:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:09:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:09:14 --> Config Class Initialized
INFO - 2024-02-08 17:09:14 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:09:14 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:09:14 --> Utf8 Class Initialized
INFO - 2024-02-08 17:09:14 --> URI Class Initialized
INFO - 2024-02-08 17:09:14 --> Router Class Initialized
INFO - 2024-02-08 17:09:14 --> Output Class Initialized
INFO - 2024-02-08 17:09:14 --> Security Class Initialized
DEBUG - 2024-02-08 17:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:09:14 --> Input Class Initialized
INFO - 2024-02-08 17:09:14 --> Language Class Initialized
INFO - 2024-02-08 17:09:14 --> Loader Class Initialized
INFO - 2024-02-08 17:09:14 --> Helper loaded: url_helper
INFO - 2024-02-08 17:09:14 --> Helper loaded: file_helper
INFO - 2024-02-08 17:09:14 --> Helper loaded: form_helper
INFO - 2024-02-08 17:09:14 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:09:14 --> Controller Class Initialized
INFO - 2024-02-08 17:09:14 --> Form Validation Class Initialized
INFO - 2024-02-08 17:09:14 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:09:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:09:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-08 17:09:14 --> Final output sent to browser
DEBUG - 2024-02-08 17:09:14 --> Total execution time: 0.0227
ERROR - 2024-02-08 17:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:16:20 --> Config Class Initialized
INFO - 2024-02-08 17:16:20 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:16:20 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:16:20 --> Utf8 Class Initialized
INFO - 2024-02-08 17:16:20 --> URI Class Initialized
INFO - 2024-02-08 17:16:20 --> Router Class Initialized
INFO - 2024-02-08 17:16:20 --> Output Class Initialized
INFO - 2024-02-08 17:16:20 --> Security Class Initialized
DEBUG - 2024-02-08 17:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:16:20 --> Input Class Initialized
INFO - 2024-02-08 17:16:20 --> Language Class Initialized
INFO - 2024-02-08 17:16:20 --> Loader Class Initialized
INFO - 2024-02-08 17:16:20 --> Helper loaded: url_helper
INFO - 2024-02-08 17:16:20 --> Helper loaded: file_helper
INFO - 2024-02-08 17:16:20 --> Helper loaded: form_helper
INFO - 2024-02-08 17:16:20 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:16:20 --> Controller Class Initialized
INFO - 2024-02-08 17:16:20 --> Form Validation Class Initialized
INFO - 2024-02-08 17:16:20 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:16:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:16:20 --> Final output sent to browser
DEBUG - 2024-02-08 17:16:20 --> Total execution time: 0.0323
ERROR - 2024-02-08 17:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:16:21 --> Config Class Initialized
INFO - 2024-02-08 17:16:21 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:16:21 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:16:21 --> Utf8 Class Initialized
INFO - 2024-02-08 17:16:21 --> URI Class Initialized
INFO - 2024-02-08 17:16:21 --> Router Class Initialized
INFO - 2024-02-08 17:16:21 --> Output Class Initialized
INFO - 2024-02-08 17:16:21 --> Security Class Initialized
DEBUG - 2024-02-08 17:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:16:21 --> Input Class Initialized
INFO - 2024-02-08 17:16:21 --> Language Class Initialized
INFO - 2024-02-08 17:16:21 --> Loader Class Initialized
INFO - 2024-02-08 17:16:21 --> Helper loaded: url_helper
INFO - 2024-02-08 17:16:21 --> Helper loaded: file_helper
INFO - 2024-02-08 17:16:21 --> Helper loaded: form_helper
INFO - 2024-02-08 17:16:21 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:16:21 --> Controller Class Initialized
INFO - 2024-02-08 17:16:21 --> Form Validation Class Initialized
INFO - 2024-02-08 17:16:21 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:16:21 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:16:30 --> Config Class Initialized
INFO - 2024-02-08 17:16:30 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:16:30 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:16:30 --> Utf8 Class Initialized
INFO - 2024-02-08 17:16:30 --> URI Class Initialized
INFO - 2024-02-08 17:16:30 --> Router Class Initialized
INFO - 2024-02-08 17:16:30 --> Output Class Initialized
INFO - 2024-02-08 17:16:30 --> Security Class Initialized
DEBUG - 2024-02-08 17:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:16:30 --> Input Class Initialized
INFO - 2024-02-08 17:16:30 --> Language Class Initialized
INFO - 2024-02-08 17:16:30 --> Loader Class Initialized
INFO - 2024-02-08 17:16:30 --> Helper loaded: url_helper
INFO - 2024-02-08 17:16:30 --> Helper loaded: file_helper
INFO - 2024-02-08 17:16:30 --> Helper loaded: form_helper
INFO - 2024-02-08 17:16:30 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:16:30 --> Controller Class Initialized
INFO - 2024-02-08 17:16:30 --> Form Validation Class Initialized
INFO - 2024-02-08 17:16:30 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:16:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:16:30 --> Final output sent to browser
DEBUG - 2024-02-08 17:16:30 --> Total execution time: 0.0335
ERROR - 2024-02-08 17:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:16:30 --> Config Class Initialized
INFO - 2024-02-08 17:16:30 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:16:30 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:16:30 --> Utf8 Class Initialized
INFO - 2024-02-08 17:16:30 --> URI Class Initialized
INFO - 2024-02-08 17:16:30 --> Router Class Initialized
INFO - 2024-02-08 17:16:30 --> Output Class Initialized
INFO - 2024-02-08 17:16:30 --> Security Class Initialized
DEBUG - 2024-02-08 17:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:16:30 --> Input Class Initialized
INFO - 2024-02-08 17:16:30 --> Language Class Initialized
INFO - 2024-02-08 17:16:30 --> Loader Class Initialized
INFO - 2024-02-08 17:16:30 --> Helper loaded: url_helper
INFO - 2024-02-08 17:16:30 --> Helper loaded: file_helper
INFO - 2024-02-08 17:16:30 --> Helper loaded: form_helper
INFO - 2024-02-08 17:16:30 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:16:30 --> Controller Class Initialized
INFO - 2024-02-08 17:16:30 --> Form Validation Class Initialized
INFO - 2024-02-08 17:16:30 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:16:30 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:16:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:16:35 --> Config Class Initialized
INFO - 2024-02-08 17:16:35 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:16:35 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:16:35 --> Utf8 Class Initialized
INFO - 2024-02-08 17:16:35 --> URI Class Initialized
INFO - 2024-02-08 17:16:35 --> Router Class Initialized
INFO - 2024-02-08 17:16:35 --> Output Class Initialized
INFO - 2024-02-08 17:16:35 --> Security Class Initialized
DEBUG - 2024-02-08 17:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:16:35 --> Input Class Initialized
INFO - 2024-02-08 17:16:35 --> Language Class Initialized
INFO - 2024-02-08 17:16:35 --> Loader Class Initialized
INFO - 2024-02-08 17:16:35 --> Helper loaded: url_helper
INFO - 2024-02-08 17:16:35 --> Helper loaded: file_helper
INFO - 2024-02-08 17:16:35 --> Helper loaded: form_helper
INFO - 2024-02-08 17:16:35 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:16:35 --> Controller Class Initialized
INFO - 2024-02-08 17:16:35 --> Form Validation Class Initialized
INFO - 2024-02-08 17:16:35 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:16:35 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:16:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:16:38 --> Config Class Initialized
INFO - 2024-02-08 17:16:38 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:16:38 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:16:38 --> Utf8 Class Initialized
INFO - 2024-02-08 17:16:38 --> URI Class Initialized
INFO - 2024-02-08 17:16:38 --> Router Class Initialized
INFO - 2024-02-08 17:16:38 --> Output Class Initialized
INFO - 2024-02-08 17:16:38 --> Security Class Initialized
DEBUG - 2024-02-08 17:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:16:38 --> Input Class Initialized
INFO - 2024-02-08 17:16:38 --> Language Class Initialized
INFO - 2024-02-08 17:16:38 --> Loader Class Initialized
INFO - 2024-02-08 17:16:38 --> Helper loaded: url_helper
INFO - 2024-02-08 17:16:38 --> Helper loaded: file_helper
INFO - 2024-02-08 17:16:38 --> Helper loaded: form_helper
INFO - 2024-02-08 17:16:38 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:16:38 --> Controller Class Initialized
INFO - 2024-02-08 17:16:38 --> Form Validation Class Initialized
INFO - 2024-02-08 17:16:38 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:16:38 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:16:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:16:42 --> Config Class Initialized
INFO - 2024-02-08 17:16:42 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:16:42 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:16:42 --> Utf8 Class Initialized
INFO - 2024-02-08 17:16:42 --> URI Class Initialized
INFO - 2024-02-08 17:16:42 --> Router Class Initialized
INFO - 2024-02-08 17:16:42 --> Output Class Initialized
INFO - 2024-02-08 17:16:42 --> Security Class Initialized
DEBUG - 2024-02-08 17:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:16:42 --> Input Class Initialized
INFO - 2024-02-08 17:16:42 --> Language Class Initialized
INFO - 2024-02-08 17:16:42 --> Loader Class Initialized
INFO - 2024-02-08 17:16:42 --> Helper loaded: url_helper
INFO - 2024-02-08 17:16:42 --> Helper loaded: file_helper
INFO - 2024-02-08 17:16:42 --> Helper loaded: form_helper
INFO - 2024-02-08 17:16:42 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:16:42 --> Controller Class Initialized
INFO - 2024-02-08 17:16:42 --> Form Validation Class Initialized
INFO - 2024-02-08 17:16:42 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:16:42 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:16:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:16:45 --> Config Class Initialized
INFO - 2024-02-08 17:16:45 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:16:45 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:16:45 --> Utf8 Class Initialized
INFO - 2024-02-08 17:16:45 --> URI Class Initialized
INFO - 2024-02-08 17:16:45 --> Router Class Initialized
INFO - 2024-02-08 17:16:45 --> Output Class Initialized
INFO - 2024-02-08 17:16:45 --> Security Class Initialized
DEBUG - 2024-02-08 17:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:16:45 --> Input Class Initialized
INFO - 2024-02-08 17:16:45 --> Language Class Initialized
INFO - 2024-02-08 17:16:45 --> Loader Class Initialized
INFO - 2024-02-08 17:16:45 --> Helper loaded: url_helper
INFO - 2024-02-08 17:16:45 --> Helper loaded: file_helper
INFO - 2024-02-08 17:16:45 --> Helper loaded: form_helper
INFO - 2024-02-08 17:16:45 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:16:45 --> Controller Class Initialized
INFO - 2024-02-08 17:16:45 --> Form Validation Class Initialized
INFO - 2024-02-08 17:16:45 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:16:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:16:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:16:48 --> Config Class Initialized
INFO - 2024-02-08 17:16:48 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:16:48 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:16:48 --> Utf8 Class Initialized
INFO - 2024-02-08 17:16:48 --> URI Class Initialized
INFO - 2024-02-08 17:16:48 --> Router Class Initialized
INFO - 2024-02-08 17:16:48 --> Output Class Initialized
INFO - 2024-02-08 17:16:48 --> Security Class Initialized
DEBUG - 2024-02-08 17:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:16:48 --> Input Class Initialized
INFO - 2024-02-08 17:16:48 --> Language Class Initialized
INFO - 2024-02-08 17:16:48 --> Loader Class Initialized
INFO - 2024-02-08 17:16:48 --> Helper loaded: url_helper
INFO - 2024-02-08 17:16:48 --> Helper loaded: file_helper
INFO - 2024-02-08 17:16:48 --> Helper loaded: form_helper
INFO - 2024-02-08 17:16:48 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:16:48 --> Controller Class Initialized
INFO - 2024-02-08 17:16:48 --> Form Validation Class Initialized
INFO - 2024-02-08 17:16:48 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:16:48 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:16:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:16:50 --> Config Class Initialized
INFO - 2024-02-08 17:16:50 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:16:50 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:16:50 --> Utf8 Class Initialized
INFO - 2024-02-08 17:16:50 --> URI Class Initialized
INFO - 2024-02-08 17:16:50 --> Router Class Initialized
INFO - 2024-02-08 17:16:50 --> Output Class Initialized
INFO - 2024-02-08 17:16:50 --> Security Class Initialized
DEBUG - 2024-02-08 17:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:16:50 --> Input Class Initialized
INFO - 2024-02-08 17:16:50 --> Language Class Initialized
INFO - 2024-02-08 17:16:50 --> Loader Class Initialized
INFO - 2024-02-08 17:16:50 --> Helper loaded: url_helper
INFO - 2024-02-08 17:16:50 --> Helper loaded: file_helper
INFO - 2024-02-08 17:16:50 --> Helper loaded: form_helper
INFO - 2024-02-08 17:16:50 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:16:50 --> Controller Class Initialized
INFO - 2024-02-08 17:16:50 --> Form Validation Class Initialized
INFO - 2024-02-08 17:16:50 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:16:50 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:17:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:17:17 --> Config Class Initialized
INFO - 2024-02-08 17:17:17 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:17:17 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:17:17 --> Utf8 Class Initialized
INFO - 2024-02-08 17:17:17 --> URI Class Initialized
INFO - 2024-02-08 17:17:17 --> Router Class Initialized
INFO - 2024-02-08 17:17:17 --> Output Class Initialized
INFO - 2024-02-08 17:17:17 --> Security Class Initialized
DEBUG - 2024-02-08 17:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:17:17 --> Input Class Initialized
INFO - 2024-02-08 17:17:17 --> Language Class Initialized
INFO - 2024-02-08 17:17:17 --> Loader Class Initialized
INFO - 2024-02-08 17:17:17 --> Helper loaded: url_helper
INFO - 2024-02-08 17:17:17 --> Helper loaded: file_helper
INFO - 2024-02-08 17:17:17 --> Helper loaded: form_helper
INFO - 2024-02-08 17:17:17 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:17:17 --> Controller Class Initialized
INFO - 2024-02-08 17:17:17 --> Form Validation Class Initialized
INFO - 2024-02-08 17:17:17 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:17:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:17:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:17:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:17:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:17:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:17:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:17:17 --> Final output sent to browser
DEBUG - 2024-02-08 17:17:17 --> Total execution time: 0.0305
ERROR - 2024-02-08 17:17:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:17:17 --> Config Class Initialized
INFO - 2024-02-08 17:17:17 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:17:17 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:17:17 --> Utf8 Class Initialized
INFO - 2024-02-08 17:17:17 --> URI Class Initialized
INFO - 2024-02-08 17:17:17 --> Router Class Initialized
INFO - 2024-02-08 17:17:17 --> Output Class Initialized
INFO - 2024-02-08 17:17:17 --> Security Class Initialized
DEBUG - 2024-02-08 17:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:17:17 --> Input Class Initialized
INFO - 2024-02-08 17:17:17 --> Language Class Initialized
INFO - 2024-02-08 17:17:17 --> Loader Class Initialized
INFO - 2024-02-08 17:17:17 --> Helper loaded: url_helper
INFO - 2024-02-08 17:17:17 --> Helper loaded: file_helper
INFO - 2024-02-08 17:17:17 --> Helper loaded: form_helper
INFO - 2024-02-08 17:17:17 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:17:17 --> Controller Class Initialized
INFO - 2024-02-08 17:17:17 --> Form Validation Class Initialized
INFO - 2024-02-08 17:17:17 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:17:17 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:17:25 --> Config Class Initialized
INFO - 2024-02-08 17:17:25 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:17:25 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:17:25 --> Utf8 Class Initialized
INFO - 2024-02-08 17:17:25 --> URI Class Initialized
INFO - 2024-02-08 17:17:25 --> Router Class Initialized
INFO - 2024-02-08 17:17:25 --> Output Class Initialized
INFO - 2024-02-08 17:17:25 --> Security Class Initialized
DEBUG - 2024-02-08 17:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:17:25 --> Input Class Initialized
INFO - 2024-02-08 17:17:25 --> Language Class Initialized
INFO - 2024-02-08 17:17:25 --> Loader Class Initialized
INFO - 2024-02-08 17:17:25 --> Helper loaded: url_helper
INFO - 2024-02-08 17:17:25 --> Helper loaded: file_helper
INFO - 2024-02-08 17:17:25 --> Helper loaded: form_helper
INFO - 2024-02-08 17:17:25 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:17:25 --> Controller Class Initialized
INFO - 2024-02-08 17:17:25 --> Form Validation Class Initialized
INFO - 2024-02-08 17:17:25 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:17:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:17:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:17:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:17:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:17:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:17:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:17:25 --> Final output sent to browser
DEBUG - 2024-02-08 17:17:25 --> Total execution time: 0.0414
ERROR - 2024-02-08 17:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:17:25 --> Config Class Initialized
INFO - 2024-02-08 17:17:25 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:17:25 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:17:25 --> Utf8 Class Initialized
INFO - 2024-02-08 17:17:25 --> URI Class Initialized
INFO - 2024-02-08 17:17:25 --> Router Class Initialized
INFO - 2024-02-08 17:17:25 --> Output Class Initialized
INFO - 2024-02-08 17:17:25 --> Security Class Initialized
DEBUG - 2024-02-08 17:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:17:25 --> Input Class Initialized
INFO - 2024-02-08 17:17:25 --> Language Class Initialized
INFO - 2024-02-08 17:17:25 --> Loader Class Initialized
INFO - 2024-02-08 17:17:25 --> Helper loaded: url_helper
INFO - 2024-02-08 17:17:25 --> Helper loaded: file_helper
INFO - 2024-02-08 17:17:25 --> Helper loaded: form_helper
INFO - 2024-02-08 17:17:25 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:17:25 --> Controller Class Initialized
INFO - 2024-02-08 17:17:25 --> Form Validation Class Initialized
INFO - 2024-02-08 17:17:25 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:17:25 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:17:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:17:29 --> Config Class Initialized
INFO - 2024-02-08 17:17:29 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:17:29 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:17:29 --> Utf8 Class Initialized
INFO - 2024-02-08 17:17:29 --> URI Class Initialized
INFO - 2024-02-08 17:17:29 --> Router Class Initialized
INFO - 2024-02-08 17:17:29 --> Output Class Initialized
INFO - 2024-02-08 17:17:29 --> Security Class Initialized
DEBUG - 2024-02-08 17:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:17:29 --> Input Class Initialized
INFO - 2024-02-08 17:17:29 --> Language Class Initialized
INFO - 2024-02-08 17:17:29 --> Loader Class Initialized
INFO - 2024-02-08 17:17:29 --> Helper loaded: url_helper
INFO - 2024-02-08 17:17:29 --> Helper loaded: file_helper
INFO - 2024-02-08 17:17:29 --> Helper loaded: form_helper
INFO - 2024-02-08 17:17:29 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:17:29 --> Controller Class Initialized
INFO - 2024-02-08 17:17:29 --> Form Validation Class Initialized
INFO - 2024-02-08 17:17:29 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:17:29 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:17:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:17:31 --> Config Class Initialized
INFO - 2024-02-08 17:17:31 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:17:31 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:17:31 --> Utf8 Class Initialized
INFO - 2024-02-08 17:17:31 --> URI Class Initialized
INFO - 2024-02-08 17:17:31 --> Router Class Initialized
INFO - 2024-02-08 17:17:31 --> Output Class Initialized
INFO - 2024-02-08 17:17:31 --> Security Class Initialized
DEBUG - 2024-02-08 17:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:17:31 --> Input Class Initialized
INFO - 2024-02-08 17:17:31 --> Language Class Initialized
INFO - 2024-02-08 17:17:31 --> Loader Class Initialized
INFO - 2024-02-08 17:17:31 --> Helper loaded: url_helper
INFO - 2024-02-08 17:17:31 --> Helper loaded: file_helper
INFO - 2024-02-08 17:17:31 --> Helper loaded: form_helper
INFO - 2024-02-08 17:17:31 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:17:31 --> Controller Class Initialized
INFO - 2024-02-08 17:17:31 --> Form Validation Class Initialized
INFO - 2024-02-08 17:17:31 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:17:31 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:17:36 --> Config Class Initialized
INFO - 2024-02-08 17:17:36 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:17:36 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:17:36 --> Utf8 Class Initialized
INFO - 2024-02-08 17:17:36 --> URI Class Initialized
INFO - 2024-02-08 17:17:36 --> Router Class Initialized
INFO - 2024-02-08 17:17:36 --> Output Class Initialized
INFO - 2024-02-08 17:17:36 --> Security Class Initialized
DEBUG - 2024-02-08 17:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:17:36 --> Input Class Initialized
INFO - 2024-02-08 17:17:36 --> Language Class Initialized
INFO - 2024-02-08 17:17:36 --> Loader Class Initialized
INFO - 2024-02-08 17:17:36 --> Helper loaded: url_helper
INFO - 2024-02-08 17:17:36 --> Helper loaded: file_helper
INFO - 2024-02-08 17:17:36 --> Helper loaded: form_helper
INFO - 2024-02-08 17:17:36 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:17:36 --> Controller Class Initialized
INFO - 2024-02-08 17:17:36 --> Form Validation Class Initialized
INFO - 2024-02-08 17:17:36 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:17:36 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:17:36 --> Config Class Initialized
INFO - 2024-02-08 17:17:36 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:17:36 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:17:36 --> Utf8 Class Initialized
INFO - 2024-02-08 17:17:36 --> URI Class Initialized
INFO - 2024-02-08 17:17:36 --> Router Class Initialized
INFO - 2024-02-08 17:17:36 --> Output Class Initialized
INFO - 2024-02-08 17:17:36 --> Security Class Initialized
DEBUG - 2024-02-08 17:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:17:36 --> Input Class Initialized
INFO - 2024-02-08 17:17:36 --> Language Class Initialized
INFO - 2024-02-08 17:17:36 --> Loader Class Initialized
INFO - 2024-02-08 17:17:36 --> Helper loaded: url_helper
INFO - 2024-02-08 17:17:36 --> Helper loaded: file_helper
INFO - 2024-02-08 17:17:36 --> Helper loaded: form_helper
INFO - 2024-02-08 17:17:36 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:17:36 --> Controller Class Initialized
INFO - 2024-02-08 17:17:36 --> Form Validation Class Initialized
INFO - 2024-02-08 17:17:36 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:17:36 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:17:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:17:37 --> Config Class Initialized
INFO - 2024-02-08 17:17:37 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:17:37 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:17:37 --> Utf8 Class Initialized
INFO - 2024-02-08 17:17:37 --> URI Class Initialized
INFO - 2024-02-08 17:17:37 --> Router Class Initialized
INFO - 2024-02-08 17:17:37 --> Output Class Initialized
INFO - 2024-02-08 17:17:37 --> Security Class Initialized
DEBUG - 2024-02-08 17:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:17:37 --> Input Class Initialized
INFO - 2024-02-08 17:17:38 --> Language Class Initialized
INFO - 2024-02-08 17:17:38 --> Loader Class Initialized
INFO - 2024-02-08 17:17:38 --> Helper loaded: url_helper
INFO - 2024-02-08 17:17:38 --> Helper loaded: file_helper
INFO - 2024-02-08 17:17:38 --> Helper loaded: form_helper
INFO - 2024-02-08 17:17:38 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:17:38 --> Controller Class Initialized
INFO - 2024-02-08 17:17:38 --> Form Validation Class Initialized
INFO - 2024-02-08 17:17:38 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:17:38 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:17:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:17:46 --> Config Class Initialized
INFO - 2024-02-08 17:17:46 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:17:46 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:17:46 --> Utf8 Class Initialized
INFO - 2024-02-08 17:17:46 --> URI Class Initialized
INFO - 2024-02-08 17:17:46 --> Router Class Initialized
INFO - 2024-02-08 17:17:46 --> Output Class Initialized
INFO - 2024-02-08 17:17:46 --> Security Class Initialized
DEBUG - 2024-02-08 17:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:17:46 --> Input Class Initialized
INFO - 2024-02-08 17:17:46 --> Language Class Initialized
INFO - 2024-02-08 17:17:46 --> Loader Class Initialized
INFO - 2024-02-08 17:17:46 --> Helper loaded: url_helper
INFO - 2024-02-08 17:17:46 --> Helper loaded: file_helper
INFO - 2024-02-08 17:17:46 --> Helper loaded: form_helper
INFO - 2024-02-08 17:17:46 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:17:46 --> Controller Class Initialized
INFO - 2024-02-08 17:17:46 --> Form Validation Class Initialized
INFO - 2024-02-08 17:17:46 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:17:46 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:17:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:17:46 --> Config Class Initialized
INFO - 2024-02-08 17:17:46 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:17:46 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:17:46 --> Utf8 Class Initialized
INFO - 2024-02-08 17:17:46 --> URI Class Initialized
INFO - 2024-02-08 17:17:46 --> Router Class Initialized
INFO - 2024-02-08 17:17:46 --> Output Class Initialized
INFO - 2024-02-08 17:17:46 --> Security Class Initialized
DEBUG - 2024-02-08 17:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:17:46 --> Input Class Initialized
INFO - 2024-02-08 17:17:46 --> Language Class Initialized
INFO - 2024-02-08 17:17:46 --> Loader Class Initialized
INFO - 2024-02-08 17:17:46 --> Helper loaded: url_helper
INFO - 2024-02-08 17:17:46 --> Helper loaded: file_helper
INFO - 2024-02-08 17:17:46 --> Helper loaded: form_helper
INFO - 2024-02-08 17:17:46 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:17:46 --> Controller Class Initialized
INFO - 2024-02-08 17:17:46 --> Form Validation Class Initialized
INFO - 2024-02-08 17:17:46 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:17:46 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:22:35 --> Config Class Initialized
INFO - 2024-02-08 17:22:35 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:22:35 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:22:35 --> Utf8 Class Initialized
INFO - 2024-02-08 17:22:35 --> URI Class Initialized
INFO - 2024-02-08 17:22:35 --> Router Class Initialized
INFO - 2024-02-08 17:22:35 --> Output Class Initialized
INFO - 2024-02-08 17:22:35 --> Security Class Initialized
DEBUG - 2024-02-08 17:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:22:35 --> Input Class Initialized
INFO - 2024-02-08 17:22:35 --> Language Class Initialized
INFO - 2024-02-08 17:22:35 --> Loader Class Initialized
INFO - 2024-02-08 17:22:35 --> Helper loaded: url_helper
INFO - 2024-02-08 17:22:35 --> Helper loaded: file_helper
INFO - 2024-02-08 17:22:35 --> Helper loaded: form_helper
INFO - 2024-02-08 17:22:35 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:22:35 --> Controller Class Initialized
INFO - 2024-02-08 17:22:35 --> Form Validation Class Initialized
INFO - 2024-02-08 17:22:35 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:22:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:22:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:22:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:22:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:22:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:22:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:22:35 --> Final output sent to browser
DEBUG - 2024-02-08 17:22:35 --> Total execution time: 0.0344
ERROR - 2024-02-08 17:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:22:35 --> Config Class Initialized
INFO - 2024-02-08 17:22:35 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:22:35 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:22:35 --> Utf8 Class Initialized
INFO - 2024-02-08 17:22:35 --> URI Class Initialized
INFO - 2024-02-08 17:22:35 --> Router Class Initialized
INFO - 2024-02-08 17:22:35 --> Output Class Initialized
INFO - 2024-02-08 17:22:35 --> Security Class Initialized
DEBUG - 2024-02-08 17:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:22:35 --> Input Class Initialized
INFO - 2024-02-08 17:22:35 --> Language Class Initialized
INFO - 2024-02-08 17:22:35 --> Loader Class Initialized
INFO - 2024-02-08 17:22:35 --> Helper loaded: url_helper
INFO - 2024-02-08 17:22:35 --> Helper loaded: file_helper
INFO - 2024-02-08 17:22:35 --> Helper loaded: form_helper
INFO - 2024-02-08 17:22:35 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:22:35 --> Controller Class Initialized
INFO - 2024-02-08 17:22:35 --> Form Validation Class Initialized
INFO - 2024-02-08 17:22:35 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:22:35 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:22:38 --> Config Class Initialized
INFO - 2024-02-08 17:22:38 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:22:38 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:22:38 --> Utf8 Class Initialized
INFO - 2024-02-08 17:22:38 --> URI Class Initialized
INFO - 2024-02-08 17:22:38 --> Router Class Initialized
INFO - 2024-02-08 17:22:38 --> Output Class Initialized
INFO - 2024-02-08 17:22:38 --> Security Class Initialized
DEBUG - 2024-02-08 17:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:22:38 --> Input Class Initialized
INFO - 2024-02-08 17:22:38 --> Language Class Initialized
INFO - 2024-02-08 17:22:38 --> Loader Class Initialized
INFO - 2024-02-08 17:22:38 --> Helper loaded: url_helper
INFO - 2024-02-08 17:22:38 --> Helper loaded: file_helper
INFO - 2024-02-08 17:22:38 --> Helper loaded: form_helper
INFO - 2024-02-08 17:22:38 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:22:38 --> Controller Class Initialized
INFO - 2024-02-08 17:22:38 --> Form Validation Class Initialized
INFO - 2024-02-08 17:22:38 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:22:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:22:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-08 17:22:38 --> Final output sent to browser
DEBUG - 2024-02-08 17:22:38 --> Total execution time: 0.0381
ERROR - 2024-02-08 17:28:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:28:17 --> Config Class Initialized
INFO - 2024-02-08 17:28:17 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:28:17 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:28:17 --> Utf8 Class Initialized
INFO - 2024-02-08 17:28:17 --> URI Class Initialized
INFO - 2024-02-08 17:28:17 --> Router Class Initialized
INFO - 2024-02-08 17:28:17 --> Output Class Initialized
INFO - 2024-02-08 17:28:17 --> Security Class Initialized
DEBUG - 2024-02-08 17:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:28:17 --> Input Class Initialized
INFO - 2024-02-08 17:28:17 --> Language Class Initialized
INFO - 2024-02-08 17:28:17 --> Loader Class Initialized
INFO - 2024-02-08 17:28:17 --> Helper loaded: url_helper
INFO - 2024-02-08 17:28:17 --> Helper loaded: file_helper
INFO - 2024-02-08 17:28:17 --> Helper loaded: form_helper
INFO - 2024-02-08 17:28:17 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:28:17 --> Controller Class Initialized
INFO - 2024-02-08 17:28:17 --> Form Validation Class Initialized
INFO - 2024-02-08 17:28:17 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:28:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:28:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:28:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:28:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:28:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:28:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:28:17 --> Final output sent to browser
DEBUG - 2024-02-08 17:28:17 --> Total execution time: 0.0387
ERROR - 2024-02-08 17:28:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:28:17 --> Config Class Initialized
INFO - 2024-02-08 17:28:17 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:28:17 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:28:17 --> Utf8 Class Initialized
INFO - 2024-02-08 17:28:17 --> URI Class Initialized
INFO - 2024-02-08 17:28:17 --> Router Class Initialized
INFO - 2024-02-08 17:28:17 --> Output Class Initialized
INFO - 2024-02-08 17:28:17 --> Security Class Initialized
DEBUG - 2024-02-08 17:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:28:17 --> Input Class Initialized
INFO - 2024-02-08 17:28:17 --> Language Class Initialized
INFO - 2024-02-08 17:28:17 --> Loader Class Initialized
INFO - 2024-02-08 17:28:17 --> Helper loaded: url_helper
INFO - 2024-02-08 17:28:17 --> Helper loaded: file_helper
INFO - 2024-02-08 17:28:17 --> Helper loaded: form_helper
INFO - 2024-02-08 17:28:17 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:28:17 --> Controller Class Initialized
INFO - 2024-02-08 17:28:17 --> Form Validation Class Initialized
INFO - 2024-02-08 17:28:17 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:28:17 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:28:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:28:20 --> Config Class Initialized
INFO - 2024-02-08 17:28:20 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:28:20 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:28:20 --> Utf8 Class Initialized
INFO - 2024-02-08 17:28:20 --> URI Class Initialized
INFO - 2024-02-08 17:28:20 --> Router Class Initialized
INFO - 2024-02-08 17:28:20 --> Output Class Initialized
INFO - 2024-02-08 17:28:20 --> Security Class Initialized
DEBUG - 2024-02-08 17:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:28:20 --> Input Class Initialized
INFO - 2024-02-08 17:28:20 --> Language Class Initialized
INFO - 2024-02-08 17:28:20 --> Loader Class Initialized
INFO - 2024-02-08 17:28:20 --> Helper loaded: url_helper
INFO - 2024-02-08 17:28:20 --> Helper loaded: file_helper
INFO - 2024-02-08 17:28:20 --> Helper loaded: form_helper
INFO - 2024-02-08 17:28:20 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:28:20 --> Controller Class Initialized
INFO - 2024-02-08 17:28:20 --> Form Validation Class Initialized
INFO - 2024-02-08 17:28:20 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:28:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:28:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-08 17:28:20 --> Final output sent to browser
DEBUG - 2024-02-08 17:28:20 --> Total execution time: 0.0366
ERROR - 2024-02-08 17:28:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:28:27 --> Config Class Initialized
INFO - 2024-02-08 17:28:27 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:28:27 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:28:27 --> Utf8 Class Initialized
INFO - 2024-02-08 17:28:27 --> URI Class Initialized
INFO - 2024-02-08 17:28:27 --> Router Class Initialized
INFO - 2024-02-08 17:28:27 --> Output Class Initialized
INFO - 2024-02-08 17:28:27 --> Security Class Initialized
DEBUG - 2024-02-08 17:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:28:27 --> Input Class Initialized
INFO - 2024-02-08 17:28:27 --> Language Class Initialized
INFO - 2024-02-08 17:28:27 --> Loader Class Initialized
INFO - 2024-02-08 17:28:27 --> Helper loaded: url_helper
INFO - 2024-02-08 17:28:27 --> Helper loaded: file_helper
INFO - 2024-02-08 17:28:27 --> Helper loaded: form_helper
INFO - 2024-02-08 17:28:27 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:28:27 --> Controller Class Initialized
INFO - 2024-02-08 17:28:27 --> Form Validation Class Initialized
INFO - 2024-02-08 17:28:27 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:28:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:28:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:28:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:28:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:28:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:28:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:28:27 --> Final output sent to browser
DEBUG - 2024-02-08 17:28:27 --> Total execution time: 0.0386
ERROR - 2024-02-08 17:28:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:28:28 --> Config Class Initialized
INFO - 2024-02-08 17:28:28 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:28:28 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:28:28 --> Utf8 Class Initialized
INFO - 2024-02-08 17:28:28 --> URI Class Initialized
INFO - 2024-02-08 17:28:28 --> Router Class Initialized
INFO - 2024-02-08 17:28:28 --> Output Class Initialized
INFO - 2024-02-08 17:28:28 --> Security Class Initialized
DEBUG - 2024-02-08 17:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:28:28 --> Input Class Initialized
INFO - 2024-02-08 17:28:28 --> Language Class Initialized
INFO - 2024-02-08 17:28:28 --> Loader Class Initialized
INFO - 2024-02-08 17:28:28 --> Helper loaded: url_helper
INFO - 2024-02-08 17:28:28 --> Helper loaded: file_helper
INFO - 2024-02-08 17:28:28 --> Helper loaded: form_helper
INFO - 2024-02-08 17:28:28 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:28:28 --> Controller Class Initialized
INFO - 2024-02-08 17:28:28 --> Form Validation Class Initialized
INFO - 2024-02-08 17:28:28 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:28:28 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:28:34 --> Config Class Initialized
INFO - 2024-02-08 17:28:34 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:28:34 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:28:34 --> Utf8 Class Initialized
INFO - 2024-02-08 17:28:34 --> URI Class Initialized
INFO - 2024-02-08 17:28:34 --> Router Class Initialized
INFO - 2024-02-08 17:28:34 --> Output Class Initialized
INFO - 2024-02-08 17:28:34 --> Security Class Initialized
DEBUG - 2024-02-08 17:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:28:34 --> Input Class Initialized
INFO - 2024-02-08 17:28:34 --> Language Class Initialized
INFO - 2024-02-08 17:28:34 --> Loader Class Initialized
INFO - 2024-02-08 17:28:34 --> Helper loaded: url_helper
INFO - 2024-02-08 17:28:34 --> Helper loaded: file_helper
INFO - 2024-02-08 17:28:34 --> Helper loaded: form_helper
INFO - 2024-02-08 17:28:34 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:28:34 --> Controller Class Initialized
INFO - 2024-02-08 17:28:34 --> Form Validation Class Initialized
INFO - 2024-02-08 17:28:34 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:28:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:28:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:28:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:28:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:28:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:28:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:28:34 --> Final output sent to browser
DEBUG - 2024-02-08 17:28:34 --> Total execution time: 0.0265
ERROR - 2024-02-08 17:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:28:34 --> Config Class Initialized
INFO - 2024-02-08 17:28:34 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:28:34 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:28:34 --> Utf8 Class Initialized
INFO - 2024-02-08 17:28:34 --> URI Class Initialized
INFO - 2024-02-08 17:28:34 --> Router Class Initialized
INFO - 2024-02-08 17:28:34 --> Output Class Initialized
INFO - 2024-02-08 17:28:34 --> Security Class Initialized
DEBUG - 2024-02-08 17:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:28:34 --> Input Class Initialized
INFO - 2024-02-08 17:28:34 --> Language Class Initialized
INFO - 2024-02-08 17:28:34 --> Loader Class Initialized
INFO - 2024-02-08 17:28:34 --> Helper loaded: url_helper
INFO - 2024-02-08 17:28:34 --> Helper loaded: file_helper
INFO - 2024-02-08 17:28:34 --> Helper loaded: form_helper
INFO - 2024-02-08 17:28:34 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:28:34 --> Controller Class Initialized
INFO - 2024-02-08 17:28:34 --> Form Validation Class Initialized
INFO - 2024-02-08 17:28:34 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:28:34 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:28:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:28:37 --> Config Class Initialized
INFO - 2024-02-08 17:28:37 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:28:37 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:28:37 --> Utf8 Class Initialized
INFO - 2024-02-08 17:28:37 --> URI Class Initialized
INFO - 2024-02-08 17:28:37 --> Router Class Initialized
INFO - 2024-02-08 17:28:37 --> Output Class Initialized
INFO - 2024-02-08 17:28:37 --> Security Class Initialized
DEBUG - 2024-02-08 17:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:28:37 --> Input Class Initialized
INFO - 2024-02-08 17:28:37 --> Language Class Initialized
INFO - 2024-02-08 17:28:37 --> Loader Class Initialized
INFO - 2024-02-08 17:28:37 --> Helper loaded: url_helper
INFO - 2024-02-08 17:28:37 --> Helper loaded: file_helper
INFO - 2024-02-08 17:28:37 --> Helper loaded: form_helper
INFO - 2024-02-08 17:28:37 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:28:37 --> Controller Class Initialized
INFO - 2024-02-08 17:28:37 --> Form Validation Class Initialized
INFO - 2024-02-08 17:28:37 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:28:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:28:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-08 17:28:37 --> Final output sent to browser
DEBUG - 2024-02-08 17:28:37 --> Total execution time: 0.0317
ERROR - 2024-02-08 17:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:30:54 --> Config Class Initialized
INFO - 2024-02-08 17:30:54 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:30:54 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:30:54 --> Utf8 Class Initialized
INFO - 2024-02-08 17:30:54 --> URI Class Initialized
INFO - 2024-02-08 17:30:54 --> Router Class Initialized
INFO - 2024-02-08 17:30:54 --> Output Class Initialized
INFO - 2024-02-08 17:30:54 --> Security Class Initialized
DEBUG - 2024-02-08 17:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:30:54 --> Input Class Initialized
INFO - 2024-02-08 17:30:54 --> Language Class Initialized
INFO - 2024-02-08 17:30:54 --> Loader Class Initialized
INFO - 2024-02-08 17:30:54 --> Helper loaded: url_helper
INFO - 2024-02-08 17:30:54 --> Helper loaded: file_helper
INFO - 2024-02-08 17:30:54 --> Helper loaded: form_helper
INFO - 2024-02-08 17:30:54 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:30:54 --> Controller Class Initialized
INFO - 2024-02-08 17:30:54 --> Form Validation Class Initialized
INFO - 2024-02-08 17:30:54 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:30:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:30:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:30:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:30:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:30:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:30:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:30:54 --> Final output sent to browser
DEBUG - 2024-02-08 17:30:54 --> Total execution time: 0.0271
ERROR - 2024-02-08 17:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:30:55 --> Config Class Initialized
INFO - 2024-02-08 17:30:55 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:30:55 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:30:55 --> Utf8 Class Initialized
INFO - 2024-02-08 17:30:55 --> URI Class Initialized
INFO - 2024-02-08 17:30:55 --> Router Class Initialized
INFO - 2024-02-08 17:30:55 --> Output Class Initialized
INFO - 2024-02-08 17:30:55 --> Security Class Initialized
DEBUG - 2024-02-08 17:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:30:55 --> Input Class Initialized
INFO - 2024-02-08 17:30:55 --> Language Class Initialized
INFO - 2024-02-08 17:30:55 --> Loader Class Initialized
INFO - 2024-02-08 17:30:55 --> Helper loaded: url_helper
INFO - 2024-02-08 17:30:55 --> Helper loaded: file_helper
INFO - 2024-02-08 17:30:55 --> Helper loaded: form_helper
INFO - 2024-02-08 17:30:55 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:30:55 --> Controller Class Initialized
INFO - 2024-02-08 17:30:55 --> Form Validation Class Initialized
INFO - 2024-02-08 17:30:55 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:30:55 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:34:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:34:10 --> Config Class Initialized
INFO - 2024-02-08 17:34:10 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:34:10 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:34:10 --> Utf8 Class Initialized
INFO - 2024-02-08 17:34:10 --> URI Class Initialized
INFO - 2024-02-08 17:34:10 --> Router Class Initialized
INFO - 2024-02-08 17:34:10 --> Output Class Initialized
INFO - 2024-02-08 17:34:10 --> Security Class Initialized
DEBUG - 2024-02-08 17:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:34:10 --> Input Class Initialized
INFO - 2024-02-08 17:34:10 --> Language Class Initialized
INFO - 2024-02-08 17:34:10 --> Loader Class Initialized
INFO - 2024-02-08 17:34:10 --> Helper loaded: url_helper
INFO - 2024-02-08 17:34:10 --> Helper loaded: file_helper
INFO - 2024-02-08 17:34:10 --> Helper loaded: form_helper
INFO - 2024-02-08 17:34:10 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:34:10 --> Controller Class Initialized
INFO - 2024-02-08 17:34:10 --> Form Validation Class Initialized
INFO - 2024-02-08 17:34:10 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:34:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:34:10 --> Final output sent to browser
DEBUG - 2024-02-08 17:34:10 --> Total execution time: 0.0288
ERROR - 2024-02-08 17:34:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:34:10 --> Config Class Initialized
INFO - 2024-02-08 17:34:10 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:34:10 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:34:10 --> Utf8 Class Initialized
INFO - 2024-02-08 17:34:10 --> URI Class Initialized
INFO - 2024-02-08 17:34:10 --> Router Class Initialized
INFO - 2024-02-08 17:34:10 --> Output Class Initialized
INFO - 2024-02-08 17:34:10 --> Security Class Initialized
DEBUG - 2024-02-08 17:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:34:10 --> Input Class Initialized
INFO - 2024-02-08 17:34:10 --> Language Class Initialized
INFO - 2024-02-08 17:34:10 --> Loader Class Initialized
INFO - 2024-02-08 17:34:10 --> Helper loaded: url_helper
INFO - 2024-02-08 17:34:10 --> Helper loaded: file_helper
INFO - 2024-02-08 17:34:10 --> Helper loaded: form_helper
INFO - 2024-02-08 17:34:10 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:34:10 --> Controller Class Initialized
INFO - 2024-02-08 17:34:10 --> Form Validation Class Initialized
INFO - 2024-02-08 17:34:10 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:34:10 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:34:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:34:48 --> Config Class Initialized
INFO - 2024-02-08 17:34:48 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:34:48 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:34:48 --> Utf8 Class Initialized
INFO - 2024-02-08 17:34:48 --> URI Class Initialized
INFO - 2024-02-08 17:34:48 --> Router Class Initialized
INFO - 2024-02-08 17:34:48 --> Output Class Initialized
INFO - 2024-02-08 17:34:48 --> Security Class Initialized
DEBUG - 2024-02-08 17:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:34:48 --> Input Class Initialized
INFO - 2024-02-08 17:34:48 --> Language Class Initialized
INFO - 2024-02-08 17:34:48 --> Loader Class Initialized
INFO - 2024-02-08 17:34:48 --> Helper loaded: url_helper
INFO - 2024-02-08 17:34:48 --> Helper loaded: file_helper
INFO - 2024-02-08 17:34:48 --> Helper loaded: form_helper
INFO - 2024-02-08 17:34:48 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:34:48 --> Controller Class Initialized
INFO - 2024-02-08 17:34:48 --> Form Validation Class Initialized
INFO - 2024-02-08 17:34:48 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:34:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:34:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:34:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:34:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:34:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:34:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:34:48 --> Final output sent to browser
DEBUG - 2024-02-08 17:34:48 --> Total execution time: 0.0253
ERROR - 2024-02-08 17:34:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:34:49 --> Config Class Initialized
INFO - 2024-02-08 17:34:49 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:34:49 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:34:49 --> Utf8 Class Initialized
INFO - 2024-02-08 17:34:49 --> URI Class Initialized
INFO - 2024-02-08 17:34:49 --> Router Class Initialized
INFO - 2024-02-08 17:34:49 --> Output Class Initialized
INFO - 2024-02-08 17:34:49 --> Security Class Initialized
DEBUG - 2024-02-08 17:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:34:49 --> Input Class Initialized
INFO - 2024-02-08 17:34:49 --> Language Class Initialized
INFO - 2024-02-08 17:34:49 --> Loader Class Initialized
INFO - 2024-02-08 17:34:49 --> Helper loaded: url_helper
INFO - 2024-02-08 17:34:49 --> Helper loaded: file_helper
INFO - 2024-02-08 17:34:49 --> Helper loaded: form_helper
INFO - 2024-02-08 17:34:49 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:34:49 --> Controller Class Initialized
INFO - 2024-02-08 17:34:49 --> Form Validation Class Initialized
INFO - 2024-02-08 17:34:49 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:34:49 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:36:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:36:51 --> Config Class Initialized
INFO - 2024-02-08 17:36:51 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:36:51 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:36:51 --> Utf8 Class Initialized
INFO - 2024-02-08 17:36:51 --> URI Class Initialized
INFO - 2024-02-08 17:36:51 --> Router Class Initialized
INFO - 2024-02-08 17:36:51 --> Output Class Initialized
INFO - 2024-02-08 17:36:51 --> Security Class Initialized
DEBUG - 2024-02-08 17:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:36:51 --> Input Class Initialized
INFO - 2024-02-08 17:36:51 --> Language Class Initialized
INFO - 2024-02-08 17:36:51 --> Loader Class Initialized
INFO - 2024-02-08 17:36:51 --> Helper loaded: url_helper
INFO - 2024-02-08 17:36:51 --> Helper loaded: file_helper
INFO - 2024-02-08 17:36:51 --> Helper loaded: form_helper
INFO - 2024-02-08 17:36:51 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:36:51 --> Controller Class Initialized
INFO - 2024-02-08 17:36:51 --> Form Validation Class Initialized
INFO - 2024-02-08 17:36:51 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:36:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:36:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:36:51 --> Final output sent to browser
DEBUG - 2024-02-08 17:36:51 --> Total execution time: 0.0311
ERROR - 2024-02-08 17:36:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:36:52 --> Config Class Initialized
INFO - 2024-02-08 17:36:52 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:36:52 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:36:52 --> Utf8 Class Initialized
INFO - 2024-02-08 17:36:52 --> URI Class Initialized
INFO - 2024-02-08 17:36:52 --> Router Class Initialized
INFO - 2024-02-08 17:36:52 --> Output Class Initialized
INFO - 2024-02-08 17:36:52 --> Security Class Initialized
DEBUG - 2024-02-08 17:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:36:52 --> Input Class Initialized
INFO - 2024-02-08 17:36:52 --> Language Class Initialized
INFO - 2024-02-08 17:36:52 --> Loader Class Initialized
INFO - 2024-02-08 17:36:52 --> Helper loaded: url_helper
INFO - 2024-02-08 17:36:52 --> Helper loaded: file_helper
INFO - 2024-02-08 17:36:52 --> Helper loaded: form_helper
INFO - 2024-02-08 17:36:52 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:36:52 --> Controller Class Initialized
INFO - 2024-02-08 17:36:52 --> Form Validation Class Initialized
INFO - 2024-02-08 17:36:52 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:36:52 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:38:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:38:46 --> Config Class Initialized
INFO - 2024-02-08 17:38:46 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:38:46 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:38:46 --> Utf8 Class Initialized
INFO - 2024-02-08 17:38:46 --> URI Class Initialized
INFO - 2024-02-08 17:38:46 --> Router Class Initialized
INFO - 2024-02-08 17:38:46 --> Output Class Initialized
INFO - 2024-02-08 17:38:46 --> Security Class Initialized
DEBUG - 2024-02-08 17:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:38:46 --> Input Class Initialized
INFO - 2024-02-08 17:38:46 --> Language Class Initialized
INFO - 2024-02-08 17:38:46 --> Loader Class Initialized
INFO - 2024-02-08 17:38:46 --> Helper loaded: url_helper
INFO - 2024-02-08 17:38:46 --> Helper loaded: file_helper
INFO - 2024-02-08 17:38:46 --> Helper loaded: form_helper
INFO - 2024-02-08 17:38:46 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:38:46 --> Controller Class Initialized
INFO - 2024-02-08 17:38:46 --> Form Validation Class Initialized
INFO - 2024-02-08 17:38:46 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:38:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 17:38:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 17:38:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 17:38:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 17:38:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 17:38:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 17:38:46 --> Final output sent to browser
DEBUG - 2024-02-08 17:38:46 --> Total execution time: 0.0281
ERROR - 2024-02-08 17:38:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:38:46 --> Config Class Initialized
INFO - 2024-02-08 17:38:46 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:38:46 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:38:46 --> Utf8 Class Initialized
INFO - 2024-02-08 17:38:46 --> URI Class Initialized
INFO - 2024-02-08 17:38:46 --> Router Class Initialized
INFO - 2024-02-08 17:38:46 --> Output Class Initialized
INFO - 2024-02-08 17:38:46 --> Security Class Initialized
DEBUG - 2024-02-08 17:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:38:46 --> Input Class Initialized
INFO - 2024-02-08 17:38:46 --> Language Class Initialized
INFO - 2024-02-08 17:38:46 --> Loader Class Initialized
INFO - 2024-02-08 17:38:46 --> Helper loaded: url_helper
INFO - 2024-02-08 17:38:46 --> Helper loaded: file_helper
INFO - 2024-02-08 17:38:46 --> Helper loaded: form_helper
INFO - 2024-02-08 17:38:46 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:38:46 --> Controller Class Initialized
INFO - 2024-02-08 17:38:46 --> Form Validation Class Initialized
INFO - 2024-02-08 17:38:46 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:38:46 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:39:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:39:15 --> Config Class Initialized
INFO - 2024-02-08 17:39:15 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:39:15 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:39:15 --> Utf8 Class Initialized
INFO - 2024-02-08 17:39:15 --> URI Class Initialized
INFO - 2024-02-08 17:39:15 --> Router Class Initialized
INFO - 2024-02-08 17:39:15 --> Output Class Initialized
INFO - 2024-02-08 17:39:15 --> Security Class Initialized
DEBUG - 2024-02-08 17:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:39:15 --> Input Class Initialized
INFO - 2024-02-08 17:39:15 --> Language Class Initialized
INFO - 2024-02-08 17:39:15 --> Loader Class Initialized
INFO - 2024-02-08 17:39:15 --> Helper loaded: url_helper
INFO - 2024-02-08 17:39:15 --> Helper loaded: file_helper
INFO - 2024-02-08 17:39:15 --> Helper loaded: form_helper
INFO - 2024-02-08 17:39:15 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:39:15 --> Controller Class Initialized
INFO - 2024-02-08 17:39:15 --> Form Validation Class Initialized
INFO - 2024-02-08 17:39:15 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:39:15 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 17:39:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 17:39:15 --> Config Class Initialized
INFO - 2024-02-08 17:39:15 --> Hooks Class Initialized
DEBUG - 2024-02-08 17:39:15 --> UTF-8 Support Enabled
INFO - 2024-02-08 17:39:15 --> Utf8 Class Initialized
INFO - 2024-02-08 17:39:15 --> URI Class Initialized
INFO - 2024-02-08 17:39:15 --> Router Class Initialized
INFO - 2024-02-08 17:39:15 --> Output Class Initialized
INFO - 2024-02-08 17:39:15 --> Security Class Initialized
DEBUG - 2024-02-08 17:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 17:39:15 --> Input Class Initialized
INFO - 2024-02-08 17:39:15 --> Language Class Initialized
INFO - 2024-02-08 17:39:15 --> Loader Class Initialized
INFO - 2024-02-08 17:39:15 --> Helper loaded: url_helper
INFO - 2024-02-08 17:39:15 --> Helper loaded: file_helper
INFO - 2024-02-08 17:39:15 --> Helper loaded: form_helper
INFO - 2024-02-08 17:39:15 --> Database Driver Class Initialized
DEBUG - 2024-02-08 17:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 17:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 17:39:15 --> Controller Class Initialized
INFO - 2024-02-08 17:39:15 --> Form Validation Class Initialized
INFO - 2024-02-08 17:39:15 --> Model "MasterModel" initialized
INFO - 2024-02-08 17:39:15 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 18:03:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:03:52 --> Config Class Initialized
INFO - 2024-02-08 18:03:52 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:03:52 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:03:52 --> Utf8 Class Initialized
INFO - 2024-02-08 18:03:52 --> URI Class Initialized
INFO - 2024-02-08 18:03:52 --> Router Class Initialized
INFO - 2024-02-08 18:03:52 --> Output Class Initialized
INFO - 2024-02-08 18:03:52 --> Security Class Initialized
DEBUG - 2024-02-08 18:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:03:52 --> Input Class Initialized
INFO - 2024-02-08 18:03:52 --> Language Class Initialized
INFO - 2024-02-08 18:03:52 --> Loader Class Initialized
INFO - 2024-02-08 18:03:52 --> Helper loaded: url_helper
INFO - 2024-02-08 18:03:52 --> Helper loaded: file_helper
INFO - 2024-02-08 18:03:52 --> Helper loaded: form_helper
INFO - 2024-02-08 18:03:52 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:03:52 --> Controller Class Initialized
INFO - 2024-02-08 18:03:52 --> Form Validation Class Initialized
INFO - 2024-02-08 18:03:52 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:03:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 18:03:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 18:03:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 18:03:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 18:03:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 18:03:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 18:03:52 --> Final output sent to browser
DEBUG - 2024-02-08 18:03:52 --> Total execution time: 0.0356
ERROR - 2024-02-08 18:03:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:03:53 --> Config Class Initialized
INFO - 2024-02-08 18:03:53 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:03:53 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:03:53 --> Utf8 Class Initialized
INFO - 2024-02-08 18:03:53 --> URI Class Initialized
INFO - 2024-02-08 18:03:53 --> Router Class Initialized
INFO - 2024-02-08 18:03:53 --> Output Class Initialized
INFO - 2024-02-08 18:03:53 --> Security Class Initialized
DEBUG - 2024-02-08 18:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:03:53 --> Input Class Initialized
INFO - 2024-02-08 18:03:53 --> Language Class Initialized
INFO - 2024-02-08 18:03:53 --> Loader Class Initialized
INFO - 2024-02-08 18:03:53 --> Helper loaded: url_helper
INFO - 2024-02-08 18:03:53 --> Helper loaded: file_helper
INFO - 2024-02-08 18:03:53 --> Helper loaded: form_helper
INFO - 2024-02-08 18:03:53 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:03:53 --> Controller Class Initialized
INFO - 2024-02-08 18:03:53 --> Form Validation Class Initialized
INFO - 2024-02-08 18:03:53 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:03:53 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 18:04:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:04:52 --> Config Class Initialized
INFO - 2024-02-08 18:04:52 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:04:52 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:04:52 --> Utf8 Class Initialized
INFO - 2024-02-08 18:04:52 --> URI Class Initialized
INFO - 2024-02-08 18:04:52 --> Router Class Initialized
INFO - 2024-02-08 18:04:52 --> Output Class Initialized
INFO - 2024-02-08 18:04:52 --> Security Class Initialized
DEBUG - 2024-02-08 18:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:04:52 --> Input Class Initialized
INFO - 2024-02-08 18:04:52 --> Language Class Initialized
INFO - 2024-02-08 18:04:52 --> Loader Class Initialized
INFO - 2024-02-08 18:04:52 --> Helper loaded: url_helper
INFO - 2024-02-08 18:04:52 --> Helper loaded: file_helper
INFO - 2024-02-08 18:04:52 --> Helper loaded: form_helper
INFO - 2024-02-08 18:04:52 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:04:52 --> Controller Class Initialized
INFO - 2024-02-08 18:04:52 --> Form Validation Class Initialized
INFO - 2024-02-08 18:04:52 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:04:52 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 18:04:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:04:55 --> Config Class Initialized
INFO - 2024-02-08 18:04:55 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:04:55 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:04:55 --> Utf8 Class Initialized
INFO - 2024-02-08 18:04:55 --> URI Class Initialized
INFO - 2024-02-08 18:04:55 --> Router Class Initialized
INFO - 2024-02-08 18:04:55 --> Output Class Initialized
INFO - 2024-02-08 18:04:55 --> Security Class Initialized
DEBUG - 2024-02-08 18:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:04:55 --> Input Class Initialized
INFO - 2024-02-08 18:04:55 --> Language Class Initialized
INFO - 2024-02-08 18:04:55 --> Loader Class Initialized
INFO - 2024-02-08 18:04:55 --> Helper loaded: url_helper
INFO - 2024-02-08 18:04:55 --> Helper loaded: file_helper
INFO - 2024-02-08 18:04:55 --> Helper loaded: form_helper
INFO - 2024-02-08 18:04:55 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:04:55 --> Controller Class Initialized
INFO - 2024-02-08 18:04:55 --> Form Validation Class Initialized
INFO - 2024-02-08 18:04:55 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:04:55 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 18:05:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:05:26 --> Config Class Initialized
INFO - 2024-02-08 18:05:26 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:05:26 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:05:26 --> Utf8 Class Initialized
INFO - 2024-02-08 18:05:26 --> URI Class Initialized
INFO - 2024-02-08 18:05:26 --> Router Class Initialized
INFO - 2024-02-08 18:05:26 --> Output Class Initialized
INFO - 2024-02-08 18:05:26 --> Security Class Initialized
DEBUG - 2024-02-08 18:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:05:26 --> Input Class Initialized
INFO - 2024-02-08 18:05:26 --> Language Class Initialized
INFO - 2024-02-08 18:05:26 --> Loader Class Initialized
INFO - 2024-02-08 18:05:26 --> Helper loaded: url_helper
INFO - 2024-02-08 18:05:26 --> Helper loaded: file_helper
INFO - 2024-02-08 18:05:26 --> Helper loaded: form_helper
INFO - 2024-02-08 18:05:26 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:05:26 --> Controller Class Initialized
INFO - 2024-02-08 18:05:26 --> Form Validation Class Initialized
INFO - 2024-02-08 18:05:26 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:05:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 18:05:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 18:05:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 18:05:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 18:05:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 18:05:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 18:05:26 --> Final output sent to browser
DEBUG - 2024-02-08 18:05:26 --> Total execution time: 0.0307
ERROR - 2024-02-08 18:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:05:27 --> Config Class Initialized
INFO - 2024-02-08 18:05:27 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:05:27 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:05:27 --> Utf8 Class Initialized
INFO - 2024-02-08 18:05:27 --> URI Class Initialized
INFO - 2024-02-08 18:05:27 --> Router Class Initialized
INFO - 2024-02-08 18:05:27 --> Output Class Initialized
INFO - 2024-02-08 18:05:27 --> Security Class Initialized
DEBUG - 2024-02-08 18:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:05:27 --> Input Class Initialized
INFO - 2024-02-08 18:05:27 --> Language Class Initialized
INFO - 2024-02-08 18:05:27 --> Loader Class Initialized
INFO - 2024-02-08 18:05:27 --> Helper loaded: url_helper
INFO - 2024-02-08 18:05:27 --> Helper loaded: file_helper
INFO - 2024-02-08 18:05:27 --> Helper loaded: form_helper
INFO - 2024-02-08 18:05:27 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:05:27 --> Controller Class Initialized
INFO - 2024-02-08 18:05:27 --> Form Validation Class Initialized
INFO - 2024-02-08 18:05:27 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:05:27 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 18:05:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:05:52 --> Config Class Initialized
INFO - 2024-02-08 18:05:52 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:05:52 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:05:52 --> Utf8 Class Initialized
INFO - 2024-02-08 18:05:52 --> URI Class Initialized
INFO - 2024-02-08 18:05:52 --> Router Class Initialized
INFO - 2024-02-08 18:05:52 --> Output Class Initialized
INFO - 2024-02-08 18:05:52 --> Security Class Initialized
DEBUG - 2024-02-08 18:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:05:52 --> Input Class Initialized
INFO - 2024-02-08 18:05:52 --> Language Class Initialized
INFO - 2024-02-08 18:05:52 --> Loader Class Initialized
INFO - 2024-02-08 18:05:52 --> Helper loaded: url_helper
INFO - 2024-02-08 18:05:52 --> Helper loaded: file_helper
INFO - 2024-02-08 18:05:52 --> Helper loaded: form_helper
INFO - 2024-02-08 18:05:52 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:05:52 --> Controller Class Initialized
INFO - 2024-02-08 18:05:52 --> Form Validation Class Initialized
INFO - 2024-02-08 18:05:52 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:05:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 18:05:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 18:05:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 18:05:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 18:05:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 18:05:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-08 18:05:52 --> Final output sent to browser
DEBUG - 2024-02-08 18:05:52 --> Total execution time: 0.0254
ERROR - 2024-02-08 18:05:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:05:53 --> Config Class Initialized
INFO - 2024-02-08 18:05:53 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:05:53 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:05:53 --> Utf8 Class Initialized
INFO - 2024-02-08 18:05:53 --> URI Class Initialized
INFO - 2024-02-08 18:05:53 --> Router Class Initialized
INFO - 2024-02-08 18:05:53 --> Output Class Initialized
INFO - 2024-02-08 18:05:53 --> Security Class Initialized
DEBUG - 2024-02-08 18:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:05:53 --> Input Class Initialized
INFO - 2024-02-08 18:05:53 --> Language Class Initialized
INFO - 2024-02-08 18:05:53 --> Loader Class Initialized
INFO - 2024-02-08 18:05:53 --> Helper loaded: url_helper
INFO - 2024-02-08 18:05:53 --> Helper loaded: file_helper
INFO - 2024-02-08 18:05:53 --> Helper loaded: form_helper
INFO - 2024-02-08 18:05:53 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:05:53 --> Controller Class Initialized
INFO - 2024-02-08 18:05:53 --> Form Validation Class Initialized
INFO - 2024-02-08 18:05:53 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:05:53 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 18:07:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:07:44 --> Config Class Initialized
INFO - 2024-02-08 18:07:44 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:07:44 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:07:44 --> Utf8 Class Initialized
INFO - 2024-02-08 18:07:44 --> URI Class Initialized
INFO - 2024-02-08 18:07:44 --> Router Class Initialized
INFO - 2024-02-08 18:07:44 --> Output Class Initialized
INFO - 2024-02-08 18:07:44 --> Security Class Initialized
DEBUG - 2024-02-08 18:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:07:44 --> Input Class Initialized
INFO - 2024-02-08 18:07:44 --> Language Class Initialized
INFO - 2024-02-08 18:07:44 --> Loader Class Initialized
INFO - 2024-02-08 18:07:44 --> Helper loaded: url_helper
INFO - 2024-02-08 18:07:44 --> Helper loaded: file_helper
INFO - 2024-02-08 18:07:44 --> Helper loaded: form_helper
INFO - 2024-02-08 18:07:44 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:07:44 --> Controller Class Initialized
INFO - 2024-02-08 18:07:44 --> Model "LoginModel" initialized
INFO - 2024-02-08 18:07:44 --> Form Validation Class Initialized
INFO - 2024-02-08 18:07:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-08 18:07:44 --> Final output sent to browser
DEBUG - 2024-02-08 18:07:44 --> Total execution time: 0.0275
ERROR - 2024-02-08 18:07:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:07:54 --> Config Class Initialized
INFO - 2024-02-08 18:07:54 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:07:54 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:07:54 --> Utf8 Class Initialized
INFO - 2024-02-08 18:07:54 --> URI Class Initialized
INFO - 2024-02-08 18:07:54 --> Router Class Initialized
INFO - 2024-02-08 18:07:54 --> Output Class Initialized
INFO - 2024-02-08 18:07:54 --> Security Class Initialized
DEBUG - 2024-02-08 18:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:07:54 --> Input Class Initialized
INFO - 2024-02-08 18:07:54 --> Language Class Initialized
INFO - 2024-02-08 18:07:54 --> Loader Class Initialized
INFO - 2024-02-08 18:07:54 --> Helper loaded: url_helper
INFO - 2024-02-08 18:07:54 --> Helper loaded: file_helper
INFO - 2024-02-08 18:07:54 --> Helper loaded: form_helper
INFO - 2024-02-08 18:07:54 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:07:54 --> Controller Class Initialized
INFO - 2024-02-08 18:07:54 --> Model "LoginModel" initialized
INFO - 2024-02-08 18:07:54 --> Form Validation Class Initialized
INFO - 2024-02-08 18:07:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-08 18:07:54 --> Severity: Notice --> Undefined property: stdClass::$emp_role D:\xampp\htdocs\sscy\application\models\LoginModel.php 18
ERROR - 2024-02-08 18:07:54 --> Severity: Notice --> Undefined variable: empRole D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-08 18:07:54 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-08 18:07:54 --> Severity: Notice --> Undefined property: stdClass::$emp_name D:\xampp\htdocs\sscy\application\models\LoginModel.php 20
ERROR - 2024-02-08 18:07:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:07:54 --> Config Class Initialized
INFO - 2024-02-08 18:07:54 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:07:54 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:07:54 --> Utf8 Class Initialized
INFO - 2024-02-08 18:07:54 --> URI Class Initialized
INFO - 2024-02-08 18:07:54 --> Router Class Initialized
INFO - 2024-02-08 18:07:54 --> Output Class Initialized
INFO - 2024-02-08 18:07:54 --> Security Class Initialized
DEBUG - 2024-02-08 18:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:07:54 --> Input Class Initialized
INFO - 2024-02-08 18:07:54 --> Language Class Initialized
INFO - 2024-02-08 18:07:54 --> Loader Class Initialized
INFO - 2024-02-08 18:07:54 --> Helper loaded: url_helper
INFO - 2024-02-08 18:07:54 --> Helper loaded: file_helper
INFO - 2024-02-08 18:07:54 --> Helper loaded: form_helper
INFO - 2024-02-08 18:07:54 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:07:54 --> Controller Class Initialized
INFO - 2024-02-08 18:07:54 --> Form Validation Class Initialized
INFO - 2024-02-08 18:07:54 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:07:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 18:07:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 18:07:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 18:07:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 18:07:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 18:07:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 18:07:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 18:07:54 --> Final output sent to browser
DEBUG - 2024-02-08 18:07:54 --> Total execution time: 0.0243
ERROR - 2024-02-08 18:09:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:09:52 --> Config Class Initialized
INFO - 2024-02-08 18:09:52 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:09:52 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:09:52 --> Utf8 Class Initialized
INFO - 2024-02-08 18:09:52 --> URI Class Initialized
INFO - 2024-02-08 18:09:52 --> Router Class Initialized
INFO - 2024-02-08 18:09:52 --> Output Class Initialized
INFO - 2024-02-08 18:09:52 --> Security Class Initialized
DEBUG - 2024-02-08 18:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:09:52 --> Input Class Initialized
INFO - 2024-02-08 18:09:52 --> Language Class Initialized
INFO - 2024-02-08 18:09:52 --> Loader Class Initialized
INFO - 2024-02-08 18:09:52 --> Helper loaded: url_helper
INFO - 2024-02-08 18:09:52 --> Helper loaded: file_helper
INFO - 2024-02-08 18:09:52 --> Helper loaded: form_helper
INFO - 2024-02-08 18:09:52 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:09:52 --> Controller Class Initialized
INFO - 2024-02-08 18:09:52 --> Form Validation Class Initialized
INFO - 2024-02-08 18:09:52 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:09:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 18:09:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-08 18:09:52 --> Final output sent to browser
DEBUG - 2024-02-08 18:09:52 --> Total execution time: 0.0327
ERROR - 2024-02-08 18:10:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:10:21 --> Config Class Initialized
INFO - 2024-02-08 18:10:21 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:10:21 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:10:21 --> Utf8 Class Initialized
INFO - 2024-02-08 18:10:21 --> URI Class Initialized
INFO - 2024-02-08 18:10:21 --> Router Class Initialized
INFO - 2024-02-08 18:10:21 --> Output Class Initialized
INFO - 2024-02-08 18:10:21 --> Security Class Initialized
DEBUG - 2024-02-08 18:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:10:21 --> Input Class Initialized
INFO - 2024-02-08 18:10:21 --> Language Class Initialized
INFO - 2024-02-08 18:10:21 --> Loader Class Initialized
INFO - 2024-02-08 18:10:21 --> Helper loaded: url_helper
INFO - 2024-02-08 18:10:21 --> Helper loaded: file_helper
INFO - 2024-02-08 18:10:21 --> Helper loaded: form_helper
INFO - 2024-02-08 18:10:21 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:10:21 --> Controller Class Initialized
INFO - 2024-02-08 18:10:21 --> Form Validation Class Initialized
INFO - 2024-02-08 18:10:21 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:10:21 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 18:10:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:10:21 --> Config Class Initialized
INFO - 2024-02-08 18:10:21 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:10:21 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:10:21 --> Utf8 Class Initialized
INFO - 2024-02-08 18:10:21 --> URI Class Initialized
INFO - 2024-02-08 18:10:21 --> Router Class Initialized
INFO - 2024-02-08 18:10:21 --> Output Class Initialized
INFO - 2024-02-08 18:10:21 --> Security Class Initialized
DEBUG - 2024-02-08 18:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:10:21 --> Input Class Initialized
INFO - 2024-02-08 18:10:21 --> Language Class Initialized
INFO - 2024-02-08 18:10:21 --> Loader Class Initialized
INFO - 2024-02-08 18:10:21 --> Helper loaded: url_helper
INFO - 2024-02-08 18:10:21 --> Helper loaded: file_helper
INFO - 2024-02-08 18:10:21 --> Helper loaded: form_helper
INFO - 2024-02-08 18:10:21 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:10:21 --> Controller Class Initialized
INFO - 2024-02-08 18:10:21 --> Form Validation Class Initialized
INFO - 2024-02-08 18:10:21 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:10:21 --> Model "UserMasterModel" initialized
ERROR - 2024-02-08 18:10:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:10:30 --> Config Class Initialized
INFO - 2024-02-08 18:10:30 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:10:30 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:10:30 --> Utf8 Class Initialized
INFO - 2024-02-08 18:10:30 --> URI Class Initialized
INFO - 2024-02-08 18:10:30 --> Router Class Initialized
INFO - 2024-02-08 18:10:30 --> Output Class Initialized
INFO - 2024-02-08 18:10:30 --> Security Class Initialized
DEBUG - 2024-02-08 18:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:10:30 --> Input Class Initialized
INFO - 2024-02-08 18:10:30 --> Language Class Initialized
INFO - 2024-02-08 18:10:30 --> Loader Class Initialized
INFO - 2024-02-08 18:10:30 --> Helper loaded: url_helper
INFO - 2024-02-08 18:10:30 --> Helper loaded: file_helper
INFO - 2024-02-08 18:10:30 --> Helper loaded: form_helper
INFO - 2024-02-08 18:10:31 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:10:31 --> Controller Class Initialized
INFO - 2024-02-08 18:10:31 --> Model "LoginModel" initialized
INFO - 2024-02-08 18:10:31 --> Form Validation Class Initialized
ERROR - 2024-02-08 18:10:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:10:31 --> Config Class Initialized
INFO - 2024-02-08 18:10:31 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:10:31 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:10:31 --> Utf8 Class Initialized
INFO - 2024-02-08 18:10:31 --> URI Class Initialized
INFO - 2024-02-08 18:10:31 --> Router Class Initialized
INFO - 2024-02-08 18:10:31 --> Output Class Initialized
INFO - 2024-02-08 18:10:31 --> Security Class Initialized
DEBUG - 2024-02-08 18:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:10:31 --> Input Class Initialized
INFO - 2024-02-08 18:10:31 --> Language Class Initialized
INFO - 2024-02-08 18:10:31 --> Loader Class Initialized
INFO - 2024-02-08 18:10:31 --> Helper loaded: url_helper
INFO - 2024-02-08 18:10:31 --> Helper loaded: file_helper
INFO - 2024-02-08 18:10:31 --> Helper loaded: form_helper
INFO - 2024-02-08 18:10:31 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:10:31 --> Controller Class Initialized
INFO - 2024-02-08 18:10:31 --> Model "LoginModel" initialized
INFO - 2024-02-08 18:10:31 --> Form Validation Class Initialized
INFO - 2024-02-08 18:10:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-08 18:10:31 --> Final output sent to browser
DEBUG - 2024-02-08 18:10:31 --> Total execution time: 0.0220
ERROR - 2024-02-08 18:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:10:40 --> Config Class Initialized
INFO - 2024-02-08 18:10:40 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:10:40 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:10:40 --> Utf8 Class Initialized
INFO - 2024-02-08 18:10:40 --> URI Class Initialized
INFO - 2024-02-08 18:10:40 --> Router Class Initialized
INFO - 2024-02-08 18:10:40 --> Output Class Initialized
INFO - 2024-02-08 18:10:40 --> Security Class Initialized
DEBUG - 2024-02-08 18:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:10:40 --> Input Class Initialized
INFO - 2024-02-08 18:10:40 --> Language Class Initialized
INFO - 2024-02-08 18:10:40 --> Loader Class Initialized
INFO - 2024-02-08 18:10:40 --> Helper loaded: url_helper
INFO - 2024-02-08 18:10:40 --> Helper loaded: file_helper
INFO - 2024-02-08 18:10:40 --> Helper loaded: form_helper
INFO - 2024-02-08 18:10:40 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:10:40 --> Controller Class Initialized
INFO - 2024-02-08 18:10:40 --> Model "LoginModel" initialized
INFO - 2024-02-08 18:10:40 --> Form Validation Class Initialized
INFO - 2024-02-08 18:10:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-08 18:10:40 --> Severity: Notice --> Undefined property: stdClass::$emp_role D:\xampp\htdocs\sscy\application\models\LoginModel.php 18
ERROR - 2024-02-08 18:10:40 --> Severity: Notice --> Undefined variable: empRole D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-08 18:10:40 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-08 18:10:40 --> Severity: Notice --> Undefined property: stdClass::$emp_name D:\xampp\htdocs\sscy\application\models\LoginModel.php 20
ERROR - 2024-02-08 18:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-08 18:10:40 --> Config Class Initialized
INFO - 2024-02-08 18:10:40 --> Hooks Class Initialized
DEBUG - 2024-02-08 18:10:40 --> UTF-8 Support Enabled
INFO - 2024-02-08 18:10:40 --> Utf8 Class Initialized
INFO - 2024-02-08 18:10:40 --> URI Class Initialized
INFO - 2024-02-08 18:10:40 --> Router Class Initialized
INFO - 2024-02-08 18:10:40 --> Output Class Initialized
INFO - 2024-02-08 18:10:40 --> Security Class Initialized
DEBUG - 2024-02-08 18:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-08 18:10:40 --> Input Class Initialized
INFO - 2024-02-08 18:10:40 --> Language Class Initialized
INFO - 2024-02-08 18:10:40 --> Loader Class Initialized
INFO - 2024-02-08 18:10:40 --> Helper loaded: url_helper
INFO - 2024-02-08 18:10:40 --> Helper loaded: file_helper
INFO - 2024-02-08 18:10:40 --> Helper loaded: form_helper
INFO - 2024-02-08 18:10:40 --> Database Driver Class Initialized
DEBUG - 2024-02-08 18:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-08 18:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-08 18:10:40 --> Controller Class Initialized
INFO - 2024-02-08 18:10:40 --> Form Validation Class Initialized
INFO - 2024-02-08 18:10:40 --> Model "MasterModel" initialized
INFO - 2024-02-08 18:10:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-08 18:10:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-08 18:10:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-08 18:10:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-08 18:10:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-08 18:10:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-08 18:10:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-08 18:10:40 --> Final output sent to browser
DEBUG - 2024-02-08 18:10:40 --> Total execution time: 0.0268
