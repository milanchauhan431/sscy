<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-07 19:06:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:06:04 --> Config Class Initialized
INFO - 2024-03-07 19:06:04 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:06:04 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:06:04 --> Utf8 Class Initialized
INFO - 2024-03-07 19:06:04 --> URI Class Initialized
INFO - 2024-03-07 19:06:04 --> Router Class Initialized
INFO - 2024-03-07 19:06:04 --> Output Class Initialized
INFO - 2024-03-07 19:06:04 --> Security Class Initialized
DEBUG - 2024-03-07 19:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:06:04 --> Input Class Initialized
INFO - 2024-03-07 19:06:04 --> Language Class Initialized
INFO - 2024-03-07 19:06:04 --> Loader Class Initialized
INFO - 2024-03-07 19:06:04 --> Helper loaded: url_helper
INFO - 2024-03-07 19:06:04 --> Helper loaded: file_helper
INFO - 2024-03-07 19:06:04 --> Helper loaded: form_helper
INFO - 2024-03-07 19:06:04 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:06:04 --> Controller Class Initialized
INFO - 2024-03-07 19:06:04 --> Form Validation Class Initialized
INFO - 2024-03-07 19:06:04 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:06:04 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:06:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:06:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:06:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:06:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:06:04 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:06:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:06:04 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:06:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 19:06:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-07 19:06:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 19:06:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 19:06:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 19:06:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 19:06:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-07 19:06:04 --> Final output sent to browser
DEBUG - 2024-03-07 19:06:04 --> Total execution time: 0.0317
ERROR - 2024-03-07 19:06:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:06:04 --> Config Class Initialized
INFO - 2024-03-07 19:06:04 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:06:04 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:06:04 --> Utf8 Class Initialized
INFO - 2024-03-07 19:06:04 --> URI Class Initialized
INFO - 2024-03-07 19:06:04 --> Router Class Initialized
INFO - 2024-03-07 19:06:04 --> Output Class Initialized
INFO - 2024-03-07 19:06:04 --> Security Class Initialized
DEBUG - 2024-03-07 19:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:06:04 --> Input Class Initialized
INFO - 2024-03-07 19:06:04 --> Language Class Initialized
INFO - 2024-03-07 19:06:04 --> Loader Class Initialized
INFO - 2024-03-07 19:06:04 --> Helper loaded: url_helper
INFO - 2024-03-07 19:06:04 --> Helper loaded: file_helper
INFO - 2024-03-07 19:06:04 --> Helper loaded: form_helper
INFO - 2024-03-07 19:06:04 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:06:04 --> Controller Class Initialized
INFO - 2024-03-07 19:06:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-03-07 19:06:04 --> Final output sent to browser
DEBUG - 2024-03-07 19:06:04 --> Total execution time: 0.0249
ERROR - 2024-03-07 19:06:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:06:05 --> Config Class Initialized
INFO - 2024-03-07 19:06:05 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:06:05 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:06:05 --> Utf8 Class Initialized
INFO - 2024-03-07 19:06:05 --> URI Class Initialized
INFO - 2024-03-07 19:06:05 --> Router Class Initialized
INFO - 2024-03-07 19:06:05 --> Output Class Initialized
INFO - 2024-03-07 19:06:05 --> Security Class Initialized
DEBUG - 2024-03-07 19:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:06:05 --> Input Class Initialized
INFO - 2024-03-07 19:06:05 --> Language Class Initialized
INFO - 2024-03-07 19:06:05 --> Loader Class Initialized
INFO - 2024-03-07 19:06:05 --> Helper loaded: url_helper
INFO - 2024-03-07 19:06:05 --> Helper loaded: file_helper
INFO - 2024-03-07 19:06:05 --> Helper loaded: form_helper
INFO - 2024-03-07 19:06:05 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:06:05 --> Controller Class Initialized
INFO - 2024-03-07 19:06:05 --> Form Validation Class Initialized
INFO - 2024-03-07 19:06:05 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:06:05 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:06:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:06:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:06:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:06:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:06:05 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:06:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:06:05 --> Model "ReportModel" initialized
ERROR - 2024-03-07 19:06:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:06:08 --> Config Class Initialized
INFO - 2024-03-07 19:06:08 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:06:08 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:06:08 --> Utf8 Class Initialized
INFO - 2024-03-07 19:06:08 --> URI Class Initialized
INFO - 2024-03-07 19:06:08 --> Router Class Initialized
INFO - 2024-03-07 19:06:08 --> Output Class Initialized
INFO - 2024-03-07 19:06:08 --> Security Class Initialized
DEBUG - 2024-03-07 19:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:06:08 --> Input Class Initialized
INFO - 2024-03-07 19:06:08 --> Language Class Initialized
INFO - 2024-03-07 19:06:08 --> Loader Class Initialized
INFO - 2024-03-07 19:06:08 --> Helper loaded: url_helper
INFO - 2024-03-07 19:06:08 --> Helper loaded: file_helper
INFO - 2024-03-07 19:06:08 --> Helper loaded: form_helper
INFO - 2024-03-07 19:06:08 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:06:08 --> Controller Class Initialized
INFO - 2024-03-07 19:06:08 --> Form Validation Class Initialized
INFO - 2024-03-07 19:06:08 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:06:08 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:06:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:06:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:06:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:06:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:06:08 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:06:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:06:08 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:06:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 19:06:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 19:06:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 19:06:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 19:06:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 19:06:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 19:06:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 19:06:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 19:06:08 --> Final output sent to browser
DEBUG - 2024-03-07 19:06:08 --> Total execution time: 0.0476
ERROR - 2024-03-07 19:06:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:06:08 --> Config Class Initialized
INFO - 2024-03-07 19:06:08 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:06:08 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:06:08 --> Utf8 Class Initialized
INFO - 2024-03-07 19:06:08 --> URI Class Initialized
INFO - 2024-03-07 19:06:08 --> Router Class Initialized
INFO - 2024-03-07 19:06:08 --> Output Class Initialized
INFO - 2024-03-07 19:06:08 --> Security Class Initialized
DEBUG - 2024-03-07 19:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:06:09 --> Input Class Initialized
INFO - 2024-03-07 19:06:09 --> Language Class Initialized
INFO - 2024-03-07 19:06:09 --> Loader Class Initialized
INFO - 2024-03-07 19:06:09 --> Helper loaded: url_helper
INFO - 2024-03-07 19:06:09 --> Helper loaded: file_helper
INFO - 2024-03-07 19:06:09 --> Helper loaded: form_helper
INFO - 2024-03-07 19:06:09 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:06:09 --> Controller Class Initialized
INFO - 2024-03-07 19:06:09 --> Form Validation Class Initialized
INFO - 2024-03-07 19:06:09 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:06:09 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:06:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:06:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:06:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:06:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:06:09 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:06:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:06:09 --> Model "ReportModel" initialized
ERROR - 2024-03-07 19:06:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:06:13 --> Config Class Initialized
INFO - 2024-03-07 19:06:13 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:06:13 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:06:13 --> Utf8 Class Initialized
INFO - 2024-03-07 19:06:13 --> URI Class Initialized
INFO - 2024-03-07 19:06:13 --> Router Class Initialized
INFO - 2024-03-07 19:06:13 --> Output Class Initialized
INFO - 2024-03-07 19:06:13 --> Security Class Initialized
DEBUG - 2024-03-07 19:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:06:13 --> Input Class Initialized
INFO - 2024-03-07 19:06:13 --> Language Class Initialized
INFO - 2024-03-07 19:06:13 --> Loader Class Initialized
INFO - 2024-03-07 19:06:13 --> Helper loaded: url_helper
INFO - 2024-03-07 19:06:13 --> Helper loaded: file_helper
INFO - 2024-03-07 19:06:13 --> Helper loaded: form_helper
INFO - 2024-03-07 19:06:13 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:06:13 --> Controller Class Initialized
INFO - 2024-03-07 19:06:13 --> Form Validation Class Initialized
INFO - 2024-03-07 19:06:13 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:06:13 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:06:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:06:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:06:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:06:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:06:14 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:06:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:06:14 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:06:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 19:06:14 --> Final output sent to browser
DEBUG - 2024-03-07 19:06:14 --> Total execution time: 0.0503
ERROR - 2024-03-07 19:06:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:06:20 --> Config Class Initialized
INFO - 2024-03-07 19:06:20 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:06:20 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:06:20 --> Utf8 Class Initialized
INFO - 2024-03-07 19:06:20 --> URI Class Initialized
INFO - 2024-03-07 19:06:20 --> Router Class Initialized
INFO - 2024-03-07 19:06:20 --> Output Class Initialized
INFO - 2024-03-07 19:06:20 --> Security Class Initialized
DEBUG - 2024-03-07 19:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:06:20 --> Input Class Initialized
INFO - 2024-03-07 19:06:20 --> Language Class Initialized
INFO - 2024-03-07 19:06:20 --> Loader Class Initialized
INFO - 2024-03-07 19:06:20 --> Helper loaded: url_helper
INFO - 2024-03-07 19:06:20 --> Helper loaded: file_helper
INFO - 2024-03-07 19:06:20 --> Helper loaded: form_helper
INFO - 2024-03-07 19:06:20 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:06:20 --> Controller Class Initialized
INFO - 2024-03-07 19:06:20 --> Form Validation Class Initialized
INFO - 2024-03-07 19:06:20 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:06:20 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:06:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:06:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:06:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:06:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:06:20 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:06:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:06:20 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:06:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 19:06:20 --> Final output sent to browser
DEBUG - 2024-03-07 19:06:20 --> Total execution time: 0.0375
ERROR - 2024-03-07 19:06:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:06:25 --> Config Class Initialized
INFO - 2024-03-07 19:06:25 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:06:25 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:06:25 --> Utf8 Class Initialized
INFO - 2024-03-07 19:06:25 --> URI Class Initialized
INFO - 2024-03-07 19:06:25 --> Router Class Initialized
INFO - 2024-03-07 19:06:25 --> Output Class Initialized
INFO - 2024-03-07 19:06:25 --> Security Class Initialized
DEBUG - 2024-03-07 19:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:06:25 --> Input Class Initialized
INFO - 2024-03-07 19:06:25 --> Language Class Initialized
INFO - 2024-03-07 19:06:25 --> Loader Class Initialized
INFO - 2024-03-07 19:06:25 --> Helper loaded: url_helper
INFO - 2024-03-07 19:06:25 --> Helper loaded: file_helper
INFO - 2024-03-07 19:06:25 --> Helper loaded: form_helper
INFO - 2024-03-07 19:06:25 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:06:25 --> Controller Class Initialized
INFO - 2024-03-07 19:06:25 --> Form Validation Class Initialized
INFO - 2024-03-07 19:06:25 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:06:25 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:06:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:06:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:06:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:06:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:06:25 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:06:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:06:25 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:06:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 19:06:25 --> Final output sent to browser
DEBUG - 2024-03-07 19:06:25 --> Total execution time: 0.0397
ERROR - 2024-03-07 19:06:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:06:31 --> Config Class Initialized
INFO - 2024-03-07 19:06:31 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:06:31 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:06:31 --> Utf8 Class Initialized
INFO - 2024-03-07 19:06:31 --> URI Class Initialized
INFO - 2024-03-07 19:06:31 --> Router Class Initialized
INFO - 2024-03-07 19:06:31 --> Output Class Initialized
INFO - 2024-03-07 19:06:31 --> Security Class Initialized
DEBUG - 2024-03-07 19:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:06:31 --> Input Class Initialized
INFO - 2024-03-07 19:06:31 --> Language Class Initialized
INFO - 2024-03-07 19:06:31 --> Loader Class Initialized
INFO - 2024-03-07 19:06:31 --> Helper loaded: url_helper
INFO - 2024-03-07 19:06:31 --> Helper loaded: file_helper
INFO - 2024-03-07 19:06:31 --> Helper loaded: form_helper
INFO - 2024-03-07 19:06:31 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:06:31 --> Controller Class Initialized
INFO - 2024-03-07 19:06:31 --> Form Validation Class Initialized
INFO - 2024-03-07 19:06:31 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:06:31 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:06:31 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:06:31 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:06:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:06:31 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:06:31 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:06:31 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:06:31 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:06:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 19:06:31 --> Final output sent to browser
DEBUG - 2024-03-07 19:06:31 --> Total execution time: 0.0429
ERROR - 2024-03-07 19:06:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:06:52 --> Config Class Initialized
INFO - 2024-03-07 19:06:52 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:06:52 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:06:52 --> Utf8 Class Initialized
INFO - 2024-03-07 19:06:52 --> URI Class Initialized
INFO - 2024-03-07 19:06:52 --> Router Class Initialized
INFO - 2024-03-07 19:06:52 --> Output Class Initialized
INFO - 2024-03-07 19:06:52 --> Security Class Initialized
DEBUG - 2024-03-07 19:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:06:52 --> Input Class Initialized
INFO - 2024-03-07 19:06:52 --> Language Class Initialized
INFO - 2024-03-07 19:06:52 --> Loader Class Initialized
INFO - 2024-03-07 19:06:52 --> Helper loaded: url_helper
INFO - 2024-03-07 19:06:52 --> Helper loaded: file_helper
INFO - 2024-03-07 19:06:52 --> Helper loaded: form_helper
INFO - 2024-03-07 19:06:52 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:06:52 --> Controller Class Initialized
INFO - 2024-03-07 19:06:52 --> Form Validation Class Initialized
INFO - 2024-03-07 19:06:52 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:06:52 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:06:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:06:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:06:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:06:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:06:52 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:06:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:06:52 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:06:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 19:06:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 19:06:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 19:06:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 19:06:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 19:06:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 19:06:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 19:06:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 19:06:52 --> Final output sent to browser
DEBUG - 2024-03-07 19:06:52 --> Total execution time: 0.0389
ERROR - 2024-03-07 19:06:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:06:53 --> Config Class Initialized
INFO - 2024-03-07 19:06:53 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:06:53 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:06:53 --> Utf8 Class Initialized
INFO - 2024-03-07 19:06:53 --> URI Class Initialized
INFO - 2024-03-07 19:06:53 --> Router Class Initialized
INFO - 2024-03-07 19:06:53 --> Output Class Initialized
INFO - 2024-03-07 19:06:53 --> Security Class Initialized
DEBUG - 2024-03-07 19:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:06:53 --> Input Class Initialized
INFO - 2024-03-07 19:06:53 --> Language Class Initialized
INFO - 2024-03-07 19:06:53 --> Loader Class Initialized
INFO - 2024-03-07 19:06:53 --> Helper loaded: url_helper
INFO - 2024-03-07 19:06:53 --> Helper loaded: file_helper
INFO - 2024-03-07 19:06:53 --> Helper loaded: form_helper
INFO - 2024-03-07 19:06:53 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:06:53 --> Controller Class Initialized
INFO - 2024-03-07 19:06:53 --> Form Validation Class Initialized
INFO - 2024-03-07 19:06:53 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:06:53 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:06:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:06:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:06:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:06:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:06:53 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:06:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:06:53 --> Model "ReportModel" initialized
ERROR - 2024-03-07 19:07:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:07:21 --> Config Class Initialized
INFO - 2024-03-07 19:07:21 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:07:21 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:07:21 --> Utf8 Class Initialized
INFO - 2024-03-07 19:07:21 --> URI Class Initialized
DEBUG - 2024-03-07 19:07:21 --> No URI present. Default controller set.
INFO - 2024-03-07 19:07:21 --> Router Class Initialized
INFO - 2024-03-07 19:07:21 --> Output Class Initialized
INFO - 2024-03-07 19:07:21 --> Security Class Initialized
DEBUG - 2024-03-07 19:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:07:21 --> Input Class Initialized
INFO - 2024-03-07 19:07:21 --> Language Class Initialized
INFO - 2024-03-07 19:07:21 --> Loader Class Initialized
INFO - 2024-03-07 19:07:21 --> Helper loaded: url_helper
INFO - 2024-03-07 19:07:21 --> Helper loaded: file_helper
INFO - 2024-03-07 19:07:21 --> Helper loaded: form_helper
INFO - 2024-03-07 19:07:21 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:07:21 --> Controller Class Initialized
INFO - 2024-03-07 19:07:21 --> Model "LoginModel" initialized
INFO - 2024-03-07 19:07:21 --> Form Validation Class Initialized
INFO - 2024-03-07 19:07:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-07 19:07:21 --> Final output sent to browser
DEBUG - 2024-03-07 19:07:21 --> Total execution time: 0.0296
ERROR - 2024-03-07 19:07:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:07:38 --> Config Class Initialized
INFO - 2024-03-07 19:07:38 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:07:38 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:07:38 --> Utf8 Class Initialized
INFO - 2024-03-07 19:07:38 --> URI Class Initialized
INFO - 2024-03-07 19:07:38 --> Router Class Initialized
INFO - 2024-03-07 19:07:38 --> Output Class Initialized
INFO - 2024-03-07 19:07:38 --> Security Class Initialized
DEBUG - 2024-03-07 19:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:07:38 --> Input Class Initialized
INFO - 2024-03-07 19:07:38 --> Language Class Initialized
INFO - 2024-03-07 19:07:38 --> Loader Class Initialized
INFO - 2024-03-07 19:07:38 --> Helper loaded: url_helper
INFO - 2024-03-07 19:07:38 --> Helper loaded: file_helper
INFO - 2024-03-07 19:07:38 --> Helper loaded: form_helper
INFO - 2024-03-07 19:07:38 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:07:38 --> Controller Class Initialized
INFO - 2024-03-07 19:07:38 --> Model "LoginModel" initialized
INFO - 2024-03-07 19:07:38 --> Form Validation Class Initialized
INFO - 2024-03-07 19:07:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-07 19:07:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:07:38 --> Config Class Initialized
INFO - 2024-03-07 19:07:38 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:07:38 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:07:38 --> Utf8 Class Initialized
INFO - 2024-03-07 19:07:38 --> URI Class Initialized
INFO - 2024-03-07 19:07:38 --> Router Class Initialized
INFO - 2024-03-07 19:07:38 --> Output Class Initialized
INFO - 2024-03-07 19:07:38 --> Security Class Initialized
DEBUG - 2024-03-07 19:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:07:38 --> Input Class Initialized
INFO - 2024-03-07 19:07:38 --> Language Class Initialized
INFO - 2024-03-07 19:07:38 --> Loader Class Initialized
INFO - 2024-03-07 19:07:38 --> Helper loaded: url_helper
INFO - 2024-03-07 19:07:38 --> Helper loaded: file_helper
INFO - 2024-03-07 19:07:38 --> Helper loaded: form_helper
INFO - 2024-03-07 19:07:38 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:07:38 --> Controller Class Initialized
INFO - 2024-03-07 19:07:38 --> Model "LoginModel" initialized
INFO - 2024-03-07 19:07:38 --> Form Validation Class Initialized
INFO - 2024-03-07 19:07:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-07 19:07:38 --> Final output sent to browser
DEBUG - 2024-03-07 19:07:38 --> Total execution time: 0.0211
ERROR - 2024-03-07 19:07:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:07:52 --> Config Class Initialized
INFO - 2024-03-07 19:07:52 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:07:52 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:07:52 --> Utf8 Class Initialized
INFO - 2024-03-07 19:07:52 --> URI Class Initialized
INFO - 2024-03-07 19:07:52 --> Router Class Initialized
INFO - 2024-03-07 19:07:52 --> Output Class Initialized
INFO - 2024-03-07 19:07:52 --> Security Class Initialized
DEBUG - 2024-03-07 19:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:07:52 --> Input Class Initialized
INFO - 2024-03-07 19:07:52 --> Language Class Initialized
INFO - 2024-03-07 19:07:52 --> Loader Class Initialized
INFO - 2024-03-07 19:07:52 --> Helper loaded: url_helper
INFO - 2024-03-07 19:07:52 --> Helper loaded: file_helper
INFO - 2024-03-07 19:07:52 --> Helper loaded: form_helper
INFO - 2024-03-07 19:07:52 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:07:52 --> Controller Class Initialized
INFO - 2024-03-07 19:07:52 --> Model "LoginModel" initialized
INFO - 2024-03-07 19:07:52 --> Form Validation Class Initialized
INFO - 2024-03-07 19:07:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-07 19:07:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:07:52 --> Config Class Initialized
INFO - 2024-03-07 19:07:52 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:07:52 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:07:52 --> Utf8 Class Initialized
INFO - 2024-03-07 19:07:52 --> URI Class Initialized
INFO - 2024-03-07 19:07:52 --> Router Class Initialized
INFO - 2024-03-07 19:07:52 --> Output Class Initialized
INFO - 2024-03-07 19:07:52 --> Security Class Initialized
DEBUG - 2024-03-07 19:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:07:52 --> Input Class Initialized
INFO - 2024-03-07 19:07:52 --> Language Class Initialized
INFO - 2024-03-07 19:07:52 --> Loader Class Initialized
INFO - 2024-03-07 19:07:52 --> Helper loaded: url_helper
INFO - 2024-03-07 19:07:52 --> Helper loaded: file_helper
INFO - 2024-03-07 19:07:52 --> Helper loaded: form_helper
INFO - 2024-03-07 19:07:52 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:07:52 --> Controller Class Initialized
INFO - 2024-03-07 19:07:52 --> Model "LoginModel" initialized
INFO - 2024-03-07 19:07:52 --> Form Validation Class Initialized
INFO - 2024-03-07 19:07:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-07 19:07:52 --> Final output sent to browser
DEBUG - 2024-03-07 19:07:52 --> Total execution time: 0.0309
ERROR - 2024-03-07 19:08:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:08:08 --> Config Class Initialized
INFO - 2024-03-07 19:08:08 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:08:08 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:08:08 --> Utf8 Class Initialized
INFO - 2024-03-07 19:08:08 --> URI Class Initialized
INFO - 2024-03-07 19:08:08 --> Router Class Initialized
INFO - 2024-03-07 19:08:08 --> Output Class Initialized
INFO - 2024-03-07 19:08:08 --> Security Class Initialized
DEBUG - 2024-03-07 19:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:08:08 --> Input Class Initialized
INFO - 2024-03-07 19:08:08 --> Language Class Initialized
INFO - 2024-03-07 19:08:08 --> Loader Class Initialized
INFO - 2024-03-07 19:08:08 --> Helper loaded: url_helper
INFO - 2024-03-07 19:08:08 --> Helper loaded: file_helper
INFO - 2024-03-07 19:08:08 --> Helper loaded: form_helper
INFO - 2024-03-07 19:08:08 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:08:08 --> Controller Class Initialized
INFO - 2024-03-07 19:08:08 --> Model "LoginModel" initialized
INFO - 2024-03-07 19:08:08 --> Form Validation Class Initialized
INFO - 2024-03-07 19:08:08 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-07 19:08:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:08:08 --> Config Class Initialized
INFO - 2024-03-07 19:08:08 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:08:08 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:08:08 --> Utf8 Class Initialized
INFO - 2024-03-07 19:08:08 --> URI Class Initialized
INFO - 2024-03-07 19:08:08 --> Router Class Initialized
INFO - 2024-03-07 19:08:08 --> Output Class Initialized
INFO - 2024-03-07 19:08:08 --> Security Class Initialized
DEBUG - 2024-03-07 19:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:08:08 --> Input Class Initialized
INFO - 2024-03-07 19:08:08 --> Language Class Initialized
INFO - 2024-03-07 19:08:08 --> Loader Class Initialized
INFO - 2024-03-07 19:08:08 --> Helper loaded: url_helper
INFO - 2024-03-07 19:08:08 --> Helper loaded: file_helper
INFO - 2024-03-07 19:08:08 --> Helper loaded: form_helper
INFO - 2024-03-07 19:08:08 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:08:08 --> Controller Class Initialized
INFO - 2024-03-07 19:08:08 --> Form Validation Class Initialized
INFO - 2024-03-07 19:08:08 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:08:08 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:08:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:08:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:08:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:08:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:08:08 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:08:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:08:08 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:08:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 19:08:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-07 19:08:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 19:08:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 19:08:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 19:08:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 19:08:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-07 19:08:08 --> Final output sent to browser
DEBUG - 2024-03-07 19:08:08 --> Total execution time: 0.0247
ERROR - 2024-03-07 19:08:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:08:09 --> Config Class Initialized
INFO - 2024-03-07 19:08:09 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:08:09 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:08:09 --> Utf8 Class Initialized
INFO - 2024-03-07 19:08:09 --> URI Class Initialized
INFO - 2024-03-07 19:08:09 --> Router Class Initialized
INFO - 2024-03-07 19:08:09 --> Output Class Initialized
INFO - 2024-03-07 19:08:09 --> Security Class Initialized
DEBUG - 2024-03-07 19:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:08:09 --> Input Class Initialized
INFO - 2024-03-07 19:08:09 --> Language Class Initialized
INFO - 2024-03-07 19:08:09 --> Loader Class Initialized
INFO - 2024-03-07 19:08:09 --> Helper loaded: url_helper
INFO - 2024-03-07 19:08:09 --> Helper loaded: file_helper
INFO - 2024-03-07 19:08:09 --> Helper loaded: form_helper
INFO - 2024-03-07 19:08:09 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:08:09 --> Controller Class Initialized
INFO - 2024-03-07 19:08:09 --> Form Validation Class Initialized
INFO - 2024-03-07 19:08:09 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:08:09 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:08:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:08:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:08:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:08:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:08:09 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:08:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:08:09 --> Model "ReportModel" initialized
ERROR - 2024-03-07 19:08:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:08:12 --> Config Class Initialized
INFO - 2024-03-07 19:08:12 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:08:12 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:08:12 --> Utf8 Class Initialized
INFO - 2024-03-07 19:08:12 --> URI Class Initialized
INFO - 2024-03-07 19:08:12 --> Router Class Initialized
INFO - 2024-03-07 19:08:12 --> Output Class Initialized
INFO - 2024-03-07 19:08:12 --> Security Class Initialized
DEBUG - 2024-03-07 19:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:08:12 --> Input Class Initialized
INFO - 2024-03-07 19:08:12 --> Language Class Initialized
INFO - 2024-03-07 19:08:12 --> Loader Class Initialized
INFO - 2024-03-07 19:08:12 --> Helper loaded: url_helper
INFO - 2024-03-07 19:08:12 --> Helper loaded: file_helper
INFO - 2024-03-07 19:08:12 --> Helper loaded: form_helper
INFO - 2024-03-07 19:08:12 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:08:12 --> Controller Class Initialized
INFO - 2024-03-07 19:08:12 --> Form Validation Class Initialized
INFO - 2024-03-07 19:08:12 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:08:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 19:08:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 19:08:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 19:08:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 19:08:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 19:08:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 19:08:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 19:08:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 19:08:12 --> Final output sent to browser
DEBUG - 2024-03-07 19:08:12 --> Total execution time: 0.0381
ERROR - 2024-03-07 19:08:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:08:12 --> Config Class Initialized
INFO - 2024-03-07 19:08:12 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:08:12 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:08:12 --> Utf8 Class Initialized
INFO - 2024-03-07 19:08:12 --> URI Class Initialized
INFO - 2024-03-07 19:08:12 --> Router Class Initialized
INFO - 2024-03-07 19:08:12 --> Output Class Initialized
INFO - 2024-03-07 19:08:12 --> Security Class Initialized
DEBUG - 2024-03-07 19:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:08:12 --> Input Class Initialized
INFO - 2024-03-07 19:08:12 --> Language Class Initialized
INFO - 2024-03-07 19:08:12 --> Loader Class Initialized
INFO - 2024-03-07 19:08:12 --> Helper loaded: url_helper
INFO - 2024-03-07 19:08:12 --> Helper loaded: file_helper
INFO - 2024-03-07 19:08:12 --> Helper loaded: form_helper
INFO - 2024-03-07 19:08:12 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:08:12 --> Controller Class Initialized
INFO - 2024-03-07 19:08:12 --> Form Validation Class Initialized
INFO - 2024-03-07 19:08:12 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:08:12 --> Model "ReportModel" initialized
ERROR - 2024-03-07 19:08:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:08:15 --> Config Class Initialized
INFO - 2024-03-07 19:08:15 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:08:15 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:08:15 --> Utf8 Class Initialized
INFO - 2024-03-07 19:08:15 --> URI Class Initialized
INFO - 2024-03-07 19:08:15 --> Router Class Initialized
INFO - 2024-03-07 19:08:15 --> Output Class Initialized
INFO - 2024-03-07 19:08:15 --> Security Class Initialized
DEBUG - 2024-03-07 19:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:08:15 --> Input Class Initialized
INFO - 2024-03-07 19:08:15 --> Language Class Initialized
INFO - 2024-03-07 19:08:15 --> Loader Class Initialized
INFO - 2024-03-07 19:08:15 --> Helper loaded: url_helper
INFO - 2024-03-07 19:08:15 --> Helper loaded: file_helper
INFO - 2024-03-07 19:08:15 --> Helper loaded: form_helper
INFO - 2024-03-07 19:08:15 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:08:15 --> Controller Class Initialized
INFO - 2024-03-07 19:08:15 --> Form Validation Class Initialized
INFO - 2024-03-07 19:08:15 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:08:15 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:08:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:08:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:08:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:08:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:08:15 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:08:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:08:15 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:08:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 19:08:15 --> Final output sent to browser
DEBUG - 2024-03-07 19:08:15 --> Total execution time: 0.0197
ERROR - 2024-03-07 19:08:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:08:35 --> Config Class Initialized
INFO - 2024-03-07 19:08:35 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:08:35 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:08:35 --> Utf8 Class Initialized
INFO - 2024-03-07 19:08:35 --> URI Class Initialized
INFO - 2024-03-07 19:08:35 --> Router Class Initialized
INFO - 2024-03-07 19:08:35 --> Output Class Initialized
INFO - 2024-03-07 19:08:35 --> Security Class Initialized
DEBUG - 2024-03-07 19:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:08:35 --> Input Class Initialized
INFO - 2024-03-07 19:08:35 --> Language Class Initialized
INFO - 2024-03-07 19:08:35 --> Loader Class Initialized
INFO - 2024-03-07 19:08:35 --> Helper loaded: url_helper
INFO - 2024-03-07 19:08:35 --> Helper loaded: file_helper
INFO - 2024-03-07 19:08:35 --> Helper loaded: form_helper
INFO - 2024-03-07 19:08:35 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:08:35 --> Controller Class Initialized
INFO - 2024-03-07 19:08:35 --> Form Validation Class Initialized
INFO - 2024-03-07 19:08:35 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:08:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 19:08:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 19:08:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 19:08:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 19:08:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 19:08:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 19:08:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 19:08:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 19:08:35 --> Final output sent to browser
DEBUG - 2024-03-07 19:08:35 --> Total execution time: 0.0693
ERROR - 2024-03-07 19:08:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:08:35 --> Config Class Initialized
INFO - 2024-03-07 19:08:35 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:08:35 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:08:35 --> Utf8 Class Initialized
INFO - 2024-03-07 19:08:35 --> URI Class Initialized
INFO - 2024-03-07 19:08:35 --> Router Class Initialized
INFO - 2024-03-07 19:08:35 --> Output Class Initialized
INFO - 2024-03-07 19:08:35 --> Security Class Initialized
DEBUG - 2024-03-07 19:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:08:35 --> Input Class Initialized
INFO - 2024-03-07 19:08:35 --> Language Class Initialized
INFO - 2024-03-07 19:08:35 --> Loader Class Initialized
INFO - 2024-03-07 19:08:35 --> Helper loaded: url_helper
INFO - 2024-03-07 19:08:35 --> Helper loaded: file_helper
INFO - 2024-03-07 19:08:35 --> Helper loaded: form_helper
INFO - 2024-03-07 19:08:35 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:08:35 --> Controller Class Initialized
INFO - 2024-03-07 19:08:35 --> Form Validation Class Initialized
INFO - 2024-03-07 19:08:35 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:08:35 --> Model "ReportModel" initialized
ERROR - 2024-03-07 19:08:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:08:37 --> Config Class Initialized
INFO - 2024-03-07 19:08:37 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:08:37 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:08:37 --> Utf8 Class Initialized
INFO - 2024-03-07 19:08:37 --> URI Class Initialized
INFO - 2024-03-07 19:08:37 --> Router Class Initialized
INFO - 2024-03-07 19:08:37 --> Output Class Initialized
INFO - 2024-03-07 19:08:37 --> Security Class Initialized
DEBUG - 2024-03-07 19:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:08:37 --> Input Class Initialized
INFO - 2024-03-07 19:08:37 --> Language Class Initialized
INFO - 2024-03-07 19:08:37 --> Loader Class Initialized
INFO - 2024-03-07 19:08:37 --> Helper loaded: url_helper
INFO - 2024-03-07 19:08:37 --> Helper loaded: file_helper
INFO - 2024-03-07 19:08:37 --> Helper loaded: form_helper
INFO - 2024-03-07 19:08:37 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:08:38 --> Controller Class Initialized
INFO - 2024-03-07 19:08:38 --> Form Validation Class Initialized
INFO - 2024-03-07 19:08:38 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:08:38 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:08:38 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:08:38 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:08:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:08:38 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:08:38 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:08:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:08:38 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:08:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 19:08:38 --> Final output sent to browser
DEBUG - 2024-03-07 19:08:38 --> Total execution time: 0.0313
ERROR - 2024-03-07 19:11:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:11:25 --> Config Class Initialized
INFO - 2024-03-07 19:11:25 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:11:25 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:11:25 --> Utf8 Class Initialized
INFO - 2024-03-07 19:11:25 --> URI Class Initialized
INFO - 2024-03-07 19:11:25 --> Router Class Initialized
INFO - 2024-03-07 19:11:25 --> Output Class Initialized
INFO - 2024-03-07 19:11:25 --> Security Class Initialized
DEBUG - 2024-03-07 19:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:11:25 --> Input Class Initialized
INFO - 2024-03-07 19:11:25 --> Language Class Initialized
INFO - 2024-03-07 19:11:25 --> Loader Class Initialized
INFO - 2024-03-07 19:11:25 --> Helper loaded: url_helper
INFO - 2024-03-07 19:11:25 --> Helper loaded: file_helper
INFO - 2024-03-07 19:11:25 --> Helper loaded: form_helper
INFO - 2024-03-07 19:11:25 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:11:25 --> Controller Class Initialized
INFO - 2024-03-07 19:11:25 --> Model "LoginModel" initialized
INFO - 2024-03-07 19:11:25 --> Form Validation Class Initialized
INFO - 2024-03-07 19:11:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-07 19:11:25 --> Final output sent to browser
DEBUG - 2024-03-07 19:11:25 --> Total execution time: 0.0323
ERROR - 2024-03-07 19:11:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:11:39 --> Config Class Initialized
INFO - 2024-03-07 19:11:39 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:11:39 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:11:39 --> Utf8 Class Initialized
INFO - 2024-03-07 19:11:39 --> URI Class Initialized
INFO - 2024-03-07 19:11:39 --> Router Class Initialized
INFO - 2024-03-07 19:11:39 --> Output Class Initialized
INFO - 2024-03-07 19:11:39 --> Security Class Initialized
DEBUG - 2024-03-07 19:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:11:39 --> Input Class Initialized
INFO - 2024-03-07 19:11:39 --> Language Class Initialized
INFO - 2024-03-07 19:11:39 --> Loader Class Initialized
INFO - 2024-03-07 19:11:39 --> Helper loaded: url_helper
INFO - 2024-03-07 19:11:39 --> Helper loaded: file_helper
INFO - 2024-03-07 19:11:39 --> Helper loaded: form_helper
INFO - 2024-03-07 19:11:39 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:11:39 --> Controller Class Initialized
INFO - 2024-03-07 19:11:39 --> Model "LoginModel" initialized
INFO - 2024-03-07 19:11:39 --> Form Validation Class Initialized
INFO - 2024-03-07 19:11:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-07 19:11:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:11:39 --> Config Class Initialized
INFO - 2024-03-07 19:11:39 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:11:39 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:11:39 --> Utf8 Class Initialized
INFO - 2024-03-07 19:11:39 --> URI Class Initialized
INFO - 2024-03-07 19:11:39 --> Router Class Initialized
INFO - 2024-03-07 19:11:39 --> Output Class Initialized
INFO - 2024-03-07 19:11:39 --> Security Class Initialized
DEBUG - 2024-03-07 19:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:11:39 --> Input Class Initialized
INFO - 2024-03-07 19:11:39 --> Language Class Initialized
INFO - 2024-03-07 19:11:39 --> Loader Class Initialized
INFO - 2024-03-07 19:11:39 --> Helper loaded: url_helper
INFO - 2024-03-07 19:11:39 --> Helper loaded: file_helper
INFO - 2024-03-07 19:11:39 --> Helper loaded: form_helper
INFO - 2024-03-07 19:11:39 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:11:39 --> Controller Class Initialized
INFO - 2024-03-07 19:11:39 --> Form Validation Class Initialized
INFO - 2024-03-07 19:11:39 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:11:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 19:11:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-07 19:11:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 19:11:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 19:11:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 19:11:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 19:11:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-07 19:11:39 --> Final output sent to browser
DEBUG - 2024-03-07 19:11:39 --> Total execution time: 0.0310
ERROR - 2024-03-07 19:11:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:11:39 --> Config Class Initialized
INFO - 2024-03-07 19:11:39 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:11:39 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:11:39 --> Utf8 Class Initialized
INFO - 2024-03-07 19:11:39 --> URI Class Initialized
INFO - 2024-03-07 19:11:39 --> Router Class Initialized
INFO - 2024-03-07 19:11:39 --> Output Class Initialized
INFO - 2024-03-07 19:11:39 --> Security Class Initialized
DEBUG - 2024-03-07 19:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:11:39 --> Input Class Initialized
INFO - 2024-03-07 19:11:39 --> Language Class Initialized
INFO - 2024-03-07 19:11:39 --> Loader Class Initialized
INFO - 2024-03-07 19:11:39 --> Helper loaded: url_helper
INFO - 2024-03-07 19:11:39 --> Helper loaded: file_helper
INFO - 2024-03-07 19:11:39 --> Helper loaded: form_helper
INFO - 2024-03-07 19:11:39 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:11:39 --> Controller Class Initialized
INFO - 2024-03-07 19:11:39 --> Form Validation Class Initialized
INFO - 2024-03-07 19:11:39 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:11:39 --> Model "ReportModel" initialized
ERROR - 2024-03-07 19:11:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:11:41 --> Config Class Initialized
INFO - 2024-03-07 19:11:41 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:11:41 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:11:41 --> Utf8 Class Initialized
INFO - 2024-03-07 19:11:41 --> URI Class Initialized
INFO - 2024-03-07 19:11:41 --> Router Class Initialized
INFO - 2024-03-07 19:11:41 --> Output Class Initialized
INFO - 2024-03-07 19:11:41 --> Security Class Initialized
DEBUG - 2024-03-07 19:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:11:41 --> Input Class Initialized
INFO - 2024-03-07 19:11:41 --> Language Class Initialized
INFO - 2024-03-07 19:11:41 --> Loader Class Initialized
INFO - 2024-03-07 19:11:41 --> Helper loaded: url_helper
INFO - 2024-03-07 19:11:41 --> Helper loaded: file_helper
INFO - 2024-03-07 19:11:41 --> Helper loaded: form_helper
INFO - 2024-03-07 19:11:41 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:11:41 --> Controller Class Initialized
INFO - 2024-03-07 19:11:41 --> Form Validation Class Initialized
INFO - 2024-03-07 19:11:41 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:11:41 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:11:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:11:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:11:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:11:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:11:41 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:11:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:11:41 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:11:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 19:11:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 19:11:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 19:11:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 19:11:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 19:11:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 19:11:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 19:11:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 19:11:41 --> Final output sent to browser
DEBUG - 2024-03-07 19:11:41 --> Total execution time: 0.0358
ERROR - 2024-03-07 19:11:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:11:42 --> Config Class Initialized
INFO - 2024-03-07 19:11:42 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:11:42 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:11:42 --> Utf8 Class Initialized
INFO - 2024-03-07 19:11:42 --> URI Class Initialized
INFO - 2024-03-07 19:11:42 --> Router Class Initialized
INFO - 2024-03-07 19:11:42 --> Output Class Initialized
INFO - 2024-03-07 19:11:42 --> Security Class Initialized
DEBUG - 2024-03-07 19:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:11:42 --> Input Class Initialized
INFO - 2024-03-07 19:11:42 --> Language Class Initialized
INFO - 2024-03-07 19:11:42 --> Loader Class Initialized
INFO - 2024-03-07 19:11:42 --> Helper loaded: url_helper
INFO - 2024-03-07 19:11:42 --> Helper loaded: file_helper
INFO - 2024-03-07 19:11:42 --> Helper loaded: form_helper
INFO - 2024-03-07 19:11:42 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:11:42 --> Controller Class Initialized
INFO - 2024-03-07 19:11:42 --> Form Validation Class Initialized
INFO - 2024-03-07 19:11:42 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:11:42 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:11:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:11:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:11:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:11:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:11:42 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:11:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:11:42 --> Model "ReportModel" initialized
ERROR - 2024-03-07 19:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:11:45 --> Config Class Initialized
INFO - 2024-03-07 19:11:45 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:11:45 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:11:45 --> Utf8 Class Initialized
INFO - 2024-03-07 19:11:45 --> URI Class Initialized
INFO - 2024-03-07 19:11:45 --> Router Class Initialized
INFO - 2024-03-07 19:11:45 --> Output Class Initialized
INFO - 2024-03-07 19:11:45 --> Security Class Initialized
DEBUG - 2024-03-07 19:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:11:45 --> Input Class Initialized
INFO - 2024-03-07 19:11:45 --> Language Class Initialized
INFO - 2024-03-07 19:11:45 --> Loader Class Initialized
INFO - 2024-03-07 19:11:45 --> Helper loaded: url_helper
INFO - 2024-03-07 19:11:45 --> Helper loaded: file_helper
INFO - 2024-03-07 19:11:45 --> Helper loaded: form_helper
INFO - 2024-03-07 19:11:45 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:11:45 --> Controller Class Initialized
INFO - 2024-03-07 19:11:45 --> Form Validation Class Initialized
INFO - 2024-03-07 19:11:45 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:11:45 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:11:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:11:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:11:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:11:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:11:45 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:11:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:11:45 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:11:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 19:11:45 --> Final output sent to browser
DEBUG - 2024-03-07 19:11:45 --> Total execution time: 0.0411
ERROR - 2024-03-07 19:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:13:12 --> Config Class Initialized
INFO - 2024-03-07 19:13:12 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:13:12 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:13:12 --> Utf8 Class Initialized
INFO - 2024-03-07 19:13:12 --> URI Class Initialized
INFO - 2024-03-07 19:13:12 --> Router Class Initialized
INFO - 2024-03-07 19:13:12 --> Output Class Initialized
INFO - 2024-03-07 19:13:12 --> Security Class Initialized
DEBUG - 2024-03-07 19:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:13:12 --> Input Class Initialized
INFO - 2024-03-07 19:13:12 --> Language Class Initialized
INFO - 2024-03-07 19:13:12 --> Loader Class Initialized
INFO - 2024-03-07 19:13:12 --> Helper loaded: url_helper
INFO - 2024-03-07 19:13:12 --> Helper loaded: file_helper
INFO - 2024-03-07 19:13:12 --> Helper loaded: form_helper
INFO - 2024-03-07 19:13:12 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:13:12 --> Controller Class Initialized
INFO - 2024-03-07 19:13:12 --> Form Validation Class Initialized
INFO - 2024-03-07 19:13:12 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:13:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 19:13:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 19:13:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 19:13:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 19:13:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 19:13:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 19:13:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 19:13:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 19:13:12 --> Final output sent to browser
DEBUG - 2024-03-07 19:13:12 --> Total execution time: 0.0421
ERROR - 2024-03-07 19:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:13:12 --> Config Class Initialized
INFO - 2024-03-07 19:13:12 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:13:12 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:13:12 --> Utf8 Class Initialized
INFO - 2024-03-07 19:13:12 --> URI Class Initialized
INFO - 2024-03-07 19:13:12 --> Router Class Initialized
INFO - 2024-03-07 19:13:12 --> Output Class Initialized
INFO - 2024-03-07 19:13:12 --> Security Class Initialized
DEBUG - 2024-03-07 19:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:13:12 --> Input Class Initialized
INFO - 2024-03-07 19:13:12 --> Language Class Initialized
INFO - 2024-03-07 19:13:12 --> Loader Class Initialized
INFO - 2024-03-07 19:13:12 --> Helper loaded: url_helper
INFO - 2024-03-07 19:13:12 --> Helper loaded: file_helper
INFO - 2024-03-07 19:13:12 --> Helper loaded: form_helper
INFO - 2024-03-07 19:13:12 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:13:12 --> Controller Class Initialized
INFO - 2024-03-07 19:13:12 --> Form Validation Class Initialized
INFO - 2024-03-07 19:13:12 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:13:12 --> Model "ReportModel" initialized
ERROR - 2024-03-07 19:13:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:13:15 --> Config Class Initialized
INFO - 2024-03-07 19:13:15 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:13:15 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:13:15 --> Utf8 Class Initialized
INFO - 2024-03-07 19:13:15 --> URI Class Initialized
INFO - 2024-03-07 19:13:15 --> Router Class Initialized
INFO - 2024-03-07 19:13:15 --> Output Class Initialized
INFO - 2024-03-07 19:13:15 --> Security Class Initialized
DEBUG - 2024-03-07 19:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:13:15 --> Input Class Initialized
INFO - 2024-03-07 19:13:15 --> Language Class Initialized
INFO - 2024-03-07 19:13:15 --> Loader Class Initialized
INFO - 2024-03-07 19:13:15 --> Helper loaded: url_helper
INFO - 2024-03-07 19:13:15 --> Helper loaded: file_helper
INFO - 2024-03-07 19:13:15 --> Helper loaded: form_helper
INFO - 2024-03-07 19:13:15 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:13:15 --> Controller Class Initialized
INFO - 2024-03-07 19:13:15 --> Form Validation Class Initialized
INFO - 2024-03-07 19:13:15 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:13:15 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:13:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:13:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:13:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:13:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:13:15 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:13:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:13:15 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:13:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 19:13:15 --> Final output sent to browser
DEBUG - 2024-03-07 19:13:15 --> Total execution time: 0.0351
ERROR - 2024-03-07 19:15:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:15:02 --> Config Class Initialized
INFO - 2024-03-07 19:15:02 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:15:02 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:15:02 --> Utf8 Class Initialized
INFO - 2024-03-07 19:15:02 --> URI Class Initialized
INFO - 2024-03-07 19:15:02 --> Router Class Initialized
INFO - 2024-03-07 19:15:02 --> Output Class Initialized
INFO - 2024-03-07 19:15:02 --> Security Class Initialized
DEBUG - 2024-03-07 19:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:15:02 --> Input Class Initialized
INFO - 2024-03-07 19:15:02 --> Language Class Initialized
INFO - 2024-03-07 19:15:02 --> Loader Class Initialized
INFO - 2024-03-07 19:15:02 --> Helper loaded: url_helper
INFO - 2024-03-07 19:15:02 --> Helper loaded: file_helper
INFO - 2024-03-07 19:15:02 --> Helper loaded: form_helper
INFO - 2024-03-07 19:15:02 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:15:02 --> Controller Class Initialized
INFO - 2024-03-07 19:15:02 --> Form Validation Class Initialized
INFO - 2024-03-07 19:15:02 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 19:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 19:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 19:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 19:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 19:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 19:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 19:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 19:15:02 --> Final output sent to browser
DEBUG - 2024-03-07 19:15:02 --> Total execution time: 0.0496
ERROR - 2024-03-07 19:15:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:15:02 --> Config Class Initialized
INFO - 2024-03-07 19:15:02 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:15:02 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:15:02 --> Utf8 Class Initialized
INFO - 2024-03-07 19:15:02 --> URI Class Initialized
INFO - 2024-03-07 19:15:02 --> Router Class Initialized
INFO - 2024-03-07 19:15:02 --> Output Class Initialized
INFO - 2024-03-07 19:15:02 --> Security Class Initialized
DEBUG - 2024-03-07 19:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:15:02 --> Input Class Initialized
INFO - 2024-03-07 19:15:02 --> Language Class Initialized
INFO - 2024-03-07 19:15:02 --> Loader Class Initialized
INFO - 2024-03-07 19:15:02 --> Helper loaded: url_helper
INFO - 2024-03-07 19:15:02 --> Helper loaded: file_helper
INFO - 2024-03-07 19:15:02 --> Helper loaded: form_helper
INFO - 2024-03-07 19:15:02 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:15:02 --> Controller Class Initialized
INFO - 2024-03-07 19:15:02 --> Form Validation Class Initialized
INFO - 2024-03-07 19:15:02 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:15:02 --> Model "ReportModel" initialized
ERROR - 2024-03-07 19:15:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:15:04 --> Config Class Initialized
INFO - 2024-03-07 19:15:04 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:15:04 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:15:04 --> Utf8 Class Initialized
INFO - 2024-03-07 19:15:04 --> URI Class Initialized
INFO - 2024-03-07 19:15:04 --> Router Class Initialized
INFO - 2024-03-07 19:15:04 --> Output Class Initialized
INFO - 2024-03-07 19:15:04 --> Security Class Initialized
DEBUG - 2024-03-07 19:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:15:04 --> Input Class Initialized
INFO - 2024-03-07 19:15:04 --> Language Class Initialized
INFO - 2024-03-07 19:15:04 --> Loader Class Initialized
INFO - 2024-03-07 19:15:04 --> Helper loaded: url_helper
INFO - 2024-03-07 19:15:04 --> Helper loaded: file_helper
INFO - 2024-03-07 19:15:04 --> Helper loaded: form_helper
INFO - 2024-03-07 19:15:04 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:15:04 --> Controller Class Initialized
INFO - 2024-03-07 19:15:04 --> Form Validation Class Initialized
INFO - 2024-03-07 19:15:04 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:15:04 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:15:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:15:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:15:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:15:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:15:04 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:15:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:15:04 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:15:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 19:15:04 --> Final output sent to browser
DEBUG - 2024-03-07 19:15:04 --> Total execution time: 0.0571
ERROR - 2024-03-07 19:15:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 19:15:14 --> Config Class Initialized
INFO - 2024-03-07 19:15:14 --> Hooks Class Initialized
DEBUG - 2024-03-07 19:15:14 --> UTF-8 Support Enabled
INFO - 2024-03-07 19:15:14 --> Utf8 Class Initialized
INFO - 2024-03-07 19:15:14 --> URI Class Initialized
INFO - 2024-03-07 19:15:14 --> Router Class Initialized
INFO - 2024-03-07 19:15:14 --> Output Class Initialized
INFO - 2024-03-07 19:15:14 --> Security Class Initialized
DEBUG - 2024-03-07 19:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 19:15:14 --> Input Class Initialized
INFO - 2024-03-07 19:15:14 --> Language Class Initialized
INFO - 2024-03-07 19:15:14 --> Loader Class Initialized
INFO - 2024-03-07 19:15:14 --> Helper loaded: url_helper
INFO - 2024-03-07 19:15:14 --> Helper loaded: file_helper
INFO - 2024-03-07 19:15:14 --> Helper loaded: form_helper
INFO - 2024-03-07 19:15:14 --> Database Driver Class Initialized
DEBUG - 2024-03-07 19:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 19:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 19:15:14 --> Controller Class Initialized
INFO - 2024-03-07 19:15:14 --> Form Validation Class Initialized
INFO - 2024-03-07 19:15:14 --> Model "MasterModel" initialized
INFO - 2024-03-07 19:15:14 --> Model "DashboardModel" initialized
INFO - 2024-03-07 19:15:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 19:15:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 19:15:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 19:15:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 19:15:14 --> Model "OrderModel" initialized
INFO - 2024-03-07 19:15:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 19:15:14 --> Model "ReportModel" initialized
INFO - 2024-03-07 19:15:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 19:15:14 --> Final output sent to browser
DEBUG - 2024-03-07 19:15:14 --> Total execution time: 0.0375
ERROR - 2024-03-07 20:21:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:21:04 --> Config Class Initialized
INFO - 2024-03-07 20:21:04 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:21:04 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:21:04 --> Utf8 Class Initialized
INFO - 2024-03-07 20:21:04 --> URI Class Initialized
INFO - 2024-03-07 20:21:04 --> Router Class Initialized
INFO - 2024-03-07 20:21:04 --> Output Class Initialized
INFO - 2024-03-07 20:21:04 --> Security Class Initialized
DEBUG - 2024-03-07 20:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:21:04 --> Input Class Initialized
INFO - 2024-03-07 20:21:04 --> Language Class Initialized
INFO - 2024-03-07 20:21:04 --> Loader Class Initialized
INFO - 2024-03-07 20:21:04 --> Helper loaded: url_helper
INFO - 2024-03-07 20:21:04 --> Helper loaded: file_helper
INFO - 2024-03-07 20:21:04 --> Helper loaded: form_helper
INFO - 2024-03-07 20:21:04 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:21:04 --> Controller Class Initialized
INFO - 2024-03-07 20:21:04 --> Form Validation Class Initialized
INFO - 2024-03-07 20:21:04 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:21:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:21:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:21:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:21:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:21:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:21:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:21:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:21:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:21:04 --> Final output sent to browser
DEBUG - 2024-03-07 20:21:04 --> Total execution time: 0.0358
ERROR - 2024-03-07 20:21:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:21:04 --> Config Class Initialized
INFO - 2024-03-07 20:21:04 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:21:04 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:21:04 --> Utf8 Class Initialized
INFO - 2024-03-07 20:21:04 --> URI Class Initialized
INFO - 2024-03-07 20:21:04 --> Router Class Initialized
INFO - 2024-03-07 20:21:04 --> Output Class Initialized
INFO - 2024-03-07 20:21:04 --> Security Class Initialized
DEBUG - 2024-03-07 20:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:21:04 --> Input Class Initialized
INFO - 2024-03-07 20:21:04 --> Language Class Initialized
INFO - 2024-03-07 20:21:04 --> Loader Class Initialized
INFO - 2024-03-07 20:21:04 --> Helper loaded: url_helper
INFO - 2024-03-07 20:21:04 --> Helper loaded: file_helper
INFO - 2024-03-07 20:21:04 --> Helper loaded: form_helper
INFO - 2024-03-07 20:21:04 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:21:04 --> Controller Class Initialized
INFO - 2024-03-07 20:21:04 --> Form Validation Class Initialized
INFO - 2024-03-07 20:21:04 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:21:04 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:21:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:21:07 --> Config Class Initialized
INFO - 2024-03-07 20:21:07 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:21:07 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:21:07 --> Utf8 Class Initialized
INFO - 2024-03-07 20:21:07 --> URI Class Initialized
INFO - 2024-03-07 20:21:07 --> Router Class Initialized
INFO - 2024-03-07 20:21:07 --> Output Class Initialized
INFO - 2024-03-07 20:21:07 --> Security Class Initialized
DEBUG - 2024-03-07 20:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:21:07 --> Input Class Initialized
INFO - 2024-03-07 20:21:07 --> Language Class Initialized
INFO - 2024-03-07 20:21:07 --> Loader Class Initialized
INFO - 2024-03-07 20:21:07 --> Helper loaded: url_helper
INFO - 2024-03-07 20:21:07 --> Helper loaded: file_helper
INFO - 2024-03-07 20:21:07 --> Helper loaded: form_helper
INFO - 2024-03-07 20:21:07 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:21:07 --> Controller Class Initialized
INFO - 2024-03-07 20:21:07 --> Form Validation Class Initialized
INFO - 2024-03-07 20:21:07 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:21:07 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:21:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:21:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:21:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:21:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:21:07 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:21:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:21:07 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:21:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:21:07 --> Final output sent to browser
DEBUG - 2024-03-07 20:21:07 --> Total execution time: 0.0463
ERROR - 2024-03-07 20:22:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:22:52 --> Config Class Initialized
INFO - 2024-03-07 20:22:52 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:22:52 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:22:52 --> Utf8 Class Initialized
INFO - 2024-03-07 20:22:52 --> URI Class Initialized
INFO - 2024-03-07 20:22:52 --> Router Class Initialized
INFO - 2024-03-07 20:22:52 --> Output Class Initialized
INFO - 2024-03-07 20:22:52 --> Security Class Initialized
DEBUG - 2024-03-07 20:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:22:52 --> Input Class Initialized
INFO - 2024-03-07 20:22:52 --> Language Class Initialized
INFO - 2024-03-07 20:22:52 --> Loader Class Initialized
INFO - 2024-03-07 20:22:52 --> Helper loaded: url_helper
INFO - 2024-03-07 20:22:52 --> Helper loaded: file_helper
INFO - 2024-03-07 20:22:52 --> Helper loaded: form_helper
INFO - 2024-03-07 20:22:52 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:22:52 --> Controller Class Initialized
INFO - 2024-03-07 20:22:52 --> Form Validation Class Initialized
INFO - 2024-03-07 20:22:52 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:22:52 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:22:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:22:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:22:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:22:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:22:52 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:22:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:22:52 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:22:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:22:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:22:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:22:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:22:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:22:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:22:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:22:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:22:52 --> Final output sent to browser
DEBUG - 2024-03-07 20:22:52 --> Total execution time: 0.0455
ERROR - 2024-03-07 20:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:22:53 --> Config Class Initialized
INFO - 2024-03-07 20:22:53 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:22:53 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:22:53 --> Utf8 Class Initialized
INFO - 2024-03-07 20:22:53 --> URI Class Initialized
INFO - 2024-03-07 20:22:53 --> Router Class Initialized
INFO - 2024-03-07 20:22:53 --> Output Class Initialized
INFO - 2024-03-07 20:22:53 --> Security Class Initialized
DEBUG - 2024-03-07 20:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:22:53 --> Input Class Initialized
INFO - 2024-03-07 20:22:53 --> Language Class Initialized
INFO - 2024-03-07 20:22:53 --> Loader Class Initialized
INFO - 2024-03-07 20:22:53 --> Helper loaded: url_helper
INFO - 2024-03-07 20:22:53 --> Helper loaded: file_helper
INFO - 2024-03-07 20:22:53 --> Helper loaded: form_helper
INFO - 2024-03-07 20:22:53 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:22:53 --> Controller Class Initialized
INFO - 2024-03-07 20:22:53 --> Form Validation Class Initialized
INFO - 2024-03-07 20:22:53 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:22:53 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:22:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:22:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:22:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:22:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:22:53 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:22:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:22:53 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:22:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:22:56 --> Config Class Initialized
INFO - 2024-03-07 20:22:56 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:22:56 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:22:56 --> Utf8 Class Initialized
INFO - 2024-03-07 20:22:56 --> URI Class Initialized
INFO - 2024-03-07 20:22:56 --> Router Class Initialized
INFO - 2024-03-07 20:22:56 --> Output Class Initialized
INFO - 2024-03-07 20:22:56 --> Security Class Initialized
DEBUG - 2024-03-07 20:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:22:56 --> Input Class Initialized
INFO - 2024-03-07 20:22:56 --> Language Class Initialized
INFO - 2024-03-07 20:22:56 --> Loader Class Initialized
INFO - 2024-03-07 20:22:56 --> Helper loaded: url_helper
INFO - 2024-03-07 20:22:56 --> Helper loaded: file_helper
INFO - 2024-03-07 20:22:56 --> Helper loaded: form_helper
INFO - 2024-03-07 20:22:56 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:22:56 --> Controller Class Initialized
INFO - 2024-03-07 20:22:56 --> Form Validation Class Initialized
INFO - 2024-03-07 20:22:56 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:22:56 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:22:56 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:22:56 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:22:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:22:56 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:22:56 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:22:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:22:56 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:22:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:22:56 --> Final output sent to browser
DEBUG - 2024-03-07 20:22:56 --> Total execution time: 0.0465
ERROR - 2024-03-07 20:24:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:24:50 --> Config Class Initialized
INFO - 2024-03-07 20:24:50 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:24:50 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:24:50 --> Utf8 Class Initialized
INFO - 2024-03-07 20:24:50 --> URI Class Initialized
INFO - 2024-03-07 20:24:50 --> Router Class Initialized
INFO - 2024-03-07 20:24:50 --> Output Class Initialized
INFO - 2024-03-07 20:24:50 --> Security Class Initialized
DEBUG - 2024-03-07 20:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:24:50 --> Input Class Initialized
INFO - 2024-03-07 20:24:50 --> Language Class Initialized
INFO - 2024-03-07 20:24:50 --> Loader Class Initialized
INFO - 2024-03-07 20:24:50 --> Helper loaded: url_helper
INFO - 2024-03-07 20:24:50 --> Helper loaded: file_helper
INFO - 2024-03-07 20:24:50 --> Helper loaded: form_helper
INFO - 2024-03-07 20:24:50 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:24:50 --> Controller Class Initialized
INFO - 2024-03-07 20:24:50 --> Form Validation Class Initialized
INFO - 2024-03-07 20:24:50 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:24:50 --> Final output sent to browser
DEBUG - 2024-03-07 20:24:50 --> Total execution time: 0.0401
ERROR - 2024-03-07 20:24:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:24:50 --> Config Class Initialized
INFO - 2024-03-07 20:24:50 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:24:50 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:24:50 --> Utf8 Class Initialized
INFO - 2024-03-07 20:24:50 --> URI Class Initialized
INFO - 2024-03-07 20:24:50 --> Router Class Initialized
INFO - 2024-03-07 20:24:50 --> Output Class Initialized
INFO - 2024-03-07 20:24:50 --> Security Class Initialized
DEBUG - 2024-03-07 20:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:24:50 --> Input Class Initialized
INFO - 2024-03-07 20:24:50 --> Language Class Initialized
INFO - 2024-03-07 20:24:50 --> Loader Class Initialized
INFO - 2024-03-07 20:24:50 --> Helper loaded: url_helper
INFO - 2024-03-07 20:24:50 --> Helper loaded: file_helper
INFO - 2024-03-07 20:24:50 --> Helper loaded: form_helper
INFO - 2024-03-07 20:24:50 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:24:50 --> Controller Class Initialized
INFO - 2024-03-07 20:24:50 --> Form Validation Class Initialized
INFO - 2024-03-07 20:24:50 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:24:50 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:24:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:24:53 --> Config Class Initialized
INFO - 2024-03-07 20:24:53 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:24:53 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:24:53 --> Utf8 Class Initialized
INFO - 2024-03-07 20:24:53 --> URI Class Initialized
INFO - 2024-03-07 20:24:53 --> Router Class Initialized
INFO - 2024-03-07 20:24:53 --> Output Class Initialized
INFO - 2024-03-07 20:24:53 --> Security Class Initialized
DEBUG - 2024-03-07 20:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:24:53 --> Input Class Initialized
INFO - 2024-03-07 20:24:53 --> Language Class Initialized
INFO - 2024-03-07 20:24:53 --> Loader Class Initialized
INFO - 2024-03-07 20:24:53 --> Helper loaded: url_helper
INFO - 2024-03-07 20:24:53 --> Helper loaded: file_helper
INFO - 2024-03-07 20:24:53 --> Helper loaded: form_helper
INFO - 2024-03-07 20:24:53 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:24:53 --> Controller Class Initialized
INFO - 2024-03-07 20:24:53 --> Form Validation Class Initialized
INFO - 2024-03-07 20:24:53 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:24:53 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:24:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:24:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:24:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:24:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:24:53 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:24:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:24:53 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:24:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:24:53 --> Final output sent to browser
DEBUG - 2024-03-07 20:24:53 --> Total execution time: 0.0376
ERROR - 2024-03-07 20:25:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:25:50 --> Config Class Initialized
INFO - 2024-03-07 20:25:50 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:25:50 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:25:50 --> Utf8 Class Initialized
INFO - 2024-03-07 20:25:50 --> URI Class Initialized
INFO - 2024-03-07 20:25:50 --> Router Class Initialized
INFO - 2024-03-07 20:25:50 --> Output Class Initialized
INFO - 2024-03-07 20:25:50 --> Security Class Initialized
DEBUG - 2024-03-07 20:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:25:50 --> Input Class Initialized
INFO - 2024-03-07 20:25:50 --> Language Class Initialized
INFO - 2024-03-07 20:25:50 --> Loader Class Initialized
INFO - 2024-03-07 20:25:50 --> Helper loaded: url_helper
INFO - 2024-03-07 20:25:50 --> Helper loaded: file_helper
INFO - 2024-03-07 20:25:50 --> Helper loaded: form_helper
INFO - 2024-03-07 20:25:50 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:25:50 --> Controller Class Initialized
INFO - 2024-03-07 20:25:50 --> Form Validation Class Initialized
INFO - 2024-03-07 20:25:50 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:25:50 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:25:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:25:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:25:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:25:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:25:50 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:25:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:25:50 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:25:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:25:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:25:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:25:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:25:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:25:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:25:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:25:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:25:50 --> Final output sent to browser
DEBUG - 2024-03-07 20:25:50 --> Total execution time: 0.0444
ERROR - 2024-03-07 20:25:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:25:52 --> Config Class Initialized
INFO - 2024-03-07 20:25:52 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:25:52 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:25:52 --> Utf8 Class Initialized
INFO - 2024-03-07 20:25:52 --> URI Class Initialized
INFO - 2024-03-07 20:25:52 --> Router Class Initialized
INFO - 2024-03-07 20:25:52 --> Output Class Initialized
INFO - 2024-03-07 20:25:52 --> Security Class Initialized
DEBUG - 2024-03-07 20:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:25:52 --> Input Class Initialized
INFO - 2024-03-07 20:25:52 --> Language Class Initialized
INFO - 2024-03-07 20:25:52 --> Loader Class Initialized
INFO - 2024-03-07 20:25:52 --> Helper loaded: url_helper
INFO - 2024-03-07 20:25:52 --> Helper loaded: file_helper
INFO - 2024-03-07 20:25:52 --> Helper loaded: form_helper
INFO - 2024-03-07 20:25:52 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:25:52 --> Controller Class Initialized
INFO - 2024-03-07 20:25:52 --> Form Validation Class Initialized
INFO - 2024-03-07 20:25:52 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:25:52 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:25:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:25:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:25:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:25:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:25:52 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:25:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:25:52 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:25:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:25:54 --> Config Class Initialized
INFO - 2024-03-07 20:25:54 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:25:54 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:25:54 --> Utf8 Class Initialized
INFO - 2024-03-07 20:25:54 --> URI Class Initialized
INFO - 2024-03-07 20:25:54 --> Router Class Initialized
INFO - 2024-03-07 20:25:54 --> Output Class Initialized
INFO - 2024-03-07 20:25:54 --> Security Class Initialized
DEBUG - 2024-03-07 20:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:25:54 --> Input Class Initialized
INFO - 2024-03-07 20:25:54 --> Language Class Initialized
INFO - 2024-03-07 20:25:54 --> Loader Class Initialized
INFO - 2024-03-07 20:25:54 --> Helper loaded: url_helper
INFO - 2024-03-07 20:25:54 --> Helper loaded: file_helper
INFO - 2024-03-07 20:25:54 --> Helper loaded: form_helper
INFO - 2024-03-07 20:25:54 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:25:54 --> Controller Class Initialized
INFO - 2024-03-07 20:25:54 --> Form Validation Class Initialized
INFO - 2024-03-07 20:25:54 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:25:54 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:25:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:25:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:25:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:25:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:25:54 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:25:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:25:54 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:25:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:25:54 --> Final output sent to browser
DEBUG - 2024-03-07 20:25:54 --> Total execution time: 0.0389
ERROR - 2024-03-07 20:26:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:26:08 --> Config Class Initialized
INFO - 2024-03-07 20:26:08 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:26:08 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:26:08 --> Utf8 Class Initialized
INFO - 2024-03-07 20:26:08 --> URI Class Initialized
INFO - 2024-03-07 20:26:08 --> Router Class Initialized
INFO - 2024-03-07 20:26:08 --> Output Class Initialized
INFO - 2024-03-07 20:26:08 --> Security Class Initialized
DEBUG - 2024-03-07 20:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:26:08 --> Input Class Initialized
INFO - 2024-03-07 20:26:08 --> Language Class Initialized
INFO - 2024-03-07 20:26:08 --> Loader Class Initialized
INFO - 2024-03-07 20:26:08 --> Helper loaded: url_helper
INFO - 2024-03-07 20:26:08 --> Helper loaded: file_helper
INFO - 2024-03-07 20:26:08 --> Helper loaded: form_helper
INFO - 2024-03-07 20:26:08 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:26:08 --> Controller Class Initialized
INFO - 2024-03-07 20:26:08 --> Form Validation Class Initialized
INFO - 2024-03-07 20:26:08 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:26:08 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:26:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:26:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:26:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:26:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:26:08 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:26:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:26:08 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:26:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:26:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:26:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:26:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:26:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:26:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:26:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:26:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:26:08 --> Final output sent to browser
DEBUG - 2024-03-07 20:26:08 --> Total execution time: 0.0260
ERROR - 2024-03-07 20:26:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:26:09 --> Config Class Initialized
INFO - 2024-03-07 20:26:09 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:26:09 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:26:09 --> Utf8 Class Initialized
INFO - 2024-03-07 20:26:09 --> URI Class Initialized
INFO - 2024-03-07 20:26:09 --> Router Class Initialized
INFO - 2024-03-07 20:26:09 --> Output Class Initialized
INFO - 2024-03-07 20:26:09 --> Security Class Initialized
DEBUG - 2024-03-07 20:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:26:09 --> Input Class Initialized
INFO - 2024-03-07 20:26:09 --> Language Class Initialized
INFO - 2024-03-07 20:26:09 --> Loader Class Initialized
INFO - 2024-03-07 20:26:09 --> Helper loaded: url_helper
INFO - 2024-03-07 20:26:09 --> Helper loaded: file_helper
INFO - 2024-03-07 20:26:09 --> Helper loaded: form_helper
INFO - 2024-03-07 20:26:09 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:26:09 --> Controller Class Initialized
INFO - 2024-03-07 20:26:09 --> Form Validation Class Initialized
INFO - 2024-03-07 20:26:09 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:26:09 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:26:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:26:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:26:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:26:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:26:09 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:26:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:26:09 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:26:12 --> Config Class Initialized
INFO - 2024-03-07 20:26:12 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:26:12 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:26:12 --> Utf8 Class Initialized
INFO - 2024-03-07 20:26:12 --> URI Class Initialized
INFO - 2024-03-07 20:26:12 --> Router Class Initialized
INFO - 2024-03-07 20:26:12 --> Output Class Initialized
INFO - 2024-03-07 20:26:12 --> Security Class Initialized
DEBUG - 2024-03-07 20:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:26:12 --> Input Class Initialized
INFO - 2024-03-07 20:26:12 --> Language Class Initialized
INFO - 2024-03-07 20:26:12 --> Loader Class Initialized
INFO - 2024-03-07 20:26:12 --> Helper loaded: url_helper
INFO - 2024-03-07 20:26:12 --> Helper loaded: file_helper
INFO - 2024-03-07 20:26:12 --> Helper loaded: form_helper
INFO - 2024-03-07 20:26:12 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:26:12 --> Controller Class Initialized
INFO - 2024-03-07 20:26:12 --> Form Validation Class Initialized
INFO - 2024-03-07 20:26:12 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:26:12 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:26:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:26:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:26:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:26:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:26:12 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:26:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:26:12 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:26:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:26:12 --> Final output sent to browser
DEBUG - 2024-03-07 20:26:12 --> Total execution time: 0.0404
ERROR - 2024-03-07 20:40:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:40:12 --> Config Class Initialized
INFO - 2024-03-07 20:40:12 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:40:12 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:40:12 --> Utf8 Class Initialized
INFO - 2024-03-07 20:40:12 --> URI Class Initialized
INFO - 2024-03-07 20:40:12 --> Router Class Initialized
INFO - 2024-03-07 20:40:12 --> Output Class Initialized
INFO - 2024-03-07 20:40:12 --> Security Class Initialized
DEBUG - 2024-03-07 20:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:40:12 --> Input Class Initialized
INFO - 2024-03-07 20:40:12 --> Language Class Initialized
INFO - 2024-03-07 20:40:12 --> Loader Class Initialized
INFO - 2024-03-07 20:40:12 --> Helper loaded: url_helper
INFO - 2024-03-07 20:40:12 --> Helper loaded: file_helper
INFO - 2024-03-07 20:40:12 --> Helper loaded: form_helper
INFO - 2024-03-07 20:40:12 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:40:12 --> Controller Class Initialized
INFO - 2024-03-07 20:40:12 --> Form Validation Class Initialized
INFO - 2024-03-07 20:40:12 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:40:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:40:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:40:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:40:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:40:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:40:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:40:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:40:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:40:12 --> Final output sent to browser
DEBUG - 2024-03-07 20:40:12 --> Total execution time: 0.0432
ERROR - 2024-03-07 20:40:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:40:12 --> Config Class Initialized
INFO - 2024-03-07 20:40:12 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:40:12 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:40:12 --> Utf8 Class Initialized
INFO - 2024-03-07 20:40:12 --> URI Class Initialized
INFO - 2024-03-07 20:40:12 --> Router Class Initialized
INFO - 2024-03-07 20:40:12 --> Output Class Initialized
INFO - 2024-03-07 20:40:12 --> Security Class Initialized
DEBUG - 2024-03-07 20:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:40:12 --> Input Class Initialized
INFO - 2024-03-07 20:40:12 --> Language Class Initialized
INFO - 2024-03-07 20:40:12 --> Loader Class Initialized
INFO - 2024-03-07 20:40:12 --> Helper loaded: url_helper
INFO - 2024-03-07 20:40:12 --> Helper loaded: file_helper
INFO - 2024-03-07 20:40:12 --> Helper loaded: form_helper
INFO - 2024-03-07 20:40:12 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:40:12 --> Controller Class Initialized
INFO - 2024-03-07 20:40:12 --> Form Validation Class Initialized
INFO - 2024-03-07 20:40:12 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:40:12 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:40:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:40:15 --> Config Class Initialized
INFO - 2024-03-07 20:40:15 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:40:15 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:40:15 --> Utf8 Class Initialized
INFO - 2024-03-07 20:40:15 --> URI Class Initialized
INFO - 2024-03-07 20:40:15 --> Router Class Initialized
INFO - 2024-03-07 20:40:15 --> Output Class Initialized
INFO - 2024-03-07 20:40:15 --> Security Class Initialized
DEBUG - 2024-03-07 20:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:40:15 --> Input Class Initialized
INFO - 2024-03-07 20:40:15 --> Language Class Initialized
INFO - 2024-03-07 20:40:15 --> Loader Class Initialized
INFO - 2024-03-07 20:40:15 --> Helper loaded: url_helper
INFO - 2024-03-07 20:40:15 --> Helper loaded: file_helper
INFO - 2024-03-07 20:40:15 --> Helper loaded: form_helper
INFO - 2024-03-07 20:40:15 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:40:15 --> Controller Class Initialized
INFO - 2024-03-07 20:40:15 --> Form Validation Class Initialized
INFO - 2024-03-07 20:40:15 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:40:15 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:40:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:40:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:40:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:40:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:40:15 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:40:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:40:15 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:40:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:40:15 --> Final output sent to browser
DEBUG - 2024-03-07 20:40:15 --> Total execution time: 0.0358
ERROR - 2024-03-07 20:42:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:42:00 --> Config Class Initialized
INFO - 2024-03-07 20:42:00 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:42:00 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:42:00 --> Utf8 Class Initialized
INFO - 2024-03-07 20:42:00 --> URI Class Initialized
INFO - 2024-03-07 20:42:00 --> Router Class Initialized
INFO - 2024-03-07 20:42:00 --> Output Class Initialized
INFO - 2024-03-07 20:42:00 --> Security Class Initialized
DEBUG - 2024-03-07 20:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:42:00 --> Input Class Initialized
INFO - 2024-03-07 20:42:00 --> Language Class Initialized
INFO - 2024-03-07 20:42:00 --> Loader Class Initialized
INFO - 2024-03-07 20:42:00 --> Helper loaded: url_helper
INFO - 2024-03-07 20:42:00 --> Helper loaded: file_helper
INFO - 2024-03-07 20:42:00 --> Helper loaded: form_helper
INFO - 2024-03-07 20:42:00 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:42:00 --> Controller Class Initialized
INFO - 2024-03-07 20:42:00 --> Form Validation Class Initialized
INFO - 2024-03-07 20:42:00 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:42:00 --> Final output sent to browser
DEBUG - 2024-03-07 20:42:00 --> Total execution time: 0.0322
ERROR - 2024-03-07 20:42:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:42:00 --> Config Class Initialized
INFO - 2024-03-07 20:42:00 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:42:00 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:42:00 --> Utf8 Class Initialized
INFO - 2024-03-07 20:42:00 --> URI Class Initialized
INFO - 2024-03-07 20:42:00 --> Router Class Initialized
INFO - 2024-03-07 20:42:00 --> Output Class Initialized
INFO - 2024-03-07 20:42:00 --> Security Class Initialized
DEBUG - 2024-03-07 20:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:42:00 --> Input Class Initialized
INFO - 2024-03-07 20:42:00 --> Language Class Initialized
INFO - 2024-03-07 20:42:00 --> Loader Class Initialized
INFO - 2024-03-07 20:42:00 --> Helper loaded: url_helper
INFO - 2024-03-07 20:42:00 --> Helper loaded: file_helper
INFO - 2024-03-07 20:42:00 --> Helper loaded: form_helper
INFO - 2024-03-07 20:42:00 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:42:00 --> Controller Class Initialized
INFO - 2024-03-07 20:42:00 --> Form Validation Class Initialized
INFO - 2024-03-07 20:42:00 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:42:00 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:42:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:42:03 --> Config Class Initialized
INFO - 2024-03-07 20:42:03 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:42:03 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:42:03 --> Utf8 Class Initialized
INFO - 2024-03-07 20:42:03 --> URI Class Initialized
INFO - 2024-03-07 20:42:03 --> Router Class Initialized
INFO - 2024-03-07 20:42:03 --> Output Class Initialized
INFO - 2024-03-07 20:42:03 --> Security Class Initialized
DEBUG - 2024-03-07 20:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:42:03 --> Input Class Initialized
INFO - 2024-03-07 20:42:03 --> Language Class Initialized
INFO - 2024-03-07 20:42:03 --> Loader Class Initialized
INFO - 2024-03-07 20:42:03 --> Helper loaded: url_helper
INFO - 2024-03-07 20:42:03 --> Helper loaded: file_helper
INFO - 2024-03-07 20:42:03 --> Helper loaded: form_helper
INFO - 2024-03-07 20:42:03 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:42:03 --> Controller Class Initialized
INFO - 2024-03-07 20:42:03 --> Form Validation Class Initialized
INFO - 2024-03-07 20:42:03 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:42:03 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:42:03 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:42:03 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:42:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:42:03 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:42:03 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:42:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:42:03 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:42:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:42:03 --> Final output sent to browser
DEBUG - 2024-03-07 20:42:03 --> Total execution time: 0.0352
ERROR - 2024-03-07 20:42:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:42:39 --> Config Class Initialized
INFO - 2024-03-07 20:42:39 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:42:39 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:42:39 --> Utf8 Class Initialized
INFO - 2024-03-07 20:42:39 --> URI Class Initialized
INFO - 2024-03-07 20:42:39 --> Router Class Initialized
INFO - 2024-03-07 20:42:39 --> Output Class Initialized
INFO - 2024-03-07 20:42:39 --> Security Class Initialized
DEBUG - 2024-03-07 20:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:42:39 --> Input Class Initialized
INFO - 2024-03-07 20:42:39 --> Language Class Initialized
INFO - 2024-03-07 20:42:39 --> Loader Class Initialized
INFO - 2024-03-07 20:42:39 --> Helper loaded: url_helper
INFO - 2024-03-07 20:42:39 --> Helper loaded: file_helper
INFO - 2024-03-07 20:42:39 --> Helper loaded: form_helper
INFO - 2024-03-07 20:42:39 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:42:39 --> Controller Class Initialized
INFO - 2024-03-07 20:42:39 --> Form Validation Class Initialized
INFO - 2024-03-07 20:42:39 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:42:39 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:42:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:42:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:42:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:42:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:42:39 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:42:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:42:39 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:42:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:42:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:42:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:42:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:42:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:42:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:42:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:42:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:42:39 --> Final output sent to browser
DEBUG - 2024-03-07 20:42:39 --> Total execution time: 0.0404
ERROR - 2024-03-07 20:42:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:42:40 --> Config Class Initialized
INFO - 2024-03-07 20:42:40 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:42:40 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:42:40 --> Utf8 Class Initialized
INFO - 2024-03-07 20:42:40 --> URI Class Initialized
INFO - 2024-03-07 20:42:40 --> Router Class Initialized
INFO - 2024-03-07 20:42:40 --> Output Class Initialized
INFO - 2024-03-07 20:42:40 --> Security Class Initialized
DEBUG - 2024-03-07 20:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:42:40 --> Input Class Initialized
INFO - 2024-03-07 20:42:40 --> Language Class Initialized
INFO - 2024-03-07 20:42:40 --> Loader Class Initialized
INFO - 2024-03-07 20:42:40 --> Helper loaded: url_helper
INFO - 2024-03-07 20:42:40 --> Helper loaded: file_helper
INFO - 2024-03-07 20:42:40 --> Helper loaded: form_helper
INFO - 2024-03-07 20:42:40 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:42:40 --> Controller Class Initialized
INFO - 2024-03-07 20:42:40 --> Form Validation Class Initialized
INFO - 2024-03-07 20:42:40 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:42:40 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:42:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:42:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:42:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:42:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:42:40 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:42:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:42:40 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:42:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:42:43 --> Config Class Initialized
INFO - 2024-03-07 20:42:43 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:42:43 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:42:43 --> Utf8 Class Initialized
INFO - 2024-03-07 20:42:43 --> URI Class Initialized
INFO - 2024-03-07 20:42:43 --> Router Class Initialized
INFO - 2024-03-07 20:42:43 --> Output Class Initialized
INFO - 2024-03-07 20:42:43 --> Security Class Initialized
DEBUG - 2024-03-07 20:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:42:43 --> Input Class Initialized
INFO - 2024-03-07 20:42:43 --> Language Class Initialized
INFO - 2024-03-07 20:42:43 --> Loader Class Initialized
INFO - 2024-03-07 20:42:43 --> Helper loaded: url_helper
INFO - 2024-03-07 20:42:43 --> Helper loaded: file_helper
INFO - 2024-03-07 20:42:43 --> Helper loaded: form_helper
INFO - 2024-03-07 20:42:43 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:42:43 --> Controller Class Initialized
INFO - 2024-03-07 20:42:43 --> Form Validation Class Initialized
INFO - 2024-03-07 20:42:43 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:42:43 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:42:43 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:42:43 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:42:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:42:43 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:42:43 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:42:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:42:43 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:42:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:42:43 --> Final output sent to browser
DEBUG - 2024-03-07 20:42:43 --> Total execution time: 0.0380
ERROR - 2024-03-07 20:43:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:43:02 --> Config Class Initialized
INFO - 2024-03-07 20:43:02 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:43:02 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:43:02 --> Utf8 Class Initialized
INFO - 2024-03-07 20:43:02 --> URI Class Initialized
INFO - 2024-03-07 20:43:02 --> Router Class Initialized
INFO - 2024-03-07 20:43:02 --> Output Class Initialized
INFO - 2024-03-07 20:43:02 --> Security Class Initialized
DEBUG - 2024-03-07 20:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:43:02 --> Input Class Initialized
INFO - 2024-03-07 20:43:02 --> Language Class Initialized
INFO - 2024-03-07 20:43:02 --> Loader Class Initialized
INFO - 2024-03-07 20:43:02 --> Helper loaded: url_helper
INFO - 2024-03-07 20:43:02 --> Helper loaded: file_helper
INFO - 2024-03-07 20:43:02 --> Helper loaded: form_helper
INFO - 2024-03-07 20:43:02 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:43:02 --> Controller Class Initialized
INFO - 2024-03-07 20:43:02 --> Form Validation Class Initialized
INFO - 2024-03-07 20:43:02 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:43:02 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:43:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:43:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:43:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:43:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:43:02 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:43:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:43:02 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:43:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:43:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:43:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:43:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:43:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:43:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:43:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:43:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:43:02 --> Final output sent to browser
DEBUG - 2024-03-07 20:43:02 --> Total execution time: 0.0365
ERROR - 2024-03-07 20:43:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:43:04 --> Config Class Initialized
INFO - 2024-03-07 20:43:04 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:43:04 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:43:04 --> Utf8 Class Initialized
INFO - 2024-03-07 20:43:04 --> URI Class Initialized
INFO - 2024-03-07 20:43:04 --> Router Class Initialized
INFO - 2024-03-07 20:43:04 --> Output Class Initialized
INFO - 2024-03-07 20:43:04 --> Security Class Initialized
DEBUG - 2024-03-07 20:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:43:04 --> Input Class Initialized
INFO - 2024-03-07 20:43:04 --> Language Class Initialized
INFO - 2024-03-07 20:43:04 --> Loader Class Initialized
INFO - 2024-03-07 20:43:04 --> Helper loaded: url_helper
INFO - 2024-03-07 20:43:04 --> Helper loaded: file_helper
INFO - 2024-03-07 20:43:04 --> Helper loaded: form_helper
INFO - 2024-03-07 20:43:04 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:43:04 --> Controller Class Initialized
INFO - 2024-03-07 20:43:04 --> Form Validation Class Initialized
INFO - 2024-03-07 20:43:04 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:43:04 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:43:04 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:43:04 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:43:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:43:04 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:43:04 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:43:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:43:04 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:43:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:43:06 --> Config Class Initialized
INFO - 2024-03-07 20:43:06 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:43:06 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:43:06 --> Utf8 Class Initialized
INFO - 2024-03-07 20:43:06 --> URI Class Initialized
INFO - 2024-03-07 20:43:06 --> Router Class Initialized
INFO - 2024-03-07 20:43:06 --> Output Class Initialized
INFO - 2024-03-07 20:43:06 --> Security Class Initialized
DEBUG - 2024-03-07 20:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:43:06 --> Input Class Initialized
INFO - 2024-03-07 20:43:06 --> Language Class Initialized
INFO - 2024-03-07 20:43:06 --> Loader Class Initialized
INFO - 2024-03-07 20:43:06 --> Helper loaded: url_helper
INFO - 2024-03-07 20:43:06 --> Helper loaded: file_helper
INFO - 2024-03-07 20:43:06 --> Helper loaded: form_helper
INFO - 2024-03-07 20:43:06 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:43:06 --> Controller Class Initialized
INFO - 2024-03-07 20:43:06 --> Form Validation Class Initialized
INFO - 2024-03-07 20:43:06 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:43:06 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:43:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:43:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:43:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:43:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:43:06 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:43:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:43:06 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:43:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:43:06 --> Final output sent to browser
DEBUG - 2024-03-07 20:43:06 --> Total execution time: 0.0383
ERROR - 2024-03-07 20:48:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:48:36 --> Config Class Initialized
INFO - 2024-03-07 20:48:36 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:48:36 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:48:36 --> Utf8 Class Initialized
INFO - 2024-03-07 20:48:36 --> URI Class Initialized
INFO - 2024-03-07 20:48:36 --> Router Class Initialized
INFO - 2024-03-07 20:48:36 --> Output Class Initialized
INFO - 2024-03-07 20:48:36 --> Security Class Initialized
DEBUG - 2024-03-07 20:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:48:36 --> Input Class Initialized
INFO - 2024-03-07 20:48:36 --> Language Class Initialized
INFO - 2024-03-07 20:48:36 --> Loader Class Initialized
INFO - 2024-03-07 20:48:36 --> Helper loaded: url_helper
INFO - 2024-03-07 20:48:36 --> Helper loaded: file_helper
INFO - 2024-03-07 20:48:36 --> Helper loaded: form_helper
INFO - 2024-03-07 20:48:36 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:48:36 --> Controller Class Initialized
INFO - 2024-03-07 20:48:36 --> Form Validation Class Initialized
INFO - 2024-03-07 20:48:36 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:48:36 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:48:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:48:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:48:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:48:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:48:36 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:48:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:48:36 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:48:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:48:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:48:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:48:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:48:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:48:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:48:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:48:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:48:36 --> Final output sent to browser
DEBUG - 2024-03-07 20:48:36 --> Total execution time: 0.0325
ERROR - 2024-03-07 20:48:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:48:37 --> Config Class Initialized
INFO - 2024-03-07 20:48:37 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:48:37 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:48:37 --> Utf8 Class Initialized
INFO - 2024-03-07 20:48:37 --> URI Class Initialized
INFO - 2024-03-07 20:48:37 --> Router Class Initialized
INFO - 2024-03-07 20:48:37 --> Output Class Initialized
INFO - 2024-03-07 20:48:37 --> Security Class Initialized
DEBUG - 2024-03-07 20:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:48:37 --> Input Class Initialized
INFO - 2024-03-07 20:48:37 --> Language Class Initialized
INFO - 2024-03-07 20:48:37 --> Loader Class Initialized
INFO - 2024-03-07 20:48:37 --> Helper loaded: url_helper
INFO - 2024-03-07 20:48:37 --> Helper loaded: file_helper
INFO - 2024-03-07 20:48:37 --> Helper loaded: form_helper
INFO - 2024-03-07 20:48:37 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:48:37 --> Controller Class Initialized
INFO - 2024-03-07 20:48:37 --> Form Validation Class Initialized
INFO - 2024-03-07 20:48:37 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:48:37 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:48:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:48:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:48:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:48:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:48:37 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:48:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:48:37 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:48:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:48:40 --> Config Class Initialized
INFO - 2024-03-07 20:48:40 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:48:40 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:48:40 --> Utf8 Class Initialized
INFO - 2024-03-07 20:48:40 --> URI Class Initialized
INFO - 2024-03-07 20:48:40 --> Router Class Initialized
INFO - 2024-03-07 20:48:40 --> Output Class Initialized
INFO - 2024-03-07 20:48:40 --> Security Class Initialized
DEBUG - 2024-03-07 20:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:48:40 --> Input Class Initialized
INFO - 2024-03-07 20:48:40 --> Language Class Initialized
INFO - 2024-03-07 20:48:40 --> Loader Class Initialized
INFO - 2024-03-07 20:48:40 --> Helper loaded: url_helper
INFO - 2024-03-07 20:48:40 --> Helper loaded: file_helper
INFO - 2024-03-07 20:48:40 --> Helper loaded: form_helper
INFO - 2024-03-07 20:48:40 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:48:40 --> Controller Class Initialized
INFO - 2024-03-07 20:48:40 --> Form Validation Class Initialized
INFO - 2024-03-07 20:48:40 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:48:40 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:48:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:48:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:48:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:48:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:48:40 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:48:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:48:40 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:48:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:48:40 --> Final output sent to browser
DEBUG - 2024-03-07 20:48:40 --> Total execution time: 0.0380
ERROR - 2024-03-07 20:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:49:08 --> Config Class Initialized
INFO - 2024-03-07 20:49:08 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:49:08 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:49:08 --> Utf8 Class Initialized
INFO - 2024-03-07 20:49:08 --> URI Class Initialized
INFO - 2024-03-07 20:49:08 --> Router Class Initialized
INFO - 2024-03-07 20:49:08 --> Output Class Initialized
INFO - 2024-03-07 20:49:08 --> Security Class Initialized
DEBUG - 2024-03-07 20:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:49:08 --> Input Class Initialized
INFO - 2024-03-07 20:49:08 --> Language Class Initialized
INFO - 2024-03-07 20:49:08 --> Loader Class Initialized
INFO - 2024-03-07 20:49:08 --> Helper loaded: url_helper
INFO - 2024-03-07 20:49:08 --> Helper loaded: file_helper
INFO - 2024-03-07 20:49:08 --> Helper loaded: form_helper
INFO - 2024-03-07 20:49:08 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:49:08 --> Controller Class Initialized
INFO - 2024-03-07 20:49:08 --> Form Validation Class Initialized
INFO - 2024-03-07 20:49:08 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:49:08 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:49:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:49:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:49:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:49:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:49:08 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:49:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:49:08 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:49:08 --> Final output sent to browser
DEBUG - 2024-03-07 20:49:08 --> Total execution time: 0.0372
ERROR - 2024-03-07 20:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:49:09 --> Config Class Initialized
INFO - 2024-03-07 20:49:09 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:49:09 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:49:09 --> Utf8 Class Initialized
INFO - 2024-03-07 20:49:09 --> URI Class Initialized
INFO - 2024-03-07 20:49:09 --> Router Class Initialized
INFO - 2024-03-07 20:49:09 --> Output Class Initialized
INFO - 2024-03-07 20:49:09 --> Security Class Initialized
DEBUG - 2024-03-07 20:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:49:09 --> Input Class Initialized
INFO - 2024-03-07 20:49:09 --> Language Class Initialized
INFO - 2024-03-07 20:49:09 --> Loader Class Initialized
INFO - 2024-03-07 20:49:09 --> Helper loaded: url_helper
INFO - 2024-03-07 20:49:09 --> Helper loaded: file_helper
INFO - 2024-03-07 20:49:09 --> Helper loaded: form_helper
INFO - 2024-03-07 20:49:09 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:49:09 --> Controller Class Initialized
INFO - 2024-03-07 20:49:09 --> Form Validation Class Initialized
INFO - 2024-03-07 20:49:09 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:49:09 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:49:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:49:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:49:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:49:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:49:09 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:49:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:49:09 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:49:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:49:12 --> Config Class Initialized
INFO - 2024-03-07 20:49:12 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:49:12 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:49:12 --> Utf8 Class Initialized
INFO - 2024-03-07 20:49:12 --> URI Class Initialized
INFO - 2024-03-07 20:49:12 --> Router Class Initialized
INFO - 2024-03-07 20:49:12 --> Output Class Initialized
INFO - 2024-03-07 20:49:12 --> Security Class Initialized
DEBUG - 2024-03-07 20:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:49:12 --> Input Class Initialized
INFO - 2024-03-07 20:49:12 --> Language Class Initialized
INFO - 2024-03-07 20:49:12 --> Loader Class Initialized
INFO - 2024-03-07 20:49:12 --> Helper loaded: url_helper
INFO - 2024-03-07 20:49:12 --> Helper loaded: file_helper
INFO - 2024-03-07 20:49:12 --> Helper loaded: form_helper
INFO - 2024-03-07 20:49:12 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:49:12 --> Controller Class Initialized
INFO - 2024-03-07 20:49:12 --> Form Validation Class Initialized
INFO - 2024-03-07 20:49:12 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:49:12 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:49:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:49:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:49:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:49:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:49:12 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:49:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:49:12 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:49:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:49:12 --> Final output sent to browser
DEBUG - 2024-03-07 20:49:12 --> Total execution time: 0.0233
ERROR - 2024-03-07 20:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:50:36 --> Config Class Initialized
INFO - 2024-03-07 20:50:36 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:50:36 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:50:36 --> Utf8 Class Initialized
INFO - 2024-03-07 20:50:36 --> URI Class Initialized
INFO - 2024-03-07 20:50:36 --> Router Class Initialized
INFO - 2024-03-07 20:50:36 --> Output Class Initialized
INFO - 2024-03-07 20:50:36 --> Security Class Initialized
DEBUG - 2024-03-07 20:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:50:36 --> Input Class Initialized
INFO - 2024-03-07 20:50:36 --> Language Class Initialized
INFO - 2024-03-07 20:50:36 --> Loader Class Initialized
INFO - 2024-03-07 20:50:36 --> Helper loaded: url_helper
INFO - 2024-03-07 20:50:36 --> Helper loaded: file_helper
INFO - 2024-03-07 20:50:36 --> Helper loaded: form_helper
INFO - 2024-03-07 20:50:36 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:50:36 --> Controller Class Initialized
INFO - 2024-03-07 20:50:36 --> Form Validation Class Initialized
INFO - 2024-03-07 20:50:36 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:50:36 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:50:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:50:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:50:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:50:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:50:36 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:50:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:50:36 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:50:36 --> Final output sent to browser
DEBUG - 2024-03-07 20:50:36 --> Total execution time: 0.0348
ERROR - 2024-03-07 20:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:50:36 --> Config Class Initialized
INFO - 2024-03-07 20:50:36 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:50:36 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:50:36 --> Utf8 Class Initialized
INFO - 2024-03-07 20:50:36 --> URI Class Initialized
INFO - 2024-03-07 20:50:36 --> Router Class Initialized
INFO - 2024-03-07 20:50:36 --> Output Class Initialized
INFO - 2024-03-07 20:50:36 --> Security Class Initialized
DEBUG - 2024-03-07 20:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:50:36 --> Input Class Initialized
INFO - 2024-03-07 20:50:36 --> Language Class Initialized
INFO - 2024-03-07 20:50:36 --> Loader Class Initialized
INFO - 2024-03-07 20:50:36 --> Helper loaded: url_helper
INFO - 2024-03-07 20:50:36 --> Helper loaded: file_helper
INFO - 2024-03-07 20:50:36 --> Helper loaded: form_helper
INFO - 2024-03-07 20:50:37 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:50:37 --> Controller Class Initialized
INFO - 2024-03-07 20:50:37 --> Form Validation Class Initialized
INFO - 2024-03-07 20:50:37 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:50:37 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:50:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:50:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:50:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:50:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:50:37 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:50:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:50:37 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:50:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:50:39 --> Config Class Initialized
INFO - 2024-03-07 20:50:39 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:50:39 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:50:39 --> Utf8 Class Initialized
INFO - 2024-03-07 20:50:39 --> URI Class Initialized
INFO - 2024-03-07 20:50:39 --> Router Class Initialized
INFO - 2024-03-07 20:50:39 --> Output Class Initialized
INFO - 2024-03-07 20:50:39 --> Security Class Initialized
DEBUG - 2024-03-07 20:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:50:39 --> Input Class Initialized
INFO - 2024-03-07 20:50:39 --> Language Class Initialized
INFO - 2024-03-07 20:50:39 --> Loader Class Initialized
INFO - 2024-03-07 20:50:39 --> Helper loaded: url_helper
INFO - 2024-03-07 20:50:39 --> Helper loaded: file_helper
INFO - 2024-03-07 20:50:39 --> Helper loaded: form_helper
INFO - 2024-03-07 20:50:39 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:50:39 --> Controller Class Initialized
INFO - 2024-03-07 20:50:39 --> Form Validation Class Initialized
INFO - 2024-03-07 20:50:39 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:50:39 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:50:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:50:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:50:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:50:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:50:39 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:50:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:50:39 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:50:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:50:39 --> Final output sent to browser
DEBUG - 2024-03-07 20:50:39 --> Total execution time: 0.0337
ERROR - 2024-03-07 20:51:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:51:02 --> Config Class Initialized
INFO - 2024-03-07 20:51:02 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:51:02 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:51:02 --> Utf8 Class Initialized
INFO - 2024-03-07 20:51:02 --> URI Class Initialized
INFO - 2024-03-07 20:51:02 --> Router Class Initialized
INFO - 2024-03-07 20:51:02 --> Output Class Initialized
INFO - 2024-03-07 20:51:02 --> Security Class Initialized
DEBUG - 2024-03-07 20:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:51:02 --> Input Class Initialized
INFO - 2024-03-07 20:51:02 --> Language Class Initialized
INFO - 2024-03-07 20:51:02 --> Loader Class Initialized
INFO - 2024-03-07 20:51:02 --> Helper loaded: url_helper
INFO - 2024-03-07 20:51:02 --> Helper loaded: file_helper
INFO - 2024-03-07 20:51:02 --> Helper loaded: form_helper
INFO - 2024-03-07 20:51:02 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:51:02 --> Controller Class Initialized
INFO - 2024-03-07 20:51:02 --> Form Validation Class Initialized
INFO - 2024-03-07 20:51:02 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:51:02 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:51:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:51:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:51:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:51:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:51:02 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:51:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:51:02 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:51:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:51:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:51:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:51:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:51:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:51:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:51:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:51:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:51:02 --> Final output sent to browser
DEBUG - 2024-03-07 20:51:02 --> Total execution time: 0.0478
ERROR - 2024-03-07 20:51:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:51:03 --> Config Class Initialized
INFO - 2024-03-07 20:51:03 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:51:03 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:51:03 --> Utf8 Class Initialized
INFO - 2024-03-07 20:51:03 --> URI Class Initialized
INFO - 2024-03-07 20:51:03 --> Router Class Initialized
INFO - 2024-03-07 20:51:03 --> Output Class Initialized
INFO - 2024-03-07 20:51:03 --> Security Class Initialized
DEBUG - 2024-03-07 20:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:51:03 --> Input Class Initialized
INFO - 2024-03-07 20:51:03 --> Language Class Initialized
INFO - 2024-03-07 20:51:03 --> Loader Class Initialized
INFO - 2024-03-07 20:51:03 --> Helper loaded: url_helper
INFO - 2024-03-07 20:51:03 --> Helper loaded: file_helper
INFO - 2024-03-07 20:51:03 --> Helper loaded: form_helper
INFO - 2024-03-07 20:51:03 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:51:03 --> Controller Class Initialized
INFO - 2024-03-07 20:51:03 --> Form Validation Class Initialized
INFO - 2024-03-07 20:51:03 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:51:03 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:51:03 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:51:03 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:51:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:51:03 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:51:03 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:51:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:51:03 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:51:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:51:05 --> Config Class Initialized
INFO - 2024-03-07 20:51:05 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:51:05 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:51:05 --> Utf8 Class Initialized
INFO - 2024-03-07 20:51:05 --> URI Class Initialized
INFO - 2024-03-07 20:51:05 --> Router Class Initialized
INFO - 2024-03-07 20:51:05 --> Output Class Initialized
INFO - 2024-03-07 20:51:05 --> Security Class Initialized
DEBUG - 2024-03-07 20:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:51:05 --> Input Class Initialized
INFO - 2024-03-07 20:51:05 --> Language Class Initialized
INFO - 2024-03-07 20:51:05 --> Loader Class Initialized
INFO - 2024-03-07 20:51:05 --> Helper loaded: url_helper
INFO - 2024-03-07 20:51:05 --> Helper loaded: file_helper
INFO - 2024-03-07 20:51:05 --> Helper loaded: form_helper
INFO - 2024-03-07 20:51:05 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:51:05 --> Controller Class Initialized
INFO - 2024-03-07 20:51:05 --> Form Validation Class Initialized
INFO - 2024-03-07 20:51:05 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:51:05 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:51:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:51:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:51:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:51:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:51:05 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:51:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:51:05 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:51:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:51:05 --> Final output sent to browser
DEBUG - 2024-03-07 20:51:05 --> Total execution time: 0.0390
ERROR - 2024-03-07 20:51:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:51:23 --> Config Class Initialized
INFO - 2024-03-07 20:51:23 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:51:23 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:51:23 --> Utf8 Class Initialized
INFO - 2024-03-07 20:51:23 --> URI Class Initialized
INFO - 2024-03-07 20:51:23 --> Router Class Initialized
INFO - 2024-03-07 20:51:23 --> Output Class Initialized
INFO - 2024-03-07 20:51:23 --> Security Class Initialized
DEBUG - 2024-03-07 20:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:51:23 --> Input Class Initialized
INFO - 2024-03-07 20:51:23 --> Language Class Initialized
INFO - 2024-03-07 20:51:23 --> Loader Class Initialized
INFO - 2024-03-07 20:51:23 --> Helper loaded: url_helper
INFO - 2024-03-07 20:51:23 --> Helper loaded: file_helper
INFO - 2024-03-07 20:51:23 --> Helper loaded: form_helper
INFO - 2024-03-07 20:51:23 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:51:23 --> Controller Class Initialized
INFO - 2024-03-07 20:51:23 --> Form Validation Class Initialized
INFO - 2024-03-07 20:51:23 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:51:23 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:51:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:51:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:51:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:51:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:51:23 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:51:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:51:23 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:51:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:51:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:51:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:51:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:51:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:51:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:51:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:51:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:51:23 --> Final output sent to browser
DEBUG - 2024-03-07 20:51:23 --> Total execution time: 0.0356
ERROR - 2024-03-07 20:51:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:51:24 --> Config Class Initialized
INFO - 2024-03-07 20:51:24 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:51:24 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:51:24 --> Utf8 Class Initialized
INFO - 2024-03-07 20:51:24 --> URI Class Initialized
INFO - 2024-03-07 20:51:24 --> Router Class Initialized
INFO - 2024-03-07 20:51:24 --> Output Class Initialized
INFO - 2024-03-07 20:51:24 --> Security Class Initialized
DEBUG - 2024-03-07 20:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:51:24 --> Input Class Initialized
INFO - 2024-03-07 20:51:24 --> Language Class Initialized
INFO - 2024-03-07 20:51:24 --> Loader Class Initialized
INFO - 2024-03-07 20:51:24 --> Helper loaded: url_helper
INFO - 2024-03-07 20:51:24 --> Helper loaded: file_helper
INFO - 2024-03-07 20:51:24 --> Helper loaded: form_helper
INFO - 2024-03-07 20:51:24 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:51:24 --> Controller Class Initialized
INFO - 2024-03-07 20:51:24 --> Form Validation Class Initialized
INFO - 2024-03-07 20:51:24 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:51:24 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:51:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:51:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:51:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:51:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:51:24 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:51:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:51:24 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:51:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:51:27 --> Config Class Initialized
INFO - 2024-03-07 20:51:27 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:51:27 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:51:27 --> Utf8 Class Initialized
INFO - 2024-03-07 20:51:27 --> URI Class Initialized
INFO - 2024-03-07 20:51:27 --> Router Class Initialized
INFO - 2024-03-07 20:51:27 --> Output Class Initialized
INFO - 2024-03-07 20:51:27 --> Security Class Initialized
DEBUG - 2024-03-07 20:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:51:27 --> Input Class Initialized
INFO - 2024-03-07 20:51:27 --> Language Class Initialized
INFO - 2024-03-07 20:51:27 --> Loader Class Initialized
INFO - 2024-03-07 20:51:27 --> Helper loaded: url_helper
INFO - 2024-03-07 20:51:27 --> Helper loaded: file_helper
INFO - 2024-03-07 20:51:27 --> Helper loaded: form_helper
INFO - 2024-03-07 20:51:27 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:51:27 --> Controller Class Initialized
INFO - 2024-03-07 20:51:27 --> Form Validation Class Initialized
INFO - 2024-03-07 20:51:27 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:51:27 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:51:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:51:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:51:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:51:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:51:27 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:51:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:51:27 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:51:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:51:27 --> Final output sent to browser
DEBUG - 2024-03-07 20:51:27 --> Total execution time: 0.0215
ERROR - 2024-03-07 20:52:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:52:01 --> Config Class Initialized
INFO - 2024-03-07 20:52:01 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:52:01 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:52:01 --> Utf8 Class Initialized
INFO - 2024-03-07 20:52:01 --> URI Class Initialized
INFO - 2024-03-07 20:52:01 --> Router Class Initialized
INFO - 2024-03-07 20:52:01 --> Output Class Initialized
INFO - 2024-03-07 20:52:01 --> Security Class Initialized
DEBUG - 2024-03-07 20:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:52:01 --> Input Class Initialized
INFO - 2024-03-07 20:52:01 --> Language Class Initialized
INFO - 2024-03-07 20:52:01 --> Loader Class Initialized
INFO - 2024-03-07 20:52:01 --> Helper loaded: url_helper
INFO - 2024-03-07 20:52:01 --> Helper loaded: file_helper
INFO - 2024-03-07 20:52:01 --> Helper loaded: form_helper
INFO - 2024-03-07 20:52:01 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:52:01 --> Controller Class Initialized
INFO - 2024-03-07 20:52:01 --> Form Validation Class Initialized
INFO - 2024-03-07 20:52:01 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:52:01 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:52:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:52:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:52:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:52:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:52:01 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:52:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:52:01 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:52:01 --> Final output sent to browser
DEBUG - 2024-03-07 20:52:01 --> Total execution time: 0.0398
ERROR - 2024-03-07 20:52:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:52:03 --> Config Class Initialized
INFO - 2024-03-07 20:52:03 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:52:03 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:52:03 --> Utf8 Class Initialized
INFO - 2024-03-07 20:52:03 --> URI Class Initialized
INFO - 2024-03-07 20:52:03 --> Router Class Initialized
INFO - 2024-03-07 20:52:03 --> Output Class Initialized
INFO - 2024-03-07 20:52:03 --> Security Class Initialized
DEBUG - 2024-03-07 20:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:52:03 --> Input Class Initialized
INFO - 2024-03-07 20:52:03 --> Language Class Initialized
INFO - 2024-03-07 20:52:03 --> Loader Class Initialized
INFO - 2024-03-07 20:52:03 --> Helper loaded: url_helper
INFO - 2024-03-07 20:52:03 --> Helper loaded: file_helper
INFO - 2024-03-07 20:52:03 --> Helper loaded: form_helper
INFO - 2024-03-07 20:52:03 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:52:03 --> Controller Class Initialized
INFO - 2024-03-07 20:52:03 --> Form Validation Class Initialized
INFO - 2024-03-07 20:52:03 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:52:03 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:52:03 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:52:03 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:52:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:52:03 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:52:03 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:52:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:52:03 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:52:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:52:05 --> Config Class Initialized
INFO - 2024-03-07 20:52:05 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:52:05 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:52:05 --> Utf8 Class Initialized
INFO - 2024-03-07 20:52:05 --> URI Class Initialized
INFO - 2024-03-07 20:52:05 --> Router Class Initialized
INFO - 2024-03-07 20:52:05 --> Output Class Initialized
INFO - 2024-03-07 20:52:05 --> Security Class Initialized
DEBUG - 2024-03-07 20:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:52:05 --> Input Class Initialized
INFO - 2024-03-07 20:52:05 --> Language Class Initialized
INFO - 2024-03-07 20:52:05 --> Loader Class Initialized
INFO - 2024-03-07 20:52:05 --> Helper loaded: url_helper
INFO - 2024-03-07 20:52:05 --> Helper loaded: file_helper
INFO - 2024-03-07 20:52:05 --> Helper loaded: form_helper
INFO - 2024-03-07 20:52:05 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:52:05 --> Controller Class Initialized
INFO - 2024-03-07 20:52:05 --> Form Validation Class Initialized
INFO - 2024-03-07 20:52:05 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:52:05 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:52:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:52:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:52:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:52:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:52:05 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:52:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:52:05 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:52:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:52:05 --> Final output sent to browser
DEBUG - 2024-03-07 20:52:05 --> Total execution time: 0.0305
ERROR - 2024-03-07 20:52:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:52:34 --> Config Class Initialized
INFO - 2024-03-07 20:52:34 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:52:34 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:52:34 --> Utf8 Class Initialized
INFO - 2024-03-07 20:52:34 --> URI Class Initialized
INFO - 2024-03-07 20:52:34 --> Router Class Initialized
INFO - 2024-03-07 20:52:34 --> Output Class Initialized
INFO - 2024-03-07 20:52:34 --> Security Class Initialized
DEBUG - 2024-03-07 20:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:52:34 --> Input Class Initialized
INFO - 2024-03-07 20:52:34 --> Language Class Initialized
INFO - 2024-03-07 20:52:34 --> Loader Class Initialized
INFO - 2024-03-07 20:52:34 --> Helper loaded: url_helper
INFO - 2024-03-07 20:52:34 --> Helper loaded: file_helper
INFO - 2024-03-07 20:52:34 --> Helper loaded: form_helper
INFO - 2024-03-07 20:52:34 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:52:34 --> Controller Class Initialized
INFO - 2024-03-07 20:52:34 --> Form Validation Class Initialized
INFO - 2024-03-07 20:52:34 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:52:34 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:52:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:52:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:52:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:52:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:52:34 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:52:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:52:34 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:52:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:52:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:52:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:52:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:52:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:52:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:52:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:52:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:52:34 --> Final output sent to browser
DEBUG - 2024-03-07 20:52:34 --> Total execution time: 0.0477
ERROR - 2024-03-07 20:52:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:52:36 --> Config Class Initialized
INFO - 2024-03-07 20:52:36 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:52:36 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:52:36 --> Utf8 Class Initialized
INFO - 2024-03-07 20:52:36 --> URI Class Initialized
INFO - 2024-03-07 20:52:36 --> Router Class Initialized
INFO - 2024-03-07 20:52:36 --> Output Class Initialized
INFO - 2024-03-07 20:52:36 --> Security Class Initialized
DEBUG - 2024-03-07 20:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:52:36 --> Input Class Initialized
INFO - 2024-03-07 20:52:36 --> Language Class Initialized
INFO - 2024-03-07 20:52:36 --> Loader Class Initialized
INFO - 2024-03-07 20:52:36 --> Helper loaded: url_helper
INFO - 2024-03-07 20:52:36 --> Helper loaded: file_helper
INFO - 2024-03-07 20:52:36 --> Helper loaded: form_helper
INFO - 2024-03-07 20:52:36 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:52:36 --> Controller Class Initialized
INFO - 2024-03-07 20:52:36 --> Form Validation Class Initialized
INFO - 2024-03-07 20:52:36 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:52:36 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:52:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:52:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:52:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:52:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:52:36 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:52:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:52:36 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:52:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:52:38 --> Config Class Initialized
INFO - 2024-03-07 20:52:38 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:52:38 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:52:38 --> Utf8 Class Initialized
INFO - 2024-03-07 20:52:38 --> URI Class Initialized
INFO - 2024-03-07 20:52:38 --> Router Class Initialized
INFO - 2024-03-07 20:52:38 --> Output Class Initialized
INFO - 2024-03-07 20:52:38 --> Security Class Initialized
DEBUG - 2024-03-07 20:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:52:38 --> Input Class Initialized
INFO - 2024-03-07 20:52:38 --> Language Class Initialized
INFO - 2024-03-07 20:52:38 --> Loader Class Initialized
INFO - 2024-03-07 20:52:38 --> Helper loaded: url_helper
INFO - 2024-03-07 20:52:38 --> Helper loaded: file_helper
INFO - 2024-03-07 20:52:38 --> Helper loaded: form_helper
INFO - 2024-03-07 20:52:38 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:52:38 --> Controller Class Initialized
INFO - 2024-03-07 20:52:38 --> Form Validation Class Initialized
INFO - 2024-03-07 20:52:38 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:52:38 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:52:38 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:52:38 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:52:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:52:38 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:52:38 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:52:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:52:38 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:52:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:52:38 --> Final output sent to browser
DEBUG - 2024-03-07 20:52:38 --> Total execution time: 0.0308
ERROR - 2024-03-07 20:54:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:54:43 --> Config Class Initialized
INFO - 2024-03-07 20:54:43 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:54:43 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:54:43 --> Utf8 Class Initialized
INFO - 2024-03-07 20:54:43 --> URI Class Initialized
INFO - 2024-03-07 20:54:43 --> Router Class Initialized
INFO - 2024-03-07 20:54:43 --> Output Class Initialized
INFO - 2024-03-07 20:54:43 --> Security Class Initialized
DEBUG - 2024-03-07 20:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:54:43 --> Input Class Initialized
INFO - 2024-03-07 20:54:43 --> Language Class Initialized
INFO - 2024-03-07 20:54:43 --> Loader Class Initialized
INFO - 2024-03-07 20:54:43 --> Helper loaded: url_helper
INFO - 2024-03-07 20:54:43 --> Helper loaded: file_helper
INFO - 2024-03-07 20:54:43 --> Helper loaded: form_helper
INFO - 2024-03-07 20:54:43 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:54:43 --> Controller Class Initialized
INFO - 2024-03-07 20:54:43 --> Form Validation Class Initialized
INFO - 2024-03-07 20:54:43 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:54:43 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:54:43 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:54:43 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:54:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:54:43 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:54:43 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:54:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:54:43 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:54:43 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:54:43 --> Severity: Notice --> Undefined variable: Array D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:54:43 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:54:43 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:54:43 --> Severity: Notice --> Undefined variable: Array D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:54:43 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:54:43 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:54:43 --> Severity: Notice --> Undefined variable: Array D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:54:43 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:54:43 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:54:43 --> Severity: Notice --> Undefined variable: Array D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:54:43 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:55:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:55:00 --> Config Class Initialized
INFO - 2024-03-07 20:55:00 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:55:00 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:55:00 --> Utf8 Class Initialized
INFO - 2024-03-07 20:55:00 --> URI Class Initialized
INFO - 2024-03-07 20:55:00 --> Router Class Initialized
INFO - 2024-03-07 20:55:00 --> Output Class Initialized
INFO - 2024-03-07 20:55:00 --> Security Class Initialized
DEBUG - 2024-03-07 20:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:55:00 --> Input Class Initialized
INFO - 2024-03-07 20:55:00 --> Language Class Initialized
INFO - 2024-03-07 20:55:00 --> Loader Class Initialized
INFO - 2024-03-07 20:55:00 --> Helper loaded: url_helper
INFO - 2024-03-07 20:55:00 --> Helper loaded: file_helper
INFO - 2024-03-07 20:55:00 --> Helper loaded: form_helper
INFO - 2024-03-07 20:55:00 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:55:00 --> Controller Class Initialized
INFO - 2024-03-07 20:55:00 --> Form Validation Class Initialized
INFO - 2024-03-07 20:55:00 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:55:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:55:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:55:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:55:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:55:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:55:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:55:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:55:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:55:00 --> Final output sent to browser
DEBUG - 2024-03-07 20:55:00 --> Total execution time: 0.0358
ERROR - 2024-03-07 20:55:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:55:00 --> Config Class Initialized
INFO - 2024-03-07 20:55:00 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:55:00 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:55:00 --> Utf8 Class Initialized
INFO - 2024-03-07 20:55:00 --> URI Class Initialized
INFO - 2024-03-07 20:55:00 --> Router Class Initialized
INFO - 2024-03-07 20:55:00 --> Output Class Initialized
INFO - 2024-03-07 20:55:00 --> Security Class Initialized
DEBUG - 2024-03-07 20:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:55:00 --> Input Class Initialized
INFO - 2024-03-07 20:55:00 --> Language Class Initialized
INFO - 2024-03-07 20:55:00 --> Loader Class Initialized
INFO - 2024-03-07 20:55:00 --> Helper loaded: url_helper
INFO - 2024-03-07 20:55:00 --> Helper loaded: file_helper
INFO - 2024-03-07 20:55:00 --> Helper loaded: form_helper
INFO - 2024-03-07 20:55:00 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:55:00 --> Controller Class Initialized
INFO - 2024-03-07 20:55:00 --> Form Validation Class Initialized
INFO - 2024-03-07 20:55:00 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:55:00 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:55:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:55:05 --> Config Class Initialized
INFO - 2024-03-07 20:55:05 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:55:05 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:55:05 --> Utf8 Class Initialized
INFO - 2024-03-07 20:55:05 --> URI Class Initialized
INFO - 2024-03-07 20:55:05 --> Router Class Initialized
INFO - 2024-03-07 20:55:05 --> Output Class Initialized
INFO - 2024-03-07 20:55:05 --> Security Class Initialized
DEBUG - 2024-03-07 20:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:55:05 --> Input Class Initialized
INFO - 2024-03-07 20:55:05 --> Language Class Initialized
INFO - 2024-03-07 20:55:05 --> Loader Class Initialized
INFO - 2024-03-07 20:55:05 --> Helper loaded: url_helper
INFO - 2024-03-07 20:55:05 --> Helper loaded: file_helper
INFO - 2024-03-07 20:55:05 --> Helper loaded: form_helper
INFO - 2024-03-07 20:55:05 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:55:05 --> Controller Class Initialized
INFO - 2024-03-07 20:55:05 --> Form Validation Class Initialized
INFO - 2024-03-07 20:55:05 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:55:05 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:55:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:55:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:55:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:55:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:55:05 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:55:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:55:05 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:55:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:55:05 --> Final output sent to browser
DEBUG - 2024-03-07 20:55:05 --> Total execution time: 0.0348
ERROR - 2024-03-07 20:55:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:55:13 --> Config Class Initialized
INFO - 2024-03-07 20:55:13 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:55:13 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:55:13 --> Utf8 Class Initialized
INFO - 2024-03-07 20:55:13 --> URI Class Initialized
INFO - 2024-03-07 20:55:13 --> Router Class Initialized
INFO - 2024-03-07 20:55:13 --> Output Class Initialized
INFO - 2024-03-07 20:55:13 --> Security Class Initialized
DEBUG - 2024-03-07 20:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:55:13 --> Input Class Initialized
INFO - 2024-03-07 20:55:13 --> Language Class Initialized
INFO - 2024-03-07 20:55:13 --> Loader Class Initialized
INFO - 2024-03-07 20:55:13 --> Helper loaded: url_helper
INFO - 2024-03-07 20:55:13 --> Helper loaded: file_helper
INFO - 2024-03-07 20:55:13 --> Helper loaded: form_helper
INFO - 2024-03-07 20:55:13 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:55:13 --> Controller Class Initialized
INFO - 2024-03-07 20:55:13 --> Form Validation Class Initialized
INFO - 2024-03-07 20:55:13 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:55:13 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:55:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:55:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:55:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:55:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:55:13 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:55:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:55:13 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:55:13 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:55:13 --> Severity: Notice --> Undefined variable: Array D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:55:13 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:55:13 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:55:13 --> Severity: Notice --> Undefined variable: Array D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:55:13 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 54
ERROR - 2024-03-07 20:55:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:55:33 --> Config Class Initialized
INFO - 2024-03-07 20:55:33 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:55:33 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:55:33 --> Utf8 Class Initialized
INFO - 2024-03-07 20:55:33 --> URI Class Initialized
INFO - 2024-03-07 20:55:33 --> Router Class Initialized
INFO - 2024-03-07 20:55:33 --> Output Class Initialized
INFO - 2024-03-07 20:55:33 --> Security Class Initialized
DEBUG - 2024-03-07 20:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:55:33 --> Input Class Initialized
INFO - 2024-03-07 20:55:33 --> Language Class Initialized
INFO - 2024-03-07 20:55:33 --> Loader Class Initialized
INFO - 2024-03-07 20:55:33 --> Helper loaded: url_helper
INFO - 2024-03-07 20:55:33 --> Helper loaded: file_helper
INFO - 2024-03-07 20:55:33 --> Helper loaded: form_helper
INFO - 2024-03-07 20:55:33 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:55:33 --> Controller Class Initialized
INFO - 2024-03-07 20:55:33 --> Form Validation Class Initialized
INFO - 2024-03-07 20:55:33 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:55:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:55:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:55:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:55:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:55:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:55:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:55:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:55:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:55:33 --> Final output sent to browser
DEBUG - 2024-03-07 20:55:33 --> Total execution time: 0.0504
ERROR - 2024-03-07 20:55:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:55:33 --> Config Class Initialized
INFO - 2024-03-07 20:55:33 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:55:33 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:55:33 --> Utf8 Class Initialized
INFO - 2024-03-07 20:55:33 --> URI Class Initialized
INFO - 2024-03-07 20:55:33 --> Router Class Initialized
INFO - 2024-03-07 20:55:33 --> Output Class Initialized
INFO - 2024-03-07 20:55:33 --> Security Class Initialized
DEBUG - 2024-03-07 20:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:55:33 --> Input Class Initialized
INFO - 2024-03-07 20:55:33 --> Language Class Initialized
INFO - 2024-03-07 20:55:33 --> Loader Class Initialized
INFO - 2024-03-07 20:55:33 --> Helper loaded: url_helper
INFO - 2024-03-07 20:55:33 --> Helper loaded: file_helper
INFO - 2024-03-07 20:55:33 --> Helper loaded: form_helper
INFO - 2024-03-07 20:55:33 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:55:33 --> Controller Class Initialized
INFO - 2024-03-07 20:55:33 --> Form Validation Class Initialized
INFO - 2024-03-07 20:55:33 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:55:33 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:55:36 --> Config Class Initialized
INFO - 2024-03-07 20:55:36 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:55:36 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:55:36 --> Utf8 Class Initialized
INFO - 2024-03-07 20:55:36 --> URI Class Initialized
INFO - 2024-03-07 20:55:36 --> Router Class Initialized
INFO - 2024-03-07 20:55:36 --> Output Class Initialized
INFO - 2024-03-07 20:55:36 --> Security Class Initialized
DEBUG - 2024-03-07 20:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:55:36 --> Input Class Initialized
INFO - 2024-03-07 20:55:36 --> Language Class Initialized
INFO - 2024-03-07 20:55:36 --> Loader Class Initialized
INFO - 2024-03-07 20:55:36 --> Helper loaded: url_helper
INFO - 2024-03-07 20:55:36 --> Helper loaded: file_helper
INFO - 2024-03-07 20:55:36 --> Helper loaded: form_helper
INFO - 2024-03-07 20:55:36 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:55:36 --> Controller Class Initialized
INFO - 2024-03-07 20:55:36 --> Form Validation Class Initialized
INFO - 2024-03-07 20:55:36 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:55:36 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:55:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:55:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:55:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:55:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:55:36 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:55:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:55:36 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:55:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:55:36 --> Final output sent to browser
DEBUG - 2024-03-07 20:55:36 --> Total execution time: 0.0419
ERROR - 2024-03-07 20:55:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:55:41 --> Config Class Initialized
INFO - 2024-03-07 20:55:41 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:55:41 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:55:41 --> Utf8 Class Initialized
INFO - 2024-03-07 20:55:41 --> URI Class Initialized
INFO - 2024-03-07 20:55:41 --> Router Class Initialized
INFO - 2024-03-07 20:55:41 --> Output Class Initialized
INFO - 2024-03-07 20:55:41 --> Security Class Initialized
DEBUG - 2024-03-07 20:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:55:41 --> Input Class Initialized
INFO - 2024-03-07 20:55:41 --> Language Class Initialized
INFO - 2024-03-07 20:55:41 --> Loader Class Initialized
INFO - 2024-03-07 20:55:41 --> Helper loaded: url_helper
INFO - 2024-03-07 20:55:41 --> Helper loaded: file_helper
INFO - 2024-03-07 20:55:41 --> Helper loaded: form_helper
INFO - 2024-03-07 20:55:41 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:55:41 --> Controller Class Initialized
INFO - 2024-03-07 20:55:41 --> Form Validation Class Initialized
INFO - 2024-03-07 20:55:41 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:55:41 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:55:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:55:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:55:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:55:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:55:41 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:55:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:55:41 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:57:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:57:06 --> Config Class Initialized
INFO - 2024-03-07 20:57:06 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:57:06 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:57:06 --> Utf8 Class Initialized
INFO - 2024-03-07 20:57:06 --> URI Class Initialized
INFO - 2024-03-07 20:57:06 --> Router Class Initialized
INFO - 2024-03-07 20:57:06 --> Output Class Initialized
INFO - 2024-03-07 20:57:06 --> Security Class Initialized
DEBUG - 2024-03-07 20:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:57:06 --> Input Class Initialized
INFO - 2024-03-07 20:57:06 --> Language Class Initialized
INFO - 2024-03-07 20:57:06 --> Loader Class Initialized
INFO - 2024-03-07 20:57:06 --> Helper loaded: url_helper
INFO - 2024-03-07 20:57:06 --> Helper loaded: file_helper
INFO - 2024-03-07 20:57:06 --> Helper loaded: form_helper
INFO - 2024-03-07 20:57:06 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:57:06 --> Controller Class Initialized
INFO - 2024-03-07 20:57:06 --> Form Validation Class Initialized
INFO - 2024-03-07 20:57:06 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:57:06 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:57:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:57:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:57:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:57:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:57:06 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:57:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:57:06 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:57:06 --> Final output sent to browser
DEBUG - 2024-03-07 20:57:06 --> Total execution time: 0.0316
ERROR - 2024-03-07 20:57:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:57:07 --> Config Class Initialized
INFO - 2024-03-07 20:57:07 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:57:07 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:57:07 --> Utf8 Class Initialized
INFO - 2024-03-07 20:57:07 --> URI Class Initialized
INFO - 2024-03-07 20:57:07 --> Router Class Initialized
INFO - 2024-03-07 20:57:07 --> Output Class Initialized
INFO - 2024-03-07 20:57:07 --> Security Class Initialized
DEBUG - 2024-03-07 20:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:57:07 --> Input Class Initialized
INFO - 2024-03-07 20:57:07 --> Language Class Initialized
INFO - 2024-03-07 20:57:07 --> Loader Class Initialized
INFO - 2024-03-07 20:57:07 --> Helper loaded: url_helper
INFO - 2024-03-07 20:57:07 --> Helper loaded: file_helper
INFO - 2024-03-07 20:57:07 --> Helper loaded: form_helper
INFO - 2024-03-07 20:57:07 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:57:07 --> Controller Class Initialized
INFO - 2024-03-07 20:57:07 --> Form Validation Class Initialized
INFO - 2024-03-07 20:57:07 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:57:07 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:57:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:57:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:57:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:57:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:57:07 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:57:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:57:07 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:57:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:57:29 --> Config Class Initialized
INFO - 2024-03-07 20:57:29 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:57:29 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:57:29 --> Utf8 Class Initialized
INFO - 2024-03-07 20:57:29 --> URI Class Initialized
INFO - 2024-03-07 20:57:29 --> Router Class Initialized
INFO - 2024-03-07 20:57:29 --> Output Class Initialized
INFO - 2024-03-07 20:57:29 --> Security Class Initialized
DEBUG - 2024-03-07 20:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:57:29 --> Input Class Initialized
INFO - 2024-03-07 20:57:29 --> Language Class Initialized
INFO - 2024-03-07 20:57:29 --> Loader Class Initialized
INFO - 2024-03-07 20:57:29 --> Helper loaded: url_helper
INFO - 2024-03-07 20:57:29 --> Helper loaded: file_helper
INFO - 2024-03-07 20:57:29 --> Helper loaded: form_helper
INFO - 2024-03-07 20:57:29 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:57:29 --> Controller Class Initialized
INFO - 2024-03-07 20:57:29 --> Form Validation Class Initialized
INFO - 2024-03-07 20:57:29 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:57:29 --> Final output sent to browser
DEBUG - 2024-03-07 20:57:29 --> Total execution time: 0.0403
ERROR - 2024-03-07 20:57:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:57:29 --> Config Class Initialized
INFO - 2024-03-07 20:57:29 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:57:29 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:57:29 --> Utf8 Class Initialized
INFO - 2024-03-07 20:57:29 --> URI Class Initialized
INFO - 2024-03-07 20:57:29 --> Router Class Initialized
INFO - 2024-03-07 20:57:29 --> Output Class Initialized
INFO - 2024-03-07 20:57:29 --> Security Class Initialized
DEBUG - 2024-03-07 20:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:57:29 --> Input Class Initialized
INFO - 2024-03-07 20:57:29 --> Language Class Initialized
INFO - 2024-03-07 20:57:29 --> Loader Class Initialized
INFO - 2024-03-07 20:57:29 --> Helper loaded: url_helper
INFO - 2024-03-07 20:57:29 --> Helper loaded: file_helper
INFO - 2024-03-07 20:57:29 --> Helper loaded: form_helper
INFO - 2024-03-07 20:57:29 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:57:29 --> Controller Class Initialized
INFO - 2024-03-07 20:57:29 --> Form Validation Class Initialized
INFO - 2024-03-07 20:57:29 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:57:29 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:58:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:58:11 --> Config Class Initialized
INFO - 2024-03-07 20:58:11 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:58:11 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:58:11 --> Utf8 Class Initialized
INFO - 2024-03-07 20:58:11 --> URI Class Initialized
INFO - 2024-03-07 20:58:11 --> Router Class Initialized
INFO - 2024-03-07 20:58:11 --> Output Class Initialized
INFO - 2024-03-07 20:58:11 --> Security Class Initialized
DEBUG - 2024-03-07 20:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:58:11 --> Input Class Initialized
INFO - 2024-03-07 20:58:11 --> Language Class Initialized
INFO - 2024-03-07 20:58:11 --> Loader Class Initialized
INFO - 2024-03-07 20:58:11 --> Helper loaded: url_helper
INFO - 2024-03-07 20:58:11 --> Helper loaded: file_helper
INFO - 2024-03-07 20:58:11 --> Helper loaded: form_helper
INFO - 2024-03-07 20:58:11 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:58:11 --> Controller Class Initialized
INFO - 2024-03-07 20:58:11 --> Form Validation Class Initialized
INFO - 2024-03-07 20:58:11 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:58:11 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:58:11 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:58:11 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:58:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:58:11 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:58:11 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:58:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:58:11 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:58:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:58:11 --> Final output sent to browser
DEBUG - 2024-03-07 20:58:11 --> Total execution time: 0.0456
ERROR - 2024-03-07 20:58:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:58:13 --> Config Class Initialized
INFO - 2024-03-07 20:58:13 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:58:13 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:58:13 --> Utf8 Class Initialized
INFO - 2024-03-07 20:58:13 --> URI Class Initialized
INFO - 2024-03-07 20:58:13 --> Router Class Initialized
INFO - 2024-03-07 20:58:13 --> Output Class Initialized
INFO - 2024-03-07 20:58:13 --> Security Class Initialized
DEBUG - 2024-03-07 20:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:58:13 --> Input Class Initialized
INFO - 2024-03-07 20:58:13 --> Language Class Initialized
INFO - 2024-03-07 20:58:13 --> Loader Class Initialized
INFO - 2024-03-07 20:58:13 --> Helper loaded: url_helper
INFO - 2024-03-07 20:58:13 --> Helper loaded: file_helper
INFO - 2024-03-07 20:58:13 --> Helper loaded: form_helper
INFO - 2024-03-07 20:58:13 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:58:13 --> Controller Class Initialized
INFO - 2024-03-07 20:58:13 --> Form Validation Class Initialized
INFO - 2024-03-07 20:58:13 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:58:13 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:58:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:58:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:58:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:58:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:58:13 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:58:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:58:13 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:58:19 --> Config Class Initialized
INFO - 2024-03-07 20:58:19 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:58:19 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:58:19 --> Utf8 Class Initialized
INFO - 2024-03-07 20:58:19 --> URI Class Initialized
INFO - 2024-03-07 20:58:19 --> Router Class Initialized
INFO - 2024-03-07 20:58:19 --> Output Class Initialized
INFO - 2024-03-07 20:58:19 --> Security Class Initialized
DEBUG - 2024-03-07 20:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:58:19 --> Input Class Initialized
INFO - 2024-03-07 20:58:19 --> Language Class Initialized
INFO - 2024-03-07 20:58:19 --> Loader Class Initialized
INFO - 2024-03-07 20:58:19 --> Helper loaded: url_helper
INFO - 2024-03-07 20:58:19 --> Helper loaded: file_helper
INFO - 2024-03-07 20:58:19 --> Helper loaded: form_helper
INFO - 2024-03-07 20:58:19 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:58:19 --> Controller Class Initialized
INFO - 2024-03-07 20:58:19 --> Form Validation Class Initialized
INFO - 2024-03-07 20:58:19 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:58:19 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:58:19 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:58:19 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:58:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:58:19 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:58:19 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:58:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:58:19 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:58:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 20:58:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 20:58:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 20:58:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 20:58:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 20:58:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 20:58:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 20:58:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 20:58:19 --> Final output sent to browser
DEBUG - 2024-03-07 20:58:19 --> Total execution time: 0.0425
ERROR - 2024-03-07 20:58:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:58:20 --> Config Class Initialized
INFO - 2024-03-07 20:58:20 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:58:20 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:58:20 --> Utf8 Class Initialized
INFO - 2024-03-07 20:58:20 --> URI Class Initialized
INFO - 2024-03-07 20:58:20 --> Router Class Initialized
INFO - 2024-03-07 20:58:20 --> Output Class Initialized
INFO - 2024-03-07 20:58:20 --> Security Class Initialized
DEBUG - 2024-03-07 20:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:58:20 --> Input Class Initialized
INFO - 2024-03-07 20:58:20 --> Language Class Initialized
INFO - 2024-03-07 20:58:20 --> Loader Class Initialized
INFO - 2024-03-07 20:58:20 --> Helper loaded: url_helper
INFO - 2024-03-07 20:58:20 --> Helper loaded: file_helper
INFO - 2024-03-07 20:58:20 --> Helper loaded: form_helper
INFO - 2024-03-07 20:58:20 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:58:20 --> Controller Class Initialized
INFO - 2024-03-07 20:58:20 --> Form Validation Class Initialized
INFO - 2024-03-07 20:58:20 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:58:20 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:58:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:58:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:58:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:58:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:58:20 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:58:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:58:20 --> Model "ReportModel" initialized
ERROR - 2024-03-07 20:58:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:58:29 --> Config Class Initialized
INFO - 2024-03-07 20:58:29 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:58:29 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:58:29 --> Utf8 Class Initialized
INFO - 2024-03-07 20:58:29 --> URI Class Initialized
INFO - 2024-03-07 20:58:29 --> Router Class Initialized
INFO - 2024-03-07 20:58:29 --> Output Class Initialized
INFO - 2024-03-07 20:58:29 --> Security Class Initialized
DEBUG - 2024-03-07 20:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:58:29 --> Input Class Initialized
INFO - 2024-03-07 20:58:29 --> Language Class Initialized
INFO - 2024-03-07 20:58:29 --> Loader Class Initialized
INFO - 2024-03-07 20:58:29 --> Helper loaded: url_helper
INFO - 2024-03-07 20:58:29 --> Helper loaded: file_helper
INFO - 2024-03-07 20:58:29 --> Helper loaded: form_helper
INFO - 2024-03-07 20:58:29 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:58:29 --> Controller Class Initialized
INFO - 2024-03-07 20:58:29 --> Form Validation Class Initialized
INFO - 2024-03-07 20:58:29 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:58:29 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:58:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:58:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:58:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:58:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:58:29 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:58:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:58:29 --> Model "ReportModel" initialized
INFO - 2024-03-07 20:58:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-07 20:58:29 --> Final output sent to browser
DEBUG - 2024-03-07 20:58:29 --> Total execution time: 0.0428
ERROR - 2024-03-07 20:58:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 20:58:33 --> Config Class Initialized
INFO - 2024-03-07 20:58:33 --> Hooks Class Initialized
DEBUG - 2024-03-07 20:58:33 --> UTF-8 Support Enabled
INFO - 2024-03-07 20:58:33 --> Utf8 Class Initialized
INFO - 2024-03-07 20:58:33 --> URI Class Initialized
INFO - 2024-03-07 20:58:33 --> Router Class Initialized
INFO - 2024-03-07 20:58:33 --> Output Class Initialized
INFO - 2024-03-07 20:58:33 --> Security Class Initialized
DEBUG - 2024-03-07 20:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 20:58:33 --> Input Class Initialized
INFO - 2024-03-07 20:58:33 --> Language Class Initialized
INFO - 2024-03-07 20:58:33 --> Loader Class Initialized
INFO - 2024-03-07 20:58:33 --> Helper loaded: url_helper
INFO - 2024-03-07 20:58:33 --> Helper loaded: file_helper
INFO - 2024-03-07 20:58:33 --> Helper loaded: form_helper
INFO - 2024-03-07 20:58:33 --> Database Driver Class Initialized
DEBUG - 2024-03-07 20:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 20:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 20:58:33 --> Controller Class Initialized
INFO - 2024-03-07 20:58:33 --> Form Validation Class Initialized
INFO - 2024-03-07 20:58:33 --> Model "MasterModel" initialized
INFO - 2024-03-07 20:58:33 --> Model "DashboardModel" initialized
INFO - 2024-03-07 20:58:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 20:58:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 20:58:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 20:58:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 20:58:33 --> Model "OrderModel" initialized
INFO - 2024-03-07 20:58:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 20:58:33 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:03:36 --> Config Class Initialized
INFO - 2024-03-07 21:03:36 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:03:36 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:03:36 --> Utf8 Class Initialized
INFO - 2024-03-07 21:03:36 --> URI Class Initialized
INFO - 2024-03-07 21:03:36 --> Router Class Initialized
INFO - 2024-03-07 21:03:36 --> Output Class Initialized
INFO - 2024-03-07 21:03:36 --> Security Class Initialized
DEBUG - 2024-03-07 21:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:03:36 --> Input Class Initialized
INFO - 2024-03-07 21:03:36 --> Language Class Initialized
INFO - 2024-03-07 21:03:36 --> Loader Class Initialized
INFO - 2024-03-07 21:03:36 --> Helper loaded: url_helper
INFO - 2024-03-07 21:03:36 --> Helper loaded: file_helper
INFO - 2024-03-07 21:03:36 --> Helper loaded: form_helper
INFO - 2024-03-07 21:03:36 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:03:36 --> Controller Class Initialized
INFO - 2024-03-07 21:03:36 --> Form Validation Class Initialized
INFO - 2024-03-07 21:03:36 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:03:36 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:03:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:03:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:03:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:03:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:03:36 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:03:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:03:36 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:03:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:03:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-07 21:03:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 21:03:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:03:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:03:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:03:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-07 21:03:36 --> Final output sent to browser
DEBUG - 2024-03-07 21:03:36 --> Total execution time: 0.0354
ERROR - 2024-03-07 21:03:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:03:37 --> Config Class Initialized
INFO - 2024-03-07 21:03:37 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:03:37 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:03:37 --> Utf8 Class Initialized
INFO - 2024-03-07 21:03:37 --> URI Class Initialized
INFO - 2024-03-07 21:03:37 --> Router Class Initialized
INFO - 2024-03-07 21:03:37 --> Output Class Initialized
INFO - 2024-03-07 21:03:37 --> Security Class Initialized
DEBUG - 2024-03-07 21:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:03:37 --> Input Class Initialized
INFO - 2024-03-07 21:03:37 --> Language Class Initialized
INFO - 2024-03-07 21:03:37 --> Loader Class Initialized
INFO - 2024-03-07 21:03:37 --> Helper loaded: url_helper
INFO - 2024-03-07 21:03:37 --> Helper loaded: file_helper
INFO - 2024-03-07 21:03:37 --> Helper loaded: form_helper
INFO - 2024-03-07 21:03:37 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:03:37 --> Controller Class Initialized
INFO - 2024-03-07 21:03:37 --> Form Validation Class Initialized
INFO - 2024-03-07 21:03:37 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:03:37 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:03:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:03:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:03:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:03:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:03:37 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:03:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:03:37 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:16:26 --> Config Class Initialized
INFO - 2024-03-07 21:16:26 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:16:26 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:16:26 --> Utf8 Class Initialized
INFO - 2024-03-07 21:16:26 --> URI Class Initialized
INFO - 2024-03-07 21:16:26 --> Router Class Initialized
INFO - 2024-03-07 21:16:26 --> Output Class Initialized
INFO - 2024-03-07 21:16:26 --> Security Class Initialized
DEBUG - 2024-03-07 21:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:16:26 --> Input Class Initialized
INFO - 2024-03-07 21:16:26 --> Language Class Initialized
INFO - 2024-03-07 21:16:26 --> Loader Class Initialized
INFO - 2024-03-07 21:16:26 --> Helper loaded: url_helper
INFO - 2024-03-07 21:16:26 --> Helper loaded: file_helper
INFO - 2024-03-07 21:16:26 --> Helper loaded: form_helper
INFO - 2024-03-07 21:16:26 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:16:26 --> Controller Class Initialized
INFO - 2024-03-07 21:16:26 --> Form Validation Class Initialized
INFO - 2024-03-07 21:16:26 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 21:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 21:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 21:16:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 21:16:26 --> Final output sent to browser
DEBUG - 2024-03-07 21:16:26 --> Total execution time: 0.0329
ERROR - 2024-03-07 21:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:16:26 --> Config Class Initialized
INFO - 2024-03-07 21:16:26 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:16:26 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:16:26 --> Utf8 Class Initialized
INFO - 2024-03-07 21:16:26 --> URI Class Initialized
INFO - 2024-03-07 21:16:26 --> Router Class Initialized
INFO - 2024-03-07 21:16:26 --> Output Class Initialized
INFO - 2024-03-07 21:16:26 --> Security Class Initialized
DEBUG - 2024-03-07 21:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:16:26 --> Input Class Initialized
INFO - 2024-03-07 21:16:26 --> Language Class Initialized
INFO - 2024-03-07 21:16:26 --> Loader Class Initialized
INFO - 2024-03-07 21:16:26 --> Helper loaded: url_helper
INFO - 2024-03-07 21:16:26 --> Helper loaded: file_helper
INFO - 2024-03-07 21:16:26 --> Helper loaded: form_helper
INFO - 2024-03-07 21:16:26 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:16:26 --> Controller Class Initialized
INFO - 2024-03-07 21:16:26 --> Form Validation Class Initialized
INFO - 2024-03-07 21:16:26 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:16:26 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:16:31 --> Config Class Initialized
INFO - 2024-03-07 21:16:31 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:16:31 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:16:31 --> Utf8 Class Initialized
INFO - 2024-03-07 21:16:31 --> URI Class Initialized
INFO - 2024-03-07 21:16:31 --> Router Class Initialized
INFO - 2024-03-07 21:16:31 --> Output Class Initialized
INFO - 2024-03-07 21:16:31 --> Security Class Initialized
DEBUG - 2024-03-07 21:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:16:31 --> Input Class Initialized
INFO - 2024-03-07 21:16:31 --> Language Class Initialized
INFO - 2024-03-07 21:16:31 --> Loader Class Initialized
INFO - 2024-03-07 21:16:31 --> Helper loaded: url_helper
INFO - 2024-03-07 21:16:31 --> Helper loaded: file_helper
INFO - 2024-03-07 21:16:31 --> Helper loaded: form_helper
INFO - 2024-03-07 21:16:31 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:16:31 --> Controller Class Initialized
INFO - 2024-03-07 21:16:31 --> Form Validation Class Initialized
INFO - 2024-03-07 21:16:31 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:16:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:16:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-07 21:16:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 21:16:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:16:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:16:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:16:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-07 21:16:31 --> Final output sent to browser
DEBUG - 2024-03-07 21:16:31 --> Total execution time: 0.0242
ERROR - 2024-03-07 21:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:16:31 --> Config Class Initialized
INFO - 2024-03-07 21:16:31 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:16:31 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:16:31 --> Utf8 Class Initialized
INFO - 2024-03-07 21:16:31 --> URI Class Initialized
INFO - 2024-03-07 21:16:31 --> Router Class Initialized
INFO - 2024-03-07 21:16:31 --> Output Class Initialized
INFO - 2024-03-07 21:16:31 --> Security Class Initialized
DEBUG - 2024-03-07 21:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:16:31 --> Input Class Initialized
INFO - 2024-03-07 21:16:31 --> Language Class Initialized
INFO - 2024-03-07 21:16:31 --> Loader Class Initialized
INFO - 2024-03-07 21:16:31 --> Helper loaded: url_helper
INFO - 2024-03-07 21:16:31 --> Helper loaded: file_helper
INFO - 2024-03-07 21:16:31 --> Helper loaded: form_helper
INFO - 2024-03-07 21:16:31 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:16:31 --> Controller Class Initialized
INFO - 2024-03-07 21:16:31 --> Form Validation Class Initialized
INFO - 2024-03-07 21:16:31 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:16:31 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:16:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:16:35 --> Config Class Initialized
INFO - 2024-03-07 21:16:35 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:16:35 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:16:35 --> Utf8 Class Initialized
INFO - 2024-03-07 21:16:35 --> URI Class Initialized
INFO - 2024-03-07 21:16:35 --> Router Class Initialized
INFO - 2024-03-07 21:16:35 --> Output Class Initialized
INFO - 2024-03-07 21:16:35 --> Security Class Initialized
DEBUG - 2024-03-07 21:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:16:35 --> Input Class Initialized
INFO - 2024-03-07 21:16:35 --> Language Class Initialized
INFO - 2024-03-07 21:16:35 --> Loader Class Initialized
INFO - 2024-03-07 21:16:35 --> Helper loaded: url_helper
INFO - 2024-03-07 21:16:35 --> Helper loaded: file_helper
INFO - 2024-03-07 21:16:35 --> Helper loaded: form_helper
INFO - 2024-03-07 21:16:35 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:16:35 --> Controller Class Initialized
INFO - 2024-03-07 21:16:35 --> Form Validation Class Initialized
INFO - 2024-03-07 21:16:35 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:16:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:16:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 21:16:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:16:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:16:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:16:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-07 21:16:35 --> Final output sent to browser
DEBUG - 2024-03-07 21:16:35 --> Total execution time: 0.0352
ERROR - 2024-03-07 21:16:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:16:35 --> Config Class Initialized
INFO - 2024-03-07 21:16:35 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:16:35 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:16:35 --> Utf8 Class Initialized
INFO - 2024-03-07 21:16:35 --> URI Class Initialized
INFO - 2024-03-07 21:16:35 --> Router Class Initialized
INFO - 2024-03-07 21:16:35 --> Output Class Initialized
INFO - 2024-03-07 21:16:35 --> Security Class Initialized
DEBUG - 2024-03-07 21:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:16:35 --> Input Class Initialized
INFO - 2024-03-07 21:16:35 --> Language Class Initialized
INFO - 2024-03-07 21:16:35 --> Loader Class Initialized
INFO - 2024-03-07 21:16:35 --> Helper loaded: url_helper
INFO - 2024-03-07 21:16:35 --> Helper loaded: file_helper
INFO - 2024-03-07 21:16:35 --> Helper loaded: form_helper
INFO - 2024-03-07 21:16:35 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:16:35 --> Controller Class Initialized
INFO - 2024-03-07 21:16:35 --> Form Validation Class Initialized
INFO - 2024-03-07 21:16:35 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:16:35 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:17:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:17:19 --> Config Class Initialized
INFO - 2024-03-07 21:17:19 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:17:19 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:17:19 --> Utf8 Class Initialized
INFO - 2024-03-07 21:17:19 --> URI Class Initialized
INFO - 2024-03-07 21:17:19 --> Router Class Initialized
INFO - 2024-03-07 21:17:19 --> Output Class Initialized
INFO - 2024-03-07 21:17:19 --> Security Class Initialized
DEBUG - 2024-03-07 21:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:17:19 --> Input Class Initialized
INFO - 2024-03-07 21:17:19 --> Language Class Initialized
INFO - 2024-03-07 21:17:19 --> Loader Class Initialized
INFO - 2024-03-07 21:17:19 --> Helper loaded: url_helper
INFO - 2024-03-07 21:17:19 --> Helper loaded: file_helper
INFO - 2024-03-07 21:17:19 --> Helper loaded: form_helper
INFO - 2024-03-07 21:17:19 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:17:19 --> Controller Class Initialized
INFO - 2024-03-07 21:17:19 --> Form Validation Class Initialized
INFO - 2024-03-07 21:17:19 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:17:19 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:17:19 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:17:19 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:17:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:17:19 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:17:19 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:17:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:17:19 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:17:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:17:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 21:17:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:17:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:17:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:17:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-07 21:17:19 --> Final output sent to browser
DEBUG - 2024-03-07 21:17:19 --> Total execution time: 0.0320
ERROR - 2024-03-07 21:17:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:17:20 --> Config Class Initialized
INFO - 2024-03-07 21:17:20 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:17:20 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:17:20 --> Utf8 Class Initialized
INFO - 2024-03-07 21:17:20 --> URI Class Initialized
INFO - 2024-03-07 21:17:20 --> Router Class Initialized
INFO - 2024-03-07 21:17:20 --> Output Class Initialized
INFO - 2024-03-07 21:17:20 --> Security Class Initialized
DEBUG - 2024-03-07 21:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:17:20 --> Input Class Initialized
INFO - 2024-03-07 21:17:20 --> Language Class Initialized
INFO - 2024-03-07 21:17:20 --> Loader Class Initialized
INFO - 2024-03-07 21:17:20 --> Helper loaded: url_helper
INFO - 2024-03-07 21:17:20 --> Helper loaded: file_helper
INFO - 2024-03-07 21:17:20 --> Helper loaded: form_helper
INFO - 2024-03-07 21:17:20 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:17:20 --> Controller Class Initialized
INFO - 2024-03-07 21:17:20 --> Form Validation Class Initialized
INFO - 2024-03-07 21:17:20 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:17:20 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:17:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:17:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:17:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:17:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:17:20 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:17:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:17:20 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:17:45 --> Config Class Initialized
INFO - 2024-03-07 21:17:45 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:17:45 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:17:45 --> Utf8 Class Initialized
INFO - 2024-03-07 21:17:45 --> URI Class Initialized
INFO - 2024-03-07 21:17:45 --> Router Class Initialized
INFO - 2024-03-07 21:17:45 --> Output Class Initialized
INFO - 2024-03-07 21:17:45 --> Security Class Initialized
DEBUG - 2024-03-07 21:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:17:45 --> Input Class Initialized
INFO - 2024-03-07 21:17:45 --> Language Class Initialized
INFO - 2024-03-07 21:17:45 --> Loader Class Initialized
INFO - 2024-03-07 21:17:45 --> Helper loaded: url_helper
INFO - 2024-03-07 21:17:45 --> Helper loaded: file_helper
INFO - 2024-03-07 21:17:45 --> Helper loaded: form_helper
INFO - 2024-03-07 21:17:45 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:17:45 --> Controller Class Initialized
INFO - 2024-03-07 21:17:45 --> Form Validation Class Initialized
INFO - 2024-03-07 21:17:45 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:17:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:17:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 21:17:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:17:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:17:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:17:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-07 21:17:45 --> Final output sent to browser
DEBUG - 2024-03-07 21:17:45 --> Total execution time: 0.0429
ERROR - 2024-03-07 21:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:17:45 --> Config Class Initialized
INFO - 2024-03-07 21:17:45 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:17:45 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:17:45 --> Utf8 Class Initialized
INFO - 2024-03-07 21:17:45 --> URI Class Initialized
INFO - 2024-03-07 21:17:45 --> Router Class Initialized
INFO - 2024-03-07 21:17:45 --> Output Class Initialized
INFO - 2024-03-07 21:17:45 --> Security Class Initialized
DEBUG - 2024-03-07 21:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:17:45 --> Input Class Initialized
INFO - 2024-03-07 21:17:45 --> Language Class Initialized
INFO - 2024-03-07 21:17:45 --> Loader Class Initialized
INFO - 2024-03-07 21:17:45 --> Helper loaded: url_helper
INFO - 2024-03-07 21:17:45 --> Helper loaded: file_helper
INFO - 2024-03-07 21:17:45 --> Helper loaded: form_helper
INFO - 2024-03-07 21:17:45 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:17:45 --> Controller Class Initialized
INFO - 2024-03-07 21:17:45 --> Form Validation Class Initialized
INFO - 2024-03-07 21:17:45 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:17:45 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:18:54 --> Config Class Initialized
INFO - 2024-03-07 21:18:54 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:18:54 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:18:54 --> Utf8 Class Initialized
INFO - 2024-03-07 21:18:54 --> URI Class Initialized
INFO - 2024-03-07 21:18:54 --> Router Class Initialized
INFO - 2024-03-07 21:18:54 --> Output Class Initialized
INFO - 2024-03-07 21:18:54 --> Security Class Initialized
DEBUG - 2024-03-07 21:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:18:54 --> Input Class Initialized
INFO - 2024-03-07 21:18:54 --> Language Class Initialized
INFO - 2024-03-07 21:18:54 --> Loader Class Initialized
INFO - 2024-03-07 21:18:54 --> Helper loaded: url_helper
INFO - 2024-03-07 21:18:54 --> Helper loaded: file_helper
INFO - 2024-03-07 21:18:54 --> Helper loaded: form_helper
INFO - 2024-03-07 21:18:54 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:18:54 --> Controller Class Initialized
INFO - 2024-03-07 21:18:54 --> Form Validation Class Initialized
INFO - 2024-03-07 21:18:54 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:18:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:18:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 21:18:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:18:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:18:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:18:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-07 21:18:54 --> Final output sent to browser
DEBUG - 2024-03-07 21:18:54 --> Total execution time: 0.0352
ERROR - 2024-03-07 21:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:18:54 --> Config Class Initialized
INFO - 2024-03-07 21:18:54 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:18:54 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:18:54 --> Utf8 Class Initialized
INFO - 2024-03-07 21:18:54 --> URI Class Initialized
INFO - 2024-03-07 21:18:54 --> Router Class Initialized
INFO - 2024-03-07 21:18:54 --> Output Class Initialized
INFO - 2024-03-07 21:18:54 --> Security Class Initialized
DEBUG - 2024-03-07 21:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:18:54 --> Input Class Initialized
INFO - 2024-03-07 21:18:54 --> Language Class Initialized
INFO - 2024-03-07 21:18:54 --> Loader Class Initialized
INFO - 2024-03-07 21:18:54 --> Helper loaded: url_helper
INFO - 2024-03-07 21:18:54 --> Helper loaded: file_helper
INFO - 2024-03-07 21:18:54 --> Helper loaded: form_helper
INFO - 2024-03-07 21:18:54 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:18:54 --> Controller Class Initialized
INFO - 2024-03-07 21:18:54 --> Form Validation Class Initialized
INFO - 2024-03-07 21:18:54 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:18:54 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:19:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:19:01 --> Config Class Initialized
INFO - 2024-03-07 21:19:01 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:19:01 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:19:01 --> Utf8 Class Initialized
INFO - 2024-03-07 21:19:01 --> URI Class Initialized
INFO - 2024-03-07 21:19:01 --> Router Class Initialized
INFO - 2024-03-07 21:19:01 --> Output Class Initialized
INFO - 2024-03-07 21:19:01 --> Security Class Initialized
DEBUG - 2024-03-07 21:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:19:01 --> Input Class Initialized
INFO - 2024-03-07 21:19:01 --> Language Class Initialized
INFO - 2024-03-07 21:19:01 --> Loader Class Initialized
INFO - 2024-03-07 21:19:01 --> Helper loaded: url_helper
INFO - 2024-03-07 21:19:01 --> Helper loaded: file_helper
INFO - 2024-03-07 21:19:01 --> Helper loaded: form_helper
INFO - 2024-03-07 21:19:01 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:19:01 --> Controller Class Initialized
INFO - 2024-03-07 21:19:01 --> Form Validation Class Initialized
INFO - 2024-03-07 21:19:01 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:19:01 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:19:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:19:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:19:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:19:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:19:01 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:19:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:19:01 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:19:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:19:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 21:19:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:19:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:19:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:19:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-07 21:19:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-07 21:19:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-07 21:19:01 --> Final output sent to browser
DEBUG - 2024-03-07 21:19:01 --> Total execution time: 0.0405
ERROR - 2024-03-07 21:19:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:19:01 --> Config Class Initialized
INFO - 2024-03-07 21:19:01 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:19:01 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:19:01 --> Utf8 Class Initialized
INFO - 2024-03-07 21:19:01 --> URI Class Initialized
INFO - 2024-03-07 21:19:01 --> Router Class Initialized
INFO - 2024-03-07 21:19:01 --> Output Class Initialized
INFO - 2024-03-07 21:19:01 --> Security Class Initialized
DEBUG - 2024-03-07 21:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:19:01 --> Input Class Initialized
INFO - 2024-03-07 21:19:01 --> Language Class Initialized
INFO - 2024-03-07 21:19:01 --> Loader Class Initialized
INFO - 2024-03-07 21:19:01 --> Helper loaded: url_helper
INFO - 2024-03-07 21:19:01 --> Helper loaded: file_helper
INFO - 2024-03-07 21:19:01 --> Helper loaded: form_helper
INFO - 2024-03-07 21:19:01 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:19:01 --> Controller Class Initialized
INFO - 2024-03-07 21:19:02 --> Form Validation Class Initialized
INFO - 2024-03-07 21:19:02 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:19:02 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:19:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:19:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:19:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:19:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:19:02 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:19:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:19:02 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:19:06 --> Config Class Initialized
INFO - 2024-03-07 21:19:06 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:19:06 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:19:06 --> Utf8 Class Initialized
INFO - 2024-03-07 21:19:06 --> URI Class Initialized
INFO - 2024-03-07 21:19:06 --> Router Class Initialized
INFO - 2024-03-07 21:19:06 --> Output Class Initialized
INFO - 2024-03-07 21:19:06 --> Security Class Initialized
DEBUG - 2024-03-07 21:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:19:06 --> Input Class Initialized
INFO - 2024-03-07 21:19:06 --> Language Class Initialized
INFO - 2024-03-07 21:19:06 --> Loader Class Initialized
INFO - 2024-03-07 21:19:06 --> Helper loaded: url_helper
INFO - 2024-03-07 21:19:06 --> Helper loaded: file_helper
INFO - 2024-03-07 21:19:06 --> Helper loaded: form_helper
INFO - 2024-03-07 21:19:06 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:19:06 --> Controller Class Initialized
INFO - 2024-03-07 21:19:06 --> Form Validation Class Initialized
INFO - 2024-03-07 21:19:06 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:19:06 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:19:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:19:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:19:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:19:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:19:06 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:19:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:19:07 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:19:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:19:07 --> Config Class Initialized
INFO - 2024-03-07 21:19:07 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:19:07 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:19:07 --> Utf8 Class Initialized
INFO - 2024-03-07 21:19:07 --> URI Class Initialized
INFO - 2024-03-07 21:19:07 --> Router Class Initialized
INFO - 2024-03-07 21:19:07 --> Output Class Initialized
INFO - 2024-03-07 21:19:07 --> Security Class Initialized
DEBUG - 2024-03-07 21:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:19:07 --> Input Class Initialized
INFO - 2024-03-07 21:19:07 --> Language Class Initialized
INFO - 2024-03-07 21:19:07 --> Loader Class Initialized
INFO - 2024-03-07 21:19:07 --> Helper loaded: url_helper
INFO - 2024-03-07 21:19:07 --> Helper loaded: file_helper
INFO - 2024-03-07 21:19:07 --> Helper loaded: form_helper
INFO - 2024-03-07 21:19:07 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:19:07 --> Controller Class Initialized
INFO - 2024-03-07 21:19:07 --> Form Validation Class Initialized
INFO - 2024-03-07 21:19:07 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:19:07 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:19:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:19:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:19:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:19:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:19:07 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:19:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:19:07 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:19:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:19:09 --> Config Class Initialized
INFO - 2024-03-07 21:19:09 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:19:09 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:19:09 --> Utf8 Class Initialized
INFO - 2024-03-07 21:19:09 --> URI Class Initialized
INFO - 2024-03-07 21:19:09 --> Router Class Initialized
INFO - 2024-03-07 21:19:09 --> Output Class Initialized
INFO - 2024-03-07 21:19:09 --> Security Class Initialized
DEBUG - 2024-03-07 21:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:19:09 --> Input Class Initialized
INFO - 2024-03-07 21:19:09 --> Language Class Initialized
INFO - 2024-03-07 21:19:09 --> Loader Class Initialized
INFO - 2024-03-07 21:19:09 --> Helper loaded: url_helper
INFO - 2024-03-07 21:19:09 --> Helper loaded: file_helper
INFO - 2024-03-07 21:19:09 --> Helper loaded: form_helper
INFO - 2024-03-07 21:19:09 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:19:09 --> Controller Class Initialized
INFO - 2024-03-07 21:19:09 --> Form Validation Class Initialized
INFO - 2024-03-07 21:19:09 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:19:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:19:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 21:19:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:19:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:19:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:19:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-07 21:19:09 --> Final output sent to browser
DEBUG - 2024-03-07 21:19:09 --> Total execution time: 0.0306
ERROR - 2024-03-07 21:19:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:19:09 --> Config Class Initialized
INFO - 2024-03-07 21:19:09 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:19:09 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:19:09 --> Utf8 Class Initialized
INFO - 2024-03-07 21:19:09 --> URI Class Initialized
INFO - 2024-03-07 21:19:09 --> Router Class Initialized
INFO - 2024-03-07 21:19:09 --> Output Class Initialized
INFO - 2024-03-07 21:19:09 --> Security Class Initialized
DEBUG - 2024-03-07 21:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:19:09 --> Input Class Initialized
INFO - 2024-03-07 21:19:09 --> Language Class Initialized
INFO - 2024-03-07 21:19:09 --> Loader Class Initialized
INFO - 2024-03-07 21:19:09 --> Helper loaded: url_helper
INFO - 2024-03-07 21:19:09 --> Helper loaded: file_helper
INFO - 2024-03-07 21:19:09 --> Helper loaded: form_helper
INFO - 2024-03-07 21:19:09 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:19:09 --> Controller Class Initialized
INFO - 2024-03-07 21:19:09 --> Form Validation Class Initialized
INFO - 2024-03-07 21:19:09 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:19:09 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:19:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:19:40 --> Config Class Initialized
INFO - 2024-03-07 21:19:40 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:19:40 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:19:40 --> Utf8 Class Initialized
INFO - 2024-03-07 21:19:40 --> URI Class Initialized
INFO - 2024-03-07 21:19:40 --> Router Class Initialized
INFO - 2024-03-07 21:19:40 --> Output Class Initialized
INFO - 2024-03-07 21:19:40 --> Security Class Initialized
DEBUG - 2024-03-07 21:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:19:40 --> Input Class Initialized
INFO - 2024-03-07 21:19:40 --> Language Class Initialized
INFO - 2024-03-07 21:19:40 --> Loader Class Initialized
INFO - 2024-03-07 21:19:40 --> Helper loaded: url_helper
INFO - 2024-03-07 21:19:40 --> Helper loaded: file_helper
INFO - 2024-03-07 21:19:40 --> Helper loaded: form_helper
INFO - 2024-03-07 21:19:40 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:19:40 --> Controller Class Initialized
INFO - 2024-03-07 21:19:40 --> Form Validation Class Initialized
INFO - 2024-03-07 21:19:40 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:19:40 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:19:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:19:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:19:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:19:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:19:40 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:19:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:19:40 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:19:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:19:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-07 21:19:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-07 21:19:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:19:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:19:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:19:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-07 21:19:40 --> Final output sent to browser
DEBUG - 2024-03-07 21:19:40 --> Total execution time: 0.0331
ERROR - 2024-03-07 21:19:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:19:40 --> Config Class Initialized
INFO - 2024-03-07 21:19:40 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:19:40 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:19:40 --> Utf8 Class Initialized
INFO - 2024-03-07 21:19:40 --> URI Class Initialized
INFO - 2024-03-07 21:19:40 --> Router Class Initialized
INFO - 2024-03-07 21:19:40 --> Output Class Initialized
INFO - 2024-03-07 21:19:40 --> Security Class Initialized
DEBUG - 2024-03-07 21:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:19:40 --> Input Class Initialized
INFO - 2024-03-07 21:19:40 --> Language Class Initialized
INFO - 2024-03-07 21:19:40 --> Loader Class Initialized
INFO - 2024-03-07 21:19:40 --> Helper loaded: url_helper
INFO - 2024-03-07 21:19:40 --> Helper loaded: file_helper
INFO - 2024-03-07 21:19:40 --> Helper loaded: form_helper
INFO - 2024-03-07 21:19:40 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:19:40 --> Controller Class Initialized
INFO - 2024-03-07 21:19:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-03-07 21:19:40 --> Final output sent to browser
DEBUG - 2024-03-07 21:19:40 --> Total execution time: 0.0265
ERROR - 2024-03-07 21:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:19:42 --> Config Class Initialized
INFO - 2024-03-07 21:19:42 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:19:42 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:19:42 --> Utf8 Class Initialized
INFO - 2024-03-07 21:19:42 --> URI Class Initialized
DEBUG - 2024-03-07 21:19:42 --> No URI present. Default controller set.
INFO - 2024-03-07 21:19:42 --> Router Class Initialized
INFO - 2024-03-07 21:19:42 --> Output Class Initialized
INFO - 2024-03-07 21:19:42 --> Security Class Initialized
DEBUG - 2024-03-07 21:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:19:42 --> Input Class Initialized
INFO - 2024-03-07 21:19:42 --> Language Class Initialized
INFO - 2024-03-07 21:19:42 --> Loader Class Initialized
INFO - 2024-03-07 21:19:42 --> Helper loaded: url_helper
INFO - 2024-03-07 21:19:42 --> Helper loaded: file_helper
INFO - 2024-03-07 21:19:42 --> Helper loaded: form_helper
INFO - 2024-03-07 21:19:42 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:19:42 --> Controller Class Initialized
INFO - 2024-03-07 21:19:42 --> Model "LoginModel" initialized
INFO - 2024-03-07 21:19:42 --> Form Validation Class Initialized
INFO - 2024-03-07 21:19:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-07 21:19:42 --> Final output sent to browser
DEBUG - 2024-03-07 21:19:42 --> Total execution time: 0.0298
ERROR - 2024-03-07 21:19:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:19:50 --> Config Class Initialized
INFO - 2024-03-07 21:19:50 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:19:50 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:19:50 --> Utf8 Class Initialized
INFO - 2024-03-07 21:19:50 --> URI Class Initialized
INFO - 2024-03-07 21:19:50 --> Router Class Initialized
INFO - 2024-03-07 21:19:50 --> Output Class Initialized
INFO - 2024-03-07 21:19:50 --> Security Class Initialized
DEBUG - 2024-03-07 21:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:19:50 --> Input Class Initialized
INFO - 2024-03-07 21:19:50 --> Language Class Initialized
INFO - 2024-03-07 21:19:50 --> Loader Class Initialized
INFO - 2024-03-07 21:19:50 --> Helper loaded: url_helper
INFO - 2024-03-07 21:19:50 --> Helper loaded: file_helper
INFO - 2024-03-07 21:19:50 --> Helper loaded: form_helper
INFO - 2024-03-07 21:19:50 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:19:50 --> Controller Class Initialized
INFO - 2024-03-07 21:19:50 --> Model "LoginModel" initialized
INFO - 2024-03-07 21:19:50 --> Form Validation Class Initialized
INFO - 2024-03-07 21:19:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-07 21:19:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:19:50 --> Config Class Initialized
INFO - 2024-03-07 21:19:50 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:19:50 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:19:50 --> Utf8 Class Initialized
INFO - 2024-03-07 21:19:50 --> URI Class Initialized
INFO - 2024-03-07 21:19:50 --> Router Class Initialized
INFO - 2024-03-07 21:19:50 --> Output Class Initialized
INFO - 2024-03-07 21:19:50 --> Security Class Initialized
DEBUG - 2024-03-07 21:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:19:50 --> Input Class Initialized
INFO - 2024-03-07 21:19:50 --> Language Class Initialized
INFO - 2024-03-07 21:19:50 --> Loader Class Initialized
INFO - 2024-03-07 21:19:50 --> Helper loaded: url_helper
INFO - 2024-03-07 21:19:50 --> Helper loaded: file_helper
INFO - 2024-03-07 21:19:50 --> Helper loaded: form_helper
INFO - 2024-03-07 21:19:50 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:19:50 --> Controller Class Initialized
INFO - 2024-03-07 21:19:50 --> Form Validation Class Initialized
INFO - 2024-03-07 21:19:50 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:19:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:19:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-07 21:19:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-07 21:19:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:19:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:19:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:19:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-07 21:19:50 --> Final output sent to browser
DEBUG - 2024-03-07 21:19:50 --> Total execution time: 0.0333
ERROR - 2024-03-07 21:19:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:19:50 --> Config Class Initialized
INFO - 2024-03-07 21:19:50 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:19:50 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:19:50 --> Utf8 Class Initialized
INFO - 2024-03-07 21:19:50 --> URI Class Initialized
INFO - 2024-03-07 21:19:50 --> Router Class Initialized
INFO - 2024-03-07 21:19:50 --> Output Class Initialized
INFO - 2024-03-07 21:19:50 --> Security Class Initialized
DEBUG - 2024-03-07 21:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:19:50 --> Input Class Initialized
INFO - 2024-03-07 21:19:50 --> Language Class Initialized
INFO - 2024-03-07 21:19:50 --> Loader Class Initialized
INFO - 2024-03-07 21:19:50 --> Helper loaded: url_helper
INFO - 2024-03-07 21:19:50 --> Helper loaded: file_helper
INFO - 2024-03-07 21:19:50 --> Helper loaded: form_helper
INFO - 2024-03-07 21:19:50 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:19:50 --> Controller Class Initialized
INFO - 2024-03-07 21:19:50 --> Form Validation Class Initialized
INFO - 2024-03-07 21:19:50 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:19:50 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:20:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:20:02 --> Config Class Initialized
INFO - 2024-03-07 21:20:02 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:20:02 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:20:02 --> Utf8 Class Initialized
INFO - 2024-03-07 21:20:02 --> URI Class Initialized
INFO - 2024-03-07 21:20:02 --> Router Class Initialized
INFO - 2024-03-07 21:20:02 --> Output Class Initialized
INFO - 2024-03-07 21:20:02 --> Security Class Initialized
DEBUG - 2024-03-07 21:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:20:02 --> Input Class Initialized
INFO - 2024-03-07 21:20:02 --> Language Class Initialized
INFO - 2024-03-07 21:20:02 --> Loader Class Initialized
INFO - 2024-03-07 21:20:02 --> Helper loaded: url_helper
INFO - 2024-03-07 21:20:02 --> Helper loaded: file_helper
INFO - 2024-03-07 21:20:02 --> Helper loaded: form_helper
INFO - 2024-03-07 21:20:02 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:20:02 --> Controller Class Initialized
INFO - 2024-03-07 21:20:02 --> Form Validation Class Initialized
INFO - 2024-03-07 21:20:02 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:20:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:20:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-07 21:20:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:20:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:20:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:20:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-07 21:20:02 --> Final output sent to browser
DEBUG - 2024-03-07 21:20:02 --> Total execution time: 0.0409
ERROR - 2024-03-07 21:20:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:20:02 --> Config Class Initialized
INFO - 2024-03-07 21:20:02 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:20:02 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:20:02 --> Utf8 Class Initialized
INFO - 2024-03-07 21:20:02 --> URI Class Initialized
INFO - 2024-03-07 21:20:02 --> Router Class Initialized
INFO - 2024-03-07 21:20:02 --> Output Class Initialized
INFO - 2024-03-07 21:20:02 --> Security Class Initialized
DEBUG - 2024-03-07 21:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:20:02 --> Input Class Initialized
INFO - 2024-03-07 21:20:02 --> Language Class Initialized
INFO - 2024-03-07 21:20:02 --> Loader Class Initialized
INFO - 2024-03-07 21:20:02 --> Helper loaded: url_helper
INFO - 2024-03-07 21:20:02 --> Helper loaded: file_helper
INFO - 2024-03-07 21:20:02 --> Helper loaded: form_helper
INFO - 2024-03-07 21:20:02 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:20:02 --> Controller Class Initialized
INFO - 2024-03-07 21:20:02 --> Form Validation Class Initialized
INFO - 2024-03-07 21:20:02 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:20:02 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:20:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:20:09 --> Config Class Initialized
INFO - 2024-03-07 21:20:09 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:20:09 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:20:09 --> Utf8 Class Initialized
INFO - 2024-03-07 21:20:09 --> URI Class Initialized
INFO - 2024-03-07 21:20:09 --> Router Class Initialized
INFO - 2024-03-07 21:20:09 --> Output Class Initialized
INFO - 2024-03-07 21:20:09 --> Security Class Initialized
DEBUG - 2024-03-07 21:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:20:09 --> Input Class Initialized
INFO - 2024-03-07 21:20:09 --> Language Class Initialized
INFO - 2024-03-07 21:20:09 --> Loader Class Initialized
INFO - 2024-03-07 21:20:09 --> Helper loaded: url_helper
INFO - 2024-03-07 21:20:09 --> Helper loaded: file_helper
INFO - 2024-03-07 21:20:09 --> Helper loaded: form_helper
INFO - 2024-03-07 21:20:09 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:20:09 --> Controller Class Initialized
INFO - 2024-03-07 21:20:09 --> Form Validation Class Initialized
INFO - 2024-03-07 21:20:09 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:20:09 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:20:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:20:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:20:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:20:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:20:09 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:20:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:20:09 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:22:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:22:16 --> Config Class Initialized
INFO - 2024-03-07 21:22:16 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:22:16 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:22:16 --> Utf8 Class Initialized
INFO - 2024-03-07 21:22:16 --> URI Class Initialized
INFO - 2024-03-07 21:22:16 --> Router Class Initialized
INFO - 2024-03-07 21:22:16 --> Output Class Initialized
INFO - 2024-03-07 21:22:16 --> Security Class Initialized
DEBUG - 2024-03-07 21:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:22:16 --> Input Class Initialized
INFO - 2024-03-07 21:22:16 --> Language Class Initialized
INFO - 2024-03-07 21:22:16 --> Loader Class Initialized
INFO - 2024-03-07 21:22:16 --> Helper loaded: url_helper
INFO - 2024-03-07 21:22:16 --> Helper loaded: file_helper
INFO - 2024-03-07 21:22:16 --> Helper loaded: form_helper
INFO - 2024-03-07 21:22:16 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:22:16 --> Controller Class Initialized
INFO - 2024-03-07 21:22:16 --> Form Validation Class Initialized
INFO - 2024-03-07 21:22:16 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:22:16 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:22:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:22:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:22:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:22:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:22:16 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:22:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:22:16 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:22:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:22:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-07 21:22:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-07 21:22:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:22:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:22:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:22:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-07 21:22:16 --> Final output sent to browser
DEBUG - 2024-03-07 21:22:16 --> Total execution time: 0.0395
ERROR - 2024-03-07 21:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:22:17 --> Config Class Initialized
INFO - 2024-03-07 21:22:17 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:22:17 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:22:17 --> Utf8 Class Initialized
INFO - 2024-03-07 21:22:17 --> URI Class Initialized
INFO - 2024-03-07 21:22:17 --> Router Class Initialized
INFO - 2024-03-07 21:22:17 --> Output Class Initialized
INFO - 2024-03-07 21:22:17 --> Security Class Initialized
DEBUG - 2024-03-07 21:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:22:17 --> Input Class Initialized
INFO - 2024-03-07 21:22:17 --> Language Class Initialized
INFO - 2024-03-07 21:22:17 --> Loader Class Initialized
INFO - 2024-03-07 21:22:17 --> Helper loaded: url_helper
INFO - 2024-03-07 21:22:17 --> Helper loaded: file_helper
INFO - 2024-03-07 21:22:17 --> Helper loaded: form_helper
INFO - 2024-03-07 21:22:17 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:22:17 --> Controller Class Initialized
INFO - 2024-03-07 21:22:17 --> Form Validation Class Initialized
INFO - 2024-03-07 21:22:17 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:22:17 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:22:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:22:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:22:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:22:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:22:17 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:22:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:22:17 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:22:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:22:23 --> Config Class Initialized
INFO - 2024-03-07 21:22:23 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:22:23 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:22:23 --> Utf8 Class Initialized
INFO - 2024-03-07 21:22:23 --> URI Class Initialized
INFO - 2024-03-07 21:22:23 --> Router Class Initialized
INFO - 2024-03-07 21:22:23 --> Output Class Initialized
INFO - 2024-03-07 21:22:23 --> Security Class Initialized
DEBUG - 2024-03-07 21:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:22:23 --> Input Class Initialized
INFO - 2024-03-07 21:22:23 --> Language Class Initialized
INFO - 2024-03-07 21:22:23 --> Loader Class Initialized
INFO - 2024-03-07 21:22:23 --> Helper loaded: url_helper
INFO - 2024-03-07 21:22:23 --> Helper loaded: file_helper
INFO - 2024-03-07 21:22:23 --> Helper loaded: form_helper
INFO - 2024-03-07 21:22:23 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:22:23 --> Controller Class Initialized
INFO - 2024-03-07 21:22:23 --> Form Validation Class Initialized
INFO - 2024-03-07 21:22:23 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:22:23 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:22:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:22:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:22:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:22:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:22:23 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:22:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:22:23 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:22:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:22:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-07 21:22:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-07 21:22:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:22:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:22:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:22:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-07 21:22:23 --> Final output sent to browser
DEBUG - 2024-03-07 21:22:23 --> Total execution time: 0.0671
ERROR - 2024-03-07 21:22:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:22:50 --> Config Class Initialized
INFO - 2024-03-07 21:22:50 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:22:50 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:22:50 --> Utf8 Class Initialized
INFO - 2024-03-07 21:22:50 --> URI Class Initialized
INFO - 2024-03-07 21:22:50 --> Router Class Initialized
INFO - 2024-03-07 21:22:50 --> Output Class Initialized
INFO - 2024-03-07 21:22:50 --> Security Class Initialized
DEBUG - 2024-03-07 21:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:22:50 --> Input Class Initialized
INFO - 2024-03-07 21:22:50 --> Language Class Initialized
INFO - 2024-03-07 21:22:50 --> Loader Class Initialized
INFO - 2024-03-07 21:22:50 --> Helper loaded: url_helper
INFO - 2024-03-07 21:22:50 --> Helper loaded: file_helper
INFO - 2024-03-07 21:22:50 --> Helper loaded: form_helper
INFO - 2024-03-07 21:22:50 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:22:50 --> Controller Class Initialized
INFO - 2024-03-07 21:22:50 --> Form Validation Class Initialized
INFO - 2024-03-07 21:22:50 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:22:50 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:22:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:22:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:22:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:22:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:22:50 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:22:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:22:50 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:22:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:22:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-07 21:22:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-07 21:22:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:22:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:22:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:22:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-07 21:22:50 --> Final output sent to browser
DEBUG - 2024-03-07 21:22:50 --> Total execution time: 0.0428
ERROR - 2024-03-07 21:22:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:22:51 --> Config Class Initialized
INFO - 2024-03-07 21:22:51 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:22:51 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:22:51 --> Utf8 Class Initialized
INFO - 2024-03-07 21:22:51 --> URI Class Initialized
INFO - 2024-03-07 21:22:51 --> Router Class Initialized
INFO - 2024-03-07 21:22:51 --> Output Class Initialized
INFO - 2024-03-07 21:22:51 --> Security Class Initialized
DEBUG - 2024-03-07 21:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:22:51 --> Input Class Initialized
INFO - 2024-03-07 21:22:51 --> Language Class Initialized
INFO - 2024-03-07 21:22:51 --> Loader Class Initialized
INFO - 2024-03-07 21:22:51 --> Helper loaded: url_helper
INFO - 2024-03-07 21:22:51 --> Helper loaded: file_helper
INFO - 2024-03-07 21:22:51 --> Helper loaded: form_helper
INFO - 2024-03-07 21:22:52 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:22:52 --> Controller Class Initialized
INFO - 2024-03-07 21:22:52 --> Form Validation Class Initialized
INFO - 2024-03-07 21:22:52 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:22:52 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:22:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:22:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:22:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:22:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:22:52 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:22:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:22:52 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:22:55 --> Config Class Initialized
INFO - 2024-03-07 21:22:55 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:22:55 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:22:55 --> Utf8 Class Initialized
INFO - 2024-03-07 21:22:55 --> URI Class Initialized
INFO - 2024-03-07 21:22:55 --> Router Class Initialized
INFO - 2024-03-07 21:22:55 --> Output Class Initialized
INFO - 2024-03-07 21:22:55 --> Security Class Initialized
DEBUG - 2024-03-07 21:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:22:55 --> Input Class Initialized
INFO - 2024-03-07 21:22:55 --> Language Class Initialized
INFO - 2024-03-07 21:22:55 --> Loader Class Initialized
INFO - 2024-03-07 21:22:55 --> Helper loaded: url_helper
INFO - 2024-03-07 21:22:55 --> Helper loaded: file_helper
INFO - 2024-03-07 21:22:55 --> Helper loaded: form_helper
INFO - 2024-03-07 21:22:55 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:22:55 --> Controller Class Initialized
INFO - 2024-03-07 21:22:55 --> Form Validation Class Initialized
INFO - 2024-03-07 21:22:55 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:22:55 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:22:55 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:22:55 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:22:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:22:55 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:22:55 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:22:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:22:55 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:22:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:22:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-07 21:22:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-07 21:22:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:22:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:22:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:22:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-07 21:22:55 --> Final output sent to browser
DEBUG - 2024-03-07 21:22:55 --> Total execution time: 0.0456
ERROR - 2024-03-07 21:22:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:22:57 --> Config Class Initialized
INFO - 2024-03-07 21:22:57 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:22:57 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:22:57 --> Utf8 Class Initialized
INFO - 2024-03-07 21:22:57 --> URI Class Initialized
INFO - 2024-03-07 21:22:57 --> Router Class Initialized
INFO - 2024-03-07 21:22:57 --> Output Class Initialized
INFO - 2024-03-07 21:22:57 --> Security Class Initialized
DEBUG - 2024-03-07 21:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:22:57 --> Input Class Initialized
INFO - 2024-03-07 21:22:57 --> Language Class Initialized
INFO - 2024-03-07 21:22:57 --> Loader Class Initialized
INFO - 2024-03-07 21:22:57 --> Helper loaded: url_helper
INFO - 2024-03-07 21:22:57 --> Helper loaded: file_helper
INFO - 2024-03-07 21:22:57 --> Helper loaded: form_helper
INFO - 2024-03-07 21:22:57 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:22:57 --> Controller Class Initialized
INFO - 2024-03-07 21:22:57 --> Form Validation Class Initialized
INFO - 2024-03-07 21:22:57 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "ReportModel" initialized
INFO - 2024-03-07 21:22:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-07 21:22:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-07 21:22:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-07 21:22:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-07 21:22:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-07 21:22:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-07 21:22:57 --> Final output sent to browser
DEBUG - 2024-03-07 21:22:57 --> Total execution time: 0.0480
ERROR - 2024-03-07 21:22:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:22:57 --> Config Class Initialized
INFO - 2024-03-07 21:22:57 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:22:57 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:22:57 --> Utf8 Class Initialized
INFO - 2024-03-07 21:22:57 --> URI Class Initialized
INFO - 2024-03-07 21:22:57 --> Router Class Initialized
INFO - 2024-03-07 21:22:57 --> Output Class Initialized
INFO - 2024-03-07 21:22:57 --> Security Class Initialized
DEBUG - 2024-03-07 21:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:22:57 --> Input Class Initialized
INFO - 2024-03-07 21:22:57 --> Language Class Initialized
INFO - 2024-03-07 21:22:57 --> Loader Class Initialized
INFO - 2024-03-07 21:22:57 --> Helper loaded: url_helper
INFO - 2024-03-07 21:22:57 --> Helper loaded: file_helper
INFO - 2024-03-07 21:22:57 --> Helper loaded: form_helper
INFO - 2024-03-07 21:22:57 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:22:57 --> Controller Class Initialized
INFO - 2024-03-07 21:22:57 --> Form Validation Class Initialized
INFO - 2024-03-07 21:22:57 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:22:57 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:23:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:23:03 --> Config Class Initialized
INFO - 2024-03-07 21:23:03 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:23:03 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:23:03 --> Utf8 Class Initialized
INFO - 2024-03-07 21:23:03 --> URI Class Initialized
INFO - 2024-03-07 21:23:03 --> Router Class Initialized
INFO - 2024-03-07 21:23:03 --> Output Class Initialized
INFO - 2024-03-07 21:23:03 --> Security Class Initialized
DEBUG - 2024-03-07 21:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:23:03 --> Input Class Initialized
INFO - 2024-03-07 21:23:03 --> Language Class Initialized
INFO - 2024-03-07 21:23:03 --> Loader Class Initialized
INFO - 2024-03-07 21:23:03 --> Helper loaded: url_helper
INFO - 2024-03-07 21:23:03 --> Helper loaded: file_helper
INFO - 2024-03-07 21:23:03 --> Helper loaded: form_helper
INFO - 2024-03-07 21:23:03 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:23:03 --> Controller Class Initialized
INFO - 2024-03-07 21:23:03 --> Form Validation Class Initialized
INFO - 2024-03-07 21:23:03 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:23:03 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:23:03 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:23:03 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:23:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:23:03 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:23:03 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:23:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:23:03 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:23:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:23:05 --> Config Class Initialized
INFO - 2024-03-07 21:23:05 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:23:05 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:23:05 --> Utf8 Class Initialized
INFO - 2024-03-07 21:23:05 --> URI Class Initialized
INFO - 2024-03-07 21:23:05 --> Router Class Initialized
INFO - 2024-03-07 21:23:05 --> Output Class Initialized
INFO - 2024-03-07 21:23:05 --> Security Class Initialized
DEBUG - 2024-03-07 21:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:23:05 --> Input Class Initialized
INFO - 2024-03-07 21:23:05 --> Language Class Initialized
INFO - 2024-03-07 21:23:05 --> Loader Class Initialized
INFO - 2024-03-07 21:23:05 --> Helper loaded: url_helper
INFO - 2024-03-07 21:23:05 --> Helper loaded: file_helper
INFO - 2024-03-07 21:23:05 --> Helper loaded: form_helper
INFO - 2024-03-07 21:23:05 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:23:05 --> Controller Class Initialized
INFO - 2024-03-07 21:23:05 --> Form Validation Class Initialized
INFO - 2024-03-07 21:23:05 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:23:05 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:23:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:23:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:23:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:23:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:23:05 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:23:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:23:05 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:23:07 --> Config Class Initialized
INFO - 2024-03-07 21:23:07 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:23:07 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:23:07 --> Utf8 Class Initialized
INFO - 2024-03-07 21:23:07 --> URI Class Initialized
INFO - 2024-03-07 21:23:07 --> Router Class Initialized
INFO - 2024-03-07 21:23:07 --> Output Class Initialized
INFO - 2024-03-07 21:23:07 --> Security Class Initialized
DEBUG - 2024-03-07 21:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:23:07 --> Input Class Initialized
INFO - 2024-03-07 21:23:07 --> Language Class Initialized
INFO - 2024-03-07 21:23:07 --> Loader Class Initialized
INFO - 2024-03-07 21:23:07 --> Helper loaded: url_helper
INFO - 2024-03-07 21:23:07 --> Helper loaded: file_helper
INFO - 2024-03-07 21:23:07 --> Helper loaded: form_helper
INFO - 2024-03-07 21:23:07 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:23:07 --> Controller Class Initialized
INFO - 2024-03-07 21:23:07 --> Form Validation Class Initialized
INFO - 2024-03-07 21:23:07 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:23:07 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:23:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:23:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:23:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:23:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:23:07 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:23:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:23:07 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:24:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:24:23 --> Config Class Initialized
INFO - 2024-03-07 21:24:23 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:24:23 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:24:23 --> Utf8 Class Initialized
INFO - 2024-03-07 21:24:23 --> URI Class Initialized
INFO - 2024-03-07 21:24:23 --> Router Class Initialized
INFO - 2024-03-07 21:24:23 --> Output Class Initialized
INFO - 2024-03-07 21:24:23 --> Security Class Initialized
DEBUG - 2024-03-07 21:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:24:23 --> Input Class Initialized
INFO - 2024-03-07 21:24:23 --> Language Class Initialized
INFO - 2024-03-07 21:24:23 --> Loader Class Initialized
INFO - 2024-03-07 21:24:23 --> Helper loaded: url_helper
INFO - 2024-03-07 21:24:23 --> Helper loaded: file_helper
INFO - 2024-03-07 21:24:23 --> Helper loaded: form_helper
INFO - 2024-03-07 21:24:23 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:24:23 --> Controller Class Initialized
INFO - 2024-03-07 21:24:23 --> Form Validation Class Initialized
INFO - 2024-03-07 21:24:23 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:24:23 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:24:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:24:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:24:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:24:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:24:23 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:24:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:24:23 --> Model "ReportModel" initialized
ERROR - 2024-03-07 21:25:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-07 21:25:19 --> Config Class Initialized
INFO - 2024-03-07 21:25:19 --> Hooks Class Initialized
DEBUG - 2024-03-07 21:25:19 --> UTF-8 Support Enabled
INFO - 2024-03-07 21:25:19 --> Utf8 Class Initialized
INFO - 2024-03-07 21:25:19 --> URI Class Initialized
INFO - 2024-03-07 21:25:19 --> Router Class Initialized
INFO - 2024-03-07 21:25:19 --> Output Class Initialized
INFO - 2024-03-07 21:25:19 --> Security Class Initialized
DEBUG - 2024-03-07 21:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 21:25:19 --> Input Class Initialized
INFO - 2024-03-07 21:25:19 --> Language Class Initialized
INFO - 2024-03-07 21:25:19 --> Loader Class Initialized
INFO - 2024-03-07 21:25:19 --> Helper loaded: url_helper
INFO - 2024-03-07 21:25:19 --> Helper loaded: file_helper
INFO - 2024-03-07 21:25:19 --> Helper loaded: form_helper
INFO - 2024-03-07 21:25:19 --> Database Driver Class Initialized
DEBUG - 2024-03-07 21:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-07 21:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 21:25:19 --> Controller Class Initialized
INFO - 2024-03-07 21:25:19 --> Form Validation Class Initialized
INFO - 2024-03-07 21:25:19 --> Model "MasterModel" initialized
INFO - 2024-03-07 21:25:19 --> Model "DashboardModel" initialized
INFO - 2024-03-07 21:25:19 --> Model "UserMasterModel" initialized
INFO - 2024-03-07 21:25:19 --> Model "ItemGroupModel" initialized
INFO - 2024-03-07 21:25:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-07 21:25:19 --> Model "ItemMasterModel" initialized
INFO - 2024-03-07 21:25:19 --> Model "OrderModel" initialized
INFO - 2024-03-07 21:25:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-07 21:25:19 --> Model "ReportModel" initialized
