<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-12 11:14:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:14:47 --> Config Class Initialized
INFO - 2024-02-12 11:14:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:14:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:14:47 --> Utf8 Class Initialized
INFO - 2024-02-12 11:14:47 --> URI Class Initialized
INFO - 2024-02-12 11:14:47 --> Router Class Initialized
INFO - 2024-02-12 11:14:47 --> Output Class Initialized
INFO - 2024-02-12 11:14:47 --> Security Class Initialized
DEBUG - 2024-02-12 11:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:14:47 --> Input Class Initialized
INFO - 2024-02-12 11:14:47 --> Language Class Initialized
INFO - 2024-02-12 11:14:47 --> Loader Class Initialized
INFO - 2024-02-12 11:14:47 --> Helper loaded: url_helper
INFO - 2024-02-12 11:14:47 --> Helper loaded: file_helper
INFO - 2024-02-12 11:14:47 --> Helper loaded: form_helper
INFO - 2024-02-12 11:14:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:14:47 --> Controller Class Initialized
INFO - 2024-02-12 11:14:47 --> Form Validation Class Initialized
INFO - 2024-02-12 11:14:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:14:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:14:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:14:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:14:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:14:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:14:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:14:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:14:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:14:47 --> Final output sent to browser
DEBUG - 2024-02-12 11:14:47 --> Total execution time: 0.0386
ERROR - 2024-02-12 11:14:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:14:47 --> Config Class Initialized
INFO - 2024-02-12 11:14:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:14:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:14:47 --> Utf8 Class Initialized
INFO - 2024-02-12 11:14:47 --> URI Class Initialized
INFO - 2024-02-12 11:14:47 --> Router Class Initialized
INFO - 2024-02-12 11:14:47 --> Output Class Initialized
INFO - 2024-02-12 11:14:47 --> Security Class Initialized
DEBUG - 2024-02-12 11:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:14:47 --> Input Class Initialized
INFO - 2024-02-12 11:14:47 --> Language Class Initialized
INFO - 2024-02-12 11:14:47 --> Loader Class Initialized
INFO - 2024-02-12 11:14:47 --> Helper loaded: url_helper
INFO - 2024-02-12 11:14:47 --> Helper loaded: file_helper
INFO - 2024-02-12 11:14:47 --> Helper loaded: form_helper
INFO - 2024-02-12 11:14:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:14:47 --> Controller Class Initialized
INFO - 2024-02-12 11:14:47 --> Form Validation Class Initialized
INFO - 2024-02-12 11:14:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:14:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:14:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:14:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:14:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:14:51 --> Config Class Initialized
INFO - 2024-02-12 11:14:51 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:14:51 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:14:51 --> Utf8 Class Initialized
INFO - 2024-02-12 11:14:51 --> URI Class Initialized
INFO - 2024-02-12 11:14:51 --> Router Class Initialized
INFO - 2024-02-12 11:14:51 --> Output Class Initialized
INFO - 2024-02-12 11:14:51 --> Security Class Initialized
DEBUG - 2024-02-12 11:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:14:51 --> Input Class Initialized
INFO - 2024-02-12 11:14:51 --> Language Class Initialized
INFO - 2024-02-12 11:14:51 --> Loader Class Initialized
INFO - 2024-02-12 11:14:51 --> Helper loaded: url_helper
INFO - 2024-02-12 11:14:51 --> Helper loaded: file_helper
INFO - 2024-02-12 11:14:51 --> Helper loaded: form_helper
INFO - 2024-02-12 11:14:51 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:14:51 --> Controller Class Initialized
INFO - 2024-02-12 11:14:51 --> Form Validation Class Initialized
INFO - 2024-02-12 11:14:51 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:14:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:14:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:14:51 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:14:51 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-12 11:14:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:14:51 --> Final output sent to browser
DEBUG - 2024-02-12 11:14:51 --> Total execution time: 0.0442
ERROR - 2024-02-12 11:18:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:18:38 --> Config Class Initialized
INFO - 2024-02-12 11:18:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:18:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:18:38 --> Utf8 Class Initialized
INFO - 2024-02-12 11:18:38 --> URI Class Initialized
INFO - 2024-02-12 11:18:38 --> Router Class Initialized
INFO - 2024-02-12 11:18:38 --> Output Class Initialized
INFO - 2024-02-12 11:18:38 --> Security Class Initialized
DEBUG - 2024-02-12 11:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:18:38 --> Input Class Initialized
INFO - 2024-02-12 11:18:38 --> Language Class Initialized
INFO - 2024-02-12 11:18:38 --> Loader Class Initialized
INFO - 2024-02-12 11:18:38 --> Helper loaded: url_helper
INFO - 2024-02-12 11:18:38 --> Helper loaded: file_helper
INFO - 2024-02-12 11:18:38 --> Helper loaded: form_helper
INFO - 2024-02-12 11:18:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:18:38 --> Controller Class Initialized
INFO - 2024-02-12 11:18:38 --> Form Validation Class Initialized
INFO - 2024-02-12 11:18:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:18:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:18:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:18:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:18:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:18:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:18:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:18:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:18:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:18:38 --> Final output sent to browser
DEBUG - 2024-02-12 11:18:38 --> Total execution time: 0.0252
ERROR - 2024-02-12 11:18:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:18:38 --> Config Class Initialized
INFO - 2024-02-12 11:18:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:18:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:18:38 --> Utf8 Class Initialized
INFO - 2024-02-12 11:18:38 --> URI Class Initialized
INFO - 2024-02-12 11:18:38 --> Router Class Initialized
INFO - 2024-02-12 11:18:38 --> Output Class Initialized
INFO - 2024-02-12 11:18:38 --> Security Class Initialized
DEBUG - 2024-02-12 11:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:18:38 --> Input Class Initialized
INFO - 2024-02-12 11:18:38 --> Language Class Initialized
INFO - 2024-02-12 11:18:38 --> Loader Class Initialized
INFO - 2024-02-12 11:18:38 --> Helper loaded: url_helper
INFO - 2024-02-12 11:18:38 --> Helper loaded: file_helper
INFO - 2024-02-12 11:18:38 --> Helper loaded: form_helper
INFO - 2024-02-12 11:18:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:18:38 --> Controller Class Initialized
INFO - 2024-02-12 11:18:38 --> Form Validation Class Initialized
INFO - 2024-02-12 11:18:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:18:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:18:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:18:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:18:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:18:41 --> Config Class Initialized
INFO - 2024-02-12 11:18:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:18:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:18:41 --> Utf8 Class Initialized
INFO - 2024-02-12 11:18:41 --> URI Class Initialized
INFO - 2024-02-12 11:18:41 --> Router Class Initialized
INFO - 2024-02-12 11:18:41 --> Output Class Initialized
INFO - 2024-02-12 11:18:41 --> Security Class Initialized
DEBUG - 2024-02-12 11:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:18:41 --> Input Class Initialized
INFO - 2024-02-12 11:18:41 --> Language Class Initialized
INFO - 2024-02-12 11:18:41 --> Loader Class Initialized
INFO - 2024-02-12 11:18:41 --> Helper loaded: url_helper
INFO - 2024-02-12 11:18:41 --> Helper loaded: file_helper
INFO - 2024-02-12 11:18:41 --> Helper loaded: form_helper
INFO - 2024-02-12 11:18:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:18:41 --> Controller Class Initialized
INFO - 2024-02-12 11:18:41 --> Form Validation Class Initialized
INFO - 2024-02-12 11:18:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:18:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:18:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:18:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:18:41 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-12 11:18:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:18:41 --> Final output sent to browser
DEBUG - 2024-02-12 11:18:41 --> Total execution time: 0.0313
ERROR - 2024-02-12 11:26:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:26:21 --> Config Class Initialized
INFO - 2024-02-12 11:26:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:26:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:26:21 --> Utf8 Class Initialized
INFO - 2024-02-12 11:26:21 --> URI Class Initialized
INFO - 2024-02-12 11:26:21 --> Router Class Initialized
INFO - 2024-02-12 11:26:21 --> Output Class Initialized
INFO - 2024-02-12 11:26:21 --> Security Class Initialized
DEBUG - 2024-02-12 11:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:26:21 --> Input Class Initialized
INFO - 2024-02-12 11:26:21 --> Language Class Initialized
INFO - 2024-02-12 11:26:21 --> Loader Class Initialized
INFO - 2024-02-12 11:26:21 --> Helper loaded: url_helper
INFO - 2024-02-12 11:26:21 --> Helper loaded: file_helper
INFO - 2024-02-12 11:26:21 --> Helper loaded: form_helper
INFO - 2024-02-12 11:26:21 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:26:21 --> Controller Class Initialized
INFO - 2024-02-12 11:26:21 --> Form Validation Class Initialized
INFO - 2024-02-12 11:26:21 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:26:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:26:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:26:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:26:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:26:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:26:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:26:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:26:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:26:21 --> Final output sent to browser
DEBUG - 2024-02-12 11:26:21 --> Total execution time: 0.0276
ERROR - 2024-02-12 11:26:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:26:21 --> Config Class Initialized
INFO - 2024-02-12 11:26:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:26:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:26:21 --> Utf8 Class Initialized
INFO - 2024-02-12 11:26:21 --> URI Class Initialized
INFO - 2024-02-12 11:26:21 --> Router Class Initialized
INFO - 2024-02-12 11:26:21 --> Output Class Initialized
INFO - 2024-02-12 11:26:21 --> Security Class Initialized
DEBUG - 2024-02-12 11:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:26:21 --> Input Class Initialized
INFO - 2024-02-12 11:26:21 --> Language Class Initialized
INFO - 2024-02-12 11:26:21 --> Loader Class Initialized
INFO - 2024-02-12 11:26:21 --> Helper loaded: url_helper
INFO - 2024-02-12 11:26:21 --> Helper loaded: file_helper
INFO - 2024-02-12 11:26:21 --> Helper loaded: form_helper
INFO - 2024-02-12 11:26:21 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:26:21 --> Controller Class Initialized
INFO - 2024-02-12 11:26:21 --> Form Validation Class Initialized
INFO - 2024-02-12 11:26:21 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:26:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:26:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:26:21 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:26:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:26:25 --> Config Class Initialized
INFO - 2024-02-12 11:26:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:26:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:26:25 --> Utf8 Class Initialized
INFO - 2024-02-12 11:26:25 --> URI Class Initialized
INFO - 2024-02-12 11:26:25 --> Router Class Initialized
INFO - 2024-02-12 11:26:25 --> Output Class Initialized
INFO - 2024-02-12 11:26:25 --> Security Class Initialized
DEBUG - 2024-02-12 11:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:26:25 --> Input Class Initialized
INFO - 2024-02-12 11:26:25 --> Language Class Initialized
INFO - 2024-02-12 11:26:25 --> Loader Class Initialized
INFO - 2024-02-12 11:26:25 --> Helper loaded: url_helper
INFO - 2024-02-12 11:26:25 --> Helper loaded: file_helper
INFO - 2024-02-12 11:26:25 --> Helper loaded: form_helper
INFO - 2024-02-12 11:26:25 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:26:25 --> Controller Class Initialized
INFO - 2024-02-12 11:26:25 --> Form Validation Class Initialized
INFO - 2024-02-12 11:26:25 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:26:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:26:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:26:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:26:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:26:50 --> Config Class Initialized
INFO - 2024-02-12 11:26:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:26:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:26:50 --> Utf8 Class Initialized
INFO - 2024-02-12 11:26:50 --> URI Class Initialized
INFO - 2024-02-12 11:26:50 --> Router Class Initialized
INFO - 2024-02-12 11:26:50 --> Output Class Initialized
INFO - 2024-02-12 11:26:50 --> Security Class Initialized
DEBUG - 2024-02-12 11:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:26:50 --> Input Class Initialized
INFO - 2024-02-12 11:26:50 --> Language Class Initialized
INFO - 2024-02-12 11:26:50 --> Loader Class Initialized
INFO - 2024-02-12 11:26:50 --> Helper loaded: url_helper
INFO - 2024-02-12 11:26:50 --> Helper loaded: file_helper
INFO - 2024-02-12 11:26:50 --> Helper loaded: form_helper
INFO - 2024-02-12 11:26:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:26:50 --> Controller Class Initialized
INFO - 2024-02-12 11:26:50 --> Form Validation Class Initialized
INFO - 2024-02-12 11:26:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:26:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:26:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:26:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:26:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:26:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:26:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:26:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:26:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:26:50 --> Final output sent to browser
DEBUG - 2024-02-12 11:26:50 --> Total execution time: 0.0322
ERROR - 2024-02-12 11:26:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:26:50 --> Config Class Initialized
INFO - 2024-02-12 11:26:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:26:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:26:50 --> Utf8 Class Initialized
INFO - 2024-02-12 11:26:50 --> URI Class Initialized
INFO - 2024-02-12 11:26:50 --> Router Class Initialized
INFO - 2024-02-12 11:26:50 --> Output Class Initialized
INFO - 2024-02-12 11:26:50 --> Security Class Initialized
DEBUG - 2024-02-12 11:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:26:50 --> Input Class Initialized
INFO - 2024-02-12 11:26:50 --> Language Class Initialized
INFO - 2024-02-12 11:26:50 --> Loader Class Initialized
INFO - 2024-02-12 11:26:50 --> Helper loaded: url_helper
INFO - 2024-02-12 11:26:50 --> Helper loaded: file_helper
INFO - 2024-02-12 11:26:50 --> Helper loaded: form_helper
INFO - 2024-02-12 11:26:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:26:50 --> Controller Class Initialized
INFO - 2024-02-12 11:26:50 --> Form Validation Class Initialized
INFO - 2024-02-12 11:26:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:26:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:26:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:26:50 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:26:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:26:53 --> Config Class Initialized
INFO - 2024-02-12 11:26:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:26:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:26:53 --> Utf8 Class Initialized
INFO - 2024-02-12 11:26:53 --> URI Class Initialized
INFO - 2024-02-12 11:26:53 --> Router Class Initialized
INFO - 2024-02-12 11:26:53 --> Output Class Initialized
INFO - 2024-02-12 11:26:53 --> Security Class Initialized
DEBUG - 2024-02-12 11:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:26:53 --> Input Class Initialized
INFO - 2024-02-12 11:26:53 --> Language Class Initialized
INFO - 2024-02-12 11:26:53 --> Loader Class Initialized
INFO - 2024-02-12 11:26:53 --> Helper loaded: url_helper
INFO - 2024-02-12 11:26:53 --> Helper loaded: file_helper
INFO - 2024-02-12 11:26:53 --> Helper loaded: form_helper
INFO - 2024-02-12 11:26:53 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:26:53 --> Controller Class Initialized
INFO - 2024-02-12 11:26:53 --> Form Validation Class Initialized
INFO - 2024-02-12 11:26:53 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:26:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:26:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:26:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:27:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:27:12 --> Config Class Initialized
INFO - 2024-02-12 11:27:12 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:27:12 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:27:12 --> Utf8 Class Initialized
INFO - 2024-02-12 11:27:12 --> URI Class Initialized
INFO - 2024-02-12 11:27:12 --> Router Class Initialized
INFO - 2024-02-12 11:27:12 --> Output Class Initialized
INFO - 2024-02-12 11:27:12 --> Security Class Initialized
DEBUG - 2024-02-12 11:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:27:12 --> Input Class Initialized
INFO - 2024-02-12 11:27:12 --> Language Class Initialized
INFO - 2024-02-12 11:27:12 --> Loader Class Initialized
INFO - 2024-02-12 11:27:12 --> Helper loaded: url_helper
INFO - 2024-02-12 11:27:12 --> Helper loaded: file_helper
INFO - 2024-02-12 11:27:12 --> Helper loaded: form_helper
INFO - 2024-02-12 11:27:12 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:27:12 --> Controller Class Initialized
INFO - 2024-02-12 11:27:12 --> Form Validation Class Initialized
INFO - 2024-02-12 11:27:12 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:27:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:27:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:27:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:27:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:27:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:27:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:27:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:27:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:27:12 --> Final output sent to browser
DEBUG - 2024-02-12 11:27:12 --> Total execution time: 0.0254
ERROR - 2024-02-12 11:27:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:27:13 --> Config Class Initialized
INFO - 2024-02-12 11:27:13 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:27:13 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:27:13 --> Utf8 Class Initialized
INFO - 2024-02-12 11:27:13 --> URI Class Initialized
INFO - 2024-02-12 11:27:13 --> Router Class Initialized
INFO - 2024-02-12 11:27:13 --> Output Class Initialized
INFO - 2024-02-12 11:27:13 --> Security Class Initialized
DEBUG - 2024-02-12 11:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:27:13 --> Input Class Initialized
INFO - 2024-02-12 11:27:13 --> Language Class Initialized
INFO - 2024-02-12 11:27:13 --> Loader Class Initialized
INFO - 2024-02-12 11:27:13 --> Helper loaded: url_helper
INFO - 2024-02-12 11:27:13 --> Helper loaded: file_helper
INFO - 2024-02-12 11:27:13 --> Helper loaded: form_helper
INFO - 2024-02-12 11:27:13 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:27:13 --> Controller Class Initialized
INFO - 2024-02-12 11:27:13 --> Form Validation Class Initialized
INFO - 2024-02-12 11:27:13 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:27:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:27:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:27:13 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:27:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:27:15 --> Config Class Initialized
INFO - 2024-02-12 11:27:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:27:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:27:15 --> Utf8 Class Initialized
INFO - 2024-02-12 11:27:15 --> URI Class Initialized
INFO - 2024-02-12 11:27:15 --> Router Class Initialized
INFO - 2024-02-12 11:27:15 --> Output Class Initialized
INFO - 2024-02-12 11:27:15 --> Security Class Initialized
DEBUG - 2024-02-12 11:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:27:15 --> Input Class Initialized
INFO - 2024-02-12 11:27:15 --> Language Class Initialized
INFO - 2024-02-12 11:27:15 --> Loader Class Initialized
INFO - 2024-02-12 11:27:15 --> Helper loaded: url_helper
INFO - 2024-02-12 11:27:15 --> Helper loaded: file_helper
INFO - 2024-02-12 11:27:15 --> Helper loaded: form_helper
INFO - 2024-02-12 11:27:15 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:27:15 --> Controller Class Initialized
INFO - 2024-02-12 11:27:15 --> Form Validation Class Initialized
INFO - 2024-02-12 11:27:15 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:27:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:27:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:27:15 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:27:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:27:43 --> Config Class Initialized
INFO - 2024-02-12 11:27:43 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:27:43 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:27:43 --> Utf8 Class Initialized
INFO - 2024-02-12 11:27:43 --> URI Class Initialized
INFO - 2024-02-12 11:27:43 --> Router Class Initialized
INFO - 2024-02-12 11:27:43 --> Output Class Initialized
INFO - 2024-02-12 11:27:43 --> Security Class Initialized
DEBUG - 2024-02-12 11:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:27:43 --> Input Class Initialized
INFO - 2024-02-12 11:27:43 --> Language Class Initialized
INFO - 2024-02-12 11:27:43 --> Loader Class Initialized
INFO - 2024-02-12 11:27:43 --> Helper loaded: url_helper
INFO - 2024-02-12 11:27:43 --> Helper loaded: file_helper
INFO - 2024-02-12 11:27:43 --> Helper loaded: form_helper
INFO - 2024-02-12 11:27:43 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:27:43 --> Controller Class Initialized
INFO - 2024-02-12 11:27:43 --> Form Validation Class Initialized
INFO - 2024-02-12 11:27:43 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:27:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:27:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:27:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:27:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:27:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:27:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:27:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:27:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:27:43 --> Final output sent to browser
DEBUG - 2024-02-12 11:27:43 --> Total execution time: 0.0404
ERROR - 2024-02-12 11:27:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:27:43 --> Config Class Initialized
INFO - 2024-02-12 11:27:43 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:27:43 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:27:43 --> Utf8 Class Initialized
INFO - 2024-02-12 11:27:43 --> URI Class Initialized
INFO - 2024-02-12 11:27:43 --> Router Class Initialized
INFO - 2024-02-12 11:27:43 --> Output Class Initialized
INFO - 2024-02-12 11:27:43 --> Security Class Initialized
DEBUG - 2024-02-12 11:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:27:43 --> Input Class Initialized
INFO - 2024-02-12 11:27:43 --> Language Class Initialized
INFO - 2024-02-12 11:27:43 --> Loader Class Initialized
INFO - 2024-02-12 11:27:43 --> Helper loaded: url_helper
INFO - 2024-02-12 11:27:43 --> Helper loaded: file_helper
INFO - 2024-02-12 11:27:43 --> Helper loaded: form_helper
INFO - 2024-02-12 11:27:43 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:27:43 --> Controller Class Initialized
INFO - 2024-02-12 11:27:43 --> Form Validation Class Initialized
INFO - 2024-02-12 11:27:43 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:27:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:27:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:27:43 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:27:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:27:45 --> Config Class Initialized
INFO - 2024-02-12 11:27:45 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:27:45 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:27:45 --> Utf8 Class Initialized
INFO - 2024-02-12 11:27:45 --> URI Class Initialized
INFO - 2024-02-12 11:27:45 --> Router Class Initialized
INFO - 2024-02-12 11:27:45 --> Output Class Initialized
INFO - 2024-02-12 11:27:45 --> Security Class Initialized
DEBUG - 2024-02-12 11:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:27:45 --> Input Class Initialized
INFO - 2024-02-12 11:27:45 --> Language Class Initialized
INFO - 2024-02-12 11:27:45 --> Loader Class Initialized
INFO - 2024-02-12 11:27:45 --> Helper loaded: url_helper
INFO - 2024-02-12 11:27:45 --> Helper loaded: file_helper
INFO - 2024-02-12 11:27:45 --> Helper loaded: form_helper
INFO - 2024-02-12 11:27:45 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:27:45 --> Controller Class Initialized
INFO - 2024-02-12 11:27:45 --> Form Validation Class Initialized
INFO - 2024-02-12 11:27:45 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:27:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:27:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:27:45 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:27:45 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-12 11:27:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:27:45 --> Final output sent to browser
DEBUG - 2024-02-12 11:27:45 --> Total execution time: 0.0382
ERROR - 2024-02-12 11:28:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:28:31 --> Config Class Initialized
INFO - 2024-02-12 11:28:31 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:28:31 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:28:31 --> Utf8 Class Initialized
INFO - 2024-02-12 11:28:31 --> URI Class Initialized
INFO - 2024-02-12 11:28:31 --> Router Class Initialized
INFO - 2024-02-12 11:28:31 --> Output Class Initialized
INFO - 2024-02-12 11:28:31 --> Security Class Initialized
DEBUG - 2024-02-12 11:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:28:31 --> Input Class Initialized
INFO - 2024-02-12 11:28:31 --> Language Class Initialized
INFO - 2024-02-12 11:28:31 --> Loader Class Initialized
INFO - 2024-02-12 11:28:31 --> Helper loaded: url_helper
INFO - 2024-02-12 11:28:31 --> Helper loaded: file_helper
INFO - 2024-02-12 11:28:31 --> Helper loaded: form_helper
INFO - 2024-02-12 11:28:31 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:28:31 --> Controller Class Initialized
INFO - 2024-02-12 11:28:31 --> Form Validation Class Initialized
INFO - 2024-02-12 11:28:31 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:28:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:28:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:28:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:28:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:28:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:28:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:28:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:28:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:28:31 --> Final output sent to browser
DEBUG - 2024-02-12 11:28:31 --> Total execution time: 0.0283
ERROR - 2024-02-12 11:28:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:28:31 --> Config Class Initialized
INFO - 2024-02-12 11:28:31 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:28:31 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:28:31 --> Utf8 Class Initialized
INFO - 2024-02-12 11:28:31 --> URI Class Initialized
INFO - 2024-02-12 11:28:31 --> Router Class Initialized
INFO - 2024-02-12 11:28:31 --> Output Class Initialized
INFO - 2024-02-12 11:28:31 --> Security Class Initialized
DEBUG - 2024-02-12 11:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:28:31 --> Input Class Initialized
INFO - 2024-02-12 11:28:31 --> Language Class Initialized
INFO - 2024-02-12 11:28:31 --> Loader Class Initialized
INFO - 2024-02-12 11:28:31 --> Helper loaded: url_helper
INFO - 2024-02-12 11:28:31 --> Helper loaded: file_helper
INFO - 2024-02-12 11:28:31 --> Helper loaded: form_helper
INFO - 2024-02-12 11:28:31 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:28:31 --> Controller Class Initialized
INFO - 2024-02-12 11:28:31 --> Form Validation Class Initialized
INFO - 2024-02-12 11:28:31 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:28:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:28:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:28:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:28:34 --> Config Class Initialized
INFO - 2024-02-12 11:28:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:28:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:28:34 --> Utf8 Class Initialized
INFO - 2024-02-12 11:28:34 --> URI Class Initialized
INFO - 2024-02-12 11:28:34 --> Router Class Initialized
INFO - 2024-02-12 11:28:34 --> Output Class Initialized
INFO - 2024-02-12 11:28:34 --> Security Class Initialized
DEBUG - 2024-02-12 11:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:28:34 --> Input Class Initialized
INFO - 2024-02-12 11:28:34 --> Language Class Initialized
INFO - 2024-02-12 11:28:34 --> Loader Class Initialized
INFO - 2024-02-12 11:28:34 --> Helper loaded: url_helper
INFO - 2024-02-12 11:28:34 --> Helper loaded: file_helper
INFO - 2024-02-12 11:28:34 --> Helper loaded: form_helper
INFO - 2024-02-12 11:28:34 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:28:34 --> Controller Class Initialized
INFO - 2024-02-12 11:28:34 --> Form Validation Class Initialized
INFO - 2024-02-12 11:28:34 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:28:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:28:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:28:34 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:28:34 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-12 11:28:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:28:34 --> Final output sent to browser
DEBUG - 2024-02-12 11:28:34 --> Total execution time: 0.0380
ERROR - 2024-02-12 11:30:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:30:25 --> Config Class Initialized
INFO - 2024-02-12 11:30:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:30:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:30:25 --> Utf8 Class Initialized
INFO - 2024-02-12 11:30:25 --> URI Class Initialized
INFO - 2024-02-12 11:30:25 --> Router Class Initialized
INFO - 2024-02-12 11:30:25 --> Output Class Initialized
INFO - 2024-02-12 11:30:25 --> Security Class Initialized
DEBUG - 2024-02-12 11:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:30:25 --> Input Class Initialized
INFO - 2024-02-12 11:30:25 --> Language Class Initialized
INFO - 2024-02-12 11:30:25 --> Loader Class Initialized
INFO - 2024-02-12 11:30:25 --> Helper loaded: url_helper
INFO - 2024-02-12 11:30:25 --> Helper loaded: file_helper
INFO - 2024-02-12 11:30:25 --> Helper loaded: form_helper
INFO - 2024-02-12 11:30:25 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:30:25 --> Controller Class Initialized
INFO - 2024-02-12 11:30:25 --> Form Validation Class Initialized
INFO - 2024-02-12 11:30:25 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:30:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:30:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:30:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:30:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:30:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:30:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:30:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:30:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:30:25 --> Final output sent to browser
DEBUG - 2024-02-12 11:30:25 --> Total execution time: 0.0297
ERROR - 2024-02-12 11:30:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:30:26 --> Config Class Initialized
INFO - 2024-02-12 11:30:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:30:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:30:26 --> Utf8 Class Initialized
INFO - 2024-02-12 11:30:26 --> URI Class Initialized
INFO - 2024-02-12 11:30:26 --> Router Class Initialized
INFO - 2024-02-12 11:30:26 --> Output Class Initialized
INFO - 2024-02-12 11:30:26 --> Security Class Initialized
DEBUG - 2024-02-12 11:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:30:26 --> Input Class Initialized
INFO - 2024-02-12 11:30:26 --> Language Class Initialized
INFO - 2024-02-12 11:30:26 --> Loader Class Initialized
INFO - 2024-02-12 11:30:26 --> Helper loaded: url_helper
INFO - 2024-02-12 11:30:26 --> Helper loaded: file_helper
INFO - 2024-02-12 11:30:26 --> Helper loaded: form_helper
INFO - 2024-02-12 11:30:26 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:30:26 --> Controller Class Initialized
INFO - 2024-02-12 11:30:26 --> Form Validation Class Initialized
INFO - 2024-02-12 11:30:26 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:30:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:30:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:30:26 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:30:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:30:29 --> Config Class Initialized
INFO - 2024-02-12 11:30:29 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:30:29 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:30:29 --> Utf8 Class Initialized
INFO - 2024-02-12 11:30:29 --> URI Class Initialized
INFO - 2024-02-12 11:30:29 --> Router Class Initialized
INFO - 2024-02-12 11:30:29 --> Output Class Initialized
INFO - 2024-02-12 11:30:29 --> Security Class Initialized
DEBUG - 2024-02-12 11:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:30:29 --> Input Class Initialized
INFO - 2024-02-12 11:30:29 --> Language Class Initialized
INFO - 2024-02-12 11:30:29 --> Loader Class Initialized
INFO - 2024-02-12 11:30:29 --> Helper loaded: url_helper
INFO - 2024-02-12 11:30:29 --> Helper loaded: file_helper
INFO - 2024-02-12 11:30:29 --> Helper loaded: form_helper
INFO - 2024-02-12 11:30:29 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:30:29 --> Controller Class Initialized
INFO - 2024-02-12 11:30:29 --> Form Validation Class Initialized
INFO - 2024-02-12 11:30:29 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:30:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:30:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:30:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:30:29 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-12 11:30:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:30:29 --> Final output sent to browser
DEBUG - 2024-02-12 11:30:29 --> Total execution time: 0.0389
ERROR - 2024-02-12 11:31:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:31:17 --> Config Class Initialized
INFO - 2024-02-12 11:31:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:31:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:31:17 --> Utf8 Class Initialized
INFO - 2024-02-12 11:31:17 --> URI Class Initialized
INFO - 2024-02-12 11:31:17 --> Router Class Initialized
INFO - 2024-02-12 11:31:17 --> Output Class Initialized
INFO - 2024-02-12 11:31:17 --> Security Class Initialized
DEBUG - 2024-02-12 11:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:31:17 --> Input Class Initialized
INFO - 2024-02-12 11:31:17 --> Language Class Initialized
INFO - 2024-02-12 11:31:17 --> Loader Class Initialized
INFO - 2024-02-12 11:31:17 --> Helper loaded: url_helper
INFO - 2024-02-12 11:31:17 --> Helper loaded: file_helper
INFO - 2024-02-12 11:31:17 --> Helper loaded: form_helper
INFO - 2024-02-12 11:31:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:31:17 --> Controller Class Initialized
INFO - 2024-02-12 11:31:17 --> Form Validation Class Initialized
INFO - 2024-02-12 11:31:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:31:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:31:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:31:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:31:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:31:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:31:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:31:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:31:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:31:17 --> Final output sent to browser
DEBUG - 2024-02-12 11:31:17 --> Total execution time: 0.0259
ERROR - 2024-02-12 11:31:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:31:18 --> Config Class Initialized
INFO - 2024-02-12 11:31:18 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:31:18 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:31:18 --> Utf8 Class Initialized
INFO - 2024-02-12 11:31:18 --> URI Class Initialized
INFO - 2024-02-12 11:31:18 --> Router Class Initialized
INFO - 2024-02-12 11:31:18 --> Output Class Initialized
INFO - 2024-02-12 11:31:18 --> Security Class Initialized
DEBUG - 2024-02-12 11:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:31:18 --> Input Class Initialized
INFO - 2024-02-12 11:31:18 --> Language Class Initialized
INFO - 2024-02-12 11:31:18 --> Loader Class Initialized
INFO - 2024-02-12 11:31:18 --> Helper loaded: url_helper
INFO - 2024-02-12 11:31:18 --> Helper loaded: file_helper
INFO - 2024-02-12 11:31:18 --> Helper loaded: form_helper
INFO - 2024-02-12 11:31:18 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:31:18 --> Controller Class Initialized
INFO - 2024-02-12 11:31:18 --> Form Validation Class Initialized
INFO - 2024-02-12 11:31:18 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:31:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:31:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:31:18 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:31:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:31:22 --> Config Class Initialized
INFO - 2024-02-12 11:31:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:31:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:31:22 --> Utf8 Class Initialized
INFO - 2024-02-12 11:31:22 --> URI Class Initialized
INFO - 2024-02-12 11:31:22 --> Router Class Initialized
INFO - 2024-02-12 11:31:22 --> Output Class Initialized
INFO - 2024-02-12 11:31:22 --> Security Class Initialized
DEBUG - 2024-02-12 11:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:31:22 --> Input Class Initialized
INFO - 2024-02-12 11:31:22 --> Language Class Initialized
INFO - 2024-02-12 11:31:22 --> Loader Class Initialized
INFO - 2024-02-12 11:31:22 --> Helper loaded: url_helper
INFO - 2024-02-12 11:31:22 --> Helper loaded: file_helper
INFO - 2024-02-12 11:31:22 --> Helper loaded: form_helper
INFO - 2024-02-12 11:31:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:31:22 --> Controller Class Initialized
INFO - 2024-02-12 11:31:22 --> Form Validation Class Initialized
INFO - 2024-02-12 11:31:22 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:31:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:31:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:31:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:31:22 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-12 11:31:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:31:22 --> Final output sent to browser
DEBUG - 2024-02-12 11:31:22 --> Total execution time: 0.0340
ERROR - 2024-02-12 11:31:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:31:50 --> Config Class Initialized
INFO - 2024-02-12 11:31:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:31:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:31:50 --> Utf8 Class Initialized
INFO - 2024-02-12 11:31:50 --> URI Class Initialized
INFO - 2024-02-12 11:31:50 --> Router Class Initialized
INFO - 2024-02-12 11:31:50 --> Output Class Initialized
INFO - 2024-02-12 11:31:50 --> Security Class Initialized
DEBUG - 2024-02-12 11:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:31:50 --> Input Class Initialized
INFO - 2024-02-12 11:31:50 --> Language Class Initialized
INFO - 2024-02-12 11:31:50 --> Loader Class Initialized
INFO - 2024-02-12 11:31:50 --> Helper loaded: url_helper
INFO - 2024-02-12 11:31:50 --> Helper loaded: file_helper
INFO - 2024-02-12 11:31:50 --> Helper loaded: form_helper
INFO - 2024-02-12 11:31:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:31:50 --> Controller Class Initialized
INFO - 2024-02-12 11:31:50 --> Model "LoginModel" initialized
INFO - 2024-02-12 11:31:50 --> Form Validation Class Initialized
ERROR - 2024-02-12 11:31:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:31:50 --> Config Class Initialized
INFO - 2024-02-12 11:31:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:31:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:31:50 --> Utf8 Class Initialized
INFO - 2024-02-12 11:31:50 --> URI Class Initialized
INFO - 2024-02-12 11:31:50 --> Router Class Initialized
INFO - 2024-02-12 11:31:50 --> Output Class Initialized
INFO - 2024-02-12 11:31:50 --> Security Class Initialized
DEBUG - 2024-02-12 11:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:31:50 --> Input Class Initialized
INFO - 2024-02-12 11:31:50 --> Language Class Initialized
INFO - 2024-02-12 11:31:50 --> Loader Class Initialized
INFO - 2024-02-12 11:31:50 --> Helper loaded: url_helper
INFO - 2024-02-12 11:31:50 --> Helper loaded: file_helper
INFO - 2024-02-12 11:31:50 --> Helper loaded: form_helper
INFO - 2024-02-12 11:31:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:31:50 --> Controller Class Initialized
INFO - 2024-02-12 11:31:50 --> Model "LoginModel" initialized
INFO - 2024-02-12 11:31:50 --> Form Validation Class Initialized
INFO - 2024-02-12 11:31:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-12 11:31:50 --> Final output sent to browser
DEBUG - 2024-02-12 11:31:50 --> Total execution time: 0.0455
ERROR - 2024-02-12 11:32:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:32:00 --> Config Class Initialized
INFO - 2024-02-12 11:32:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:32:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:32:00 --> Utf8 Class Initialized
INFO - 2024-02-12 11:32:00 --> URI Class Initialized
INFO - 2024-02-12 11:32:00 --> Router Class Initialized
INFO - 2024-02-12 11:32:00 --> Output Class Initialized
INFO - 2024-02-12 11:32:00 --> Security Class Initialized
DEBUG - 2024-02-12 11:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:32:00 --> Input Class Initialized
INFO - 2024-02-12 11:32:00 --> Language Class Initialized
INFO - 2024-02-12 11:32:00 --> Loader Class Initialized
INFO - 2024-02-12 11:32:00 --> Helper loaded: url_helper
INFO - 2024-02-12 11:32:00 --> Helper loaded: file_helper
INFO - 2024-02-12 11:32:00 --> Helper loaded: form_helper
INFO - 2024-02-12 11:32:00 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:32:00 --> Controller Class Initialized
INFO - 2024-02-12 11:32:00 --> Model "LoginModel" initialized
INFO - 2024-02-12 11:32:00 --> Form Validation Class Initialized
INFO - 2024-02-12 11:32:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-12 11:32:00 --> Final output sent to browser
DEBUG - 2024-02-12 11:32:00 --> Total execution time: 0.0339
ERROR - 2024-02-12 11:32:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:32:09 --> Config Class Initialized
INFO - 2024-02-12 11:32:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:32:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:32:09 --> Utf8 Class Initialized
INFO - 2024-02-12 11:32:09 --> URI Class Initialized
INFO - 2024-02-12 11:32:09 --> Router Class Initialized
INFO - 2024-02-12 11:32:09 --> Output Class Initialized
INFO - 2024-02-12 11:32:09 --> Security Class Initialized
DEBUG - 2024-02-12 11:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:32:09 --> Input Class Initialized
INFO - 2024-02-12 11:32:09 --> Language Class Initialized
INFO - 2024-02-12 11:32:09 --> Loader Class Initialized
INFO - 2024-02-12 11:32:09 --> Helper loaded: url_helper
INFO - 2024-02-12 11:32:09 --> Helper loaded: file_helper
INFO - 2024-02-12 11:32:09 --> Helper loaded: form_helper
INFO - 2024-02-12 11:32:09 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:32:09 --> Controller Class Initialized
INFO - 2024-02-12 11:32:09 --> Model "LoginModel" initialized
INFO - 2024-02-12 11:32:09 --> Form Validation Class Initialized
INFO - 2024-02-12 11:32:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-12 11:32:09 --> Final output sent to browser
DEBUG - 2024-02-12 11:32:09 --> Total execution time: 0.0270
ERROR - 2024-02-12 11:32:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:32:21 --> Config Class Initialized
INFO - 2024-02-12 11:32:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:32:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:32:21 --> Utf8 Class Initialized
INFO - 2024-02-12 11:32:21 --> URI Class Initialized
INFO - 2024-02-12 11:32:21 --> Router Class Initialized
INFO - 2024-02-12 11:32:21 --> Output Class Initialized
INFO - 2024-02-12 11:32:21 --> Security Class Initialized
DEBUG - 2024-02-12 11:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:32:21 --> Input Class Initialized
INFO - 2024-02-12 11:32:21 --> Language Class Initialized
INFO - 2024-02-12 11:32:21 --> Loader Class Initialized
INFO - 2024-02-12 11:32:21 --> Helper loaded: url_helper
INFO - 2024-02-12 11:32:21 --> Helper loaded: file_helper
INFO - 2024-02-12 11:32:21 --> Helper loaded: form_helper
INFO - 2024-02-12 11:32:21 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:32:21 --> Controller Class Initialized
INFO - 2024-02-12 11:32:21 --> Model "LoginModel" initialized
INFO - 2024-02-12 11:32:21 --> Form Validation Class Initialized
INFO - 2024-02-12 11:32:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-12 11:32:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:32:21 --> Config Class Initialized
INFO - 2024-02-12 11:32:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:32:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:32:21 --> Utf8 Class Initialized
INFO - 2024-02-12 11:32:21 --> URI Class Initialized
INFO - 2024-02-12 11:32:21 --> Router Class Initialized
INFO - 2024-02-12 11:32:21 --> Output Class Initialized
INFO - 2024-02-12 11:32:21 --> Security Class Initialized
DEBUG - 2024-02-12 11:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:32:21 --> Input Class Initialized
INFO - 2024-02-12 11:32:21 --> Language Class Initialized
INFO - 2024-02-12 11:32:21 --> Loader Class Initialized
INFO - 2024-02-12 11:32:21 --> Helper loaded: url_helper
INFO - 2024-02-12 11:32:21 --> Helper loaded: file_helper
INFO - 2024-02-12 11:32:21 --> Helper loaded: form_helper
INFO - 2024-02-12 11:32:21 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:32:21 --> Controller Class Initialized
INFO - 2024-02-12 11:32:21 --> Form Validation Class Initialized
INFO - 2024-02-12 11:32:21 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:32:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:32:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:32:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:32:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:32:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-12 11:32:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:32:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:32:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:32:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-12 11:32:21 --> Final output sent to browser
DEBUG - 2024-02-12 11:32:21 --> Total execution time: 0.0237
ERROR - 2024-02-12 11:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:32:25 --> Config Class Initialized
INFO - 2024-02-12 11:32:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:32:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:32:25 --> Utf8 Class Initialized
INFO - 2024-02-12 11:32:25 --> URI Class Initialized
INFO - 2024-02-12 11:32:25 --> Router Class Initialized
INFO - 2024-02-12 11:32:25 --> Output Class Initialized
INFO - 2024-02-12 11:32:25 --> Security Class Initialized
DEBUG - 2024-02-12 11:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:32:25 --> Input Class Initialized
INFO - 2024-02-12 11:32:25 --> Language Class Initialized
INFO - 2024-02-12 11:32:25 --> Loader Class Initialized
INFO - 2024-02-12 11:32:25 --> Helper loaded: url_helper
INFO - 2024-02-12 11:32:25 --> Helper loaded: file_helper
INFO - 2024-02-12 11:32:25 --> Helper loaded: form_helper
INFO - 2024-02-12 11:32:25 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:32:25 --> Controller Class Initialized
INFO - 2024-02-12 11:32:25 --> Form Validation Class Initialized
INFO - 2024-02-12 11:32:25 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:32:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:32:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:32:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:32:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:32:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:32:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:32:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:32:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:32:25 --> Final output sent to browser
DEBUG - 2024-02-12 11:32:25 --> Total execution time: 0.0231
ERROR - 2024-02-12 11:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:32:25 --> Config Class Initialized
INFO - 2024-02-12 11:32:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:32:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:32:25 --> Utf8 Class Initialized
INFO - 2024-02-12 11:32:25 --> URI Class Initialized
INFO - 2024-02-12 11:32:25 --> Router Class Initialized
INFO - 2024-02-12 11:32:25 --> Output Class Initialized
INFO - 2024-02-12 11:32:25 --> Security Class Initialized
DEBUG - 2024-02-12 11:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:32:25 --> Input Class Initialized
INFO - 2024-02-12 11:32:25 --> Language Class Initialized
INFO - 2024-02-12 11:32:25 --> Loader Class Initialized
INFO - 2024-02-12 11:32:25 --> Helper loaded: url_helper
INFO - 2024-02-12 11:32:25 --> Helper loaded: file_helper
INFO - 2024-02-12 11:32:25 --> Helper loaded: form_helper
INFO - 2024-02-12 11:32:25 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:32:25 --> Controller Class Initialized
INFO - 2024-02-12 11:32:25 --> Form Validation Class Initialized
INFO - 2024-02-12 11:32:25 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:32:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:32:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:32:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:32:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:32:27 --> Config Class Initialized
INFO - 2024-02-12 11:32:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:32:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:32:27 --> Utf8 Class Initialized
INFO - 2024-02-12 11:32:27 --> URI Class Initialized
INFO - 2024-02-12 11:32:27 --> Router Class Initialized
INFO - 2024-02-12 11:32:27 --> Output Class Initialized
INFO - 2024-02-12 11:32:27 --> Security Class Initialized
DEBUG - 2024-02-12 11:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:32:27 --> Input Class Initialized
INFO - 2024-02-12 11:32:27 --> Language Class Initialized
INFO - 2024-02-12 11:32:27 --> Loader Class Initialized
INFO - 2024-02-12 11:32:27 --> Helper loaded: url_helper
INFO - 2024-02-12 11:32:27 --> Helper loaded: file_helper
INFO - 2024-02-12 11:32:27 --> Helper loaded: form_helper
INFO - 2024-02-12 11:32:27 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:32:27 --> Controller Class Initialized
INFO - 2024-02-12 11:32:27 --> Form Validation Class Initialized
INFO - 2024-02-12 11:32:27 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:32:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:32:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:32:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:32:27 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-12 11:32:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:32:27 --> Final output sent to browser
DEBUG - 2024-02-12 11:32:27 --> Total execution time: 0.0439
ERROR - 2024-02-12 11:33:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:33:50 --> Config Class Initialized
INFO - 2024-02-12 11:33:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:33:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:33:50 --> Utf8 Class Initialized
INFO - 2024-02-12 11:33:50 --> URI Class Initialized
INFO - 2024-02-12 11:33:50 --> Router Class Initialized
INFO - 2024-02-12 11:33:50 --> Output Class Initialized
INFO - 2024-02-12 11:33:50 --> Security Class Initialized
DEBUG - 2024-02-12 11:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:33:50 --> Input Class Initialized
INFO - 2024-02-12 11:33:50 --> Language Class Initialized
INFO - 2024-02-12 11:33:50 --> Loader Class Initialized
INFO - 2024-02-12 11:33:50 --> Helper loaded: url_helper
INFO - 2024-02-12 11:33:50 --> Helper loaded: file_helper
INFO - 2024-02-12 11:33:50 --> Helper loaded: form_helper
INFO - 2024-02-12 11:33:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:33:50 --> Controller Class Initialized
INFO - 2024-02-12 11:33:50 --> Form Validation Class Initialized
INFO - 2024-02-12 11:33:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:33:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:33:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:33:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:33:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:33:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:33:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:33:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:33:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:33:50 --> Final output sent to browser
DEBUG - 2024-02-12 11:33:50 --> Total execution time: 0.0320
ERROR - 2024-02-12 11:33:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:33:51 --> Config Class Initialized
INFO - 2024-02-12 11:33:51 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:33:51 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:33:51 --> Utf8 Class Initialized
INFO - 2024-02-12 11:33:51 --> URI Class Initialized
INFO - 2024-02-12 11:33:51 --> Router Class Initialized
INFO - 2024-02-12 11:33:51 --> Output Class Initialized
INFO - 2024-02-12 11:33:51 --> Security Class Initialized
DEBUG - 2024-02-12 11:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:33:51 --> Input Class Initialized
INFO - 2024-02-12 11:33:51 --> Language Class Initialized
INFO - 2024-02-12 11:33:51 --> Loader Class Initialized
INFO - 2024-02-12 11:33:51 --> Helper loaded: url_helper
INFO - 2024-02-12 11:33:51 --> Helper loaded: file_helper
INFO - 2024-02-12 11:33:51 --> Helper loaded: form_helper
INFO - 2024-02-12 11:33:51 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:33:51 --> Controller Class Initialized
INFO - 2024-02-12 11:33:51 --> Form Validation Class Initialized
INFO - 2024-02-12 11:33:51 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:33:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:33:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:33:51 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:33:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:33:54 --> Config Class Initialized
INFO - 2024-02-12 11:33:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:33:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:33:54 --> Utf8 Class Initialized
INFO - 2024-02-12 11:33:54 --> URI Class Initialized
INFO - 2024-02-12 11:33:54 --> Router Class Initialized
INFO - 2024-02-12 11:33:54 --> Output Class Initialized
INFO - 2024-02-12 11:33:54 --> Security Class Initialized
DEBUG - 2024-02-12 11:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:33:54 --> Input Class Initialized
INFO - 2024-02-12 11:33:54 --> Language Class Initialized
INFO - 2024-02-12 11:33:54 --> Loader Class Initialized
INFO - 2024-02-12 11:33:54 --> Helper loaded: url_helper
INFO - 2024-02-12 11:33:54 --> Helper loaded: file_helper
INFO - 2024-02-12 11:33:54 --> Helper loaded: form_helper
INFO - 2024-02-12 11:33:54 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:33:54 --> Controller Class Initialized
INFO - 2024-02-12 11:33:54 --> Form Validation Class Initialized
INFO - 2024-02-12 11:33:54 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:33:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:33:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:33:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:33:54 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-12 11:33:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:33:54 --> Final output sent to browser
DEBUG - 2024-02-12 11:33:54 --> Total execution time: 0.0210
ERROR - 2024-02-12 11:34:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:34:27 --> Config Class Initialized
INFO - 2024-02-12 11:34:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:34:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:34:27 --> Utf8 Class Initialized
INFO - 2024-02-12 11:34:27 --> URI Class Initialized
INFO - 2024-02-12 11:34:27 --> Router Class Initialized
INFO - 2024-02-12 11:34:27 --> Output Class Initialized
INFO - 2024-02-12 11:34:27 --> Security Class Initialized
DEBUG - 2024-02-12 11:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:34:27 --> Input Class Initialized
INFO - 2024-02-12 11:34:27 --> Language Class Initialized
INFO - 2024-02-12 11:34:27 --> Loader Class Initialized
INFO - 2024-02-12 11:34:27 --> Helper loaded: url_helper
INFO - 2024-02-12 11:34:27 --> Helper loaded: file_helper
INFO - 2024-02-12 11:34:27 --> Helper loaded: form_helper
INFO - 2024-02-12 11:34:27 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:34:27 --> Controller Class Initialized
INFO - 2024-02-12 11:34:27 --> Form Validation Class Initialized
INFO - 2024-02-12 11:34:27 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:34:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:34:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:34:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:34:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:34:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:34:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:34:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:34:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:34:27 --> Final output sent to browser
DEBUG - 2024-02-12 11:34:27 --> Total execution time: 0.0265
ERROR - 2024-02-12 11:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:34:28 --> Config Class Initialized
INFO - 2024-02-12 11:34:28 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:34:28 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:34:28 --> Utf8 Class Initialized
INFO - 2024-02-12 11:34:28 --> URI Class Initialized
INFO - 2024-02-12 11:34:28 --> Router Class Initialized
INFO - 2024-02-12 11:34:28 --> Output Class Initialized
INFO - 2024-02-12 11:34:28 --> Security Class Initialized
DEBUG - 2024-02-12 11:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:34:28 --> Input Class Initialized
INFO - 2024-02-12 11:34:28 --> Language Class Initialized
INFO - 2024-02-12 11:34:28 --> Loader Class Initialized
INFO - 2024-02-12 11:34:28 --> Helper loaded: url_helper
INFO - 2024-02-12 11:34:28 --> Helper loaded: file_helper
INFO - 2024-02-12 11:34:28 --> Helper loaded: form_helper
INFO - 2024-02-12 11:34:28 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:34:28 --> Controller Class Initialized
INFO - 2024-02-12 11:34:28 --> Form Validation Class Initialized
INFO - 2024-02-12 11:34:28 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:34:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:34:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:34:28 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:34:30 --> Config Class Initialized
INFO - 2024-02-12 11:34:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:34:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:34:30 --> Utf8 Class Initialized
INFO - 2024-02-12 11:34:30 --> URI Class Initialized
INFO - 2024-02-12 11:34:30 --> Router Class Initialized
INFO - 2024-02-12 11:34:30 --> Output Class Initialized
INFO - 2024-02-12 11:34:30 --> Security Class Initialized
DEBUG - 2024-02-12 11:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:34:30 --> Input Class Initialized
INFO - 2024-02-12 11:34:30 --> Language Class Initialized
INFO - 2024-02-12 11:34:30 --> Loader Class Initialized
INFO - 2024-02-12 11:34:30 --> Helper loaded: url_helper
INFO - 2024-02-12 11:34:30 --> Helper loaded: file_helper
INFO - 2024-02-12 11:34:30 --> Helper loaded: form_helper
INFO - 2024-02-12 11:34:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:34:30 --> Controller Class Initialized
INFO - 2024-02-12 11:34:30 --> Form Validation Class Initialized
INFO - 2024-02-12 11:34:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:34:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:34:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:34:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:30 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-12 11:34:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:34:30 --> Final output sent to browser
DEBUG - 2024-02-12 11:34:30 --> Total execution time: 0.0214
ERROR - 2024-02-12 11:34:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:34:44 --> Config Class Initialized
INFO - 2024-02-12 11:34:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:34:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:34:44 --> Utf8 Class Initialized
INFO - 2024-02-12 11:34:44 --> URI Class Initialized
INFO - 2024-02-12 11:34:44 --> Router Class Initialized
INFO - 2024-02-12 11:34:44 --> Output Class Initialized
INFO - 2024-02-12 11:34:44 --> Security Class Initialized
DEBUG - 2024-02-12 11:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:34:44 --> Input Class Initialized
INFO - 2024-02-12 11:34:44 --> Language Class Initialized
INFO - 2024-02-12 11:34:44 --> Loader Class Initialized
INFO - 2024-02-12 11:34:44 --> Helper loaded: url_helper
INFO - 2024-02-12 11:34:44 --> Helper loaded: file_helper
INFO - 2024-02-12 11:34:44 --> Helper loaded: form_helper
INFO - 2024-02-12 11:34:44 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:34:44 --> Controller Class Initialized
INFO - 2024-02-12 11:34:44 --> Form Validation Class Initialized
INFO - 2024-02-12 11:34:44 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:34:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:34:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:34:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:34:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:34:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:34:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:34:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:34:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:34:44 --> Final output sent to browser
DEBUG - 2024-02-12 11:34:44 --> Total execution time: 0.0323
ERROR - 2024-02-12 11:34:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:34:44 --> Config Class Initialized
INFO - 2024-02-12 11:34:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:34:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:34:44 --> Utf8 Class Initialized
INFO - 2024-02-12 11:34:44 --> URI Class Initialized
INFO - 2024-02-12 11:34:44 --> Router Class Initialized
INFO - 2024-02-12 11:34:44 --> Output Class Initialized
INFO - 2024-02-12 11:34:44 --> Security Class Initialized
DEBUG - 2024-02-12 11:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:34:44 --> Input Class Initialized
INFO - 2024-02-12 11:34:44 --> Language Class Initialized
INFO - 2024-02-12 11:34:44 --> Loader Class Initialized
INFO - 2024-02-12 11:34:44 --> Helper loaded: url_helper
INFO - 2024-02-12 11:34:44 --> Helper loaded: file_helper
INFO - 2024-02-12 11:34:44 --> Helper loaded: form_helper
INFO - 2024-02-12 11:34:44 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:34:44 --> Controller Class Initialized
INFO - 2024-02-12 11:34:44 --> Form Validation Class Initialized
INFO - 2024-02-12 11:34:44 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:34:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:34:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:34:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:34:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:34:47 --> Config Class Initialized
INFO - 2024-02-12 11:34:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:34:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:34:47 --> Utf8 Class Initialized
INFO - 2024-02-12 11:34:47 --> URI Class Initialized
INFO - 2024-02-12 11:34:47 --> Router Class Initialized
INFO - 2024-02-12 11:34:47 --> Output Class Initialized
INFO - 2024-02-12 11:34:47 --> Security Class Initialized
DEBUG - 2024-02-12 11:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:34:47 --> Input Class Initialized
INFO - 2024-02-12 11:34:47 --> Language Class Initialized
INFO - 2024-02-12 11:34:47 --> Loader Class Initialized
INFO - 2024-02-12 11:34:47 --> Helper loaded: url_helper
INFO - 2024-02-12 11:34:47 --> Helper loaded: file_helper
INFO - 2024-02-12 11:34:47 --> Helper loaded: form_helper
INFO - 2024-02-12 11:34:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:34:47 --> Controller Class Initialized
INFO - 2024-02-12 11:34:47 --> Form Validation Class Initialized
INFO - 2024-02-12 11:34:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:34:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:34:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:34:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:47 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-12 11:34:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:34:47 --> Final output sent to browser
DEBUG - 2024-02-12 11:34:47 --> Total execution time: 0.0332
ERROR - 2024-02-12 11:34:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:34:58 --> Config Class Initialized
INFO - 2024-02-12 11:34:58 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:34:59 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:34:59 --> Utf8 Class Initialized
INFO - 2024-02-12 11:34:59 --> URI Class Initialized
INFO - 2024-02-12 11:34:59 --> Router Class Initialized
INFO - 2024-02-12 11:34:59 --> Output Class Initialized
INFO - 2024-02-12 11:34:59 --> Security Class Initialized
DEBUG - 2024-02-12 11:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:34:59 --> Input Class Initialized
INFO - 2024-02-12 11:34:59 --> Language Class Initialized
INFO - 2024-02-12 11:34:59 --> Loader Class Initialized
INFO - 2024-02-12 11:34:59 --> Helper loaded: url_helper
INFO - 2024-02-12 11:34:59 --> Helper loaded: file_helper
INFO - 2024-02-12 11:34:59 --> Helper loaded: form_helper
INFO - 2024-02-12 11:34:59 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:34:59 --> Controller Class Initialized
INFO - 2024-02-12 11:34:59 --> Form Validation Class Initialized
INFO - 2024-02-12 11:34:59 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:34:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:34:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:34:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-12 11:34:59 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-12 11:34:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:34:59 --> Final output sent to browser
DEBUG - 2024-02-12 11:34:59 --> Total execution time: 0.0343
ERROR - 2024-02-12 11:35:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:35:19 --> Config Class Initialized
INFO - 2024-02-12 11:35:19 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:35:19 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:35:19 --> Utf8 Class Initialized
INFO - 2024-02-12 11:35:19 --> URI Class Initialized
INFO - 2024-02-12 11:35:19 --> Router Class Initialized
INFO - 2024-02-12 11:35:19 --> Output Class Initialized
INFO - 2024-02-12 11:35:19 --> Security Class Initialized
DEBUG - 2024-02-12 11:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:35:19 --> Input Class Initialized
INFO - 2024-02-12 11:35:19 --> Language Class Initialized
INFO - 2024-02-12 11:35:19 --> Loader Class Initialized
INFO - 2024-02-12 11:35:19 --> Helper loaded: url_helper
INFO - 2024-02-12 11:35:19 --> Helper loaded: file_helper
INFO - 2024-02-12 11:35:19 --> Helper loaded: form_helper
INFO - 2024-02-12 11:35:19 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:35:19 --> Controller Class Initialized
INFO - 2024-02-12 11:35:19 --> Form Validation Class Initialized
INFO - 2024-02-12 11:35:19 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:35:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:35:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:35:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:35:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:35:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:35:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:35:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:35:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:35:19 --> Final output sent to browser
DEBUG - 2024-02-12 11:35:19 --> Total execution time: 0.0344
ERROR - 2024-02-12 11:37:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:37:17 --> Config Class Initialized
INFO - 2024-02-12 11:37:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:37:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:37:17 --> Utf8 Class Initialized
INFO - 2024-02-12 11:37:17 --> URI Class Initialized
INFO - 2024-02-12 11:37:17 --> Router Class Initialized
INFO - 2024-02-12 11:37:17 --> Output Class Initialized
INFO - 2024-02-12 11:37:17 --> Security Class Initialized
DEBUG - 2024-02-12 11:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:37:17 --> Input Class Initialized
INFO - 2024-02-12 11:37:17 --> Language Class Initialized
INFO - 2024-02-12 11:37:17 --> Loader Class Initialized
INFO - 2024-02-12 11:37:17 --> Helper loaded: url_helper
INFO - 2024-02-12 11:37:17 --> Helper loaded: file_helper
INFO - 2024-02-12 11:37:17 --> Helper loaded: form_helper
INFO - 2024-02-12 11:37:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:37:17 --> Controller Class Initialized
INFO - 2024-02-12 11:37:17 --> Form Validation Class Initialized
INFO - 2024-02-12 11:37:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:37:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:37:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:37:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:37:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:37:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:37:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:37:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:37:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:37:17 --> Final output sent to browser
DEBUG - 2024-02-12 11:37:17 --> Total execution time: 0.0340
ERROR - 2024-02-12 11:37:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:37:17 --> Config Class Initialized
INFO - 2024-02-12 11:37:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:37:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:37:17 --> Utf8 Class Initialized
INFO - 2024-02-12 11:37:17 --> URI Class Initialized
INFO - 2024-02-12 11:37:17 --> Router Class Initialized
INFO - 2024-02-12 11:37:17 --> Output Class Initialized
INFO - 2024-02-12 11:37:17 --> Security Class Initialized
DEBUG - 2024-02-12 11:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:37:17 --> Input Class Initialized
INFO - 2024-02-12 11:37:17 --> Language Class Initialized
INFO - 2024-02-12 11:37:17 --> Loader Class Initialized
INFO - 2024-02-12 11:37:18 --> Helper loaded: url_helper
INFO - 2024-02-12 11:37:18 --> Helper loaded: file_helper
INFO - 2024-02-12 11:37:18 --> Helper loaded: form_helper
INFO - 2024-02-12 11:37:18 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:37:18 --> Controller Class Initialized
INFO - 2024-02-12 11:37:18 --> Form Validation Class Initialized
INFO - 2024-02-12 11:37:18 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:37:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:37:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:37:18 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:37:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:37:20 --> Config Class Initialized
INFO - 2024-02-12 11:37:20 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:37:20 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:37:20 --> Utf8 Class Initialized
INFO - 2024-02-12 11:37:20 --> URI Class Initialized
INFO - 2024-02-12 11:37:20 --> Router Class Initialized
INFO - 2024-02-12 11:37:20 --> Output Class Initialized
INFO - 2024-02-12 11:37:20 --> Security Class Initialized
DEBUG - 2024-02-12 11:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:37:20 --> Input Class Initialized
INFO - 2024-02-12 11:37:20 --> Language Class Initialized
INFO - 2024-02-12 11:37:20 --> Loader Class Initialized
INFO - 2024-02-12 11:37:20 --> Helper loaded: url_helper
INFO - 2024-02-12 11:37:20 --> Helper loaded: file_helper
INFO - 2024-02-12 11:37:20 --> Helper loaded: form_helper
INFO - 2024-02-12 11:37:20 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:37:20 --> Controller Class Initialized
INFO - 2024-02-12 11:37:20 --> Form Validation Class Initialized
INFO - 2024-02-12 11:37:20 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:37:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:37:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:37:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:20 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
INFO - 2024-02-12 11:37:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:37:20 --> Final output sent to browser
DEBUG - 2024-02-12 11:37:20 --> Total execution time: 0.0346
ERROR - 2024-02-12 11:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:37:46 --> Config Class Initialized
INFO - 2024-02-12 11:37:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:37:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:37:46 --> Utf8 Class Initialized
INFO - 2024-02-12 11:37:46 --> URI Class Initialized
INFO - 2024-02-12 11:37:46 --> Router Class Initialized
INFO - 2024-02-12 11:37:46 --> Output Class Initialized
INFO - 2024-02-12 11:37:46 --> Security Class Initialized
DEBUG - 2024-02-12 11:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:37:46 --> Input Class Initialized
INFO - 2024-02-12 11:37:46 --> Language Class Initialized
INFO - 2024-02-12 11:37:46 --> Loader Class Initialized
INFO - 2024-02-12 11:37:46 --> Helper loaded: url_helper
INFO - 2024-02-12 11:37:46 --> Helper loaded: file_helper
INFO - 2024-02-12 11:37:46 --> Helper loaded: form_helper
INFO - 2024-02-12 11:37:46 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:37:46 --> Controller Class Initialized
INFO - 2024-02-12 11:37:46 --> Form Validation Class Initialized
INFO - 2024-02-12 11:37:46 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:37:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:37:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:37:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:37:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:37:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:37:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:37:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:37:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:37:46 --> Final output sent to browser
DEBUG - 2024-02-12 11:37:46 --> Total execution time: 0.0376
ERROR - 2024-02-12 11:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:37:47 --> Config Class Initialized
INFO - 2024-02-12 11:37:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:37:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:37:47 --> Utf8 Class Initialized
INFO - 2024-02-12 11:37:47 --> URI Class Initialized
INFO - 2024-02-12 11:37:47 --> Router Class Initialized
INFO - 2024-02-12 11:37:47 --> Output Class Initialized
INFO - 2024-02-12 11:37:47 --> Security Class Initialized
DEBUG - 2024-02-12 11:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:37:47 --> Input Class Initialized
INFO - 2024-02-12 11:37:47 --> Language Class Initialized
INFO - 2024-02-12 11:37:47 --> Loader Class Initialized
INFO - 2024-02-12 11:37:47 --> Helper loaded: url_helper
INFO - 2024-02-12 11:37:47 --> Helper loaded: file_helper
INFO - 2024-02-12 11:37:47 --> Helper loaded: form_helper
INFO - 2024-02-12 11:37:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:37:47 --> Controller Class Initialized
INFO - 2024-02-12 11:37:47 --> Form Validation Class Initialized
INFO - 2024-02-12 11:37:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:37:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:37:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:37:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:37:49 --> Config Class Initialized
INFO - 2024-02-12 11:37:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:37:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:37:49 --> Utf8 Class Initialized
INFO - 2024-02-12 11:37:49 --> URI Class Initialized
INFO - 2024-02-12 11:37:49 --> Router Class Initialized
INFO - 2024-02-12 11:37:49 --> Output Class Initialized
INFO - 2024-02-12 11:37:49 --> Security Class Initialized
DEBUG - 2024-02-12 11:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:37:49 --> Input Class Initialized
INFO - 2024-02-12 11:37:49 --> Language Class Initialized
INFO - 2024-02-12 11:37:49 --> Loader Class Initialized
INFO - 2024-02-12 11:37:49 --> Helper loaded: url_helper
INFO - 2024-02-12 11:37:49 --> Helper loaded: file_helper
INFO - 2024-02-12 11:37:49 --> Helper loaded: form_helper
INFO - 2024-02-12 11:37:49 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:37:49 --> Controller Class Initialized
INFO - 2024-02-12 11:37:49 --> Form Validation Class Initialized
INFO - 2024-02-12 11:37:49 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:37:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:37:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:37:49 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
ERROR - 2024-02-12 11:37:49 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 37
INFO - 2024-02-12 11:37:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:37:49 --> Final output sent to browser
DEBUG - 2024-02-12 11:37:49 --> Total execution time: 0.0375
ERROR - 2024-02-12 11:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:38:24 --> Config Class Initialized
INFO - 2024-02-12 11:38:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:38:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:38:24 --> Utf8 Class Initialized
INFO - 2024-02-12 11:38:24 --> URI Class Initialized
INFO - 2024-02-12 11:38:24 --> Router Class Initialized
INFO - 2024-02-12 11:38:24 --> Output Class Initialized
INFO - 2024-02-12 11:38:24 --> Security Class Initialized
DEBUG - 2024-02-12 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:38:24 --> Input Class Initialized
INFO - 2024-02-12 11:38:24 --> Language Class Initialized
INFO - 2024-02-12 11:38:24 --> Loader Class Initialized
INFO - 2024-02-12 11:38:24 --> Helper loaded: url_helper
INFO - 2024-02-12 11:38:24 --> Helper loaded: file_helper
INFO - 2024-02-12 11:38:24 --> Helper loaded: form_helper
INFO - 2024-02-12 11:38:24 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:38:24 --> Controller Class Initialized
INFO - 2024-02-12 11:38:24 --> Form Validation Class Initialized
INFO - 2024-02-12 11:38:24 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:38:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:38:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:38:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:38:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:38:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:38:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:38:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:38:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:38:24 --> Final output sent to browser
DEBUG - 2024-02-12 11:38:24 --> Total execution time: 0.0334
ERROR - 2024-02-12 11:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:38:24 --> Config Class Initialized
INFO - 2024-02-12 11:38:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:38:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:38:24 --> Utf8 Class Initialized
INFO - 2024-02-12 11:38:24 --> URI Class Initialized
INFO - 2024-02-12 11:38:24 --> Router Class Initialized
INFO - 2024-02-12 11:38:24 --> Output Class Initialized
INFO - 2024-02-12 11:38:24 --> Security Class Initialized
DEBUG - 2024-02-12 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:38:24 --> Input Class Initialized
INFO - 2024-02-12 11:38:24 --> Language Class Initialized
INFO - 2024-02-12 11:38:24 --> Loader Class Initialized
INFO - 2024-02-12 11:38:24 --> Helper loaded: url_helper
INFO - 2024-02-12 11:38:24 --> Helper loaded: file_helper
INFO - 2024-02-12 11:38:24 --> Helper loaded: form_helper
INFO - 2024-02-12 11:38:24 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:38:24 --> Controller Class Initialized
INFO - 2024-02-12 11:38:24 --> Form Validation Class Initialized
INFO - 2024-02-12 11:38:24 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:38:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:38:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:38:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:38:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:38:26 --> Config Class Initialized
INFO - 2024-02-12 11:38:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:38:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:38:26 --> Utf8 Class Initialized
INFO - 2024-02-12 11:38:26 --> URI Class Initialized
INFO - 2024-02-12 11:38:26 --> Router Class Initialized
INFO - 2024-02-12 11:38:26 --> Output Class Initialized
INFO - 2024-02-12 11:38:26 --> Security Class Initialized
DEBUG - 2024-02-12 11:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:38:26 --> Input Class Initialized
INFO - 2024-02-12 11:38:26 --> Language Class Initialized
INFO - 2024-02-12 11:38:26 --> Loader Class Initialized
INFO - 2024-02-12 11:38:26 --> Helper loaded: url_helper
INFO - 2024-02-12 11:38:26 --> Helper loaded: file_helper
INFO - 2024-02-12 11:38:26 --> Helper loaded: form_helper
INFO - 2024-02-12 11:38:26 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:38:26 --> Controller Class Initialized
INFO - 2024-02-12 11:38:26 --> Form Validation Class Initialized
INFO - 2024-02-12 11:38:26 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:38:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:38:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:38:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:38:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:38:26 --> Final output sent to browser
DEBUG - 2024-02-12 11:38:26 --> Total execution time: 0.0352
ERROR - 2024-02-12 11:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:40:39 --> Config Class Initialized
INFO - 2024-02-12 11:40:39 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:40:39 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:40:39 --> Utf8 Class Initialized
INFO - 2024-02-12 11:40:39 --> URI Class Initialized
INFO - 2024-02-12 11:40:39 --> Router Class Initialized
INFO - 2024-02-12 11:40:39 --> Output Class Initialized
INFO - 2024-02-12 11:40:39 --> Security Class Initialized
DEBUG - 2024-02-12 11:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:40:39 --> Input Class Initialized
INFO - 2024-02-12 11:40:39 --> Language Class Initialized
INFO - 2024-02-12 11:40:39 --> Loader Class Initialized
INFO - 2024-02-12 11:40:39 --> Helper loaded: url_helper
INFO - 2024-02-12 11:40:39 --> Helper loaded: file_helper
INFO - 2024-02-12 11:40:39 --> Helper loaded: form_helper
INFO - 2024-02-12 11:40:39 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:40:39 --> Controller Class Initialized
INFO - 2024-02-12 11:40:39 --> Form Validation Class Initialized
INFO - 2024-02-12 11:40:39 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:40:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:40:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:40:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:40:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:40:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:40:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:40:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:40:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:40:39 --> Final output sent to browser
DEBUG - 2024-02-12 11:40:39 --> Total execution time: 0.0404
ERROR - 2024-02-12 11:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:40:39 --> Config Class Initialized
INFO - 2024-02-12 11:40:39 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:40:39 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:40:39 --> Utf8 Class Initialized
INFO - 2024-02-12 11:40:39 --> URI Class Initialized
INFO - 2024-02-12 11:40:39 --> Router Class Initialized
INFO - 2024-02-12 11:40:39 --> Output Class Initialized
INFO - 2024-02-12 11:40:39 --> Security Class Initialized
DEBUG - 2024-02-12 11:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:40:39 --> Input Class Initialized
INFO - 2024-02-12 11:40:39 --> Language Class Initialized
INFO - 2024-02-12 11:40:39 --> Loader Class Initialized
INFO - 2024-02-12 11:40:39 --> Helper loaded: url_helper
INFO - 2024-02-12 11:40:39 --> Helper loaded: file_helper
INFO - 2024-02-12 11:40:39 --> Helper loaded: form_helper
INFO - 2024-02-12 11:40:39 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:40:39 --> Controller Class Initialized
INFO - 2024-02-12 11:40:39 --> Form Validation Class Initialized
INFO - 2024-02-12 11:40:39 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:40:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:40:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:40:39 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:40:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:40:42 --> Config Class Initialized
INFO - 2024-02-12 11:40:42 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:40:42 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:40:42 --> Utf8 Class Initialized
INFO - 2024-02-12 11:40:42 --> URI Class Initialized
INFO - 2024-02-12 11:40:42 --> Router Class Initialized
INFO - 2024-02-12 11:40:42 --> Output Class Initialized
INFO - 2024-02-12 11:40:42 --> Security Class Initialized
DEBUG - 2024-02-12 11:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:40:42 --> Input Class Initialized
INFO - 2024-02-12 11:40:42 --> Language Class Initialized
INFO - 2024-02-12 11:40:42 --> Loader Class Initialized
INFO - 2024-02-12 11:40:42 --> Helper loaded: url_helper
INFO - 2024-02-12 11:40:42 --> Helper loaded: file_helper
INFO - 2024-02-12 11:40:42 --> Helper loaded: form_helper
INFO - 2024-02-12 11:40:42 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:40:42 --> Controller Class Initialized
INFO - 2024-02-12 11:40:42 --> Form Validation Class Initialized
INFO - 2024-02-12 11:40:42 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:40:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:40:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:40:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:40:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:40:42 --> Final output sent to browser
DEBUG - 2024-02-12 11:40:42 --> Total execution time: 0.0267
ERROR - 2024-02-12 11:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:53:40 --> Config Class Initialized
INFO - 2024-02-12 11:53:40 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:53:40 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:53:40 --> Utf8 Class Initialized
INFO - 2024-02-12 11:53:40 --> URI Class Initialized
INFO - 2024-02-12 11:53:40 --> Router Class Initialized
INFO - 2024-02-12 11:53:40 --> Output Class Initialized
INFO - 2024-02-12 11:53:40 --> Security Class Initialized
DEBUG - 2024-02-12 11:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:53:40 --> Input Class Initialized
INFO - 2024-02-12 11:53:40 --> Language Class Initialized
INFO - 2024-02-12 11:53:40 --> Loader Class Initialized
INFO - 2024-02-12 11:53:40 --> Helper loaded: url_helper
INFO - 2024-02-12 11:53:40 --> Helper loaded: file_helper
INFO - 2024-02-12 11:53:40 --> Helper loaded: form_helper
INFO - 2024-02-12 11:53:40 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:53:40 --> Controller Class Initialized
INFO - 2024-02-12 11:53:40 --> Form Validation Class Initialized
INFO - 2024-02-12 11:53:40 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:53:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:53:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:53:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:53:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:53:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:53:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:53:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:53:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:53:40 --> Final output sent to browser
DEBUG - 2024-02-12 11:53:40 --> Total execution time: 0.0407
ERROR - 2024-02-12 11:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:53:41 --> Config Class Initialized
INFO - 2024-02-12 11:53:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:53:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:53:41 --> Utf8 Class Initialized
INFO - 2024-02-12 11:53:41 --> URI Class Initialized
INFO - 2024-02-12 11:53:41 --> Router Class Initialized
INFO - 2024-02-12 11:53:41 --> Output Class Initialized
INFO - 2024-02-12 11:53:41 --> Security Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:53:41 --> Input Class Initialized
INFO - 2024-02-12 11:53:41 --> Language Class Initialized
INFO - 2024-02-12 11:53:41 --> Loader Class Initialized
INFO - 2024-02-12 11:53:41 --> Helper loaded: url_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: file_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: form_helper
INFO - 2024-02-12 11:53:41 --> Database Driver Class Initialized
ERROR - 2024-02-12 11:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:53:41 --> Config Class Initialized
INFO - 2024-02-12 11:53:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:53:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:53:41 --> Utf8 Class Initialized
INFO - 2024-02-12 11:53:41 --> URI Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:53:41 --> Router Class Initialized
INFO - 2024-02-12 11:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:53:41 --> Controller Class Initialized
INFO - 2024-02-12 11:53:41 --> Output Class Initialized
INFO - 2024-02-12 11:53:41 --> Form Validation Class Initialized
INFO - 2024-02-12 11:53:41 --> Security Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "UserMasterModel" initialized
DEBUG - 2024-02-12 11:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:53:41 --> Input Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:53:41 --> Language Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Loader Class Initialized
INFO - 2024-02-12 11:53:41 --> Helper loaded: url_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: file_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: form_helper
INFO - 2024-02-12 11:53:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:53:41 --> Controller Class Initialized
INFO - 2024-02-12 11:53:41 --> Form Validation Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:53:41 --> Config Class Initialized
INFO - 2024-02-12 11:53:41 --> Hooks Class Initialized
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:53:41 --> Final output sent to browser
DEBUG - 2024-02-12 11:53:41 --> Total execution time: 0.0387
DEBUG - 2024-02-12 11:53:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:53:41 --> Utf8 Class Initialized
INFO - 2024-02-12 11:53:41 --> URI Class Initialized
INFO - 2024-02-12 11:53:41 --> Router Class Initialized
INFO - 2024-02-12 11:53:41 --> Output Class Initialized
INFO - 2024-02-12 11:53:41 --> Security Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:53:41 --> Input Class Initialized
INFO - 2024-02-12 11:53:41 --> Language Class Initialized
INFO - 2024-02-12 11:53:41 --> Loader Class Initialized
INFO - 2024-02-12 11:53:41 --> Helper loaded: url_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: file_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: form_helper
ERROR - 2024-02-12 11:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:53:41 --> Config Class Initialized
INFO - 2024-02-12 11:53:41 --> Hooks Class Initialized
INFO - 2024-02-12 11:53:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:53:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:53:41 --> Utf8 Class Initialized
INFO - 2024-02-12 11:53:41 --> URI Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:53:41 --> Router Class Initialized
INFO - 2024-02-12 11:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:53:41 --> Controller Class Initialized
INFO - 2024-02-12 11:53:41 --> Output Class Initialized
INFO - 2024-02-12 11:53:41 --> Form Validation Class Initialized
INFO - 2024-02-12 11:53:41 --> Security Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemCategoryModel" initialized
DEBUG - 2024-02-12 11:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:53:41 --> Input Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Language Class Initialized
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:53:41 --> Final output sent to browser
DEBUG - 2024-02-12 11:53:41 --> Total execution time: 0.0459
INFO - 2024-02-12 11:53:41 --> Loader Class Initialized
INFO - 2024-02-12 11:53:41 --> Helper loaded: url_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: file_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: form_helper
INFO - 2024-02-12 11:53:41 --> Database Driver Class Initialized
ERROR - 2024-02-12 11:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2024-02-12 11:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:53:41 --> Config Class Initialized
INFO - 2024-02-12 11:53:41 --> Controller Class Initialized
INFO - 2024-02-12 11:53:41 --> Hooks Class Initialized
INFO - 2024-02-12 11:53:41 --> Form Validation Class Initialized
DEBUG - 2024-02-12 11:53:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:53:41 --> Utf8 Class Initialized
INFO - 2024-02-12 11:53:41 --> URI Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Router Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Output Class Initialized
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:53:41 --> Security Class Initialized
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
DEBUG - 2024-02-12 11:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:53:41 --> Input Class Initialized
INFO - 2024-02-12 11:53:41 --> Final output sent to browser
DEBUG - 2024-02-12 11:53:41 --> Total execution time: 0.0440
INFO - 2024-02-12 11:53:41 --> Language Class Initialized
INFO - 2024-02-12 11:53:41 --> Loader Class Initialized
INFO - 2024-02-12 11:53:41 --> Helper loaded: url_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: file_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: form_helper
INFO - 2024-02-12 11:53:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:53:41 --> Controller Class Initialized
INFO - 2024-02-12 11:53:41 --> Form Validation Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:53:41 --> Final output sent to browser
DEBUG - 2024-02-12 11:53:41 --> Total execution time: 0.0501
ERROR - 2024-02-12 11:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:53:41 --> Config Class Initialized
INFO - 2024-02-12 11:53:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:53:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:53:41 --> Utf8 Class Initialized
INFO - 2024-02-12 11:53:41 --> URI Class Initialized
INFO - 2024-02-12 11:53:41 --> Router Class Initialized
INFO - 2024-02-12 11:53:41 --> Output Class Initialized
INFO - 2024-02-12 11:53:41 --> Security Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:53:41 --> Input Class Initialized
INFO - 2024-02-12 11:53:41 --> Language Class Initialized
INFO - 2024-02-12 11:53:41 --> Loader Class Initialized
INFO - 2024-02-12 11:53:41 --> Helper loaded: url_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: file_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: form_helper
ERROR - 2024-02-12 11:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:53:41 --> Database Driver Class Initialized
INFO - 2024-02-12 11:53:41 --> Config Class Initialized
INFO - 2024-02-12 11:53:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:53:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:53:41 --> Utf8 Class Initialized
INFO - 2024-02-12 11:53:41 --> URI Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:53:41 --> Router Class Initialized
INFO - 2024-02-12 11:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:53:41 --> Controller Class Initialized
INFO - 2024-02-12 11:53:41 --> Output Class Initialized
INFO - 2024-02-12 11:53:41 --> Form Validation Class Initialized
INFO - 2024-02-12 11:53:41 --> Security Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:53:41 --> Input Class Initialized
INFO - 2024-02-12 11:53:41 --> Language Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:53:41 --> Loader Class Initialized
INFO - 2024-02-12 11:53:41 --> Helper loaded: url_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: file_helper
INFO - 2024-02-12 11:53:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Helper loaded: form_helper
INFO - 2024-02-12 11:53:41 --> Database Driver Class Initialized
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:53:41 --> Final output sent to browser
DEBUG - 2024-02-12 11:53:41 --> Total execution time: 0.0497
DEBUG - 2024-02-12 11:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:53:41 --> Controller Class Initialized
INFO - 2024-02-12 11:53:41 --> Form Validation Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:53:41 --> Config Class Initialized
INFO - 2024-02-12 11:53:41 --> Hooks Class Initialized
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:53:41 --> Final output sent to browser
DEBUG - 2024-02-12 11:53:41 --> Total execution time: 0.0517
DEBUG - 2024-02-12 11:53:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:53:41 --> Utf8 Class Initialized
INFO - 2024-02-12 11:53:41 --> URI Class Initialized
INFO - 2024-02-12 11:53:41 --> Router Class Initialized
INFO - 2024-02-12 11:53:41 --> Output Class Initialized
INFO - 2024-02-12 11:53:41 --> Security Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:53:41 --> Input Class Initialized
INFO - 2024-02-12 11:53:41 --> Language Class Initialized
INFO - 2024-02-12 11:53:41 --> Loader Class Initialized
INFO - 2024-02-12 11:53:41 --> Helper loaded: url_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: file_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: form_helper
INFO - 2024-02-12 11:53:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:53:41 --> Controller Class Initialized
INFO - 2024-02-12 11:53:41 --> Form Validation Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:53:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:53:41 --> Final output sent to browser
DEBUG - 2024-02-12 11:53:41 --> Total execution time: 0.0720
ERROR - 2024-02-12 11:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:53:41 --> Config Class Initialized
INFO - 2024-02-12 11:53:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:53:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:53:41 --> Utf8 Class Initialized
INFO - 2024-02-12 11:53:41 --> URI Class Initialized
INFO - 2024-02-12 11:53:41 --> Router Class Initialized
INFO - 2024-02-12 11:53:41 --> Output Class Initialized
INFO - 2024-02-12 11:53:41 --> Security Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:53:41 --> Input Class Initialized
INFO - 2024-02-12 11:53:41 --> Language Class Initialized
INFO - 2024-02-12 11:53:41 --> Loader Class Initialized
INFO - 2024-02-12 11:53:41 --> Helper loaded: url_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: file_helper
INFO - 2024-02-12 11:53:41 --> Helper loaded: form_helper
INFO - 2024-02-12 11:53:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:53:41 --> Controller Class Initialized
INFO - 2024-02-12 11:53:41 --> Form Validation Class Initialized
INFO - 2024-02-12 11:53:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:53:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:53:44 --> Config Class Initialized
INFO - 2024-02-12 11:53:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:53:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:53:44 --> Utf8 Class Initialized
INFO - 2024-02-12 11:53:44 --> URI Class Initialized
INFO - 2024-02-12 11:53:44 --> Router Class Initialized
INFO - 2024-02-12 11:53:44 --> Output Class Initialized
INFO - 2024-02-12 11:53:44 --> Security Class Initialized
DEBUG - 2024-02-12 11:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:53:44 --> Input Class Initialized
INFO - 2024-02-12 11:53:44 --> Language Class Initialized
INFO - 2024-02-12 11:53:44 --> Loader Class Initialized
INFO - 2024-02-12 11:53:44 --> Helper loaded: url_helper
INFO - 2024-02-12 11:53:44 --> Helper loaded: file_helper
INFO - 2024-02-12 11:53:44 --> Helper loaded: form_helper
INFO - 2024-02-12 11:53:44 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:53:44 --> Controller Class Initialized
INFO - 2024-02-12 11:53:44 --> Form Validation Class Initialized
INFO - 2024-02-12 11:53:44 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:53:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:53:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:53:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:53:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:53:44 --> Final output sent to browser
DEBUG - 2024-02-12 11:53:44 --> Total execution time: 0.0348
ERROR - 2024-02-12 11:56:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:56:02 --> Config Class Initialized
INFO - 2024-02-12 11:56:02 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:56:02 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:56:02 --> Utf8 Class Initialized
INFO - 2024-02-12 11:56:02 --> URI Class Initialized
INFO - 2024-02-12 11:56:02 --> Router Class Initialized
INFO - 2024-02-12 11:56:02 --> Output Class Initialized
INFO - 2024-02-12 11:56:02 --> Security Class Initialized
DEBUG - 2024-02-12 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:56:02 --> Input Class Initialized
INFO - 2024-02-12 11:56:02 --> Language Class Initialized
INFO - 2024-02-12 11:56:02 --> Loader Class Initialized
INFO - 2024-02-12 11:56:02 --> Helper loaded: url_helper
INFO - 2024-02-12 11:56:02 --> Helper loaded: file_helper
INFO - 2024-02-12 11:56:02 --> Helper loaded: form_helper
INFO - 2024-02-12 11:56:02 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:56:02 --> Controller Class Initialized
INFO - 2024-02-12 11:56:02 --> Form Validation Class Initialized
INFO - 2024-02-12 11:56:02 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:56:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:56:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:56:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:56:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:56:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:56:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:56:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:56:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:56:02 --> Final output sent to browser
DEBUG - 2024-02-12 11:56:02 --> Total execution time: 0.0305
ERROR - 2024-02-12 11:56:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:56:02 --> Config Class Initialized
INFO - 2024-02-12 11:56:02 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:56:02 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:56:02 --> Utf8 Class Initialized
INFO - 2024-02-12 11:56:02 --> URI Class Initialized
INFO - 2024-02-12 11:56:02 --> Router Class Initialized
INFO - 2024-02-12 11:56:02 --> Output Class Initialized
INFO - 2024-02-12 11:56:02 --> Security Class Initialized
DEBUG - 2024-02-12 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:56:02 --> Input Class Initialized
INFO - 2024-02-12 11:56:02 --> Language Class Initialized
INFO - 2024-02-12 11:56:02 --> Loader Class Initialized
INFO - 2024-02-12 11:56:02 --> Helper loaded: url_helper
INFO - 2024-02-12 11:56:02 --> Helper loaded: file_helper
INFO - 2024-02-12 11:56:02 --> Helper loaded: form_helper
INFO - 2024-02-12 11:56:02 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:56:02 --> Controller Class Initialized
INFO - 2024-02-12 11:56:02 --> Form Validation Class Initialized
INFO - 2024-02-12 11:56:02 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:56:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:56:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:56:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:56:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:56:04 --> Config Class Initialized
INFO - 2024-02-12 11:56:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:56:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:56:04 --> Utf8 Class Initialized
INFO - 2024-02-12 11:56:04 --> URI Class Initialized
INFO - 2024-02-12 11:56:04 --> Router Class Initialized
INFO - 2024-02-12 11:56:04 --> Output Class Initialized
INFO - 2024-02-12 11:56:04 --> Security Class Initialized
DEBUG - 2024-02-12 11:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:56:04 --> Input Class Initialized
INFO - 2024-02-12 11:56:04 --> Language Class Initialized
INFO - 2024-02-12 11:56:04 --> Loader Class Initialized
INFO - 2024-02-12 11:56:04 --> Helper loaded: url_helper
INFO - 2024-02-12 11:56:04 --> Helper loaded: file_helper
INFO - 2024-02-12 11:56:04 --> Helper loaded: form_helper
INFO - 2024-02-12 11:56:04 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:56:04 --> Controller Class Initialized
INFO - 2024-02-12 11:56:04 --> Form Validation Class Initialized
INFO - 2024-02-12 11:56:04 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:56:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:56:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:56:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:56:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:56:04 --> Final output sent to browser
DEBUG - 2024-02-12 11:56:04 --> Total execution time: 0.0193
ERROR - 2024-02-12 11:59:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:59:47 --> Config Class Initialized
INFO - 2024-02-12 11:59:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:59:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:59:47 --> Utf8 Class Initialized
INFO - 2024-02-12 11:59:47 --> URI Class Initialized
INFO - 2024-02-12 11:59:47 --> Router Class Initialized
INFO - 2024-02-12 11:59:47 --> Output Class Initialized
INFO - 2024-02-12 11:59:47 --> Security Class Initialized
DEBUG - 2024-02-12 11:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:59:47 --> Input Class Initialized
INFO - 2024-02-12 11:59:47 --> Language Class Initialized
INFO - 2024-02-12 11:59:47 --> Loader Class Initialized
INFO - 2024-02-12 11:59:47 --> Helper loaded: url_helper
INFO - 2024-02-12 11:59:47 --> Helper loaded: file_helper
INFO - 2024-02-12 11:59:47 --> Helper loaded: form_helper
INFO - 2024-02-12 11:59:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:59:47 --> Controller Class Initialized
INFO - 2024-02-12 11:59:47 --> Form Validation Class Initialized
INFO - 2024-02-12 11:59:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:59:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:59:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:59:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:59:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 11:59:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 11:59:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 11:59:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 11:59:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 11:59:47 --> Final output sent to browser
DEBUG - 2024-02-12 11:59:47 --> Total execution time: 0.0346
ERROR - 2024-02-12 11:59:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:59:48 --> Config Class Initialized
INFO - 2024-02-12 11:59:48 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:59:48 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:59:48 --> Utf8 Class Initialized
INFO - 2024-02-12 11:59:48 --> URI Class Initialized
INFO - 2024-02-12 11:59:48 --> Router Class Initialized
INFO - 2024-02-12 11:59:48 --> Output Class Initialized
INFO - 2024-02-12 11:59:48 --> Security Class Initialized
DEBUG - 2024-02-12 11:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:59:48 --> Input Class Initialized
INFO - 2024-02-12 11:59:48 --> Language Class Initialized
INFO - 2024-02-12 11:59:48 --> Loader Class Initialized
INFO - 2024-02-12 11:59:48 --> Helper loaded: url_helper
INFO - 2024-02-12 11:59:48 --> Helper loaded: file_helper
INFO - 2024-02-12 11:59:48 --> Helper loaded: form_helper
INFO - 2024-02-12 11:59:48 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:59:48 --> Controller Class Initialized
INFO - 2024-02-12 11:59:48 --> Form Validation Class Initialized
INFO - 2024-02-12 11:59:48 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:59:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:59:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:59:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 11:59:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 11:59:50 --> Config Class Initialized
INFO - 2024-02-12 11:59:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:59:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:59:50 --> Utf8 Class Initialized
INFO - 2024-02-12 11:59:50 --> URI Class Initialized
INFO - 2024-02-12 11:59:50 --> Router Class Initialized
INFO - 2024-02-12 11:59:50 --> Output Class Initialized
INFO - 2024-02-12 11:59:50 --> Security Class Initialized
DEBUG - 2024-02-12 11:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:59:50 --> Input Class Initialized
INFO - 2024-02-12 11:59:50 --> Language Class Initialized
INFO - 2024-02-12 11:59:50 --> Loader Class Initialized
INFO - 2024-02-12 11:59:50 --> Helper loaded: url_helper
INFO - 2024-02-12 11:59:50 --> Helper loaded: file_helper
INFO - 2024-02-12 11:59:50 --> Helper loaded: form_helper
INFO - 2024-02-12 11:59:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 11:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 11:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:59:50 --> Controller Class Initialized
INFO - 2024-02-12 11:59:50 --> Form Validation Class Initialized
INFO - 2024-02-12 11:59:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 11:59:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 11:59:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 11:59:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 11:59:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 11:59:50 --> Final output sent to browser
DEBUG - 2024-02-12 11:59:50 --> Total execution time: 0.0359
ERROR - 2024-02-12 12:08:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:08:45 --> Config Class Initialized
INFO - 2024-02-12 12:08:45 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:08:45 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:08:45 --> Utf8 Class Initialized
INFO - 2024-02-12 12:08:45 --> URI Class Initialized
INFO - 2024-02-12 12:08:45 --> Router Class Initialized
INFO - 2024-02-12 12:08:45 --> Output Class Initialized
INFO - 2024-02-12 12:08:45 --> Security Class Initialized
DEBUG - 2024-02-12 12:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:08:46 --> Input Class Initialized
INFO - 2024-02-12 12:08:46 --> Language Class Initialized
INFO - 2024-02-12 12:08:46 --> Loader Class Initialized
INFO - 2024-02-12 12:08:46 --> Helper loaded: url_helper
INFO - 2024-02-12 12:08:46 --> Helper loaded: file_helper
INFO - 2024-02-12 12:08:46 --> Helper loaded: form_helper
INFO - 2024-02-12 12:08:46 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:08:46 --> Controller Class Initialized
INFO - 2024-02-12 12:08:46 --> Form Validation Class Initialized
INFO - 2024-02-12 12:08:46 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:08:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:08:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:08:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:08:46 --> Final output sent to browser
DEBUG - 2024-02-12 12:08:46 --> Total execution time: 0.0446
ERROR - 2024-02-12 12:08:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:08:46 --> Config Class Initialized
INFO - 2024-02-12 12:08:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:08:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:08:46 --> Utf8 Class Initialized
INFO - 2024-02-12 12:08:46 --> URI Class Initialized
INFO - 2024-02-12 12:08:46 --> Router Class Initialized
INFO - 2024-02-12 12:08:46 --> Output Class Initialized
INFO - 2024-02-12 12:08:46 --> Security Class Initialized
DEBUG - 2024-02-12 12:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:08:46 --> Input Class Initialized
INFO - 2024-02-12 12:08:46 --> Language Class Initialized
INFO - 2024-02-12 12:08:46 --> Loader Class Initialized
INFO - 2024-02-12 12:08:46 --> Helper loaded: url_helper
INFO - 2024-02-12 12:08:46 --> Helper loaded: file_helper
INFO - 2024-02-12 12:08:46 --> Helper loaded: form_helper
INFO - 2024-02-12 12:08:46 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:08:46 --> Controller Class Initialized
INFO - 2024-02-12 12:08:46 --> Form Validation Class Initialized
INFO - 2024-02-12 12:08:46 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:08:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:08:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:08:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:08:46 --> Final output sent to browser
DEBUG - 2024-02-12 12:08:46 --> Total execution time: 0.0264
ERROR - 2024-02-12 12:08:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:08:46 --> Config Class Initialized
INFO - 2024-02-12 12:08:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:08:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:08:46 --> Utf8 Class Initialized
INFO - 2024-02-12 12:08:46 --> URI Class Initialized
INFO - 2024-02-12 12:08:46 --> Router Class Initialized
INFO - 2024-02-12 12:08:46 --> Output Class Initialized
INFO - 2024-02-12 12:08:46 --> Security Class Initialized
DEBUG - 2024-02-12 12:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:08:46 --> Input Class Initialized
INFO - 2024-02-12 12:08:46 --> Language Class Initialized
INFO - 2024-02-12 12:08:46 --> Loader Class Initialized
INFO - 2024-02-12 12:08:46 --> Helper loaded: url_helper
INFO - 2024-02-12 12:08:46 --> Helper loaded: file_helper
INFO - 2024-02-12 12:08:46 --> Helper loaded: form_helper
INFO - 2024-02-12 12:08:46 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:08:46 --> Controller Class Initialized
INFO - 2024-02-12 12:08:46 --> Form Validation Class Initialized
INFO - 2024-02-12 12:08:46 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:08:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:08:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:08:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:08:46 --> Final output sent to browser
DEBUG - 2024-02-12 12:08:46 --> Total execution time: 0.0265
ERROR - 2024-02-12 12:08:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:08:46 --> Config Class Initialized
INFO - 2024-02-12 12:08:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:08:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:08:46 --> Utf8 Class Initialized
INFO - 2024-02-12 12:08:46 --> URI Class Initialized
INFO - 2024-02-12 12:08:46 --> Router Class Initialized
INFO - 2024-02-12 12:08:46 --> Output Class Initialized
INFO - 2024-02-12 12:08:46 --> Security Class Initialized
DEBUG - 2024-02-12 12:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:08:46 --> Input Class Initialized
INFO - 2024-02-12 12:08:46 --> Language Class Initialized
INFO - 2024-02-12 12:08:46 --> Loader Class Initialized
INFO - 2024-02-12 12:08:46 --> Helper loaded: url_helper
INFO - 2024-02-12 12:08:46 --> Helper loaded: file_helper
INFO - 2024-02-12 12:08:46 --> Helper loaded: form_helper
INFO - 2024-02-12 12:08:46 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:08:46 --> Controller Class Initialized
INFO - 2024-02-12 12:08:46 --> Form Validation Class Initialized
INFO - 2024-02-12 12:08:46 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:08:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:08:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:08:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:08:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:08:46 --> Final output sent to browser
DEBUG - 2024-02-12 12:08:46 --> Total execution time: 0.0315
ERROR - 2024-02-12 12:08:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:08:47 --> Config Class Initialized
INFO - 2024-02-12 12:08:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:08:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:08:47 --> Utf8 Class Initialized
INFO - 2024-02-12 12:08:47 --> URI Class Initialized
INFO - 2024-02-12 12:08:47 --> Router Class Initialized
INFO - 2024-02-12 12:08:47 --> Output Class Initialized
INFO - 2024-02-12 12:08:47 --> Security Class Initialized
DEBUG - 2024-02-12 12:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:08:47 --> Input Class Initialized
INFO - 2024-02-12 12:08:47 --> Language Class Initialized
INFO - 2024-02-12 12:08:47 --> Loader Class Initialized
INFO - 2024-02-12 12:08:47 --> Helper loaded: url_helper
INFO - 2024-02-12 12:08:47 --> Helper loaded: file_helper
INFO - 2024-02-12 12:08:47 --> Helper loaded: form_helper
INFO - 2024-02-12 12:08:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:08:47 --> Controller Class Initialized
INFO - 2024-02-12 12:08:47 --> Form Validation Class Initialized
INFO - 2024-02-12 12:08:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:08:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:08:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:08:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:08:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:08:50 --> Config Class Initialized
INFO - 2024-02-12 12:08:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:08:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:08:50 --> Utf8 Class Initialized
INFO - 2024-02-12 12:08:50 --> URI Class Initialized
INFO - 2024-02-12 12:08:50 --> Router Class Initialized
INFO - 2024-02-12 12:08:50 --> Output Class Initialized
INFO - 2024-02-12 12:08:50 --> Security Class Initialized
DEBUG - 2024-02-12 12:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:08:50 --> Input Class Initialized
INFO - 2024-02-12 12:08:50 --> Language Class Initialized
INFO - 2024-02-12 12:08:50 --> Loader Class Initialized
INFO - 2024-02-12 12:08:50 --> Helper loaded: url_helper
INFO - 2024-02-12 12:08:50 --> Helper loaded: file_helper
INFO - 2024-02-12 12:08:50 --> Helper loaded: form_helper
INFO - 2024-02-12 12:08:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:08:50 --> Controller Class Initialized
INFO - 2024-02-12 12:08:50 --> Form Validation Class Initialized
INFO - 2024-02-12 12:08:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:08:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:08:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:08:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:08:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:08:50 --> Final output sent to browser
DEBUG - 2024-02-12 12:08:50 --> Total execution time: 0.0349
ERROR - 2024-02-12 12:09:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:09:03 --> Config Class Initialized
INFO - 2024-02-12 12:09:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:09:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:09:03 --> Utf8 Class Initialized
INFO - 2024-02-12 12:09:03 --> URI Class Initialized
INFO - 2024-02-12 12:09:03 --> Router Class Initialized
INFO - 2024-02-12 12:09:03 --> Output Class Initialized
INFO - 2024-02-12 12:09:03 --> Security Class Initialized
DEBUG - 2024-02-12 12:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:09:03 --> Input Class Initialized
INFO - 2024-02-12 12:09:03 --> Language Class Initialized
INFO - 2024-02-12 12:09:03 --> Loader Class Initialized
INFO - 2024-02-12 12:09:03 --> Helper loaded: url_helper
INFO - 2024-02-12 12:09:03 --> Helper loaded: file_helper
INFO - 2024-02-12 12:09:03 --> Helper loaded: form_helper
INFO - 2024-02-12 12:09:03 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:09:03 --> Controller Class Initialized
INFO - 2024-02-12 12:09:03 --> Form Validation Class Initialized
INFO - 2024-02-12 12:09:03 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:09:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:09:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:09:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:09:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:09:03 --> Final output sent to browser
DEBUG - 2024-02-12 12:09:03 --> Total execution time: 0.0385
ERROR - 2024-02-12 12:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:10:51 --> Config Class Initialized
INFO - 2024-02-12 12:10:51 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:10:51 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:10:51 --> Utf8 Class Initialized
INFO - 2024-02-12 12:10:51 --> URI Class Initialized
INFO - 2024-02-12 12:10:51 --> Router Class Initialized
INFO - 2024-02-12 12:10:51 --> Output Class Initialized
INFO - 2024-02-12 12:10:51 --> Security Class Initialized
DEBUG - 2024-02-12 12:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:10:51 --> Input Class Initialized
INFO - 2024-02-12 12:10:51 --> Language Class Initialized
INFO - 2024-02-12 12:10:51 --> Loader Class Initialized
INFO - 2024-02-12 12:10:51 --> Helper loaded: url_helper
INFO - 2024-02-12 12:10:51 --> Helper loaded: file_helper
INFO - 2024-02-12 12:10:51 --> Helper loaded: form_helper
INFO - 2024-02-12 12:10:51 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:10:51 --> Controller Class Initialized
INFO - 2024-02-12 12:10:51 --> Form Validation Class Initialized
INFO - 2024-02-12 12:10:51 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:10:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:10:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:10:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:10:51 --> Final output sent to browser
DEBUG - 2024-02-12 12:10:51 --> Total execution time: 0.0262
ERROR - 2024-02-12 12:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:10:52 --> Config Class Initialized
INFO - 2024-02-12 12:10:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:10:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:10:52 --> Utf8 Class Initialized
INFO - 2024-02-12 12:10:52 --> URI Class Initialized
INFO - 2024-02-12 12:10:52 --> Router Class Initialized
INFO - 2024-02-12 12:10:52 --> Output Class Initialized
INFO - 2024-02-12 12:10:52 --> Security Class Initialized
DEBUG - 2024-02-12 12:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:10:52 --> Input Class Initialized
INFO - 2024-02-12 12:10:52 --> Language Class Initialized
INFO - 2024-02-12 12:10:52 --> Loader Class Initialized
INFO - 2024-02-12 12:10:52 --> Helper loaded: url_helper
INFO - 2024-02-12 12:10:52 --> Helper loaded: file_helper
INFO - 2024-02-12 12:10:52 --> Helper loaded: form_helper
INFO - 2024-02-12 12:10:52 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:10:52 --> Controller Class Initialized
INFO - 2024-02-12 12:10:52 --> Form Validation Class Initialized
INFO - 2024-02-12 12:10:52 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:10:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:10:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:10:52 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:10:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:10:54 --> Config Class Initialized
INFO - 2024-02-12 12:10:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:10:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:10:54 --> Utf8 Class Initialized
INFO - 2024-02-12 12:10:54 --> URI Class Initialized
INFO - 2024-02-12 12:10:54 --> Router Class Initialized
INFO - 2024-02-12 12:10:54 --> Output Class Initialized
INFO - 2024-02-12 12:10:54 --> Security Class Initialized
DEBUG - 2024-02-12 12:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:10:54 --> Input Class Initialized
INFO - 2024-02-12 12:10:54 --> Language Class Initialized
INFO - 2024-02-12 12:10:54 --> Loader Class Initialized
INFO - 2024-02-12 12:10:54 --> Helper loaded: url_helper
INFO - 2024-02-12 12:10:54 --> Helper loaded: file_helper
INFO - 2024-02-12 12:10:54 --> Helper loaded: form_helper
INFO - 2024-02-12 12:10:54 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:10:54 --> Controller Class Initialized
INFO - 2024-02-12 12:10:54 --> Form Validation Class Initialized
INFO - 2024-02-12 12:10:54 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:10:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:10:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:10:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:10:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:10:54 --> Final output sent to browser
DEBUG - 2024-02-12 12:10:54 --> Total execution time: 0.0400
ERROR - 2024-02-12 12:13:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:13:26 --> Config Class Initialized
INFO - 2024-02-12 12:13:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:13:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:13:26 --> Utf8 Class Initialized
INFO - 2024-02-12 12:13:26 --> URI Class Initialized
INFO - 2024-02-12 12:13:26 --> Router Class Initialized
INFO - 2024-02-12 12:13:26 --> Output Class Initialized
INFO - 2024-02-12 12:13:26 --> Security Class Initialized
DEBUG - 2024-02-12 12:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:13:26 --> Input Class Initialized
INFO - 2024-02-12 12:13:26 --> Language Class Initialized
INFO - 2024-02-12 12:13:26 --> Loader Class Initialized
INFO - 2024-02-12 12:13:26 --> Helper loaded: url_helper
INFO - 2024-02-12 12:13:26 --> Helper loaded: file_helper
INFO - 2024-02-12 12:13:26 --> Helper loaded: form_helper
INFO - 2024-02-12 12:13:26 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:13:26 --> Controller Class Initialized
INFO - 2024-02-12 12:13:26 --> Form Validation Class Initialized
INFO - 2024-02-12 12:13:26 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:13:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:13:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:13:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:13:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:13:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:13:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:13:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:13:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:13:26 --> Final output sent to browser
DEBUG - 2024-02-12 12:13:26 --> Total execution time: 0.0403
ERROR - 2024-02-12 12:13:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:13:29 --> Config Class Initialized
INFO - 2024-02-12 12:13:29 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:13:29 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:13:29 --> Utf8 Class Initialized
INFO - 2024-02-12 12:13:29 --> URI Class Initialized
INFO - 2024-02-12 12:13:29 --> Router Class Initialized
INFO - 2024-02-12 12:13:29 --> Output Class Initialized
INFO - 2024-02-12 12:13:29 --> Security Class Initialized
DEBUG - 2024-02-12 12:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:13:29 --> Input Class Initialized
INFO - 2024-02-12 12:13:29 --> Language Class Initialized
INFO - 2024-02-12 12:13:29 --> Loader Class Initialized
INFO - 2024-02-12 12:13:29 --> Helper loaded: url_helper
INFO - 2024-02-12 12:13:29 --> Helper loaded: file_helper
INFO - 2024-02-12 12:13:29 --> Helper loaded: form_helper
INFO - 2024-02-12 12:13:29 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:13:29 --> Controller Class Initialized
INFO - 2024-02-12 12:13:29 --> Form Validation Class Initialized
INFO - 2024-02-12 12:13:29 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:13:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:13:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:13:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:13:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:13:31 --> Config Class Initialized
INFO - 2024-02-12 12:13:31 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:13:31 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:13:31 --> Utf8 Class Initialized
INFO - 2024-02-12 12:13:31 --> URI Class Initialized
INFO - 2024-02-12 12:13:31 --> Router Class Initialized
INFO - 2024-02-12 12:13:31 --> Output Class Initialized
INFO - 2024-02-12 12:13:31 --> Security Class Initialized
DEBUG - 2024-02-12 12:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:13:31 --> Input Class Initialized
INFO - 2024-02-12 12:13:31 --> Language Class Initialized
INFO - 2024-02-12 12:13:31 --> Loader Class Initialized
INFO - 2024-02-12 12:13:31 --> Helper loaded: url_helper
INFO - 2024-02-12 12:13:31 --> Helper loaded: file_helper
INFO - 2024-02-12 12:13:31 --> Helper loaded: form_helper
INFO - 2024-02-12 12:13:31 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:13:31 --> Controller Class Initialized
INFO - 2024-02-12 12:13:31 --> Form Validation Class Initialized
INFO - 2024-02-12 12:13:31 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:13:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:13:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:13:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:13:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:13:31 --> Final output sent to browser
DEBUG - 2024-02-12 12:13:31 --> Total execution time: 0.0200
ERROR - 2024-02-12 12:15:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:15:57 --> Config Class Initialized
INFO - 2024-02-12 12:15:57 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:15:57 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:15:57 --> Utf8 Class Initialized
INFO - 2024-02-12 12:15:57 --> URI Class Initialized
INFO - 2024-02-12 12:15:57 --> Router Class Initialized
INFO - 2024-02-12 12:15:57 --> Output Class Initialized
INFO - 2024-02-12 12:15:57 --> Security Class Initialized
DEBUG - 2024-02-12 12:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:15:57 --> Input Class Initialized
INFO - 2024-02-12 12:15:57 --> Language Class Initialized
INFO - 2024-02-12 12:15:57 --> Loader Class Initialized
INFO - 2024-02-12 12:15:57 --> Helper loaded: url_helper
INFO - 2024-02-12 12:15:57 --> Helper loaded: file_helper
INFO - 2024-02-12 12:15:57 --> Helper loaded: form_helper
INFO - 2024-02-12 12:15:57 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:15:57 --> Controller Class Initialized
INFO - 2024-02-12 12:15:57 --> Form Validation Class Initialized
INFO - 2024-02-12 12:15:57 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:15:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:15:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:15:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:15:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:15:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:15:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:15:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:15:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:15:57 --> Final output sent to browser
DEBUG - 2024-02-12 12:15:57 --> Total execution time: 0.0299
ERROR - 2024-02-12 12:15:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:15:59 --> Config Class Initialized
INFO - 2024-02-12 12:15:59 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:15:59 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:15:59 --> Utf8 Class Initialized
INFO - 2024-02-12 12:15:59 --> URI Class Initialized
INFO - 2024-02-12 12:15:59 --> Router Class Initialized
INFO - 2024-02-12 12:15:59 --> Output Class Initialized
INFO - 2024-02-12 12:15:59 --> Security Class Initialized
DEBUG - 2024-02-12 12:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:15:59 --> Input Class Initialized
INFO - 2024-02-12 12:15:59 --> Language Class Initialized
INFO - 2024-02-12 12:15:59 --> Loader Class Initialized
INFO - 2024-02-12 12:15:59 --> Helper loaded: url_helper
INFO - 2024-02-12 12:15:59 --> Helper loaded: file_helper
INFO - 2024-02-12 12:15:59 --> Helper loaded: form_helper
INFO - 2024-02-12 12:15:59 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:15:59 --> Controller Class Initialized
INFO - 2024-02-12 12:15:59 --> Form Validation Class Initialized
INFO - 2024-02-12 12:15:59 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:15:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:15:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:15:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:16:01 --> Config Class Initialized
INFO - 2024-02-12 12:16:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:16:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:16:01 --> Utf8 Class Initialized
INFO - 2024-02-12 12:16:01 --> URI Class Initialized
INFO - 2024-02-12 12:16:01 --> Router Class Initialized
INFO - 2024-02-12 12:16:01 --> Output Class Initialized
INFO - 2024-02-12 12:16:01 --> Security Class Initialized
DEBUG - 2024-02-12 12:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:16:01 --> Input Class Initialized
INFO - 2024-02-12 12:16:01 --> Language Class Initialized
INFO - 2024-02-12 12:16:01 --> Loader Class Initialized
INFO - 2024-02-12 12:16:01 --> Helper loaded: url_helper
INFO - 2024-02-12 12:16:01 --> Helper loaded: file_helper
INFO - 2024-02-12 12:16:01 --> Helper loaded: form_helper
INFO - 2024-02-12 12:16:01 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:16:01 --> Controller Class Initialized
INFO - 2024-02-12 12:16:01 --> Form Validation Class Initialized
INFO - 2024-02-12 12:16:01 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:16:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:16:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:16:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:16:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:16:01 --> Final output sent to browser
DEBUG - 2024-02-12 12:16:01 --> Total execution time: 0.0268
ERROR - 2024-02-12 12:19:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:19:27 --> Config Class Initialized
INFO - 2024-02-12 12:19:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:19:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:19:27 --> Utf8 Class Initialized
INFO - 2024-02-12 12:19:27 --> URI Class Initialized
INFO - 2024-02-12 12:19:27 --> Router Class Initialized
INFO - 2024-02-12 12:19:27 --> Output Class Initialized
INFO - 2024-02-12 12:19:27 --> Security Class Initialized
DEBUG - 2024-02-12 12:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:19:27 --> Input Class Initialized
INFO - 2024-02-12 12:19:27 --> Language Class Initialized
INFO - 2024-02-12 12:19:27 --> Loader Class Initialized
INFO - 2024-02-12 12:19:27 --> Helper loaded: url_helper
INFO - 2024-02-12 12:19:27 --> Helper loaded: file_helper
INFO - 2024-02-12 12:19:27 --> Helper loaded: form_helper
INFO - 2024-02-12 12:19:27 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:19:27 --> Controller Class Initialized
INFO - 2024-02-12 12:19:27 --> Form Validation Class Initialized
INFO - 2024-02-12 12:19:27 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:19:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:19:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:19:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:19:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:19:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:19:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:19:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:19:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:19:27 --> Final output sent to browser
DEBUG - 2024-02-12 12:19:27 --> Total execution time: 0.0358
ERROR - 2024-02-12 12:19:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:19:27 --> Config Class Initialized
INFO - 2024-02-12 12:19:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:19:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:19:27 --> Utf8 Class Initialized
INFO - 2024-02-12 12:19:27 --> URI Class Initialized
INFO - 2024-02-12 12:19:27 --> Router Class Initialized
INFO - 2024-02-12 12:19:27 --> Output Class Initialized
INFO - 2024-02-12 12:19:27 --> Security Class Initialized
DEBUG - 2024-02-12 12:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:19:27 --> Input Class Initialized
INFO - 2024-02-12 12:19:27 --> Language Class Initialized
INFO - 2024-02-12 12:19:27 --> Loader Class Initialized
INFO - 2024-02-12 12:19:27 --> Helper loaded: url_helper
INFO - 2024-02-12 12:19:27 --> Helper loaded: file_helper
INFO - 2024-02-12 12:19:27 --> Helper loaded: form_helper
INFO - 2024-02-12 12:19:27 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:19:27 --> Controller Class Initialized
INFO - 2024-02-12 12:19:27 --> Form Validation Class Initialized
INFO - 2024-02-12 12:19:27 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:19:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:19:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:19:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:19:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:19:30 --> Config Class Initialized
INFO - 2024-02-12 12:19:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:19:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:19:30 --> Utf8 Class Initialized
INFO - 2024-02-12 12:19:30 --> URI Class Initialized
INFO - 2024-02-12 12:19:30 --> Router Class Initialized
INFO - 2024-02-12 12:19:30 --> Output Class Initialized
INFO - 2024-02-12 12:19:30 --> Security Class Initialized
DEBUG - 2024-02-12 12:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:19:30 --> Input Class Initialized
INFO - 2024-02-12 12:19:30 --> Language Class Initialized
INFO - 2024-02-12 12:19:30 --> Loader Class Initialized
INFO - 2024-02-12 12:19:30 --> Helper loaded: url_helper
INFO - 2024-02-12 12:19:30 --> Helper loaded: file_helper
INFO - 2024-02-12 12:19:30 --> Helper loaded: form_helper
INFO - 2024-02-12 12:19:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:19:30 --> Controller Class Initialized
INFO - 2024-02-12 12:19:30 --> Form Validation Class Initialized
INFO - 2024-02-12 12:19:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:19:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:19:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:19:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:19:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:19:30 --> Final output sent to browser
DEBUG - 2024-02-12 12:19:30 --> Total execution time: 0.0367
ERROR - 2024-02-12 12:20:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:20:01 --> Config Class Initialized
INFO - 2024-02-12 12:20:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:20:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:20:01 --> Utf8 Class Initialized
INFO - 2024-02-12 12:20:01 --> URI Class Initialized
INFO - 2024-02-12 12:20:01 --> Router Class Initialized
INFO - 2024-02-12 12:20:01 --> Output Class Initialized
INFO - 2024-02-12 12:20:01 --> Security Class Initialized
DEBUG - 2024-02-12 12:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:20:01 --> Input Class Initialized
INFO - 2024-02-12 12:20:01 --> Language Class Initialized
INFO - 2024-02-12 12:20:01 --> Loader Class Initialized
INFO - 2024-02-12 12:20:01 --> Helper loaded: url_helper
INFO - 2024-02-12 12:20:01 --> Helper loaded: file_helper
INFO - 2024-02-12 12:20:01 --> Helper loaded: form_helper
INFO - 2024-02-12 12:20:01 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:20:01 --> Controller Class Initialized
INFO - 2024-02-12 12:20:01 --> Form Validation Class Initialized
INFO - 2024-02-12 12:20:01 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:20:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:20:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:20:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:20:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:20:01 --> Final output sent to browser
DEBUG - 2024-02-12 12:20:01 --> Total execution time: 0.0326
ERROR - 2024-02-12 12:21:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:21:07 --> Config Class Initialized
INFO - 2024-02-12 12:21:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:21:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:21:07 --> Utf8 Class Initialized
INFO - 2024-02-12 12:21:07 --> URI Class Initialized
INFO - 2024-02-12 12:21:07 --> Router Class Initialized
INFO - 2024-02-12 12:21:07 --> Output Class Initialized
INFO - 2024-02-12 12:21:07 --> Security Class Initialized
DEBUG - 2024-02-12 12:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:21:07 --> Input Class Initialized
INFO - 2024-02-12 12:21:07 --> Language Class Initialized
INFO - 2024-02-12 12:21:07 --> Loader Class Initialized
INFO - 2024-02-12 12:21:07 --> Helper loaded: url_helper
INFO - 2024-02-12 12:21:07 --> Helper loaded: file_helper
INFO - 2024-02-12 12:21:07 --> Helper loaded: form_helper
INFO - 2024-02-12 12:21:07 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:21:07 --> Controller Class Initialized
INFO - 2024-02-12 12:21:07 --> Form Validation Class Initialized
INFO - 2024-02-12 12:21:07 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:21:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:21:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:21:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:21:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:21:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:21:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:21:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:21:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:21:07 --> Final output sent to browser
DEBUG - 2024-02-12 12:21:07 --> Total execution time: 0.0337
ERROR - 2024-02-12 12:21:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:21:07 --> Config Class Initialized
INFO - 2024-02-12 12:21:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:21:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:21:07 --> Utf8 Class Initialized
INFO - 2024-02-12 12:21:07 --> URI Class Initialized
INFO - 2024-02-12 12:21:07 --> Router Class Initialized
INFO - 2024-02-12 12:21:07 --> Output Class Initialized
INFO - 2024-02-12 12:21:07 --> Security Class Initialized
DEBUG - 2024-02-12 12:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:21:07 --> Input Class Initialized
INFO - 2024-02-12 12:21:07 --> Language Class Initialized
INFO - 2024-02-12 12:21:07 --> Loader Class Initialized
INFO - 2024-02-12 12:21:07 --> Helper loaded: url_helper
INFO - 2024-02-12 12:21:07 --> Helper loaded: file_helper
INFO - 2024-02-12 12:21:07 --> Helper loaded: form_helper
INFO - 2024-02-12 12:21:07 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:21:07 --> Controller Class Initialized
INFO - 2024-02-12 12:21:07 --> Form Validation Class Initialized
INFO - 2024-02-12 12:21:07 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:21:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:21:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:21:07 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:21:09 --> Config Class Initialized
INFO - 2024-02-12 12:21:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:21:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:21:09 --> Utf8 Class Initialized
INFO - 2024-02-12 12:21:09 --> URI Class Initialized
INFO - 2024-02-12 12:21:09 --> Router Class Initialized
INFO - 2024-02-12 12:21:09 --> Output Class Initialized
INFO - 2024-02-12 12:21:09 --> Security Class Initialized
DEBUG - 2024-02-12 12:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:21:09 --> Input Class Initialized
INFO - 2024-02-12 12:21:09 --> Language Class Initialized
INFO - 2024-02-12 12:21:09 --> Loader Class Initialized
INFO - 2024-02-12 12:21:09 --> Helper loaded: url_helper
INFO - 2024-02-12 12:21:09 --> Helper loaded: file_helper
INFO - 2024-02-12 12:21:09 --> Helper loaded: form_helper
INFO - 2024-02-12 12:21:09 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:21:09 --> Controller Class Initialized
INFO - 2024-02-12 12:21:09 --> Form Validation Class Initialized
INFO - 2024-02-12 12:21:09 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:21:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:21:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:21:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:21:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:21:09 --> Final output sent to browser
DEBUG - 2024-02-12 12:21:09 --> Total execution time: 0.0335
ERROR - 2024-02-12 12:24:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:24:53 --> Config Class Initialized
INFO - 2024-02-12 12:24:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:24:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:24:53 --> Utf8 Class Initialized
INFO - 2024-02-12 12:24:53 --> URI Class Initialized
INFO - 2024-02-12 12:24:53 --> Router Class Initialized
INFO - 2024-02-12 12:24:53 --> Output Class Initialized
INFO - 2024-02-12 12:24:53 --> Security Class Initialized
DEBUG - 2024-02-12 12:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:24:53 --> Input Class Initialized
INFO - 2024-02-12 12:24:53 --> Language Class Initialized
INFO - 2024-02-12 12:24:53 --> Loader Class Initialized
INFO - 2024-02-12 12:24:53 --> Helper loaded: url_helper
INFO - 2024-02-12 12:24:53 --> Helper loaded: file_helper
INFO - 2024-02-12 12:24:53 --> Helper loaded: form_helper
INFO - 2024-02-12 12:24:53 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:24:53 --> Controller Class Initialized
INFO - 2024-02-12 12:24:53 --> Form Validation Class Initialized
INFO - 2024-02-12 12:24:53 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:24:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:24:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:24:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:24:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:24:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:24:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:24:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:24:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:24:53 --> Final output sent to browser
DEBUG - 2024-02-12 12:24:53 --> Total execution time: 0.0332
ERROR - 2024-02-12 12:24:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:24:53 --> Config Class Initialized
INFO - 2024-02-12 12:24:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:24:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:24:53 --> Utf8 Class Initialized
INFO - 2024-02-12 12:24:53 --> URI Class Initialized
INFO - 2024-02-12 12:24:53 --> Router Class Initialized
INFO - 2024-02-12 12:24:53 --> Output Class Initialized
INFO - 2024-02-12 12:24:53 --> Security Class Initialized
DEBUG - 2024-02-12 12:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:24:53 --> Input Class Initialized
INFO - 2024-02-12 12:24:53 --> Language Class Initialized
INFO - 2024-02-12 12:24:53 --> Loader Class Initialized
INFO - 2024-02-12 12:24:53 --> Helper loaded: url_helper
INFO - 2024-02-12 12:24:53 --> Helper loaded: file_helper
INFO - 2024-02-12 12:24:53 --> Helper loaded: form_helper
INFO - 2024-02-12 12:24:53 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:24:53 --> Controller Class Initialized
INFO - 2024-02-12 12:24:53 --> Form Validation Class Initialized
INFO - 2024-02-12 12:24:53 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:24:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:24:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:24:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:24:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:24:57 --> Config Class Initialized
INFO - 2024-02-12 12:24:57 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:24:57 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:24:57 --> Utf8 Class Initialized
INFO - 2024-02-12 12:24:57 --> URI Class Initialized
INFO - 2024-02-12 12:24:57 --> Router Class Initialized
INFO - 2024-02-12 12:24:57 --> Output Class Initialized
INFO - 2024-02-12 12:24:57 --> Security Class Initialized
DEBUG - 2024-02-12 12:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:24:57 --> Input Class Initialized
INFO - 2024-02-12 12:24:57 --> Language Class Initialized
INFO - 2024-02-12 12:24:57 --> Loader Class Initialized
INFO - 2024-02-12 12:24:57 --> Helper loaded: url_helper
INFO - 2024-02-12 12:24:57 --> Helper loaded: file_helper
INFO - 2024-02-12 12:24:57 --> Helper loaded: form_helper
INFO - 2024-02-12 12:24:57 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:24:57 --> Controller Class Initialized
INFO - 2024-02-12 12:24:57 --> Form Validation Class Initialized
INFO - 2024-02-12 12:24:57 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:24:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:24:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:24:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:24:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:24:57 --> Final output sent to browser
DEBUG - 2024-02-12 12:24:57 --> Total execution time: 0.0386
ERROR - 2024-02-12 12:26:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:26:52 --> Config Class Initialized
INFO - 2024-02-12 12:26:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:26:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:26:52 --> Utf8 Class Initialized
INFO - 2024-02-12 12:26:52 --> URI Class Initialized
INFO - 2024-02-12 12:26:52 --> Router Class Initialized
INFO - 2024-02-12 12:26:52 --> Output Class Initialized
INFO - 2024-02-12 12:26:52 --> Security Class Initialized
DEBUG - 2024-02-12 12:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:26:52 --> Input Class Initialized
INFO - 2024-02-12 12:26:52 --> Language Class Initialized
INFO - 2024-02-12 12:26:52 --> Loader Class Initialized
INFO - 2024-02-12 12:26:52 --> Helper loaded: url_helper
INFO - 2024-02-12 12:26:52 --> Helper loaded: file_helper
INFO - 2024-02-12 12:26:52 --> Helper loaded: form_helper
INFO - 2024-02-12 12:26:52 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:26:52 --> Controller Class Initialized
INFO - 2024-02-12 12:26:52 --> Form Validation Class Initialized
INFO - 2024-02-12 12:26:52 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:26:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:26:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:26:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:26:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:26:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:26:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:26:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:26:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:26:52 --> Final output sent to browser
DEBUG - 2024-02-12 12:26:52 --> Total execution time: 0.0309
ERROR - 2024-02-12 12:26:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:26:53 --> Config Class Initialized
INFO - 2024-02-12 12:26:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:26:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:26:53 --> Utf8 Class Initialized
INFO - 2024-02-12 12:26:53 --> URI Class Initialized
INFO - 2024-02-12 12:26:53 --> Router Class Initialized
INFO - 2024-02-12 12:26:53 --> Output Class Initialized
INFO - 2024-02-12 12:26:53 --> Security Class Initialized
DEBUG - 2024-02-12 12:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:26:53 --> Input Class Initialized
INFO - 2024-02-12 12:26:53 --> Language Class Initialized
INFO - 2024-02-12 12:26:53 --> Loader Class Initialized
INFO - 2024-02-12 12:26:53 --> Helper loaded: url_helper
INFO - 2024-02-12 12:26:53 --> Helper loaded: file_helper
INFO - 2024-02-12 12:26:53 --> Helper loaded: form_helper
INFO - 2024-02-12 12:26:53 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:26:53 --> Controller Class Initialized
INFO - 2024-02-12 12:26:53 --> Form Validation Class Initialized
INFO - 2024-02-12 12:26:53 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:26:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:26:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:26:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:26:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:26:55 --> Config Class Initialized
INFO - 2024-02-12 12:26:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:26:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:26:55 --> Utf8 Class Initialized
INFO - 2024-02-12 12:26:55 --> URI Class Initialized
INFO - 2024-02-12 12:26:55 --> Router Class Initialized
INFO - 2024-02-12 12:26:55 --> Output Class Initialized
INFO - 2024-02-12 12:26:55 --> Security Class Initialized
DEBUG - 2024-02-12 12:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:26:55 --> Input Class Initialized
INFO - 2024-02-12 12:26:55 --> Language Class Initialized
INFO - 2024-02-12 12:26:55 --> Loader Class Initialized
INFO - 2024-02-12 12:26:55 --> Helper loaded: url_helper
INFO - 2024-02-12 12:26:55 --> Helper loaded: file_helper
INFO - 2024-02-12 12:26:55 --> Helper loaded: form_helper
INFO - 2024-02-12 12:26:55 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:26:55 --> Controller Class Initialized
INFO - 2024-02-12 12:26:55 --> Form Validation Class Initialized
INFO - 2024-02-12 12:26:55 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:26:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:26:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:26:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:26:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:26:55 --> Final output sent to browser
DEBUG - 2024-02-12 12:26:55 --> Total execution time: 0.0209
ERROR - 2024-02-12 12:27:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:27:34 --> Config Class Initialized
INFO - 2024-02-12 12:27:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:27:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:27:34 --> Utf8 Class Initialized
INFO - 2024-02-12 12:27:34 --> URI Class Initialized
INFO - 2024-02-12 12:27:34 --> Router Class Initialized
INFO - 2024-02-12 12:27:34 --> Output Class Initialized
INFO - 2024-02-12 12:27:34 --> Security Class Initialized
DEBUG - 2024-02-12 12:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:27:34 --> Input Class Initialized
INFO - 2024-02-12 12:27:34 --> Language Class Initialized
INFO - 2024-02-12 12:27:34 --> Loader Class Initialized
INFO - 2024-02-12 12:27:34 --> Helper loaded: url_helper
INFO - 2024-02-12 12:27:34 --> Helper loaded: file_helper
INFO - 2024-02-12 12:27:34 --> Helper loaded: form_helper
INFO - 2024-02-12 12:27:34 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:27:34 --> Controller Class Initialized
INFO - 2024-02-12 12:27:34 --> Form Validation Class Initialized
INFO - 2024-02-12 12:27:34 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:27:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:27:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:27:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:27:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:27:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:27:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:27:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:27:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:27:34 --> Final output sent to browser
DEBUG - 2024-02-12 12:27:34 --> Total execution time: 0.0284
ERROR - 2024-02-12 12:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:27:35 --> Config Class Initialized
INFO - 2024-02-12 12:27:35 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:27:35 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:27:35 --> Utf8 Class Initialized
INFO - 2024-02-12 12:27:35 --> URI Class Initialized
INFO - 2024-02-12 12:27:35 --> Router Class Initialized
INFO - 2024-02-12 12:27:35 --> Output Class Initialized
INFO - 2024-02-12 12:27:35 --> Security Class Initialized
DEBUG - 2024-02-12 12:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:27:35 --> Input Class Initialized
INFO - 2024-02-12 12:27:35 --> Language Class Initialized
INFO - 2024-02-12 12:27:35 --> Loader Class Initialized
INFO - 2024-02-12 12:27:35 --> Helper loaded: url_helper
INFO - 2024-02-12 12:27:35 --> Helper loaded: file_helper
INFO - 2024-02-12 12:27:35 --> Helper loaded: form_helper
INFO - 2024-02-12 12:27:35 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:27:35 --> Controller Class Initialized
INFO - 2024-02-12 12:27:35 --> Form Validation Class Initialized
INFO - 2024-02-12 12:27:35 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:27:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:27:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:27:35 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:27:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:27:38 --> Config Class Initialized
INFO - 2024-02-12 12:27:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:27:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:27:38 --> Utf8 Class Initialized
INFO - 2024-02-12 12:27:38 --> URI Class Initialized
INFO - 2024-02-12 12:27:38 --> Router Class Initialized
INFO - 2024-02-12 12:27:38 --> Output Class Initialized
INFO - 2024-02-12 12:27:38 --> Security Class Initialized
DEBUG - 2024-02-12 12:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:27:38 --> Input Class Initialized
INFO - 2024-02-12 12:27:38 --> Language Class Initialized
INFO - 2024-02-12 12:27:38 --> Loader Class Initialized
INFO - 2024-02-12 12:27:38 --> Helper loaded: url_helper
INFO - 2024-02-12 12:27:38 --> Helper loaded: file_helper
INFO - 2024-02-12 12:27:38 --> Helper loaded: form_helper
INFO - 2024-02-12 12:27:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:27:38 --> Controller Class Initialized
INFO - 2024-02-12 12:27:38 --> Form Validation Class Initialized
INFO - 2024-02-12 12:27:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:27:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:27:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:27:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:27:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:27:38 --> Final output sent to browser
DEBUG - 2024-02-12 12:27:38 --> Total execution time: 0.0496
ERROR - 2024-02-12 12:28:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:28:02 --> Config Class Initialized
INFO - 2024-02-12 12:28:02 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:28:02 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:28:02 --> Utf8 Class Initialized
INFO - 2024-02-12 12:28:02 --> URI Class Initialized
INFO - 2024-02-12 12:28:02 --> Router Class Initialized
INFO - 2024-02-12 12:28:02 --> Output Class Initialized
INFO - 2024-02-12 12:28:02 --> Security Class Initialized
DEBUG - 2024-02-12 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:28:02 --> Input Class Initialized
INFO - 2024-02-12 12:28:02 --> Language Class Initialized
INFO - 2024-02-12 12:28:02 --> Loader Class Initialized
INFO - 2024-02-12 12:28:02 --> Helper loaded: url_helper
INFO - 2024-02-12 12:28:02 --> Helper loaded: file_helper
INFO - 2024-02-12 12:28:02 --> Helper loaded: form_helper
INFO - 2024-02-12 12:28:02 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:28:02 --> Controller Class Initialized
INFO - 2024-02-12 12:28:02 --> Form Validation Class Initialized
INFO - 2024-02-12 12:28:02 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:28:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:28:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:28:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:28:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:28:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:28:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:28:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:28:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:28:02 --> Final output sent to browser
DEBUG - 2024-02-12 12:28:02 --> Total execution time: 0.0326
ERROR - 2024-02-12 12:28:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:28:03 --> Config Class Initialized
INFO - 2024-02-12 12:28:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:28:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:28:03 --> Utf8 Class Initialized
INFO - 2024-02-12 12:28:03 --> URI Class Initialized
INFO - 2024-02-12 12:28:03 --> Router Class Initialized
INFO - 2024-02-12 12:28:03 --> Output Class Initialized
INFO - 2024-02-12 12:28:03 --> Security Class Initialized
DEBUG - 2024-02-12 12:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:28:03 --> Input Class Initialized
INFO - 2024-02-12 12:28:03 --> Language Class Initialized
INFO - 2024-02-12 12:28:03 --> Loader Class Initialized
INFO - 2024-02-12 12:28:03 --> Helper loaded: url_helper
INFO - 2024-02-12 12:28:03 --> Helper loaded: file_helper
INFO - 2024-02-12 12:28:03 --> Helper loaded: form_helper
INFO - 2024-02-12 12:28:03 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:28:03 --> Controller Class Initialized
INFO - 2024-02-12 12:28:03 --> Form Validation Class Initialized
INFO - 2024-02-12 12:28:03 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:28:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:28:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:28:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:28:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:28:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:28:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:28:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:28:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:28:03 --> Final output sent to browser
DEBUG - 2024-02-12 12:28:03 --> Total execution time: 0.0413
ERROR - 2024-02-12 12:28:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:28:05 --> Config Class Initialized
INFO - 2024-02-12 12:28:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:28:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:28:05 --> Utf8 Class Initialized
INFO - 2024-02-12 12:28:05 --> URI Class Initialized
INFO - 2024-02-12 12:28:05 --> Router Class Initialized
INFO - 2024-02-12 12:28:05 --> Output Class Initialized
INFO - 2024-02-12 12:28:05 --> Security Class Initialized
DEBUG - 2024-02-12 12:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:28:05 --> Input Class Initialized
INFO - 2024-02-12 12:28:05 --> Language Class Initialized
INFO - 2024-02-12 12:28:05 --> Loader Class Initialized
INFO - 2024-02-12 12:28:05 --> Helper loaded: url_helper
INFO - 2024-02-12 12:28:05 --> Helper loaded: file_helper
INFO - 2024-02-12 12:28:05 --> Helper loaded: form_helper
INFO - 2024-02-12 12:28:05 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:28:05 --> Controller Class Initialized
INFO - 2024-02-12 12:28:05 --> Form Validation Class Initialized
INFO - 2024-02-12 12:28:05 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:28:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:28:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:28:05 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:28:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:28:07 --> Config Class Initialized
INFO - 2024-02-12 12:28:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:28:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:28:07 --> Utf8 Class Initialized
INFO - 2024-02-12 12:28:07 --> URI Class Initialized
INFO - 2024-02-12 12:28:07 --> Router Class Initialized
INFO - 2024-02-12 12:28:07 --> Output Class Initialized
INFO - 2024-02-12 12:28:07 --> Security Class Initialized
DEBUG - 2024-02-12 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:28:07 --> Input Class Initialized
INFO - 2024-02-12 12:28:07 --> Language Class Initialized
INFO - 2024-02-12 12:28:07 --> Loader Class Initialized
INFO - 2024-02-12 12:28:07 --> Helper loaded: url_helper
INFO - 2024-02-12 12:28:07 --> Helper loaded: file_helper
INFO - 2024-02-12 12:28:07 --> Helper loaded: form_helper
INFO - 2024-02-12 12:28:07 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:28:07 --> Controller Class Initialized
INFO - 2024-02-12 12:28:07 --> Form Validation Class Initialized
INFO - 2024-02-12 12:28:07 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:28:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:28:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:28:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:28:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:28:07 --> Final output sent to browser
DEBUG - 2024-02-12 12:28:07 --> Total execution time: 0.0299
ERROR - 2024-02-12 12:29:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:29:06 --> Config Class Initialized
INFO - 2024-02-12 12:29:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:29:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:29:06 --> Utf8 Class Initialized
INFO - 2024-02-12 12:29:06 --> URI Class Initialized
INFO - 2024-02-12 12:29:06 --> Router Class Initialized
INFO - 2024-02-12 12:29:06 --> Output Class Initialized
INFO - 2024-02-12 12:29:06 --> Security Class Initialized
DEBUG - 2024-02-12 12:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:29:06 --> Input Class Initialized
INFO - 2024-02-12 12:29:06 --> Language Class Initialized
INFO - 2024-02-12 12:29:06 --> Loader Class Initialized
INFO - 2024-02-12 12:29:06 --> Helper loaded: url_helper
INFO - 2024-02-12 12:29:06 --> Helper loaded: file_helper
INFO - 2024-02-12 12:29:06 --> Helper loaded: form_helper
INFO - 2024-02-12 12:29:06 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:29:06 --> Controller Class Initialized
INFO - 2024-02-12 12:29:06 --> Form Validation Class Initialized
INFO - 2024-02-12 12:29:06 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:29:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:29:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:29:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:29:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:29:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:29:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:29:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:29:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:29:06 --> Final output sent to browser
DEBUG - 2024-02-12 12:29:06 --> Total execution time: 0.0291
ERROR - 2024-02-12 12:29:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:29:06 --> Config Class Initialized
INFO - 2024-02-12 12:29:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:29:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:29:06 --> Utf8 Class Initialized
INFO - 2024-02-12 12:29:06 --> URI Class Initialized
INFO - 2024-02-12 12:29:06 --> Router Class Initialized
INFO - 2024-02-12 12:29:06 --> Output Class Initialized
INFO - 2024-02-12 12:29:06 --> Security Class Initialized
DEBUG - 2024-02-12 12:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:29:06 --> Input Class Initialized
INFO - 2024-02-12 12:29:06 --> Language Class Initialized
INFO - 2024-02-12 12:29:06 --> Loader Class Initialized
INFO - 2024-02-12 12:29:06 --> Helper loaded: url_helper
INFO - 2024-02-12 12:29:06 --> Helper loaded: file_helper
INFO - 2024-02-12 12:29:06 --> Helper loaded: form_helper
INFO - 2024-02-12 12:29:06 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:29:06 --> Controller Class Initialized
INFO - 2024-02-12 12:29:06 --> Form Validation Class Initialized
INFO - 2024-02-12 12:29:06 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:29:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:29:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:29:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:29:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:29:09 --> Config Class Initialized
INFO - 2024-02-12 12:29:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:29:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:29:09 --> Utf8 Class Initialized
INFO - 2024-02-12 12:29:09 --> URI Class Initialized
INFO - 2024-02-12 12:29:09 --> Router Class Initialized
INFO - 2024-02-12 12:29:09 --> Output Class Initialized
INFO - 2024-02-12 12:29:09 --> Security Class Initialized
DEBUG - 2024-02-12 12:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:29:09 --> Input Class Initialized
INFO - 2024-02-12 12:29:09 --> Language Class Initialized
INFO - 2024-02-12 12:29:09 --> Loader Class Initialized
INFO - 2024-02-12 12:29:09 --> Helper loaded: url_helper
INFO - 2024-02-12 12:29:09 --> Helper loaded: file_helper
INFO - 2024-02-12 12:29:09 --> Helper loaded: form_helper
INFO - 2024-02-12 12:29:09 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:29:09 --> Controller Class Initialized
INFO - 2024-02-12 12:29:09 --> Form Validation Class Initialized
INFO - 2024-02-12 12:29:09 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:29:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:29:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:29:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:29:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:29:09 --> Final output sent to browser
DEBUG - 2024-02-12 12:29:09 --> Total execution time: 0.0276
ERROR - 2024-02-12 12:30:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:30:04 --> Config Class Initialized
INFO - 2024-02-12 12:30:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:30:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:30:04 --> Utf8 Class Initialized
INFO - 2024-02-12 12:30:04 --> URI Class Initialized
INFO - 2024-02-12 12:30:04 --> Router Class Initialized
INFO - 2024-02-12 12:30:04 --> Output Class Initialized
INFO - 2024-02-12 12:30:04 --> Security Class Initialized
DEBUG - 2024-02-12 12:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:30:04 --> Input Class Initialized
INFO - 2024-02-12 12:30:04 --> Language Class Initialized
INFO - 2024-02-12 12:30:04 --> Loader Class Initialized
INFO - 2024-02-12 12:30:04 --> Helper loaded: url_helper
INFO - 2024-02-12 12:30:04 --> Helper loaded: file_helper
INFO - 2024-02-12 12:30:04 --> Helper loaded: form_helper
INFO - 2024-02-12 12:30:04 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:30:04 --> Controller Class Initialized
INFO - 2024-02-12 12:30:04 --> Form Validation Class Initialized
INFO - 2024-02-12 12:30:04 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:30:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:30:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:30:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:30:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:30:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:30:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:30:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:30:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:30:04 --> Final output sent to browser
DEBUG - 2024-02-12 12:30:04 --> Total execution time: 0.0337
ERROR - 2024-02-12 12:30:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:30:05 --> Config Class Initialized
INFO - 2024-02-12 12:30:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:30:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:30:05 --> Utf8 Class Initialized
INFO - 2024-02-12 12:30:05 --> URI Class Initialized
INFO - 2024-02-12 12:30:05 --> Router Class Initialized
INFO - 2024-02-12 12:30:05 --> Output Class Initialized
INFO - 2024-02-12 12:30:05 --> Security Class Initialized
DEBUG - 2024-02-12 12:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:30:05 --> Input Class Initialized
INFO - 2024-02-12 12:30:05 --> Language Class Initialized
INFO - 2024-02-12 12:30:05 --> Loader Class Initialized
INFO - 2024-02-12 12:30:05 --> Helper loaded: url_helper
INFO - 2024-02-12 12:30:05 --> Helper loaded: file_helper
INFO - 2024-02-12 12:30:05 --> Helper loaded: form_helper
INFO - 2024-02-12 12:30:05 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:30:05 --> Controller Class Initialized
INFO - 2024-02-12 12:30:05 --> Form Validation Class Initialized
INFO - 2024-02-12 12:30:05 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:30:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:30:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:30:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:30:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:30:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:30:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:30:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:30:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:30:05 --> Final output sent to browser
DEBUG - 2024-02-12 12:30:05 --> Total execution time: 0.0290
ERROR - 2024-02-12 12:30:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:30:05 --> Config Class Initialized
INFO - 2024-02-12 12:30:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:30:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:30:05 --> Utf8 Class Initialized
INFO - 2024-02-12 12:30:05 --> URI Class Initialized
INFO - 2024-02-12 12:30:05 --> Router Class Initialized
INFO - 2024-02-12 12:30:05 --> Output Class Initialized
INFO - 2024-02-12 12:30:05 --> Security Class Initialized
DEBUG - 2024-02-12 12:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:30:05 --> Input Class Initialized
INFO - 2024-02-12 12:30:05 --> Language Class Initialized
INFO - 2024-02-12 12:30:05 --> Loader Class Initialized
INFO - 2024-02-12 12:30:05 --> Helper loaded: url_helper
INFO - 2024-02-12 12:30:05 --> Helper loaded: file_helper
INFO - 2024-02-12 12:30:05 --> Helper loaded: form_helper
INFO - 2024-02-12 12:30:05 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:30:05 --> Controller Class Initialized
INFO - 2024-02-12 12:30:05 --> Form Validation Class Initialized
INFO - 2024-02-12 12:30:05 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:30:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:30:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:30:05 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:30:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:30:08 --> Config Class Initialized
INFO - 2024-02-12 12:30:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:30:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:30:08 --> Utf8 Class Initialized
INFO - 2024-02-12 12:30:08 --> URI Class Initialized
INFO - 2024-02-12 12:30:08 --> Router Class Initialized
INFO - 2024-02-12 12:30:08 --> Output Class Initialized
INFO - 2024-02-12 12:30:08 --> Security Class Initialized
DEBUG - 2024-02-12 12:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:30:08 --> Input Class Initialized
INFO - 2024-02-12 12:30:08 --> Language Class Initialized
INFO - 2024-02-12 12:30:08 --> Loader Class Initialized
INFO - 2024-02-12 12:30:08 --> Helper loaded: url_helper
INFO - 2024-02-12 12:30:08 --> Helper loaded: file_helper
INFO - 2024-02-12 12:30:08 --> Helper loaded: form_helper
INFO - 2024-02-12 12:30:08 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:30:08 --> Controller Class Initialized
INFO - 2024-02-12 12:30:08 --> Form Validation Class Initialized
INFO - 2024-02-12 12:30:08 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:30:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:30:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:30:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:30:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:30:08 --> Final output sent to browser
DEBUG - 2024-02-12 12:30:08 --> Total execution time: 0.0417
ERROR - 2024-02-12 12:30:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:30:50 --> Config Class Initialized
INFO - 2024-02-12 12:30:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:30:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:30:50 --> Utf8 Class Initialized
INFO - 2024-02-12 12:30:50 --> URI Class Initialized
INFO - 2024-02-12 12:30:50 --> Router Class Initialized
INFO - 2024-02-12 12:30:50 --> Output Class Initialized
INFO - 2024-02-12 12:30:50 --> Security Class Initialized
DEBUG - 2024-02-12 12:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:30:50 --> Input Class Initialized
INFO - 2024-02-12 12:30:50 --> Language Class Initialized
INFO - 2024-02-12 12:30:50 --> Loader Class Initialized
INFO - 2024-02-12 12:30:50 --> Helper loaded: url_helper
INFO - 2024-02-12 12:30:50 --> Helper loaded: file_helper
INFO - 2024-02-12 12:30:50 --> Helper loaded: form_helper
INFO - 2024-02-12 12:30:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:30:50 --> Controller Class Initialized
INFO - 2024-02-12 12:30:50 --> Form Validation Class Initialized
INFO - 2024-02-12 12:30:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:30:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:30:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:30:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:30:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:30:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:30:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:30:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:30:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:30:50 --> Final output sent to browser
DEBUG - 2024-02-12 12:30:50 --> Total execution time: 0.0245
ERROR - 2024-02-12 12:30:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:30:50 --> Config Class Initialized
INFO - 2024-02-12 12:30:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:30:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:30:50 --> Utf8 Class Initialized
INFO - 2024-02-12 12:30:50 --> URI Class Initialized
INFO - 2024-02-12 12:30:50 --> Router Class Initialized
INFO - 2024-02-12 12:30:50 --> Output Class Initialized
INFO - 2024-02-12 12:30:50 --> Security Class Initialized
DEBUG - 2024-02-12 12:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:30:50 --> Input Class Initialized
INFO - 2024-02-12 12:30:50 --> Language Class Initialized
INFO - 2024-02-12 12:30:50 --> Loader Class Initialized
INFO - 2024-02-12 12:30:50 --> Helper loaded: url_helper
INFO - 2024-02-12 12:30:50 --> Helper loaded: file_helper
INFO - 2024-02-12 12:30:50 --> Helper loaded: form_helper
INFO - 2024-02-12 12:30:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:30:50 --> Controller Class Initialized
INFO - 2024-02-12 12:30:50 --> Form Validation Class Initialized
INFO - 2024-02-12 12:30:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:30:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:30:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:30:50 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:30:52 --> Config Class Initialized
INFO - 2024-02-12 12:30:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:30:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:30:52 --> Utf8 Class Initialized
INFO - 2024-02-12 12:30:52 --> URI Class Initialized
INFO - 2024-02-12 12:30:52 --> Router Class Initialized
INFO - 2024-02-12 12:30:52 --> Output Class Initialized
INFO - 2024-02-12 12:30:52 --> Security Class Initialized
DEBUG - 2024-02-12 12:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:30:52 --> Input Class Initialized
INFO - 2024-02-12 12:30:52 --> Language Class Initialized
INFO - 2024-02-12 12:30:52 --> Loader Class Initialized
INFO - 2024-02-12 12:30:52 --> Helper loaded: url_helper
INFO - 2024-02-12 12:30:52 --> Helper loaded: file_helper
INFO - 2024-02-12 12:30:52 --> Helper loaded: form_helper
INFO - 2024-02-12 12:30:52 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:30:52 --> Controller Class Initialized
INFO - 2024-02-12 12:30:52 --> Form Validation Class Initialized
INFO - 2024-02-12 12:30:52 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:30:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:30:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:30:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:30:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:30:52 --> Final output sent to browser
DEBUG - 2024-02-12 12:30:52 --> Total execution time: 0.0307
ERROR - 2024-02-12 12:31:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:31:25 --> Config Class Initialized
INFO - 2024-02-12 12:31:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:31:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:31:25 --> Utf8 Class Initialized
INFO - 2024-02-12 12:31:25 --> URI Class Initialized
INFO - 2024-02-12 12:31:25 --> Router Class Initialized
INFO - 2024-02-12 12:31:25 --> Output Class Initialized
INFO - 2024-02-12 12:31:25 --> Security Class Initialized
DEBUG - 2024-02-12 12:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:31:25 --> Input Class Initialized
INFO - 2024-02-12 12:31:25 --> Language Class Initialized
INFO - 2024-02-12 12:31:25 --> Loader Class Initialized
INFO - 2024-02-12 12:31:25 --> Helper loaded: url_helper
INFO - 2024-02-12 12:31:25 --> Helper loaded: file_helper
INFO - 2024-02-12 12:31:25 --> Helper loaded: form_helper
INFO - 2024-02-12 12:31:25 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:31:25 --> Controller Class Initialized
INFO - 2024-02-12 12:31:25 --> Form Validation Class Initialized
INFO - 2024-02-12 12:31:25 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:31:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:31:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:31:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:31:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:31:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:31:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:31:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:31:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:31:25 --> Final output sent to browser
DEBUG - 2024-02-12 12:31:25 --> Total execution time: 0.0359
ERROR - 2024-02-12 12:31:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:31:25 --> Config Class Initialized
INFO - 2024-02-12 12:31:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:31:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:31:25 --> Utf8 Class Initialized
INFO - 2024-02-12 12:31:25 --> URI Class Initialized
INFO - 2024-02-12 12:31:25 --> Router Class Initialized
INFO - 2024-02-12 12:31:25 --> Output Class Initialized
INFO - 2024-02-12 12:31:25 --> Security Class Initialized
DEBUG - 2024-02-12 12:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:31:25 --> Input Class Initialized
INFO - 2024-02-12 12:31:25 --> Language Class Initialized
INFO - 2024-02-12 12:31:25 --> Loader Class Initialized
INFO - 2024-02-12 12:31:25 --> Helper loaded: url_helper
INFO - 2024-02-12 12:31:25 --> Helper loaded: file_helper
INFO - 2024-02-12 12:31:25 --> Helper loaded: form_helper
INFO - 2024-02-12 12:31:25 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:31:25 --> Controller Class Initialized
INFO - 2024-02-12 12:31:25 --> Form Validation Class Initialized
INFO - 2024-02-12 12:31:25 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:31:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:31:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:31:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:31:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:31:28 --> Config Class Initialized
INFO - 2024-02-12 12:31:28 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:31:28 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:31:28 --> Utf8 Class Initialized
INFO - 2024-02-12 12:31:28 --> URI Class Initialized
INFO - 2024-02-12 12:31:28 --> Router Class Initialized
INFO - 2024-02-12 12:31:28 --> Output Class Initialized
INFO - 2024-02-12 12:31:28 --> Security Class Initialized
DEBUG - 2024-02-12 12:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:31:28 --> Input Class Initialized
INFO - 2024-02-12 12:31:28 --> Language Class Initialized
INFO - 2024-02-12 12:31:28 --> Loader Class Initialized
INFO - 2024-02-12 12:31:28 --> Helper loaded: url_helper
INFO - 2024-02-12 12:31:28 --> Helper loaded: file_helper
INFO - 2024-02-12 12:31:28 --> Helper loaded: form_helper
INFO - 2024-02-12 12:31:28 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:31:28 --> Controller Class Initialized
INFO - 2024-02-12 12:31:28 --> Form Validation Class Initialized
INFO - 2024-02-12 12:31:28 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:31:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:31:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:31:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:31:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:31:28 --> Final output sent to browser
DEBUG - 2024-02-12 12:31:28 --> Total execution time: 0.0316
ERROR - 2024-02-12 12:31:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:31:47 --> Config Class Initialized
INFO - 2024-02-12 12:31:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:31:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:31:47 --> Utf8 Class Initialized
INFO - 2024-02-12 12:31:47 --> URI Class Initialized
INFO - 2024-02-12 12:31:47 --> Router Class Initialized
INFO - 2024-02-12 12:31:47 --> Output Class Initialized
INFO - 2024-02-12 12:31:47 --> Security Class Initialized
DEBUG - 2024-02-12 12:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:31:47 --> Input Class Initialized
INFO - 2024-02-12 12:31:47 --> Language Class Initialized
INFO - 2024-02-12 12:31:47 --> Loader Class Initialized
INFO - 2024-02-12 12:31:47 --> Helper loaded: url_helper
INFO - 2024-02-12 12:31:47 --> Helper loaded: file_helper
INFO - 2024-02-12 12:31:47 --> Helper loaded: form_helper
INFO - 2024-02-12 12:31:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:31:47 --> Controller Class Initialized
INFO - 2024-02-12 12:31:47 --> Form Validation Class Initialized
INFO - 2024-02-12 12:31:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:31:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:31:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:31:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:31:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:31:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:31:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:31:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:31:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:31:47 --> Final output sent to browser
DEBUG - 2024-02-12 12:31:47 --> Total execution time: 0.0319
ERROR - 2024-02-12 12:31:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:31:47 --> Config Class Initialized
INFO - 2024-02-12 12:31:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:31:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:31:47 --> Utf8 Class Initialized
INFO - 2024-02-12 12:31:47 --> URI Class Initialized
INFO - 2024-02-12 12:31:47 --> Router Class Initialized
INFO - 2024-02-12 12:31:47 --> Output Class Initialized
INFO - 2024-02-12 12:31:47 --> Security Class Initialized
DEBUG - 2024-02-12 12:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:31:47 --> Input Class Initialized
INFO - 2024-02-12 12:31:47 --> Language Class Initialized
INFO - 2024-02-12 12:31:47 --> Loader Class Initialized
INFO - 2024-02-12 12:31:47 --> Helper loaded: url_helper
INFO - 2024-02-12 12:31:47 --> Helper loaded: file_helper
INFO - 2024-02-12 12:31:47 --> Helper loaded: form_helper
INFO - 2024-02-12 12:31:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:31:47 --> Controller Class Initialized
INFO - 2024-02-12 12:31:47 --> Form Validation Class Initialized
INFO - 2024-02-12 12:31:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:31:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:31:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:31:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:31:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:31:49 --> Config Class Initialized
INFO - 2024-02-12 12:31:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:31:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:31:49 --> Utf8 Class Initialized
INFO - 2024-02-12 12:31:49 --> URI Class Initialized
INFO - 2024-02-12 12:31:49 --> Router Class Initialized
INFO - 2024-02-12 12:31:49 --> Output Class Initialized
INFO - 2024-02-12 12:31:49 --> Security Class Initialized
DEBUG - 2024-02-12 12:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:31:49 --> Input Class Initialized
INFO - 2024-02-12 12:31:49 --> Language Class Initialized
INFO - 2024-02-12 12:31:49 --> Loader Class Initialized
INFO - 2024-02-12 12:31:49 --> Helper loaded: url_helper
INFO - 2024-02-12 12:31:49 --> Helper loaded: file_helper
INFO - 2024-02-12 12:31:49 --> Helper loaded: form_helper
INFO - 2024-02-12 12:31:49 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:31:49 --> Controller Class Initialized
INFO - 2024-02-12 12:31:49 --> Form Validation Class Initialized
INFO - 2024-02-12 12:31:49 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:31:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:31:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:31:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:31:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:31:49 --> Final output sent to browser
DEBUG - 2024-02-12 12:31:49 --> Total execution time: 0.0253
ERROR - 2024-02-12 12:34:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:34:03 --> Config Class Initialized
INFO - 2024-02-12 12:34:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:34:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:34:03 --> Utf8 Class Initialized
INFO - 2024-02-12 12:34:03 --> URI Class Initialized
INFO - 2024-02-12 12:34:03 --> Router Class Initialized
INFO - 2024-02-12 12:34:03 --> Output Class Initialized
INFO - 2024-02-12 12:34:03 --> Security Class Initialized
DEBUG - 2024-02-12 12:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:34:03 --> Input Class Initialized
INFO - 2024-02-12 12:34:03 --> Language Class Initialized
INFO - 2024-02-12 12:34:03 --> Loader Class Initialized
INFO - 2024-02-12 12:34:03 --> Helper loaded: url_helper
INFO - 2024-02-12 12:34:03 --> Helper loaded: file_helper
INFO - 2024-02-12 12:34:03 --> Helper loaded: form_helper
INFO - 2024-02-12 12:34:03 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:34:03 --> Controller Class Initialized
INFO - 2024-02-12 12:34:03 --> Form Validation Class Initialized
INFO - 2024-02-12 12:34:03 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:34:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:34:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:34:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:34:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:34:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:34:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:34:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:34:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:34:03 --> Final output sent to browser
DEBUG - 2024-02-12 12:34:03 --> Total execution time: 0.0308
ERROR - 2024-02-12 12:34:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:34:03 --> Config Class Initialized
INFO - 2024-02-12 12:34:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:34:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:34:03 --> Utf8 Class Initialized
INFO - 2024-02-12 12:34:03 --> URI Class Initialized
INFO - 2024-02-12 12:34:03 --> Router Class Initialized
INFO - 2024-02-12 12:34:03 --> Output Class Initialized
INFO - 2024-02-12 12:34:03 --> Security Class Initialized
DEBUG - 2024-02-12 12:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:34:03 --> Input Class Initialized
INFO - 2024-02-12 12:34:03 --> Language Class Initialized
INFO - 2024-02-12 12:34:03 --> Loader Class Initialized
INFO - 2024-02-12 12:34:03 --> Helper loaded: url_helper
INFO - 2024-02-12 12:34:03 --> Helper loaded: file_helper
INFO - 2024-02-12 12:34:03 --> Helper loaded: form_helper
INFO - 2024-02-12 12:34:03 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:34:03 --> Controller Class Initialized
INFO - 2024-02-12 12:34:03 --> Form Validation Class Initialized
INFO - 2024-02-12 12:34:03 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:34:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:34:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:34:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:34:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:34:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:34:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:34:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:34:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:34:03 --> Final output sent to browser
DEBUG - 2024-02-12 12:34:03 --> Total execution time: 0.0584
ERROR - 2024-02-12 12:34:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:34:03 --> Config Class Initialized
INFO - 2024-02-12 12:34:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:34:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:34:03 --> Utf8 Class Initialized
INFO - 2024-02-12 12:34:03 --> URI Class Initialized
INFO - 2024-02-12 12:34:03 --> Router Class Initialized
INFO - 2024-02-12 12:34:03 --> Output Class Initialized
INFO - 2024-02-12 12:34:04 --> Security Class Initialized
DEBUG - 2024-02-12 12:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:34:04 --> Input Class Initialized
INFO - 2024-02-12 12:34:04 --> Language Class Initialized
INFO - 2024-02-12 12:34:04 --> Loader Class Initialized
INFO - 2024-02-12 12:34:04 --> Helper loaded: url_helper
INFO - 2024-02-12 12:34:04 --> Helper loaded: file_helper
INFO - 2024-02-12 12:34:04 --> Helper loaded: form_helper
INFO - 2024-02-12 12:34:04 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:34:04 --> Controller Class Initialized
INFO - 2024-02-12 12:34:04 --> Form Validation Class Initialized
INFO - 2024-02-12 12:34:04 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:34:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:34:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:34:04 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:34:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:34:04 --> Config Class Initialized
INFO - 2024-02-12 12:34:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:34:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:34:04 --> Utf8 Class Initialized
INFO - 2024-02-12 12:34:04 --> URI Class Initialized
INFO - 2024-02-12 12:34:04 --> Router Class Initialized
INFO - 2024-02-12 12:34:04 --> Output Class Initialized
INFO - 2024-02-12 12:34:04 --> Security Class Initialized
DEBUG - 2024-02-12 12:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:34:04 --> Input Class Initialized
INFO - 2024-02-12 12:34:04 --> Language Class Initialized
INFO - 2024-02-12 12:34:04 --> Loader Class Initialized
INFO - 2024-02-12 12:34:04 --> Helper loaded: url_helper
INFO - 2024-02-12 12:34:04 --> Helper loaded: file_helper
INFO - 2024-02-12 12:34:04 --> Helper loaded: form_helper
INFO - 2024-02-12 12:34:04 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:34:04 --> Controller Class Initialized
INFO - 2024-02-12 12:34:04 --> Form Validation Class Initialized
INFO - 2024-02-12 12:34:04 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:34:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:34:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:34:04 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:34:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:34:06 --> Config Class Initialized
INFO - 2024-02-12 12:34:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:34:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:34:06 --> Utf8 Class Initialized
INFO - 2024-02-12 12:34:06 --> URI Class Initialized
INFO - 2024-02-12 12:34:06 --> Router Class Initialized
INFO - 2024-02-12 12:34:06 --> Output Class Initialized
INFO - 2024-02-12 12:34:06 --> Security Class Initialized
DEBUG - 2024-02-12 12:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:34:06 --> Input Class Initialized
INFO - 2024-02-12 12:34:06 --> Language Class Initialized
INFO - 2024-02-12 12:34:06 --> Loader Class Initialized
INFO - 2024-02-12 12:34:06 --> Helper loaded: url_helper
INFO - 2024-02-12 12:34:06 --> Helper loaded: file_helper
INFO - 2024-02-12 12:34:06 --> Helper loaded: form_helper
INFO - 2024-02-12 12:34:06 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:34:06 --> Controller Class Initialized
INFO - 2024-02-12 12:34:06 --> Form Validation Class Initialized
INFO - 2024-02-12 12:34:06 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:34:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:34:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:34:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:34:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:34:06 --> Final output sent to browser
DEBUG - 2024-02-12 12:34:06 --> Total execution time: 0.0352
ERROR - 2024-02-12 12:34:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:34:40 --> Config Class Initialized
INFO - 2024-02-12 12:34:40 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:34:40 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:34:40 --> Utf8 Class Initialized
INFO - 2024-02-12 12:34:40 --> URI Class Initialized
INFO - 2024-02-12 12:34:40 --> Router Class Initialized
INFO - 2024-02-12 12:34:40 --> Output Class Initialized
INFO - 2024-02-12 12:34:40 --> Security Class Initialized
DEBUG - 2024-02-12 12:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:34:40 --> Input Class Initialized
INFO - 2024-02-12 12:34:40 --> Language Class Initialized
INFO - 2024-02-12 12:34:40 --> Loader Class Initialized
INFO - 2024-02-12 12:34:40 --> Helper loaded: url_helper
INFO - 2024-02-12 12:34:40 --> Helper loaded: file_helper
INFO - 2024-02-12 12:34:40 --> Helper loaded: form_helper
INFO - 2024-02-12 12:34:40 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:34:40 --> Controller Class Initialized
INFO - 2024-02-12 12:34:40 --> Form Validation Class Initialized
INFO - 2024-02-12 12:34:40 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:34:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:34:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:34:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:34:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:34:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:34:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:34:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:34:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:34:40 --> Final output sent to browser
DEBUG - 2024-02-12 12:34:40 --> Total execution time: 0.0293
ERROR - 2024-02-12 12:34:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:34:40 --> Config Class Initialized
INFO - 2024-02-12 12:34:40 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:34:40 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:34:40 --> Utf8 Class Initialized
INFO - 2024-02-12 12:34:40 --> URI Class Initialized
INFO - 2024-02-12 12:34:40 --> Router Class Initialized
INFO - 2024-02-12 12:34:40 --> Output Class Initialized
INFO - 2024-02-12 12:34:40 --> Security Class Initialized
DEBUG - 2024-02-12 12:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:34:40 --> Input Class Initialized
INFO - 2024-02-12 12:34:40 --> Language Class Initialized
INFO - 2024-02-12 12:34:40 --> Loader Class Initialized
INFO - 2024-02-12 12:34:40 --> Helper loaded: url_helper
INFO - 2024-02-12 12:34:40 --> Helper loaded: file_helper
INFO - 2024-02-12 12:34:40 --> Helper loaded: form_helper
INFO - 2024-02-12 12:34:40 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:34:40 --> Controller Class Initialized
INFO - 2024-02-12 12:34:40 --> Form Validation Class Initialized
INFO - 2024-02-12 12:34:40 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:34:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:34:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:34:40 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:34:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:34:42 --> Config Class Initialized
INFO - 2024-02-12 12:34:42 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:34:42 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:34:42 --> Utf8 Class Initialized
INFO - 2024-02-12 12:34:42 --> URI Class Initialized
INFO - 2024-02-12 12:34:42 --> Router Class Initialized
INFO - 2024-02-12 12:34:42 --> Output Class Initialized
INFO - 2024-02-12 12:34:42 --> Security Class Initialized
DEBUG - 2024-02-12 12:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:34:42 --> Input Class Initialized
INFO - 2024-02-12 12:34:42 --> Language Class Initialized
INFO - 2024-02-12 12:34:42 --> Loader Class Initialized
INFO - 2024-02-12 12:34:42 --> Helper loaded: url_helper
INFO - 2024-02-12 12:34:42 --> Helper loaded: file_helper
INFO - 2024-02-12 12:34:42 --> Helper loaded: form_helper
INFO - 2024-02-12 12:34:42 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:34:42 --> Controller Class Initialized
INFO - 2024-02-12 12:34:42 --> Form Validation Class Initialized
INFO - 2024-02-12 12:34:42 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:34:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:34:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:34:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:34:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:34:42 --> Final output sent to browser
DEBUG - 2024-02-12 12:34:42 --> Total execution time: 0.0365
ERROR - 2024-02-12 12:34:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:34:59 --> Config Class Initialized
INFO - 2024-02-12 12:34:59 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:34:59 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:34:59 --> Utf8 Class Initialized
INFO - 2024-02-12 12:34:59 --> URI Class Initialized
INFO - 2024-02-12 12:34:59 --> Router Class Initialized
INFO - 2024-02-12 12:34:59 --> Output Class Initialized
INFO - 2024-02-12 12:34:59 --> Security Class Initialized
DEBUG - 2024-02-12 12:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:34:59 --> Input Class Initialized
INFO - 2024-02-12 12:34:59 --> Language Class Initialized
INFO - 2024-02-12 12:34:59 --> Loader Class Initialized
INFO - 2024-02-12 12:34:59 --> Helper loaded: url_helper
INFO - 2024-02-12 12:34:59 --> Helper loaded: file_helper
INFO - 2024-02-12 12:34:59 --> Helper loaded: form_helper
INFO - 2024-02-12 12:34:59 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:34:59 --> Controller Class Initialized
INFO - 2024-02-12 12:34:59 --> Form Validation Class Initialized
INFO - 2024-02-12 12:34:59 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:34:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:34:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:34:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:34:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:34:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:34:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:34:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:34:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:34:59 --> Final output sent to browser
DEBUG - 2024-02-12 12:34:59 --> Total execution time: 0.0313
ERROR - 2024-02-12 12:34:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:34:59 --> Config Class Initialized
INFO - 2024-02-12 12:34:59 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:34:59 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:34:59 --> Utf8 Class Initialized
INFO - 2024-02-12 12:34:59 --> URI Class Initialized
INFO - 2024-02-12 12:34:59 --> Router Class Initialized
INFO - 2024-02-12 12:34:59 --> Output Class Initialized
INFO - 2024-02-12 12:34:59 --> Security Class Initialized
DEBUG - 2024-02-12 12:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:34:59 --> Input Class Initialized
INFO - 2024-02-12 12:34:59 --> Language Class Initialized
INFO - 2024-02-12 12:34:59 --> Loader Class Initialized
INFO - 2024-02-12 12:34:59 --> Helper loaded: url_helper
INFO - 2024-02-12 12:34:59 --> Helper loaded: file_helper
INFO - 2024-02-12 12:34:59 --> Helper loaded: form_helper
INFO - 2024-02-12 12:34:59 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:34:59 --> Controller Class Initialized
INFO - 2024-02-12 12:34:59 --> Form Validation Class Initialized
INFO - 2024-02-12 12:34:59 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:34:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:34:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:34:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:35:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:35:02 --> Config Class Initialized
INFO - 2024-02-12 12:35:02 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:35:02 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:35:02 --> Utf8 Class Initialized
INFO - 2024-02-12 12:35:02 --> URI Class Initialized
INFO - 2024-02-12 12:35:02 --> Router Class Initialized
INFO - 2024-02-12 12:35:02 --> Output Class Initialized
INFO - 2024-02-12 12:35:02 --> Security Class Initialized
DEBUG - 2024-02-12 12:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:35:02 --> Input Class Initialized
INFO - 2024-02-12 12:35:02 --> Language Class Initialized
INFO - 2024-02-12 12:35:02 --> Loader Class Initialized
INFO - 2024-02-12 12:35:02 --> Helper loaded: url_helper
INFO - 2024-02-12 12:35:02 --> Helper loaded: file_helper
INFO - 2024-02-12 12:35:02 --> Helper loaded: form_helper
INFO - 2024-02-12 12:35:02 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:35:02 --> Controller Class Initialized
INFO - 2024-02-12 12:35:02 --> Form Validation Class Initialized
INFO - 2024-02-12 12:35:02 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:35:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:35:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:35:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:35:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:35:02 --> Final output sent to browser
DEBUG - 2024-02-12 12:35:02 --> Total execution time: 0.0382
ERROR - 2024-02-12 12:36:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:36:05 --> Config Class Initialized
INFO - 2024-02-12 12:36:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:36:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:36:05 --> Utf8 Class Initialized
INFO - 2024-02-12 12:36:05 --> URI Class Initialized
INFO - 2024-02-12 12:36:05 --> Router Class Initialized
INFO - 2024-02-12 12:36:05 --> Output Class Initialized
INFO - 2024-02-12 12:36:05 --> Security Class Initialized
DEBUG - 2024-02-12 12:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:36:05 --> Input Class Initialized
INFO - 2024-02-12 12:36:05 --> Language Class Initialized
INFO - 2024-02-12 12:36:05 --> Loader Class Initialized
INFO - 2024-02-12 12:36:05 --> Helper loaded: url_helper
INFO - 2024-02-12 12:36:05 --> Helper loaded: file_helper
INFO - 2024-02-12 12:36:05 --> Helper loaded: form_helper
INFO - 2024-02-12 12:36:05 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:36:05 --> Controller Class Initialized
INFO - 2024-02-12 12:36:05 --> Form Validation Class Initialized
INFO - 2024-02-12 12:36:05 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:36:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:36:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:36:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:36:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:36:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:36:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:36:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:36:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:36:05 --> Final output sent to browser
DEBUG - 2024-02-12 12:36:05 --> Total execution time: 0.0324
ERROR - 2024-02-12 12:36:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:36:05 --> Config Class Initialized
INFO - 2024-02-12 12:36:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:36:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:36:05 --> Utf8 Class Initialized
INFO - 2024-02-12 12:36:05 --> URI Class Initialized
INFO - 2024-02-12 12:36:05 --> Router Class Initialized
INFO - 2024-02-12 12:36:05 --> Output Class Initialized
INFO - 2024-02-12 12:36:05 --> Security Class Initialized
DEBUG - 2024-02-12 12:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:36:05 --> Input Class Initialized
INFO - 2024-02-12 12:36:05 --> Language Class Initialized
INFO - 2024-02-12 12:36:05 --> Loader Class Initialized
INFO - 2024-02-12 12:36:05 --> Helper loaded: url_helper
INFO - 2024-02-12 12:36:05 --> Helper loaded: file_helper
INFO - 2024-02-12 12:36:05 --> Helper loaded: form_helper
INFO - 2024-02-12 12:36:05 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:36:05 --> Controller Class Initialized
INFO - 2024-02-12 12:36:05 --> Form Validation Class Initialized
INFO - 2024-02-12 12:36:05 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:36:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:36:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:36:05 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:36:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:36:08 --> Config Class Initialized
INFO - 2024-02-12 12:36:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:36:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:36:08 --> Utf8 Class Initialized
INFO - 2024-02-12 12:36:08 --> URI Class Initialized
INFO - 2024-02-12 12:36:08 --> Router Class Initialized
INFO - 2024-02-12 12:36:08 --> Output Class Initialized
INFO - 2024-02-12 12:36:08 --> Security Class Initialized
DEBUG - 2024-02-12 12:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:36:08 --> Input Class Initialized
INFO - 2024-02-12 12:36:08 --> Language Class Initialized
INFO - 2024-02-12 12:36:08 --> Loader Class Initialized
INFO - 2024-02-12 12:36:08 --> Helper loaded: url_helper
INFO - 2024-02-12 12:36:08 --> Helper loaded: file_helper
INFO - 2024-02-12 12:36:08 --> Helper loaded: form_helper
INFO - 2024-02-12 12:36:08 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:36:08 --> Controller Class Initialized
INFO - 2024-02-12 12:36:08 --> Form Validation Class Initialized
INFO - 2024-02-12 12:36:08 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:36:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:36:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:36:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:36:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:36:08 --> Final output sent to browser
DEBUG - 2024-02-12 12:36:08 --> Total execution time: 0.0303
ERROR - 2024-02-12 12:36:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:36:42 --> Config Class Initialized
INFO - 2024-02-12 12:36:42 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:36:42 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:36:42 --> Utf8 Class Initialized
INFO - 2024-02-12 12:36:42 --> URI Class Initialized
INFO - 2024-02-12 12:36:42 --> Router Class Initialized
INFO - 2024-02-12 12:36:42 --> Output Class Initialized
INFO - 2024-02-12 12:36:42 --> Security Class Initialized
DEBUG - 2024-02-12 12:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:36:42 --> Input Class Initialized
INFO - 2024-02-12 12:36:42 --> Language Class Initialized
INFO - 2024-02-12 12:36:42 --> Loader Class Initialized
INFO - 2024-02-12 12:36:42 --> Helper loaded: url_helper
INFO - 2024-02-12 12:36:42 --> Helper loaded: file_helper
INFO - 2024-02-12 12:36:42 --> Helper loaded: form_helper
INFO - 2024-02-12 12:36:42 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:36:42 --> Controller Class Initialized
INFO - 2024-02-12 12:36:42 --> Form Validation Class Initialized
INFO - 2024-02-12 12:36:42 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:36:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:36:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:36:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:36:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:36:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:36:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:36:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:36:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:36:42 --> Final output sent to browser
DEBUG - 2024-02-12 12:36:42 --> Total execution time: 0.0275
ERROR - 2024-02-12 12:36:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:36:42 --> Config Class Initialized
INFO - 2024-02-12 12:36:42 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:36:42 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:36:42 --> Utf8 Class Initialized
INFO - 2024-02-12 12:36:42 --> URI Class Initialized
INFO - 2024-02-12 12:36:42 --> Router Class Initialized
INFO - 2024-02-12 12:36:42 --> Output Class Initialized
INFO - 2024-02-12 12:36:42 --> Security Class Initialized
DEBUG - 2024-02-12 12:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:36:42 --> Input Class Initialized
INFO - 2024-02-12 12:36:42 --> Language Class Initialized
INFO - 2024-02-12 12:36:42 --> Loader Class Initialized
INFO - 2024-02-12 12:36:42 --> Helper loaded: url_helper
INFO - 2024-02-12 12:36:42 --> Helper loaded: file_helper
INFO - 2024-02-12 12:36:42 --> Helper loaded: form_helper
INFO - 2024-02-12 12:36:42 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:36:42 --> Controller Class Initialized
INFO - 2024-02-12 12:36:42 --> Form Validation Class Initialized
INFO - 2024-02-12 12:36:42 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:36:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:36:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:36:42 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:36:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:36:44 --> Config Class Initialized
INFO - 2024-02-12 12:36:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:36:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:36:44 --> Utf8 Class Initialized
INFO - 2024-02-12 12:36:44 --> URI Class Initialized
INFO - 2024-02-12 12:36:44 --> Router Class Initialized
INFO - 2024-02-12 12:36:44 --> Output Class Initialized
INFO - 2024-02-12 12:36:44 --> Security Class Initialized
DEBUG - 2024-02-12 12:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:36:44 --> Input Class Initialized
INFO - 2024-02-12 12:36:44 --> Language Class Initialized
INFO - 2024-02-12 12:36:44 --> Loader Class Initialized
INFO - 2024-02-12 12:36:44 --> Helper loaded: url_helper
INFO - 2024-02-12 12:36:44 --> Helper loaded: file_helper
INFO - 2024-02-12 12:36:44 --> Helper loaded: form_helper
INFO - 2024-02-12 12:36:44 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:36:44 --> Controller Class Initialized
INFO - 2024-02-12 12:36:44 --> Form Validation Class Initialized
INFO - 2024-02-12 12:36:44 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:36:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:36:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:36:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:36:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:36:44 --> Final output sent to browser
DEBUG - 2024-02-12 12:36:44 --> Total execution time: 0.0378
ERROR - 2024-02-12 12:37:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:37:11 --> Config Class Initialized
INFO - 2024-02-12 12:37:11 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:37:11 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:37:11 --> Utf8 Class Initialized
INFO - 2024-02-12 12:37:11 --> URI Class Initialized
INFO - 2024-02-12 12:37:11 --> Router Class Initialized
INFO - 2024-02-12 12:37:11 --> Output Class Initialized
INFO - 2024-02-12 12:37:11 --> Security Class Initialized
DEBUG - 2024-02-12 12:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:37:11 --> Input Class Initialized
INFO - 2024-02-12 12:37:11 --> Language Class Initialized
INFO - 2024-02-12 12:37:11 --> Loader Class Initialized
INFO - 2024-02-12 12:37:11 --> Helper loaded: url_helper
INFO - 2024-02-12 12:37:11 --> Helper loaded: file_helper
INFO - 2024-02-12 12:37:11 --> Helper loaded: form_helper
INFO - 2024-02-12 12:37:11 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:37:11 --> Controller Class Initialized
INFO - 2024-02-12 12:37:11 --> Form Validation Class Initialized
INFO - 2024-02-12 12:37:11 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:37:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:37:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:37:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:37:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:37:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:37:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:37:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:37:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:37:11 --> Final output sent to browser
DEBUG - 2024-02-12 12:37:11 --> Total execution time: 0.0348
ERROR - 2024-02-12 12:37:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:37:12 --> Config Class Initialized
INFO - 2024-02-12 12:37:12 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:37:12 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:37:12 --> Utf8 Class Initialized
INFO - 2024-02-12 12:37:12 --> URI Class Initialized
INFO - 2024-02-12 12:37:12 --> Router Class Initialized
INFO - 2024-02-12 12:37:12 --> Output Class Initialized
INFO - 2024-02-12 12:37:12 --> Security Class Initialized
DEBUG - 2024-02-12 12:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:37:12 --> Input Class Initialized
INFO - 2024-02-12 12:37:12 --> Language Class Initialized
INFO - 2024-02-12 12:37:12 --> Loader Class Initialized
INFO - 2024-02-12 12:37:12 --> Helper loaded: url_helper
INFO - 2024-02-12 12:37:12 --> Helper loaded: file_helper
INFO - 2024-02-12 12:37:12 --> Helper loaded: form_helper
INFO - 2024-02-12 12:37:12 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:37:12 --> Controller Class Initialized
INFO - 2024-02-12 12:37:12 --> Form Validation Class Initialized
INFO - 2024-02-12 12:37:12 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:37:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:37:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:37:12 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:37:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:37:14 --> Config Class Initialized
INFO - 2024-02-12 12:37:14 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:37:14 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:37:14 --> Utf8 Class Initialized
INFO - 2024-02-12 12:37:14 --> URI Class Initialized
INFO - 2024-02-12 12:37:14 --> Router Class Initialized
INFO - 2024-02-12 12:37:14 --> Output Class Initialized
INFO - 2024-02-12 12:37:14 --> Security Class Initialized
DEBUG - 2024-02-12 12:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:37:14 --> Input Class Initialized
INFO - 2024-02-12 12:37:14 --> Language Class Initialized
INFO - 2024-02-12 12:37:14 --> Loader Class Initialized
INFO - 2024-02-12 12:37:14 --> Helper loaded: url_helper
INFO - 2024-02-12 12:37:14 --> Helper loaded: file_helper
INFO - 2024-02-12 12:37:14 --> Helper loaded: form_helper
INFO - 2024-02-12 12:37:14 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:37:14 --> Controller Class Initialized
INFO - 2024-02-12 12:37:14 --> Form Validation Class Initialized
INFO - 2024-02-12 12:37:14 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:37:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:37:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:37:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:37:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:37:14 --> Final output sent to browser
DEBUG - 2024-02-12 12:37:14 --> Total execution time: 0.0310
ERROR - 2024-02-12 12:37:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:37:38 --> Config Class Initialized
INFO - 2024-02-12 12:37:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:37:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:37:38 --> Utf8 Class Initialized
INFO - 2024-02-12 12:37:38 --> URI Class Initialized
INFO - 2024-02-12 12:37:38 --> Router Class Initialized
INFO - 2024-02-12 12:37:38 --> Output Class Initialized
INFO - 2024-02-12 12:37:38 --> Security Class Initialized
DEBUG - 2024-02-12 12:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:37:38 --> Input Class Initialized
INFO - 2024-02-12 12:37:38 --> Language Class Initialized
INFO - 2024-02-12 12:37:38 --> Loader Class Initialized
INFO - 2024-02-12 12:37:38 --> Helper loaded: url_helper
INFO - 2024-02-12 12:37:38 --> Helper loaded: file_helper
INFO - 2024-02-12 12:37:38 --> Helper loaded: form_helper
INFO - 2024-02-12 12:37:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:37:38 --> Controller Class Initialized
INFO - 2024-02-12 12:37:38 --> Form Validation Class Initialized
INFO - 2024-02-12 12:37:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:37:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:37:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:37:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:37:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:37:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:37:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:37:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:37:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:37:38 --> Final output sent to browser
DEBUG - 2024-02-12 12:37:38 --> Total execution time: 0.0326
ERROR - 2024-02-12 12:37:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:37:38 --> Config Class Initialized
INFO - 2024-02-12 12:37:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:37:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:37:38 --> Utf8 Class Initialized
INFO - 2024-02-12 12:37:38 --> URI Class Initialized
INFO - 2024-02-12 12:37:38 --> Router Class Initialized
INFO - 2024-02-12 12:37:38 --> Output Class Initialized
INFO - 2024-02-12 12:37:38 --> Security Class Initialized
DEBUG - 2024-02-12 12:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:37:38 --> Input Class Initialized
INFO - 2024-02-12 12:37:38 --> Language Class Initialized
INFO - 2024-02-12 12:37:38 --> Loader Class Initialized
INFO - 2024-02-12 12:37:38 --> Helper loaded: url_helper
INFO - 2024-02-12 12:37:38 --> Helper loaded: file_helper
INFO - 2024-02-12 12:37:38 --> Helper loaded: form_helper
INFO - 2024-02-12 12:37:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:37:38 --> Controller Class Initialized
INFO - 2024-02-12 12:37:38 --> Form Validation Class Initialized
INFO - 2024-02-12 12:37:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:37:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:37:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:37:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:37:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:37:40 --> Config Class Initialized
INFO - 2024-02-12 12:37:40 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:37:40 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:37:40 --> Utf8 Class Initialized
INFO - 2024-02-12 12:37:40 --> URI Class Initialized
INFO - 2024-02-12 12:37:40 --> Router Class Initialized
INFO - 2024-02-12 12:37:40 --> Output Class Initialized
INFO - 2024-02-12 12:37:40 --> Security Class Initialized
DEBUG - 2024-02-12 12:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:37:40 --> Input Class Initialized
INFO - 2024-02-12 12:37:40 --> Language Class Initialized
INFO - 2024-02-12 12:37:40 --> Loader Class Initialized
INFO - 2024-02-12 12:37:40 --> Helper loaded: url_helper
INFO - 2024-02-12 12:37:40 --> Helper loaded: file_helper
INFO - 2024-02-12 12:37:40 --> Helper loaded: form_helper
INFO - 2024-02-12 12:37:40 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:37:40 --> Controller Class Initialized
INFO - 2024-02-12 12:37:40 --> Form Validation Class Initialized
INFO - 2024-02-12 12:37:40 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:37:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:37:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:37:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:37:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:37:40 --> Final output sent to browser
DEBUG - 2024-02-12 12:37:40 --> Total execution time: 0.0320
ERROR - 2024-02-12 12:38:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:38:15 --> Config Class Initialized
INFO - 2024-02-12 12:38:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:38:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:38:15 --> Utf8 Class Initialized
INFO - 2024-02-12 12:38:15 --> URI Class Initialized
INFO - 2024-02-12 12:38:15 --> Router Class Initialized
INFO - 2024-02-12 12:38:15 --> Output Class Initialized
INFO - 2024-02-12 12:38:15 --> Security Class Initialized
DEBUG - 2024-02-12 12:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:38:15 --> Input Class Initialized
INFO - 2024-02-12 12:38:15 --> Language Class Initialized
INFO - 2024-02-12 12:38:15 --> Loader Class Initialized
INFO - 2024-02-12 12:38:15 --> Helper loaded: url_helper
INFO - 2024-02-12 12:38:15 --> Helper loaded: file_helper
INFO - 2024-02-12 12:38:15 --> Helper loaded: form_helper
INFO - 2024-02-12 12:38:15 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:38:15 --> Controller Class Initialized
INFO - 2024-02-12 12:38:15 --> Form Validation Class Initialized
INFO - 2024-02-12 12:38:15 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:38:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:38:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:38:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:38:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:38:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:38:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:38:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:38:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:38:15 --> Final output sent to browser
DEBUG - 2024-02-12 12:38:15 --> Total execution time: 0.0439
ERROR - 2024-02-12 12:38:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:38:15 --> Config Class Initialized
INFO - 2024-02-12 12:38:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:38:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:38:15 --> Utf8 Class Initialized
INFO - 2024-02-12 12:38:15 --> URI Class Initialized
INFO - 2024-02-12 12:38:15 --> Router Class Initialized
INFO - 2024-02-12 12:38:15 --> Output Class Initialized
INFO - 2024-02-12 12:38:15 --> Security Class Initialized
DEBUG - 2024-02-12 12:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:38:15 --> Input Class Initialized
INFO - 2024-02-12 12:38:15 --> Language Class Initialized
INFO - 2024-02-12 12:38:15 --> Loader Class Initialized
INFO - 2024-02-12 12:38:15 --> Helper loaded: url_helper
INFO - 2024-02-12 12:38:15 --> Helper loaded: file_helper
INFO - 2024-02-12 12:38:15 --> Helper loaded: form_helper
INFO - 2024-02-12 12:38:15 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:38:15 --> Controller Class Initialized
INFO - 2024-02-12 12:38:15 --> Form Validation Class Initialized
INFO - 2024-02-12 12:38:15 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:38:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:38:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:38:15 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:38:18 --> Config Class Initialized
INFO - 2024-02-12 12:38:18 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:38:18 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:38:18 --> Utf8 Class Initialized
INFO - 2024-02-12 12:38:18 --> URI Class Initialized
INFO - 2024-02-12 12:38:18 --> Router Class Initialized
INFO - 2024-02-12 12:38:18 --> Output Class Initialized
INFO - 2024-02-12 12:38:18 --> Security Class Initialized
DEBUG - 2024-02-12 12:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:38:18 --> Input Class Initialized
INFO - 2024-02-12 12:38:18 --> Language Class Initialized
INFO - 2024-02-12 12:38:18 --> Loader Class Initialized
INFO - 2024-02-12 12:38:18 --> Helper loaded: url_helper
INFO - 2024-02-12 12:38:18 --> Helper loaded: file_helper
INFO - 2024-02-12 12:38:18 --> Helper loaded: form_helper
INFO - 2024-02-12 12:38:18 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:38:18 --> Controller Class Initialized
INFO - 2024-02-12 12:38:18 --> Form Validation Class Initialized
INFO - 2024-02-12 12:38:18 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:38:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:38:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:38:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:38:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:38:18 --> Final output sent to browser
DEBUG - 2024-02-12 12:38:18 --> Total execution time: 0.0325
ERROR - 2024-02-12 12:38:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:38:43 --> Config Class Initialized
INFO - 2024-02-12 12:38:43 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:38:43 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:38:43 --> Utf8 Class Initialized
INFO - 2024-02-12 12:38:43 --> URI Class Initialized
INFO - 2024-02-12 12:38:43 --> Router Class Initialized
INFO - 2024-02-12 12:38:43 --> Output Class Initialized
INFO - 2024-02-12 12:38:43 --> Security Class Initialized
DEBUG - 2024-02-12 12:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:38:43 --> Input Class Initialized
INFO - 2024-02-12 12:38:43 --> Language Class Initialized
INFO - 2024-02-12 12:38:43 --> Loader Class Initialized
INFO - 2024-02-12 12:38:43 --> Helper loaded: url_helper
INFO - 2024-02-12 12:38:43 --> Helper loaded: file_helper
INFO - 2024-02-12 12:38:43 --> Helper loaded: form_helper
INFO - 2024-02-12 12:38:43 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:38:43 --> Controller Class Initialized
INFO - 2024-02-12 12:38:43 --> Form Validation Class Initialized
INFO - 2024-02-12 12:38:43 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:38:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:38:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:38:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:38:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:38:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:38:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:38:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:38:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:38:43 --> Final output sent to browser
DEBUG - 2024-02-12 12:38:43 --> Total execution time: 0.0334
ERROR - 2024-02-12 12:38:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:38:44 --> Config Class Initialized
INFO - 2024-02-12 12:38:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:38:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:38:44 --> Utf8 Class Initialized
INFO - 2024-02-12 12:38:44 --> URI Class Initialized
INFO - 2024-02-12 12:38:44 --> Router Class Initialized
INFO - 2024-02-12 12:38:44 --> Output Class Initialized
INFO - 2024-02-12 12:38:44 --> Security Class Initialized
DEBUG - 2024-02-12 12:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:38:44 --> Input Class Initialized
INFO - 2024-02-12 12:38:44 --> Language Class Initialized
INFO - 2024-02-12 12:38:44 --> Loader Class Initialized
INFO - 2024-02-12 12:38:44 --> Helper loaded: url_helper
INFO - 2024-02-12 12:38:44 --> Helper loaded: file_helper
INFO - 2024-02-12 12:38:44 --> Helper loaded: form_helper
INFO - 2024-02-12 12:38:44 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:38:44 --> Controller Class Initialized
INFO - 2024-02-12 12:38:44 --> Form Validation Class Initialized
INFO - 2024-02-12 12:38:44 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:38:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:38:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:38:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:38:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:38:47 --> Config Class Initialized
INFO - 2024-02-12 12:38:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:38:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:38:47 --> Utf8 Class Initialized
INFO - 2024-02-12 12:38:47 --> URI Class Initialized
INFO - 2024-02-12 12:38:47 --> Router Class Initialized
INFO - 2024-02-12 12:38:47 --> Output Class Initialized
INFO - 2024-02-12 12:38:47 --> Security Class Initialized
DEBUG - 2024-02-12 12:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:38:47 --> Input Class Initialized
INFO - 2024-02-12 12:38:47 --> Language Class Initialized
INFO - 2024-02-12 12:38:47 --> Loader Class Initialized
INFO - 2024-02-12 12:38:47 --> Helper loaded: url_helper
INFO - 2024-02-12 12:38:47 --> Helper loaded: file_helper
INFO - 2024-02-12 12:38:47 --> Helper loaded: form_helper
INFO - 2024-02-12 12:38:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:38:47 --> Controller Class Initialized
INFO - 2024-02-12 12:38:47 --> Form Validation Class Initialized
INFO - 2024-02-12 12:38:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:38:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:38:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:38:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:38:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:38:47 --> Final output sent to browser
DEBUG - 2024-02-12 12:38:47 --> Total execution time: 0.0210
ERROR - 2024-02-12 12:39:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:39:30 --> Config Class Initialized
INFO - 2024-02-12 12:39:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:39:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:39:30 --> Utf8 Class Initialized
INFO - 2024-02-12 12:39:30 --> URI Class Initialized
INFO - 2024-02-12 12:39:30 --> Router Class Initialized
INFO - 2024-02-12 12:39:30 --> Output Class Initialized
INFO - 2024-02-12 12:39:30 --> Security Class Initialized
DEBUG - 2024-02-12 12:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:39:30 --> Input Class Initialized
INFO - 2024-02-12 12:39:30 --> Language Class Initialized
INFO - 2024-02-12 12:39:30 --> Loader Class Initialized
INFO - 2024-02-12 12:39:30 --> Helper loaded: url_helper
INFO - 2024-02-12 12:39:30 --> Helper loaded: file_helper
INFO - 2024-02-12 12:39:30 --> Helper loaded: form_helper
INFO - 2024-02-12 12:39:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:39:30 --> Controller Class Initialized
INFO - 2024-02-12 12:39:30 --> Form Validation Class Initialized
INFO - 2024-02-12 12:39:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:39:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:39:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:39:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:39:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:39:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:39:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:39:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:39:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:39:30 --> Final output sent to browser
DEBUG - 2024-02-12 12:39:30 --> Total execution time: 0.0333
ERROR - 2024-02-12 12:39:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:39:31 --> Config Class Initialized
INFO - 2024-02-12 12:39:31 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:39:31 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:39:31 --> Utf8 Class Initialized
INFO - 2024-02-12 12:39:31 --> URI Class Initialized
INFO - 2024-02-12 12:39:31 --> Router Class Initialized
INFO - 2024-02-12 12:39:31 --> Output Class Initialized
INFO - 2024-02-12 12:39:31 --> Security Class Initialized
DEBUG - 2024-02-12 12:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:39:31 --> Input Class Initialized
INFO - 2024-02-12 12:39:31 --> Language Class Initialized
INFO - 2024-02-12 12:39:31 --> Loader Class Initialized
INFO - 2024-02-12 12:39:31 --> Helper loaded: url_helper
INFO - 2024-02-12 12:39:31 --> Helper loaded: file_helper
INFO - 2024-02-12 12:39:31 --> Helper loaded: form_helper
INFO - 2024-02-12 12:39:31 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:39:31 --> Controller Class Initialized
INFO - 2024-02-12 12:39:31 --> Form Validation Class Initialized
INFO - 2024-02-12 12:39:31 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:39:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:39:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:39:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:39:59 --> Config Class Initialized
INFO - 2024-02-12 12:39:59 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:39:59 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:39:59 --> Utf8 Class Initialized
INFO - 2024-02-12 12:39:59 --> URI Class Initialized
INFO - 2024-02-12 12:39:59 --> Router Class Initialized
INFO - 2024-02-12 12:39:59 --> Output Class Initialized
INFO - 2024-02-12 12:39:59 --> Security Class Initialized
DEBUG - 2024-02-12 12:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:39:59 --> Input Class Initialized
INFO - 2024-02-12 12:39:59 --> Language Class Initialized
INFO - 2024-02-12 12:39:59 --> Loader Class Initialized
INFO - 2024-02-12 12:39:59 --> Helper loaded: url_helper
INFO - 2024-02-12 12:39:59 --> Helper loaded: file_helper
INFO - 2024-02-12 12:39:59 --> Helper loaded: form_helper
INFO - 2024-02-12 12:39:59 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:39:59 --> Controller Class Initialized
INFO - 2024-02-12 12:39:59 --> Form Validation Class Initialized
INFO - 2024-02-12 12:39:59 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:39:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:39:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:39:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:39:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:39:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:39:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:39:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:39:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:39:59 --> Final output sent to browser
DEBUG - 2024-02-12 12:39:59 --> Total execution time: 0.0274
ERROR - 2024-02-12 12:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:40:00 --> Config Class Initialized
INFO - 2024-02-12 12:40:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:40:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:40:00 --> Utf8 Class Initialized
INFO - 2024-02-12 12:40:00 --> URI Class Initialized
INFO - 2024-02-12 12:40:00 --> Router Class Initialized
INFO - 2024-02-12 12:40:00 --> Output Class Initialized
INFO - 2024-02-12 12:40:00 --> Security Class Initialized
DEBUG - 2024-02-12 12:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:40:00 --> Input Class Initialized
INFO - 2024-02-12 12:40:00 --> Language Class Initialized
INFO - 2024-02-12 12:40:00 --> Loader Class Initialized
INFO - 2024-02-12 12:40:00 --> Helper loaded: url_helper
INFO - 2024-02-12 12:40:00 --> Helper loaded: file_helper
INFO - 2024-02-12 12:40:00 --> Helper loaded: form_helper
INFO - 2024-02-12 12:40:00 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:40:00 --> Controller Class Initialized
INFO - 2024-02-12 12:40:00 --> Form Validation Class Initialized
INFO - 2024-02-12 12:40:00 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:40:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:40:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:40:00 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:40:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:40:02 --> Config Class Initialized
INFO - 2024-02-12 12:40:02 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:40:02 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:40:02 --> Utf8 Class Initialized
INFO - 2024-02-12 12:40:02 --> URI Class Initialized
INFO - 2024-02-12 12:40:02 --> Router Class Initialized
INFO - 2024-02-12 12:40:02 --> Output Class Initialized
INFO - 2024-02-12 12:40:02 --> Security Class Initialized
DEBUG - 2024-02-12 12:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:40:02 --> Input Class Initialized
INFO - 2024-02-12 12:40:02 --> Language Class Initialized
INFO - 2024-02-12 12:40:02 --> Loader Class Initialized
INFO - 2024-02-12 12:40:02 --> Helper loaded: url_helper
INFO - 2024-02-12 12:40:02 --> Helper loaded: file_helper
INFO - 2024-02-12 12:40:02 --> Helper loaded: form_helper
INFO - 2024-02-12 12:40:02 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:40:02 --> Controller Class Initialized
INFO - 2024-02-12 12:40:02 --> Form Validation Class Initialized
INFO - 2024-02-12 12:40:02 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:40:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:40:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:40:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:40:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:40:02 --> Final output sent to browser
DEBUG - 2024-02-12 12:40:02 --> Total execution time: 0.0264
ERROR - 2024-02-12 12:40:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:40:47 --> Config Class Initialized
INFO - 2024-02-12 12:40:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:40:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:40:47 --> Utf8 Class Initialized
INFO - 2024-02-12 12:40:47 --> URI Class Initialized
INFO - 2024-02-12 12:40:47 --> Router Class Initialized
INFO - 2024-02-12 12:40:47 --> Output Class Initialized
INFO - 2024-02-12 12:40:47 --> Security Class Initialized
DEBUG - 2024-02-12 12:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:40:47 --> Input Class Initialized
INFO - 2024-02-12 12:40:47 --> Language Class Initialized
INFO - 2024-02-12 12:40:47 --> Loader Class Initialized
INFO - 2024-02-12 12:40:47 --> Helper loaded: url_helper
INFO - 2024-02-12 12:40:47 --> Helper loaded: file_helper
INFO - 2024-02-12 12:40:47 --> Helper loaded: form_helper
INFO - 2024-02-12 12:40:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:40:47 --> Controller Class Initialized
INFO - 2024-02-12 12:40:47 --> Form Validation Class Initialized
INFO - 2024-02-12 12:40:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:40:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:40:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:40:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:40:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:40:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:40:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:40:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:40:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:40:47 --> Final output sent to browser
DEBUG - 2024-02-12 12:40:47 --> Total execution time: 0.0335
ERROR - 2024-02-12 12:40:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:40:48 --> Config Class Initialized
INFO - 2024-02-12 12:40:48 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:40:48 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:40:48 --> Utf8 Class Initialized
INFO - 2024-02-12 12:40:48 --> URI Class Initialized
INFO - 2024-02-12 12:40:48 --> Router Class Initialized
INFO - 2024-02-12 12:40:48 --> Output Class Initialized
INFO - 2024-02-12 12:40:48 --> Security Class Initialized
DEBUG - 2024-02-12 12:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:40:48 --> Input Class Initialized
INFO - 2024-02-12 12:40:48 --> Language Class Initialized
INFO - 2024-02-12 12:40:48 --> Loader Class Initialized
INFO - 2024-02-12 12:40:48 --> Helper loaded: url_helper
INFO - 2024-02-12 12:40:48 --> Helper loaded: file_helper
INFO - 2024-02-12 12:40:48 --> Helper loaded: form_helper
INFO - 2024-02-12 12:40:48 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:40:48 --> Controller Class Initialized
INFO - 2024-02-12 12:40:48 --> Form Validation Class Initialized
INFO - 2024-02-12 12:40:48 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:40:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:40:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:40:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:40:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:40:51 --> Config Class Initialized
INFO - 2024-02-12 12:40:51 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:40:51 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:40:51 --> Utf8 Class Initialized
INFO - 2024-02-12 12:40:51 --> URI Class Initialized
INFO - 2024-02-12 12:40:51 --> Router Class Initialized
INFO - 2024-02-12 12:40:51 --> Output Class Initialized
INFO - 2024-02-12 12:40:51 --> Security Class Initialized
DEBUG - 2024-02-12 12:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:40:51 --> Input Class Initialized
INFO - 2024-02-12 12:40:51 --> Language Class Initialized
INFO - 2024-02-12 12:40:51 --> Loader Class Initialized
INFO - 2024-02-12 12:40:51 --> Helper loaded: url_helper
INFO - 2024-02-12 12:40:51 --> Helper loaded: file_helper
INFO - 2024-02-12 12:40:51 --> Helper loaded: form_helper
INFO - 2024-02-12 12:40:51 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:40:51 --> Controller Class Initialized
INFO - 2024-02-12 12:40:51 --> Form Validation Class Initialized
INFO - 2024-02-12 12:40:51 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:40:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:40:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:40:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:40:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:40:51 --> Final output sent to browser
DEBUG - 2024-02-12 12:40:51 --> Total execution time: 0.0212
ERROR - 2024-02-12 12:42:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:42:44 --> Config Class Initialized
INFO - 2024-02-12 12:42:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:42:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:42:44 --> Utf8 Class Initialized
INFO - 2024-02-12 12:42:44 --> URI Class Initialized
INFO - 2024-02-12 12:42:44 --> Router Class Initialized
INFO - 2024-02-12 12:42:44 --> Output Class Initialized
INFO - 2024-02-12 12:42:44 --> Security Class Initialized
DEBUG - 2024-02-12 12:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:42:44 --> Input Class Initialized
INFO - 2024-02-12 12:42:44 --> Language Class Initialized
INFO - 2024-02-12 12:42:44 --> Loader Class Initialized
INFO - 2024-02-12 12:42:44 --> Helper loaded: url_helper
INFO - 2024-02-12 12:42:44 --> Helper loaded: file_helper
INFO - 2024-02-12 12:42:44 --> Helper loaded: form_helper
INFO - 2024-02-12 12:42:44 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:42:44 --> Controller Class Initialized
INFO - 2024-02-12 12:42:44 --> Form Validation Class Initialized
INFO - 2024-02-12 12:42:44 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:42:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:42:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:42:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:42:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:42:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:42:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:42:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:42:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:42:44 --> Final output sent to browser
DEBUG - 2024-02-12 12:42:44 --> Total execution time: 0.0400
ERROR - 2024-02-12 12:42:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:42:44 --> Config Class Initialized
INFO - 2024-02-12 12:42:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:42:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:42:44 --> Utf8 Class Initialized
INFO - 2024-02-12 12:42:44 --> URI Class Initialized
INFO - 2024-02-12 12:42:44 --> Router Class Initialized
INFO - 2024-02-12 12:42:44 --> Output Class Initialized
INFO - 2024-02-12 12:42:44 --> Security Class Initialized
DEBUG - 2024-02-12 12:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:42:44 --> Input Class Initialized
INFO - 2024-02-12 12:42:44 --> Language Class Initialized
INFO - 2024-02-12 12:42:44 --> Loader Class Initialized
INFO - 2024-02-12 12:42:44 --> Helper loaded: url_helper
INFO - 2024-02-12 12:42:44 --> Helper loaded: file_helper
INFO - 2024-02-12 12:42:44 --> Helper loaded: form_helper
INFO - 2024-02-12 12:42:44 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:42:44 --> Controller Class Initialized
INFO - 2024-02-12 12:42:44 --> Form Validation Class Initialized
INFO - 2024-02-12 12:42:44 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:42:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:42:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:42:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:42:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:42:47 --> Config Class Initialized
INFO - 2024-02-12 12:42:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:42:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:42:47 --> Utf8 Class Initialized
INFO - 2024-02-12 12:42:47 --> URI Class Initialized
INFO - 2024-02-12 12:42:47 --> Router Class Initialized
INFO - 2024-02-12 12:42:47 --> Output Class Initialized
INFO - 2024-02-12 12:42:47 --> Security Class Initialized
DEBUG - 2024-02-12 12:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:42:47 --> Input Class Initialized
INFO - 2024-02-12 12:42:47 --> Language Class Initialized
INFO - 2024-02-12 12:42:47 --> Loader Class Initialized
INFO - 2024-02-12 12:42:47 --> Helper loaded: url_helper
INFO - 2024-02-12 12:42:47 --> Helper loaded: file_helper
INFO - 2024-02-12 12:42:47 --> Helper loaded: form_helper
INFO - 2024-02-12 12:42:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:42:47 --> Controller Class Initialized
INFO - 2024-02-12 12:42:47 --> Form Validation Class Initialized
INFO - 2024-02-12 12:42:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:42:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:42:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:42:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:42:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:42:47 --> Final output sent to browser
DEBUG - 2024-02-12 12:42:47 --> Total execution time: 0.0244
ERROR - 2024-02-12 12:44:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:44:28 --> Config Class Initialized
INFO - 2024-02-12 12:44:28 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:44:28 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:44:28 --> Utf8 Class Initialized
INFO - 2024-02-12 12:44:28 --> URI Class Initialized
INFO - 2024-02-12 12:44:28 --> Router Class Initialized
INFO - 2024-02-12 12:44:28 --> Output Class Initialized
INFO - 2024-02-12 12:44:28 --> Security Class Initialized
DEBUG - 2024-02-12 12:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:44:28 --> Input Class Initialized
INFO - 2024-02-12 12:44:28 --> Language Class Initialized
INFO - 2024-02-12 12:44:28 --> Loader Class Initialized
INFO - 2024-02-12 12:44:28 --> Helper loaded: url_helper
INFO - 2024-02-12 12:44:28 --> Helper loaded: file_helper
INFO - 2024-02-12 12:44:28 --> Helper loaded: form_helper
INFO - 2024-02-12 12:44:28 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:44:28 --> Controller Class Initialized
INFO - 2024-02-12 12:44:28 --> Form Validation Class Initialized
INFO - 2024-02-12 12:44:28 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:44:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:44:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:44:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:44:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:44:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:44:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:44:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:44:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:44:28 --> Final output sent to browser
DEBUG - 2024-02-12 12:44:28 --> Total execution time: 0.0269
ERROR - 2024-02-12 12:44:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:44:29 --> Config Class Initialized
INFO - 2024-02-12 12:44:29 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:44:29 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:44:29 --> Utf8 Class Initialized
INFO - 2024-02-12 12:44:29 --> URI Class Initialized
INFO - 2024-02-12 12:44:29 --> Router Class Initialized
INFO - 2024-02-12 12:44:29 --> Output Class Initialized
INFO - 2024-02-12 12:44:29 --> Security Class Initialized
DEBUG - 2024-02-12 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:44:29 --> Input Class Initialized
INFO - 2024-02-12 12:44:29 --> Language Class Initialized
INFO - 2024-02-12 12:44:29 --> Loader Class Initialized
INFO - 2024-02-12 12:44:29 --> Helper loaded: url_helper
INFO - 2024-02-12 12:44:29 --> Helper loaded: file_helper
INFO - 2024-02-12 12:44:29 --> Helper loaded: form_helper
INFO - 2024-02-12 12:44:29 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:44:29 --> Controller Class Initialized
INFO - 2024-02-12 12:44:29 --> Form Validation Class Initialized
INFO - 2024-02-12 12:44:29 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:44:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:44:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:44:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:44:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:44:32 --> Config Class Initialized
INFO - 2024-02-12 12:44:32 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:44:32 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:44:32 --> Utf8 Class Initialized
INFO - 2024-02-12 12:44:32 --> URI Class Initialized
INFO - 2024-02-12 12:44:32 --> Router Class Initialized
INFO - 2024-02-12 12:44:32 --> Output Class Initialized
INFO - 2024-02-12 12:44:32 --> Security Class Initialized
DEBUG - 2024-02-12 12:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:44:32 --> Input Class Initialized
INFO - 2024-02-12 12:44:32 --> Language Class Initialized
INFO - 2024-02-12 12:44:32 --> Loader Class Initialized
INFO - 2024-02-12 12:44:32 --> Helper loaded: url_helper
INFO - 2024-02-12 12:44:32 --> Helper loaded: file_helper
INFO - 2024-02-12 12:44:32 --> Helper loaded: form_helper
INFO - 2024-02-12 12:44:32 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:44:32 --> Controller Class Initialized
INFO - 2024-02-12 12:44:32 --> Form Validation Class Initialized
INFO - 2024-02-12 12:44:32 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:44:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:44:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:44:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:44:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:44:32 --> Final output sent to browser
DEBUG - 2024-02-12 12:44:32 --> Total execution time: 0.0334
ERROR - 2024-02-12 12:44:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:44:43 --> Config Class Initialized
INFO - 2024-02-12 12:44:43 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:44:43 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:44:43 --> Utf8 Class Initialized
INFO - 2024-02-12 12:44:43 --> URI Class Initialized
INFO - 2024-02-12 12:44:43 --> Router Class Initialized
INFO - 2024-02-12 12:44:43 --> Output Class Initialized
INFO - 2024-02-12 12:44:43 --> Security Class Initialized
DEBUG - 2024-02-12 12:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:44:43 --> Input Class Initialized
INFO - 2024-02-12 12:44:43 --> Language Class Initialized
INFO - 2024-02-12 12:44:43 --> Loader Class Initialized
INFO - 2024-02-12 12:44:43 --> Helper loaded: url_helper
INFO - 2024-02-12 12:44:43 --> Helper loaded: file_helper
INFO - 2024-02-12 12:44:43 --> Helper loaded: form_helper
INFO - 2024-02-12 12:44:43 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:44:43 --> Controller Class Initialized
INFO - 2024-02-12 12:44:43 --> Form Validation Class Initialized
INFO - 2024-02-12 12:44:43 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:44:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:44:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:44:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:44:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:44:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:44:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:44:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:44:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:44:43 --> Final output sent to browser
DEBUG - 2024-02-12 12:44:43 --> Total execution time: 0.0288
ERROR - 2024-02-12 12:46:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:46:23 --> Config Class Initialized
INFO - 2024-02-12 12:46:23 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:46:23 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:46:23 --> Utf8 Class Initialized
INFO - 2024-02-12 12:46:23 --> URI Class Initialized
INFO - 2024-02-12 12:46:23 --> Router Class Initialized
INFO - 2024-02-12 12:46:23 --> Output Class Initialized
INFO - 2024-02-12 12:46:23 --> Security Class Initialized
DEBUG - 2024-02-12 12:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:46:23 --> Input Class Initialized
INFO - 2024-02-12 12:46:23 --> Language Class Initialized
INFO - 2024-02-12 12:46:23 --> Loader Class Initialized
INFO - 2024-02-12 12:46:23 --> Helper loaded: url_helper
INFO - 2024-02-12 12:46:23 --> Helper loaded: file_helper
INFO - 2024-02-12 12:46:23 --> Helper loaded: form_helper
INFO - 2024-02-12 12:46:23 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:46:23 --> Controller Class Initialized
INFO - 2024-02-12 12:46:23 --> Form Validation Class Initialized
INFO - 2024-02-12 12:46:23 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:46:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:46:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:46:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:46:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:46:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:46:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:46:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:46:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:46:23 --> Final output sent to browser
DEBUG - 2024-02-12 12:46:23 --> Total execution time: 0.0298
ERROR - 2024-02-12 12:46:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:46:24 --> Config Class Initialized
INFO - 2024-02-12 12:46:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:46:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:46:24 --> Utf8 Class Initialized
INFO - 2024-02-12 12:46:24 --> URI Class Initialized
INFO - 2024-02-12 12:46:24 --> Router Class Initialized
INFO - 2024-02-12 12:46:24 --> Output Class Initialized
INFO - 2024-02-12 12:46:24 --> Security Class Initialized
DEBUG - 2024-02-12 12:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:46:24 --> Input Class Initialized
INFO - 2024-02-12 12:46:24 --> Language Class Initialized
INFO - 2024-02-12 12:46:24 --> Loader Class Initialized
INFO - 2024-02-12 12:46:24 --> Helper loaded: url_helper
INFO - 2024-02-12 12:46:24 --> Helper loaded: file_helper
INFO - 2024-02-12 12:46:24 --> Helper loaded: form_helper
INFO - 2024-02-12 12:46:24 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:46:24 --> Controller Class Initialized
INFO - 2024-02-12 12:46:24 --> Form Validation Class Initialized
INFO - 2024-02-12 12:46:24 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:46:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:46:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:46:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:46:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:46:26 --> Config Class Initialized
INFO - 2024-02-12 12:46:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:46:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:46:26 --> Utf8 Class Initialized
INFO - 2024-02-12 12:46:26 --> URI Class Initialized
INFO - 2024-02-12 12:46:26 --> Router Class Initialized
INFO - 2024-02-12 12:46:26 --> Output Class Initialized
INFO - 2024-02-12 12:46:26 --> Security Class Initialized
DEBUG - 2024-02-12 12:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:46:26 --> Input Class Initialized
INFO - 2024-02-12 12:46:26 --> Language Class Initialized
INFO - 2024-02-12 12:46:26 --> Loader Class Initialized
INFO - 2024-02-12 12:46:26 --> Helper loaded: url_helper
INFO - 2024-02-12 12:46:26 --> Helper loaded: file_helper
INFO - 2024-02-12 12:46:26 --> Helper loaded: form_helper
INFO - 2024-02-12 12:46:26 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:46:26 --> Controller Class Initialized
INFO - 2024-02-12 12:46:26 --> Form Validation Class Initialized
INFO - 2024-02-12 12:46:26 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:46:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:46:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:46:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:46:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:46:26 --> Final output sent to browser
DEBUG - 2024-02-12 12:46:26 --> Total execution time: 0.0375
ERROR - 2024-02-12 12:47:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:47:36 --> Config Class Initialized
INFO - 2024-02-12 12:47:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:47:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:47:36 --> Utf8 Class Initialized
INFO - 2024-02-12 12:47:36 --> URI Class Initialized
INFO - 2024-02-12 12:47:36 --> Router Class Initialized
INFO - 2024-02-12 12:47:36 --> Output Class Initialized
INFO - 2024-02-12 12:47:36 --> Security Class Initialized
DEBUG - 2024-02-12 12:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:47:36 --> Input Class Initialized
INFO - 2024-02-12 12:47:36 --> Language Class Initialized
INFO - 2024-02-12 12:47:36 --> Loader Class Initialized
INFO - 2024-02-12 12:47:36 --> Helper loaded: url_helper
INFO - 2024-02-12 12:47:36 --> Helper loaded: file_helper
INFO - 2024-02-12 12:47:36 --> Helper loaded: form_helper
INFO - 2024-02-12 12:47:36 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:47:36 --> Controller Class Initialized
INFO - 2024-02-12 12:47:36 --> Form Validation Class Initialized
INFO - 2024-02-12 12:47:36 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:47:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:47:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:47:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:47:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:47:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:47:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:47:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:47:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:47:36 --> Final output sent to browser
DEBUG - 2024-02-12 12:47:36 --> Total execution time: 0.0260
ERROR - 2024-02-12 12:47:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:47:36 --> Config Class Initialized
INFO - 2024-02-12 12:47:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:47:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:47:36 --> Utf8 Class Initialized
INFO - 2024-02-12 12:47:36 --> URI Class Initialized
INFO - 2024-02-12 12:47:36 --> Router Class Initialized
INFO - 2024-02-12 12:47:36 --> Output Class Initialized
INFO - 2024-02-12 12:47:36 --> Security Class Initialized
DEBUG - 2024-02-12 12:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:47:36 --> Input Class Initialized
INFO - 2024-02-12 12:47:36 --> Language Class Initialized
INFO - 2024-02-12 12:47:36 --> Loader Class Initialized
INFO - 2024-02-12 12:47:36 --> Helper loaded: url_helper
INFO - 2024-02-12 12:47:36 --> Helper loaded: file_helper
INFO - 2024-02-12 12:47:36 --> Helper loaded: form_helper
INFO - 2024-02-12 12:47:36 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:47:36 --> Controller Class Initialized
INFO - 2024-02-12 12:47:36 --> Form Validation Class Initialized
INFO - 2024-02-12 12:47:36 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:47:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:47:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:47:36 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:47:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:47:38 --> Config Class Initialized
INFO - 2024-02-12 12:47:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:47:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:47:38 --> Utf8 Class Initialized
INFO - 2024-02-12 12:47:38 --> URI Class Initialized
INFO - 2024-02-12 12:47:38 --> Router Class Initialized
INFO - 2024-02-12 12:47:38 --> Output Class Initialized
INFO - 2024-02-12 12:47:38 --> Security Class Initialized
DEBUG - 2024-02-12 12:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:47:38 --> Input Class Initialized
INFO - 2024-02-12 12:47:38 --> Language Class Initialized
INFO - 2024-02-12 12:47:38 --> Loader Class Initialized
INFO - 2024-02-12 12:47:38 --> Helper loaded: url_helper
INFO - 2024-02-12 12:47:38 --> Helper loaded: file_helper
INFO - 2024-02-12 12:47:38 --> Helper loaded: form_helper
INFO - 2024-02-12 12:47:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:47:38 --> Controller Class Initialized
INFO - 2024-02-12 12:47:38 --> Form Validation Class Initialized
INFO - 2024-02-12 12:47:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:47:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:47:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:47:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:47:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:47:38 --> Final output sent to browser
DEBUG - 2024-02-12 12:47:38 --> Total execution time: 0.0367
ERROR - 2024-02-12 12:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:49:08 --> Config Class Initialized
INFO - 2024-02-12 12:49:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:49:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:49:08 --> Utf8 Class Initialized
INFO - 2024-02-12 12:49:08 --> URI Class Initialized
INFO - 2024-02-12 12:49:08 --> Router Class Initialized
INFO - 2024-02-12 12:49:08 --> Output Class Initialized
INFO - 2024-02-12 12:49:08 --> Security Class Initialized
DEBUG - 2024-02-12 12:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:49:08 --> Input Class Initialized
INFO - 2024-02-12 12:49:08 --> Language Class Initialized
INFO - 2024-02-12 12:49:08 --> Loader Class Initialized
INFO - 2024-02-12 12:49:08 --> Helper loaded: url_helper
INFO - 2024-02-12 12:49:08 --> Helper loaded: file_helper
INFO - 2024-02-12 12:49:08 --> Helper loaded: form_helper
INFO - 2024-02-12 12:49:08 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:49:08 --> Controller Class Initialized
INFO - 2024-02-12 12:49:08 --> Form Validation Class Initialized
INFO - 2024-02-12 12:49:08 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:49:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:49:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:49:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:49:08 --> Final output sent to browser
DEBUG - 2024-02-12 12:49:08 --> Total execution time: 0.0338
ERROR - 2024-02-12 12:50:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:50:30 --> Config Class Initialized
INFO - 2024-02-12 12:50:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:50:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:50:30 --> Utf8 Class Initialized
INFO - 2024-02-12 12:50:30 --> URI Class Initialized
INFO - 2024-02-12 12:50:30 --> Router Class Initialized
INFO - 2024-02-12 12:50:30 --> Output Class Initialized
INFO - 2024-02-12 12:50:30 --> Security Class Initialized
DEBUG - 2024-02-12 12:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:50:30 --> Input Class Initialized
INFO - 2024-02-12 12:50:30 --> Language Class Initialized
INFO - 2024-02-12 12:50:30 --> Loader Class Initialized
INFO - 2024-02-12 12:50:30 --> Helper loaded: url_helper
INFO - 2024-02-12 12:50:30 --> Helper loaded: file_helper
INFO - 2024-02-12 12:50:30 --> Helper loaded: form_helper
INFO - 2024-02-12 12:50:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:50:30 --> Controller Class Initialized
INFO - 2024-02-12 12:50:30 --> Form Validation Class Initialized
INFO - 2024-02-12 12:50:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:50:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:50:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:50:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:50:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:50:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:50:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:50:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:50:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:50:30 --> Final output sent to browser
DEBUG - 2024-02-12 12:50:30 --> Total execution time: 0.0280
ERROR - 2024-02-12 12:50:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:50:30 --> Config Class Initialized
INFO - 2024-02-12 12:50:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:50:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:50:30 --> Utf8 Class Initialized
INFO - 2024-02-12 12:50:30 --> URI Class Initialized
INFO - 2024-02-12 12:50:30 --> Router Class Initialized
INFO - 2024-02-12 12:50:30 --> Output Class Initialized
INFO - 2024-02-12 12:50:30 --> Security Class Initialized
DEBUG - 2024-02-12 12:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:50:30 --> Input Class Initialized
INFO - 2024-02-12 12:50:30 --> Language Class Initialized
INFO - 2024-02-12 12:50:30 --> Loader Class Initialized
INFO - 2024-02-12 12:50:30 --> Helper loaded: url_helper
INFO - 2024-02-12 12:50:30 --> Helper loaded: file_helper
INFO - 2024-02-12 12:50:30 --> Helper loaded: form_helper
INFO - 2024-02-12 12:50:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:50:30 --> Controller Class Initialized
INFO - 2024-02-12 12:50:30 --> Form Validation Class Initialized
INFO - 2024-02-12 12:50:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:50:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:50:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:50:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:50:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:50:33 --> Config Class Initialized
INFO - 2024-02-12 12:50:33 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:50:33 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:50:33 --> Utf8 Class Initialized
INFO - 2024-02-12 12:50:33 --> URI Class Initialized
INFO - 2024-02-12 12:50:33 --> Router Class Initialized
INFO - 2024-02-12 12:50:33 --> Output Class Initialized
INFO - 2024-02-12 12:50:33 --> Security Class Initialized
DEBUG - 2024-02-12 12:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:50:33 --> Input Class Initialized
INFO - 2024-02-12 12:50:33 --> Language Class Initialized
INFO - 2024-02-12 12:50:33 --> Loader Class Initialized
INFO - 2024-02-12 12:50:33 --> Helper loaded: url_helper
INFO - 2024-02-12 12:50:33 --> Helper loaded: file_helper
INFO - 2024-02-12 12:50:33 --> Helper loaded: form_helper
INFO - 2024-02-12 12:50:33 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:50:33 --> Controller Class Initialized
INFO - 2024-02-12 12:50:33 --> Form Validation Class Initialized
INFO - 2024-02-12 12:50:33 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:50:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:50:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:50:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:50:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:50:33 --> Final output sent to browser
DEBUG - 2024-02-12 12:50:33 --> Total execution time: 0.0310
ERROR - 2024-02-12 12:50:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:50:55 --> Config Class Initialized
INFO - 2024-02-12 12:50:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:50:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:50:55 --> Utf8 Class Initialized
INFO - 2024-02-12 12:50:55 --> URI Class Initialized
INFO - 2024-02-12 12:50:55 --> Router Class Initialized
INFO - 2024-02-12 12:50:55 --> Output Class Initialized
INFO - 2024-02-12 12:50:55 --> Security Class Initialized
DEBUG - 2024-02-12 12:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:50:55 --> Input Class Initialized
INFO - 2024-02-12 12:50:55 --> Language Class Initialized
INFO - 2024-02-12 12:50:55 --> Loader Class Initialized
INFO - 2024-02-12 12:50:55 --> Helper loaded: url_helper
INFO - 2024-02-12 12:50:55 --> Helper loaded: file_helper
INFO - 2024-02-12 12:50:55 --> Helper loaded: form_helper
INFO - 2024-02-12 12:50:55 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:50:55 --> Controller Class Initialized
INFO - 2024-02-12 12:50:55 --> Form Validation Class Initialized
INFO - 2024-02-12 12:50:55 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:50:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:50:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:50:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:50:55 --> Final output sent to browser
DEBUG - 2024-02-12 12:50:55 --> Total execution time: 0.0303
ERROR - 2024-02-12 12:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:50:56 --> Config Class Initialized
INFO - 2024-02-12 12:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:50:56 --> Utf8 Class Initialized
INFO - 2024-02-12 12:50:56 --> URI Class Initialized
INFO - 2024-02-12 12:50:56 --> Router Class Initialized
INFO - 2024-02-12 12:50:56 --> Output Class Initialized
INFO - 2024-02-12 12:50:56 --> Security Class Initialized
DEBUG - 2024-02-12 12:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:50:56 --> Input Class Initialized
INFO - 2024-02-12 12:50:56 --> Language Class Initialized
INFO - 2024-02-12 12:50:56 --> Loader Class Initialized
INFO - 2024-02-12 12:50:56 --> Helper loaded: url_helper
INFO - 2024-02-12 12:50:56 --> Helper loaded: file_helper
INFO - 2024-02-12 12:50:56 --> Helper loaded: form_helper
INFO - 2024-02-12 12:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:50:56 --> Controller Class Initialized
INFO - 2024-02-12 12:50:56 --> Form Validation Class Initialized
INFO - 2024-02-12 12:50:56 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:50:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:50:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:50:56 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:50:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:50:58 --> Config Class Initialized
INFO - 2024-02-12 12:50:58 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:50:58 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:50:58 --> Utf8 Class Initialized
INFO - 2024-02-12 12:50:58 --> URI Class Initialized
INFO - 2024-02-12 12:50:58 --> Router Class Initialized
INFO - 2024-02-12 12:50:58 --> Output Class Initialized
INFO - 2024-02-12 12:50:58 --> Security Class Initialized
DEBUG - 2024-02-12 12:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:50:58 --> Input Class Initialized
INFO - 2024-02-12 12:50:58 --> Language Class Initialized
INFO - 2024-02-12 12:50:58 --> Loader Class Initialized
INFO - 2024-02-12 12:50:58 --> Helper loaded: url_helper
INFO - 2024-02-12 12:50:58 --> Helper loaded: file_helper
INFO - 2024-02-12 12:50:58 --> Helper loaded: form_helper
INFO - 2024-02-12 12:50:58 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:50:58 --> Controller Class Initialized
INFO - 2024-02-12 12:50:58 --> Form Validation Class Initialized
INFO - 2024-02-12 12:50:58 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:50:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:50:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:50:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:50:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:50:58 --> Final output sent to browser
DEBUG - 2024-02-12 12:50:58 --> Total execution time: 0.0382
ERROR - 2024-02-12 12:51:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:51:26 --> Config Class Initialized
INFO - 2024-02-12 12:51:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:51:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:51:26 --> Utf8 Class Initialized
INFO - 2024-02-12 12:51:26 --> URI Class Initialized
INFO - 2024-02-12 12:51:26 --> Router Class Initialized
INFO - 2024-02-12 12:51:26 --> Output Class Initialized
INFO - 2024-02-12 12:51:26 --> Security Class Initialized
DEBUG - 2024-02-12 12:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:51:26 --> Input Class Initialized
INFO - 2024-02-12 12:51:26 --> Language Class Initialized
INFO - 2024-02-12 12:51:26 --> Loader Class Initialized
INFO - 2024-02-12 12:51:26 --> Helper loaded: url_helper
INFO - 2024-02-12 12:51:26 --> Helper loaded: file_helper
INFO - 2024-02-12 12:51:26 --> Helper loaded: form_helper
INFO - 2024-02-12 12:51:26 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:51:26 --> Controller Class Initialized
INFO - 2024-02-12 12:51:26 --> Form Validation Class Initialized
INFO - 2024-02-12 12:51:26 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:51:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:51:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:51:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:51:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:51:26 --> Final output sent to browser
DEBUG - 2024-02-12 12:51:26 --> Total execution time: 0.0329
ERROR - 2024-02-12 12:51:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:51:32 --> Config Class Initialized
INFO - 2024-02-12 12:51:32 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:51:32 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:51:32 --> Utf8 Class Initialized
INFO - 2024-02-12 12:51:32 --> URI Class Initialized
INFO - 2024-02-12 12:51:32 --> Router Class Initialized
INFO - 2024-02-12 12:51:32 --> Output Class Initialized
INFO - 2024-02-12 12:51:32 --> Security Class Initialized
DEBUG - 2024-02-12 12:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:51:32 --> Input Class Initialized
INFO - 2024-02-12 12:51:32 --> Language Class Initialized
INFO - 2024-02-12 12:51:32 --> Loader Class Initialized
INFO - 2024-02-12 12:51:32 --> Helper loaded: url_helper
INFO - 2024-02-12 12:51:32 --> Helper loaded: file_helper
INFO - 2024-02-12 12:51:32 --> Helper loaded: form_helper
INFO - 2024-02-12 12:51:32 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:51:32 --> Controller Class Initialized
INFO - 2024-02-12 12:51:32 --> Form Validation Class Initialized
INFO - 2024-02-12 12:51:32 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:51:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:51:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:51:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:51:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:51:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:51:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:51:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:51:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:51:32 --> Final output sent to browser
DEBUG - 2024-02-12 12:51:32 --> Total execution time: 0.0335
ERROR - 2024-02-12 12:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:51:33 --> Config Class Initialized
INFO - 2024-02-12 12:51:33 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:51:33 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:51:33 --> Utf8 Class Initialized
INFO - 2024-02-12 12:51:33 --> URI Class Initialized
INFO - 2024-02-12 12:51:33 --> Router Class Initialized
INFO - 2024-02-12 12:51:33 --> Output Class Initialized
INFO - 2024-02-12 12:51:33 --> Security Class Initialized
DEBUG - 2024-02-12 12:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:51:33 --> Input Class Initialized
INFO - 2024-02-12 12:51:33 --> Language Class Initialized
INFO - 2024-02-12 12:51:33 --> Loader Class Initialized
INFO - 2024-02-12 12:51:33 --> Helper loaded: url_helper
INFO - 2024-02-12 12:51:33 --> Helper loaded: file_helper
INFO - 2024-02-12 12:51:33 --> Helper loaded: form_helper
INFO - 2024-02-12 12:51:33 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:51:33 --> Controller Class Initialized
INFO - 2024-02-12 12:51:33 --> Form Validation Class Initialized
INFO - 2024-02-12 12:51:33 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:51:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:51:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:51:33 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:51:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:51:35 --> Config Class Initialized
INFO - 2024-02-12 12:51:35 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:51:35 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:51:35 --> Utf8 Class Initialized
INFO - 2024-02-12 12:51:35 --> URI Class Initialized
INFO - 2024-02-12 12:51:35 --> Router Class Initialized
INFO - 2024-02-12 12:51:35 --> Output Class Initialized
INFO - 2024-02-12 12:51:35 --> Security Class Initialized
DEBUG - 2024-02-12 12:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:51:35 --> Input Class Initialized
INFO - 2024-02-12 12:51:35 --> Language Class Initialized
INFO - 2024-02-12 12:51:35 --> Loader Class Initialized
INFO - 2024-02-12 12:51:35 --> Helper loaded: url_helper
INFO - 2024-02-12 12:51:35 --> Helper loaded: file_helper
INFO - 2024-02-12 12:51:35 --> Helper loaded: form_helper
INFO - 2024-02-12 12:51:35 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:51:35 --> Controller Class Initialized
INFO - 2024-02-12 12:51:35 --> Form Validation Class Initialized
INFO - 2024-02-12 12:51:35 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:51:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:51:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:51:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:51:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:51:35 --> Final output sent to browser
DEBUG - 2024-02-12 12:51:35 --> Total execution time: 0.0350
ERROR - 2024-02-12 12:54:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:54:52 --> Config Class Initialized
INFO - 2024-02-12 12:54:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:54:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:54:52 --> Utf8 Class Initialized
INFO - 2024-02-12 12:54:52 --> URI Class Initialized
INFO - 2024-02-12 12:54:52 --> Router Class Initialized
INFO - 2024-02-12 12:54:52 --> Output Class Initialized
INFO - 2024-02-12 12:54:52 --> Security Class Initialized
DEBUG - 2024-02-12 12:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:54:52 --> Input Class Initialized
INFO - 2024-02-12 12:54:52 --> Language Class Initialized
INFO - 2024-02-12 12:54:52 --> Loader Class Initialized
INFO - 2024-02-12 12:54:52 --> Helper loaded: url_helper
INFO - 2024-02-12 12:54:52 --> Helper loaded: file_helper
INFO - 2024-02-12 12:54:52 --> Helper loaded: form_helper
INFO - 2024-02-12 12:54:52 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:54:52 --> Controller Class Initialized
INFO - 2024-02-12 12:54:52 --> Form Validation Class Initialized
INFO - 2024-02-12 12:54:52 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:54:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:54:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:54:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:54:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:54:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:54:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:54:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:54:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:54:52 --> Final output sent to browser
DEBUG - 2024-02-12 12:54:52 --> Total execution time: 0.0367
ERROR - 2024-02-12 12:54:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:54:53 --> Config Class Initialized
INFO - 2024-02-12 12:54:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:54:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:54:53 --> Utf8 Class Initialized
INFO - 2024-02-12 12:54:53 --> URI Class Initialized
INFO - 2024-02-12 12:54:53 --> Router Class Initialized
INFO - 2024-02-12 12:54:53 --> Output Class Initialized
INFO - 2024-02-12 12:54:53 --> Security Class Initialized
DEBUG - 2024-02-12 12:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:54:53 --> Input Class Initialized
INFO - 2024-02-12 12:54:53 --> Language Class Initialized
INFO - 2024-02-12 12:54:53 --> Loader Class Initialized
INFO - 2024-02-12 12:54:53 --> Helper loaded: url_helper
INFO - 2024-02-12 12:54:53 --> Helper loaded: file_helper
INFO - 2024-02-12 12:54:53 --> Helper loaded: form_helper
INFO - 2024-02-12 12:54:53 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:54:53 --> Controller Class Initialized
INFO - 2024-02-12 12:54:53 --> Form Validation Class Initialized
INFO - 2024-02-12 12:54:53 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:54:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:54:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:54:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:54:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:54:56 --> Config Class Initialized
INFO - 2024-02-12 12:54:56 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:54:56 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:54:56 --> Utf8 Class Initialized
INFO - 2024-02-12 12:54:56 --> URI Class Initialized
INFO - 2024-02-12 12:54:56 --> Router Class Initialized
INFO - 2024-02-12 12:54:56 --> Output Class Initialized
INFO - 2024-02-12 12:54:56 --> Security Class Initialized
DEBUG - 2024-02-12 12:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:54:56 --> Input Class Initialized
INFO - 2024-02-12 12:54:56 --> Language Class Initialized
INFO - 2024-02-12 12:54:56 --> Loader Class Initialized
INFO - 2024-02-12 12:54:56 --> Helper loaded: url_helper
INFO - 2024-02-12 12:54:56 --> Helper loaded: file_helper
INFO - 2024-02-12 12:54:56 --> Helper loaded: form_helper
INFO - 2024-02-12 12:54:56 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:54:56 --> Controller Class Initialized
INFO - 2024-02-12 12:54:56 --> Form Validation Class Initialized
INFO - 2024-02-12 12:54:56 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:54:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:54:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:54:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:54:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:54:56 --> Final output sent to browser
DEBUG - 2024-02-12 12:54:56 --> Total execution time: 0.0280
ERROR - 2024-02-12 12:55:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:55:24 --> Config Class Initialized
INFO - 2024-02-12 12:55:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:55:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:55:24 --> Utf8 Class Initialized
INFO - 2024-02-12 12:55:24 --> URI Class Initialized
INFO - 2024-02-12 12:55:24 --> Router Class Initialized
INFO - 2024-02-12 12:55:24 --> Output Class Initialized
INFO - 2024-02-12 12:55:24 --> Security Class Initialized
DEBUG - 2024-02-12 12:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:55:24 --> Input Class Initialized
INFO - 2024-02-12 12:55:24 --> Language Class Initialized
INFO - 2024-02-12 12:55:24 --> Loader Class Initialized
INFO - 2024-02-12 12:55:24 --> Helper loaded: url_helper
INFO - 2024-02-12 12:55:24 --> Helper loaded: file_helper
INFO - 2024-02-12 12:55:24 --> Helper loaded: form_helper
INFO - 2024-02-12 12:55:24 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:55:24 --> Controller Class Initialized
INFO - 2024-02-12 12:55:24 --> Form Validation Class Initialized
INFO - 2024-02-12 12:55:24 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:55:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:55:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:55:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:55:24 --> Final output sent to browser
DEBUG - 2024-02-12 12:55:24 --> Total execution time: 0.0294
ERROR - 2024-02-12 12:55:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:55:25 --> Config Class Initialized
INFO - 2024-02-12 12:55:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:55:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:55:25 --> Utf8 Class Initialized
INFO - 2024-02-12 12:55:25 --> URI Class Initialized
INFO - 2024-02-12 12:55:25 --> Router Class Initialized
INFO - 2024-02-12 12:55:25 --> Output Class Initialized
INFO - 2024-02-12 12:55:25 --> Security Class Initialized
DEBUG - 2024-02-12 12:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:55:25 --> Input Class Initialized
INFO - 2024-02-12 12:55:25 --> Language Class Initialized
INFO - 2024-02-12 12:55:25 --> Loader Class Initialized
INFO - 2024-02-12 12:55:25 --> Helper loaded: url_helper
INFO - 2024-02-12 12:55:25 --> Helper loaded: file_helper
INFO - 2024-02-12 12:55:25 --> Helper loaded: form_helper
INFO - 2024-02-12 12:55:25 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:55:25 --> Controller Class Initialized
INFO - 2024-02-12 12:55:25 --> Form Validation Class Initialized
INFO - 2024-02-12 12:55:25 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:55:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:55:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:55:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:55:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:55:28 --> Config Class Initialized
INFO - 2024-02-12 12:55:28 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:55:28 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:55:28 --> Utf8 Class Initialized
INFO - 2024-02-12 12:55:28 --> URI Class Initialized
INFO - 2024-02-12 12:55:28 --> Router Class Initialized
INFO - 2024-02-12 12:55:28 --> Output Class Initialized
INFO - 2024-02-12 12:55:28 --> Security Class Initialized
DEBUG - 2024-02-12 12:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:55:28 --> Input Class Initialized
INFO - 2024-02-12 12:55:28 --> Language Class Initialized
INFO - 2024-02-12 12:55:28 --> Loader Class Initialized
INFO - 2024-02-12 12:55:28 --> Helper loaded: url_helper
INFO - 2024-02-12 12:55:28 --> Helper loaded: file_helper
INFO - 2024-02-12 12:55:28 --> Helper loaded: form_helper
INFO - 2024-02-12 12:55:28 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:55:28 --> Controller Class Initialized
INFO - 2024-02-12 12:55:28 --> Form Validation Class Initialized
INFO - 2024-02-12 12:55:28 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:55:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:55:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:55:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:55:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:55:28 --> Final output sent to browser
DEBUG - 2024-02-12 12:55:28 --> Total execution time: 0.0377
ERROR - 2024-02-12 12:55:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:55:49 --> Config Class Initialized
INFO - 2024-02-12 12:55:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:55:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:55:49 --> Utf8 Class Initialized
INFO - 2024-02-12 12:55:49 --> URI Class Initialized
INFO - 2024-02-12 12:55:49 --> Router Class Initialized
INFO - 2024-02-12 12:55:49 --> Output Class Initialized
INFO - 2024-02-12 12:55:49 --> Security Class Initialized
DEBUG - 2024-02-12 12:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:55:49 --> Input Class Initialized
INFO - 2024-02-12 12:55:49 --> Language Class Initialized
INFO - 2024-02-12 12:55:49 --> Loader Class Initialized
INFO - 2024-02-12 12:55:49 --> Helper loaded: url_helper
INFO - 2024-02-12 12:55:49 --> Helper loaded: file_helper
INFO - 2024-02-12 12:55:49 --> Helper loaded: form_helper
INFO - 2024-02-12 12:55:49 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:55:49 --> Controller Class Initialized
INFO - 2024-02-12 12:55:49 --> Form Validation Class Initialized
INFO - 2024-02-12 12:55:49 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:55:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:55:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:55:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:55:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:55:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:55:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:55:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:55:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:55:49 --> Final output sent to browser
DEBUG - 2024-02-12 12:55:49 --> Total execution time: 0.0317
ERROR - 2024-02-12 12:55:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:55:50 --> Config Class Initialized
INFO - 2024-02-12 12:55:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:55:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:55:50 --> Utf8 Class Initialized
INFO - 2024-02-12 12:55:50 --> URI Class Initialized
INFO - 2024-02-12 12:55:50 --> Router Class Initialized
INFO - 2024-02-12 12:55:50 --> Output Class Initialized
INFO - 2024-02-12 12:55:50 --> Security Class Initialized
DEBUG - 2024-02-12 12:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:55:50 --> Input Class Initialized
INFO - 2024-02-12 12:55:50 --> Language Class Initialized
INFO - 2024-02-12 12:55:50 --> Loader Class Initialized
INFO - 2024-02-12 12:55:50 --> Helper loaded: url_helper
INFO - 2024-02-12 12:55:50 --> Helper loaded: file_helper
INFO - 2024-02-12 12:55:50 --> Helper loaded: form_helper
INFO - 2024-02-12 12:55:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:55:50 --> Controller Class Initialized
INFO - 2024-02-12 12:55:50 --> Form Validation Class Initialized
INFO - 2024-02-12 12:55:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:55:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:55:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:55:50 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:55:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:55:53 --> Config Class Initialized
INFO - 2024-02-12 12:55:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:55:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:55:53 --> Utf8 Class Initialized
INFO - 2024-02-12 12:55:53 --> URI Class Initialized
INFO - 2024-02-12 12:55:53 --> Router Class Initialized
INFO - 2024-02-12 12:55:53 --> Output Class Initialized
INFO - 2024-02-12 12:55:53 --> Security Class Initialized
DEBUG - 2024-02-12 12:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:55:53 --> Input Class Initialized
INFO - 2024-02-12 12:55:53 --> Language Class Initialized
INFO - 2024-02-12 12:55:53 --> Loader Class Initialized
INFO - 2024-02-12 12:55:53 --> Helper loaded: url_helper
INFO - 2024-02-12 12:55:53 --> Helper loaded: file_helper
INFO - 2024-02-12 12:55:53 --> Helper loaded: form_helper
INFO - 2024-02-12 12:55:53 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:55:53 --> Controller Class Initialized
INFO - 2024-02-12 12:55:53 --> Form Validation Class Initialized
INFO - 2024-02-12 12:55:53 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:55:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:55:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:55:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:55:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:55:53 --> Final output sent to browser
DEBUG - 2024-02-12 12:55:53 --> Total execution time: 0.0265
ERROR - 2024-02-12 12:56:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:56:29 --> Config Class Initialized
INFO - 2024-02-12 12:56:29 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:56:29 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:56:29 --> Utf8 Class Initialized
INFO - 2024-02-12 12:56:29 --> URI Class Initialized
INFO - 2024-02-12 12:56:29 --> Router Class Initialized
INFO - 2024-02-12 12:56:29 --> Output Class Initialized
INFO - 2024-02-12 12:56:29 --> Security Class Initialized
DEBUG - 2024-02-12 12:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:56:29 --> Input Class Initialized
INFO - 2024-02-12 12:56:29 --> Language Class Initialized
INFO - 2024-02-12 12:56:29 --> Loader Class Initialized
INFO - 2024-02-12 12:56:29 --> Helper loaded: url_helper
INFO - 2024-02-12 12:56:29 --> Helper loaded: file_helper
INFO - 2024-02-12 12:56:29 --> Helper loaded: form_helper
INFO - 2024-02-12 12:56:29 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:56:29 --> Controller Class Initialized
INFO - 2024-02-12 12:56:29 --> Form Validation Class Initialized
INFO - 2024-02-12 12:56:29 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:56:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:56:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:56:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:56:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:56:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:56:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:56:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:56:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:56:29 --> Final output sent to browser
DEBUG - 2024-02-12 12:56:29 --> Total execution time: 0.0381
ERROR - 2024-02-12 12:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:56:30 --> Config Class Initialized
INFO - 2024-02-12 12:56:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:56:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:56:30 --> Utf8 Class Initialized
INFO - 2024-02-12 12:56:30 --> URI Class Initialized
INFO - 2024-02-12 12:56:30 --> Router Class Initialized
INFO - 2024-02-12 12:56:30 --> Output Class Initialized
INFO - 2024-02-12 12:56:30 --> Security Class Initialized
DEBUG - 2024-02-12 12:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:56:30 --> Input Class Initialized
INFO - 2024-02-12 12:56:30 --> Language Class Initialized
INFO - 2024-02-12 12:56:30 --> Loader Class Initialized
INFO - 2024-02-12 12:56:30 --> Helper loaded: url_helper
INFO - 2024-02-12 12:56:30 --> Helper loaded: file_helper
INFO - 2024-02-12 12:56:30 --> Helper loaded: form_helper
INFO - 2024-02-12 12:56:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:56:30 --> Controller Class Initialized
INFO - 2024-02-12 12:56:30 --> Form Validation Class Initialized
INFO - 2024-02-12 12:56:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:56:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:56:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:56:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:56:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:56:32 --> Config Class Initialized
INFO - 2024-02-12 12:56:32 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:56:32 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:56:32 --> Utf8 Class Initialized
INFO - 2024-02-12 12:56:32 --> URI Class Initialized
INFO - 2024-02-12 12:56:32 --> Router Class Initialized
INFO - 2024-02-12 12:56:32 --> Output Class Initialized
INFO - 2024-02-12 12:56:32 --> Security Class Initialized
DEBUG - 2024-02-12 12:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:56:32 --> Input Class Initialized
INFO - 2024-02-12 12:56:32 --> Language Class Initialized
INFO - 2024-02-12 12:56:32 --> Loader Class Initialized
INFO - 2024-02-12 12:56:32 --> Helper loaded: url_helper
INFO - 2024-02-12 12:56:32 --> Helper loaded: file_helper
INFO - 2024-02-12 12:56:32 --> Helper loaded: form_helper
INFO - 2024-02-12 12:56:32 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:56:32 --> Controller Class Initialized
INFO - 2024-02-12 12:56:32 --> Form Validation Class Initialized
INFO - 2024-02-12 12:56:32 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:56:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:56:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:56:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:56:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:56:32 --> Final output sent to browser
DEBUG - 2024-02-12 12:56:32 --> Total execution time: 0.0185
ERROR - 2024-02-12 12:56:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:56:47 --> Config Class Initialized
INFO - 2024-02-12 12:56:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:56:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:56:47 --> Utf8 Class Initialized
INFO - 2024-02-12 12:56:47 --> URI Class Initialized
INFO - 2024-02-12 12:56:47 --> Router Class Initialized
INFO - 2024-02-12 12:56:47 --> Output Class Initialized
INFO - 2024-02-12 12:56:47 --> Security Class Initialized
DEBUG - 2024-02-12 12:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:56:47 --> Input Class Initialized
INFO - 2024-02-12 12:56:47 --> Language Class Initialized
INFO - 2024-02-12 12:56:47 --> Loader Class Initialized
INFO - 2024-02-12 12:56:47 --> Helper loaded: url_helper
INFO - 2024-02-12 12:56:47 --> Helper loaded: file_helper
INFO - 2024-02-12 12:56:47 --> Helper loaded: form_helper
INFO - 2024-02-12 12:56:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:56:47 --> Controller Class Initialized
INFO - 2024-02-12 12:56:47 --> Form Validation Class Initialized
INFO - 2024-02-12 12:56:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:56:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:56:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:56:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:56:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:56:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:56:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:56:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:56:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:56:47 --> Final output sent to browser
DEBUG - 2024-02-12 12:56:47 --> Total execution time: 0.0340
ERROR - 2024-02-12 12:56:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:56:48 --> Config Class Initialized
INFO - 2024-02-12 12:56:48 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:56:48 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:56:48 --> Utf8 Class Initialized
INFO - 2024-02-12 12:56:48 --> URI Class Initialized
INFO - 2024-02-12 12:56:48 --> Router Class Initialized
INFO - 2024-02-12 12:56:48 --> Output Class Initialized
INFO - 2024-02-12 12:56:48 --> Security Class Initialized
DEBUG - 2024-02-12 12:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:56:48 --> Input Class Initialized
INFO - 2024-02-12 12:56:48 --> Language Class Initialized
INFO - 2024-02-12 12:56:48 --> Loader Class Initialized
INFO - 2024-02-12 12:56:48 --> Helper loaded: url_helper
INFO - 2024-02-12 12:56:48 --> Helper loaded: file_helper
INFO - 2024-02-12 12:56:48 --> Helper loaded: form_helper
INFO - 2024-02-12 12:56:48 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:56:48 --> Controller Class Initialized
INFO - 2024-02-12 12:56:48 --> Form Validation Class Initialized
INFO - 2024-02-12 12:56:48 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:56:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:56:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:56:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:56:49 --> Config Class Initialized
INFO - 2024-02-12 12:56:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:56:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:56:49 --> Utf8 Class Initialized
INFO - 2024-02-12 12:56:49 --> URI Class Initialized
INFO - 2024-02-12 12:56:49 --> Router Class Initialized
INFO - 2024-02-12 12:56:50 --> Output Class Initialized
INFO - 2024-02-12 12:56:50 --> Security Class Initialized
DEBUG - 2024-02-12 12:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:56:50 --> Input Class Initialized
INFO - 2024-02-12 12:56:50 --> Language Class Initialized
INFO - 2024-02-12 12:56:50 --> Loader Class Initialized
INFO - 2024-02-12 12:56:50 --> Helper loaded: url_helper
INFO - 2024-02-12 12:56:50 --> Helper loaded: file_helper
INFO - 2024-02-12 12:56:50 --> Helper loaded: form_helper
INFO - 2024-02-12 12:56:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:56:50 --> Controller Class Initialized
INFO - 2024-02-12 12:56:50 --> Form Validation Class Initialized
INFO - 2024-02-12 12:56:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:56:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:56:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:56:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:56:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:56:50 --> Final output sent to browser
DEBUG - 2024-02-12 12:56:50 --> Total execution time: 0.0189
ERROR - 2024-02-12 12:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:58:18 --> Config Class Initialized
INFO - 2024-02-12 12:58:18 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:58:18 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:58:18 --> Utf8 Class Initialized
INFO - 2024-02-12 12:58:18 --> URI Class Initialized
INFO - 2024-02-12 12:58:18 --> Router Class Initialized
INFO - 2024-02-12 12:58:18 --> Output Class Initialized
INFO - 2024-02-12 12:58:18 --> Security Class Initialized
DEBUG - 2024-02-12 12:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:58:18 --> Input Class Initialized
INFO - 2024-02-12 12:58:18 --> Language Class Initialized
INFO - 2024-02-12 12:58:18 --> Loader Class Initialized
INFO - 2024-02-12 12:58:18 --> Helper loaded: url_helper
INFO - 2024-02-12 12:58:18 --> Helper loaded: file_helper
INFO - 2024-02-12 12:58:18 --> Helper loaded: form_helper
INFO - 2024-02-12 12:58:18 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:58:18 --> Controller Class Initialized
INFO - 2024-02-12 12:58:18 --> Form Validation Class Initialized
INFO - 2024-02-12 12:58:18 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:58:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:58:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:58:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:58:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:58:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:58:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:58:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:58:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:58:18 --> Final output sent to browser
DEBUG - 2024-02-12 12:58:18 --> Total execution time: 0.0405
ERROR - 2024-02-12 12:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:58:19 --> Config Class Initialized
INFO - 2024-02-12 12:58:19 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:58:19 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:58:19 --> Utf8 Class Initialized
INFO - 2024-02-12 12:58:19 --> URI Class Initialized
INFO - 2024-02-12 12:58:19 --> Router Class Initialized
INFO - 2024-02-12 12:58:19 --> Output Class Initialized
INFO - 2024-02-12 12:58:19 --> Security Class Initialized
DEBUG - 2024-02-12 12:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:58:19 --> Input Class Initialized
INFO - 2024-02-12 12:58:19 --> Language Class Initialized
INFO - 2024-02-12 12:58:19 --> Loader Class Initialized
INFO - 2024-02-12 12:58:19 --> Helper loaded: url_helper
INFO - 2024-02-12 12:58:19 --> Helper loaded: file_helper
INFO - 2024-02-12 12:58:19 --> Helper loaded: form_helper
INFO - 2024-02-12 12:58:19 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:58:19 --> Controller Class Initialized
INFO - 2024-02-12 12:58:19 --> Form Validation Class Initialized
INFO - 2024-02-12 12:58:19 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:58:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:58:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:58:19 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:58:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:58:23 --> Config Class Initialized
INFO - 2024-02-12 12:58:23 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:58:23 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:58:23 --> Utf8 Class Initialized
INFO - 2024-02-12 12:58:23 --> URI Class Initialized
INFO - 2024-02-12 12:58:23 --> Router Class Initialized
INFO - 2024-02-12 12:58:23 --> Output Class Initialized
INFO - 2024-02-12 12:58:23 --> Security Class Initialized
DEBUG - 2024-02-12 12:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:58:23 --> Input Class Initialized
INFO - 2024-02-12 12:58:23 --> Language Class Initialized
INFO - 2024-02-12 12:58:23 --> Loader Class Initialized
INFO - 2024-02-12 12:58:23 --> Helper loaded: url_helper
INFO - 2024-02-12 12:58:23 --> Helper loaded: file_helper
INFO - 2024-02-12 12:58:23 --> Helper loaded: form_helper
INFO - 2024-02-12 12:58:23 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:58:23 --> Controller Class Initialized
INFO - 2024-02-12 12:58:23 --> Form Validation Class Initialized
INFO - 2024-02-12 12:58:23 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:58:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:58:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:58:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:58:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:58:23 --> Final output sent to browser
DEBUG - 2024-02-12 12:58:23 --> Total execution time: 0.0305
ERROR - 2024-02-12 12:59:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:59:08 --> Config Class Initialized
INFO - 2024-02-12 12:59:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:59:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:59:08 --> Utf8 Class Initialized
INFO - 2024-02-12 12:59:08 --> URI Class Initialized
INFO - 2024-02-12 12:59:08 --> Router Class Initialized
INFO - 2024-02-12 12:59:08 --> Output Class Initialized
INFO - 2024-02-12 12:59:08 --> Security Class Initialized
DEBUG - 2024-02-12 12:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:59:08 --> Input Class Initialized
INFO - 2024-02-12 12:59:08 --> Language Class Initialized
INFO - 2024-02-12 12:59:08 --> Loader Class Initialized
INFO - 2024-02-12 12:59:08 --> Helper loaded: url_helper
INFO - 2024-02-12 12:59:08 --> Helper loaded: file_helper
INFO - 2024-02-12 12:59:08 --> Helper loaded: form_helper
INFO - 2024-02-12 12:59:08 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:59:08 --> Controller Class Initialized
INFO - 2024-02-12 12:59:08 --> Form Validation Class Initialized
INFO - 2024-02-12 12:59:08 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:59:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:59:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:59:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:59:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:59:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:59:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:59:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:59:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:59:08 --> Final output sent to browser
DEBUG - 2024-02-12 12:59:08 --> Total execution time: 0.0359
ERROR - 2024-02-12 12:59:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:59:09 --> Config Class Initialized
INFO - 2024-02-12 12:59:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:59:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:59:09 --> Utf8 Class Initialized
INFO - 2024-02-12 12:59:09 --> URI Class Initialized
INFO - 2024-02-12 12:59:09 --> Router Class Initialized
INFO - 2024-02-12 12:59:09 --> Output Class Initialized
INFO - 2024-02-12 12:59:09 --> Security Class Initialized
DEBUG - 2024-02-12 12:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:59:09 --> Input Class Initialized
INFO - 2024-02-12 12:59:09 --> Language Class Initialized
INFO - 2024-02-12 12:59:09 --> Loader Class Initialized
INFO - 2024-02-12 12:59:09 --> Helper loaded: url_helper
INFO - 2024-02-12 12:59:09 --> Helper loaded: file_helper
INFO - 2024-02-12 12:59:09 --> Helper loaded: form_helper
INFO - 2024-02-12 12:59:09 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:59:09 --> Controller Class Initialized
INFO - 2024-02-12 12:59:09 --> Form Validation Class Initialized
INFO - 2024-02-12 12:59:09 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:59:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:59:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:59:09 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:59:11 --> Config Class Initialized
INFO - 2024-02-12 12:59:11 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:59:11 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:59:11 --> Utf8 Class Initialized
INFO - 2024-02-12 12:59:11 --> URI Class Initialized
INFO - 2024-02-12 12:59:11 --> Router Class Initialized
INFO - 2024-02-12 12:59:11 --> Output Class Initialized
INFO - 2024-02-12 12:59:11 --> Security Class Initialized
DEBUG - 2024-02-12 12:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:59:11 --> Input Class Initialized
INFO - 2024-02-12 12:59:11 --> Language Class Initialized
INFO - 2024-02-12 12:59:11 --> Loader Class Initialized
INFO - 2024-02-12 12:59:11 --> Helper loaded: url_helper
INFO - 2024-02-12 12:59:11 --> Helper loaded: file_helper
INFO - 2024-02-12 12:59:11 --> Helper loaded: form_helper
INFO - 2024-02-12 12:59:11 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:59:11 --> Controller Class Initialized
INFO - 2024-02-12 12:59:11 --> Form Validation Class Initialized
INFO - 2024-02-12 12:59:11 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:59:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:59:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:59:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:59:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:59:11 --> Final output sent to browser
DEBUG - 2024-02-12 12:59:11 --> Total execution time: 0.0315
ERROR - 2024-02-12 12:59:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:59:17 --> Config Class Initialized
INFO - 2024-02-12 12:59:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:59:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:59:17 --> Utf8 Class Initialized
INFO - 2024-02-12 12:59:17 --> URI Class Initialized
INFO - 2024-02-12 12:59:17 --> Router Class Initialized
INFO - 2024-02-12 12:59:17 --> Output Class Initialized
INFO - 2024-02-12 12:59:17 --> Security Class Initialized
DEBUG - 2024-02-12 12:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:59:17 --> Input Class Initialized
INFO - 2024-02-12 12:59:17 --> Language Class Initialized
INFO - 2024-02-12 12:59:17 --> Loader Class Initialized
INFO - 2024-02-12 12:59:17 --> Helper loaded: url_helper
INFO - 2024-02-12 12:59:17 --> Helper loaded: file_helper
INFO - 2024-02-12 12:59:17 --> Helper loaded: form_helper
INFO - 2024-02-12 12:59:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:59:17 --> Controller Class Initialized
INFO - 2024-02-12 12:59:17 --> Form Validation Class Initialized
INFO - 2024-02-12 12:59:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:59:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:59:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:59:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:59:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 12:59:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 12:59:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 12:59:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 12:59:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 12:59:17 --> Final output sent to browser
DEBUG - 2024-02-12 12:59:17 --> Total execution time: 0.0305
ERROR - 2024-02-12 12:59:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:59:17 --> Config Class Initialized
INFO - 2024-02-12 12:59:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:59:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:59:17 --> Utf8 Class Initialized
INFO - 2024-02-12 12:59:17 --> URI Class Initialized
INFO - 2024-02-12 12:59:17 --> Router Class Initialized
INFO - 2024-02-12 12:59:17 --> Output Class Initialized
INFO - 2024-02-12 12:59:17 --> Security Class Initialized
DEBUG - 2024-02-12 12:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:59:17 --> Input Class Initialized
INFO - 2024-02-12 12:59:17 --> Language Class Initialized
INFO - 2024-02-12 12:59:17 --> Loader Class Initialized
INFO - 2024-02-12 12:59:17 --> Helper loaded: url_helper
INFO - 2024-02-12 12:59:17 --> Helper loaded: file_helper
INFO - 2024-02-12 12:59:17 --> Helper loaded: form_helper
INFO - 2024-02-12 12:59:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:59:17 --> Controller Class Initialized
INFO - 2024-02-12 12:59:17 --> Form Validation Class Initialized
INFO - 2024-02-12 12:59:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:59:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:59:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:59:17 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 12:59:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 12:59:21 --> Config Class Initialized
INFO - 2024-02-12 12:59:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:59:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:59:21 --> Utf8 Class Initialized
INFO - 2024-02-12 12:59:21 --> URI Class Initialized
INFO - 2024-02-12 12:59:21 --> Router Class Initialized
INFO - 2024-02-12 12:59:21 --> Output Class Initialized
INFO - 2024-02-12 12:59:21 --> Security Class Initialized
DEBUG - 2024-02-12 12:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:59:21 --> Input Class Initialized
INFO - 2024-02-12 12:59:21 --> Language Class Initialized
INFO - 2024-02-12 12:59:21 --> Loader Class Initialized
INFO - 2024-02-12 12:59:21 --> Helper loaded: url_helper
INFO - 2024-02-12 12:59:21 --> Helper loaded: file_helper
INFO - 2024-02-12 12:59:21 --> Helper loaded: form_helper
INFO - 2024-02-12 12:59:21 --> Database Driver Class Initialized
DEBUG - 2024-02-12 12:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 12:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:59:21 --> Controller Class Initialized
INFO - 2024-02-12 12:59:21 --> Form Validation Class Initialized
INFO - 2024-02-12 12:59:21 --> Model "MasterModel" initialized
INFO - 2024-02-12 12:59:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 12:59:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 12:59:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 12:59:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 12:59:21 --> Final output sent to browser
DEBUG - 2024-02-12 12:59:21 --> Total execution time: 0.0349
ERROR - 2024-02-12 13:00:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:00:08 --> Config Class Initialized
INFO - 2024-02-12 13:00:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:00:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:00:08 --> Utf8 Class Initialized
INFO - 2024-02-12 13:00:08 --> URI Class Initialized
INFO - 2024-02-12 13:00:08 --> Router Class Initialized
INFO - 2024-02-12 13:00:08 --> Output Class Initialized
INFO - 2024-02-12 13:00:08 --> Security Class Initialized
DEBUG - 2024-02-12 13:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:00:08 --> Input Class Initialized
INFO - 2024-02-12 13:00:08 --> Language Class Initialized
INFO - 2024-02-12 13:00:08 --> Loader Class Initialized
INFO - 2024-02-12 13:00:08 --> Helper loaded: url_helper
INFO - 2024-02-12 13:00:08 --> Helper loaded: file_helper
INFO - 2024-02-12 13:00:08 --> Helper loaded: form_helper
INFO - 2024-02-12 13:00:08 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:00:08 --> Controller Class Initialized
INFO - 2024-02-12 13:00:08 --> Form Validation Class Initialized
INFO - 2024-02-12 13:00:08 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:00:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:00:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:00:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 13:00:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 13:00:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 13:00:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 13:00:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 13:00:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 13:00:08 --> Final output sent to browser
DEBUG - 2024-02-12 13:00:08 --> Total execution time: 0.0389
ERROR - 2024-02-12 13:00:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:00:08 --> Config Class Initialized
INFO - 2024-02-12 13:00:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:00:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:00:08 --> Utf8 Class Initialized
INFO - 2024-02-12 13:00:08 --> URI Class Initialized
INFO - 2024-02-12 13:00:08 --> Router Class Initialized
INFO - 2024-02-12 13:00:08 --> Output Class Initialized
INFO - 2024-02-12 13:00:08 --> Security Class Initialized
DEBUG - 2024-02-12 13:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:00:08 --> Input Class Initialized
INFO - 2024-02-12 13:00:08 --> Language Class Initialized
INFO - 2024-02-12 13:00:08 --> Loader Class Initialized
INFO - 2024-02-12 13:00:08 --> Helper loaded: url_helper
INFO - 2024-02-12 13:00:08 --> Helper loaded: file_helper
INFO - 2024-02-12 13:00:08 --> Helper loaded: form_helper
INFO - 2024-02-12 13:00:08 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:00:08 --> Controller Class Initialized
INFO - 2024-02-12 13:00:08 --> Form Validation Class Initialized
INFO - 2024-02-12 13:00:08 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:00:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:00:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:00:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 13:00:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:00:10 --> Config Class Initialized
INFO - 2024-02-12 13:00:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:00:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:00:10 --> Utf8 Class Initialized
INFO - 2024-02-12 13:00:10 --> URI Class Initialized
INFO - 2024-02-12 13:00:10 --> Router Class Initialized
INFO - 2024-02-12 13:00:10 --> Output Class Initialized
INFO - 2024-02-12 13:00:10 --> Security Class Initialized
DEBUG - 2024-02-12 13:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:00:10 --> Input Class Initialized
INFO - 2024-02-12 13:00:10 --> Language Class Initialized
INFO - 2024-02-12 13:00:10 --> Loader Class Initialized
INFO - 2024-02-12 13:00:10 --> Helper loaded: url_helper
INFO - 2024-02-12 13:00:10 --> Helper loaded: file_helper
INFO - 2024-02-12 13:00:10 --> Helper loaded: form_helper
INFO - 2024-02-12 13:00:10 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:00:10 --> Controller Class Initialized
INFO - 2024-02-12 13:00:10 --> Form Validation Class Initialized
INFO - 2024-02-12 13:00:10 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:00:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:00:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:00:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 13:00:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 13:00:10 --> Final output sent to browser
DEBUG - 2024-02-12 13:00:10 --> Total execution time: 0.0339
ERROR - 2024-02-12 13:00:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:00:30 --> Config Class Initialized
INFO - 2024-02-12 13:00:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:00:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:00:30 --> Utf8 Class Initialized
INFO - 2024-02-12 13:00:30 --> URI Class Initialized
INFO - 2024-02-12 13:00:30 --> Router Class Initialized
INFO - 2024-02-12 13:00:30 --> Output Class Initialized
INFO - 2024-02-12 13:00:30 --> Security Class Initialized
DEBUG - 2024-02-12 13:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:00:30 --> Input Class Initialized
INFO - 2024-02-12 13:00:30 --> Language Class Initialized
INFO - 2024-02-12 13:00:30 --> Loader Class Initialized
INFO - 2024-02-12 13:00:30 --> Helper loaded: url_helper
INFO - 2024-02-12 13:00:30 --> Helper loaded: file_helper
INFO - 2024-02-12 13:00:30 --> Helper loaded: form_helper
INFO - 2024-02-12 13:00:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:00:30 --> Controller Class Initialized
INFO - 2024-02-12 13:00:30 --> Form Validation Class Initialized
INFO - 2024-02-12 13:00:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:00:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:00:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:00:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 13:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 13:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 13:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 13:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 13:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 13:00:30 --> Final output sent to browser
DEBUG - 2024-02-12 13:00:30 --> Total execution time: 0.0279
ERROR - 2024-02-12 13:00:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:00:30 --> Config Class Initialized
INFO - 2024-02-12 13:00:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:00:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:00:30 --> Utf8 Class Initialized
INFO - 2024-02-12 13:00:30 --> URI Class Initialized
INFO - 2024-02-12 13:00:30 --> Router Class Initialized
INFO - 2024-02-12 13:00:30 --> Output Class Initialized
INFO - 2024-02-12 13:00:30 --> Security Class Initialized
DEBUG - 2024-02-12 13:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:00:30 --> Input Class Initialized
INFO - 2024-02-12 13:00:30 --> Language Class Initialized
INFO - 2024-02-12 13:00:30 --> Loader Class Initialized
INFO - 2024-02-12 13:00:30 --> Helper loaded: url_helper
INFO - 2024-02-12 13:00:30 --> Helper loaded: file_helper
INFO - 2024-02-12 13:00:30 --> Helper loaded: form_helper
INFO - 2024-02-12 13:00:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:00:30 --> Controller Class Initialized
INFO - 2024-02-12 13:00:30 --> Form Validation Class Initialized
INFO - 2024-02-12 13:00:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:00:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:00:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:00:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 13:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:00:32 --> Config Class Initialized
INFO - 2024-02-12 13:00:32 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:00:32 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:00:32 --> Utf8 Class Initialized
INFO - 2024-02-12 13:00:32 --> URI Class Initialized
INFO - 2024-02-12 13:00:32 --> Router Class Initialized
INFO - 2024-02-12 13:00:32 --> Output Class Initialized
INFO - 2024-02-12 13:00:32 --> Security Class Initialized
DEBUG - 2024-02-12 13:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:00:32 --> Input Class Initialized
INFO - 2024-02-12 13:00:32 --> Language Class Initialized
INFO - 2024-02-12 13:00:32 --> Loader Class Initialized
INFO - 2024-02-12 13:00:32 --> Helper loaded: url_helper
INFO - 2024-02-12 13:00:32 --> Helper loaded: file_helper
INFO - 2024-02-12 13:00:32 --> Helper loaded: form_helper
INFO - 2024-02-12 13:00:32 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:00:32 --> Controller Class Initialized
INFO - 2024-02-12 13:00:32 --> Form Validation Class Initialized
INFO - 2024-02-12 13:00:32 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:00:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:00:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:00:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 13:00:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 13:00:32 --> Final output sent to browser
DEBUG - 2024-02-12 13:00:32 --> Total execution time: 0.0287
ERROR - 2024-02-12 13:04:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:04:28 --> Config Class Initialized
INFO - 2024-02-12 13:04:28 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:04:28 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:04:28 --> Utf8 Class Initialized
INFO - 2024-02-12 13:04:28 --> URI Class Initialized
INFO - 2024-02-12 13:04:28 --> Router Class Initialized
INFO - 2024-02-12 13:04:28 --> Output Class Initialized
INFO - 2024-02-12 13:04:28 --> Security Class Initialized
DEBUG - 2024-02-12 13:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:04:28 --> Input Class Initialized
INFO - 2024-02-12 13:04:28 --> Language Class Initialized
INFO - 2024-02-12 13:04:28 --> Loader Class Initialized
INFO - 2024-02-12 13:04:28 --> Helper loaded: url_helper
INFO - 2024-02-12 13:04:28 --> Helper loaded: file_helper
INFO - 2024-02-12 13:04:28 --> Helper loaded: form_helper
INFO - 2024-02-12 13:04:28 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:04:28 --> Controller Class Initialized
INFO - 2024-02-12 13:04:28 --> Form Validation Class Initialized
INFO - 2024-02-12 13:04:28 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:04:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:04:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:04:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 13:04:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 13:04:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 13:04:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 13:04:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 13:04:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 13:04:28 --> Final output sent to browser
DEBUG - 2024-02-12 13:04:28 --> Total execution time: 0.0239
ERROR - 2024-02-12 13:04:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:04:29 --> Config Class Initialized
INFO - 2024-02-12 13:04:29 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:04:29 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:04:29 --> Utf8 Class Initialized
INFO - 2024-02-12 13:04:29 --> URI Class Initialized
INFO - 2024-02-12 13:04:29 --> Router Class Initialized
INFO - 2024-02-12 13:04:29 --> Output Class Initialized
INFO - 2024-02-12 13:04:29 --> Security Class Initialized
DEBUG - 2024-02-12 13:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:04:29 --> Input Class Initialized
INFO - 2024-02-12 13:04:29 --> Language Class Initialized
INFO - 2024-02-12 13:04:29 --> Loader Class Initialized
INFO - 2024-02-12 13:04:29 --> Helper loaded: url_helper
INFO - 2024-02-12 13:04:29 --> Helper loaded: file_helper
INFO - 2024-02-12 13:04:29 --> Helper loaded: form_helper
INFO - 2024-02-12 13:04:29 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:04:29 --> Controller Class Initialized
INFO - 2024-02-12 13:04:29 --> Form Validation Class Initialized
INFO - 2024-02-12 13:04:29 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:04:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:04:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:04:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 13:04:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:04:30 --> Config Class Initialized
INFO - 2024-02-12 13:04:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:04:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:04:30 --> Utf8 Class Initialized
INFO - 2024-02-12 13:04:30 --> URI Class Initialized
INFO - 2024-02-12 13:04:30 --> Router Class Initialized
INFO - 2024-02-12 13:04:30 --> Output Class Initialized
INFO - 2024-02-12 13:04:30 --> Security Class Initialized
DEBUG - 2024-02-12 13:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:04:30 --> Input Class Initialized
INFO - 2024-02-12 13:04:30 --> Language Class Initialized
INFO - 2024-02-12 13:04:30 --> Loader Class Initialized
INFO - 2024-02-12 13:04:30 --> Helper loaded: url_helper
INFO - 2024-02-12 13:04:30 --> Helper loaded: file_helper
INFO - 2024-02-12 13:04:30 --> Helper loaded: form_helper
INFO - 2024-02-12 13:04:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:04:30 --> Controller Class Initialized
INFO - 2024-02-12 13:04:30 --> Form Validation Class Initialized
INFO - 2024-02-12 13:04:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:04:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:04:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:04:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 13:04:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 13:04:30 --> Final output sent to browser
DEBUG - 2024-02-12 13:04:30 --> Total execution time: 0.0195
ERROR - 2024-02-12 13:05:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:05:29 --> Config Class Initialized
INFO - 2024-02-12 13:05:29 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:05:29 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:05:29 --> Utf8 Class Initialized
INFO - 2024-02-12 13:05:29 --> URI Class Initialized
INFO - 2024-02-12 13:05:29 --> Router Class Initialized
INFO - 2024-02-12 13:05:29 --> Output Class Initialized
INFO - 2024-02-12 13:05:29 --> Security Class Initialized
DEBUG - 2024-02-12 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:05:29 --> Input Class Initialized
INFO - 2024-02-12 13:05:29 --> Language Class Initialized
INFO - 2024-02-12 13:05:29 --> Loader Class Initialized
INFO - 2024-02-12 13:05:29 --> Helper loaded: url_helper
INFO - 2024-02-12 13:05:29 --> Helper loaded: file_helper
INFO - 2024-02-12 13:05:29 --> Helper loaded: form_helper
INFO - 2024-02-12 13:05:29 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:05:29 --> Controller Class Initialized
INFO - 2024-02-12 13:05:29 --> Form Validation Class Initialized
INFO - 2024-02-12 13:05:29 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:05:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:05:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:05:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 13:05:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 13:05:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 13:05:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 13:05:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 13:05:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 13:05:29 --> Final output sent to browser
DEBUG - 2024-02-12 13:05:29 --> Total execution time: 0.0364
ERROR - 2024-02-12 13:05:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:05:29 --> Config Class Initialized
INFO - 2024-02-12 13:05:29 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:05:29 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:05:29 --> Utf8 Class Initialized
INFO - 2024-02-12 13:05:29 --> URI Class Initialized
INFO - 2024-02-12 13:05:29 --> Router Class Initialized
INFO - 2024-02-12 13:05:29 --> Output Class Initialized
INFO - 2024-02-12 13:05:29 --> Security Class Initialized
DEBUG - 2024-02-12 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:05:29 --> Input Class Initialized
INFO - 2024-02-12 13:05:29 --> Language Class Initialized
INFO - 2024-02-12 13:05:29 --> Loader Class Initialized
INFO - 2024-02-12 13:05:29 --> Helper loaded: url_helper
INFO - 2024-02-12 13:05:29 --> Helper loaded: file_helper
INFO - 2024-02-12 13:05:29 --> Helper loaded: form_helper
INFO - 2024-02-12 13:05:29 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:05:29 --> Controller Class Initialized
INFO - 2024-02-12 13:05:29 --> Form Validation Class Initialized
INFO - 2024-02-12 13:05:29 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:05:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:05:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:05:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 13:05:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 13:05:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 13:05:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 13:05:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 13:05:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 13:05:29 --> Final output sent to browser
DEBUG - 2024-02-12 13:05:29 --> Total execution time: 0.0308
ERROR - 2024-02-12 13:05:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:05:30 --> Config Class Initialized
INFO - 2024-02-12 13:05:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:05:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:05:30 --> Utf8 Class Initialized
INFO - 2024-02-12 13:05:30 --> URI Class Initialized
INFO - 2024-02-12 13:05:30 --> Router Class Initialized
INFO - 2024-02-12 13:05:30 --> Output Class Initialized
INFO - 2024-02-12 13:05:30 --> Security Class Initialized
DEBUG - 2024-02-12 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:05:30 --> Input Class Initialized
INFO - 2024-02-12 13:05:30 --> Language Class Initialized
INFO - 2024-02-12 13:05:30 --> Loader Class Initialized
INFO - 2024-02-12 13:05:30 --> Helper loaded: url_helper
INFO - 2024-02-12 13:05:30 --> Helper loaded: file_helper
INFO - 2024-02-12 13:05:30 --> Helper loaded: form_helper
INFO - 2024-02-12 13:05:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:05:30 --> Controller Class Initialized
INFO - 2024-02-12 13:05:30 --> Form Validation Class Initialized
INFO - 2024-02-12 13:05:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:05:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:05:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:05:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 13:05:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:05:33 --> Config Class Initialized
INFO - 2024-02-12 13:05:33 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:05:33 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:05:33 --> Utf8 Class Initialized
INFO - 2024-02-12 13:05:33 --> URI Class Initialized
INFO - 2024-02-12 13:05:33 --> Router Class Initialized
INFO - 2024-02-12 13:05:33 --> Output Class Initialized
INFO - 2024-02-12 13:05:33 --> Security Class Initialized
DEBUG - 2024-02-12 13:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:05:33 --> Input Class Initialized
INFO - 2024-02-12 13:05:33 --> Language Class Initialized
INFO - 2024-02-12 13:05:33 --> Loader Class Initialized
INFO - 2024-02-12 13:05:33 --> Helper loaded: url_helper
INFO - 2024-02-12 13:05:33 --> Helper loaded: file_helper
INFO - 2024-02-12 13:05:33 --> Helper loaded: form_helper
INFO - 2024-02-12 13:05:33 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:05:33 --> Controller Class Initialized
INFO - 2024-02-12 13:05:33 --> Form Validation Class Initialized
INFO - 2024-02-12 13:05:33 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:05:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:05:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:05:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 13:05:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 13:05:33 --> Final output sent to browser
DEBUG - 2024-02-12 13:05:33 --> Total execution time: 0.0276
ERROR - 2024-02-12 13:07:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:07:03 --> Config Class Initialized
INFO - 2024-02-12 13:07:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:07:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:07:03 --> Utf8 Class Initialized
INFO - 2024-02-12 13:07:03 --> URI Class Initialized
INFO - 2024-02-12 13:07:03 --> Router Class Initialized
INFO - 2024-02-12 13:07:03 --> Output Class Initialized
INFO - 2024-02-12 13:07:03 --> Security Class Initialized
DEBUG - 2024-02-12 13:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:07:03 --> Input Class Initialized
INFO - 2024-02-12 13:07:03 --> Language Class Initialized
INFO - 2024-02-12 13:07:03 --> Loader Class Initialized
INFO - 2024-02-12 13:07:03 --> Helper loaded: url_helper
INFO - 2024-02-12 13:07:03 --> Helper loaded: file_helper
INFO - 2024-02-12 13:07:03 --> Helper loaded: form_helper
INFO - 2024-02-12 13:07:03 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:07:03 --> Controller Class Initialized
INFO - 2024-02-12 13:07:03 --> Form Validation Class Initialized
INFO - 2024-02-12 13:07:03 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:07:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:07:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:07:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 13:07:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 13:07:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 13:07:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 13:07:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 13:07:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 13:07:03 --> Final output sent to browser
DEBUG - 2024-02-12 13:07:03 --> Total execution time: 0.0345
ERROR - 2024-02-12 13:07:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:07:04 --> Config Class Initialized
INFO - 2024-02-12 13:07:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:07:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:07:04 --> Utf8 Class Initialized
INFO - 2024-02-12 13:07:04 --> URI Class Initialized
INFO - 2024-02-12 13:07:04 --> Router Class Initialized
INFO - 2024-02-12 13:07:04 --> Output Class Initialized
INFO - 2024-02-12 13:07:04 --> Security Class Initialized
DEBUG - 2024-02-12 13:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:07:04 --> Input Class Initialized
INFO - 2024-02-12 13:07:04 --> Language Class Initialized
INFO - 2024-02-12 13:07:04 --> Loader Class Initialized
INFO - 2024-02-12 13:07:04 --> Helper loaded: url_helper
INFO - 2024-02-12 13:07:04 --> Helper loaded: file_helper
INFO - 2024-02-12 13:07:04 --> Helper loaded: form_helper
INFO - 2024-02-12 13:07:04 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:07:04 --> Controller Class Initialized
INFO - 2024-02-12 13:07:04 --> Form Validation Class Initialized
INFO - 2024-02-12 13:07:04 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:07:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:07:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:07:04 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 13:07:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 13:07:09 --> Config Class Initialized
INFO - 2024-02-12 13:07:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:07:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:07:09 --> Utf8 Class Initialized
INFO - 2024-02-12 13:07:09 --> URI Class Initialized
INFO - 2024-02-12 13:07:09 --> Router Class Initialized
INFO - 2024-02-12 13:07:09 --> Output Class Initialized
INFO - 2024-02-12 13:07:09 --> Security Class Initialized
DEBUG - 2024-02-12 13:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:07:09 --> Input Class Initialized
INFO - 2024-02-12 13:07:09 --> Language Class Initialized
INFO - 2024-02-12 13:07:09 --> Loader Class Initialized
INFO - 2024-02-12 13:07:09 --> Helper loaded: url_helper
INFO - 2024-02-12 13:07:09 --> Helper loaded: file_helper
INFO - 2024-02-12 13:07:09 --> Helper loaded: form_helper
INFO - 2024-02-12 13:07:09 --> Database Driver Class Initialized
DEBUG - 2024-02-12 13:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 13:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:07:09 --> Controller Class Initialized
INFO - 2024-02-12 13:07:09 --> Form Validation Class Initialized
INFO - 2024-02-12 13:07:09 --> Model "MasterModel" initialized
INFO - 2024-02-12 13:07:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 13:07:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 13:07:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 13:07:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 13:07:09 --> Final output sent to browser
DEBUG - 2024-02-12 13:07:09 --> Total execution time: 0.0272
ERROR - 2024-02-12 19:31:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:01 --> Config Class Initialized
INFO - 2024-02-12 19:31:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:01 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:01 --> URI Class Initialized
INFO - 2024-02-12 19:31:01 --> Router Class Initialized
INFO - 2024-02-12 19:31:01 --> Output Class Initialized
INFO - 2024-02-12 19:31:01 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:01 --> Input Class Initialized
INFO - 2024-02-12 19:31:01 --> Language Class Initialized
INFO - 2024-02-12 19:31:01 --> Loader Class Initialized
INFO - 2024-02-12 19:31:01 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:01 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:01 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:01 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:01 --> Controller Class Initialized
INFO - 2024-02-12 19:31:01 --> Model "LoginModel" initialized
INFO - 2024-02-12 19:31:01 --> Form Validation Class Initialized
ERROR - 2024-02-12 19:31:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:01 --> Config Class Initialized
INFO - 2024-02-12 19:31:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:01 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:01 --> URI Class Initialized
INFO - 2024-02-12 19:31:01 --> Router Class Initialized
INFO - 2024-02-12 19:31:01 --> Output Class Initialized
INFO - 2024-02-12 19:31:01 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:01 --> Input Class Initialized
INFO - 2024-02-12 19:31:01 --> Language Class Initialized
INFO - 2024-02-12 19:31:01 --> Loader Class Initialized
INFO - 2024-02-12 19:31:01 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:01 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:01 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:01 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:01 --> Controller Class Initialized
INFO - 2024-02-12 19:31:01 --> Form Validation Class Initialized
INFO - 2024-02-12 19:31:01 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:31:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:31:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:31:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:31:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:31:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-12 19:31:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:31:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:31:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:31:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-12 19:31:01 --> Final output sent to browser
DEBUG - 2024-02-12 19:31:01 --> Total execution time: 0.0240
ERROR - 2024-02-12 19:31:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:05 --> Config Class Initialized
INFO - 2024-02-12 19:31:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:05 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:05 --> URI Class Initialized
INFO - 2024-02-12 19:31:05 --> Router Class Initialized
INFO - 2024-02-12 19:31:05 --> Output Class Initialized
INFO - 2024-02-12 19:31:05 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:05 --> Input Class Initialized
INFO - 2024-02-12 19:31:05 --> Language Class Initialized
INFO - 2024-02-12 19:31:05 --> Loader Class Initialized
INFO - 2024-02-12 19:31:05 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:05 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:05 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:05 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:05 --> Controller Class Initialized
INFO - 2024-02-12 19:31:05 --> Form Validation Class Initialized
INFO - 2024-02-12 19:31:05 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:31:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:31:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:31:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:31:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:31:05 --> Final output sent to browser
DEBUG - 2024-02-12 19:31:05 --> Total execution time: 0.0268
ERROR - 2024-02-12 19:31:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:05 --> Config Class Initialized
INFO - 2024-02-12 19:31:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:05 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:05 --> URI Class Initialized
INFO - 2024-02-12 19:31:05 --> Router Class Initialized
INFO - 2024-02-12 19:31:05 --> Output Class Initialized
INFO - 2024-02-12 19:31:05 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:05 --> Input Class Initialized
INFO - 2024-02-12 19:31:05 --> Language Class Initialized
INFO - 2024-02-12 19:31:05 --> Loader Class Initialized
INFO - 2024-02-12 19:31:05 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:05 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:05 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:05 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:05 --> Controller Class Initialized
INFO - 2024-02-12 19:31:05 --> Form Validation Class Initialized
INFO - 2024-02-12 19:31:05 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:31:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:31:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:31:05 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:08 --> Config Class Initialized
INFO - 2024-02-12 19:31:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:08 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:08 --> URI Class Initialized
INFO - 2024-02-12 19:31:08 --> Router Class Initialized
INFO - 2024-02-12 19:31:08 --> Output Class Initialized
INFO - 2024-02-12 19:31:08 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:08 --> Input Class Initialized
INFO - 2024-02-12 19:31:08 --> Language Class Initialized
INFO - 2024-02-12 19:31:08 --> Loader Class Initialized
INFO - 2024-02-12 19:31:08 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:08 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:08 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:08 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:08 --> Controller Class Initialized
INFO - 2024-02-12 19:31:08 --> Form Validation Class Initialized
INFO - 2024-02-12 19:31:08 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:31:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:31:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:31:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:31:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:31:08 --> Final output sent to browser
DEBUG - 2024-02-12 19:31:08 --> Total execution time: 0.0363
ERROR - 2024-02-12 19:31:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:22 --> Config Class Initialized
INFO - 2024-02-12 19:31:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:22 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:22 --> URI Class Initialized
INFO - 2024-02-12 19:31:22 --> Router Class Initialized
INFO - 2024-02-12 19:31:22 --> Output Class Initialized
INFO - 2024-02-12 19:31:22 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:22 --> Input Class Initialized
INFO - 2024-02-12 19:31:22 --> Language Class Initialized
INFO - 2024-02-12 19:31:22 --> Loader Class Initialized
INFO - 2024-02-12 19:31:22 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:22 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:22 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:22 --> Controller Class Initialized
INFO - 2024-02-12 19:31:22 --> Model "LoginModel" initialized
INFO - 2024-02-12 19:31:22 --> Form Validation Class Initialized
ERROR - 2024-02-12 19:31:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:22 --> Config Class Initialized
INFO - 2024-02-12 19:31:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:22 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:22 --> URI Class Initialized
INFO - 2024-02-12 19:31:22 --> Router Class Initialized
INFO - 2024-02-12 19:31:22 --> Output Class Initialized
INFO - 2024-02-12 19:31:22 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:22 --> Input Class Initialized
INFO - 2024-02-12 19:31:22 --> Language Class Initialized
INFO - 2024-02-12 19:31:22 --> Loader Class Initialized
INFO - 2024-02-12 19:31:22 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:22 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:22 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:22 --> Controller Class Initialized
INFO - 2024-02-12 19:31:22 --> Model "LoginModel" initialized
INFO - 2024-02-12 19:31:22 --> Form Validation Class Initialized
INFO - 2024-02-12 19:31:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-12 19:31:22 --> Final output sent to browser
DEBUG - 2024-02-12 19:31:22 --> Total execution time: 0.0277
ERROR - 2024-02-12 19:31:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:24 --> Config Class Initialized
INFO - 2024-02-12 19:31:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:24 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:24 --> URI Class Initialized
INFO - 2024-02-12 19:31:24 --> Router Class Initialized
INFO - 2024-02-12 19:31:24 --> Output Class Initialized
INFO - 2024-02-12 19:31:24 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:24 --> Input Class Initialized
INFO - 2024-02-12 19:31:24 --> Language Class Initialized
INFO - 2024-02-12 19:31:24 --> Loader Class Initialized
INFO - 2024-02-12 19:31:24 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:24 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:24 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:24 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:24 --> Controller Class Initialized
INFO - 2024-02-12 19:31:24 --> Model "LoginModel" initialized
INFO - 2024-02-12 19:31:24 --> Form Validation Class Initialized
INFO - 2024-02-12 19:31:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-12 19:31:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:24 --> Config Class Initialized
INFO - 2024-02-12 19:31:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:24 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:24 --> URI Class Initialized
INFO - 2024-02-12 19:31:24 --> Router Class Initialized
INFO - 2024-02-12 19:31:24 --> Output Class Initialized
INFO - 2024-02-12 19:31:24 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:24 --> Input Class Initialized
INFO - 2024-02-12 19:31:24 --> Language Class Initialized
INFO - 2024-02-12 19:31:24 --> Loader Class Initialized
INFO - 2024-02-12 19:31:24 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:24 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:24 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:24 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:24 --> Controller Class Initialized
INFO - 2024-02-12 19:31:24 --> Form Validation Class Initialized
INFO - 2024-02-12 19:31:24 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:31:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:31:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:31:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:31:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:31:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-12 19:31:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:31:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:31:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:31:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-12 19:31:24 --> Final output sent to browser
DEBUG - 2024-02-12 19:31:24 --> Total execution time: 0.0288
ERROR - 2024-02-12 19:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:26 --> Config Class Initialized
INFO - 2024-02-12 19:31:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:26 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:26 --> URI Class Initialized
INFO - 2024-02-12 19:31:26 --> Router Class Initialized
INFO - 2024-02-12 19:31:26 --> Output Class Initialized
INFO - 2024-02-12 19:31:26 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:26 --> Input Class Initialized
INFO - 2024-02-12 19:31:26 --> Language Class Initialized
INFO - 2024-02-12 19:31:26 --> Loader Class Initialized
INFO - 2024-02-12 19:31:26 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:26 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:26 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:26 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:26 --> Controller Class Initialized
INFO - 2024-02-12 19:31:26 --> Form Validation Class Initialized
INFO - 2024-02-12 19:31:26 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:31:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:31:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:31:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:31:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:31:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:31:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:31:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:31:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:31:26 --> Final output sent to browser
DEBUG - 2024-02-12 19:31:26 --> Total execution time: 0.0299
ERROR - 2024-02-12 19:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:26 --> Config Class Initialized
INFO - 2024-02-12 19:31:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:26 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:26 --> URI Class Initialized
INFO - 2024-02-12 19:31:26 --> Router Class Initialized
INFO - 2024-02-12 19:31:26 --> Output Class Initialized
INFO - 2024-02-12 19:31:27 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:27 --> Input Class Initialized
INFO - 2024-02-12 19:31:27 --> Language Class Initialized
INFO - 2024-02-12 19:31:27 --> Loader Class Initialized
INFO - 2024-02-12 19:31:27 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:27 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:27 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:27 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:27 --> Controller Class Initialized
INFO - 2024-02-12 19:31:27 --> Form Validation Class Initialized
INFO - 2024-02-12 19:31:27 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:31:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:31:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:31:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:31:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:31 --> Config Class Initialized
INFO - 2024-02-12 19:31:31 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:31 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:31 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:31 --> URI Class Initialized
INFO - 2024-02-12 19:31:31 --> Router Class Initialized
INFO - 2024-02-12 19:31:31 --> Output Class Initialized
INFO - 2024-02-12 19:31:31 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:31 --> Input Class Initialized
INFO - 2024-02-12 19:31:31 --> Language Class Initialized
INFO - 2024-02-12 19:31:31 --> Loader Class Initialized
INFO - 2024-02-12 19:31:31 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:31 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:31 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:31 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:31 --> Controller Class Initialized
INFO - 2024-02-12 19:31:31 --> Form Validation Class Initialized
INFO - 2024-02-12 19:31:31 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:31:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:31:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:31:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:31:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:31:31 --> Final output sent to browser
DEBUG - 2024-02-12 19:31:31 --> Total execution time: 0.0320
ERROR - 2024-02-12 19:31:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:31:37 --> Config Class Initialized
INFO - 2024-02-12 19:31:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:31:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:31:37 --> Utf8 Class Initialized
INFO - 2024-02-12 19:31:37 --> URI Class Initialized
INFO - 2024-02-12 19:31:37 --> Router Class Initialized
INFO - 2024-02-12 19:31:37 --> Output Class Initialized
INFO - 2024-02-12 19:31:37 --> Security Class Initialized
DEBUG - 2024-02-12 19:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:31:37 --> Input Class Initialized
INFO - 2024-02-12 19:31:37 --> Language Class Initialized
INFO - 2024-02-12 19:31:37 --> Loader Class Initialized
INFO - 2024-02-12 19:31:37 --> Helper loaded: url_helper
INFO - 2024-02-12 19:31:37 --> Helper loaded: file_helper
INFO - 2024-02-12 19:31:37 --> Helper loaded: form_helper
INFO - 2024-02-12 19:31:37 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:31:37 --> Controller Class Initialized
INFO - 2024-02-12 19:31:37 --> Form Validation Class Initialized
INFO - 2024-02-12 19:31:37 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:31:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:31:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:31:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:31:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:31:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:31:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:31:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:31:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:31:37 --> Final output sent to browser
DEBUG - 2024-02-12 19:31:37 --> Total execution time: 0.0333
ERROR - 2024-02-12 19:35:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:35:41 --> Config Class Initialized
INFO - 2024-02-12 19:35:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:35:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:35:41 --> Utf8 Class Initialized
INFO - 2024-02-12 19:35:41 --> URI Class Initialized
INFO - 2024-02-12 19:35:41 --> Router Class Initialized
INFO - 2024-02-12 19:35:41 --> Output Class Initialized
INFO - 2024-02-12 19:35:41 --> Security Class Initialized
DEBUG - 2024-02-12 19:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:35:41 --> Input Class Initialized
INFO - 2024-02-12 19:35:41 --> Language Class Initialized
INFO - 2024-02-12 19:35:41 --> Loader Class Initialized
INFO - 2024-02-12 19:35:41 --> Helper loaded: url_helper
INFO - 2024-02-12 19:35:41 --> Helper loaded: file_helper
INFO - 2024-02-12 19:35:41 --> Helper loaded: form_helper
INFO - 2024-02-12 19:35:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:35:41 --> Controller Class Initialized
INFO - 2024-02-12 19:35:41 --> Form Validation Class Initialized
INFO - 2024-02-12 19:35:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:35:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:35:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:35:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:35:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:35:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:35:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:35:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:35:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:35:41 --> Final output sent to browser
DEBUG - 2024-02-12 19:35:41 --> Total execution time: 0.0373
ERROR - 2024-02-12 19:35:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:35:41 --> Config Class Initialized
INFO - 2024-02-12 19:35:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:35:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:35:41 --> Utf8 Class Initialized
INFO - 2024-02-12 19:35:41 --> URI Class Initialized
INFO - 2024-02-12 19:35:41 --> Router Class Initialized
INFO - 2024-02-12 19:35:41 --> Output Class Initialized
INFO - 2024-02-12 19:35:41 --> Security Class Initialized
DEBUG - 2024-02-12 19:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:35:41 --> Input Class Initialized
INFO - 2024-02-12 19:35:41 --> Language Class Initialized
INFO - 2024-02-12 19:35:41 --> Loader Class Initialized
INFO - 2024-02-12 19:35:41 --> Helper loaded: url_helper
INFO - 2024-02-12 19:35:41 --> Helper loaded: file_helper
INFO - 2024-02-12 19:35:41 --> Helper loaded: form_helper
INFO - 2024-02-12 19:35:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:35:41 --> Controller Class Initialized
INFO - 2024-02-12 19:35:41 --> Form Validation Class Initialized
INFO - 2024-02-12 19:35:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:35:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:35:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:35:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:35:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:35:44 --> Config Class Initialized
INFO - 2024-02-12 19:35:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:35:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:35:44 --> Utf8 Class Initialized
INFO - 2024-02-12 19:35:44 --> URI Class Initialized
INFO - 2024-02-12 19:35:44 --> Router Class Initialized
INFO - 2024-02-12 19:35:44 --> Output Class Initialized
INFO - 2024-02-12 19:35:44 --> Security Class Initialized
DEBUG - 2024-02-12 19:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:35:44 --> Input Class Initialized
INFO - 2024-02-12 19:35:44 --> Language Class Initialized
INFO - 2024-02-12 19:35:44 --> Loader Class Initialized
INFO - 2024-02-12 19:35:44 --> Helper loaded: url_helper
INFO - 2024-02-12 19:35:44 --> Helper loaded: file_helper
INFO - 2024-02-12 19:35:44 --> Helper loaded: form_helper
INFO - 2024-02-12 19:35:44 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:35:44 --> Controller Class Initialized
INFO - 2024-02-12 19:35:44 --> Form Validation Class Initialized
INFO - 2024-02-12 19:35:44 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:35:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:35:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:35:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:35:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:35:44 --> Final output sent to browser
DEBUG - 2024-02-12 19:35:44 --> Total execution time: 0.0355
ERROR - 2024-02-12 19:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:35:49 --> Config Class Initialized
INFO - 2024-02-12 19:35:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:35:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:35:49 --> Utf8 Class Initialized
INFO - 2024-02-12 19:35:49 --> URI Class Initialized
INFO - 2024-02-12 19:35:49 --> Router Class Initialized
INFO - 2024-02-12 19:35:49 --> Output Class Initialized
INFO - 2024-02-12 19:35:49 --> Security Class Initialized
DEBUG - 2024-02-12 19:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:35:49 --> Input Class Initialized
INFO - 2024-02-12 19:35:49 --> Language Class Initialized
INFO - 2024-02-12 19:35:49 --> Loader Class Initialized
INFO - 2024-02-12 19:35:49 --> Helper loaded: url_helper
INFO - 2024-02-12 19:35:49 --> Helper loaded: file_helper
INFO - 2024-02-12 19:35:49 --> Helper loaded: form_helper
INFO - 2024-02-12 19:35:49 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:35:49 --> Controller Class Initialized
INFO - 2024-02-12 19:35:49 --> Form Validation Class Initialized
INFO - 2024-02-12 19:35:49 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:35:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:35:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:35:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:35:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:35:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:35:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:35:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:35:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:35:49 --> Final output sent to browser
DEBUG - 2024-02-12 19:35:49 --> Total execution time: 0.0317
ERROR - 2024-02-12 19:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:35:49 --> Config Class Initialized
INFO - 2024-02-12 19:35:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:35:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:35:49 --> Utf8 Class Initialized
INFO - 2024-02-12 19:35:49 --> URI Class Initialized
INFO - 2024-02-12 19:35:49 --> Router Class Initialized
INFO - 2024-02-12 19:35:49 --> Output Class Initialized
INFO - 2024-02-12 19:35:49 --> Security Class Initialized
DEBUG - 2024-02-12 19:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:35:49 --> Input Class Initialized
INFO - 2024-02-12 19:35:49 --> Language Class Initialized
INFO - 2024-02-12 19:35:49 --> Loader Class Initialized
INFO - 2024-02-12 19:35:49 --> Helper loaded: url_helper
INFO - 2024-02-12 19:35:49 --> Helper loaded: file_helper
INFO - 2024-02-12 19:35:49 --> Helper loaded: form_helper
INFO - 2024-02-12 19:35:49 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:35:49 --> Controller Class Initialized
INFO - 2024-02-12 19:35:49 --> Form Validation Class Initialized
INFO - 2024-02-12 19:35:49 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:35:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:35:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:35:49 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:35:52 --> Config Class Initialized
INFO - 2024-02-12 19:35:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:35:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:35:52 --> Utf8 Class Initialized
INFO - 2024-02-12 19:35:52 --> URI Class Initialized
INFO - 2024-02-12 19:35:52 --> Router Class Initialized
INFO - 2024-02-12 19:35:52 --> Output Class Initialized
INFO - 2024-02-12 19:35:52 --> Security Class Initialized
DEBUG - 2024-02-12 19:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:35:52 --> Input Class Initialized
INFO - 2024-02-12 19:35:52 --> Language Class Initialized
INFO - 2024-02-12 19:35:52 --> Loader Class Initialized
INFO - 2024-02-12 19:35:52 --> Helper loaded: url_helper
INFO - 2024-02-12 19:35:52 --> Helper loaded: file_helper
INFO - 2024-02-12 19:35:52 --> Helper loaded: form_helper
INFO - 2024-02-12 19:35:52 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:35:52 --> Controller Class Initialized
INFO - 2024-02-12 19:35:52 --> Form Validation Class Initialized
INFO - 2024-02-12 19:35:52 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:35:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:35:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:35:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:35:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:35:52 --> Final output sent to browser
DEBUG - 2024-02-12 19:35:52 --> Total execution time: 0.0362
ERROR - 2024-02-12 19:36:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:36:17 --> Config Class Initialized
INFO - 2024-02-12 19:36:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:36:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:36:17 --> Utf8 Class Initialized
INFO - 2024-02-12 19:36:17 --> URI Class Initialized
INFO - 2024-02-12 19:36:17 --> Router Class Initialized
INFO - 2024-02-12 19:36:17 --> Output Class Initialized
INFO - 2024-02-12 19:36:17 --> Security Class Initialized
DEBUG - 2024-02-12 19:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:36:17 --> Input Class Initialized
INFO - 2024-02-12 19:36:17 --> Language Class Initialized
INFO - 2024-02-12 19:36:17 --> Loader Class Initialized
INFO - 2024-02-12 19:36:17 --> Helper loaded: url_helper
INFO - 2024-02-12 19:36:17 --> Helper loaded: file_helper
INFO - 2024-02-12 19:36:17 --> Helper loaded: form_helper
INFO - 2024-02-12 19:36:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:36:17 --> Controller Class Initialized
INFO - 2024-02-12 19:36:17 --> Form Validation Class Initialized
INFO - 2024-02-12 19:36:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:36:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:36:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:36:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:36:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:36:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:36:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:36:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:36:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:36:17 --> Final output sent to browser
DEBUG - 2024-02-12 19:36:17 --> Total execution time: 0.0314
ERROR - 2024-02-12 19:36:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:36:18 --> Config Class Initialized
INFO - 2024-02-12 19:36:18 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:36:18 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:36:18 --> Utf8 Class Initialized
INFO - 2024-02-12 19:36:18 --> URI Class Initialized
INFO - 2024-02-12 19:36:18 --> Router Class Initialized
INFO - 2024-02-12 19:36:18 --> Output Class Initialized
INFO - 2024-02-12 19:36:18 --> Security Class Initialized
DEBUG - 2024-02-12 19:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:36:18 --> Input Class Initialized
INFO - 2024-02-12 19:36:18 --> Language Class Initialized
INFO - 2024-02-12 19:36:18 --> Loader Class Initialized
INFO - 2024-02-12 19:36:18 --> Helper loaded: url_helper
INFO - 2024-02-12 19:36:18 --> Helper loaded: file_helper
INFO - 2024-02-12 19:36:18 --> Helper loaded: form_helper
INFO - 2024-02-12 19:36:18 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:36:18 --> Controller Class Initialized
INFO - 2024-02-12 19:36:18 --> Form Validation Class Initialized
INFO - 2024-02-12 19:36:18 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:36:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:36:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:36:18 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:36:20 --> Config Class Initialized
INFO - 2024-02-12 19:36:20 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:36:20 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:36:20 --> Utf8 Class Initialized
INFO - 2024-02-12 19:36:20 --> URI Class Initialized
INFO - 2024-02-12 19:36:20 --> Router Class Initialized
INFO - 2024-02-12 19:36:20 --> Output Class Initialized
INFO - 2024-02-12 19:36:20 --> Security Class Initialized
DEBUG - 2024-02-12 19:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:36:20 --> Input Class Initialized
INFO - 2024-02-12 19:36:20 --> Language Class Initialized
INFO - 2024-02-12 19:36:20 --> Loader Class Initialized
INFO - 2024-02-12 19:36:20 --> Helper loaded: url_helper
INFO - 2024-02-12 19:36:20 --> Helper loaded: file_helper
INFO - 2024-02-12 19:36:20 --> Helper loaded: form_helper
INFO - 2024-02-12 19:36:20 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:36:20 --> Controller Class Initialized
INFO - 2024-02-12 19:36:20 --> Form Validation Class Initialized
INFO - 2024-02-12 19:36:20 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:36:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:36:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:36:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:36:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:36:20 --> Final output sent to browser
DEBUG - 2024-02-12 19:36:20 --> Total execution time: 0.0192
ERROR - 2024-02-12 19:38:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:38:01 --> Config Class Initialized
INFO - 2024-02-12 19:38:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:38:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:38:01 --> Utf8 Class Initialized
INFO - 2024-02-12 19:38:01 --> URI Class Initialized
INFO - 2024-02-12 19:38:01 --> Router Class Initialized
INFO - 2024-02-12 19:38:01 --> Output Class Initialized
INFO - 2024-02-12 19:38:01 --> Security Class Initialized
DEBUG - 2024-02-12 19:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:38:01 --> Input Class Initialized
INFO - 2024-02-12 19:38:01 --> Language Class Initialized
INFO - 2024-02-12 19:38:01 --> Loader Class Initialized
INFO - 2024-02-12 19:38:01 --> Helper loaded: url_helper
INFO - 2024-02-12 19:38:01 --> Helper loaded: file_helper
INFO - 2024-02-12 19:38:01 --> Helper loaded: form_helper
INFO - 2024-02-12 19:38:01 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:38:01 --> Controller Class Initialized
INFO - 2024-02-12 19:38:01 --> Form Validation Class Initialized
INFO - 2024-02-12 19:38:01 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:38:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:38:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:38:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:38:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:38:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:38:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:38:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:38:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:38:01 --> Final output sent to browser
DEBUG - 2024-02-12 19:38:01 --> Total execution time: 0.0353
ERROR - 2024-02-12 19:38:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:38:01 --> Config Class Initialized
INFO - 2024-02-12 19:38:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:38:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:38:01 --> Utf8 Class Initialized
INFO - 2024-02-12 19:38:01 --> URI Class Initialized
INFO - 2024-02-12 19:38:01 --> Router Class Initialized
INFO - 2024-02-12 19:38:01 --> Output Class Initialized
INFO - 2024-02-12 19:38:01 --> Security Class Initialized
DEBUG - 2024-02-12 19:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:38:01 --> Input Class Initialized
INFO - 2024-02-12 19:38:01 --> Language Class Initialized
INFO - 2024-02-12 19:38:01 --> Loader Class Initialized
INFO - 2024-02-12 19:38:01 --> Helper loaded: url_helper
INFO - 2024-02-12 19:38:01 --> Helper loaded: file_helper
INFO - 2024-02-12 19:38:01 --> Helper loaded: form_helper
INFO - 2024-02-12 19:38:01 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:38:01 --> Controller Class Initialized
INFO - 2024-02-12 19:38:01 --> Form Validation Class Initialized
INFO - 2024-02-12 19:38:01 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:38:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:38:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:38:01 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:38:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:38:04 --> Config Class Initialized
INFO - 2024-02-12 19:38:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:38:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:38:04 --> Utf8 Class Initialized
INFO - 2024-02-12 19:38:04 --> URI Class Initialized
INFO - 2024-02-12 19:38:04 --> Router Class Initialized
INFO - 2024-02-12 19:38:04 --> Output Class Initialized
INFO - 2024-02-12 19:38:04 --> Security Class Initialized
DEBUG - 2024-02-12 19:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:38:04 --> Input Class Initialized
INFO - 2024-02-12 19:38:04 --> Language Class Initialized
INFO - 2024-02-12 19:38:04 --> Loader Class Initialized
INFO - 2024-02-12 19:38:04 --> Helper loaded: url_helper
INFO - 2024-02-12 19:38:04 --> Helper loaded: file_helper
INFO - 2024-02-12 19:38:04 --> Helper loaded: form_helper
INFO - 2024-02-12 19:38:04 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:38:04 --> Controller Class Initialized
INFO - 2024-02-12 19:38:04 --> Form Validation Class Initialized
INFO - 2024-02-12 19:38:04 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:38:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:38:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:38:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:38:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:38:04 --> Final output sent to browser
DEBUG - 2024-02-12 19:38:04 --> Total execution time: 0.0212
ERROR - 2024-02-12 19:39:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:39:29 --> Config Class Initialized
INFO - 2024-02-12 19:39:29 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:39:29 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:39:29 --> Utf8 Class Initialized
INFO - 2024-02-12 19:39:29 --> URI Class Initialized
INFO - 2024-02-12 19:39:29 --> Router Class Initialized
INFO - 2024-02-12 19:39:29 --> Output Class Initialized
INFO - 2024-02-12 19:39:29 --> Security Class Initialized
DEBUG - 2024-02-12 19:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:39:29 --> Input Class Initialized
INFO - 2024-02-12 19:39:29 --> Language Class Initialized
INFO - 2024-02-12 19:39:29 --> Loader Class Initialized
INFO - 2024-02-12 19:39:29 --> Helper loaded: url_helper
INFO - 2024-02-12 19:39:29 --> Helper loaded: file_helper
INFO - 2024-02-12 19:39:29 --> Helper loaded: form_helper
INFO - 2024-02-12 19:39:29 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:39:29 --> Controller Class Initialized
INFO - 2024-02-12 19:39:29 --> Form Validation Class Initialized
INFO - 2024-02-12 19:39:29 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:39:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:39:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:39:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:39:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:39:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:39:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:39:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:39:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:39:29 --> Final output sent to browser
DEBUG - 2024-02-12 19:39:29 --> Total execution time: 0.0287
ERROR - 2024-02-12 19:39:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:39:30 --> Config Class Initialized
INFO - 2024-02-12 19:39:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:39:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:39:30 --> Utf8 Class Initialized
INFO - 2024-02-12 19:39:30 --> URI Class Initialized
INFO - 2024-02-12 19:39:30 --> Router Class Initialized
INFO - 2024-02-12 19:39:30 --> Output Class Initialized
INFO - 2024-02-12 19:39:30 --> Security Class Initialized
DEBUG - 2024-02-12 19:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:39:30 --> Input Class Initialized
INFO - 2024-02-12 19:39:30 --> Language Class Initialized
INFO - 2024-02-12 19:39:30 --> Loader Class Initialized
INFO - 2024-02-12 19:39:30 --> Helper loaded: url_helper
INFO - 2024-02-12 19:39:30 --> Helper loaded: file_helper
INFO - 2024-02-12 19:39:30 --> Helper loaded: form_helper
INFO - 2024-02-12 19:39:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:39:30 --> Controller Class Initialized
INFO - 2024-02-12 19:39:30 --> Form Validation Class Initialized
INFO - 2024-02-12 19:39:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:39:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:39:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:39:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:39:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:39:33 --> Config Class Initialized
INFO - 2024-02-12 19:39:33 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:39:33 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:39:33 --> Utf8 Class Initialized
INFO - 2024-02-12 19:39:33 --> URI Class Initialized
INFO - 2024-02-12 19:39:33 --> Router Class Initialized
INFO - 2024-02-12 19:39:33 --> Output Class Initialized
INFO - 2024-02-12 19:39:33 --> Security Class Initialized
DEBUG - 2024-02-12 19:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:39:33 --> Input Class Initialized
INFO - 2024-02-12 19:39:33 --> Language Class Initialized
INFO - 2024-02-12 19:39:33 --> Loader Class Initialized
INFO - 2024-02-12 19:39:33 --> Helper loaded: url_helper
INFO - 2024-02-12 19:39:33 --> Helper loaded: file_helper
INFO - 2024-02-12 19:39:33 --> Helper loaded: form_helper
INFO - 2024-02-12 19:39:33 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:39:33 --> Controller Class Initialized
INFO - 2024-02-12 19:39:33 --> Form Validation Class Initialized
INFO - 2024-02-12 19:39:33 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:39:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:39:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:39:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:39:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:39:33 --> Final output sent to browser
DEBUG - 2024-02-12 19:39:33 --> Total execution time: 0.0366
ERROR - 2024-02-12 19:42:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:42:17 --> Config Class Initialized
INFO - 2024-02-12 19:42:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:42:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:42:17 --> Utf8 Class Initialized
INFO - 2024-02-12 19:42:17 --> URI Class Initialized
INFO - 2024-02-12 19:42:17 --> Router Class Initialized
INFO - 2024-02-12 19:42:17 --> Output Class Initialized
INFO - 2024-02-12 19:42:17 --> Security Class Initialized
DEBUG - 2024-02-12 19:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:42:17 --> Input Class Initialized
INFO - 2024-02-12 19:42:17 --> Language Class Initialized
INFO - 2024-02-12 19:42:17 --> Loader Class Initialized
INFO - 2024-02-12 19:42:17 --> Helper loaded: url_helper
INFO - 2024-02-12 19:42:17 --> Helper loaded: file_helper
INFO - 2024-02-12 19:42:17 --> Helper loaded: form_helper
INFO - 2024-02-12 19:42:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:42:17 --> Controller Class Initialized
INFO - 2024-02-12 19:42:17 --> Form Validation Class Initialized
INFO - 2024-02-12 19:42:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:42:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:42:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:42:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:42:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:42:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:42:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:42:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:42:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:42:17 --> Final output sent to browser
DEBUG - 2024-02-12 19:42:17 --> Total execution time: 0.0335
ERROR - 2024-02-12 19:42:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:42:17 --> Config Class Initialized
INFO - 2024-02-12 19:42:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:42:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:42:17 --> Utf8 Class Initialized
INFO - 2024-02-12 19:42:17 --> URI Class Initialized
INFO - 2024-02-12 19:42:17 --> Router Class Initialized
INFO - 2024-02-12 19:42:17 --> Output Class Initialized
INFO - 2024-02-12 19:42:17 --> Security Class Initialized
DEBUG - 2024-02-12 19:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:42:17 --> Input Class Initialized
INFO - 2024-02-12 19:42:17 --> Language Class Initialized
INFO - 2024-02-12 19:42:17 --> Loader Class Initialized
INFO - 2024-02-12 19:42:17 --> Helper loaded: url_helper
INFO - 2024-02-12 19:42:17 --> Helper loaded: file_helper
INFO - 2024-02-12 19:42:17 --> Helper loaded: form_helper
INFO - 2024-02-12 19:42:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:42:17 --> Controller Class Initialized
INFO - 2024-02-12 19:42:17 --> Form Validation Class Initialized
INFO - 2024-02-12 19:42:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:42:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:42:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:42:17 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:42:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:42:20 --> Config Class Initialized
INFO - 2024-02-12 19:42:20 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:42:20 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:42:20 --> Utf8 Class Initialized
INFO - 2024-02-12 19:42:20 --> URI Class Initialized
INFO - 2024-02-12 19:42:20 --> Router Class Initialized
INFO - 2024-02-12 19:42:20 --> Output Class Initialized
INFO - 2024-02-12 19:42:20 --> Security Class Initialized
DEBUG - 2024-02-12 19:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:42:20 --> Input Class Initialized
INFO - 2024-02-12 19:42:20 --> Language Class Initialized
INFO - 2024-02-12 19:42:20 --> Loader Class Initialized
INFO - 2024-02-12 19:42:20 --> Helper loaded: url_helper
INFO - 2024-02-12 19:42:20 --> Helper loaded: file_helper
INFO - 2024-02-12 19:42:20 --> Helper loaded: form_helper
INFO - 2024-02-12 19:42:20 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:42:20 --> Controller Class Initialized
INFO - 2024-02-12 19:42:20 --> Form Validation Class Initialized
INFO - 2024-02-12 19:42:20 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:42:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:42:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:42:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:42:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:42:20 --> Final output sent to browser
DEBUG - 2024-02-12 19:42:20 --> Total execution time: 0.0373
ERROR - 2024-02-12 19:43:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:43:00 --> Config Class Initialized
INFO - 2024-02-12 19:43:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:43:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:43:00 --> Utf8 Class Initialized
INFO - 2024-02-12 19:43:00 --> URI Class Initialized
INFO - 2024-02-12 19:43:00 --> Router Class Initialized
INFO - 2024-02-12 19:43:00 --> Output Class Initialized
INFO - 2024-02-12 19:43:00 --> Security Class Initialized
DEBUG - 2024-02-12 19:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:43:00 --> Input Class Initialized
INFO - 2024-02-12 19:43:00 --> Language Class Initialized
INFO - 2024-02-12 19:43:00 --> Loader Class Initialized
INFO - 2024-02-12 19:43:00 --> Helper loaded: url_helper
INFO - 2024-02-12 19:43:00 --> Helper loaded: file_helper
INFO - 2024-02-12 19:43:00 --> Helper loaded: form_helper
INFO - 2024-02-12 19:43:01 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:43:01 --> Controller Class Initialized
INFO - 2024-02-12 19:43:01 --> Form Validation Class Initialized
INFO - 2024-02-12 19:43:01 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:43:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:43:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:43:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:43:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:43:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:43:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:43:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:43:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:43:01 --> Final output sent to browser
DEBUG - 2024-02-12 19:43:01 --> Total execution time: 0.0277
ERROR - 2024-02-12 19:43:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:43:01 --> Config Class Initialized
INFO - 2024-02-12 19:43:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:43:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:43:01 --> Utf8 Class Initialized
INFO - 2024-02-12 19:43:01 --> URI Class Initialized
INFO - 2024-02-12 19:43:01 --> Router Class Initialized
INFO - 2024-02-12 19:43:01 --> Output Class Initialized
INFO - 2024-02-12 19:43:01 --> Security Class Initialized
DEBUG - 2024-02-12 19:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:43:01 --> Input Class Initialized
INFO - 2024-02-12 19:43:01 --> Language Class Initialized
INFO - 2024-02-12 19:43:01 --> Loader Class Initialized
INFO - 2024-02-12 19:43:01 --> Helper loaded: url_helper
INFO - 2024-02-12 19:43:01 --> Helper loaded: file_helper
INFO - 2024-02-12 19:43:01 --> Helper loaded: form_helper
INFO - 2024-02-12 19:43:01 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:43:01 --> Controller Class Initialized
INFO - 2024-02-12 19:43:01 --> Form Validation Class Initialized
INFO - 2024-02-12 19:43:01 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:43:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:43:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:43:01 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:43:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:43:04 --> Config Class Initialized
INFO - 2024-02-12 19:43:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:43:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:43:04 --> Utf8 Class Initialized
INFO - 2024-02-12 19:43:04 --> URI Class Initialized
INFO - 2024-02-12 19:43:04 --> Router Class Initialized
INFO - 2024-02-12 19:43:04 --> Output Class Initialized
INFO - 2024-02-12 19:43:04 --> Security Class Initialized
DEBUG - 2024-02-12 19:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:43:04 --> Input Class Initialized
INFO - 2024-02-12 19:43:04 --> Language Class Initialized
INFO - 2024-02-12 19:43:04 --> Loader Class Initialized
INFO - 2024-02-12 19:43:04 --> Helper loaded: url_helper
INFO - 2024-02-12 19:43:04 --> Helper loaded: file_helper
INFO - 2024-02-12 19:43:04 --> Helper loaded: form_helper
INFO - 2024-02-12 19:43:04 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:43:04 --> Controller Class Initialized
INFO - 2024-02-12 19:43:04 --> Form Validation Class Initialized
INFO - 2024-02-12 19:43:04 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:43:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:43:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:43:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:43:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:43:04 --> Final output sent to browser
DEBUG - 2024-02-12 19:43:04 --> Total execution time: 0.0305
ERROR - 2024-02-12 19:44:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:44:02 --> Config Class Initialized
INFO - 2024-02-12 19:44:02 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:44:02 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:44:02 --> Utf8 Class Initialized
INFO - 2024-02-12 19:44:02 --> URI Class Initialized
INFO - 2024-02-12 19:44:02 --> Router Class Initialized
INFO - 2024-02-12 19:44:02 --> Output Class Initialized
INFO - 2024-02-12 19:44:02 --> Security Class Initialized
DEBUG - 2024-02-12 19:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:44:02 --> Input Class Initialized
INFO - 2024-02-12 19:44:02 --> Language Class Initialized
INFO - 2024-02-12 19:44:02 --> Loader Class Initialized
INFO - 2024-02-12 19:44:02 --> Helper loaded: url_helper
INFO - 2024-02-12 19:44:02 --> Helper loaded: file_helper
INFO - 2024-02-12 19:44:02 --> Helper loaded: form_helper
INFO - 2024-02-12 19:44:02 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:44:02 --> Controller Class Initialized
INFO - 2024-02-12 19:44:02 --> Form Validation Class Initialized
INFO - 2024-02-12 19:44:02 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:44:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:44:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:44:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:44:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:44:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:44:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:44:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:44:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:44:02 --> Final output sent to browser
DEBUG - 2024-02-12 19:44:02 --> Total execution time: 0.0319
ERROR - 2024-02-12 19:44:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:44:03 --> Config Class Initialized
INFO - 2024-02-12 19:44:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:44:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:44:03 --> Utf8 Class Initialized
INFO - 2024-02-12 19:44:03 --> URI Class Initialized
INFO - 2024-02-12 19:44:03 --> Router Class Initialized
INFO - 2024-02-12 19:44:03 --> Output Class Initialized
INFO - 2024-02-12 19:44:03 --> Security Class Initialized
DEBUG - 2024-02-12 19:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:44:03 --> Input Class Initialized
INFO - 2024-02-12 19:44:03 --> Language Class Initialized
INFO - 2024-02-12 19:44:03 --> Loader Class Initialized
INFO - 2024-02-12 19:44:03 --> Helper loaded: url_helper
INFO - 2024-02-12 19:44:03 --> Helper loaded: file_helper
INFO - 2024-02-12 19:44:03 --> Helper loaded: form_helper
INFO - 2024-02-12 19:44:03 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:44:03 --> Controller Class Initialized
INFO - 2024-02-12 19:44:03 --> Form Validation Class Initialized
INFO - 2024-02-12 19:44:03 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:44:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:44:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:44:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:44:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:44:05 --> Config Class Initialized
INFO - 2024-02-12 19:44:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:44:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:44:05 --> Utf8 Class Initialized
INFO - 2024-02-12 19:44:05 --> URI Class Initialized
INFO - 2024-02-12 19:44:05 --> Router Class Initialized
INFO - 2024-02-12 19:44:05 --> Output Class Initialized
INFO - 2024-02-12 19:44:05 --> Security Class Initialized
DEBUG - 2024-02-12 19:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:44:05 --> Input Class Initialized
INFO - 2024-02-12 19:44:05 --> Language Class Initialized
INFO - 2024-02-12 19:44:05 --> Loader Class Initialized
INFO - 2024-02-12 19:44:05 --> Helper loaded: url_helper
INFO - 2024-02-12 19:44:05 --> Helper loaded: file_helper
INFO - 2024-02-12 19:44:05 --> Helper loaded: form_helper
INFO - 2024-02-12 19:44:05 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:44:05 --> Controller Class Initialized
INFO - 2024-02-12 19:44:05 --> Form Validation Class Initialized
INFO - 2024-02-12 19:44:05 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:44:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:44:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:44:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:44:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:44:05 --> Final output sent to browser
DEBUG - 2024-02-12 19:44:05 --> Total execution time: 0.0330
ERROR - 2024-02-12 19:45:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:45:33 --> Config Class Initialized
INFO - 2024-02-12 19:45:33 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:45:33 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:45:33 --> Utf8 Class Initialized
INFO - 2024-02-12 19:45:33 --> URI Class Initialized
INFO - 2024-02-12 19:45:33 --> Router Class Initialized
INFO - 2024-02-12 19:45:33 --> Output Class Initialized
INFO - 2024-02-12 19:45:33 --> Security Class Initialized
DEBUG - 2024-02-12 19:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:45:33 --> Input Class Initialized
INFO - 2024-02-12 19:45:33 --> Language Class Initialized
INFO - 2024-02-12 19:45:33 --> Loader Class Initialized
INFO - 2024-02-12 19:45:33 --> Helper loaded: url_helper
INFO - 2024-02-12 19:45:33 --> Helper loaded: file_helper
INFO - 2024-02-12 19:45:33 --> Helper loaded: form_helper
INFO - 2024-02-12 19:45:33 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:45:33 --> Controller Class Initialized
INFO - 2024-02-12 19:45:33 --> Form Validation Class Initialized
INFO - 2024-02-12 19:45:33 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:45:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:45:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:45:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:45:33 --> Final output sent to browser
DEBUG - 2024-02-12 19:45:33 --> Total execution time: 0.0283
ERROR - 2024-02-12 19:45:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:45:34 --> Config Class Initialized
INFO - 2024-02-12 19:45:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:45:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:45:34 --> Utf8 Class Initialized
INFO - 2024-02-12 19:45:34 --> URI Class Initialized
INFO - 2024-02-12 19:45:34 --> Router Class Initialized
INFO - 2024-02-12 19:45:34 --> Output Class Initialized
INFO - 2024-02-12 19:45:34 --> Security Class Initialized
DEBUG - 2024-02-12 19:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:45:34 --> Input Class Initialized
INFO - 2024-02-12 19:45:34 --> Language Class Initialized
INFO - 2024-02-12 19:45:34 --> Loader Class Initialized
INFO - 2024-02-12 19:45:34 --> Helper loaded: url_helper
INFO - 2024-02-12 19:45:34 --> Helper loaded: file_helper
INFO - 2024-02-12 19:45:34 --> Helper loaded: form_helper
INFO - 2024-02-12 19:45:34 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:45:34 --> Controller Class Initialized
INFO - 2024-02-12 19:45:34 --> Form Validation Class Initialized
INFO - 2024-02-12 19:45:34 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:45:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:45:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:45:34 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:45:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:45:36 --> Config Class Initialized
INFO - 2024-02-12 19:45:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:45:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:45:36 --> Utf8 Class Initialized
INFO - 2024-02-12 19:45:36 --> URI Class Initialized
INFO - 2024-02-12 19:45:36 --> Router Class Initialized
INFO - 2024-02-12 19:45:36 --> Output Class Initialized
INFO - 2024-02-12 19:45:36 --> Security Class Initialized
DEBUG - 2024-02-12 19:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:45:36 --> Input Class Initialized
INFO - 2024-02-12 19:45:36 --> Language Class Initialized
INFO - 2024-02-12 19:45:36 --> Loader Class Initialized
INFO - 2024-02-12 19:45:36 --> Helper loaded: url_helper
INFO - 2024-02-12 19:45:36 --> Helper loaded: file_helper
INFO - 2024-02-12 19:45:36 --> Helper loaded: form_helper
INFO - 2024-02-12 19:45:36 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:45:36 --> Controller Class Initialized
INFO - 2024-02-12 19:45:36 --> Form Validation Class Initialized
INFO - 2024-02-12 19:45:36 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:45:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:45:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:45:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:45:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:45:36 --> Final output sent to browser
DEBUG - 2024-02-12 19:45:36 --> Total execution time: 0.0294
ERROR - 2024-02-12 19:47:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:47:50 --> Config Class Initialized
INFO - 2024-02-12 19:47:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:47:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:47:50 --> Utf8 Class Initialized
INFO - 2024-02-12 19:47:50 --> URI Class Initialized
INFO - 2024-02-12 19:47:50 --> Router Class Initialized
INFO - 2024-02-12 19:47:50 --> Output Class Initialized
INFO - 2024-02-12 19:47:50 --> Security Class Initialized
DEBUG - 2024-02-12 19:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:47:50 --> Input Class Initialized
INFO - 2024-02-12 19:47:50 --> Language Class Initialized
INFO - 2024-02-12 19:47:50 --> Loader Class Initialized
INFO - 2024-02-12 19:47:50 --> Helper loaded: url_helper
INFO - 2024-02-12 19:47:50 --> Helper loaded: file_helper
INFO - 2024-02-12 19:47:50 --> Helper loaded: form_helper
INFO - 2024-02-12 19:47:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:47:50 --> Controller Class Initialized
INFO - 2024-02-12 19:47:50 --> Form Validation Class Initialized
INFO - 2024-02-12 19:47:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:47:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:47:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:47:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:47:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:47:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:47:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:47:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:47:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:47:50 --> Final output sent to browser
DEBUG - 2024-02-12 19:47:50 --> Total execution time: 0.0264
ERROR - 2024-02-12 19:47:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:47:50 --> Config Class Initialized
INFO - 2024-02-12 19:47:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:47:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:47:50 --> Utf8 Class Initialized
INFO - 2024-02-12 19:47:50 --> URI Class Initialized
INFO - 2024-02-12 19:47:50 --> Router Class Initialized
INFO - 2024-02-12 19:47:50 --> Output Class Initialized
INFO - 2024-02-12 19:47:50 --> Security Class Initialized
DEBUG - 2024-02-12 19:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:47:50 --> Input Class Initialized
INFO - 2024-02-12 19:47:50 --> Language Class Initialized
INFO - 2024-02-12 19:47:50 --> Loader Class Initialized
INFO - 2024-02-12 19:47:50 --> Helper loaded: url_helper
INFO - 2024-02-12 19:47:50 --> Helper loaded: file_helper
INFO - 2024-02-12 19:47:50 --> Helper loaded: form_helper
INFO - 2024-02-12 19:47:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:47:50 --> Controller Class Initialized
INFO - 2024-02-12 19:47:50 --> Form Validation Class Initialized
INFO - 2024-02-12 19:47:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:47:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:47:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:47:50 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:47:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:47:53 --> Config Class Initialized
INFO - 2024-02-12 19:47:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:47:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:47:53 --> Utf8 Class Initialized
INFO - 2024-02-12 19:47:53 --> URI Class Initialized
INFO - 2024-02-12 19:47:53 --> Router Class Initialized
INFO - 2024-02-12 19:47:53 --> Output Class Initialized
INFO - 2024-02-12 19:47:53 --> Security Class Initialized
DEBUG - 2024-02-12 19:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:47:53 --> Input Class Initialized
INFO - 2024-02-12 19:47:53 --> Language Class Initialized
INFO - 2024-02-12 19:47:53 --> Loader Class Initialized
INFO - 2024-02-12 19:47:53 --> Helper loaded: url_helper
INFO - 2024-02-12 19:47:53 --> Helper loaded: file_helper
INFO - 2024-02-12 19:47:53 --> Helper loaded: form_helper
INFO - 2024-02-12 19:47:53 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:47:53 --> Controller Class Initialized
INFO - 2024-02-12 19:47:53 --> Form Validation Class Initialized
INFO - 2024-02-12 19:47:53 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:47:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:47:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:47:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:47:53 --> Final output sent to browser
DEBUG - 2024-02-12 19:47:53 --> Total execution time: 0.0277
ERROR - 2024-02-12 19:48:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:48:08 --> Config Class Initialized
INFO - 2024-02-12 19:48:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:48:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:48:08 --> Utf8 Class Initialized
INFO - 2024-02-12 19:48:08 --> URI Class Initialized
INFO - 2024-02-12 19:48:08 --> Router Class Initialized
INFO - 2024-02-12 19:48:08 --> Output Class Initialized
INFO - 2024-02-12 19:48:08 --> Security Class Initialized
DEBUG - 2024-02-12 19:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:48:08 --> Input Class Initialized
INFO - 2024-02-12 19:48:08 --> Language Class Initialized
INFO - 2024-02-12 19:48:08 --> Loader Class Initialized
INFO - 2024-02-12 19:48:08 --> Helper loaded: url_helper
INFO - 2024-02-12 19:48:08 --> Helper loaded: file_helper
INFO - 2024-02-12 19:48:08 --> Helper loaded: form_helper
INFO - 2024-02-12 19:48:08 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:48:08 --> Controller Class Initialized
INFO - 2024-02-12 19:48:08 --> Form Validation Class Initialized
INFO - 2024-02-12 19:48:08 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:48:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:48:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:48:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:48:09 --> Final output sent to browser
DEBUG - 2024-02-12 19:48:09 --> Total execution time: 0.0385
ERROR - 2024-02-12 19:48:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:48:09 --> Config Class Initialized
INFO - 2024-02-12 19:48:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:48:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:48:09 --> Utf8 Class Initialized
INFO - 2024-02-12 19:48:09 --> URI Class Initialized
INFO - 2024-02-12 19:48:09 --> Router Class Initialized
INFO - 2024-02-12 19:48:09 --> Output Class Initialized
INFO - 2024-02-12 19:48:09 --> Security Class Initialized
DEBUG - 2024-02-12 19:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:48:09 --> Input Class Initialized
INFO - 2024-02-12 19:48:09 --> Language Class Initialized
INFO - 2024-02-12 19:48:09 --> Loader Class Initialized
INFO - 2024-02-12 19:48:09 --> Helper loaded: url_helper
INFO - 2024-02-12 19:48:09 --> Helper loaded: file_helper
INFO - 2024-02-12 19:48:09 --> Helper loaded: form_helper
INFO - 2024-02-12 19:48:09 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:48:09 --> Controller Class Initialized
INFO - 2024-02-12 19:48:09 --> Form Validation Class Initialized
INFO - 2024-02-12 19:48:09 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:48:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:48:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:48:09 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:48:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:48:11 --> Config Class Initialized
INFO - 2024-02-12 19:48:11 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:48:11 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:48:11 --> Utf8 Class Initialized
INFO - 2024-02-12 19:48:11 --> URI Class Initialized
INFO - 2024-02-12 19:48:11 --> Router Class Initialized
INFO - 2024-02-12 19:48:11 --> Output Class Initialized
INFO - 2024-02-12 19:48:11 --> Security Class Initialized
DEBUG - 2024-02-12 19:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:48:11 --> Input Class Initialized
INFO - 2024-02-12 19:48:11 --> Language Class Initialized
INFO - 2024-02-12 19:48:11 --> Loader Class Initialized
INFO - 2024-02-12 19:48:11 --> Helper loaded: url_helper
INFO - 2024-02-12 19:48:11 --> Helper loaded: file_helper
INFO - 2024-02-12 19:48:11 --> Helper loaded: form_helper
INFO - 2024-02-12 19:48:11 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:48:11 --> Controller Class Initialized
INFO - 2024-02-12 19:48:11 --> Form Validation Class Initialized
INFO - 2024-02-12 19:48:11 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:48:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:48:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:48:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:48:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:48:11 --> Final output sent to browser
DEBUG - 2024-02-12 19:48:11 --> Total execution time: 0.0317
ERROR - 2024-02-12 19:48:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:48:24 --> Config Class Initialized
INFO - 2024-02-12 19:48:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:48:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:48:24 --> Utf8 Class Initialized
INFO - 2024-02-12 19:48:24 --> URI Class Initialized
INFO - 2024-02-12 19:48:24 --> Router Class Initialized
INFO - 2024-02-12 19:48:24 --> Output Class Initialized
INFO - 2024-02-12 19:48:24 --> Security Class Initialized
DEBUG - 2024-02-12 19:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:48:24 --> Input Class Initialized
INFO - 2024-02-12 19:48:24 --> Language Class Initialized
INFO - 2024-02-12 19:48:24 --> Loader Class Initialized
INFO - 2024-02-12 19:48:24 --> Helper loaded: url_helper
INFO - 2024-02-12 19:48:24 --> Helper loaded: file_helper
INFO - 2024-02-12 19:48:24 --> Helper loaded: form_helper
INFO - 2024-02-12 19:48:24 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:48:24 --> Controller Class Initialized
INFO - 2024-02-12 19:48:24 --> Form Validation Class Initialized
INFO - 2024-02-12 19:48:24 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:48:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:48:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:48:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:48:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:48:24 --> Final output sent to browser
DEBUG - 2024-02-12 19:48:24 --> Total execution time: 0.0292
ERROR - 2024-02-12 19:48:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:48:24 --> Config Class Initialized
INFO - 2024-02-12 19:48:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:48:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:48:24 --> Utf8 Class Initialized
INFO - 2024-02-12 19:48:24 --> URI Class Initialized
INFO - 2024-02-12 19:48:24 --> Router Class Initialized
INFO - 2024-02-12 19:48:24 --> Output Class Initialized
INFO - 2024-02-12 19:48:24 --> Security Class Initialized
DEBUG - 2024-02-12 19:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:48:24 --> Input Class Initialized
INFO - 2024-02-12 19:48:24 --> Language Class Initialized
INFO - 2024-02-12 19:48:24 --> Loader Class Initialized
INFO - 2024-02-12 19:48:24 --> Helper loaded: url_helper
INFO - 2024-02-12 19:48:24 --> Helper loaded: file_helper
INFO - 2024-02-12 19:48:24 --> Helper loaded: form_helper
INFO - 2024-02-12 19:48:24 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:48:24 --> Controller Class Initialized
INFO - 2024-02-12 19:48:24 --> Form Validation Class Initialized
INFO - 2024-02-12 19:48:24 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:48:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:48:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:48:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:48:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:48:27 --> Config Class Initialized
INFO - 2024-02-12 19:48:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:48:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:48:27 --> Utf8 Class Initialized
INFO - 2024-02-12 19:48:27 --> URI Class Initialized
INFO - 2024-02-12 19:48:27 --> Router Class Initialized
INFO - 2024-02-12 19:48:27 --> Output Class Initialized
INFO - 2024-02-12 19:48:27 --> Security Class Initialized
DEBUG - 2024-02-12 19:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:48:27 --> Input Class Initialized
INFO - 2024-02-12 19:48:27 --> Language Class Initialized
INFO - 2024-02-12 19:48:27 --> Loader Class Initialized
INFO - 2024-02-12 19:48:27 --> Helper loaded: url_helper
INFO - 2024-02-12 19:48:27 --> Helper loaded: file_helper
INFO - 2024-02-12 19:48:27 --> Helper loaded: form_helper
INFO - 2024-02-12 19:48:27 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:48:27 --> Controller Class Initialized
INFO - 2024-02-12 19:48:27 --> Form Validation Class Initialized
INFO - 2024-02-12 19:48:27 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:48:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:48:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:48:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:48:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:48:27 --> Final output sent to browser
DEBUG - 2024-02-12 19:48:27 --> Total execution time: 0.0418
ERROR - 2024-02-12 19:49:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:49:15 --> Config Class Initialized
INFO - 2024-02-12 19:49:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:49:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:49:15 --> Utf8 Class Initialized
INFO - 2024-02-12 19:49:15 --> URI Class Initialized
INFO - 2024-02-12 19:49:15 --> Router Class Initialized
INFO - 2024-02-12 19:49:15 --> Output Class Initialized
INFO - 2024-02-12 19:49:15 --> Security Class Initialized
DEBUG - 2024-02-12 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:49:15 --> Input Class Initialized
INFO - 2024-02-12 19:49:15 --> Language Class Initialized
INFO - 2024-02-12 19:49:15 --> Loader Class Initialized
INFO - 2024-02-12 19:49:15 --> Helper loaded: url_helper
INFO - 2024-02-12 19:49:15 --> Helper loaded: file_helper
INFO - 2024-02-12 19:49:15 --> Helper loaded: form_helper
INFO - 2024-02-12 19:49:15 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:49:15 --> Controller Class Initialized
INFO - 2024-02-12 19:49:15 --> Form Validation Class Initialized
INFO - 2024-02-12 19:49:15 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:49:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:49:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:49:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:49:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:49:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:49:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:49:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:49:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:49:15 --> Final output sent to browser
DEBUG - 2024-02-12 19:49:15 --> Total execution time: 0.0398
ERROR - 2024-02-12 19:49:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:49:15 --> Config Class Initialized
INFO - 2024-02-12 19:49:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:49:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:49:15 --> Utf8 Class Initialized
INFO - 2024-02-12 19:49:15 --> URI Class Initialized
INFO - 2024-02-12 19:49:15 --> Router Class Initialized
INFO - 2024-02-12 19:49:15 --> Output Class Initialized
INFO - 2024-02-12 19:49:15 --> Security Class Initialized
DEBUG - 2024-02-12 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:49:15 --> Input Class Initialized
INFO - 2024-02-12 19:49:15 --> Language Class Initialized
INFO - 2024-02-12 19:49:15 --> Loader Class Initialized
INFO - 2024-02-12 19:49:15 --> Helper loaded: url_helper
INFO - 2024-02-12 19:49:15 --> Helper loaded: file_helper
INFO - 2024-02-12 19:49:15 --> Helper loaded: form_helper
INFO - 2024-02-12 19:49:15 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:49:15 --> Controller Class Initialized
INFO - 2024-02-12 19:49:15 --> Form Validation Class Initialized
INFO - 2024-02-12 19:49:15 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:49:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:49:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:49:15 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:49:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:49:19 --> Config Class Initialized
INFO - 2024-02-12 19:49:19 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:49:19 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:49:19 --> Utf8 Class Initialized
INFO - 2024-02-12 19:49:19 --> URI Class Initialized
INFO - 2024-02-12 19:49:19 --> Router Class Initialized
INFO - 2024-02-12 19:49:19 --> Output Class Initialized
INFO - 2024-02-12 19:49:19 --> Security Class Initialized
DEBUG - 2024-02-12 19:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:49:19 --> Input Class Initialized
INFO - 2024-02-12 19:49:19 --> Language Class Initialized
INFO - 2024-02-12 19:49:19 --> Loader Class Initialized
INFO - 2024-02-12 19:49:19 --> Helper loaded: url_helper
INFO - 2024-02-12 19:49:19 --> Helper loaded: file_helper
INFO - 2024-02-12 19:49:19 --> Helper loaded: form_helper
INFO - 2024-02-12 19:49:19 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:49:19 --> Controller Class Initialized
INFO - 2024-02-12 19:49:19 --> Form Validation Class Initialized
INFO - 2024-02-12 19:49:19 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:49:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:49:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:49:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:49:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:49:19 --> Final output sent to browser
DEBUG - 2024-02-12 19:49:19 --> Total execution time: 0.0393
ERROR - 2024-02-12 19:49:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:49:49 --> Config Class Initialized
INFO - 2024-02-12 19:49:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:49:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:49:49 --> Utf8 Class Initialized
INFO - 2024-02-12 19:49:49 --> URI Class Initialized
INFO - 2024-02-12 19:49:49 --> Router Class Initialized
INFO - 2024-02-12 19:49:49 --> Output Class Initialized
INFO - 2024-02-12 19:49:49 --> Security Class Initialized
DEBUG - 2024-02-12 19:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:49:49 --> Input Class Initialized
INFO - 2024-02-12 19:49:49 --> Language Class Initialized
INFO - 2024-02-12 19:49:49 --> Loader Class Initialized
INFO - 2024-02-12 19:49:49 --> Helper loaded: url_helper
INFO - 2024-02-12 19:49:49 --> Helper loaded: file_helper
INFO - 2024-02-12 19:49:49 --> Helper loaded: form_helper
INFO - 2024-02-12 19:49:49 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:49:49 --> Controller Class Initialized
INFO - 2024-02-12 19:49:49 --> Form Validation Class Initialized
INFO - 2024-02-12 19:49:49 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:49:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:49:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:49:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:49:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:49:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:49:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:49:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:49:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:49:49 --> Final output sent to browser
DEBUG - 2024-02-12 19:49:49 --> Total execution time: 0.0321
ERROR - 2024-02-12 19:49:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:49:50 --> Config Class Initialized
INFO - 2024-02-12 19:49:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:49:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:49:50 --> Utf8 Class Initialized
INFO - 2024-02-12 19:49:50 --> URI Class Initialized
INFO - 2024-02-12 19:49:50 --> Router Class Initialized
INFO - 2024-02-12 19:49:50 --> Output Class Initialized
INFO - 2024-02-12 19:49:50 --> Security Class Initialized
DEBUG - 2024-02-12 19:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:49:50 --> Input Class Initialized
INFO - 2024-02-12 19:49:50 --> Language Class Initialized
INFO - 2024-02-12 19:49:50 --> Loader Class Initialized
INFO - 2024-02-12 19:49:50 --> Helper loaded: url_helper
INFO - 2024-02-12 19:49:50 --> Helper loaded: file_helper
INFO - 2024-02-12 19:49:50 --> Helper loaded: form_helper
INFO - 2024-02-12 19:49:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:49:50 --> Controller Class Initialized
INFO - 2024-02-12 19:49:50 --> Form Validation Class Initialized
INFO - 2024-02-12 19:49:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:49:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:49:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:49:50 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:49:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:49:52 --> Config Class Initialized
INFO - 2024-02-12 19:49:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:49:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:49:52 --> Utf8 Class Initialized
INFO - 2024-02-12 19:49:52 --> URI Class Initialized
INFO - 2024-02-12 19:49:52 --> Router Class Initialized
INFO - 2024-02-12 19:49:52 --> Output Class Initialized
INFO - 2024-02-12 19:49:52 --> Security Class Initialized
DEBUG - 2024-02-12 19:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:49:52 --> Input Class Initialized
INFO - 2024-02-12 19:49:52 --> Language Class Initialized
INFO - 2024-02-12 19:49:52 --> Loader Class Initialized
INFO - 2024-02-12 19:49:52 --> Helper loaded: url_helper
INFO - 2024-02-12 19:49:52 --> Helper loaded: file_helper
INFO - 2024-02-12 19:49:52 --> Helper loaded: form_helper
INFO - 2024-02-12 19:49:52 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:49:52 --> Controller Class Initialized
INFO - 2024-02-12 19:49:52 --> Form Validation Class Initialized
INFO - 2024-02-12 19:49:52 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:49:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:49:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:49:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:49:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:49:52 --> Final output sent to browser
DEBUG - 2024-02-12 19:49:52 --> Total execution time: 0.0393
ERROR - 2024-02-12 19:51:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:51:06 --> Config Class Initialized
INFO - 2024-02-12 19:51:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:51:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:51:06 --> Utf8 Class Initialized
INFO - 2024-02-12 19:51:06 --> URI Class Initialized
INFO - 2024-02-12 19:51:06 --> Router Class Initialized
INFO - 2024-02-12 19:51:06 --> Output Class Initialized
INFO - 2024-02-12 19:51:06 --> Security Class Initialized
DEBUG - 2024-02-12 19:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:51:06 --> Input Class Initialized
INFO - 2024-02-12 19:51:06 --> Language Class Initialized
INFO - 2024-02-12 19:51:06 --> Loader Class Initialized
INFO - 2024-02-12 19:51:06 --> Helper loaded: url_helper
INFO - 2024-02-12 19:51:06 --> Helper loaded: file_helper
INFO - 2024-02-12 19:51:06 --> Helper loaded: form_helper
INFO - 2024-02-12 19:51:06 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:51:06 --> Controller Class Initialized
INFO - 2024-02-12 19:51:06 --> Form Validation Class Initialized
INFO - 2024-02-12 19:51:06 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:51:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:51:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:51:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:51:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:51:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:51:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:51:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:51:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:51:06 --> Final output sent to browser
DEBUG - 2024-02-12 19:51:06 --> Total execution time: 0.0297
ERROR - 2024-02-12 19:51:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:51:06 --> Config Class Initialized
INFO - 2024-02-12 19:51:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:51:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:51:06 --> Utf8 Class Initialized
INFO - 2024-02-12 19:51:06 --> URI Class Initialized
INFO - 2024-02-12 19:51:06 --> Router Class Initialized
INFO - 2024-02-12 19:51:06 --> Output Class Initialized
INFO - 2024-02-12 19:51:06 --> Security Class Initialized
DEBUG - 2024-02-12 19:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:51:06 --> Input Class Initialized
INFO - 2024-02-12 19:51:06 --> Language Class Initialized
INFO - 2024-02-12 19:51:06 --> Loader Class Initialized
INFO - 2024-02-12 19:51:06 --> Helper loaded: url_helper
INFO - 2024-02-12 19:51:06 --> Helper loaded: file_helper
INFO - 2024-02-12 19:51:06 --> Helper loaded: form_helper
INFO - 2024-02-12 19:51:06 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:51:06 --> Controller Class Initialized
INFO - 2024-02-12 19:51:06 --> Form Validation Class Initialized
INFO - 2024-02-12 19:51:06 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:51:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:51:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:51:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:51:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:51:10 --> Config Class Initialized
INFO - 2024-02-12 19:51:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:51:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:51:10 --> Utf8 Class Initialized
INFO - 2024-02-12 19:51:10 --> URI Class Initialized
INFO - 2024-02-12 19:51:10 --> Router Class Initialized
INFO - 2024-02-12 19:51:10 --> Output Class Initialized
INFO - 2024-02-12 19:51:10 --> Security Class Initialized
DEBUG - 2024-02-12 19:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:51:10 --> Input Class Initialized
INFO - 2024-02-12 19:51:10 --> Language Class Initialized
INFO - 2024-02-12 19:51:10 --> Loader Class Initialized
INFO - 2024-02-12 19:51:10 --> Helper loaded: url_helper
INFO - 2024-02-12 19:51:10 --> Helper loaded: file_helper
INFO - 2024-02-12 19:51:10 --> Helper loaded: form_helper
INFO - 2024-02-12 19:51:10 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:51:10 --> Controller Class Initialized
INFO - 2024-02-12 19:51:10 --> Form Validation Class Initialized
INFO - 2024-02-12 19:51:10 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:51:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:51:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:51:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:51:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:51:10 --> Final output sent to browser
DEBUG - 2024-02-12 19:51:10 --> Total execution time: 0.0416
ERROR - 2024-02-12 19:51:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:51:26 --> Config Class Initialized
INFO - 2024-02-12 19:51:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:51:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:51:26 --> Utf8 Class Initialized
INFO - 2024-02-12 19:51:26 --> URI Class Initialized
INFO - 2024-02-12 19:51:26 --> Router Class Initialized
INFO - 2024-02-12 19:51:26 --> Output Class Initialized
INFO - 2024-02-12 19:51:26 --> Security Class Initialized
DEBUG - 2024-02-12 19:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:51:26 --> Input Class Initialized
INFO - 2024-02-12 19:51:26 --> Language Class Initialized
INFO - 2024-02-12 19:51:26 --> Loader Class Initialized
INFO - 2024-02-12 19:51:26 --> Helper loaded: url_helper
INFO - 2024-02-12 19:51:26 --> Helper loaded: file_helper
INFO - 2024-02-12 19:51:26 --> Helper loaded: form_helper
INFO - 2024-02-12 19:51:26 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:51:26 --> Controller Class Initialized
INFO - 2024-02-12 19:51:26 --> Form Validation Class Initialized
INFO - 2024-02-12 19:51:26 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:51:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:51:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:51:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:51:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:51:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:51:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:51:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:51:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:51:26 --> Final output sent to browser
DEBUG - 2024-02-12 19:51:26 --> Total execution time: 0.0391
ERROR - 2024-02-12 19:51:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:51:26 --> Config Class Initialized
INFO - 2024-02-12 19:51:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:51:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:51:26 --> Utf8 Class Initialized
INFO - 2024-02-12 19:51:26 --> URI Class Initialized
INFO - 2024-02-12 19:51:26 --> Router Class Initialized
INFO - 2024-02-12 19:51:26 --> Output Class Initialized
INFO - 2024-02-12 19:51:26 --> Security Class Initialized
DEBUG - 2024-02-12 19:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:51:26 --> Input Class Initialized
INFO - 2024-02-12 19:51:26 --> Language Class Initialized
INFO - 2024-02-12 19:51:26 --> Loader Class Initialized
INFO - 2024-02-12 19:51:26 --> Helper loaded: url_helper
INFO - 2024-02-12 19:51:26 --> Helper loaded: file_helper
INFO - 2024-02-12 19:51:26 --> Helper loaded: form_helper
INFO - 2024-02-12 19:51:26 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:51:26 --> Controller Class Initialized
INFO - 2024-02-12 19:51:26 --> Form Validation Class Initialized
INFO - 2024-02-12 19:51:26 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:51:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:51:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:51:26 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:51:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:51:28 --> Config Class Initialized
INFO - 2024-02-12 19:51:28 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:51:28 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:51:28 --> Utf8 Class Initialized
INFO - 2024-02-12 19:51:28 --> URI Class Initialized
INFO - 2024-02-12 19:51:28 --> Router Class Initialized
INFO - 2024-02-12 19:51:28 --> Output Class Initialized
INFO - 2024-02-12 19:51:28 --> Security Class Initialized
DEBUG - 2024-02-12 19:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:51:28 --> Input Class Initialized
INFO - 2024-02-12 19:51:28 --> Language Class Initialized
INFO - 2024-02-12 19:51:28 --> Loader Class Initialized
INFO - 2024-02-12 19:51:28 --> Helper loaded: url_helper
INFO - 2024-02-12 19:51:28 --> Helper loaded: file_helper
INFO - 2024-02-12 19:51:28 --> Helper loaded: form_helper
INFO - 2024-02-12 19:51:28 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:51:28 --> Controller Class Initialized
INFO - 2024-02-12 19:51:28 --> Form Validation Class Initialized
INFO - 2024-02-12 19:51:28 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:51:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:51:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:51:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:51:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:51:28 --> Final output sent to browser
DEBUG - 2024-02-12 19:51:28 --> Total execution time: 0.0369
ERROR - 2024-02-12 19:52:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:52:14 --> Config Class Initialized
INFO - 2024-02-12 19:52:14 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:52:14 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:52:14 --> Utf8 Class Initialized
INFO - 2024-02-12 19:52:14 --> URI Class Initialized
INFO - 2024-02-12 19:52:14 --> Router Class Initialized
INFO - 2024-02-12 19:52:14 --> Output Class Initialized
INFO - 2024-02-12 19:52:14 --> Security Class Initialized
DEBUG - 2024-02-12 19:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:52:14 --> Input Class Initialized
INFO - 2024-02-12 19:52:14 --> Language Class Initialized
INFO - 2024-02-12 19:52:14 --> Loader Class Initialized
INFO - 2024-02-12 19:52:14 --> Helper loaded: url_helper
INFO - 2024-02-12 19:52:14 --> Helper loaded: file_helper
INFO - 2024-02-12 19:52:14 --> Helper loaded: form_helper
INFO - 2024-02-12 19:52:14 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:52:14 --> Controller Class Initialized
INFO - 2024-02-12 19:52:14 --> Form Validation Class Initialized
INFO - 2024-02-12 19:52:14 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:52:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:52:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:52:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:52:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:52:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:52:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:52:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:52:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:52:14 --> Final output sent to browser
DEBUG - 2024-02-12 19:52:14 --> Total execution time: 0.0331
ERROR - 2024-02-12 19:52:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:52:15 --> Config Class Initialized
INFO - 2024-02-12 19:52:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:52:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:52:15 --> Utf8 Class Initialized
INFO - 2024-02-12 19:52:15 --> URI Class Initialized
INFO - 2024-02-12 19:52:15 --> Router Class Initialized
INFO - 2024-02-12 19:52:15 --> Output Class Initialized
INFO - 2024-02-12 19:52:15 --> Security Class Initialized
DEBUG - 2024-02-12 19:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:52:15 --> Input Class Initialized
INFO - 2024-02-12 19:52:15 --> Language Class Initialized
INFO - 2024-02-12 19:52:15 --> Loader Class Initialized
INFO - 2024-02-12 19:52:15 --> Helper loaded: url_helper
INFO - 2024-02-12 19:52:15 --> Helper loaded: file_helper
INFO - 2024-02-12 19:52:15 --> Helper loaded: form_helper
INFO - 2024-02-12 19:52:15 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:52:15 --> Controller Class Initialized
INFO - 2024-02-12 19:52:15 --> Form Validation Class Initialized
INFO - 2024-02-12 19:52:15 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:52:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:52:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:52:15 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:52:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:52:17 --> Config Class Initialized
INFO - 2024-02-12 19:52:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:52:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:52:17 --> Utf8 Class Initialized
INFO - 2024-02-12 19:52:17 --> URI Class Initialized
INFO - 2024-02-12 19:52:17 --> Router Class Initialized
INFO - 2024-02-12 19:52:17 --> Output Class Initialized
INFO - 2024-02-12 19:52:17 --> Security Class Initialized
DEBUG - 2024-02-12 19:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:52:17 --> Input Class Initialized
INFO - 2024-02-12 19:52:17 --> Language Class Initialized
INFO - 2024-02-12 19:52:17 --> Loader Class Initialized
INFO - 2024-02-12 19:52:17 --> Helper loaded: url_helper
INFO - 2024-02-12 19:52:17 --> Helper loaded: file_helper
INFO - 2024-02-12 19:52:17 --> Helper loaded: form_helper
INFO - 2024-02-12 19:52:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:52:17 --> Controller Class Initialized
INFO - 2024-02-12 19:52:17 --> Form Validation Class Initialized
INFO - 2024-02-12 19:52:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:52:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:52:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:52:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:52:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:52:17 --> Final output sent to browser
DEBUG - 2024-02-12 19:52:17 --> Total execution time: 0.0341
ERROR - 2024-02-12 19:52:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:52:39 --> Config Class Initialized
INFO - 2024-02-12 19:52:39 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:52:39 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:52:39 --> Utf8 Class Initialized
INFO - 2024-02-12 19:52:39 --> URI Class Initialized
INFO - 2024-02-12 19:52:39 --> Router Class Initialized
INFO - 2024-02-12 19:52:39 --> Output Class Initialized
INFO - 2024-02-12 19:52:39 --> Security Class Initialized
DEBUG - 2024-02-12 19:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:52:39 --> Input Class Initialized
INFO - 2024-02-12 19:52:39 --> Language Class Initialized
INFO - 2024-02-12 19:52:39 --> Loader Class Initialized
INFO - 2024-02-12 19:52:39 --> Helper loaded: url_helper
INFO - 2024-02-12 19:52:39 --> Helper loaded: file_helper
INFO - 2024-02-12 19:52:39 --> Helper loaded: form_helper
INFO - 2024-02-12 19:52:39 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:52:39 --> Controller Class Initialized
INFO - 2024-02-12 19:52:39 --> Form Validation Class Initialized
INFO - 2024-02-12 19:52:39 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:52:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:52:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:52:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:52:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:52:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:52:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:52:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:52:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:52:39 --> Final output sent to browser
DEBUG - 2024-02-12 19:52:39 --> Total execution time: 0.0253
ERROR - 2024-02-12 19:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:52:40 --> Config Class Initialized
INFO - 2024-02-12 19:52:40 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:52:40 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:52:40 --> Utf8 Class Initialized
INFO - 2024-02-12 19:52:40 --> URI Class Initialized
INFO - 2024-02-12 19:52:40 --> Router Class Initialized
INFO - 2024-02-12 19:52:40 --> Output Class Initialized
INFO - 2024-02-12 19:52:40 --> Security Class Initialized
DEBUG - 2024-02-12 19:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:52:40 --> Input Class Initialized
INFO - 2024-02-12 19:52:40 --> Language Class Initialized
INFO - 2024-02-12 19:52:40 --> Loader Class Initialized
INFO - 2024-02-12 19:52:40 --> Helper loaded: url_helper
INFO - 2024-02-12 19:52:40 --> Helper loaded: file_helper
INFO - 2024-02-12 19:52:40 --> Helper loaded: form_helper
INFO - 2024-02-12 19:52:40 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:52:40 --> Controller Class Initialized
INFO - 2024-02-12 19:52:40 --> Form Validation Class Initialized
INFO - 2024-02-12 19:52:40 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:52:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:52:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:52:40 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:52:41 --> Config Class Initialized
INFO - 2024-02-12 19:52:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:52:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:52:41 --> Utf8 Class Initialized
INFO - 2024-02-12 19:52:41 --> URI Class Initialized
INFO - 2024-02-12 19:52:41 --> Router Class Initialized
INFO - 2024-02-12 19:52:41 --> Output Class Initialized
INFO - 2024-02-12 19:52:41 --> Security Class Initialized
DEBUG - 2024-02-12 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:52:41 --> Input Class Initialized
INFO - 2024-02-12 19:52:41 --> Language Class Initialized
INFO - 2024-02-12 19:52:41 --> Loader Class Initialized
INFO - 2024-02-12 19:52:41 --> Helper loaded: url_helper
INFO - 2024-02-12 19:52:41 --> Helper loaded: file_helper
INFO - 2024-02-12 19:52:41 --> Helper loaded: form_helper
INFO - 2024-02-12 19:52:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:52:41 --> Controller Class Initialized
INFO - 2024-02-12 19:52:41 --> Form Validation Class Initialized
INFO - 2024-02-12 19:52:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:52:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:52:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:52:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:52:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:52:41 --> Final output sent to browser
DEBUG - 2024-02-12 19:52:41 --> Total execution time: 0.0247
ERROR - 2024-02-12 19:53:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:53:22 --> Config Class Initialized
INFO - 2024-02-12 19:53:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:53:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:53:22 --> Utf8 Class Initialized
INFO - 2024-02-12 19:53:22 --> URI Class Initialized
INFO - 2024-02-12 19:53:22 --> Router Class Initialized
INFO - 2024-02-12 19:53:22 --> Output Class Initialized
INFO - 2024-02-12 19:53:22 --> Security Class Initialized
DEBUG - 2024-02-12 19:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:53:22 --> Input Class Initialized
INFO - 2024-02-12 19:53:22 --> Language Class Initialized
INFO - 2024-02-12 19:53:22 --> Loader Class Initialized
INFO - 2024-02-12 19:53:22 --> Helper loaded: url_helper
INFO - 2024-02-12 19:53:22 --> Helper loaded: file_helper
INFO - 2024-02-12 19:53:22 --> Helper loaded: form_helper
INFO - 2024-02-12 19:53:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:53:22 --> Controller Class Initialized
INFO - 2024-02-12 19:53:22 --> Form Validation Class Initialized
INFO - 2024-02-12 19:53:22 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:53:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:53:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:53:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:53:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:53:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:53:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:53:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:53:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:53:22 --> Final output sent to browser
DEBUG - 2024-02-12 19:53:22 --> Total execution time: 0.0273
ERROR - 2024-02-12 19:53:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:53:22 --> Config Class Initialized
INFO - 2024-02-12 19:53:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:53:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:53:22 --> Utf8 Class Initialized
INFO - 2024-02-12 19:53:22 --> URI Class Initialized
INFO - 2024-02-12 19:53:22 --> Router Class Initialized
INFO - 2024-02-12 19:53:22 --> Output Class Initialized
INFO - 2024-02-12 19:53:22 --> Security Class Initialized
DEBUG - 2024-02-12 19:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:53:22 --> Input Class Initialized
INFO - 2024-02-12 19:53:22 --> Language Class Initialized
INFO - 2024-02-12 19:53:22 --> Loader Class Initialized
INFO - 2024-02-12 19:53:22 --> Helper loaded: url_helper
INFO - 2024-02-12 19:53:22 --> Helper loaded: file_helper
INFO - 2024-02-12 19:53:22 --> Helper loaded: form_helper
INFO - 2024-02-12 19:53:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:53:23 --> Controller Class Initialized
INFO - 2024-02-12 19:53:23 --> Form Validation Class Initialized
INFO - 2024-02-12 19:53:23 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:53:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:53:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:53:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:53:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:53:26 --> Config Class Initialized
INFO - 2024-02-12 19:53:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:53:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:53:26 --> Utf8 Class Initialized
INFO - 2024-02-12 19:53:26 --> URI Class Initialized
INFO - 2024-02-12 19:53:26 --> Router Class Initialized
INFO - 2024-02-12 19:53:26 --> Output Class Initialized
INFO - 2024-02-12 19:53:26 --> Security Class Initialized
DEBUG - 2024-02-12 19:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:53:26 --> Input Class Initialized
INFO - 2024-02-12 19:53:26 --> Language Class Initialized
INFO - 2024-02-12 19:53:26 --> Loader Class Initialized
INFO - 2024-02-12 19:53:26 --> Helper loaded: url_helper
INFO - 2024-02-12 19:53:26 --> Helper loaded: file_helper
INFO - 2024-02-12 19:53:26 --> Helper loaded: form_helper
INFO - 2024-02-12 19:53:26 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:53:26 --> Controller Class Initialized
INFO - 2024-02-12 19:53:26 --> Form Validation Class Initialized
INFO - 2024-02-12 19:53:26 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:53:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:53:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:53:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:53:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:53:26 --> Final output sent to browser
DEBUG - 2024-02-12 19:53:26 --> Total execution time: 0.0317
ERROR - 2024-02-12 19:55:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:55:13 --> Config Class Initialized
INFO - 2024-02-12 19:55:13 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:55:13 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:55:13 --> Utf8 Class Initialized
INFO - 2024-02-12 19:55:13 --> URI Class Initialized
INFO - 2024-02-12 19:55:13 --> Router Class Initialized
INFO - 2024-02-12 19:55:13 --> Output Class Initialized
INFO - 2024-02-12 19:55:13 --> Security Class Initialized
DEBUG - 2024-02-12 19:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:55:13 --> Input Class Initialized
INFO - 2024-02-12 19:55:13 --> Language Class Initialized
INFO - 2024-02-12 19:55:13 --> Loader Class Initialized
INFO - 2024-02-12 19:55:13 --> Helper loaded: url_helper
INFO - 2024-02-12 19:55:13 --> Helper loaded: file_helper
INFO - 2024-02-12 19:55:13 --> Helper loaded: form_helper
INFO - 2024-02-12 19:55:13 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:55:13 --> Controller Class Initialized
INFO - 2024-02-12 19:55:13 --> Form Validation Class Initialized
INFO - 2024-02-12 19:55:13 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:55:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:55:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:55:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:55:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:55:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:55:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:55:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:55:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:55:13 --> Final output sent to browser
DEBUG - 2024-02-12 19:55:13 --> Total execution time: 0.0280
ERROR - 2024-02-12 19:55:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:55:14 --> Config Class Initialized
INFO - 2024-02-12 19:55:14 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:55:14 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:55:14 --> Utf8 Class Initialized
INFO - 2024-02-12 19:55:14 --> URI Class Initialized
INFO - 2024-02-12 19:55:14 --> Router Class Initialized
INFO - 2024-02-12 19:55:14 --> Output Class Initialized
INFO - 2024-02-12 19:55:14 --> Security Class Initialized
DEBUG - 2024-02-12 19:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:55:14 --> Input Class Initialized
INFO - 2024-02-12 19:55:14 --> Language Class Initialized
INFO - 2024-02-12 19:55:14 --> Loader Class Initialized
INFO - 2024-02-12 19:55:14 --> Helper loaded: url_helper
INFO - 2024-02-12 19:55:14 --> Helper loaded: file_helper
INFO - 2024-02-12 19:55:14 --> Helper loaded: form_helper
INFO - 2024-02-12 19:55:14 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:55:14 --> Controller Class Initialized
INFO - 2024-02-12 19:55:14 --> Form Validation Class Initialized
INFO - 2024-02-12 19:55:14 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:55:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:55:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:55:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:55:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:55:16 --> Config Class Initialized
INFO - 2024-02-12 19:55:16 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:55:16 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:55:16 --> Utf8 Class Initialized
INFO - 2024-02-12 19:55:16 --> URI Class Initialized
INFO - 2024-02-12 19:55:16 --> Router Class Initialized
INFO - 2024-02-12 19:55:16 --> Output Class Initialized
INFO - 2024-02-12 19:55:16 --> Security Class Initialized
DEBUG - 2024-02-12 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:55:16 --> Input Class Initialized
INFO - 2024-02-12 19:55:16 --> Language Class Initialized
INFO - 2024-02-12 19:55:16 --> Loader Class Initialized
INFO - 2024-02-12 19:55:16 --> Helper loaded: url_helper
INFO - 2024-02-12 19:55:16 --> Helper loaded: file_helper
INFO - 2024-02-12 19:55:16 --> Helper loaded: form_helper
INFO - 2024-02-12 19:55:16 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:55:16 --> Controller Class Initialized
INFO - 2024-02-12 19:55:16 --> Form Validation Class Initialized
INFO - 2024-02-12 19:55:16 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:55:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:55:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:55:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:55:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:55:16 --> Final output sent to browser
DEBUG - 2024-02-12 19:55:16 --> Total execution time: 0.0499
ERROR - 2024-02-12 19:56:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:56:23 --> Config Class Initialized
INFO - 2024-02-12 19:56:23 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:56:23 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:56:23 --> Utf8 Class Initialized
INFO - 2024-02-12 19:56:23 --> URI Class Initialized
INFO - 2024-02-12 19:56:23 --> Router Class Initialized
INFO - 2024-02-12 19:56:23 --> Output Class Initialized
INFO - 2024-02-12 19:56:23 --> Security Class Initialized
DEBUG - 2024-02-12 19:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:56:23 --> Input Class Initialized
INFO - 2024-02-12 19:56:23 --> Language Class Initialized
INFO - 2024-02-12 19:56:23 --> Loader Class Initialized
INFO - 2024-02-12 19:56:23 --> Helper loaded: url_helper
INFO - 2024-02-12 19:56:23 --> Helper loaded: file_helper
INFO - 2024-02-12 19:56:23 --> Helper loaded: form_helper
INFO - 2024-02-12 19:56:23 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:56:23 --> Controller Class Initialized
INFO - 2024-02-12 19:56:23 --> Form Validation Class Initialized
INFO - 2024-02-12 19:56:23 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:56:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:56:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:56:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:56:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:56:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:56:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:56:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:56:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:56:23 --> Final output sent to browser
DEBUG - 2024-02-12 19:56:23 --> Total execution time: 0.0323
ERROR - 2024-02-12 19:56:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:56:23 --> Config Class Initialized
INFO - 2024-02-12 19:56:23 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:56:23 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:56:23 --> Utf8 Class Initialized
INFO - 2024-02-12 19:56:23 --> URI Class Initialized
INFO - 2024-02-12 19:56:23 --> Router Class Initialized
INFO - 2024-02-12 19:56:23 --> Output Class Initialized
INFO - 2024-02-12 19:56:23 --> Security Class Initialized
DEBUG - 2024-02-12 19:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:56:23 --> Input Class Initialized
INFO - 2024-02-12 19:56:23 --> Language Class Initialized
INFO - 2024-02-12 19:56:23 --> Loader Class Initialized
INFO - 2024-02-12 19:56:23 --> Helper loaded: url_helper
INFO - 2024-02-12 19:56:23 --> Helper loaded: file_helper
INFO - 2024-02-12 19:56:23 --> Helper loaded: form_helper
INFO - 2024-02-12 19:56:23 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:56:23 --> Controller Class Initialized
INFO - 2024-02-12 19:56:23 --> Form Validation Class Initialized
INFO - 2024-02-12 19:56:23 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:56:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:56:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:56:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:56:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:56:27 --> Config Class Initialized
INFO - 2024-02-12 19:56:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:56:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:56:27 --> Utf8 Class Initialized
INFO - 2024-02-12 19:56:27 --> URI Class Initialized
INFO - 2024-02-12 19:56:27 --> Router Class Initialized
INFO - 2024-02-12 19:56:27 --> Output Class Initialized
INFO - 2024-02-12 19:56:27 --> Security Class Initialized
DEBUG - 2024-02-12 19:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:56:27 --> Input Class Initialized
INFO - 2024-02-12 19:56:27 --> Language Class Initialized
INFO - 2024-02-12 19:56:27 --> Loader Class Initialized
INFO - 2024-02-12 19:56:27 --> Helper loaded: url_helper
INFO - 2024-02-12 19:56:27 --> Helper loaded: file_helper
INFO - 2024-02-12 19:56:27 --> Helper loaded: form_helper
INFO - 2024-02-12 19:56:27 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:56:27 --> Controller Class Initialized
INFO - 2024-02-12 19:56:27 --> Form Validation Class Initialized
INFO - 2024-02-12 19:56:27 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:56:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:56:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:56:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:56:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:56:27 --> Final output sent to browser
DEBUG - 2024-02-12 19:56:27 --> Total execution time: 0.0329
ERROR - 2024-02-12 19:57:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:57:08 --> Config Class Initialized
INFO - 2024-02-12 19:57:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:57:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:57:08 --> Utf8 Class Initialized
INFO - 2024-02-12 19:57:08 --> URI Class Initialized
INFO - 2024-02-12 19:57:08 --> Router Class Initialized
INFO - 2024-02-12 19:57:08 --> Output Class Initialized
INFO - 2024-02-12 19:57:08 --> Security Class Initialized
DEBUG - 2024-02-12 19:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:57:08 --> Input Class Initialized
INFO - 2024-02-12 19:57:08 --> Language Class Initialized
INFO - 2024-02-12 19:57:08 --> Loader Class Initialized
INFO - 2024-02-12 19:57:08 --> Helper loaded: url_helper
INFO - 2024-02-12 19:57:08 --> Helper loaded: file_helper
INFO - 2024-02-12 19:57:08 --> Helper loaded: form_helper
INFO - 2024-02-12 19:57:08 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:57:08 --> Controller Class Initialized
INFO - 2024-02-12 19:57:08 --> Form Validation Class Initialized
INFO - 2024-02-12 19:57:08 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:57:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:57:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:57:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:57:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:57:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:57:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:57:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:57:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:57:08 --> Final output sent to browser
DEBUG - 2024-02-12 19:57:08 --> Total execution time: 0.0319
ERROR - 2024-02-12 19:57:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:57:08 --> Config Class Initialized
INFO - 2024-02-12 19:57:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:57:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:57:08 --> Utf8 Class Initialized
INFO - 2024-02-12 19:57:08 --> URI Class Initialized
INFO - 2024-02-12 19:57:08 --> Router Class Initialized
INFO - 2024-02-12 19:57:08 --> Output Class Initialized
INFO - 2024-02-12 19:57:08 --> Security Class Initialized
DEBUG - 2024-02-12 19:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:57:08 --> Input Class Initialized
INFO - 2024-02-12 19:57:08 --> Language Class Initialized
INFO - 2024-02-12 19:57:08 --> Loader Class Initialized
INFO - 2024-02-12 19:57:08 --> Helper loaded: url_helper
INFO - 2024-02-12 19:57:08 --> Helper loaded: file_helper
INFO - 2024-02-12 19:57:08 --> Helper loaded: form_helper
INFO - 2024-02-12 19:57:09 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:57:09 --> Controller Class Initialized
INFO - 2024-02-12 19:57:09 --> Form Validation Class Initialized
INFO - 2024-02-12 19:57:09 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:57:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:57:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:57:09 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:57:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:57:11 --> Config Class Initialized
INFO - 2024-02-12 19:57:11 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:57:11 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:57:11 --> Utf8 Class Initialized
INFO - 2024-02-12 19:57:11 --> URI Class Initialized
INFO - 2024-02-12 19:57:11 --> Router Class Initialized
INFO - 2024-02-12 19:57:11 --> Output Class Initialized
INFO - 2024-02-12 19:57:11 --> Security Class Initialized
DEBUG - 2024-02-12 19:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:57:11 --> Input Class Initialized
INFO - 2024-02-12 19:57:11 --> Language Class Initialized
INFO - 2024-02-12 19:57:11 --> Loader Class Initialized
INFO - 2024-02-12 19:57:11 --> Helper loaded: url_helper
INFO - 2024-02-12 19:57:11 --> Helper loaded: file_helper
INFO - 2024-02-12 19:57:11 --> Helper loaded: form_helper
INFO - 2024-02-12 19:57:11 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:57:11 --> Controller Class Initialized
INFO - 2024-02-12 19:57:11 --> Form Validation Class Initialized
INFO - 2024-02-12 19:57:11 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:57:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:57:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:57:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:57:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:57:11 --> Final output sent to browser
DEBUG - 2024-02-12 19:57:11 --> Total execution time: 0.0325
ERROR - 2024-02-12 19:59:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:59:07 --> Config Class Initialized
INFO - 2024-02-12 19:59:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:59:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:59:07 --> Utf8 Class Initialized
INFO - 2024-02-12 19:59:07 --> URI Class Initialized
INFO - 2024-02-12 19:59:07 --> Router Class Initialized
INFO - 2024-02-12 19:59:07 --> Output Class Initialized
INFO - 2024-02-12 19:59:07 --> Security Class Initialized
DEBUG - 2024-02-12 19:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:59:07 --> Input Class Initialized
INFO - 2024-02-12 19:59:07 --> Language Class Initialized
INFO - 2024-02-12 19:59:07 --> Loader Class Initialized
INFO - 2024-02-12 19:59:07 --> Helper loaded: url_helper
INFO - 2024-02-12 19:59:07 --> Helper loaded: file_helper
INFO - 2024-02-12 19:59:07 --> Helper loaded: form_helper
INFO - 2024-02-12 19:59:07 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:59:07 --> Controller Class Initialized
INFO - 2024-02-12 19:59:07 --> Form Validation Class Initialized
INFO - 2024-02-12 19:59:07 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:59:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:59:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:59:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:59:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:59:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:59:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:59:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:59:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:59:07 --> Final output sent to browser
DEBUG - 2024-02-12 19:59:07 --> Total execution time: 0.0296
ERROR - 2024-02-12 19:59:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:59:07 --> Config Class Initialized
INFO - 2024-02-12 19:59:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:59:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:59:07 --> Utf8 Class Initialized
INFO - 2024-02-12 19:59:07 --> URI Class Initialized
INFO - 2024-02-12 19:59:07 --> Router Class Initialized
INFO - 2024-02-12 19:59:07 --> Output Class Initialized
INFO - 2024-02-12 19:59:07 --> Security Class Initialized
DEBUG - 2024-02-12 19:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:59:07 --> Input Class Initialized
INFO - 2024-02-12 19:59:07 --> Language Class Initialized
INFO - 2024-02-12 19:59:07 --> Loader Class Initialized
INFO - 2024-02-12 19:59:07 --> Helper loaded: url_helper
INFO - 2024-02-12 19:59:07 --> Helper loaded: file_helper
INFO - 2024-02-12 19:59:07 --> Helper loaded: form_helper
INFO - 2024-02-12 19:59:07 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:59:07 --> Controller Class Initialized
INFO - 2024-02-12 19:59:07 --> Form Validation Class Initialized
INFO - 2024-02-12 19:59:07 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:59:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:59:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:59:07 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:59:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:59:10 --> Config Class Initialized
INFO - 2024-02-12 19:59:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:59:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:59:10 --> Utf8 Class Initialized
INFO - 2024-02-12 19:59:10 --> URI Class Initialized
INFO - 2024-02-12 19:59:10 --> Router Class Initialized
INFO - 2024-02-12 19:59:10 --> Output Class Initialized
INFO - 2024-02-12 19:59:10 --> Security Class Initialized
DEBUG - 2024-02-12 19:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:59:10 --> Input Class Initialized
INFO - 2024-02-12 19:59:10 --> Language Class Initialized
INFO - 2024-02-12 19:59:10 --> Loader Class Initialized
INFO - 2024-02-12 19:59:10 --> Helper loaded: url_helper
INFO - 2024-02-12 19:59:10 --> Helper loaded: file_helper
INFO - 2024-02-12 19:59:10 --> Helper loaded: form_helper
INFO - 2024-02-12 19:59:10 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:59:10 --> Controller Class Initialized
INFO - 2024-02-12 19:59:10 --> Form Validation Class Initialized
INFO - 2024-02-12 19:59:10 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:59:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:59:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:59:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:59:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:59:10 --> Final output sent to browser
DEBUG - 2024-02-12 19:59:10 --> Total execution time: 0.0347
ERROR - 2024-02-12 19:59:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:59:54 --> Config Class Initialized
INFO - 2024-02-12 19:59:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:59:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:59:54 --> Utf8 Class Initialized
INFO - 2024-02-12 19:59:54 --> URI Class Initialized
INFO - 2024-02-12 19:59:54 --> Router Class Initialized
INFO - 2024-02-12 19:59:54 --> Output Class Initialized
INFO - 2024-02-12 19:59:54 --> Security Class Initialized
DEBUG - 2024-02-12 19:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:59:54 --> Input Class Initialized
INFO - 2024-02-12 19:59:54 --> Language Class Initialized
INFO - 2024-02-12 19:59:54 --> Loader Class Initialized
INFO - 2024-02-12 19:59:54 --> Helper loaded: url_helper
INFO - 2024-02-12 19:59:54 --> Helper loaded: file_helper
INFO - 2024-02-12 19:59:54 --> Helper loaded: form_helper
INFO - 2024-02-12 19:59:54 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:59:54 --> Controller Class Initialized
INFO - 2024-02-12 19:59:54 --> Form Validation Class Initialized
INFO - 2024-02-12 19:59:54 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:59:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:59:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:59:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:59:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 19:59:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 19:59:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 19:59:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 19:59:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 19:59:54 --> Final output sent to browser
DEBUG - 2024-02-12 19:59:54 --> Total execution time: 0.0280
ERROR - 2024-02-12 19:59:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:59:55 --> Config Class Initialized
INFO - 2024-02-12 19:59:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:59:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:59:55 --> Utf8 Class Initialized
INFO - 2024-02-12 19:59:55 --> URI Class Initialized
INFO - 2024-02-12 19:59:55 --> Router Class Initialized
INFO - 2024-02-12 19:59:55 --> Output Class Initialized
INFO - 2024-02-12 19:59:55 --> Security Class Initialized
DEBUG - 2024-02-12 19:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:59:55 --> Input Class Initialized
INFO - 2024-02-12 19:59:55 --> Language Class Initialized
INFO - 2024-02-12 19:59:55 --> Loader Class Initialized
INFO - 2024-02-12 19:59:55 --> Helper loaded: url_helper
INFO - 2024-02-12 19:59:55 --> Helper loaded: file_helper
INFO - 2024-02-12 19:59:55 --> Helper loaded: form_helper
INFO - 2024-02-12 19:59:55 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:59:55 --> Controller Class Initialized
INFO - 2024-02-12 19:59:55 --> Form Validation Class Initialized
INFO - 2024-02-12 19:59:55 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:59:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:59:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:59:55 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 19:59:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 19:59:57 --> Config Class Initialized
INFO - 2024-02-12 19:59:57 --> Hooks Class Initialized
DEBUG - 2024-02-12 19:59:57 --> UTF-8 Support Enabled
INFO - 2024-02-12 19:59:57 --> Utf8 Class Initialized
INFO - 2024-02-12 19:59:57 --> URI Class Initialized
INFO - 2024-02-12 19:59:57 --> Router Class Initialized
INFO - 2024-02-12 19:59:57 --> Output Class Initialized
INFO - 2024-02-12 19:59:57 --> Security Class Initialized
DEBUG - 2024-02-12 19:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 19:59:57 --> Input Class Initialized
INFO - 2024-02-12 19:59:57 --> Language Class Initialized
INFO - 2024-02-12 19:59:57 --> Loader Class Initialized
INFO - 2024-02-12 19:59:57 --> Helper loaded: url_helper
INFO - 2024-02-12 19:59:57 --> Helper loaded: file_helper
INFO - 2024-02-12 19:59:57 --> Helper loaded: form_helper
INFO - 2024-02-12 19:59:57 --> Database Driver Class Initialized
DEBUG - 2024-02-12 19:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 19:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 19:59:57 --> Controller Class Initialized
INFO - 2024-02-12 19:59:57 --> Form Validation Class Initialized
INFO - 2024-02-12 19:59:57 --> Model "MasterModel" initialized
INFO - 2024-02-12 19:59:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 19:59:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 19:59:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 19:59:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 19:59:57 --> Final output sent to browser
DEBUG - 2024-02-12 19:59:57 --> Total execution time: 0.0286
ERROR - 2024-02-12 20:00:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:00:17 --> Config Class Initialized
INFO - 2024-02-12 20:00:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:00:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:00:17 --> Utf8 Class Initialized
INFO - 2024-02-12 20:00:17 --> URI Class Initialized
INFO - 2024-02-12 20:00:17 --> Router Class Initialized
INFO - 2024-02-12 20:00:17 --> Output Class Initialized
INFO - 2024-02-12 20:00:17 --> Security Class Initialized
DEBUG - 2024-02-12 20:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:00:17 --> Input Class Initialized
INFO - 2024-02-12 20:00:17 --> Language Class Initialized
INFO - 2024-02-12 20:00:17 --> Loader Class Initialized
INFO - 2024-02-12 20:00:17 --> Helper loaded: url_helper
INFO - 2024-02-12 20:00:17 --> Helper loaded: file_helper
INFO - 2024-02-12 20:00:17 --> Helper loaded: form_helper
INFO - 2024-02-12 20:00:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:00:17 --> Controller Class Initialized
INFO - 2024-02-12 20:00:17 --> Form Validation Class Initialized
INFO - 2024-02-12 20:00:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:00:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:00:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:00:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:00:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:00:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:00:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:00:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:00:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:00:17 --> Final output sent to browser
DEBUG - 2024-02-12 20:00:17 --> Total execution time: 0.0324
ERROR - 2024-02-12 20:00:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:00:18 --> Config Class Initialized
INFO - 2024-02-12 20:00:18 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:00:18 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:00:18 --> Utf8 Class Initialized
INFO - 2024-02-12 20:00:18 --> URI Class Initialized
INFO - 2024-02-12 20:00:18 --> Router Class Initialized
INFO - 2024-02-12 20:00:18 --> Output Class Initialized
INFO - 2024-02-12 20:00:18 --> Security Class Initialized
DEBUG - 2024-02-12 20:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:00:18 --> Input Class Initialized
INFO - 2024-02-12 20:00:18 --> Language Class Initialized
INFO - 2024-02-12 20:00:18 --> Loader Class Initialized
INFO - 2024-02-12 20:00:18 --> Helper loaded: url_helper
INFO - 2024-02-12 20:00:18 --> Helper loaded: file_helper
INFO - 2024-02-12 20:00:18 --> Helper loaded: form_helper
INFO - 2024-02-12 20:00:18 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:00:18 --> Controller Class Initialized
INFO - 2024-02-12 20:00:18 --> Form Validation Class Initialized
INFO - 2024-02-12 20:00:18 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:00:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:00:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:00:18 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:00:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:00:21 --> Config Class Initialized
INFO - 2024-02-12 20:00:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:00:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:00:21 --> Utf8 Class Initialized
INFO - 2024-02-12 20:00:21 --> URI Class Initialized
INFO - 2024-02-12 20:00:21 --> Router Class Initialized
INFO - 2024-02-12 20:00:21 --> Output Class Initialized
INFO - 2024-02-12 20:00:21 --> Security Class Initialized
DEBUG - 2024-02-12 20:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:00:21 --> Input Class Initialized
INFO - 2024-02-12 20:00:21 --> Language Class Initialized
INFO - 2024-02-12 20:00:21 --> Loader Class Initialized
INFO - 2024-02-12 20:00:21 --> Helper loaded: url_helper
INFO - 2024-02-12 20:00:21 --> Helper loaded: file_helper
INFO - 2024-02-12 20:00:21 --> Helper loaded: form_helper
INFO - 2024-02-12 20:00:21 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:00:21 --> Controller Class Initialized
INFO - 2024-02-12 20:00:21 --> Form Validation Class Initialized
INFO - 2024-02-12 20:00:21 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:00:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:00:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:00:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:00:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:00:21 --> Final output sent to browser
DEBUG - 2024-02-12 20:00:21 --> Total execution time: 0.0349
ERROR - 2024-02-12 20:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:01:16 --> Config Class Initialized
INFO - 2024-02-12 20:01:16 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:01:16 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:01:16 --> Utf8 Class Initialized
INFO - 2024-02-12 20:01:16 --> URI Class Initialized
INFO - 2024-02-12 20:01:16 --> Router Class Initialized
INFO - 2024-02-12 20:01:16 --> Output Class Initialized
INFO - 2024-02-12 20:01:16 --> Security Class Initialized
DEBUG - 2024-02-12 20:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:01:16 --> Input Class Initialized
INFO - 2024-02-12 20:01:16 --> Language Class Initialized
INFO - 2024-02-12 20:01:16 --> Loader Class Initialized
INFO - 2024-02-12 20:01:16 --> Helper loaded: url_helper
INFO - 2024-02-12 20:01:16 --> Helper loaded: file_helper
INFO - 2024-02-12 20:01:16 --> Helper loaded: form_helper
INFO - 2024-02-12 20:01:16 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:01:16 --> Controller Class Initialized
INFO - 2024-02-12 20:01:16 --> Form Validation Class Initialized
INFO - 2024-02-12 20:01:16 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:01:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:01:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:01:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:01:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:01:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:01:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:01:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:01:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:01:16 --> Final output sent to browser
DEBUG - 2024-02-12 20:01:16 --> Total execution time: 0.0347
ERROR - 2024-02-12 20:01:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:01:17 --> Config Class Initialized
INFO - 2024-02-12 20:01:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:01:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:01:17 --> Utf8 Class Initialized
INFO - 2024-02-12 20:01:17 --> URI Class Initialized
INFO - 2024-02-12 20:01:17 --> Router Class Initialized
INFO - 2024-02-12 20:01:17 --> Output Class Initialized
INFO - 2024-02-12 20:01:17 --> Security Class Initialized
DEBUG - 2024-02-12 20:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:01:17 --> Input Class Initialized
INFO - 2024-02-12 20:01:17 --> Language Class Initialized
INFO - 2024-02-12 20:01:17 --> Loader Class Initialized
INFO - 2024-02-12 20:01:17 --> Helper loaded: url_helper
INFO - 2024-02-12 20:01:17 --> Helper loaded: file_helper
INFO - 2024-02-12 20:01:17 --> Helper loaded: form_helper
INFO - 2024-02-12 20:01:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:01:17 --> Controller Class Initialized
INFO - 2024-02-12 20:01:17 --> Form Validation Class Initialized
INFO - 2024-02-12 20:01:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:01:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:01:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:01:17 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:01:22 --> Config Class Initialized
INFO - 2024-02-12 20:01:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:01:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:01:22 --> Utf8 Class Initialized
INFO - 2024-02-12 20:01:22 --> URI Class Initialized
INFO - 2024-02-12 20:01:22 --> Router Class Initialized
INFO - 2024-02-12 20:01:22 --> Output Class Initialized
INFO - 2024-02-12 20:01:22 --> Security Class Initialized
DEBUG - 2024-02-12 20:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:01:22 --> Input Class Initialized
INFO - 2024-02-12 20:01:22 --> Language Class Initialized
INFO - 2024-02-12 20:01:22 --> Loader Class Initialized
INFO - 2024-02-12 20:01:22 --> Helper loaded: url_helper
INFO - 2024-02-12 20:01:22 --> Helper loaded: file_helper
INFO - 2024-02-12 20:01:22 --> Helper loaded: form_helper
INFO - 2024-02-12 20:01:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:01:22 --> Controller Class Initialized
INFO - 2024-02-12 20:01:22 --> Form Validation Class Initialized
INFO - 2024-02-12 20:01:22 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:01:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:01:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:01:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:01:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:01:22 --> Final output sent to browser
DEBUG - 2024-02-12 20:01:22 --> Total execution time: 0.0250
ERROR - 2024-02-12 20:02:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:02:08 --> Config Class Initialized
INFO - 2024-02-12 20:02:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:02:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:02:08 --> Utf8 Class Initialized
INFO - 2024-02-12 20:02:08 --> URI Class Initialized
INFO - 2024-02-12 20:02:08 --> Router Class Initialized
INFO - 2024-02-12 20:02:08 --> Output Class Initialized
INFO - 2024-02-12 20:02:08 --> Security Class Initialized
DEBUG - 2024-02-12 20:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:02:08 --> Input Class Initialized
INFO - 2024-02-12 20:02:08 --> Language Class Initialized
INFO - 2024-02-12 20:02:08 --> Loader Class Initialized
INFO - 2024-02-12 20:02:08 --> Helper loaded: url_helper
INFO - 2024-02-12 20:02:08 --> Helper loaded: file_helper
INFO - 2024-02-12 20:02:08 --> Helper loaded: form_helper
INFO - 2024-02-12 20:02:08 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:02:08 --> Controller Class Initialized
INFO - 2024-02-12 20:02:08 --> Form Validation Class Initialized
INFO - 2024-02-12 20:02:08 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:02:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:02:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:02:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:02:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:02:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:02:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:02:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:02:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:02:08 --> Final output sent to browser
DEBUG - 2024-02-12 20:02:08 --> Total execution time: 0.0424
ERROR - 2024-02-12 20:02:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:02:09 --> Config Class Initialized
INFO - 2024-02-12 20:02:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:02:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:02:09 --> Utf8 Class Initialized
INFO - 2024-02-12 20:02:09 --> URI Class Initialized
INFO - 2024-02-12 20:02:09 --> Router Class Initialized
INFO - 2024-02-12 20:02:09 --> Output Class Initialized
INFO - 2024-02-12 20:02:09 --> Security Class Initialized
DEBUG - 2024-02-12 20:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:02:09 --> Input Class Initialized
INFO - 2024-02-12 20:02:09 --> Language Class Initialized
INFO - 2024-02-12 20:02:09 --> Loader Class Initialized
INFO - 2024-02-12 20:02:09 --> Helper loaded: url_helper
INFO - 2024-02-12 20:02:09 --> Helper loaded: file_helper
INFO - 2024-02-12 20:02:09 --> Helper loaded: form_helper
INFO - 2024-02-12 20:02:09 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:02:09 --> Controller Class Initialized
INFO - 2024-02-12 20:02:09 --> Form Validation Class Initialized
INFO - 2024-02-12 20:02:09 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:02:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:02:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:02:09 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:02:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:02:12 --> Config Class Initialized
INFO - 2024-02-12 20:02:12 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:02:12 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:02:12 --> Utf8 Class Initialized
INFO - 2024-02-12 20:02:12 --> URI Class Initialized
INFO - 2024-02-12 20:02:12 --> Router Class Initialized
INFO - 2024-02-12 20:02:12 --> Output Class Initialized
INFO - 2024-02-12 20:02:12 --> Security Class Initialized
DEBUG - 2024-02-12 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:02:12 --> Input Class Initialized
INFO - 2024-02-12 20:02:12 --> Language Class Initialized
INFO - 2024-02-12 20:02:12 --> Loader Class Initialized
INFO - 2024-02-12 20:02:12 --> Helper loaded: url_helper
INFO - 2024-02-12 20:02:12 --> Helper loaded: file_helper
INFO - 2024-02-12 20:02:12 --> Helper loaded: form_helper
INFO - 2024-02-12 20:02:12 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:02:12 --> Controller Class Initialized
INFO - 2024-02-12 20:02:12 --> Form Validation Class Initialized
INFO - 2024-02-12 20:02:12 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:02:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:02:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:02:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:02:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:02:12 --> Final output sent to browser
DEBUG - 2024-02-12 20:02:12 --> Total execution time: 0.0303
ERROR - 2024-02-12 20:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:02:52 --> Config Class Initialized
INFO - 2024-02-12 20:02:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:02:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:02:52 --> Utf8 Class Initialized
INFO - 2024-02-12 20:02:52 --> URI Class Initialized
INFO - 2024-02-12 20:02:52 --> Router Class Initialized
INFO - 2024-02-12 20:02:52 --> Output Class Initialized
INFO - 2024-02-12 20:02:52 --> Security Class Initialized
DEBUG - 2024-02-12 20:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:02:52 --> Input Class Initialized
INFO - 2024-02-12 20:02:52 --> Language Class Initialized
INFO - 2024-02-12 20:02:52 --> Loader Class Initialized
INFO - 2024-02-12 20:02:52 --> Helper loaded: url_helper
INFO - 2024-02-12 20:02:52 --> Helper loaded: file_helper
INFO - 2024-02-12 20:02:52 --> Helper loaded: form_helper
INFO - 2024-02-12 20:02:52 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:02:52 --> Controller Class Initialized
INFO - 2024-02-12 20:02:52 --> Form Validation Class Initialized
INFO - 2024-02-12 20:02:52 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:02:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:02:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:02:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:02:52 --> Final output sent to browser
DEBUG - 2024-02-12 20:02:52 --> Total execution time: 0.0315
ERROR - 2024-02-12 20:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:02:52 --> Config Class Initialized
INFO - 2024-02-12 20:02:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:02:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:02:52 --> Utf8 Class Initialized
INFO - 2024-02-12 20:02:52 --> URI Class Initialized
INFO - 2024-02-12 20:02:52 --> Router Class Initialized
INFO - 2024-02-12 20:02:52 --> Output Class Initialized
INFO - 2024-02-12 20:02:52 --> Security Class Initialized
DEBUG - 2024-02-12 20:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:02:52 --> Input Class Initialized
INFO - 2024-02-12 20:02:52 --> Language Class Initialized
INFO - 2024-02-12 20:02:52 --> Loader Class Initialized
INFO - 2024-02-12 20:02:52 --> Helper loaded: url_helper
INFO - 2024-02-12 20:02:52 --> Helper loaded: file_helper
INFO - 2024-02-12 20:02:52 --> Helper loaded: form_helper
INFO - 2024-02-12 20:02:52 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:02:52 --> Controller Class Initialized
INFO - 2024-02-12 20:02:52 --> Form Validation Class Initialized
INFO - 2024-02-12 20:02:52 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:02:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:02:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:02:52 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:02:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:02:54 --> Config Class Initialized
INFO - 2024-02-12 20:02:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:02:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:02:54 --> Utf8 Class Initialized
INFO - 2024-02-12 20:02:54 --> URI Class Initialized
INFO - 2024-02-12 20:02:54 --> Router Class Initialized
INFO - 2024-02-12 20:02:54 --> Output Class Initialized
INFO - 2024-02-12 20:02:54 --> Security Class Initialized
DEBUG - 2024-02-12 20:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:02:54 --> Input Class Initialized
INFO - 2024-02-12 20:02:54 --> Language Class Initialized
INFO - 2024-02-12 20:02:54 --> Loader Class Initialized
INFO - 2024-02-12 20:02:54 --> Helper loaded: url_helper
INFO - 2024-02-12 20:02:54 --> Helper loaded: file_helper
INFO - 2024-02-12 20:02:54 --> Helper loaded: form_helper
INFO - 2024-02-12 20:02:54 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:02:54 --> Controller Class Initialized
INFO - 2024-02-12 20:02:54 --> Form Validation Class Initialized
INFO - 2024-02-12 20:02:54 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:02:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:02:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:02:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:02:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:02:54 --> Final output sent to browser
DEBUG - 2024-02-12 20:02:54 --> Total execution time: 0.0296
ERROR - 2024-02-12 20:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:03:22 --> Config Class Initialized
INFO - 2024-02-12 20:03:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:03:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:03:22 --> Utf8 Class Initialized
INFO - 2024-02-12 20:03:22 --> URI Class Initialized
INFO - 2024-02-12 20:03:22 --> Router Class Initialized
INFO - 2024-02-12 20:03:22 --> Output Class Initialized
INFO - 2024-02-12 20:03:22 --> Security Class Initialized
DEBUG - 2024-02-12 20:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:03:22 --> Input Class Initialized
INFO - 2024-02-12 20:03:22 --> Language Class Initialized
INFO - 2024-02-12 20:03:22 --> Loader Class Initialized
INFO - 2024-02-12 20:03:22 --> Helper loaded: url_helper
INFO - 2024-02-12 20:03:22 --> Helper loaded: file_helper
INFO - 2024-02-12 20:03:22 --> Helper loaded: form_helper
INFO - 2024-02-12 20:03:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:03:22 --> Controller Class Initialized
INFO - 2024-02-12 20:03:22 --> Form Validation Class Initialized
INFO - 2024-02-12 20:03:22 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:03:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:03:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:03:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:03:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:03:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:03:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:03:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:03:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:03:22 --> Final output sent to browser
DEBUG - 2024-02-12 20:03:22 --> Total execution time: 0.0363
ERROR - 2024-02-12 20:03:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:03:24 --> Config Class Initialized
INFO - 2024-02-12 20:03:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:03:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:03:24 --> Utf8 Class Initialized
INFO - 2024-02-12 20:03:24 --> URI Class Initialized
INFO - 2024-02-12 20:03:24 --> Router Class Initialized
INFO - 2024-02-12 20:03:24 --> Output Class Initialized
INFO - 2024-02-12 20:03:24 --> Security Class Initialized
DEBUG - 2024-02-12 20:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:03:24 --> Input Class Initialized
INFO - 2024-02-12 20:03:24 --> Language Class Initialized
INFO - 2024-02-12 20:03:24 --> Loader Class Initialized
INFO - 2024-02-12 20:03:24 --> Helper loaded: url_helper
INFO - 2024-02-12 20:03:24 --> Helper loaded: file_helper
INFO - 2024-02-12 20:03:24 --> Helper loaded: form_helper
INFO - 2024-02-12 20:03:24 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:03:24 --> Controller Class Initialized
INFO - 2024-02-12 20:03:24 --> Form Validation Class Initialized
INFO - 2024-02-12 20:03:24 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:03:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:03:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:03:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:03:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:03:26 --> Config Class Initialized
INFO - 2024-02-12 20:03:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:03:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:03:26 --> Utf8 Class Initialized
INFO - 2024-02-12 20:03:26 --> URI Class Initialized
INFO - 2024-02-12 20:03:26 --> Router Class Initialized
INFO - 2024-02-12 20:03:26 --> Output Class Initialized
INFO - 2024-02-12 20:03:26 --> Security Class Initialized
DEBUG - 2024-02-12 20:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:03:26 --> Input Class Initialized
INFO - 2024-02-12 20:03:26 --> Language Class Initialized
INFO - 2024-02-12 20:03:26 --> Loader Class Initialized
INFO - 2024-02-12 20:03:26 --> Helper loaded: url_helper
INFO - 2024-02-12 20:03:26 --> Helper loaded: file_helper
INFO - 2024-02-12 20:03:26 --> Helper loaded: form_helper
INFO - 2024-02-12 20:03:26 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:03:26 --> Controller Class Initialized
INFO - 2024-02-12 20:03:26 --> Form Validation Class Initialized
INFO - 2024-02-12 20:03:26 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:03:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:03:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:03:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:03:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:03:26 --> Final output sent to browser
DEBUG - 2024-02-12 20:03:26 --> Total execution time: 0.0312
ERROR - 2024-02-12 20:04:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:04:48 --> Config Class Initialized
INFO - 2024-02-12 20:04:48 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:04:48 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:04:48 --> Utf8 Class Initialized
INFO - 2024-02-12 20:04:48 --> URI Class Initialized
INFO - 2024-02-12 20:04:48 --> Router Class Initialized
INFO - 2024-02-12 20:04:48 --> Output Class Initialized
INFO - 2024-02-12 20:04:48 --> Security Class Initialized
DEBUG - 2024-02-12 20:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:04:48 --> Input Class Initialized
INFO - 2024-02-12 20:04:48 --> Language Class Initialized
INFO - 2024-02-12 20:04:48 --> Loader Class Initialized
INFO - 2024-02-12 20:04:48 --> Helper loaded: url_helper
INFO - 2024-02-12 20:04:48 --> Helper loaded: file_helper
INFO - 2024-02-12 20:04:48 --> Helper loaded: form_helper
INFO - 2024-02-12 20:04:48 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:04:48 --> Controller Class Initialized
INFO - 2024-02-12 20:04:48 --> Form Validation Class Initialized
INFO - 2024-02-12 20:04:48 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:04:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:04:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:04:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:04:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:04:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:04:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:04:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:04:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:04:48 --> Final output sent to browser
DEBUG - 2024-02-12 20:04:48 --> Total execution time: 0.0281
ERROR - 2024-02-12 20:04:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:04:48 --> Config Class Initialized
INFO - 2024-02-12 20:04:48 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:04:48 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:04:48 --> Utf8 Class Initialized
INFO - 2024-02-12 20:04:48 --> URI Class Initialized
INFO - 2024-02-12 20:04:48 --> Router Class Initialized
INFO - 2024-02-12 20:04:48 --> Output Class Initialized
INFO - 2024-02-12 20:04:48 --> Security Class Initialized
DEBUG - 2024-02-12 20:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:04:48 --> Input Class Initialized
INFO - 2024-02-12 20:04:48 --> Language Class Initialized
INFO - 2024-02-12 20:04:48 --> Loader Class Initialized
INFO - 2024-02-12 20:04:48 --> Helper loaded: url_helper
INFO - 2024-02-12 20:04:48 --> Helper loaded: file_helper
INFO - 2024-02-12 20:04:48 --> Helper loaded: form_helper
INFO - 2024-02-12 20:04:48 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:04:48 --> Controller Class Initialized
INFO - 2024-02-12 20:04:48 --> Form Validation Class Initialized
INFO - 2024-02-12 20:04:48 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:04:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:04:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:04:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:04:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:04:58 --> Config Class Initialized
INFO - 2024-02-12 20:04:58 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:04:58 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:04:58 --> Utf8 Class Initialized
INFO - 2024-02-12 20:04:58 --> URI Class Initialized
INFO - 2024-02-12 20:04:58 --> Router Class Initialized
INFO - 2024-02-12 20:04:58 --> Output Class Initialized
INFO - 2024-02-12 20:04:58 --> Security Class Initialized
DEBUG - 2024-02-12 20:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:04:58 --> Input Class Initialized
INFO - 2024-02-12 20:04:58 --> Language Class Initialized
INFO - 2024-02-12 20:04:58 --> Loader Class Initialized
INFO - 2024-02-12 20:04:58 --> Helper loaded: url_helper
INFO - 2024-02-12 20:04:58 --> Helper loaded: file_helper
INFO - 2024-02-12 20:04:58 --> Helper loaded: form_helper
INFO - 2024-02-12 20:04:58 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:04:58 --> Controller Class Initialized
INFO - 2024-02-12 20:04:58 --> Form Validation Class Initialized
INFO - 2024-02-12 20:04:58 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:04:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:04:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:04:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:04:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:04:58 --> Final output sent to browser
DEBUG - 2024-02-12 20:04:58 --> Total execution time: 0.0457
ERROR - 2024-02-12 20:07:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:07:36 --> Config Class Initialized
INFO - 2024-02-12 20:07:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:07:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:07:36 --> Utf8 Class Initialized
INFO - 2024-02-12 20:07:36 --> URI Class Initialized
INFO - 2024-02-12 20:07:36 --> Router Class Initialized
INFO - 2024-02-12 20:07:36 --> Output Class Initialized
INFO - 2024-02-12 20:07:36 --> Security Class Initialized
DEBUG - 2024-02-12 20:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:07:36 --> Input Class Initialized
INFO - 2024-02-12 20:07:36 --> Language Class Initialized
INFO - 2024-02-12 20:07:36 --> Loader Class Initialized
INFO - 2024-02-12 20:07:36 --> Helper loaded: url_helper
INFO - 2024-02-12 20:07:36 --> Helper loaded: file_helper
INFO - 2024-02-12 20:07:36 --> Helper loaded: form_helper
INFO - 2024-02-12 20:07:36 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:07:36 --> Controller Class Initialized
INFO - 2024-02-12 20:07:36 --> Form Validation Class Initialized
INFO - 2024-02-12 20:07:36 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:07:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:07:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:07:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:07:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:07:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:07:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:07:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:07:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:07:36 --> Final output sent to browser
DEBUG - 2024-02-12 20:07:36 --> Total execution time: 0.0280
ERROR - 2024-02-12 20:07:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:07:37 --> Config Class Initialized
INFO - 2024-02-12 20:07:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:07:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:07:37 --> Utf8 Class Initialized
INFO - 2024-02-12 20:07:37 --> URI Class Initialized
INFO - 2024-02-12 20:07:37 --> Router Class Initialized
INFO - 2024-02-12 20:07:37 --> Output Class Initialized
INFO - 2024-02-12 20:07:37 --> Security Class Initialized
DEBUG - 2024-02-12 20:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:07:37 --> Input Class Initialized
INFO - 2024-02-12 20:07:37 --> Language Class Initialized
INFO - 2024-02-12 20:07:37 --> Loader Class Initialized
INFO - 2024-02-12 20:07:37 --> Helper loaded: url_helper
INFO - 2024-02-12 20:07:37 --> Helper loaded: file_helper
INFO - 2024-02-12 20:07:37 --> Helper loaded: form_helper
INFO - 2024-02-12 20:07:37 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:07:37 --> Controller Class Initialized
INFO - 2024-02-12 20:07:37 --> Form Validation Class Initialized
INFO - 2024-02-12 20:07:37 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:07:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:07:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:07:37 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:07:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:07:40 --> Config Class Initialized
INFO - 2024-02-12 20:07:40 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:07:40 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:07:40 --> Utf8 Class Initialized
INFO - 2024-02-12 20:07:40 --> URI Class Initialized
INFO - 2024-02-12 20:07:40 --> Router Class Initialized
INFO - 2024-02-12 20:07:40 --> Output Class Initialized
INFO - 2024-02-12 20:07:40 --> Security Class Initialized
DEBUG - 2024-02-12 20:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:07:40 --> Input Class Initialized
INFO - 2024-02-12 20:07:40 --> Language Class Initialized
INFO - 2024-02-12 20:07:40 --> Loader Class Initialized
INFO - 2024-02-12 20:07:40 --> Helper loaded: url_helper
INFO - 2024-02-12 20:07:40 --> Helper loaded: file_helper
INFO - 2024-02-12 20:07:40 --> Helper loaded: form_helper
INFO - 2024-02-12 20:07:40 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:07:40 --> Controller Class Initialized
INFO - 2024-02-12 20:07:40 --> Form Validation Class Initialized
INFO - 2024-02-12 20:07:40 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:07:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:07:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:07:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:07:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:07:40 --> Final output sent to browser
DEBUG - 2024-02-12 20:07:40 --> Total execution time: 0.0391
ERROR - 2024-02-12 20:09:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:09:02 --> Config Class Initialized
INFO - 2024-02-12 20:09:02 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:09:02 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:09:02 --> Utf8 Class Initialized
INFO - 2024-02-12 20:09:02 --> URI Class Initialized
INFO - 2024-02-12 20:09:02 --> Router Class Initialized
INFO - 2024-02-12 20:09:02 --> Output Class Initialized
INFO - 2024-02-12 20:09:02 --> Security Class Initialized
DEBUG - 2024-02-12 20:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:09:02 --> Input Class Initialized
INFO - 2024-02-12 20:09:02 --> Language Class Initialized
INFO - 2024-02-12 20:09:02 --> Loader Class Initialized
INFO - 2024-02-12 20:09:02 --> Helper loaded: url_helper
INFO - 2024-02-12 20:09:02 --> Helper loaded: file_helper
INFO - 2024-02-12 20:09:02 --> Helper loaded: form_helper
INFO - 2024-02-12 20:09:02 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:09:02 --> Controller Class Initialized
INFO - 2024-02-12 20:09:02 --> Form Validation Class Initialized
INFO - 2024-02-12 20:09:02 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:09:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:09:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:09:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:09:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:09:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:09:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:09:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:09:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:09:02 --> Final output sent to browser
DEBUG - 2024-02-12 20:09:02 --> Total execution time: 0.0366
ERROR - 2024-02-12 20:09:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:09:03 --> Config Class Initialized
INFO - 2024-02-12 20:09:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:09:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:09:03 --> Utf8 Class Initialized
INFO - 2024-02-12 20:09:03 --> URI Class Initialized
INFO - 2024-02-12 20:09:03 --> Router Class Initialized
INFO - 2024-02-12 20:09:03 --> Output Class Initialized
INFO - 2024-02-12 20:09:03 --> Security Class Initialized
DEBUG - 2024-02-12 20:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:09:03 --> Input Class Initialized
INFO - 2024-02-12 20:09:03 --> Language Class Initialized
INFO - 2024-02-12 20:09:03 --> Loader Class Initialized
INFO - 2024-02-12 20:09:03 --> Helper loaded: url_helper
INFO - 2024-02-12 20:09:03 --> Helper loaded: file_helper
INFO - 2024-02-12 20:09:03 --> Helper loaded: form_helper
INFO - 2024-02-12 20:09:03 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:09:03 --> Controller Class Initialized
INFO - 2024-02-12 20:09:03 --> Form Validation Class Initialized
INFO - 2024-02-12 20:09:03 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:09:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:09:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:09:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:09:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:09:05 --> Config Class Initialized
INFO - 2024-02-12 20:09:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:09:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:09:05 --> Utf8 Class Initialized
INFO - 2024-02-12 20:09:05 --> URI Class Initialized
INFO - 2024-02-12 20:09:05 --> Router Class Initialized
INFO - 2024-02-12 20:09:05 --> Output Class Initialized
INFO - 2024-02-12 20:09:05 --> Security Class Initialized
DEBUG - 2024-02-12 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:09:05 --> Input Class Initialized
INFO - 2024-02-12 20:09:05 --> Language Class Initialized
INFO - 2024-02-12 20:09:05 --> Loader Class Initialized
INFO - 2024-02-12 20:09:05 --> Helper loaded: url_helper
INFO - 2024-02-12 20:09:05 --> Helper loaded: file_helper
INFO - 2024-02-12 20:09:05 --> Helper loaded: form_helper
INFO - 2024-02-12 20:09:05 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:09:05 --> Controller Class Initialized
INFO - 2024-02-12 20:09:05 --> Form Validation Class Initialized
INFO - 2024-02-12 20:09:05 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:09:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:09:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:09:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:09:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:09:05 --> Final output sent to browser
DEBUG - 2024-02-12 20:09:05 --> Total execution time: 0.0392
ERROR - 2024-02-12 20:09:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:09:43 --> Config Class Initialized
INFO - 2024-02-12 20:09:43 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:09:43 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:09:43 --> Utf8 Class Initialized
INFO - 2024-02-12 20:09:43 --> URI Class Initialized
INFO - 2024-02-12 20:09:43 --> Router Class Initialized
INFO - 2024-02-12 20:09:43 --> Output Class Initialized
INFO - 2024-02-12 20:09:43 --> Security Class Initialized
DEBUG - 2024-02-12 20:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:09:43 --> Input Class Initialized
INFO - 2024-02-12 20:09:43 --> Language Class Initialized
INFO - 2024-02-12 20:09:43 --> Loader Class Initialized
INFO - 2024-02-12 20:09:43 --> Helper loaded: url_helper
INFO - 2024-02-12 20:09:43 --> Helper loaded: file_helper
INFO - 2024-02-12 20:09:43 --> Helper loaded: form_helper
INFO - 2024-02-12 20:09:43 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:09:43 --> Controller Class Initialized
INFO - 2024-02-12 20:09:43 --> Form Validation Class Initialized
INFO - 2024-02-12 20:09:43 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:09:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:09:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:09:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:09:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:09:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:09:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:09:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:09:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:09:43 --> Final output sent to browser
DEBUG - 2024-02-12 20:09:43 --> Total execution time: 0.0300
ERROR - 2024-02-12 20:09:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:09:43 --> Config Class Initialized
INFO - 2024-02-12 20:09:43 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:09:43 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:09:43 --> Utf8 Class Initialized
INFO - 2024-02-12 20:09:43 --> URI Class Initialized
INFO - 2024-02-12 20:09:43 --> Router Class Initialized
INFO - 2024-02-12 20:09:43 --> Output Class Initialized
INFO - 2024-02-12 20:09:43 --> Security Class Initialized
DEBUG - 2024-02-12 20:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:09:43 --> Input Class Initialized
INFO - 2024-02-12 20:09:43 --> Language Class Initialized
INFO - 2024-02-12 20:09:43 --> Loader Class Initialized
INFO - 2024-02-12 20:09:43 --> Helper loaded: url_helper
INFO - 2024-02-12 20:09:43 --> Helper loaded: file_helper
INFO - 2024-02-12 20:09:43 --> Helper loaded: form_helper
INFO - 2024-02-12 20:09:43 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:09:43 --> Controller Class Initialized
INFO - 2024-02-12 20:09:43 --> Form Validation Class Initialized
INFO - 2024-02-12 20:09:43 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:09:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:09:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:09:43 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:09:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:09:46 --> Config Class Initialized
INFO - 2024-02-12 20:09:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:09:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:09:46 --> Utf8 Class Initialized
INFO - 2024-02-12 20:09:46 --> URI Class Initialized
INFO - 2024-02-12 20:09:46 --> Router Class Initialized
INFO - 2024-02-12 20:09:46 --> Output Class Initialized
INFO - 2024-02-12 20:09:46 --> Security Class Initialized
DEBUG - 2024-02-12 20:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:09:46 --> Input Class Initialized
INFO - 2024-02-12 20:09:46 --> Language Class Initialized
INFO - 2024-02-12 20:09:46 --> Loader Class Initialized
INFO - 2024-02-12 20:09:46 --> Helper loaded: url_helper
INFO - 2024-02-12 20:09:46 --> Helper loaded: file_helper
INFO - 2024-02-12 20:09:46 --> Helper loaded: form_helper
INFO - 2024-02-12 20:09:46 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:09:46 --> Controller Class Initialized
INFO - 2024-02-12 20:09:46 --> Form Validation Class Initialized
INFO - 2024-02-12 20:09:46 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:09:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:09:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:09:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:09:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:09:46 --> Final output sent to browser
DEBUG - 2024-02-12 20:09:46 --> Total execution time: 0.0387
ERROR - 2024-02-12 20:10:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:10:13 --> Config Class Initialized
INFO - 2024-02-12 20:10:13 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:10:13 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:10:13 --> Utf8 Class Initialized
INFO - 2024-02-12 20:10:13 --> URI Class Initialized
INFO - 2024-02-12 20:10:13 --> Router Class Initialized
INFO - 2024-02-12 20:10:13 --> Output Class Initialized
INFO - 2024-02-12 20:10:13 --> Security Class Initialized
DEBUG - 2024-02-12 20:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:10:13 --> Input Class Initialized
INFO - 2024-02-12 20:10:13 --> Language Class Initialized
INFO - 2024-02-12 20:10:13 --> Loader Class Initialized
INFO - 2024-02-12 20:10:13 --> Helper loaded: url_helper
INFO - 2024-02-12 20:10:13 --> Helper loaded: file_helper
INFO - 2024-02-12 20:10:13 --> Helper loaded: form_helper
INFO - 2024-02-12 20:10:13 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:10:13 --> Controller Class Initialized
INFO - 2024-02-12 20:10:13 --> Form Validation Class Initialized
INFO - 2024-02-12 20:10:13 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:10:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:10:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:10:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:10:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:10:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:10:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:10:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:10:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:10:13 --> Final output sent to browser
DEBUG - 2024-02-12 20:10:13 --> Total execution time: 0.0290
ERROR - 2024-02-12 20:10:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:10:13 --> Config Class Initialized
INFO - 2024-02-12 20:10:13 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:10:13 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:10:13 --> Utf8 Class Initialized
INFO - 2024-02-12 20:10:13 --> URI Class Initialized
INFO - 2024-02-12 20:10:13 --> Router Class Initialized
INFO - 2024-02-12 20:10:13 --> Output Class Initialized
INFO - 2024-02-12 20:10:13 --> Security Class Initialized
DEBUG - 2024-02-12 20:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:10:13 --> Input Class Initialized
INFO - 2024-02-12 20:10:13 --> Language Class Initialized
INFO - 2024-02-12 20:10:13 --> Loader Class Initialized
INFO - 2024-02-12 20:10:13 --> Helper loaded: url_helper
INFO - 2024-02-12 20:10:13 --> Helper loaded: file_helper
INFO - 2024-02-12 20:10:13 --> Helper loaded: form_helper
INFO - 2024-02-12 20:10:13 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:10:13 --> Controller Class Initialized
INFO - 2024-02-12 20:10:13 --> Form Validation Class Initialized
INFO - 2024-02-12 20:10:13 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:10:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:10:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:10:13 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:10:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:10:15 --> Config Class Initialized
INFO - 2024-02-12 20:10:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:10:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:10:15 --> Utf8 Class Initialized
INFO - 2024-02-12 20:10:15 --> URI Class Initialized
INFO - 2024-02-12 20:10:15 --> Router Class Initialized
INFO - 2024-02-12 20:10:15 --> Output Class Initialized
INFO - 2024-02-12 20:10:15 --> Security Class Initialized
DEBUG - 2024-02-12 20:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:10:15 --> Input Class Initialized
INFO - 2024-02-12 20:10:15 --> Language Class Initialized
INFO - 2024-02-12 20:10:15 --> Loader Class Initialized
INFO - 2024-02-12 20:10:15 --> Helper loaded: url_helper
INFO - 2024-02-12 20:10:15 --> Helper loaded: file_helper
INFO - 2024-02-12 20:10:15 --> Helper loaded: form_helper
INFO - 2024-02-12 20:10:15 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:10:15 --> Controller Class Initialized
INFO - 2024-02-12 20:10:15 --> Form Validation Class Initialized
INFO - 2024-02-12 20:10:15 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:10:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:10:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:10:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:10:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:10:15 --> Final output sent to browser
DEBUG - 2024-02-12 20:10:15 --> Total execution time: 0.0325
ERROR - 2024-02-12 20:11:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:11:54 --> Config Class Initialized
INFO - 2024-02-12 20:11:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:11:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:11:54 --> Utf8 Class Initialized
INFO - 2024-02-12 20:11:54 --> URI Class Initialized
INFO - 2024-02-12 20:11:54 --> Router Class Initialized
INFO - 2024-02-12 20:11:54 --> Output Class Initialized
INFO - 2024-02-12 20:11:54 --> Security Class Initialized
DEBUG - 2024-02-12 20:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:11:54 --> Input Class Initialized
INFO - 2024-02-12 20:11:54 --> Language Class Initialized
INFO - 2024-02-12 20:11:54 --> Loader Class Initialized
INFO - 2024-02-12 20:11:54 --> Helper loaded: url_helper
INFO - 2024-02-12 20:11:54 --> Helper loaded: file_helper
INFO - 2024-02-12 20:11:54 --> Helper loaded: form_helper
INFO - 2024-02-12 20:11:54 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:11:54 --> Controller Class Initialized
INFO - 2024-02-12 20:11:54 --> Form Validation Class Initialized
INFO - 2024-02-12 20:11:54 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:11:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:11:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:11:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:11:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:11:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:11:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:11:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:11:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:11:54 --> Final output sent to browser
DEBUG - 2024-02-12 20:11:54 --> Total execution time: 0.0261
ERROR - 2024-02-12 20:11:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:11:54 --> Config Class Initialized
INFO - 2024-02-12 20:11:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:11:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:11:54 --> Utf8 Class Initialized
INFO - 2024-02-12 20:11:54 --> URI Class Initialized
INFO - 2024-02-12 20:11:54 --> Router Class Initialized
INFO - 2024-02-12 20:11:54 --> Output Class Initialized
INFO - 2024-02-12 20:11:54 --> Security Class Initialized
DEBUG - 2024-02-12 20:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:11:54 --> Input Class Initialized
INFO - 2024-02-12 20:11:54 --> Language Class Initialized
INFO - 2024-02-12 20:11:54 --> Loader Class Initialized
INFO - 2024-02-12 20:11:54 --> Helper loaded: url_helper
INFO - 2024-02-12 20:11:54 --> Helper loaded: file_helper
INFO - 2024-02-12 20:11:54 --> Helper loaded: form_helper
INFO - 2024-02-12 20:11:54 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:11:54 --> Controller Class Initialized
INFO - 2024-02-12 20:11:54 --> Form Validation Class Initialized
INFO - 2024-02-12 20:11:54 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:11:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:11:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:11:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:11:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:11:56 --> Config Class Initialized
INFO - 2024-02-12 20:11:56 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:11:56 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:11:56 --> Utf8 Class Initialized
INFO - 2024-02-12 20:11:56 --> URI Class Initialized
INFO - 2024-02-12 20:11:56 --> Router Class Initialized
INFO - 2024-02-12 20:11:56 --> Output Class Initialized
INFO - 2024-02-12 20:11:56 --> Security Class Initialized
DEBUG - 2024-02-12 20:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:11:56 --> Input Class Initialized
INFO - 2024-02-12 20:11:56 --> Language Class Initialized
INFO - 2024-02-12 20:11:56 --> Loader Class Initialized
INFO - 2024-02-12 20:11:56 --> Helper loaded: url_helper
INFO - 2024-02-12 20:11:56 --> Helper loaded: file_helper
INFO - 2024-02-12 20:11:56 --> Helper loaded: form_helper
INFO - 2024-02-12 20:11:57 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:11:57 --> Controller Class Initialized
INFO - 2024-02-12 20:11:57 --> Form Validation Class Initialized
INFO - 2024-02-12 20:11:57 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:11:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:11:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:11:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:11:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:11:57 --> Final output sent to browser
DEBUG - 2024-02-12 20:11:57 --> Total execution time: 0.0319
ERROR - 2024-02-12 20:13:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:13:22 --> Config Class Initialized
INFO - 2024-02-12 20:13:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:13:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:13:22 --> Utf8 Class Initialized
INFO - 2024-02-12 20:13:22 --> URI Class Initialized
INFO - 2024-02-12 20:13:22 --> Router Class Initialized
INFO - 2024-02-12 20:13:22 --> Output Class Initialized
INFO - 2024-02-12 20:13:22 --> Security Class Initialized
DEBUG - 2024-02-12 20:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:13:22 --> Input Class Initialized
INFO - 2024-02-12 20:13:22 --> Language Class Initialized
INFO - 2024-02-12 20:13:22 --> Loader Class Initialized
INFO - 2024-02-12 20:13:22 --> Helper loaded: url_helper
INFO - 2024-02-12 20:13:22 --> Helper loaded: file_helper
INFO - 2024-02-12 20:13:22 --> Helper loaded: form_helper
INFO - 2024-02-12 20:13:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:13:22 --> Controller Class Initialized
INFO - 2024-02-12 20:13:22 --> Form Validation Class Initialized
INFO - 2024-02-12 20:13:22 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:13:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:13:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:13:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:13:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:13:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:13:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:13:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:13:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:13:22 --> Final output sent to browser
DEBUG - 2024-02-12 20:13:22 --> Total execution time: 0.0335
ERROR - 2024-02-12 20:13:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:13:23 --> Config Class Initialized
INFO - 2024-02-12 20:13:23 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:13:23 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:13:23 --> Utf8 Class Initialized
INFO - 2024-02-12 20:13:23 --> URI Class Initialized
INFO - 2024-02-12 20:13:23 --> Router Class Initialized
INFO - 2024-02-12 20:13:23 --> Output Class Initialized
INFO - 2024-02-12 20:13:23 --> Security Class Initialized
DEBUG - 2024-02-12 20:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:13:23 --> Input Class Initialized
INFO - 2024-02-12 20:13:23 --> Language Class Initialized
INFO - 2024-02-12 20:13:23 --> Loader Class Initialized
INFO - 2024-02-12 20:13:23 --> Helper loaded: url_helper
INFO - 2024-02-12 20:13:23 --> Helper loaded: file_helper
INFO - 2024-02-12 20:13:23 --> Helper loaded: form_helper
INFO - 2024-02-12 20:13:23 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:13:23 --> Controller Class Initialized
INFO - 2024-02-12 20:13:23 --> Form Validation Class Initialized
INFO - 2024-02-12 20:13:23 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:13:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:13:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:13:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:13:25 --> Config Class Initialized
INFO - 2024-02-12 20:13:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:13:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:13:25 --> Utf8 Class Initialized
INFO - 2024-02-12 20:13:25 --> URI Class Initialized
INFO - 2024-02-12 20:13:25 --> Router Class Initialized
INFO - 2024-02-12 20:13:25 --> Output Class Initialized
INFO - 2024-02-12 20:13:25 --> Security Class Initialized
DEBUG - 2024-02-12 20:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:13:25 --> Input Class Initialized
INFO - 2024-02-12 20:13:25 --> Language Class Initialized
INFO - 2024-02-12 20:13:25 --> Loader Class Initialized
INFO - 2024-02-12 20:13:25 --> Helper loaded: url_helper
INFO - 2024-02-12 20:13:25 --> Helper loaded: file_helper
INFO - 2024-02-12 20:13:25 --> Helper loaded: form_helper
INFO - 2024-02-12 20:13:25 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:13:25 --> Controller Class Initialized
INFO - 2024-02-12 20:13:25 --> Form Validation Class Initialized
INFO - 2024-02-12 20:13:25 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:13:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:13:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:13:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:13:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:13:25 --> Final output sent to browser
DEBUG - 2024-02-12 20:13:25 --> Total execution time: 0.0343
ERROR - 2024-02-12 20:14:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:14:03 --> Config Class Initialized
INFO - 2024-02-12 20:14:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:14:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:14:03 --> Utf8 Class Initialized
INFO - 2024-02-12 20:14:03 --> URI Class Initialized
INFO - 2024-02-12 20:14:03 --> Router Class Initialized
INFO - 2024-02-12 20:14:03 --> Output Class Initialized
INFO - 2024-02-12 20:14:03 --> Security Class Initialized
DEBUG - 2024-02-12 20:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:14:03 --> Input Class Initialized
INFO - 2024-02-12 20:14:03 --> Language Class Initialized
INFO - 2024-02-12 20:14:03 --> Loader Class Initialized
INFO - 2024-02-12 20:14:03 --> Helper loaded: url_helper
INFO - 2024-02-12 20:14:03 --> Helper loaded: file_helper
INFO - 2024-02-12 20:14:03 --> Helper loaded: form_helper
INFO - 2024-02-12 20:14:03 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:14:03 --> Controller Class Initialized
INFO - 2024-02-12 20:14:03 --> Form Validation Class Initialized
INFO - 2024-02-12 20:14:03 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:14:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:14:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:14:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:14:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:14:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:14:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:14:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:14:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:14:03 --> Final output sent to browser
DEBUG - 2024-02-12 20:14:03 --> Total execution time: 0.0264
ERROR - 2024-02-12 20:14:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:14:04 --> Config Class Initialized
INFO - 2024-02-12 20:14:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:14:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:14:04 --> Utf8 Class Initialized
INFO - 2024-02-12 20:14:04 --> URI Class Initialized
INFO - 2024-02-12 20:14:04 --> Router Class Initialized
INFO - 2024-02-12 20:14:04 --> Output Class Initialized
INFO - 2024-02-12 20:14:04 --> Security Class Initialized
DEBUG - 2024-02-12 20:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:14:04 --> Input Class Initialized
INFO - 2024-02-12 20:14:04 --> Language Class Initialized
INFO - 2024-02-12 20:14:04 --> Loader Class Initialized
INFO - 2024-02-12 20:14:04 --> Helper loaded: url_helper
INFO - 2024-02-12 20:14:04 --> Helper loaded: file_helper
INFO - 2024-02-12 20:14:04 --> Helper loaded: form_helper
INFO - 2024-02-12 20:14:04 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:14:04 --> Controller Class Initialized
INFO - 2024-02-12 20:14:04 --> Form Validation Class Initialized
INFO - 2024-02-12 20:14:04 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:14:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:14:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:14:04 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:14:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:14:06 --> Config Class Initialized
INFO - 2024-02-12 20:14:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:14:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:14:06 --> Utf8 Class Initialized
INFO - 2024-02-12 20:14:06 --> URI Class Initialized
INFO - 2024-02-12 20:14:06 --> Router Class Initialized
INFO - 2024-02-12 20:14:06 --> Output Class Initialized
INFO - 2024-02-12 20:14:06 --> Security Class Initialized
DEBUG - 2024-02-12 20:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:14:06 --> Input Class Initialized
INFO - 2024-02-12 20:14:06 --> Language Class Initialized
INFO - 2024-02-12 20:14:06 --> Loader Class Initialized
INFO - 2024-02-12 20:14:06 --> Helper loaded: url_helper
INFO - 2024-02-12 20:14:06 --> Helper loaded: file_helper
INFO - 2024-02-12 20:14:06 --> Helper loaded: form_helper
INFO - 2024-02-12 20:14:06 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:14:06 --> Controller Class Initialized
INFO - 2024-02-12 20:14:06 --> Form Validation Class Initialized
INFO - 2024-02-12 20:14:06 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:14:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:14:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:14:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:14:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:14:06 --> Final output sent to browser
DEBUG - 2024-02-12 20:14:06 --> Total execution time: 0.0337
ERROR - 2024-02-12 20:14:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:14:22 --> Config Class Initialized
INFO - 2024-02-12 20:14:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:14:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:14:22 --> Utf8 Class Initialized
INFO - 2024-02-12 20:14:22 --> URI Class Initialized
INFO - 2024-02-12 20:14:22 --> Router Class Initialized
INFO - 2024-02-12 20:14:22 --> Output Class Initialized
INFO - 2024-02-12 20:14:22 --> Security Class Initialized
DEBUG - 2024-02-12 20:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:14:22 --> Input Class Initialized
INFO - 2024-02-12 20:14:22 --> Language Class Initialized
INFO - 2024-02-12 20:14:22 --> Loader Class Initialized
INFO - 2024-02-12 20:14:22 --> Helper loaded: url_helper
INFO - 2024-02-12 20:14:22 --> Helper loaded: file_helper
INFO - 2024-02-12 20:14:22 --> Helper loaded: form_helper
INFO - 2024-02-12 20:14:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:14:22 --> Controller Class Initialized
INFO - 2024-02-12 20:14:22 --> Form Validation Class Initialized
INFO - 2024-02-12 20:14:22 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:14:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:14:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:14:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:14:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:14:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:14:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:14:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:14:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:14:22 --> Final output sent to browser
DEBUG - 2024-02-12 20:14:22 --> Total execution time: 0.0394
ERROR - 2024-02-12 20:14:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:14:22 --> Config Class Initialized
INFO - 2024-02-12 20:14:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:14:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:14:22 --> Utf8 Class Initialized
INFO - 2024-02-12 20:14:22 --> URI Class Initialized
INFO - 2024-02-12 20:14:22 --> Router Class Initialized
INFO - 2024-02-12 20:14:22 --> Output Class Initialized
INFO - 2024-02-12 20:14:22 --> Security Class Initialized
DEBUG - 2024-02-12 20:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:14:22 --> Input Class Initialized
INFO - 2024-02-12 20:14:22 --> Language Class Initialized
INFO - 2024-02-12 20:14:22 --> Loader Class Initialized
INFO - 2024-02-12 20:14:22 --> Helper loaded: url_helper
INFO - 2024-02-12 20:14:22 --> Helper loaded: file_helper
INFO - 2024-02-12 20:14:22 --> Helper loaded: form_helper
INFO - 2024-02-12 20:14:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:14:22 --> Controller Class Initialized
INFO - 2024-02-12 20:14:22 --> Form Validation Class Initialized
INFO - 2024-02-12 20:14:22 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:14:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:14:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:14:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:14:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:14:25 --> Config Class Initialized
INFO - 2024-02-12 20:14:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:14:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:14:25 --> Utf8 Class Initialized
INFO - 2024-02-12 20:14:25 --> URI Class Initialized
INFO - 2024-02-12 20:14:25 --> Router Class Initialized
INFO - 2024-02-12 20:14:25 --> Output Class Initialized
INFO - 2024-02-12 20:14:25 --> Security Class Initialized
DEBUG - 2024-02-12 20:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:14:25 --> Input Class Initialized
INFO - 2024-02-12 20:14:25 --> Language Class Initialized
INFO - 2024-02-12 20:14:25 --> Loader Class Initialized
INFO - 2024-02-12 20:14:25 --> Helper loaded: url_helper
INFO - 2024-02-12 20:14:25 --> Helper loaded: file_helper
INFO - 2024-02-12 20:14:25 --> Helper loaded: form_helper
INFO - 2024-02-12 20:14:25 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:14:25 --> Controller Class Initialized
INFO - 2024-02-12 20:14:25 --> Form Validation Class Initialized
INFO - 2024-02-12 20:14:25 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:14:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:14:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:14:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:14:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:14:25 --> Final output sent to browser
DEBUG - 2024-02-12 20:14:25 --> Total execution time: 0.0382
ERROR - 2024-02-12 20:15:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:15:03 --> Config Class Initialized
INFO - 2024-02-12 20:15:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:15:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:15:03 --> Utf8 Class Initialized
INFO - 2024-02-12 20:15:03 --> URI Class Initialized
INFO - 2024-02-12 20:15:03 --> Router Class Initialized
INFO - 2024-02-12 20:15:03 --> Output Class Initialized
INFO - 2024-02-12 20:15:03 --> Security Class Initialized
DEBUG - 2024-02-12 20:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:15:03 --> Input Class Initialized
INFO - 2024-02-12 20:15:03 --> Language Class Initialized
INFO - 2024-02-12 20:15:03 --> Loader Class Initialized
INFO - 2024-02-12 20:15:03 --> Helper loaded: url_helper
INFO - 2024-02-12 20:15:03 --> Helper loaded: file_helper
INFO - 2024-02-12 20:15:03 --> Helper loaded: form_helper
INFO - 2024-02-12 20:15:03 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:15:03 --> Controller Class Initialized
INFO - 2024-02-12 20:15:03 --> Form Validation Class Initialized
INFO - 2024-02-12 20:15:03 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:15:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:15:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:15:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:15:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:15:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:15:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:15:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:15:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:15:03 --> Final output sent to browser
DEBUG - 2024-02-12 20:15:03 --> Total execution time: 0.0338
ERROR - 2024-02-12 20:15:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:15:04 --> Config Class Initialized
INFO - 2024-02-12 20:15:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:15:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:15:04 --> Utf8 Class Initialized
INFO - 2024-02-12 20:15:04 --> URI Class Initialized
INFO - 2024-02-12 20:15:04 --> Router Class Initialized
INFO - 2024-02-12 20:15:04 --> Output Class Initialized
INFO - 2024-02-12 20:15:04 --> Security Class Initialized
DEBUG - 2024-02-12 20:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:15:04 --> Input Class Initialized
INFO - 2024-02-12 20:15:04 --> Language Class Initialized
INFO - 2024-02-12 20:15:04 --> Loader Class Initialized
INFO - 2024-02-12 20:15:04 --> Helper loaded: url_helper
INFO - 2024-02-12 20:15:04 --> Helper loaded: file_helper
INFO - 2024-02-12 20:15:04 --> Helper loaded: form_helper
INFO - 2024-02-12 20:15:04 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:15:04 --> Controller Class Initialized
INFO - 2024-02-12 20:15:04 --> Form Validation Class Initialized
INFO - 2024-02-12 20:15:04 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:15:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:15:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:15:04 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:15:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:15:07 --> Config Class Initialized
INFO - 2024-02-12 20:15:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:15:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:15:07 --> Utf8 Class Initialized
INFO - 2024-02-12 20:15:07 --> URI Class Initialized
INFO - 2024-02-12 20:15:07 --> Router Class Initialized
INFO - 2024-02-12 20:15:07 --> Output Class Initialized
INFO - 2024-02-12 20:15:07 --> Security Class Initialized
DEBUG - 2024-02-12 20:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:15:07 --> Input Class Initialized
INFO - 2024-02-12 20:15:07 --> Language Class Initialized
INFO - 2024-02-12 20:15:07 --> Loader Class Initialized
INFO - 2024-02-12 20:15:07 --> Helper loaded: url_helper
INFO - 2024-02-12 20:15:07 --> Helper loaded: file_helper
INFO - 2024-02-12 20:15:07 --> Helper loaded: form_helper
INFO - 2024-02-12 20:15:07 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:15:07 --> Controller Class Initialized
INFO - 2024-02-12 20:15:07 --> Form Validation Class Initialized
INFO - 2024-02-12 20:15:07 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:15:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:15:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:15:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:15:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:15:07 --> Final output sent to browser
DEBUG - 2024-02-12 20:15:07 --> Total execution time: 0.0503
ERROR - 2024-02-12 20:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:16:17 --> Config Class Initialized
INFO - 2024-02-12 20:16:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:16:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:16:17 --> Utf8 Class Initialized
INFO - 2024-02-12 20:16:17 --> URI Class Initialized
INFO - 2024-02-12 20:16:17 --> Router Class Initialized
INFO - 2024-02-12 20:16:17 --> Output Class Initialized
INFO - 2024-02-12 20:16:17 --> Security Class Initialized
DEBUG - 2024-02-12 20:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:16:17 --> Input Class Initialized
INFO - 2024-02-12 20:16:17 --> Language Class Initialized
INFO - 2024-02-12 20:16:17 --> Loader Class Initialized
INFO - 2024-02-12 20:16:17 --> Helper loaded: url_helper
INFO - 2024-02-12 20:16:17 --> Helper loaded: file_helper
INFO - 2024-02-12 20:16:17 --> Helper loaded: form_helper
INFO - 2024-02-12 20:16:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:16:17 --> Controller Class Initialized
INFO - 2024-02-12 20:16:17 --> Form Validation Class Initialized
INFO - 2024-02-12 20:16:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:16:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:16:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:16:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:16:17 --> Final output sent to browser
DEBUG - 2024-02-12 20:16:17 --> Total execution time: 0.0310
ERROR - 2024-02-12 20:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:16:17 --> Config Class Initialized
INFO - 2024-02-12 20:16:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:16:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:16:17 --> Utf8 Class Initialized
INFO - 2024-02-12 20:16:17 --> URI Class Initialized
INFO - 2024-02-12 20:16:17 --> Router Class Initialized
INFO - 2024-02-12 20:16:17 --> Output Class Initialized
INFO - 2024-02-12 20:16:17 --> Security Class Initialized
DEBUG - 2024-02-12 20:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:16:17 --> Input Class Initialized
INFO - 2024-02-12 20:16:17 --> Language Class Initialized
INFO - 2024-02-12 20:16:17 --> Loader Class Initialized
INFO - 2024-02-12 20:16:17 --> Helper loaded: url_helper
INFO - 2024-02-12 20:16:17 --> Helper loaded: file_helper
INFO - 2024-02-12 20:16:17 --> Helper loaded: form_helper
INFO - 2024-02-12 20:16:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:16:17 --> Controller Class Initialized
INFO - 2024-02-12 20:16:17 --> Form Validation Class Initialized
INFO - 2024-02-12 20:16:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:16:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:16:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:16:17 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:16:20 --> Config Class Initialized
INFO - 2024-02-12 20:16:20 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:16:20 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:16:20 --> Utf8 Class Initialized
INFO - 2024-02-12 20:16:20 --> URI Class Initialized
INFO - 2024-02-12 20:16:20 --> Router Class Initialized
INFO - 2024-02-12 20:16:20 --> Output Class Initialized
INFO - 2024-02-12 20:16:20 --> Security Class Initialized
DEBUG - 2024-02-12 20:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:16:20 --> Input Class Initialized
INFO - 2024-02-12 20:16:20 --> Language Class Initialized
INFO - 2024-02-12 20:16:20 --> Loader Class Initialized
INFO - 2024-02-12 20:16:20 --> Helper loaded: url_helper
INFO - 2024-02-12 20:16:20 --> Helper loaded: file_helper
INFO - 2024-02-12 20:16:20 --> Helper loaded: form_helper
INFO - 2024-02-12 20:16:20 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:16:20 --> Controller Class Initialized
INFO - 2024-02-12 20:16:20 --> Form Validation Class Initialized
INFO - 2024-02-12 20:16:20 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:16:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:16:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:16:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:16:20 --> Final output sent to browser
DEBUG - 2024-02-12 20:16:20 --> Total execution time: 0.0307
ERROR - 2024-02-12 20:16:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:16:53 --> Config Class Initialized
INFO - 2024-02-12 20:16:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:16:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:16:53 --> Utf8 Class Initialized
INFO - 2024-02-12 20:16:53 --> URI Class Initialized
INFO - 2024-02-12 20:16:53 --> Router Class Initialized
INFO - 2024-02-12 20:16:53 --> Output Class Initialized
INFO - 2024-02-12 20:16:53 --> Security Class Initialized
DEBUG - 2024-02-12 20:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:16:53 --> Input Class Initialized
INFO - 2024-02-12 20:16:53 --> Language Class Initialized
INFO - 2024-02-12 20:16:53 --> Loader Class Initialized
INFO - 2024-02-12 20:16:53 --> Helper loaded: url_helper
INFO - 2024-02-12 20:16:53 --> Helper loaded: file_helper
INFO - 2024-02-12 20:16:53 --> Helper loaded: form_helper
INFO - 2024-02-12 20:16:53 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:16:53 --> Controller Class Initialized
INFO - 2024-02-12 20:16:53 --> Form Validation Class Initialized
INFO - 2024-02-12 20:16:53 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:16:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:16:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:16:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:16:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:16:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:16:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:16:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:16:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:16:53 --> Final output sent to browser
DEBUG - 2024-02-12 20:16:53 --> Total execution time: 0.0274
ERROR - 2024-02-12 20:16:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:16:54 --> Config Class Initialized
INFO - 2024-02-12 20:16:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:16:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:16:54 --> Utf8 Class Initialized
INFO - 2024-02-12 20:16:54 --> URI Class Initialized
INFO - 2024-02-12 20:16:54 --> Router Class Initialized
INFO - 2024-02-12 20:16:54 --> Output Class Initialized
INFO - 2024-02-12 20:16:54 --> Security Class Initialized
DEBUG - 2024-02-12 20:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:16:54 --> Input Class Initialized
INFO - 2024-02-12 20:16:54 --> Language Class Initialized
INFO - 2024-02-12 20:16:54 --> Loader Class Initialized
INFO - 2024-02-12 20:16:54 --> Helper loaded: url_helper
INFO - 2024-02-12 20:16:54 --> Helper loaded: file_helper
INFO - 2024-02-12 20:16:54 --> Helper loaded: form_helper
INFO - 2024-02-12 20:16:54 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:16:54 --> Controller Class Initialized
INFO - 2024-02-12 20:16:54 --> Form Validation Class Initialized
INFO - 2024-02-12 20:16:54 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:16:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:16:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:16:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:16:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:16:57 --> Config Class Initialized
INFO - 2024-02-12 20:16:57 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:16:57 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:16:57 --> Utf8 Class Initialized
INFO - 2024-02-12 20:16:57 --> URI Class Initialized
INFO - 2024-02-12 20:16:57 --> Router Class Initialized
INFO - 2024-02-12 20:16:57 --> Output Class Initialized
INFO - 2024-02-12 20:16:57 --> Security Class Initialized
DEBUG - 2024-02-12 20:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:16:57 --> Input Class Initialized
INFO - 2024-02-12 20:16:57 --> Language Class Initialized
INFO - 2024-02-12 20:16:57 --> Loader Class Initialized
INFO - 2024-02-12 20:16:57 --> Helper loaded: url_helper
INFO - 2024-02-12 20:16:57 --> Helper loaded: file_helper
INFO - 2024-02-12 20:16:57 --> Helper loaded: form_helper
INFO - 2024-02-12 20:16:57 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:16:57 --> Controller Class Initialized
INFO - 2024-02-12 20:16:57 --> Form Validation Class Initialized
INFO - 2024-02-12 20:16:57 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:16:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:16:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:16:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:16:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:16:57 --> Final output sent to browser
DEBUG - 2024-02-12 20:16:57 --> Total execution time: 0.0433
ERROR - 2024-02-12 20:18:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:18:33 --> Config Class Initialized
INFO - 2024-02-12 20:18:33 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:18:33 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:18:33 --> Utf8 Class Initialized
INFO - 2024-02-12 20:18:33 --> URI Class Initialized
INFO - 2024-02-12 20:18:33 --> Router Class Initialized
INFO - 2024-02-12 20:18:33 --> Output Class Initialized
INFO - 2024-02-12 20:18:33 --> Security Class Initialized
DEBUG - 2024-02-12 20:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:18:33 --> Input Class Initialized
INFO - 2024-02-12 20:18:33 --> Language Class Initialized
INFO - 2024-02-12 20:18:33 --> Loader Class Initialized
INFO - 2024-02-12 20:18:33 --> Helper loaded: url_helper
INFO - 2024-02-12 20:18:33 --> Helper loaded: file_helper
INFO - 2024-02-12 20:18:33 --> Helper loaded: form_helper
INFO - 2024-02-12 20:18:33 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:18:33 --> Controller Class Initialized
INFO - 2024-02-12 20:18:33 --> Form Validation Class Initialized
INFO - 2024-02-12 20:18:33 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:18:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:18:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:18:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:18:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:18:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:18:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:18:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:18:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:18:33 --> Final output sent to browser
DEBUG - 2024-02-12 20:18:33 --> Total execution time: 0.0301
ERROR - 2024-02-12 20:18:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:18:34 --> Config Class Initialized
INFO - 2024-02-12 20:18:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:18:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:18:34 --> Utf8 Class Initialized
INFO - 2024-02-12 20:18:34 --> URI Class Initialized
INFO - 2024-02-12 20:18:34 --> Router Class Initialized
INFO - 2024-02-12 20:18:34 --> Output Class Initialized
INFO - 2024-02-12 20:18:34 --> Security Class Initialized
DEBUG - 2024-02-12 20:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:18:34 --> Input Class Initialized
INFO - 2024-02-12 20:18:34 --> Language Class Initialized
INFO - 2024-02-12 20:18:34 --> Loader Class Initialized
INFO - 2024-02-12 20:18:34 --> Helper loaded: url_helper
INFO - 2024-02-12 20:18:34 --> Helper loaded: file_helper
INFO - 2024-02-12 20:18:34 --> Helper loaded: form_helper
INFO - 2024-02-12 20:18:34 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:18:34 --> Controller Class Initialized
INFO - 2024-02-12 20:18:34 --> Form Validation Class Initialized
INFO - 2024-02-12 20:18:34 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:18:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:18:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:18:34 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:18:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:18:35 --> Config Class Initialized
INFO - 2024-02-12 20:18:35 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:18:35 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:18:35 --> Utf8 Class Initialized
INFO - 2024-02-12 20:18:35 --> URI Class Initialized
INFO - 2024-02-12 20:18:35 --> Router Class Initialized
INFO - 2024-02-12 20:18:35 --> Output Class Initialized
INFO - 2024-02-12 20:18:35 --> Security Class Initialized
DEBUG - 2024-02-12 20:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:18:35 --> Input Class Initialized
INFO - 2024-02-12 20:18:35 --> Language Class Initialized
INFO - 2024-02-12 20:18:35 --> Loader Class Initialized
INFO - 2024-02-12 20:18:35 --> Helper loaded: url_helper
INFO - 2024-02-12 20:18:35 --> Helper loaded: file_helper
INFO - 2024-02-12 20:18:35 --> Helper loaded: form_helper
INFO - 2024-02-12 20:18:35 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:18:35 --> Controller Class Initialized
INFO - 2024-02-12 20:18:36 --> Form Validation Class Initialized
INFO - 2024-02-12 20:18:36 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:18:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:18:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:18:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:18:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:18:36 --> Final output sent to browser
DEBUG - 2024-02-12 20:18:36 --> Total execution time: 0.0402
ERROR - 2024-02-12 20:20:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:20:39 --> Config Class Initialized
INFO - 2024-02-12 20:20:39 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:20:39 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:20:39 --> Utf8 Class Initialized
INFO - 2024-02-12 20:20:39 --> URI Class Initialized
INFO - 2024-02-12 20:20:39 --> Router Class Initialized
INFO - 2024-02-12 20:20:39 --> Output Class Initialized
INFO - 2024-02-12 20:20:39 --> Security Class Initialized
DEBUG - 2024-02-12 20:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:20:39 --> Input Class Initialized
INFO - 2024-02-12 20:20:39 --> Language Class Initialized
INFO - 2024-02-12 20:20:39 --> Loader Class Initialized
INFO - 2024-02-12 20:20:39 --> Helper loaded: url_helper
INFO - 2024-02-12 20:20:39 --> Helper loaded: file_helper
INFO - 2024-02-12 20:20:39 --> Helper loaded: form_helper
INFO - 2024-02-12 20:20:39 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:20:39 --> Controller Class Initialized
INFO - 2024-02-12 20:20:39 --> Form Validation Class Initialized
INFO - 2024-02-12 20:20:39 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:20:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:20:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:20:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:20:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:20:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:20:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:20:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:20:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:20:39 --> Final output sent to browser
DEBUG - 2024-02-12 20:20:39 --> Total execution time: 0.0294
ERROR - 2024-02-12 20:20:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:20:40 --> Config Class Initialized
INFO - 2024-02-12 20:20:40 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:20:40 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:20:40 --> Utf8 Class Initialized
INFO - 2024-02-12 20:20:40 --> URI Class Initialized
INFO - 2024-02-12 20:20:40 --> Router Class Initialized
INFO - 2024-02-12 20:20:40 --> Output Class Initialized
INFO - 2024-02-12 20:20:40 --> Security Class Initialized
DEBUG - 2024-02-12 20:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:20:40 --> Input Class Initialized
INFO - 2024-02-12 20:20:40 --> Language Class Initialized
INFO - 2024-02-12 20:20:40 --> Loader Class Initialized
INFO - 2024-02-12 20:20:40 --> Helper loaded: url_helper
INFO - 2024-02-12 20:20:40 --> Helper loaded: file_helper
INFO - 2024-02-12 20:20:40 --> Helper loaded: form_helper
INFO - 2024-02-12 20:20:40 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:20:40 --> Controller Class Initialized
INFO - 2024-02-12 20:20:40 --> Form Validation Class Initialized
INFO - 2024-02-12 20:20:40 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:20:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:20:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:20:40 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:20:42 --> Config Class Initialized
INFO - 2024-02-12 20:20:42 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:20:42 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:20:42 --> Utf8 Class Initialized
INFO - 2024-02-12 20:20:42 --> URI Class Initialized
INFO - 2024-02-12 20:20:42 --> Router Class Initialized
INFO - 2024-02-12 20:20:42 --> Output Class Initialized
INFO - 2024-02-12 20:20:42 --> Security Class Initialized
DEBUG - 2024-02-12 20:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:20:42 --> Input Class Initialized
INFO - 2024-02-12 20:20:42 --> Language Class Initialized
INFO - 2024-02-12 20:20:42 --> Loader Class Initialized
INFO - 2024-02-12 20:20:42 --> Helper loaded: url_helper
INFO - 2024-02-12 20:20:42 --> Helper loaded: file_helper
INFO - 2024-02-12 20:20:42 --> Helper loaded: form_helper
INFO - 2024-02-12 20:20:42 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:20:42 --> Controller Class Initialized
INFO - 2024-02-12 20:20:42 --> Form Validation Class Initialized
INFO - 2024-02-12 20:20:42 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:20:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:20:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:20:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:20:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:20:42 --> Final output sent to browser
DEBUG - 2024-02-12 20:20:42 --> Total execution time: 0.0352
ERROR - 2024-02-12 20:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:21:19 --> Config Class Initialized
INFO - 2024-02-12 20:21:19 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:21:19 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:21:19 --> Utf8 Class Initialized
INFO - 2024-02-12 20:21:19 --> URI Class Initialized
INFO - 2024-02-12 20:21:19 --> Router Class Initialized
INFO - 2024-02-12 20:21:19 --> Output Class Initialized
INFO - 2024-02-12 20:21:19 --> Security Class Initialized
DEBUG - 2024-02-12 20:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:21:19 --> Input Class Initialized
INFO - 2024-02-12 20:21:19 --> Language Class Initialized
INFO - 2024-02-12 20:21:19 --> Loader Class Initialized
INFO - 2024-02-12 20:21:19 --> Helper loaded: url_helper
INFO - 2024-02-12 20:21:19 --> Helper loaded: file_helper
INFO - 2024-02-12 20:21:19 --> Helper loaded: form_helper
INFO - 2024-02-12 20:21:19 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:21:19 --> Controller Class Initialized
INFO - 2024-02-12 20:21:19 --> Form Validation Class Initialized
INFO - 2024-02-12 20:21:19 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:21:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:21:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:21:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:21:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:21:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:21:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:21:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:21:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:21:19 --> Final output sent to browser
DEBUG - 2024-02-12 20:21:19 --> Total execution time: 0.0264
ERROR - 2024-02-12 20:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:21:19 --> Config Class Initialized
INFO - 2024-02-12 20:21:19 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:21:19 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:21:19 --> Utf8 Class Initialized
INFO - 2024-02-12 20:21:19 --> URI Class Initialized
INFO - 2024-02-12 20:21:19 --> Router Class Initialized
INFO - 2024-02-12 20:21:19 --> Output Class Initialized
INFO - 2024-02-12 20:21:19 --> Security Class Initialized
DEBUG - 2024-02-12 20:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:21:19 --> Input Class Initialized
INFO - 2024-02-12 20:21:19 --> Language Class Initialized
INFO - 2024-02-12 20:21:19 --> Loader Class Initialized
INFO - 2024-02-12 20:21:19 --> Helper loaded: url_helper
INFO - 2024-02-12 20:21:19 --> Helper loaded: file_helper
INFO - 2024-02-12 20:21:19 --> Helper loaded: form_helper
INFO - 2024-02-12 20:21:19 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:21:19 --> Controller Class Initialized
INFO - 2024-02-12 20:21:19 --> Form Validation Class Initialized
INFO - 2024-02-12 20:21:19 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:21:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:21:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:21:19 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:21:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:21:21 --> Config Class Initialized
INFO - 2024-02-12 20:21:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:21:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:21:21 --> Utf8 Class Initialized
INFO - 2024-02-12 20:21:21 --> URI Class Initialized
INFO - 2024-02-12 20:21:21 --> Router Class Initialized
INFO - 2024-02-12 20:21:21 --> Output Class Initialized
INFO - 2024-02-12 20:21:21 --> Security Class Initialized
DEBUG - 2024-02-12 20:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:21:21 --> Input Class Initialized
INFO - 2024-02-12 20:21:21 --> Language Class Initialized
INFO - 2024-02-12 20:21:21 --> Loader Class Initialized
INFO - 2024-02-12 20:21:21 --> Helper loaded: url_helper
INFO - 2024-02-12 20:21:21 --> Helper loaded: file_helper
INFO - 2024-02-12 20:21:21 --> Helper loaded: form_helper
INFO - 2024-02-12 20:21:21 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:21:21 --> Controller Class Initialized
INFO - 2024-02-12 20:21:21 --> Form Validation Class Initialized
INFO - 2024-02-12 20:21:21 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:21:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:21:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:21:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:21:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:21:21 --> Final output sent to browser
DEBUG - 2024-02-12 20:21:21 --> Total execution time: 0.0263
ERROR - 2024-02-12 20:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:21:58 --> Config Class Initialized
INFO - 2024-02-12 20:21:58 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:21:58 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:21:58 --> Utf8 Class Initialized
INFO - 2024-02-12 20:21:58 --> URI Class Initialized
INFO - 2024-02-12 20:21:58 --> Router Class Initialized
INFO - 2024-02-12 20:21:58 --> Output Class Initialized
INFO - 2024-02-12 20:21:58 --> Security Class Initialized
DEBUG - 2024-02-12 20:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:21:58 --> Input Class Initialized
INFO - 2024-02-12 20:21:58 --> Language Class Initialized
INFO - 2024-02-12 20:21:58 --> Loader Class Initialized
INFO - 2024-02-12 20:21:58 --> Helper loaded: url_helper
INFO - 2024-02-12 20:21:58 --> Helper loaded: file_helper
INFO - 2024-02-12 20:21:58 --> Helper loaded: form_helper
INFO - 2024-02-12 20:21:58 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:21:58 --> Controller Class Initialized
INFO - 2024-02-12 20:21:58 --> Form Validation Class Initialized
INFO - 2024-02-12 20:21:58 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:21:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:21:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:21:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:21:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:21:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:21:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:21:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:21:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:21:58 --> Final output sent to browser
DEBUG - 2024-02-12 20:21:58 --> Total execution time: 0.0232
ERROR - 2024-02-12 20:21:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:21:59 --> Config Class Initialized
INFO - 2024-02-12 20:21:59 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:21:59 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:21:59 --> Utf8 Class Initialized
INFO - 2024-02-12 20:21:59 --> URI Class Initialized
INFO - 2024-02-12 20:21:59 --> Router Class Initialized
INFO - 2024-02-12 20:21:59 --> Output Class Initialized
INFO - 2024-02-12 20:21:59 --> Security Class Initialized
DEBUG - 2024-02-12 20:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:21:59 --> Input Class Initialized
INFO - 2024-02-12 20:21:59 --> Language Class Initialized
INFO - 2024-02-12 20:21:59 --> Loader Class Initialized
INFO - 2024-02-12 20:21:59 --> Helper loaded: url_helper
INFO - 2024-02-12 20:21:59 --> Helper loaded: file_helper
INFO - 2024-02-12 20:21:59 --> Helper loaded: form_helper
INFO - 2024-02-12 20:21:59 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:21:59 --> Controller Class Initialized
INFO - 2024-02-12 20:21:59 --> Form Validation Class Initialized
INFO - 2024-02-12 20:21:59 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:21:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:21:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:21:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:22:01 --> Config Class Initialized
INFO - 2024-02-12 20:22:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:22:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:22:01 --> Utf8 Class Initialized
INFO - 2024-02-12 20:22:01 --> URI Class Initialized
INFO - 2024-02-12 20:22:01 --> Router Class Initialized
INFO - 2024-02-12 20:22:01 --> Output Class Initialized
INFO - 2024-02-12 20:22:01 --> Security Class Initialized
DEBUG - 2024-02-12 20:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:22:01 --> Input Class Initialized
INFO - 2024-02-12 20:22:01 --> Language Class Initialized
INFO - 2024-02-12 20:22:01 --> Loader Class Initialized
INFO - 2024-02-12 20:22:01 --> Helper loaded: url_helper
INFO - 2024-02-12 20:22:01 --> Helper loaded: file_helper
INFO - 2024-02-12 20:22:01 --> Helper loaded: form_helper
INFO - 2024-02-12 20:22:01 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:22:01 --> Controller Class Initialized
INFO - 2024-02-12 20:22:01 --> Form Validation Class Initialized
INFO - 2024-02-12 20:22:01 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:22:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:22:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:22:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:22:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:22:01 --> Final output sent to browser
DEBUG - 2024-02-12 20:22:01 --> Total execution time: 0.0308
ERROR - 2024-02-12 20:22:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:22:45 --> Config Class Initialized
INFO - 2024-02-12 20:22:45 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:22:45 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:22:45 --> Utf8 Class Initialized
INFO - 2024-02-12 20:22:45 --> URI Class Initialized
INFO - 2024-02-12 20:22:45 --> Router Class Initialized
INFO - 2024-02-12 20:22:45 --> Output Class Initialized
INFO - 2024-02-12 20:22:45 --> Security Class Initialized
DEBUG - 2024-02-12 20:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:22:45 --> Input Class Initialized
INFO - 2024-02-12 20:22:45 --> Language Class Initialized
INFO - 2024-02-12 20:22:45 --> Loader Class Initialized
INFO - 2024-02-12 20:22:45 --> Helper loaded: url_helper
INFO - 2024-02-12 20:22:45 --> Helper loaded: file_helper
INFO - 2024-02-12 20:22:45 --> Helper loaded: form_helper
INFO - 2024-02-12 20:22:45 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:22:45 --> Controller Class Initialized
INFO - 2024-02-12 20:22:45 --> Form Validation Class Initialized
INFO - 2024-02-12 20:22:45 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:22:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:22:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:22:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:22:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:22:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:22:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:22:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:22:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:22:45 --> Final output sent to browser
DEBUG - 2024-02-12 20:22:45 --> Total execution time: 0.0267
ERROR - 2024-02-12 20:22:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:22:45 --> Config Class Initialized
INFO - 2024-02-12 20:22:45 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:22:45 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:22:45 --> Utf8 Class Initialized
INFO - 2024-02-12 20:22:45 --> URI Class Initialized
INFO - 2024-02-12 20:22:45 --> Router Class Initialized
INFO - 2024-02-12 20:22:45 --> Output Class Initialized
INFO - 2024-02-12 20:22:45 --> Security Class Initialized
DEBUG - 2024-02-12 20:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:22:46 --> Input Class Initialized
INFO - 2024-02-12 20:22:46 --> Language Class Initialized
INFO - 2024-02-12 20:22:46 --> Loader Class Initialized
INFO - 2024-02-12 20:22:46 --> Helper loaded: url_helper
INFO - 2024-02-12 20:22:46 --> Helper loaded: file_helper
INFO - 2024-02-12 20:22:46 --> Helper loaded: form_helper
INFO - 2024-02-12 20:22:46 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:22:46 --> Controller Class Initialized
INFO - 2024-02-12 20:22:46 --> Form Validation Class Initialized
INFO - 2024-02-12 20:22:46 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:22:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:22:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:22:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:22:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:22:48 --> Config Class Initialized
INFO - 2024-02-12 20:22:48 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:22:48 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:22:48 --> Utf8 Class Initialized
INFO - 2024-02-12 20:22:48 --> URI Class Initialized
INFO - 2024-02-12 20:22:48 --> Router Class Initialized
INFO - 2024-02-12 20:22:48 --> Output Class Initialized
INFO - 2024-02-12 20:22:48 --> Security Class Initialized
DEBUG - 2024-02-12 20:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:22:48 --> Input Class Initialized
INFO - 2024-02-12 20:22:48 --> Language Class Initialized
INFO - 2024-02-12 20:22:48 --> Loader Class Initialized
INFO - 2024-02-12 20:22:48 --> Helper loaded: url_helper
INFO - 2024-02-12 20:22:48 --> Helper loaded: file_helper
INFO - 2024-02-12 20:22:48 --> Helper loaded: form_helper
INFO - 2024-02-12 20:22:48 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:22:48 --> Controller Class Initialized
INFO - 2024-02-12 20:22:48 --> Form Validation Class Initialized
INFO - 2024-02-12 20:22:48 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:22:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:22:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:22:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:22:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:22:48 --> Final output sent to browser
DEBUG - 2024-02-12 20:22:48 --> Total execution time: 0.0290
ERROR - 2024-02-12 20:23:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:23:38 --> Config Class Initialized
INFO - 2024-02-12 20:23:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:23:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:23:38 --> Utf8 Class Initialized
INFO - 2024-02-12 20:23:38 --> URI Class Initialized
INFO - 2024-02-12 20:23:38 --> Router Class Initialized
INFO - 2024-02-12 20:23:38 --> Output Class Initialized
INFO - 2024-02-12 20:23:38 --> Security Class Initialized
DEBUG - 2024-02-12 20:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:23:38 --> Input Class Initialized
INFO - 2024-02-12 20:23:38 --> Language Class Initialized
INFO - 2024-02-12 20:23:38 --> Loader Class Initialized
INFO - 2024-02-12 20:23:38 --> Helper loaded: url_helper
INFO - 2024-02-12 20:23:38 --> Helper loaded: file_helper
INFO - 2024-02-12 20:23:38 --> Helper loaded: form_helper
INFO - 2024-02-12 20:23:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:23:38 --> Controller Class Initialized
INFO - 2024-02-12 20:23:38 --> Form Validation Class Initialized
INFO - 2024-02-12 20:23:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:23:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:23:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:23:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:23:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:23:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:23:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:23:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:23:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:23:38 --> Final output sent to browser
DEBUG - 2024-02-12 20:23:38 --> Total execution time: 0.0281
ERROR - 2024-02-12 20:23:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:23:38 --> Config Class Initialized
INFO - 2024-02-12 20:23:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:23:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:23:38 --> Utf8 Class Initialized
INFO - 2024-02-12 20:23:38 --> URI Class Initialized
INFO - 2024-02-12 20:23:38 --> Router Class Initialized
INFO - 2024-02-12 20:23:38 --> Output Class Initialized
INFO - 2024-02-12 20:23:38 --> Security Class Initialized
DEBUG - 2024-02-12 20:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:23:38 --> Input Class Initialized
INFO - 2024-02-12 20:23:38 --> Language Class Initialized
INFO - 2024-02-12 20:23:38 --> Loader Class Initialized
INFO - 2024-02-12 20:23:38 --> Helper loaded: url_helper
INFO - 2024-02-12 20:23:38 --> Helper loaded: file_helper
INFO - 2024-02-12 20:23:38 --> Helper loaded: form_helper
INFO - 2024-02-12 20:23:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:23:38 --> Controller Class Initialized
INFO - 2024-02-12 20:23:38 --> Form Validation Class Initialized
INFO - 2024-02-12 20:23:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:23:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:23:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:23:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:23:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:23:41 --> Config Class Initialized
INFO - 2024-02-12 20:23:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:23:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:23:41 --> Utf8 Class Initialized
INFO - 2024-02-12 20:23:41 --> URI Class Initialized
INFO - 2024-02-12 20:23:41 --> Router Class Initialized
INFO - 2024-02-12 20:23:41 --> Output Class Initialized
INFO - 2024-02-12 20:23:41 --> Security Class Initialized
DEBUG - 2024-02-12 20:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:23:41 --> Input Class Initialized
INFO - 2024-02-12 20:23:41 --> Language Class Initialized
INFO - 2024-02-12 20:23:41 --> Loader Class Initialized
INFO - 2024-02-12 20:23:41 --> Helper loaded: url_helper
INFO - 2024-02-12 20:23:41 --> Helper loaded: file_helper
INFO - 2024-02-12 20:23:41 --> Helper loaded: form_helper
INFO - 2024-02-12 20:23:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:23:41 --> Controller Class Initialized
INFO - 2024-02-12 20:23:41 --> Form Validation Class Initialized
INFO - 2024-02-12 20:23:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:23:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:23:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:23:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:23:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:23:41 --> Final output sent to browser
DEBUG - 2024-02-12 20:23:41 --> Total execution time: 0.0432
ERROR - 2024-02-12 20:24:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:24:52 --> Config Class Initialized
INFO - 2024-02-12 20:24:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:24:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:24:52 --> Utf8 Class Initialized
INFO - 2024-02-12 20:24:52 --> URI Class Initialized
INFO - 2024-02-12 20:24:52 --> Router Class Initialized
INFO - 2024-02-12 20:24:52 --> Output Class Initialized
INFO - 2024-02-12 20:24:52 --> Security Class Initialized
DEBUG - 2024-02-12 20:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:24:52 --> Input Class Initialized
INFO - 2024-02-12 20:24:52 --> Language Class Initialized
INFO - 2024-02-12 20:24:52 --> Loader Class Initialized
INFO - 2024-02-12 20:24:52 --> Helper loaded: url_helper
INFO - 2024-02-12 20:24:52 --> Helper loaded: file_helper
INFO - 2024-02-12 20:24:52 --> Helper loaded: form_helper
INFO - 2024-02-12 20:24:52 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:24:52 --> Controller Class Initialized
INFO - 2024-02-12 20:24:52 --> Form Validation Class Initialized
INFO - 2024-02-12 20:24:52 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:24:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:24:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:24:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:24:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:24:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:24:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:24:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:24:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:24:52 --> Final output sent to browser
DEBUG - 2024-02-12 20:24:52 --> Total execution time: 0.0269
ERROR - 2024-02-12 20:24:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:24:52 --> Config Class Initialized
INFO - 2024-02-12 20:24:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:24:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:24:52 --> Utf8 Class Initialized
INFO - 2024-02-12 20:24:52 --> URI Class Initialized
INFO - 2024-02-12 20:24:52 --> Router Class Initialized
INFO - 2024-02-12 20:24:52 --> Output Class Initialized
INFO - 2024-02-12 20:24:52 --> Security Class Initialized
DEBUG - 2024-02-12 20:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:24:52 --> Input Class Initialized
INFO - 2024-02-12 20:24:52 --> Language Class Initialized
INFO - 2024-02-12 20:24:52 --> Loader Class Initialized
INFO - 2024-02-12 20:24:52 --> Helper loaded: url_helper
INFO - 2024-02-12 20:24:52 --> Helper loaded: file_helper
INFO - 2024-02-12 20:24:52 --> Helper loaded: form_helper
INFO - 2024-02-12 20:24:52 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:24:52 --> Controller Class Initialized
INFO - 2024-02-12 20:24:52 --> Form Validation Class Initialized
INFO - 2024-02-12 20:24:52 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:24:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:24:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:24:52 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:24:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:24:54 --> Config Class Initialized
INFO - 2024-02-12 20:24:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:24:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:24:54 --> Utf8 Class Initialized
INFO - 2024-02-12 20:24:54 --> URI Class Initialized
INFO - 2024-02-12 20:24:54 --> Router Class Initialized
INFO - 2024-02-12 20:24:54 --> Output Class Initialized
INFO - 2024-02-12 20:24:54 --> Security Class Initialized
DEBUG - 2024-02-12 20:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:24:54 --> Input Class Initialized
INFO - 2024-02-12 20:24:54 --> Language Class Initialized
INFO - 2024-02-12 20:24:54 --> Loader Class Initialized
INFO - 2024-02-12 20:24:54 --> Helper loaded: url_helper
INFO - 2024-02-12 20:24:54 --> Helper loaded: file_helper
INFO - 2024-02-12 20:24:54 --> Helper loaded: form_helper
INFO - 2024-02-12 20:24:54 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:24:54 --> Controller Class Initialized
INFO - 2024-02-12 20:24:54 --> Form Validation Class Initialized
INFO - 2024-02-12 20:24:54 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:24:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:24:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:24:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:24:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:24:54 --> Final output sent to browser
DEBUG - 2024-02-12 20:24:54 --> Total execution time: 0.0359
ERROR - 2024-02-12 20:26:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:26:24 --> Config Class Initialized
INFO - 2024-02-12 20:26:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:26:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:26:24 --> Utf8 Class Initialized
INFO - 2024-02-12 20:26:24 --> URI Class Initialized
INFO - 2024-02-12 20:26:24 --> Router Class Initialized
INFO - 2024-02-12 20:26:24 --> Output Class Initialized
INFO - 2024-02-12 20:26:24 --> Security Class Initialized
DEBUG - 2024-02-12 20:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:26:24 --> Input Class Initialized
INFO - 2024-02-12 20:26:24 --> Language Class Initialized
INFO - 2024-02-12 20:26:24 --> Loader Class Initialized
INFO - 2024-02-12 20:26:24 --> Helper loaded: url_helper
INFO - 2024-02-12 20:26:24 --> Helper loaded: file_helper
INFO - 2024-02-12 20:26:24 --> Helper loaded: form_helper
INFO - 2024-02-12 20:26:24 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:26:24 --> Controller Class Initialized
INFO - 2024-02-12 20:26:24 --> Form Validation Class Initialized
INFO - 2024-02-12 20:26:24 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:26:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:26:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:26:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:26:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:26:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:26:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:26:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:26:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:26:24 --> Final output sent to browser
DEBUG - 2024-02-12 20:26:24 --> Total execution time: 0.0323
ERROR - 2024-02-12 20:26:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:26:25 --> Config Class Initialized
INFO - 2024-02-12 20:26:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:26:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:26:25 --> Utf8 Class Initialized
INFO - 2024-02-12 20:26:25 --> URI Class Initialized
INFO - 2024-02-12 20:26:25 --> Router Class Initialized
INFO - 2024-02-12 20:26:25 --> Output Class Initialized
INFO - 2024-02-12 20:26:25 --> Security Class Initialized
DEBUG - 2024-02-12 20:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:26:25 --> Input Class Initialized
INFO - 2024-02-12 20:26:25 --> Language Class Initialized
INFO - 2024-02-12 20:26:25 --> Loader Class Initialized
INFO - 2024-02-12 20:26:25 --> Helper loaded: url_helper
INFO - 2024-02-12 20:26:25 --> Helper loaded: file_helper
INFO - 2024-02-12 20:26:25 --> Helper loaded: form_helper
INFO - 2024-02-12 20:26:25 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:26:25 --> Controller Class Initialized
INFO - 2024-02-12 20:26:25 --> Form Validation Class Initialized
INFO - 2024-02-12 20:26:25 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:26:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:26:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:26:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:26:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:26:27 --> Config Class Initialized
INFO - 2024-02-12 20:26:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:26:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:26:27 --> Utf8 Class Initialized
INFO - 2024-02-12 20:26:27 --> URI Class Initialized
INFO - 2024-02-12 20:26:27 --> Router Class Initialized
INFO - 2024-02-12 20:26:27 --> Output Class Initialized
INFO - 2024-02-12 20:26:27 --> Security Class Initialized
DEBUG - 2024-02-12 20:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:26:27 --> Input Class Initialized
INFO - 2024-02-12 20:26:27 --> Language Class Initialized
INFO - 2024-02-12 20:26:27 --> Loader Class Initialized
INFO - 2024-02-12 20:26:27 --> Helper loaded: url_helper
INFO - 2024-02-12 20:26:27 --> Helper loaded: file_helper
INFO - 2024-02-12 20:26:27 --> Helper loaded: form_helper
INFO - 2024-02-12 20:26:27 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:26:27 --> Controller Class Initialized
INFO - 2024-02-12 20:26:27 --> Form Validation Class Initialized
INFO - 2024-02-12 20:26:27 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:26:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:26:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:26:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:26:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:26:27 --> Final output sent to browser
DEBUG - 2024-02-12 20:26:27 --> Total execution time: 0.0192
ERROR - 2024-02-12 20:27:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:27:10 --> Config Class Initialized
INFO - 2024-02-12 20:27:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:27:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:27:10 --> Utf8 Class Initialized
INFO - 2024-02-12 20:27:10 --> URI Class Initialized
INFO - 2024-02-12 20:27:10 --> Router Class Initialized
INFO - 2024-02-12 20:27:10 --> Output Class Initialized
INFO - 2024-02-12 20:27:10 --> Security Class Initialized
DEBUG - 2024-02-12 20:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:27:10 --> Input Class Initialized
INFO - 2024-02-12 20:27:10 --> Language Class Initialized
INFO - 2024-02-12 20:27:10 --> Loader Class Initialized
INFO - 2024-02-12 20:27:10 --> Helper loaded: url_helper
INFO - 2024-02-12 20:27:10 --> Helper loaded: file_helper
INFO - 2024-02-12 20:27:10 --> Helper loaded: form_helper
INFO - 2024-02-12 20:27:10 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:27:10 --> Controller Class Initialized
INFO - 2024-02-12 20:27:10 --> Form Validation Class Initialized
INFO - 2024-02-12 20:27:10 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:27:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:27:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:27:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:27:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:27:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:27:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:27:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:27:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:27:10 --> Final output sent to browser
DEBUG - 2024-02-12 20:27:10 --> Total execution time: 0.0302
ERROR - 2024-02-12 20:27:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:27:11 --> Config Class Initialized
INFO - 2024-02-12 20:27:11 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:27:11 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:27:11 --> Utf8 Class Initialized
INFO - 2024-02-12 20:27:11 --> URI Class Initialized
INFO - 2024-02-12 20:27:11 --> Router Class Initialized
INFO - 2024-02-12 20:27:11 --> Output Class Initialized
INFO - 2024-02-12 20:27:11 --> Security Class Initialized
DEBUG - 2024-02-12 20:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:27:11 --> Input Class Initialized
INFO - 2024-02-12 20:27:11 --> Language Class Initialized
INFO - 2024-02-12 20:27:11 --> Loader Class Initialized
INFO - 2024-02-12 20:27:11 --> Helper loaded: url_helper
INFO - 2024-02-12 20:27:11 --> Helper loaded: file_helper
INFO - 2024-02-12 20:27:11 --> Helper loaded: form_helper
INFO - 2024-02-12 20:27:11 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:27:11 --> Controller Class Initialized
INFO - 2024-02-12 20:27:11 --> Form Validation Class Initialized
INFO - 2024-02-12 20:27:11 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:27:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:27:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:27:11 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:27:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:27:15 --> Config Class Initialized
INFO - 2024-02-12 20:27:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:27:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:27:15 --> Utf8 Class Initialized
INFO - 2024-02-12 20:27:15 --> URI Class Initialized
INFO - 2024-02-12 20:27:15 --> Router Class Initialized
INFO - 2024-02-12 20:27:15 --> Output Class Initialized
INFO - 2024-02-12 20:27:15 --> Security Class Initialized
DEBUG - 2024-02-12 20:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:27:15 --> Input Class Initialized
INFO - 2024-02-12 20:27:15 --> Language Class Initialized
INFO - 2024-02-12 20:27:15 --> Loader Class Initialized
INFO - 2024-02-12 20:27:15 --> Helper loaded: url_helper
INFO - 2024-02-12 20:27:15 --> Helper loaded: file_helper
INFO - 2024-02-12 20:27:15 --> Helper loaded: form_helper
INFO - 2024-02-12 20:27:15 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:27:15 --> Controller Class Initialized
INFO - 2024-02-12 20:27:15 --> Form Validation Class Initialized
INFO - 2024-02-12 20:27:15 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:27:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:27:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:27:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:27:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:27:15 --> Final output sent to browser
DEBUG - 2024-02-12 20:27:15 --> Total execution time: 0.0430
ERROR - 2024-02-12 20:27:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:27:37 --> Config Class Initialized
INFO - 2024-02-12 20:27:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:27:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:27:37 --> Utf8 Class Initialized
INFO - 2024-02-12 20:27:37 --> URI Class Initialized
INFO - 2024-02-12 20:27:37 --> Router Class Initialized
INFO - 2024-02-12 20:27:37 --> Output Class Initialized
INFO - 2024-02-12 20:27:37 --> Security Class Initialized
DEBUG - 2024-02-12 20:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:27:37 --> Input Class Initialized
INFO - 2024-02-12 20:27:37 --> Language Class Initialized
INFO - 2024-02-12 20:27:37 --> Loader Class Initialized
INFO - 2024-02-12 20:27:37 --> Helper loaded: url_helper
INFO - 2024-02-12 20:27:37 --> Helper loaded: file_helper
INFO - 2024-02-12 20:27:37 --> Helper loaded: form_helper
INFO - 2024-02-12 20:27:37 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:27:37 --> Controller Class Initialized
INFO - 2024-02-12 20:27:37 --> Form Validation Class Initialized
INFO - 2024-02-12 20:27:37 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:27:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:27:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:27:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:27:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:27:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:27:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:27:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:27:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:27:37 --> Final output sent to browser
DEBUG - 2024-02-12 20:27:37 --> Total execution time: 0.0382
ERROR - 2024-02-12 20:27:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:27:38 --> Config Class Initialized
INFO - 2024-02-12 20:27:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:27:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:27:38 --> Utf8 Class Initialized
INFO - 2024-02-12 20:27:38 --> URI Class Initialized
INFO - 2024-02-12 20:27:38 --> Router Class Initialized
INFO - 2024-02-12 20:27:38 --> Output Class Initialized
INFO - 2024-02-12 20:27:38 --> Security Class Initialized
DEBUG - 2024-02-12 20:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:27:38 --> Input Class Initialized
INFO - 2024-02-12 20:27:38 --> Language Class Initialized
INFO - 2024-02-12 20:27:38 --> Loader Class Initialized
INFO - 2024-02-12 20:27:38 --> Helper loaded: url_helper
INFO - 2024-02-12 20:27:38 --> Helper loaded: file_helper
INFO - 2024-02-12 20:27:38 --> Helper loaded: form_helper
INFO - 2024-02-12 20:27:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:27:38 --> Controller Class Initialized
INFO - 2024-02-12 20:27:38 --> Form Validation Class Initialized
INFO - 2024-02-12 20:27:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:27:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:27:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:27:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:27:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:27:40 --> Config Class Initialized
INFO - 2024-02-12 20:27:40 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:27:40 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:27:40 --> Utf8 Class Initialized
INFO - 2024-02-12 20:27:40 --> URI Class Initialized
INFO - 2024-02-12 20:27:40 --> Router Class Initialized
INFO - 2024-02-12 20:27:40 --> Output Class Initialized
INFO - 2024-02-12 20:27:40 --> Security Class Initialized
DEBUG - 2024-02-12 20:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:27:40 --> Input Class Initialized
INFO - 2024-02-12 20:27:40 --> Language Class Initialized
INFO - 2024-02-12 20:27:40 --> Loader Class Initialized
INFO - 2024-02-12 20:27:40 --> Helper loaded: url_helper
INFO - 2024-02-12 20:27:40 --> Helper loaded: file_helper
INFO - 2024-02-12 20:27:40 --> Helper loaded: form_helper
INFO - 2024-02-12 20:27:40 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:27:40 --> Controller Class Initialized
INFO - 2024-02-12 20:27:40 --> Form Validation Class Initialized
INFO - 2024-02-12 20:27:40 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:27:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:27:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:27:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:27:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:27:40 --> Final output sent to browser
DEBUG - 2024-02-12 20:27:40 --> Total execution time: 0.0316
ERROR - 2024-02-12 20:28:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:28:27 --> Config Class Initialized
INFO - 2024-02-12 20:28:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:28:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:28:27 --> Utf8 Class Initialized
INFO - 2024-02-12 20:28:27 --> URI Class Initialized
INFO - 2024-02-12 20:28:27 --> Router Class Initialized
INFO - 2024-02-12 20:28:27 --> Output Class Initialized
INFO - 2024-02-12 20:28:27 --> Security Class Initialized
DEBUG - 2024-02-12 20:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:28:27 --> Input Class Initialized
INFO - 2024-02-12 20:28:27 --> Language Class Initialized
INFO - 2024-02-12 20:28:27 --> Loader Class Initialized
INFO - 2024-02-12 20:28:27 --> Helper loaded: url_helper
INFO - 2024-02-12 20:28:27 --> Helper loaded: file_helper
INFO - 2024-02-12 20:28:27 --> Helper loaded: form_helper
INFO - 2024-02-12 20:28:27 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:28:27 --> Controller Class Initialized
INFO - 2024-02-12 20:28:27 --> Form Validation Class Initialized
INFO - 2024-02-12 20:28:27 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:28:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:28:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:28:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:28:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:28:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:28:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:28:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:28:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:28:27 --> Final output sent to browser
DEBUG - 2024-02-12 20:28:27 --> Total execution time: 0.0265
ERROR - 2024-02-12 20:28:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:28:28 --> Config Class Initialized
INFO - 2024-02-12 20:28:28 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:28:28 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:28:28 --> Utf8 Class Initialized
INFO - 2024-02-12 20:28:28 --> URI Class Initialized
INFO - 2024-02-12 20:28:28 --> Router Class Initialized
INFO - 2024-02-12 20:28:28 --> Output Class Initialized
INFO - 2024-02-12 20:28:28 --> Security Class Initialized
DEBUG - 2024-02-12 20:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:28:28 --> Input Class Initialized
INFO - 2024-02-12 20:28:28 --> Language Class Initialized
INFO - 2024-02-12 20:28:28 --> Loader Class Initialized
INFO - 2024-02-12 20:28:28 --> Helper loaded: url_helper
INFO - 2024-02-12 20:28:28 --> Helper loaded: file_helper
INFO - 2024-02-12 20:28:28 --> Helper loaded: form_helper
INFO - 2024-02-12 20:28:28 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:28:28 --> Controller Class Initialized
INFO - 2024-02-12 20:28:28 --> Form Validation Class Initialized
INFO - 2024-02-12 20:28:28 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:28:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:28:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:28:28 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:28:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:28:31 --> Config Class Initialized
INFO - 2024-02-12 20:28:31 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:28:31 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:28:31 --> Utf8 Class Initialized
INFO - 2024-02-12 20:28:31 --> URI Class Initialized
INFO - 2024-02-12 20:28:31 --> Router Class Initialized
INFO - 2024-02-12 20:28:31 --> Output Class Initialized
INFO - 2024-02-12 20:28:31 --> Security Class Initialized
DEBUG - 2024-02-12 20:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:28:31 --> Input Class Initialized
INFO - 2024-02-12 20:28:31 --> Language Class Initialized
INFO - 2024-02-12 20:28:31 --> Loader Class Initialized
INFO - 2024-02-12 20:28:31 --> Helper loaded: url_helper
INFO - 2024-02-12 20:28:31 --> Helper loaded: file_helper
INFO - 2024-02-12 20:28:31 --> Helper loaded: form_helper
INFO - 2024-02-12 20:28:31 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:28:31 --> Controller Class Initialized
INFO - 2024-02-12 20:28:31 --> Form Validation Class Initialized
INFO - 2024-02-12 20:28:31 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:28:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:28:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:28:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:28:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:28:31 --> Final output sent to browser
DEBUG - 2024-02-12 20:28:31 --> Total execution time: 0.0340
ERROR - 2024-02-12 20:32:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:32:20 --> Config Class Initialized
INFO - 2024-02-12 20:32:20 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:32:20 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:32:20 --> Utf8 Class Initialized
INFO - 2024-02-12 20:32:20 --> URI Class Initialized
INFO - 2024-02-12 20:32:20 --> Router Class Initialized
INFO - 2024-02-12 20:32:20 --> Output Class Initialized
INFO - 2024-02-12 20:32:20 --> Security Class Initialized
DEBUG - 2024-02-12 20:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:32:20 --> Input Class Initialized
INFO - 2024-02-12 20:32:20 --> Language Class Initialized
INFO - 2024-02-12 20:32:20 --> Loader Class Initialized
INFO - 2024-02-12 20:32:20 --> Helper loaded: url_helper
INFO - 2024-02-12 20:32:20 --> Helper loaded: file_helper
INFO - 2024-02-12 20:32:20 --> Helper loaded: form_helper
INFO - 2024-02-12 20:32:20 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:32:20 --> Controller Class Initialized
INFO - 2024-02-12 20:32:20 --> Form Validation Class Initialized
INFO - 2024-02-12 20:32:20 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:32:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:32:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:32:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:32:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:32:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:32:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:32:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:32:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:32:20 --> Final output sent to browser
DEBUG - 2024-02-12 20:32:20 --> Total execution time: 0.0310
ERROR - 2024-02-12 20:32:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:32:21 --> Config Class Initialized
INFO - 2024-02-12 20:32:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:32:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:32:21 --> Utf8 Class Initialized
INFO - 2024-02-12 20:32:21 --> URI Class Initialized
INFO - 2024-02-12 20:32:21 --> Router Class Initialized
INFO - 2024-02-12 20:32:21 --> Output Class Initialized
INFO - 2024-02-12 20:32:21 --> Security Class Initialized
DEBUG - 2024-02-12 20:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:32:21 --> Input Class Initialized
INFO - 2024-02-12 20:32:21 --> Language Class Initialized
INFO - 2024-02-12 20:32:21 --> Loader Class Initialized
INFO - 2024-02-12 20:32:21 --> Helper loaded: url_helper
INFO - 2024-02-12 20:32:21 --> Helper loaded: file_helper
INFO - 2024-02-12 20:32:21 --> Helper loaded: form_helper
INFO - 2024-02-12 20:32:21 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:32:21 --> Controller Class Initialized
INFO - 2024-02-12 20:32:21 --> Form Validation Class Initialized
INFO - 2024-02-12 20:32:21 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:32:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:32:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:32:21 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:32:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:32:24 --> Config Class Initialized
INFO - 2024-02-12 20:32:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:32:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:32:24 --> Utf8 Class Initialized
INFO - 2024-02-12 20:32:24 --> URI Class Initialized
INFO - 2024-02-12 20:32:24 --> Router Class Initialized
INFO - 2024-02-12 20:32:24 --> Output Class Initialized
INFO - 2024-02-12 20:32:24 --> Security Class Initialized
DEBUG - 2024-02-12 20:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:32:24 --> Input Class Initialized
INFO - 2024-02-12 20:32:24 --> Language Class Initialized
INFO - 2024-02-12 20:32:24 --> Loader Class Initialized
INFO - 2024-02-12 20:32:24 --> Helper loaded: url_helper
INFO - 2024-02-12 20:32:24 --> Helper loaded: file_helper
INFO - 2024-02-12 20:32:24 --> Helper loaded: form_helper
INFO - 2024-02-12 20:32:24 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:32:24 --> Controller Class Initialized
INFO - 2024-02-12 20:32:24 --> Form Validation Class Initialized
INFO - 2024-02-12 20:32:24 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:32:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:32:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:32:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:32:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:32:24 --> Final output sent to browser
DEBUG - 2024-02-12 20:32:24 --> Total execution time: 0.0241
ERROR - 2024-02-12 20:33:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:33:30 --> Config Class Initialized
INFO - 2024-02-12 20:33:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:33:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:33:30 --> Utf8 Class Initialized
INFO - 2024-02-12 20:33:30 --> URI Class Initialized
INFO - 2024-02-12 20:33:30 --> Router Class Initialized
INFO - 2024-02-12 20:33:30 --> Output Class Initialized
INFO - 2024-02-12 20:33:30 --> Security Class Initialized
DEBUG - 2024-02-12 20:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:33:30 --> Input Class Initialized
INFO - 2024-02-12 20:33:30 --> Language Class Initialized
INFO - 2024-02-12 20:33:30 --> Loader Class Initialized
INFO - 2024-02-12 20:33:30 --> Helper loaded: url_helper
INFO - 2024-02-12 20:33:30 --> Helper loaded: file_helper
INFO - 2024-02-12 20:33:30 --> Helper loaded: form_helper
INFO - 2024-02-12 20:33:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:33:30 --> Controller Class Initialized
INFO - 2024-02-12 20:33:30 --> Form Validation Class Initialized
INFO - 2024-02-12 20:33:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:33:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:33:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:33:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:33:30 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\sscy\application\models\ItemMasterModel.php 29
ERROR - 2024-02-12 20:33:30 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\sscy\application\models\ItemMasterModel.php 43
ERROR - 2024-02-12 20:33:30 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\sscy\application\models\MasterModel.php 748
ERROR - 2024-02-12 20:33:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:33:38 --> Config Class Initialized
INFO - 2024-02-12 20:33:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:33:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:33:38 --> Utf8 Class Initialized
INFO - 2024-02-12 20:33:38 --> URI Class Initialized
INFO - 2024-02-12 20:33:38 --> Router Class Initialized
INFO - 2024-02-12 20:33:38 --> Output Class Initialized
INFO - 2024-02-12 20:33:38 --> Security Class Initialized
DEBUG - 2024-02-12 20:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:33:38 --> Input Class Initialized
INFO - 2024-02-12 20:33:38 --> Language Class Initialized
INFO - 2024-02-12 20:33:38 --> Loader Class Initialized
INFO - 2024-02-12 20:33:38 --> Helper loaded: url_helper
INFO - 2024-02-12 20:33:38 --> Helper loaded: file_helper
INFO - 2024-02-12 20:33:38 --> Helper loaded: form_helper
INFO - 2024-02-12 20:33:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:33:38 --> Controller Class Initialized
INFO - 2024-02-12 20:33:38 --> Form Validation Class Initialized
INFO - 2024-02-12 20:33:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:33:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:33:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:33:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:33:38 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\sscy\application\models\ItemMasterModel.php 29
ERROR - 2024-02-12 20:34:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:34:00 --> Config Class Initialized
INFO - 2024-02-12 20:34:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:34:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:34:00 --> Utf8 Class Initialized
INFO - 2024-02-12 20:34:00 --> URI Class Initialized
INFO - 2024-02-12 20:34:00 --> Router Class Initialized
INFO - 2024-02-12 20:34:00 --> Output Class Initialized
INFO - 2024-02-12 20:34:00 --> Security Class Initialized
DEBUG - 2024-02-12 20:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:34:00 --> Input Class Initialized
INFO - 2024-02-12 20:34:00 --> Language Class Initialized
INFO - 2024-02-12 20:34:00 --> Loader Class Initialized
INFO - 2024-02-12 20:34:00 --> Helper loaded: url_helper
INFO - 2024-02-12 20:34:00 --> Helper loaded: file_helper
INFO - 2024-02-12 20:34:00 --> Helper loaded: form_helper
INFO - 2024-02-12 20:34:00 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:34:00 --> Controller Class Initialized
INFO - 2024-02-12 20:34:00 --> Form Validation Class Initialized
INFO - 2024-02-12 20:34:00 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:34:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:34:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:34:00 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:34:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:34:00 --> Config Class Initialized
INFO - 2024-02-12 20:34:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:34:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:34:00 --> Utf8 Class Initialized
INFO - 2024-02-12 20:34:00 --> URI Class Initialized
INFO - 2024-02-12 20:34:00 --> Router Class Initialized
INFO - 2024-02-12 20:34:00 --> Output Class Initialized
INFO - 2024-02-12 20:34:00 --> Security Class Initialized
DEBUG - 2024-02-12 20:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:34:00 --> Input Class Initialized
INFO - 2024-02-12 20:34:00 --> Language Class Initialized
INFO - 2024-02-12 20:34:00 --> Loader Class Initialized
INFO - 2024-02-12 20:34:00 --> Helper loaded: url_helper
INFO - 2024-02-12 20:34:00 --> Helper loaded: file_helper
INFO - 2024-02-12 20:34:00 --> Helper loaded: form_helper
INFO - 2024-02-12 20:34:00 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:34:00 --> Controller Class Initialized
INFO - 2024-02-12 20:34:00 --> Form Validation Class Initialized
INFO - 2024-02-12 20:34:00 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:34:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:34:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:34:00 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:34:08 --> Config Class Initialized
INFO - 2024-02-12 20:34:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:34:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:34:08 --> Utf8 Class Initialized
INFO - 2024-02-12 20:34:08 --> URI Class Initialized
INFO - 2024-02-12 20:34:08 --> Router Class Initialized
INFO - 2024-02-12 20:34:08 --> Output Class Initialized
INFO - 2024-02-12 20:34:08 --> Security Class Initialized
DEBUG - 2024-02-12 20:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:34:08 --> Input Class Initialized
INFO - 2024-02-12 20:34:08 --> Language Class Initialized
INFO - 2024-02-12 20:34:08 --> Loader Class Initialized
INFO - 2024-02-12 20:34:08 --> Helper loaded: url_helper
INFO - 2024-02-12 20:34:08 --> Helper loaded: file_helper
INFO - 2024-02-12 20:34:08 --> Helper loaded: form_helper
INFO - 2024-02-12 20:34:08 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:34:08 --> Controller Class Initialized
INFO - 2024-02-12 20:34:08 --> Form Validation Class Initialized
INFO - 2024-02-12 20:34:08 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:34:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:34:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:34:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:34:08 --> Config Class Initialized
INFO - 2024-02-12 20:34:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:34:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:34:08 --> Utf8 Class Initialized
INFO - 2024-02-12 20:34:08 --> URI Class Initialized
INFO - 2024-02-12 20:34:08 --> Router Class Initialized
INFO - 2024-02-12 20:34:08 --> Output Class Initialized
INFO - 2024-02-12 20:34:08 --> Security Class Initialized
DEBUG - 2024-02-12 20:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:34:08 --> Input Class Initialized
INFO - 2024-02-12 20:34:08 --> Language Class Initialized
INFO - 2024-02-12 20:34:08 --> Loader Class Initialized
INFO - 2024-02-12 20:34:08 --> Helper loaded: url_helper
INFO - 2024-02-12 20:34:08 --> Helper loaded: file_helper
INFO - 2024-02-12 20:34:08 --> Helper loaded: form_helper
INFO - 2024-02-12 20:34:08 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:34:08 --> Controller Class Initialized
INFO - 2024-02-12 20:34:08 --> Form Validation Class Initialized
INFO - 2024-02-12 20:34:08 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:34:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:34:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:34:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:34:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:34:27 --> Config Class Initialized
INFO - 2024-02-12 20:34:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:34:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:34:27 --> Utf8 Class Initialized
INFO - 2024-02-12 20:34:27 --> URI Class Initialized
INFO - 2024-02-12 20:34:27 --> Router Class Initialized
INFO - 2024-02-12 20:34:27 --> Output Class Initialized
INFO - 2024-02-12 20:34:27 --> Security Class Initialized
DEBUG - 2024-02-12 20:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:34:27 --> Input Class Initialized
INFO - 2024-02-12 20:34:27 --> Language Class Initialized
INFO - 2024-02-12 20:34:27 --> Loader Class Initialized
INFO - 2024-02-12 20:34:27 --> Helper loaded: url_helper
INFO - 2024-02-12 20:34:27 --> Helper loaded: file_helper
INFO - 2024-02-12 20:34:27 --> Helper loaded: form_helper
INFO - 2024-02-12 20:34:27 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:34:27 --> Controller Class Initialized
INFO - 2024-02-12 20:34:27 --> Form Validation Class Initialized
INFO - 2024-02-12 20:34:27 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:34:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:34:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:34:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:34:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:34:27 --> Config Class Initialized
INFO - 2024-02-12 20:34:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:34:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:34:27 --> Utf8 Class Initialized
INFO - 2024-02-12 20:34:27 --> URI Class Initialized
INFO - 2024-02-12 20:34:27 --> Router Class Initialized
INFO - 2024-02-12 20:34:27 --> Output Class Initialized
INFO - 2024-02-12 20:34:27 --> Security Class Initialized
DEBUG - 2024-02-12 20:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:34:27 --> Input Class Initialized
INFO - 2024-02-12 20:34:27 --> Language Class Initialized
INFO - 2024-02-12 20:34:27 --> Loader Class Initialized
INFO - 2024-02-12 20:34:27 --> Helper loaded: url_helper
INFO - 2024-02-12 20:34:27 --> Helper loaded: file_helper
INFO - 2024-02-12 20:34:27 --> Helper loaded: form_helper
INFO - 2024-02-12 20:34:27 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:34:27 --> Controller Class Initialized
INFO - 2024-02-12 20:34:27 --> Form Validation Class Initialized
INFO - 2024-02-12 20:34:27 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:34:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:34:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:34:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:34:29 --> Config Class Initialized
INFO - 2024-02-12 20:34:29 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:34:29 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:34:29 --> Utf8 Class Initialized
INFO - 2024-02-12 20:34:29 --> URI Class Initialized
INFO - 2024-02-12 20:34:29 --> Router Class Initialized
INFO - 2024-02-12 20:34:29 --> Output Class Initialized
INFO - 2024-02-12 20:34:29 --> Security Class Initialized
DEBUG - 2024-02-12 20:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:34:29 --> Input Class Initialized
INFO - 2024-02-12 20:34:29 --> Language Class Initialized
INFO - 2024-02-12 20:34:29 --> Loader Class Initialized
INFO - 2024-02-12 20:34:29 --> Helper loaded: url_helper
INFO - 2024-02-12 20:34:29 --> Helper loaded: file_helper
INFO - 2024-02-12 20:34:29 --> Helper loaded: form_helper
INFO - 2024-02-12 20:34:29 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:34:29 --> Controller Class Initialized
INFO - 2024-02-12 20:34:29 --> Form Validation Class Initialized
INFO - 2024-02-12 20:34:29 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:34:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:34:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:34:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:34:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:34:29 --> Final output sent to browser
DEBUG - 2024-02-12 20:34:29 --> Total execution time: 0.0246
ERROR - 2024-02-12 20:35:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:35:15 --> Config Class Initialized
INFO - 2024-02-12 20:35:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:35:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:35:15 --> Utf8 Class Initialized
INFO - 2024-02-12 20:35:15 --> URI Class Initialized
INFO - 2024-02-12 20:35:15 --> Router Class Initialized
INFO - 2024-02-12 20:35:15 --> Output Class Initialized
INFO - 2024-02-12 20:35:15 --> Security Class Initialized
DEBUG - 2024-02-12 20:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:35:15 --> Input Class Initialized
INFO - 2024-02-12 20:35:15 --> Language Class Initialized
INFO - 2024-02-12 20:35:15 --> Loader Class Initialized
INFO - 2024-02-12 20:35:15 --> Helper loaded: url_helper
INFO - 2024-02-12 20:35:15 --> Helper loaded: file_helper
INFO - 2024-02-12 20:35:15 --> Helper loaded: form_helper
INFO - 2024-02-12 20:35:15 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:35:15 --> Controller Class Initialized
INFO - 2024-02-12 20:35:15 --> Form Validation Class Initialized
INFO - 2024-02-12 20:35:15 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:35:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:35:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:35:15 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:36:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:36:35 --> Config Class Initialized
INFO - 2024-02-12 20:36:35 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:36:35 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:36:35 --> Utf8 Class Initialized
INFO - 2024-02-12 20:36:35 --> URI Class Initialized
INFO - 2024-02-12 20:36:35 --> Router Class Initialized
INFO - 2024-02-12 20:36:35 --> Output Class Initialized
INFO - 2024-02-12 20:36:35 --> Security Class Initialized
DEBUG - 2024-02-12 20:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:36:35 --> Input Class Initialized
INFO - 2024-02-12 20:36:35 --> Language Class Initialized
INFO - 2024-02-12 20:36:35 --> Loader Class Initialized
INFO - 2024-02-12 20:36:35 --> Helper loaded: url_helper
INFO - 2024-02-12 20:36:35 --> Helper loaded: file_helper
INFO - 2024-02-12 20:36:35 --> Helper loaded: form_helper
INFO - 2024-02-12 20:36:35 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:36:35 --> Controller Class Initialized
INFO - 2024-02-12 20:36:35 --> Form Validation Class Initialized
INFO - 2024-02-12 20:36:35 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:36:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:36:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:36:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:36:35 --> Upload Class Initialized
INFO - 2024-02-12 20:36:35 --> Image Lib Class Initialized
ERROR - 2024-02-12 20:36:35 --> Severity: Notice --> Undefined variable: fileName D:\xampp\htdocs\sscy\application\controllers\app\ItemMaster.php 53
ERROR - 2024-02-12 20:37:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:37:06 --> Config Class Initialized
INFO - 2024-02-12 20:37:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:37:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:37:06 --> Utf8 Class Initialized
INFO - 2024-02-12 20:37:06 --> URI Class Initialized
INFO - 2024-02-12 20:37:06 --> Router Class Initialized
INFO - 2024-02-12 20:37:06 --> Output Class Initialized
INFO - 2024-02-12 20:37:06 --> Security Class Initialized
DEBUG - 2024-02-12 20:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:37:06 --> Input Class Initialized
INFO - 2024-02-12 20:37:06 --> Language Class Initialized
INFO - 2024-02-12 20:37:06 --> Loader Class Initialized
INFO - 2024-02-12 20:37:06 --> Helper loaded: url_helper
INFO - 2024-02-12 20:37:06 --> Helper loaded: file_helper
INFO - 2024-02-12 20:37:06 --> Helper loaded: form_helper
INFO - 2024-02-12 20:37:06 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:37:06 --> Controller Class Initialized
INFO - 2024-02-12 20:37:06 --> Form Validation Class Initialized
INFO - 2024-02-12 20:37:06 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:37:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:37:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:37:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:37:06 --> Upload Class Initialized
INFO - 2024-02-12 20:37:06 --> Image Lib Class Initialized
ERROR - 2024-02-12 20:37:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:37:14 --> Config Class Initialized
INFO - 2024-02-12 20:37:14 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:37:14 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:37:14 --> Utf8 Class Initialized
INFO - 2024-02-12 20:37:14 --> URI Class Initialized
INFO - 2024-02-12 20:37:14 --> Router Class Initialized
INFO - 2024-02-12 20:37:14 --> Output Class Initialized
INFO - 2024-02-12 20:37:14 --> Security Class Initialized
DEBUG - 2024-02-12 20:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:37:14 --> Input Class Initialized
INFO - 2024-02-12 20:37:14 --> Language Class Initialized
INFO - 2024-02-12 20:37:14 --> Loader Class Initialized
INFO - 2024-02-12 20:37:14 --> Helper loaded: url_helper
INFO - 2024-02-12 20:37:14 --> Helper loaded: file_helper
INFO - 2024-02-12 20:37:14 --> Helper loaded: form_helper
INFO - 2024-02-12 20:37:14 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:37:14 --> Controller Class Initialized
INFO - 2024-02-12 20:37:14 --> Form Validation Class Initialized
INFO - 2024-02-12 20:37:14 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:37:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:37:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:37:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:37:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:37:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:37:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:37:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:37:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:37:14 --> Final output sent to browser
DEBUG - 2024-02-12 20:37:14 --> Total execution time: 0.0314
ERROR - 2024-02-12 20:37:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:37:14 --> Config Class Initialized
INFO - 2024-02-12 20:37:14 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:37:14 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:37:14 --> Utf8 Class Initialized
INFO - 2024-02-12 20:37:14 --> URI Class Initialized
INFO - 2024-02-12 20:37:14 --> Router Class Initialized
INFO - 2024-02-12 20:37:14 --> Output Class Initialized
INFO - 2024-02-12 20:37:14 --> Security Class Initialized
DEBUG - 2024-02-12 20:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:37:14 --> Input Class Initialized
INFO - 2024-02-12 20:37:14 --> Language Class Initialized
INFO - 2024-02-12 20:37:14 --> Loader Class Initialized
INFO - 2024-02-12 20:37:14 --> Helper loaded: url_helper
INFO - 2024-02-12 20:37:14 --> Helper loaded: file_helper
INFO - 2024-02-12 20:37:14 --> Helper loaded: form_helper
INFO - 2024-02-12 20:37:14 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:37:14 --> Controller Class Initialized
INFO - 2024-02-12 20:37:14 --> Form Validation Class Initialized
INFO - 2024-02-12 20:37:14 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:37:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:37:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:37:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:37:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:37:21 --> Config Class Initialized
INFO - 2024-02-12 20:37:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:37:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:37:21 --> Utf8 Class Initialized
INFO - 2024-02-12 20:37:21 --> URI Class Initialized
INFO - 2024-02-12 20:37:21 --> Router Class Initialized
INFO - 2024-02-12 20:37:21 --> Output Class Initialized
INFO - 2024-02-12 20:37:21 --> Security Class Initialized
DEBUG - 2024-02-12 20:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:37:21 --> Input Class Initialized
INFO - 2024-02-12 20:37:21 --> Language Class Initialized
INFO - 2024-02-12 20:37:21 --> Loader Class Initialized
INFO - 2024-02-12 20:37:21 --> Helper loaded: url_helper
INFO - 2024-02-12 20:37:21 --> Helper loaded: file_helper
INFO - 2024-02-12 20:37:21 --> Helper loaded: form_helper
INFO - 2024-02-12 20:37:21 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:37:21 --> Controller Class Initialized
INFO - 2024-02-12 20:37:21 --> Form Validation Class Initialized
INFO - 2024-02-12 20:37:21 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:37:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:37:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:37:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:37:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:37:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:37:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:37:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:37:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:37:21 --> Final output sent to browser
DEBUG - 2024-02-12 20:37:21 --> Total execution time: 0.0332
ERROR - 2024-02-12 20:37:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:37:53 --> Config Class Initialized
INFO - 2024-02-12 20:37:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:37:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:37:53 --> Utf8 Class Initialized
INFO - 2024-02-12 20:37:53 --> URI Class Initialized
INFO - 2024-02-12 20:37:53 --> Router Class Initialized
INFO - 2024-02-12 20:37:53 --> Output Class Initialized
INFO - 2024-02-12 20:37:53 --> Security Class Initialized
DEBUG - 2024-02-12 20:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:37:53 --> Input Class Initialized
INFO - 2024-02-12 20:37:53 --> Language Class Initialized
INFO - 2024-02-12 20:37:53 --> Loader Class Initialized
INFO - 2024-02-12 20:37:53 --> Helper loaded: url_helper
INFO - 2024-02-12 20:37:53 --> Helper loaded: file_helper
INFO - 2024-02-12 20:37:53 --> Helper loaded: form_helper
INFO - 2024-02-12 20:37:53 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:37:53 --> Controller Class Initialized
INFO - 2024-02-12 20:37:53 --> Form Validation Class Initialized
INFO - 2024-02-12 20:37:53 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:37:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:37:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:37:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:38:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:38:42 --> Config Class Initialized
INFO - 2024-02-12 20:38:42 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:38:42 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:38:42 --> Utf8 Class Initialized
INFO - 2024-02-12 20:38:42 --> URI Class Initialized
INFO - 2024-02-12 20:38:42 --> Router Class Initialized
INFO - 2024-02-12 20:38:42 --> Output Class Initialized
INFO - 2024-02-12 20:38:42 --> Security Class Initialized
DEBUG - 2024-02-12 20:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:38:42 --> Input Class Initialized
INFO - 2024-02-12 20:38:42 --> Language Class Initialized
INFO - 2024-02-12 20:38:42 --> Loader Class Initialized
INFO - 2024-02-12 20:38:42 --> Helper loaded: url_helper
INFO - 2024-02-12 20:38:42 --> Helper loaded: file_helper
INFO - 2024-02-12 20:38:42 --> Helper loaded: form_helper
INFO - 2024-02-12 20:38:42 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:38:42 --> Controller Class Initialized
INFO - 2024-02-12 20:38:42 --> Form Validation Class Initialized
INFO - 2024-02-12 20:38:42 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:38:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:38:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:38:42 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:38:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:38:44 --> Config Class Initialized
INFO - 2024-02-12 20:38:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:38:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:38:44 --> Utf8 Class Initialized
INFO - 2024-02-12 20:38:44 --> URI Class Initialized
INFO - 2024-02-12 20:38:44 --> Router Class Initialized
INFO - 2024-02-12 20:38:44 --> Output Class Initialized
INFO - 2024-02-12 20:38:44 --> Security Class Initialized
DEBUG - 2024-02-12 20:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:38:44 --> Input Class Initialized
INFO - 2024-02-12 20:38:44 --> Language Class Initialized
INFO - 2024-02-12 20:38:44 --> Loader Class Initialized
INFO - 2024-02-12 20:38:44 --> Helper loaded: url_helper
INFO - 2024-02-12 20:38:44 --> Helper loaded: file_helper
INFO - 2024-02-12 20:38:44 --> Helper loaded: form_helper
INFO - 2024-02-12 20:38:44 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:38:44 --> Controller Class Initialized
INFO - 2024-02-12 20:38:44 --> Form Validation Class Initialized
INFO - 2024-02-12 20:38:44 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:38:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:38:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:38:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:39:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:39:36 --> Config Class Initialized
INFO - 2024-02-12 20:39:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:39:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:39:36 --> Utf8 Class Initialized
INFO - 2024-02-12 20:39:36 --> URI Class Initialized
INFO - 2024-02-12 20:39:36 --> Router Class Initialized
INFO - 2024-02-12 20:39:36 --> Output Class Initialized
INFO - 2024-02-12 20:39:36 --> Security Class Initialized
DEBUG - 2024-02-12 20:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:39:36 --> Input Class Initialized
INFO - 2024-02-12 20:39:36 --> Language Class Initialized
INFO - 2024-02-12 20:39:36 --> Loader Class Initialized
INFO - 2024-02-12 20:39:36 --> Helper loaded: url_helper
INFO - 2024-02-12 20:39:36 --> Helper loaded: file_helper
INFO - 2024-02-12 20:39:36 --> Helper loaded: form_helper
INFO - 2024-02-12 20:39:36 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:39:36 --> Controller Class Initialized
INFO - 2024-02-12 20:39:36 --> Form Validation Class Initialized
INFO - 2024-02-12 20:39:36 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:39:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:39:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:39:36 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:40:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:40:35 --> Config Class Initialized
INFO - 2024-02-12 20:40:35 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:40:35 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:40:35 --> Utf8 Class Initialized
INFO - 2024-02-12 20:40:35 --> URI Class Initialized
INFO - 2024-02-12 20:40:35 --> Router Class Initialized
INFO - 2024-02-12 20:40:35 --> Output Class Initialized
INFO - 2024-02-12 20:40:35 --> Security Class Initialized
DEBUG - 2024-02-12 20:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:40:35 --> Input Class Initialized
INFO - 2024-02-12 20:40:35 --> Language Class Initialized
INFO - 2024-02-12 20:40:35 --> Loader Class Initialized
INFO - 2024-02-12 20:40:35 --> Helper loaded: url_helper
INFO - 2024-02-12 20:40:35 --> Helper loaded: file_helper
INFO - 2024-02-12 20:40:35 --> Helper loaded: form_helper
INFO - 2024-02-12 20:40:35 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:40:35 --> Controller Class Initialized
INFO - 2024-02-12 20:40:35 --> Form Validation Class Initialized
INFO - 2024-02-12 20:40:35 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:40:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:40:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:40:35 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:40:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:40:36 --> Config Class Initialized
INFO - 2024-02-12 20:40:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:40:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:40:36 --> Utf8 Class Initialized
INFO - 2024-02-12 20:40:36 --> URI Class Initialized
INFO - 2024-02-12 20:40:36 --> Router Class Initialized
INFO - 2024-02-12 20:40:36 --> Output Class Initialized
INFO - 2024-02-12 20:40:36 --> Security Class Initialized
DEBUG - 2024-02-12 20:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:40:36 --> Input Class Initialized
INFO - 2024-02-12 20:40:36 --> Language Class Initialized
INFO - 2024-02-12 20:40:36 --> Loader Class Initialized
INFO - 2024-02-12 20:40:36 --> Helper loaded: url_helper
INFO - 2024-02-12 20:40:36 --> Helper loaded: file_helper
INFO - 2024-02-12 20:40:36 --> Helper loaded: form_helper
INFO - 2024-02-12 20:40:36 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:40:36 --> Controller Class Initialized
INFO - 2024-02-12 20:40:36 --> Form Validation Class Initialized
INFO - 2024-02-12 20:40:36 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:40:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:40:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:40:36 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:40:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:40:37 --> Config Class Initialized
INFO - 2024-02-12 20:40:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:40:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:40:38 --> Utf8 Class Initialized
INFO - 2024-02-12 20:40:38 --> URI Class Initialized
INFO - 2024-02-12 20:40:38 --> Router Class Initialized
INFO - 2024-02-12 20:40:38 --> Output Class Initialized
INFO - 2024-02-12 20:40:38 --> Security Class Initialized
DEBUG - 2024-02-12 20:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:40:38 --> Input Class Initialized
INFO - 2024-02-12 20:40:38 --> Language Class Initialized
INFO - 2024-02-12 20:40:38 --> Loader Class Initialized
INFO - 2024-02-12 20:40:38 --> Helper loaded: url_helper
INFO - 2024-02-12 20:40:38 --> Helper loaded: file_helper
INFO - 2024-02-12 20:40:38 --> Helper loaded: form_helper
INFO - 2024-02-12 20:40:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:40:38 --> Controller Class Initialized
INFO - 2024-02-12 20:40:38 --> Form Validation Class Initialized
INFO - 2024-02-12 20:40:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:40:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:40:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:40:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:40:39 --> Config Class Initialized
INFO - 2024-02-12 20:40:39 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:40:39 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:40:39 --> Utf8 Class Initialized
INFO - 2024-02-12 20:40:39 --> URI Class Initialized
INFO - 2024-02-12 20:40:39 --> Router Class Initialized
INFO - 2024-02-12 20:40:39 --> Output Class Initialized
INFO - 2024-02-12 20:40:39 --> Security Class Initialized
DEBUG - 2024-02-12 20:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:40:39 --> Input Class Initialized
INFO - 2024-02-12 20:40:39 --> Language Class Initialized
INFO - 2024-02-12 20:40:39 --> Loader Class Initialized
INFO - 2024-02-12 20:40:39 --> Helper loaded: url_helper
INFO - 2024-02-12 20:40:39 --> Helper loaded: file_helper
INFO - 2024-02-12 20:40:39 --> Helper loaded: form_helper
INFO - 2024-02-12 20:40:39 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:40:39 --> Controller Class Initialized
INFO - 2024-02-12 20:40:39 --> Form Validation Class Initialized
INFO - 2024-02-12 20:40:39 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:40:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:40:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:40:39 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:40:41 --> Config Class Initialized
INFO - 2024-02-12 20:40:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:40:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:40:41 --> Utf8 Class Initialized
INFO - 2024-02-12 20:40:41 --> URI Class Initialized
INFO - 2024-02-12 20:40:41 --> Router Class Initialized
INFO - 2024-02-12 20:40:41 --> Output Class Initialized
INFO - 2024-02-12 20:40:41 --> Security Class Initialized
DEBUG - 2024-02-12 20:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:40:41 --> Input Class Initialized
INFO - 2024-02-12 20:40:41 --> Language Class Initialized
INFO - 2024-02-12 20:40:41 --> Loader Class Initialized
INFO - 2024-02-12 20:40:41 --> Helper loaded: url_helper
INFO - 2024-02-12 20:40:41 --> Helper loaded: file_helper
INFO - 2024-02-12 20:40:41 --> Helper loaded: form_helper
INFO - 2024-02-12 20:40:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:40:41 --> Controller Class Initialized
INFO - 2024-02-12 20:40:41 --> Form Validation Class Initialized
INFO - 2024-02-12 20:40:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:40:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:40:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:40:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:40:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:40:43 --> Config Class Initialized
INFO - 2024-02-12 20:40:43 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:40:43 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:40:43 --> Utf8 Class Initialized
INFO - 2024-02-12 20:40:43 --> URI Class Initialized
INFO - 2024-02-12 20:40:43 --> Router Class Initialized
INFO - 2024-02-12 20:40:43 --> Output Class Initialized
INFO - 2024-02-12 20:40:43 --> Security Class Initialized
DEBUG - 2024-02-12 20:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:40:43 --> Input Class Initialized
INFO - 2024-02-12 20:40:43 --> Language Class Initialized
INFO - 2024-02-12 20:40:43 --> Loader Class Initialized
INFO - 2024-02-12 20:40:43 --> Helper loaded: url_helper
INFO - 2024-02-12 20:40:43 --> Helper loaded: file_helper
INFO - 2024-02-12 20:40:43 --> Helper loaded: form_helper
INFO - 2024-02-12 20:40:43 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:40:43 --> Controller Class Initialized
INFO - 2024-02-12 20:40:43 --> Form Validation Class Initialized
INFO - 2024-02-12 20:40:43 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:40:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:40:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:40:43 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:40:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:40:46 --> Config Class Initialized
INFO - 2024-02-12 20:40:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:40:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:40:46 --> Utf8 Class Initialized
INFO - 2024-02-12 20:40:46 --> URI Class Initialized
INFO - 2024-02-12 20:40:46 --> Router Class Initialized
INFO - 2024-02-12 20:40:46 --> Output Class Initialized
INFO - 2024-02-12 20:40:46 --> Security Class Initialized
DEBUG - 2024-02-12 20:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:40:46 --> Input Class Initialized
INFO - 2024-02-12 20:40:46 --> Language Class Initialized
INFO - 2024-02-12 20:40:46 --> Loader Class Initialized
INFO - 2024-02-12 20:40:46 --> Helper loaded: url_helper
INFO - 2024-02-12 20:40:46 --> Helper loaded: file_helper
INFO - 2024-02-12 20:40:46 --> Helper loaded: form_helper
INFO - 2024-02-12 20:40:46 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:40:46 --> Controller Class Initialized
INFO - 2024-02-12 20:40:46 --> Form Validation Class Initialized
INFO - 2024-02-12 20:40:46 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:40:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:40:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:40:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:41:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:41:11 --> Config Class Initialized
INFO - 2024-02-12 20:41:11 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:41:11 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:41:11 --> Utf8 Class Initialized
INFO - 2024-02-12 20:41:11 --> URI Class Initialized
INFO - 2024-02-12 20:41:11 --> Router Class Initialized
INFO - 2024-02-12 20:41:11 --> Output Class Initialized
INFO - 2024-02-12 20:41:11 --> Security Class Initialized
DEBUG - 2024-02-12 20:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:41:11 --> Input Class Initialized
INFO - 2024-02-12 20:41:11 --> Language Class Initialized
INFO - 2024-02-12 20:41:11 --> Loader Class Initialized
INFO - 2024-02-12 20:41:11 --> Helper loaded: url_helper
INFO - 2024-02-12 20:41:11 --> Helper loaded: file_helper
INFO - 2024-02-12 20:41:11 --> Helper loaded: form_helper
INFO - 2024-02-12 20:41:11 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:41:11 --> Controller Class Initialized
INFO - 2024-02-12 20:41:11 --> Form Validation Class Initialized
INFO - 2024-02-12 20:41:11 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:41:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:41:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:41:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:41:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:41:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:41:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:41:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:41:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:41:11 --> Final output sent to browser
DEBUG - 2024-02-12 20:41:11 --> Total execution time: 0.0275
ERROR - 2024-02-12 20:41:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:41:12 --> Config Class Initialized
INFO - 2024-02-12 20:41:12 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:41:12 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:41:12 --> Utf8 Class Initialized
INFO - 2024-02-12 20:41:12 --> URI Class Initialized
INFO - 2024-02-12 20:41:12 --> Router Class Initialized
INFO - 2024-02-12 20:41:12 --> Output Class Initialized
INFO - 2024-02-12 20:41:12 --> Security Class Initialized
DEBUG - 2024-02-12 20:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:41:12 --> Input Class Initialized
INFO - 2024-02-12 20:41:12 --> Language Class Initialized
INFO - 2024-02-12 20:41:12 --> Loader Class Initialized
INFO - 2024-02-12 20:41:12 --> Helper loaded: url_helper
INFO - 2024-02-12 20:41:12 --> Helper loaded: file_helper
INFO - 2024-02-12 20:41:12 --> Helper loaded: form_helper
INFO - 2024-02-12 20:41:12 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:41:12 --> Controller Class Initialized
INFO - 2024-02-12 20:41:12 --> Form Validation Class Initialized
INFO - 2024-02-12 20:41:12 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:41:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:41:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:41:12 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:45:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:45:11 --> Config Class Initialized
INFO - 2024-02-12 20:45:11 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:45:11 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:45:11 --> Utf8 Class Initialized
INFO - 2024-02-12 20:45:11 --> URI Class Initialized
INFO - 2024-02-12 20:45:11 --> Router Class Initialized
INFO - 2024-02-12 20:45:11 --> Output Class Initialized
INFO - 2024-02-12 20:45:11 --> Security Class Initialized
DEBUG - 2024-02-12 20:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:45:11 --> Input Class Initialized
INFO - 2024-02-12 20:45:11 --> Language Class Initialized
INFO - 2024-02-12 20:45:11 --> Loader Class Initialized
INFO - 2024-02-12 20:45:11 --> Helper loaded: url_helper
INFO - 2024-02-12 20:45:11 --> Helper loaded: file_helper
INFO - 2024-02-12 20:45:11 --> Helper loaded: form_helper
INFO - 2024-02-12 20:45:11 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:45:11 --> Controller Class Initialized
INFO - 2024-02-12 20:45:11 --> Form Validation Class Initialized
INFO - 2024-02-12 20:45:11 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:45:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:45:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:45:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:45:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:45:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:45:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:45:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:45:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:45:11 --> Final output sent to browser
DEBUG - 2024-02-12 20:45:11 --> Total execution time: 0.0390
ERROR - 2024-02-12 20:45:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:45:12 --> Config Class Initialized
INFO - 2024-02-12 20:45:12 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:45:12 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:45:12 --> Utf8 Class Initialized
INFO - 2024-02-12 20:45:12 --> URI Class Initialized
INFO - 2024-02-12 20:45:12 --> Router Class Initialized
INFO - 2024-02-12 20:45:12 --> Output Class Initialized
INFO - 2024-02-12 20:45:12 --> Security Class Initialized
DEBUG - 2024-02-12 20:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:45:12 --> Input Class Initialized
INFO - 2024-02-12 20:45:12 --> Language Class Initialized
INFO - 2024-02-12 20:45:12 --> Loader Class Initialized
INFO - 2024-02-12 20:45:12 --> Helper loaded: url_helper
INFO - 2024-02-12 20:45:12 --> Helper loaded: file_helper
INFO - 2024-02-12 20:45:12 --> Helper loaded: form_helper
INFO - 2024-02-12 20:45:12 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:45:12 --> Controller Class Initialized
INFO - 2024-02-12 20:45:12 --> Form Validation Class Initialized
INFO - 2024-02-12 20:45:12 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:45:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:45:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:45:12 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:45:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:45:38 --> Config Class Initialized
INFO - 2024-02-12 20:45:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:45:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:45:38 --> Utf8 Class Initialized
INFO - 2024-02-12 20:45:38 --> URI Class Initialized
INFO - 2024-02-12 20:45:38 --> Router Class Initialized
INFO - 2024-02-12 20:45:38 --> Output Class Initialized
INFO - 2024-02-12 20:45:38 --> Security Class Initialized
DEBUG - 2024-02-12 20:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:45:38 --> Input Class Initialized
INFO - 2024-02-12 20:45:38 --> Language Class Initialized
INFO - 2024-02-12 20:45:38 --> Loader Class Initialized
INFO - 2024-02-12 20:45:38 --> Helper loaded: url_helper
INFO - 2024-02-12 20:45:38 --> Helper loaded: file_helper
INFO - 2024-02-12 20:45:38 --> Helper loaded: form_helper
INFO - 2024-02-12 20:45:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:45:38 --> Controller Class Initialized
INFO - 2024-02-12 20:45:38 --> Form Validation Class Initialized
INFO - 2024-02-12 20:45:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:45:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:45:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:45:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:45:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:45:38 --> Final output sent to browser
DEBUG - 2024-02-12 20:45:38 --> Total execution time: 0.0439
ERROR - 2024-02-12 20:45:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:45:55 --> Config Class Initialized
INFO - 2024-02-12 20:45:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:45:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:45:55 --> Utf8 Class Initialized
INFO - 2024-02-12 20:45:55 --> URI Class Initialized
INFO - 2024-02-12 20:45:55 --> Router Class Initialized
INFO - 2024-02-12 20:45:55 --> Output Class Initialized
INFO - 2024-02-12 20:45:55 --> Security Class Initialized
DEBUG - 2024-02-12 20:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:45:55 --> Input Class Initialized
INFO - 2024-02-12 20:45:55 --> Language Class Initialized
INFO - 2024-02-12 20:45:55 --> Loader Class Initialized
INFO - 2024-02-12 20:45:55 --> Helper loaded: url_helper
INFO - 2024-02-12 20:45:55 --> Helper loaded: file_helper
INFO - 2024-02-12 20:45:55 --> Helper loaded: form_helper
INFO - 2024-02-12 20:45:55 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:45:55 --> Controller Class Initialized
INFO - 2024-02-12 20:45:55 --> Form Validation Class Initialized
INFO - 2024-02-12 20:45:55 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:45:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:45:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:45:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:45:55 --> Upload Class Initialized
INFO - 2024-02-12 20:45:55 --> Image Lib Class Initialized
ERROR - 2024-02-12 20:45:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:45:55 --> Config Class Initialized
INFO - 2024-02-12 20:45:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:45:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:45:55 --> Utf8 Class Initialized
INFO - 2024-02-12 20:45:55 --> URI Class Initialized
INFO - 2024-02-12 20:45:55 --> Router Class Initialized
INFO - 2024-02-12 20:45:55 --> Output Class Initialized
INFO - 2024-02-12 20:45:55 --> Security Class Initialized
DEBUG - 2024-02-12 20:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:45:55 --> Input Class Initialized
INFO - 2024-02-12 20:45:55 --> Language Class Initialized
INFO - 2024-02-12 20:45:55 --> Loader Class Initialized
INFO - 2024-02-12 20:45:55 --> Helper loaded: url_helper
INFO - 2024-02-12 20:45:55 --> Helper loaded: file_helper
INFO - 2024-02-12 20:45:55 --> Helper loaded: form_helper
INFO - 2024-02-12 20:45:55 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:45:55 --> Controller Class Initialized
INFO - 2024-02-12 20:45:55 --> Form Validation Class Initialized
INFO - 2024-02-12 20:45:55 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:45:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:45:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:45:55 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:46:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:46:00 --> Config Class Initialized
INFO - 2024-02-12 20:46:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:46:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:46:00 --> Utf8 Class Initialized
INFO - 2024-02-12 20:46:00 --> URI Class Initialized
INFO - 2024-02-12 20:46:00 --> Router Class Initialized
INFO - 2024-02-12 20:46:00 --> Output Class Initialized
INFO - 2024-02-12 20:46:00 --> Security Class Initialized
DEBUG - 2024-02-12 20:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:46:00 --> Input Class Initialized
INFO - 2024-02-12 20:46:00 --> Language Class Initialized
INFO - 2024-02-12 20:46:00 --> Loader Class Initialized
INFO - 2024-02-12 20:46:00 --> Helper loaded: url_helper
INFO - 2024-02-12 20:46:00 --> Helper loaded: file_helper
INFO - 2024-02-12 20:46:00 --> Helper loaded: form_helper
INFO - 2024-02-12 20:46:00 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:46:01 --> Controller Class Initialized
INFO - 2024-02-12 20:46:01 --> Form Validation Class Initialized
INFO - 2024-02-12 20:46:01 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:46:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:46:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:46:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:46:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:46:01 --> Final output sent to browser
DEBUG - 2024-02-12 20:46:01 --> Total execution time: 0.0391
ERROR - 2024-02-12 20:49:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:49:07 --> Config Class Initialized
INFO - 2024-02-12 20:49:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:49:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:49:07 --> Utf8 Class Initialized
INFO - 2024-02-12 20:49:07 --> URI Class Initialized
INFO - 2024-02-12 20:49:07 --> Router Class Initialized
INFO - 2024-02-12 20:49:07 --> Output Class Initialized
INFO - 2024-02-12 20:49:07 --> Security Class Initialized
DEBUG - 2024-02-12 20:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:49:07 --> Input Class Initialized
INFO - 2024-02-12 20:49:07 --> Language Class Initialized
INFO - 2024-02-12 20:49:07 --> Loader Class Initialized
INFO - 2024-02-12 20:49:07 --> Helper loaded: url_helper
INFO - 2024-02-12 20:49:07 --> Helper loaded: file_helper
INFO - 2024-02-12 20:49:07 --> Helper loaded: form_helper
INFO - 2024-02-12 20:49:07 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:49:07 --> Controller Class Initialized
INFO - 2024-02-12 20:49:07 --> Form Validation Class Initialized
INFO - 2024-02-12 20:49:07 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:49:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:49:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:49:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:49:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:49:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:49:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:49:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:49:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:49:07 --> Final output sent to browser
DEBUG - 2024-02-12 20:49:07 --> Total execution time: 0.0247
ERROR - 2024-02-12 20:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:49:09 --> Config Class Initialized
INFO - 2024-02-12 20:49:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:49:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:49:09 --> Utf8 Class Initialized
INFO - 2024-02-12 20:49:09 --> URI Class Initialized
INFO - 2024-02-12 20:49:09 --> Router Class Initialized
INFO - 2024-02-12 20:49:09 --> Output Class Initialized
INFO - 2024-02-12 20:49:09 --> Security Class Initialized
DEBUG - 2024-02-12 20:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:49:09 --> Input Class Initialized
INFO - 2024-02-12 20:49:09 --> Language Class Initialized
INFO - 2024-02-12 20:49:09 --> Loader Class Initialized
INFO - 2024-02-12 20:49:09 --> Helper loaded: url_helper
INFO - 2024-02-12 20:49:09 --> Helper loaded: file_helper
INFO - 2024-02-12 20:49:09 --> Helper loaded: form_helper
INFO - 2024-02-12 20:49:09 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:49:09 --> Controller Class Initialized
INFO - 2024-02-12 20:49:09 --> Form Validation Class Initialized
INFO - 2024-02-12 20:49:09 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:49:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:49:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:49:09 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:49:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:49:11 --> Config Class Initialized
INFO - 2024-02-12 20:49:11 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:49:11 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:49:11 --> Utf8 Class Initialized
INFO - 2024-02-12 20:49:11 --> URI Class Initialized
INFO - 2024-02-12 20:49:11 --> Router Class Initialized
INFO - 2024-02-12 20:49:11 --> Output Class Initialized
INFO - 2024-02-12 20:49:11 --> Security Class Initialized
DEBUG - 2024-02-12 20:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:49:11 --> Input Class Initialized
INFO - 2024-02-12 20:49:11 --> Language Class Initialized
INFO - 2024-02-12 20:49:11 --> Loader Class Initialized
INFO - 2024-02-12 20:49:11 --> Helper loaded: url_helper
INFO - 2024-02-12 20:49:11 --> Helper loaded: file_helper
INFO - 2024-02-12 20:49:11 --> Helper loaded: form_helper
INFO - 2024-02-12 20:49:11 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:49:11 --> Controller Class Initialized
INFO - 2024-02-12 20:49:11 --> Form Validation Class Initialized
INFO - 2024-02-12 20:49:11 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:49:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:49:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:49:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:49:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:49:11 --> Final output sent to browser
DEBUG - 2024-02-12 20:49:11 --> Total execution time: 0.0427
ERROR - 2024-02-12 20:49:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:49:22 --> Config Class Initialized
INFO - 2024-02-12 20:49:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:49:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:49:22 --> Utf8 Class Initialized
INFO - 2024-02-12 20:49:22 --> URI Class Initialized
INFO - 2024-02-12 20:49:22 --> Router Class Initialized
INFO - 2024-02-12 20:49:22 --> Output Class Initialized
INFO - 2024-02-12 20:49:22 --> Security Class Initialized
DEBUG - 2024-02-12 20:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:49:22 --> Input Class Initialized
INFO - 2024-02-12 20:49:22 --> Language Class Initialized
INFO - 2024-02-12 20:49:22 --> Loader Class Initialized
INFO - 2024-02-12 20:49:22 --> Helper loaded: url_helper
INFO - 2024-02-12 20:49:22 --> Helper loaded: file_helper
INFO - 2024-02-12 20:49:22 --> Helper loaded: form_helper
INFO - 2024-02-12 20:49:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:49:22 --> Controller Class Initialized
INFO - 2024-02-12 20:49:22 --> Form Validation Class Initialized
INFO - 2024-02-12 20:49:22 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:49:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:49:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:49:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:49:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:49:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:49:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:49:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:49:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:49:22 --> Final output sent to browser
DEBUG - 2024-02-12 20:49:22 --> Total execution time: 0.0327
ERROR - 2024-02-12 20:50:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:50:15 --> Config Class Initialized
INFO - 2024-02-12 20:50:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:50:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:50:15 --> Utf8 Class Initialized
INFO - 2024-02-12 20:50:15 --> URI Class Initialized
INFO - 2024-02-12 20:50:15 --> Router Class Initialized
INFO - 2024-02-12 20:50:15 --> Output Class Initialized
INFO - 2024-02-12 20:50:15 --> Security Class Initialized
DEBUG - 2024-02-12 20:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:50:15 --> Input Class Initialized
INFO - 2024-02-12 20:50:15 --> Language Class Initialized
INFO - 2024-02-12 20:50:15 --> Loader Class Initialized
INFO - 2024-02-12 20:50:15 --> Helper loaded: url_helper
INFO - 2024-02-12 20:50:15 --> Helper loaded: file_helper
INFO - 2024-02-12 20:50:15 --> Helper loaded: form_helper
INFO - 2024-02-12 20:50:15 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:50:15 --> Controller Class Initialized
INFO - 2024-02-12 20:50:15 --> Form Validation Class Initialized
INFO - 2024-02-12 20:50:15 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:50:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:50:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:50:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:50:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:50:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:50:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:50:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:50:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:50:15 --> Final output sent to browser
DEBUG - 2024-02-12 20:50:15 --> Total execution time: 0.0315
ERROR - 2024-02-12 20:50:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:50:16 --> Config Class Initialized
INFO - 2024-02-12 20:50:16 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:50:16 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:50:16 --> Utf8 Class Initialized
INFO - 2024-02-12 20:50:16 --> URI Class Initialized
INFO - 2024-02-12 20:50:16 --> Router Class Initialized
INFO - 2024-02-12 20:50:16 --> Output Class Initialized
INFO - 2024-02-12 20:50:16 --> Security Class Initialized
DEBUG - 2024-02-12 20:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:50:16 --> Input Class Initialized
INFO - 2024-02-12 20:50:16 --> Language Class Initialized
INFO - 2024-02-12 20:50:16 --> Loader Class Initialized
INFO - 2024-02-12 20:50:16 --> Helper loaded: url_helper
INFO - 2024-02-12 20:50:16 --> Helper loaded: file_helper
INFO - 2024-02-12 20:50:16 --> Helper loaded: form_helper
INFO - 2024-02-12 20:50:16 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:50:16 --> Controller Class Initialized
INFO - 2024-02-12 20:50:16 --> Form Validation Class Initialized
INFO - 2024-02-12 20:50:16 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:50:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:50:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:50:16 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:50:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:50:19 --> Config Class Initialized
INFO - 2024-02-12 20:50:19 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:50:19 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:50:19 --> Utf8 Class Initialized
INFO - 2024-02-12 20:50:19 --> URI Class Initialized
INFO - 2024-02-12 20:50:19 --> Router Class Initialized
INFO - 2024-02-12 20:50:19 --> Output Class Initialized
INFO - 2024-02-12 20:50:19 --> Security Class Initialized
DEBUG - 2024-02-12 20:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:50:19 --> Input Class Initialized
INFO - 2024-02-12 20:50:19 --> Language Class Initialized
INFO - 2024-02-12 20:50:19 --> Loader Class Initialized
INFO - 2024-02-12 20:50:19 --> Helper loaded: url_helper
INFO - 2024-02-12 20:50:19 --> Helper loaded: file_helper
INFO - 2024-02-12 20:50:19 --> Helper loaded: form_helper
INFO - 2024-02-12 20:50:19 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:50:19 --> Controller Class Initialized
INFO - 2024-02-12 20:50:19 --> Form Validation Class Initialized
INFO - 2024-02-12 20:50:19 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:50:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:50:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:50:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:50:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:50:19 --> Final output sent to browser
DEBUG - 2024-02-12 20:50:19 --> Total execution time: 0.0433
ERROR - 2024-02-12 20:50:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:50:34 --> Config Class Initialized
INFO - 2024-02-12 20:50:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:50:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:50:34 --> Utf8 Class Initialized
INFO - 2024-02-12 20:50:34 --> URI Class Initialized
INFO - 2024-02-12 20:50:34 --> Router Class Initialized
INFO - 2024-02-12 20:50:34 --> Output Class Initialized
INFO - 2024-02-12 20:50:34 --> Security Class Initialized
DEBUG - 2024-02-12 20:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:50:34 --> Input Class Initialized
INFO - 2024-02-12 20:50:34 --> Language Class Initialized
INFO - 2024-02-12 20:50:34 --> Loader Class Initialized
INFO - 2024-02-12 20:50:34 --> Helper loaded: url_helper
INFO - 2024-02-12 20:50:34 --> Helper loaded: file_helper
INFO - 2024-02-12 20:50:34 --> Helper loaded: form_helper
INFO - 2024-02-12 20:50:34 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:50:34 --> Controller Class Initialized
INFO - 2024-02-12 20:50:34 --> Form Validation Class Initialized
INFO - 2024-02-12 20:50:34 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:50:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:50:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:50:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:50:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:50:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:50:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:50:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:50:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:50:34 --> Final output sent to browser
DEBUG - 2024-02-12 20:50:34 --> Total execution time: 0.0496
ERROR - 2024-02-12 20:51:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:51:49 --> Config Class Initialized
INFO - 2024-02-12 20:51:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:51:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:51:49 --> Utf8 Class Initialized
INFO - 2024-02-12 20:51:49 --> URI Class Initialized
INFO - 2024-02-12 20:51:49 --> Router Class Initialized
INFO - 2024-02-12 20:51:49 --> Output Class Initialized
INFO - 2024-02-12 20:51:49 --> Security Class Initialized
DEBUG - 2024-02-12 20:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:51:49 --> Input Class Initialized
INFO - 2024-02-12 20:51:49 --> Language Class Initialized
INFO - 2024-02-12 20:51:49 --> Loader Class Initialized
INFO - 2024-02-12 20:51:49 --> Helper loaded: url_helper
INFO - 2024-02-12 20:51:49 --> Helper loaded: file_helper
INFO - 2024-02-12 20:51:49 --> Helper loaded: form_helper
INFO - 2024-02-12 20:51:49 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:51:49 --> Controller Class Initialized
INFO - 2024-02-12 20:51:49 --> Form Validation Class Initialized
INFO - 2024-02-12 20:51:49 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:51:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:51:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:51:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:51:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:51:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:51:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:51:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:51:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:51:49 --> Final output sent to browser
DEBUG - 2024-02-12 20:51:49 --> Total execution time: 0.0324
ERROR - 2024-02-12 20:51:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:51:50 --> Config Class Initialized
INFO - 2024-02-12 20:51:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:51:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:51:50 --> Utf8 Class Initialized
INFO - 2024-02-12 20:51:50 --> URI Class Initialized
INFO - 2024-02-12 20:51:50 --> Router Class Initialized
INFO - 2024-02-12 20:51:50 --> Output Class Initialized
INFO - 2024-02-12 20:51:50 --> Security Class Initialized
DEBUG - 2024-02-12 20:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:51:50 --> Input Class Initialized
INFO - 2024-02-12 20:51:50 --> Language Class Initialized
INFO - 2024-02-12 20:51:50 --> Loader Class Initialized
INFO - 2024-02-12 20:51:50 --> Helper loaded: url_helper
INFO - 2024-02-12 20:51:50 --> Helper loaded: file_helper
INFO - 2024-02-12 20:51:50 --> Helper loaded: form_helper
INFO - 2024-02-12 20:51:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:51:50 --> Controller Class Initialized
INFO - 2024-02-12 20:51:50 --> Form Validation Class Initialized
INFO - 2024-02-12 20:51:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:51:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:51:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:51:50 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:51:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:51:53 --> Config Class Initialized
INFO - 2024-02-12 20:51:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:51:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:51:53 --> Utf8 Class Initialized
INFO - 2024-02-12 20:51:53 --> URI Class Initialized
INFO - 2024-02-12 20:51:53 --> Router Class Initialized
INFO - 2024-02-12 20:51:53 --> Output Class Initialized
INFO - 2024-02-12 20:51:53 --> Security Class Initialized
DEBUG - 2024-02-12 20:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:51:53 --> Input Class Initialized
INFO - 2024-02-12 20:51:53 --> Language Class Initialized
INFO - 2024-02-12 20:51:53 --> Loader Class Initialized
INFO - 2024-02-12 20:51:53 --> Helper loaded: url_helper
INFO - 2024-02-12 20:51:53 --> Helper loaded: file_helper
INFO - 2024-02-12 20:51:53 --> Helper loaded: form_helper
INFO - 2024-02-12 20:51:53 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:51:53 --> Controller Class Initialized
INFO - 2024-02-12 20:51:53 --> Form Validation Class Initialized
INFO - 2024-02-12 20:51:53 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:51:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:51:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:51:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:51:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:51:53 --> Final output sent to browser
DEBUG - 2024-02-12 20:51:53 --> Total execution time: 0.0248
ERROR - 2024-02-12 20:52:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:52:05 --> Config Class Initialized
INFO - 2024-02-12 20:52:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:52:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:52:05 --> Utf8 Class Initialized
INFO - 2024-02-12 20:52:05 --> URI Class Initialized
INFO - 2024-02-12 20:52:05 --> Router Class Initialized
INFO - 2024-02-12 20:52:05 --> Output Class Initialized
INFO - 2024-02-12 20:52:05 --> Security Class Initialized
DEBUG - 2024-02-12 20:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:52:05 --> Input Class Initialized
INFO - 2024-02-12 20:52:05 --> Language Class Initialized
INFO - 2024-02-12 20:52:05 --> Loader Class Initialized
INFO - 2024-02-12 20:52:05 --> Helper loaded: url_helper
INFO - 2024-02-12 20:52:05 --> Helper loaded: file_helper
INFO - 2024-02-12 20:52:05 --> Helper loaded: form_helper
INFO - 2024-02-12 20:52:05 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:52:05 --> Controller Class Initialized
INFO - 2024-02-12 20:52:05 --> Form Validation Class Initialized
INFO - 2024-02-12 20:52:05 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:52:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:52:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:52:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:52:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:52:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:52:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:52:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:52:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:52:05 --> Final output sent to browser
DEBUG - 2024-02-12 20:52:05 --> Total execution time: 0.0383
ERROR - 2024-02-12 20:53:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:53:01 --> Config Class Initialized
INFO - 2024-02-12 20:53:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:53:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:53:01 --> Utf8 Class Initialized
INFO - 2024-02-12 20:53:01 --> URI Class Initialized
INFO - 2024-02-12 20:53:01 --> Router Class Initialized
INFO - 2024-02-12 20:53:01 --> Output Class Initialized
INFO - 2024-02-12 20:53:01 --> Security Class Initialized
DEBUG - 2024-02-12 20:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:53:01 --> Input Class Initialized
INFO - 2024-02-12 20:53:01 --> Language Class Initialized
INFO - 2024-02-12 20:53:01 --> Loader Class Initialized
INFO - 2024-02-12 20:53:01 --> Helper loaded: url_helper
INFO - 2024-02-12 20:53:01 --> Helper loaded: file_helper
INFO - 2024-02-12 20:53:01 --> Helper loaded: form_helper
INFO - 2024-02-12 20:53:01 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:53:01 --> Controller Class Initialized
INFO - 2024-02-12 20:53:01 --> Form Validation Class Initialized
INFO - 2024-02-12 20:53:01 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:53:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:53:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:53:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:53:01 --> Upload Class Initialized
INFO - 2024-02-12 20:53:01 --> Image Lib Class Initialized
ERROR - 2024-02-12 20:53:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:53:02 --> Config Class Initialized
INFO - 2024-02-12 20:53:02 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:53:02 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:53:02 --> Utf8 Class Initialized
INFO - 2024-02-12 20:53:02 --> URI Class Initialized
INFO - 2024-02-12 20:53:02 --> Router Class Initialized
INFO - 2024-02-12 20:53:02 --> Output Class Initialized
INFO - 2024-02-12 20:53:02 --> Security Class Initialized
DEBUG - 2024-02-12 20:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:53:02 --> Input Class Initialized
INFO - 2024-02-12 20:53:02 --> Language Class Initialized
INFO - 2024-02-12 20:53:02 --> Loader Class Initialized
INFO - 2024-02-12 20:53:02 --> Helper loaded: url_helper
INFO - 2024-02-12 20:53:02 --> Helper loaded: file_helper
INFO - 2024-02-12 20:53:02 --> Helper loaded: form_helper
INFO - 2024-02-12 20:53:02 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:53:02 --> Controller Class Initialized
INFO - 2024-02-12 20:53:02 --> Form Validation Class Initialized
INFO - 2024-02-12 20:53:02 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:53:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:53:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:53:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:53:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:53:37 --> Config Class Initialized
INFO - 2024-02-12 20:53:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:53:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:53:37 --> Utf8 Class Initialized
INFO - 2024-02-12 20:53:37 --> URI Class Initialized
INFO - 2024-02-12 20:53:37 --> Router Class Initialized
INFO - 2024-02-12 20:53:37 --> Output Class Initialized
INFO - 2024-02-12 20:53:37 --> Security Class Initialized
DEBUG - 2024-02-12 20:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:53:37 --> Input Class Initialized
INFO - 2024-02-12 20:53:37 --> Language Class Initialized
INFO - 2024-02-12 20:53:37 --> Loader Class Initialized
INFO - 2024-02-12 20:53:37 --> Helper loaded: url_helper
INFO - 2024-02-12 20:53:37 --> Helper loaded: file_helper
INFO - 2024-02-12 20:53:37 --> Helper loaded: form_helper
INFO - 2024-02-12 20:53:37 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:53:37 --> Controller Class Initialized
INFO - 2024-02-12 20:53:37 --> Form Validation Class Initialized
INFO - 2024-02-12 20:53:37 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:53:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:53:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:53:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:53:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:53:37 --> Final output sent to browser
DEBUG - 2024-02-12 20:53:37 --> Total execution time: 0.0381
ERROR - 2024-02-12 20:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:53:41 --> Config Class Initialized
INFO - 2024-02-12 20:53:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:53:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:53:41 --> Utf8 Class Initialized
INFO - 2024-02-12 20:53:41 --> URI Class Initialized
INFO - 2024-02-12 20:53:41 --> Router Class Initialized
INFO - 2024-02-12 20:53:41 --> Output Class Initialized
INFO - 2024-02-12 20:53:41 --> Security Class Initialized
DEBUG - 2024-02-12 20:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:53:41 --> Input Class Initialized
INFO - 2024-02-12 20:53:41 --> Language Class Initialized
INFO - 2024-02-12 20:53:41 --> Loader Class Initialized
INFO - 2024-02-12 20:53:41 --> Helper loaded: url_helper
INFO - 2024-02-12 20:53:41 --> Helper loaded: file_helper
INFO - 2024-02-12 20:53:41 --> Helper loaded: form_helper
INFO - 2024-02-12 20:53:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:53:41 --> Controller Class Initialized
INFO - 2024-02-12 20:53:41 --> Form Validation Class Initialized
INFO - 2024-02-12 20:53:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:53:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:53:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:53:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:53:41 --> Config Class Initialized
INFO - 2024-02-12 20:53:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:53:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:53:41 --> Utf8 Class Initialized
INFO - 2024-02-12 20:53:41 --> URI Class Initialized
INFO - 2024-02-12 20:53:41 --> Router Class Initialized
INFO - 2024-02-12 20:53:41 --> Output Class Initialized
INFO - 2024-02-12 20:53:41 --> Security Class Initialized
DEBUG - 2024-02-12 20:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:53:41 --> Input Class Initialized
INFO - 2024-02-12 20:53:41 --> Language Class Initialized
INFO - 2024-02-12 20:53:41 --> Loader Class Initialized
INFO - 2024-02-12 20:53:41 --> Helper loaded: url_helper
INFO - 2024-02-12 20:53:41 --> Helper loaded: file_helper
INFO - 2024-02-12 20:53:41 --> Helper loaded: form_helper
INFO - 2024-02-12 20:53:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:53:41 --> Controller Class Initialized
INFO - 2024-02-12 20:53:41 --> Form Validation Class Initialized
INFO - 2024-02-12 20:53:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:53:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:53:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:53:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:53:46 --> Config Class Initialized
INFO - 2024-02-12 20:53:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:53:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:53:46 --> Utf8 Class Initialized
INFO - 2024-02-12 20:53:46 --> URI Class Initialized
INFO - 2024-02-12 20:53:46 --> Router Class Initialized
INFO - 2024-02-12 20:53:46 --> Output Class Initialized
INFO - 2024-02-12 20:53:46 --> Security Class Initialized
DEBUG - 2024-02-12 20:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:53:46 --> Input Class Initialized
INFO - 2024-02-12 20:53:46 --> Language Class Initialized
INFO - 2024-02-12 20:53:46 --> Loader Class Initialized
INFO - 2024-02-12 20:53:46 --> Helper loaded: url_helper
INFO - 2024-02-12 20:53:46 --> Helper loaded: file_helper
INFO - 2024-02-12 20:53:46 --> Helper loaded: form_helper
INFO - 2024-02-12 20:53:46 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:53:46 --> Controller Class Initialized
INFO - 2024-02-12 20:53:46 --> Form Validation Class Initialized
INFO - 2024-02-12 20:53:46 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:53:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:53:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:53:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:53:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:53:47 --> Config Class Initialized
INFO - 2024-02-12 20:53:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:53:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:53:47 --> Utf8 Class Initialized
INFO - 2024-02-12 20:53:47 --> URI Class Initialized
INFO - 2024-02-12 20:53:47 --> Router Class Initialized
INFO - 2024-02-12 20:53:47 --> Output Class Initialized
INFO - 2024-02-12 20:53:47 --> Security Class Initialized
DEBUG - 2024-02-12 20:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:53:47 --> Input Class Initialized
INFO - 2024-02-12 20:53:47 --> Language Class Initialized
INFO - 2024-02-12 20:53:47 --> Loader Class Initialized
INFO - 2024-02-12 20:53:47 --> Helper loaded: url_helper
INFO - 2024-02-12 20:53:47 --> Helper loaded: file_helper
INFO - 2024-02-12 20:53:47 --> Helper loaded: form_helper
INFO - 2024-02-12 20:53:47 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:53:47 --> Controller Class Initialized
INFO - 2024-02-12 20:53:47 --> Form Validation Class Initialized
INFO - 2024-02-12 20:53:47 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:53:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:53:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:53:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:54:44 --> Config Class Initialized
INFO - 2024-02-12 20:54:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:54:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:54:44 --> Utf8 Class Initialized
INFO - 2024-02-12 20:54:44 --> URI Class Initialized
INFO - 2024-02-12 20:54:44 --> Router Class Initialized
INFO - 2024-02-12 20:54:44 --> Output Class Initialized
INFO - 2024-02-12 20:54:44 --> Security Class Initialized
DEBUG - 2024-02-12 20:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:54:44 --> Input Class Initialized
INFO - 2024-02-12 20:54:44 --> Language Class Initialized
INFO - 2024-02-12 20:54:44 --> Loader Class Initialized
INFO - 2024-02-12 20:54:44 --> Helper loaded: url_helper
INFO - 2024-02-12 20:54:44 --> Helper loaded: file_helper
INFO - 2024-02-12 20:54:44 --> Helper loaded: form_helper
INFO - 2024-02-12 20:54:44 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:54:44 --> Controller Class Initialized
INFO - 2024-02-12 20:54:44 --> Form Validation Class Initialized
INFO - 2024-02-12 20:54:44 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:54:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:54:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:54:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:54:44 --> Config Class Initialized
INFO - 2024-02-12 20:54:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:54:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:54:44 --> Utf8 Class Initialized
INFO - 2024-02-12 20:54:44 --> URI Class Initialized
INFO - 2024-02-12 20:54:44 --> Router Class Initialized
INFO - 2024-02-12 20:54:44 --> Output Class Initialized
INFO - 2024-02-12 20:54:44 --> Security Class Initialized
DEBUG - 2024-02-12 20:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:54:44 --> Input Class Initialized
INFO - 2024-02-12 20:54:44 --> Language Class Initialized
INFO - 2024-02-12 20:54:44 --> Loader Class Initialized
INFO - 2024-02-12 20:54:44 --> Helper loaded: url_helper
INFO - 2024-02-12 20:54:44 --> Helper loaded: file_helper
INFO - 2024-02-12 20:54:44 --> Helper loaded: form_helper
INFO - 2024-02-12 20:54:44 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:54:44 --> Controller Class Initialized
INFO - 2024-02-12 20:54:44 --> Form Validation Class Initialized
INFO - 2024-02-12 20:54:44 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:54:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:54:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:54:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:54:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:54:48 --> Config Class Initialized
INFO - 2024-02-12 20:54:48 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:54:48 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:54:48 --> Utf8 Class Initialized
INFO - 2024-02-12 20:54:48 --> URI Class Initialized
INFO - 2024-02-12 20:54:48 --> Router Class Initialized
INFO - 2024-02-12 20:54:48 --> Output Class Initialized
INFO - 2024-02-12 20:54:48 --> Security Class Initialized
DEBUG - 2024-02-12 20:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:54:48 --> Input Class Initialized
INFO - 2024-02-12 20:54:48 --> Language Class Initialized
INFO - 2024-02-12 20:54:48 --> Loader Class Initialized
INFO - 2024-02-12 20:54:48 --> Helper loaded: url_helper
INFO - 2024-02-12 20:54:48 --> Helper loaded: file_helper
INFO - 2024-02-12 20:54:48 --> Helper loaded: form_helper
INFO - 2024-02-12 20:54:48 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:54:48 --> Controller Class Initialized
INFO - 2024-02-12 20:54:48 --> Form Validation Class Initialized
INFO - 2024-02-12 20:54:48 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:54:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:54:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:54:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:54:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:54:48 --> Final output sent to browser
DEBUG - 2024-02-12 20:54:48 --> Total execution time: 0.0310
ERROR - 2024-02-12 20:55:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:55:13 --> Config Class Initialized
INFO - 2024-02-12 20:55:13 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:55:13 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:55:13 --> Utf8 Class Initialized
INFO - 2024-02-12 20:55:13 --> URI Class Initialized
INFO - 2024-02-12 20:55:13 --> Router Class Initialized
INFO - 2024-02-12 20:55:13 --> Output Class Initialized
INFO - 2024-02-12 20:55:13 --> Security Class Initialized
DEBUG - 2024-02-12 20:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:55:13 --> Input Class Initialized
INFO - 2024-02-12 20:55:13 --> Language Class Initialized
INFO - 2024-02-12 20:55:13 --> Loader Class Initialized
INFO - 2024-02-12 20:55:13 --> Helper loaded: url_helper
INFO - 2024-02-12 20:55:13 --> Helper loaded: file_helper
INFO - 2024-02-12 20:55:13 --> Helper loaded: form_helper
INFO - 2024-02-12 20:55:13 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:55:13 --> Controller Class Initialized
INFO - 2024-02-12 20:55:13 --> Form Validation Class Initialized
INFO - 2024-02-12 20:55:13 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:55:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:55:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:55:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:55:13 --> Upload Class Initialized
INFO - 2024-02-12 20:55:13 --> Image Lib Class Initialized
ERROR - 2024-02-12 20:55:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:55:13 --> Config Class Initialized
INFO - 2024-02-12 20:55:13 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:55:13 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:55:13 --> Utf8 Class Initialized
INFO - 2024-02-12 20:55:13 --> URI Class Initialized
INFO - 2024-02-12 20:55:13 --> Router Class Initialized
INFO - 2024-02-12 20:55:13 --> Output Class Initialized
INFO - 2024-02-12 20:55:13 --> Security Class Initialized
DEBUG - 2024-02-12 20:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:55:13 --> Input Class Initialized
INFO - 2024-02-12 20:55:13 --> Language Class Initialized
INFO - 2024-02-12 20:55:13 --> Loader Class Initialized
INFO - 2024-02-12 20:55:13 --> Helper loaded: url_helper
INFO - 2024-02-12 20:55:13 --> Helper loaded: file_helper
INFO - 2024-02-12 20:55:13 --> Helper loaded: form_helper
INFO - 2024-02-12 20:55:13 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:55:13 --> Controller Class Initialized
INFO - 2024-02-12 20:55:13 --> Form Validation Class Initialized
INFO - 2024-02-12 20:55:13 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:55:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:55:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:55:13 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:55:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:55:15 --> Config Class Initialized
INFO - 2024-02-12 20:55:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:55:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:55:15 --> Utf8 Class Initialized
INFO - 2024-02-12 20:55:15 --> URI Class Initialized
INFO - 2024-02-12 20:55:15 --> Router Class Initialized
INFO - 2024-02-12 20:55:15 --> Output Class Initialized
INFO - 2024-02-12 20:55:15 --> Security Class Initialized
DEBUG - 2024-02-12 20:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:55:15 --> Input Class Initialized
INFO - 2024-02-12 20:55:15 --> Language Class Initialized
INFO - 2024-02-12 20:55:15 --> Loader Class Initialized
INFO - 2024-02-12 20:55:15 --> Helper loaded: url_helper
INFO - 2024-02-12 20:55:15 --> Helper loaded: file_helper
INFO - 2024-02-12 20:55:15 --> Helper loaded: form_helper
INFO - 2024-02-12 20:55:15 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:55:15 --> Controller Class Initialized
INFO - 2024-02-12 20:55:15 --> Form Validation Class Initialized
INFO - 2024-02-12 20:55:15 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:55:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:55:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:55:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:55:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 20:55:15 --> Final output sent to browser
DEBUG - 2024-02-12 20:55:15 --> Total execution time: 0.0403
ERROR - 2024-02-12 20:55:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:55:49 --> Config Class Initialized
INFO - 2024-02-12 20:55:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:55:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:55:49 --> Utf8 Class Initialized
INFO - 2024-02-12 20:55:49 --> URI Class Initialized
INFO - 2024-02-12 20:55:49 --> Router Class Initialized
INFO - 2024-02-12 20:55:49 --> Output Class Initialized
INFO - 2024-02-12 20:55:49 --> Security Class Initialized
DEBUG - 2024-02-12 20:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:55:49 --> Input Class Initialized
INFO - 2024-02-12 20:55:49 --> Language Class Initialized
INFO - 2024-02-12 20:55:49 --> Loader Class Initialized
INFO - 2024-02-12 20:55:49 --> Helper loaded: url_helper
INFO - 2024-02-12 20:55:49 --> Helper loaded: file_helper
INFO - 2024-02-12 20:55:49 --> Helper loaded: form_helper
INFO - 2024-02-12 20:55:49 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:55:49 --> Controller Class Initialized
INFO - 2024-02-12 20:55:49 --> Form Validation Class Initialized
INFO - 2024-02-12 20:55:49 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:55:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:55:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:55:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:55:49 --> Upload Class Initialized
INFO - 2024-02-12 20:55:49 --> Image Lib Class Initialized
ERROR - 2024-02-12 20:55:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:55:49 --> Config Class Initialized
INFO - 2024-02-12 20:55:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:55:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:55:49 --> Utf8 Class Initialized
INFO - 2024-02-12 20:55:49 --> URI Class Initialized
INFO - 2024-02-12 20:55:49 --> Router Class Initialized
INFO - 2024-02-12 20:55:49 --> Output Class Initialized
INFO - 2024-02-12 20:55:49 --> Security Class Initialized
DEBUG - 2024-02-12 20:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:55:49 --> Input Class Initialized
INFO - 2024-02-12 20:55:49 --> Language Class Initialized
INFO - 2024-02-12 20:55:49 --> Loader Class Initialized
INFO - 2024-02-12 20:55:49 --> Helper loaded: url_helper
INFO - 2024-02-12 20:55:49 --> Helper loaded: file_helper
INFO - 2024-02-12 20:55:49 --> Helper loaded: form_helper
INFO - 2024-02-12 20:55:49 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:55:49 --> Controller Class Initialized
INFO - 2024-02-12 20:55:49 --> Form Validation Class Initialized
INFO - 2024-02-12 20:55:49 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:55:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:55:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:55:49 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:56:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:56:43 --> Config Class Initialized
INFO - 2024-02-12 20:56:43 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:56:43 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:56:43 --> Utf8 Class Initialized
INFO - 2024-02-12 20:56:43 --> URI Class Initialized
INFO - 2024-02-12 20:56:43 --> Router Class Initialized
INFO - 2024-02-12 20:56:43 --> Output Class Initialized
INFO - 2024-02-12 20:56:43 --> Security Class Initialized
DEBUG - 2024-02-12 20:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:56:43 --> Input Class Initialized
INFO - 2024-02-12 20:56:43 --> Language Class Initialized
INFO - 2024-02-12 20:56:43 --> Loader Class Initialized
INFO - 2024-02-12 20:56:43 --> Helper loaded: url_helper
INFO - 2024-02-12 20:56:43 --> Helper loaded: file_helper
INFO - 2024-02-12 20:56:43 --> Helper loaded: form_helper
INFO - 2024-02-12 20:56:43 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:56:43 --> Controller Class Initialized
INFO - 2024-02-12 20:56:43 --> Form Validation Class Initialized
INFO - 2024-02-12 20:56:43 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:56:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:56:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:56:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 20:56:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 20:56:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 20:56:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 20:56:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 20:56:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 20:56:43 --> Final output sent to browser
DEBUG - 2024-02-12 20:56:43 --> Total execution time: 0.0367
ERROR - 2024-02-12 20:56:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:56:43 --> Config Class Initialized
INFO - 2024-02-12 20:56:43 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:56:43 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:56:43 --> Utf8 Class Initialized
INFO - 2024-02-12 20:56:43 --> URI Class Initialized
INFO - 2024-02-12 20:56:43 --> Router Class Initialized
INFO - 2024-02-12 20:56:43 --> Output Class Initialized
INFO - 2024-02-12 20:56:43 --> Security Class Initialized
DEBUG - 2024-02-12 20:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:56:43 --> Input Class Initialized
INFO - 2024-02-12 20:56:43 --> Language Class Initialized
INFO - 2024-02-12 20:56:43 --> Loader Class Initialized
INFO - 2024-02-12 20:56:43 --> Helper loaded: url_helper
INFO - 2024-02-12 20:56:43 --> Helper loaded: file_helper
INFO - 2024-02-12 20:56:43 --> Helper loaded: form_helper
INFO - 2024-02-12 20:56:43 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:56:43 --> Controller Class Initialized
INFO - 2024-02-12 20:56:43 --> Form Validation Class Initialized
INFO - 2024-02-12 20:56:43 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:56:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:56:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:56:43 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:56:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:56:46 --> Config Class Initialized
INFO - 2024-02-12 20:56:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:56:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:56:46 --> Utf8 Class Initialized
INFO - 2024-02-12 20:56:46 --> URI Class Initialized
INFO - 2024-02-12 20:56:46 --> Router Class Initialized
INFO - 2024-02-12 20:56:46 --> Output Class Initialized
INFO - 2024-02-12 20:56:46 --> Security Class Initialized
DEBUG - 2024-02-12 20:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:56:46 --> Input Class Initialized
INFO - 2024-02-12 20:56:46 --> Language Class Initialized
INFO - 2024-02-12 20:56:46 --> Loader Class Initialized
INFO - 2024-02-12 20:56:46 --> Helper loaded: url_helper
INFO - 2024-02-12 20:56:46 --> Helper loaded: file_helper
INFO - 2024-02-12 20:56:46 --> Helper loaded: form_helper
INFO - 2024-02-12 20:56:46 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:56:46 --> Controller Class Initialized
INFO - 2024-02-12 20:56:46 --> Form Validation Class Initialized
INFO - 2024-02-12 20:56:46 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:56:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:56:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:56:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 20:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 20:56:49 --> Config Class Initialized
INFO - 2024-02-12 20:56:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 20:56:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 20:56:49 --> Utf8 Class Initialized
INFO - 2024-02-12 20:56:49 --> URI Class Initialized
INFO - 2024-02-12 20:56:49 --> Router Class Initialized
INFO - 2024-02-12 20:56:49 --> Output Class Initialized
INFO - 2024-02-12 20:56:49 --> Security Class Initialized
DEBUG - 2024-02-12 20:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 20:56:49 --> Input Class Initialized
INFO - 2024-02-12 20:56:49 --> Language Class Initialized
INFO - 2024-02-12 20:56:49 --> Loader Class Initialized
INFO - 2024-02-12 20:56:49 --> Helper loaded: url_helper
INFO - 2024-02-12 20:56:49 --> Helper loaded: file_helper
INFO - 2024-02-12 20:56:49 --> Helper loaded: form_helper
INFO - 2024-02-12 20:56:49 --> Database Driver Class Initialized
DEBUG - 2024-02-12 20:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 20:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 20:56:49 --> Controller Class Initialized
INFO - 2024-02-12 20:56:49 --> Form Validation Class Initialized
INFO - 2024-02-12 20:56:49 --> Model "MasterModel" initialized
INFO - 2024-02-12 20:56:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 20:56:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 20:56:49 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:00:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:00:55 --> Config Class Initialized
INFO - 2024-02-12 21:00:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:00:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:00:55 --> Utf8 Class Initialized
INFO - 2024-02-12 21:00:55 --> URI Class Initialized
INFO - 2024-02-12 21:00:55 --> Router Class Initialized
INFO - 2024-02-12 21:00:55 --> Output Class Initialized
INFO - 2024-02-12 21:00:55 --> Security Class Initialized
DEBUG - 2024-02-12 21:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:00:55 --> Input Class Initialized
INFO - 2024-02-12 21:00:55 --> Language Class Initialized
INFO - 2024-02-12 21:00:55 --> Loader Class Initialized
INFO - 2024-02-12 21:00:55 --> Helper loaded: url_helper
INFO - 2024-02-12 21:00:55 --> Helper loaded: file_helper
INFO - 2024-02-12 21:00:55 --> Helper loaded: form_helper
INFO - 2024-02-12 21:00:55 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:00:55 --> Controller Class Initialized
INFO - 2024-02-12 21:00:55 --> Form Validation Class Initialized
INFO - 2024-02-12 21:00:55 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:00:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:00:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:00:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:00:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 21:00:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 21:00:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 21:00:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 21:00:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 21:00:55 --> Final output sent to browser
DEBUG - 2024-02-12 21:00:55 --> Total execution time: 0.0310
ERROR - 2024-02-12 21:00:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:00:56 --> Config Class Initialized
INFO - 2024-02-12 21:00:56 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:00:56 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:00:56 --> Utf8 Class Initialized
INFO - 2024-02-12 21:00:56 --> URI Class Initialized
INFO - 2024-02-12 21:00:56 --> Router Class Initialized
INFO - 2024-02-12 21:00:56 --> Output Class Initialized
INFO - 2024-02-12 21:00:56 --> Security Class Initialized
DEBUG - 2024-02-12 21:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:00:56 --> Input Class Initialized
INFO - 2024-02-12 21:00:56 --> Language Class Initialized
INFO - 2024-02-12 21:00:56 --> Loader Class Initialized
INFO - 2024-02-12 21:00:56 --> Helper loaded: url_helper
INFO - 2024-02-12 21:00:56 --> Helper loaded: file_helper
INFO - 2024-02-12 21:00:56 --> Helper loaded: form_helper
INFO - 2024-02-12 21:00:56 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:00:56 --> Controller Class Initialized
INFO - 2024-02-12 21:00:56 --> Form Validation Class Initialized
INFO - 2024-02-12 21:00:56 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:00:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:00:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:00:56 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:01:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:01:04 --> Config Class Initialized
INFO - 2024-02-12 21:01:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:01:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:01:04 --> Utf8 Class Initialized
INFO - 2024-02-12 21:01:04 --> URI Class Initialized
INFO - 2024-02-12 21:01:04 --> Router Class Initialized
INFO - 2024-02-12 21:01:04 --> Output Class Initialized
INFO - 2024-02-12 21:01:04 --> Security Class Initialized
DEBUG - 2024-02-12 21:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:01:04 --> Input Class Initialized
INFO - 2024-02-12 21:01:04 --> Language Class Initialized
INFO - 2024-02-12 21:01:04 --> Loader Class Initialized
INFO - 2024-02-12 21:01:04 --> Helper loaded: url_helper
INFO - 2024-02-12 21:01:04 --> Helper loaded: file_helper
INFO - 2024-02-12 21:01:04 --> Helper loaded: form_helper
INFO - 2024-02-12 21:01:04 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:01:04 --> Controller Class Initialized
INFO - 2024-02-12 21:01:04 --> Form Validation Class Initialized
INFO - 2024-02-12 21:01:04 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:01:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:01:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:01:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:01:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 21:01:04 --> Final output sent to browser
DEBUG - 2024-02-12 21:01:04 --> Total execution time: 0.0406
ERROR - 2024-02-12 21:01:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:01:07 --> Config Class Initialized
INFO - 2024-02-12 21:01:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:01:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:01:07 --> Utf8 Class Initialized
INFO - 2024-02-12 21:01:07 --> URI Class Initialized
INFO - 2024-02-12 21:01:07 --> Router Class Initialized
INFO - 2024-02-12 21:01:07 --> Output Class Initialized
INFO - 2024-02-12 21:01:07 --> Security Class Initialized
DEBUG - 2024-02-12 21:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:01:07 --> Input Class Initialized
INFO - 2024-02-12 21:01:07 --> Language Class Initialized
INFO - 2024-02-12 21:01:07 --> Loader Class Initialized
INFO - 2024-02-12 21:01:07 --> Helper loaded: url_helper
INFO - 2024-02-12 21:01:07 --> Helper loaded: file_helper
INFO - 2024-02-12 21:01:07 --> Helper loaded: form_helper
INFO - 2024-02-12 21:01:07 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:01:07 --> Controller Class Initialized
INFO - 2024-02-12 21:01:07 --> Form Validation Class Initialized
INFO - 2024-02-12 21:01:07 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:01:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:01:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:01:07 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:01:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:01:07 --> Config Class Initialized
INFO - 2024-02-12 21:01:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:01:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:01:07 --> Utf8 Class Initialized
INFO - 2024-02-12 21:01:07 --> URI Class Initialized
INFO - 2024-02-12 21:01:07 --> Router Class Initialized
INFO - 2024-02-12 21:01:07 --> Output Class Initialized
INFO - 2024-02-12 21:01:07 --> Security Class Initialized
DEBUG - 2024-02-12 21:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:01:07 --> Input Class Initialized
INFO - 2024-02-12 21:01:07 --> Language Class Initialized
INFO - 2024-02-12 21:01:07 --> Loader Class Initialized
INFO - 2024-02-12 21:01:07 --> Helper loaded: url_helper
INFO - 2024-02-12 21:01:07 --> Helper loaded: file_helper
INFO - 2024-02-12 21:01:07 --> Helper loaded: form_helper
INFO - 2024-02-12 21:01:07 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:01:07 --> Controller Class Initialized
INFO - 2024-02-12 21:01:07 --> Form Validation Class Initialized
INFO - 2024-02-12 21:01:07 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:01:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:01:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:01:07 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:01:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:01:18 --> Config Class Initialized
INFO - 2024-02-12 21:01:18 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:01:18 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:01:18 --> Utf8 Class Initialized
INFO - 2024-02-12 21:01:18 --> URI Class Initialized
INFO - 2024-02-12 21:01:18 --> Router Class Initialized
INFO - 2024-02-12 21:01:18 --> Output Class Initialized
INFO - 2024-02-12 21:01:18 --> Security Class Initialized
DEBUG - 2024-02-12 21:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:01:18 --> Input Class Initialized
INFO - 2024-02-12 21:01:18 --> Language Class Initialized
INFO - 2024-02-12 21:01:18 --> Loader Class Initialized
INFO - 2024-02-12 21:01:18 --> Helper loaded: url_helper
INFO - 2024-02-12 21:01:18 --> Helper loaded: file_helper
INFO - 2024-02-12 21:01:18 --> Helper loaded: form_helper
INFO - 2024-02-12 21:01:18 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:01:18 --> Controller Class Initialized
INFO - 2024-02-12 21:01:18 --> Form Validation Class Initialized
INFO - 2024-02-12 21:01:18 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:01:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:01:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:01:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:01:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 21:01:18 --> Final output sent to browser
DEBUG - 2024-02-12 21:01:18 --> Total execution time: 0.0319
ERROR - 2024-02-12 21:01:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:01:31 --> Config Class Initialized
INFO - 2024-02-12 21:01:31 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:01:31 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:01:31 --> Utf8 Class Initialized
INFO - 2024-02-12 21:01:31 --> URI Class Initialized
INFO - 2024-02-12 21:01:31 --> Router Class Initialized
INFO - 2024-02-12 21:01:31 --> Output Class Initialized
INFO - 2024-02-12 21:01:31 --> Security Class Initialized
DEBUG - 2024-02-12 21:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:01:31 --> Input Class Initialized
INFO - 2024-02-12 21:01:31 --> Language Class Initialized
INFO - 2024-02-12 21:01:31 --> Loader Class Initialized
INFO - 2024-02-12 21:01:31 --> Helper loaded: url_helper
INFO - 2024-02-12 21:01:31 --> Helper loaded: file_helper
INFO - 2024-02-12 21:01:31 --> Helper loaded: form_helper
INFO - 2024-02-12 21:01:31 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:01:31 --> Controller Class Initialized
INFO - 2024-02-12 21:01:31 --> Form Validation Class Initialized
INFO - 2024-02-12 21:01:31 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:01:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:01:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:01:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:01:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:01:31 --> Config Class Initialized
INFO - 2024-02-12 21:01:31 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:01:31 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:01:31 --> Utf8 Class Initialized
INFO - 2024-02-12 21:01:31 --> URI Class Initialized
INFO - 2024-02-12 21:01:31 --> Router Class Initialized
INFO - 2024-02-12 21:01:31 --> Output Class Initialized
INFO - 2024-02-12 21:01:31 --> Security Class Initialized
DEBUG - 2024-02-12 21:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:01:31 --> Input Class Initialized
INFO - 2024-02-12 21:01:31 --> Language Class Initialized
INFO - 2024-02-12 21:01:32 --> Loader Class Initialized
INFO - 2024-02-12 21:01:32 --> Helper loaded: url_helper
INFO - 2024-02-12 21:01:32 --> Helper loaded: file_helper
INFO - 2024-02-12 21:01:32 --> Helper loaded: form_helper
INFO - 2024-02-12 21:01:32 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:01:32 --> Controller Class Initialized
INFO - 2024-02-12 21:01:32 --> Form Validation Class Initialized
INFO - 2024-02-12 21:01:32 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:01:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:01:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:01:32 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:02:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:02:46 --> Config Class Initialized
INFO - 2024-02-12 21:02:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:02:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:02:46 --> Utf8 Class Initialized
INFO - 2024-02-12 21:02:46 --> URI Class Initialized
INFO - 2024-02-12 21:02:46 --> Router Class Initialized
INFO - 2024-02-12 21:02:46 --> Output Class Initialized
INFO - 2024-02-12 21:02:46 --> Security Class Initialized
DEBUG - 2024-02-12 21:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:02:46 --> Input Class Initialized
INFO - 2024-02-12 21:02:46 --> Language Class Initialized
INFO - 2024-02-12 21:02:46 --> Loader Class Initialized
INFO - 2024-02-12 21:02:46 --> Helper loaded: url_helper
INFO - 2024-02-12 21:02:46 --> Helper loaded: file_helper
INFO - 2024-02-12 21:02:46 --> Helper loaded: form_helper
INFO - 2024-02-12 21:02:46 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:02:46 --> Controller Class Initialized
INFO - 2024-02-12 21:02:46 --> Form Validation Class Initialized
INFO - 2024-02-12 21:02:46 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:02:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:02:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:02:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:02:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 21:02:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 21:02:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 21:02:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 21:02:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 21:02:46 --> Final output sent to browser
DEBUG - 2024-02-12 21:02:46 --> Total execution time: 0.0238
ERROR - 2024-02-12 21:02:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:02:46 --> Config Class Initialized
INFO - 2024-02-12 21:02:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:02:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:02:46 --> Utf8 Class Initialized
INFO - 2024-02-12 21:02:46 --> URI Class Initialized
INFO - 2024-02-12 21:02:46 --> Router Class Initialized
INFO - 2024-02-12 21:02:46 --> Output Class Initialized
INFO - 2024-02-12 21:02:46 --> Security Class Initialized
DEBUG - 2024-02-12 21:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:02:46 --> Input Class Initialized
INFO - 2024-02-12 21:02:46 --> Language Class Initialized
INFO - 2024-02-12 21:02:46 --> Loader Class Initialized
INFO - 2024-02-12 21:02:46 --> Helper loaded: url_helper
INFO - 2024-02-12 21:02:46 --> Helper loaded: file_helper
INFO - 2024-02-12 21:02:46 --> Helper loaded: form_helper
INFO - 2024-02-12 21:02:46 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:02:46 --> Controller Class Initialized
INFO - 2024-02-12 21:02:46 --> Form Validation Class Initialized
INFO - 2024-02-12 21:02:46 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:02:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:02:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:02:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:02:50 --> Config Class Initialized
INFO - 2024-02-12 21:02:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:02:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:02:50 --> Utf8 Class Initialized
INFO - 2024-02-12 21:02:50 --> URI Class Initialized
INFO - 2024-02-12 21:02:50 --> Router Class Initialized
INFO - 2024-02-12 21:02:50 --> Output Class Initialized
INFO - 2024-02-12 21:02:50 --> Security Class Initialized
DEBUG - 2024-02-12 21:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:02:50 --> Input Class Initialized
INFO - 2024-02-12 21:02:50 --> Language Class Initialized
INFO - 2024-02-12 21:02:50 --> Loader Class Initialized
INFO - 2024-02-12 21:02:50 --> Helper loaded: url_helper
INFO - 2024-02-12 21:02:50 --> Helper loaded: file_helper
INFO - 2024-02-12 21:02:50 --> Helper loaded: form_helper
INFO - 2024-02-12 21:02:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:02:50 --> Controller Class Initialized
INFO - 2024-02-12 21:02:50 --> Form Validation Class Initialized
INFO - 2024-02-12 21:02:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:02:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:02:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:02:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:02:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 21:02:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 21:02:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 21:02:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 21:02:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 21:02:51 --> Final output sent to browser
DEBUG - 2024-02-12 21:02:51 --> Total execution time: 0.0310
ERROR - 2024-02-12 21:03:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:03:50 --> Config Class Initialized
INFO - 2024-02-12 21:03:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:03:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:03:50 --> Utf8 Class Initialized
INFO - 2024-02-12 21:03:50 --> URI Class Initialized
INFO - 2024-02-12 21:03:50 --> Router Class Initialized
INFO - 2024-02-12 21:03:50 --> Output Class Initialized
INFO - 2024-02-12 21:03:50 --> Security Class Initialized
DEBUG - 2024-02-12 21:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:03:50 --> Input Class Initialized
INFO - 2024-02-12 21:03:50 --> Language Class Initialized
INFO - 2024-02-12 21:03:50 --> Loader Class Initialized
INFO - 2024-02-12 21:03:50 --> Helper loaded: url_helper
INFO - 2024-02-12 21:03:50 --> Helper loaded: file_helper
INFO - 2024-02-12 21:03:50 --> Helper loaded: form_helper
INFO - 2024-02-12 21:03:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:03:50 --> Controller Class Initialized
INFO - 2024-02-12 21:03:50 --> Form Validation Class Initialized
INFO - 2024-02-12 21:03:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:03:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:03:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:03:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:03:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 21:03:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 21:03:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 21:03:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 21:03:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 21:03:50 --> Final output sent to browser
DEBUG - 2024-02-12 21:03:50 --> Total execution time: 0.0315
ERROR - 2024-02-12 21:03:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:03:50 --> Config Class Initialized
INFO - 2024-02-12 21:03:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:03:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:03:50 --> Utf8 Class Initialized
INFO - 2024-02-12 21:03:50 --> URI Class Initialized
INFO - 2024-02-12 21:03:50 --> Router Class Initialized
INFO - 2024-02-12 21:03:50 --> Output Class Initialized
INFO - 2024-02-12 21:03:50 --> Security Class Initialized
DEBUG - 2024-02-12 21:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:03:50 --> Input Class Initialized
INFO - 2024-02-12 21:03:50 --> Language Class Initialized
INFO - 2024-02-12 21:03:50 --> Loader Class Initialized
INFO - 2024-02-12 21:03:50 --> Helper loaded: url_helper
INFO - 2024-02-12 21:03:50 --> Helper loaded: file_helper
INFO - 2024-02-12 21:03:50 --> Helper loaded: form_helper
INFO - 2024-02-12 21:03:50 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:03:50 --> Controller Class Initialized
INFO - 2024-02-12 21:03:50 --> Form Validation Class Initialized
INFO - 2024-02-12 21:03:50 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:03:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:03:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:03:50 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:03:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:03:51 --> Config Class Initialized
INFO - 2024-02-12 21:03:51 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:03:51 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:03:51 --> Utf8 Class Initialized
INFO - 2024-02-12 21:03:51 --> URI Class Initialized
INFO - 2024-02-12 21:03:51 --> Router Class Initialized
INFO - 2024-02-12 21:03:51 --> Output Class Initialized
INFO - 2024-02-12 21:03:51 --> Security Class Initialized
DEBUG - 2024-02-12 21:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:03:51 --> Input Class Initialized
INFO - 2024-02-12 21:03:51 --> Language Class Initialized
INFO - 2024-02-12 21:03:51 --> Loader Class Initialized
INFO - 2024-02-12 21:03:51 --> Helper loaded: url_helper
INFO - 2024-02-12 21:03:51 --> Helper loaded: file_helper
INFO - 2024-02-12 21:03:51 --> Helper loaded: form_helper
INFO - 2024-02-12 21:03:51 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:03:51 --> Controller Class Initialized
INFO - 2024-02-12 21:03:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-12 21:03:51 --> Final output sent to browser
DEBUG - 2024-02-12 21:03:51 --> Total execution time: 0.0244
ERROR - 2024-02-12 21:03:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:03:54 --> Config Class Initialized
INFO - 2024-02-12 21:03:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:03:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:03:54 --> Utf8 Class Initialized
INFO - 2024-02-12 21:03:54 --> URI Class Initialized
INFO - 2024-02-12 21:03:54 --> Router Class Initialized
INFO - 2024-02-12 21:03:54 --> Output Class Initialized
INFO - 2024-02-12 21:03:54 --> Security Class Initialized
DEBUG - 2024-02-12 21:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:03:54 --> Input Class Initialized
INFO - 2024-02-12 21:03:54 --> Language Class Initialized
INFO - 2024-02-12 21:03:54 --> Loader Class Initialized
INFO - 2024-02-12 21:03:54 --> Helper loaded: url_helper
INFO - 2024-02-12 21:03:54 --> Helper loaded: file_helper
INFO - 2024-02-12 21:03:54 --> Helper loaded: form_helper
INFO - 2024-02-12 21:03:54 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:03:54 --> Controller Class Initialized
INFO - 2024-02-12 21:03:54 --> Form Validation Class Initialized
INFO - 2024-02-12 21:03:54 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:03:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:03:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:03:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:03:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 21:03:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 21:03:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 21:03:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 21:03:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 21:03:54 --> Final output sent to browser
DEBUG - 2024-02-12 21:03:54 --> Total execution time: 0.0337
ERROR - 2024-02-12 21:05:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:05:17 --> Config Class Initialized
INFO - 2024-02-12 21:05:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:05:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:05:17 --> Utf8 Class Initialized
INFO - 2024-02-12 21:05:17 --> URI Class Initialized
INFO - 2024-02-12 21:05:17 --> Router Class Initialized
INFO - 2024-02-12 21:05:17 --> Output Class Initialized
INFO - 2024-02-12 21:05:17 --> Security Class Initialized
DEBUG - 2024-02-12 21:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:05:17 --> Input Class Initialized
INFO - 2024-02-12 21:05:17 --> Language Class Initialized
INFO - 2024-02-12 21:05:17 --> Loader Class Initialized
INFO - 2024-02-12 21:05:17 --> Helper loaded: url_helper
INFO - 2024-02-12 21:05:17 --> Helper loaded: file_helper
INFO - 2024-02-12 21:05:17 --> Helper loaded: form_helper
INFO - 2024-02-12 21:05:17 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:05:17 --> Controller Class Initialized
INFO - 2024-02-12 21:05:17 --> Form Validation Class Initialized
INFO - 2024-02-12 21:05:17 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:05:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:05:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:05:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:05:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 21:05:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 21:05:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 21:05:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 21:05:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 21:05:17 --> Final output sent to browser
DEBUG - 2024-02-12 21:05:17 --> Total execution time: 0.0361
ERROR - 2024-02-12 21:05:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:05:18 --> Config Class Initialized
INFO - 2024-02-12 21:05:18 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:05:18 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:05:18 --> Utf8 Class Initialized
INFO - 2024-02-12 21:05:18 --> URI Class Initialized
INFO - 2024-02-12 21:05:18 --> Router Class Initialized
INFO - 2024-02-12 21:05:18 --> Output Class Initialized
INFO - 2024-02-12 21:05:18 --> Security Class Initialized
DEBUG - 2024-02-12 21:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:05:18 --> Input Class Initialized
INFO - 2024-02-12 21:05:18 --> Language Class Initialized
INFO - 2024-02-12 21:05:18 --> Loader Class Initialized
INFO - 2024-02-12 21:05:18 --> Helper loaded: url_helper
INFO - 2024-02-12 21:05:18 --> Helper loaded: file_helper
INFO - 2024-02-12 21:05:18 --> Helper loaded: form_helper
INFO - 2024-02-12 21:05:18 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:05:18 --> Controller Class Initialized
INFO - 2024-02-12 21:05:18 --> Form Validation Class Initialized
INFO - 2024-02-12 21:05:18 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:05:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:05:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:05:18 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:05:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:05:22 --> Config Class Initialized
INFO - 2024-02-12 21:05:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:05:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:05:22 --> Utf8 Class Initialized
INFO - 2024-02-12 21:05:22 --> URI Class Initialized
INFO - 2024-02-12 21:05:22 --> Router Class Initialized
INFO - 2024-02-12 21:05:22 --> Output Class Initialized
INFO - 2024-02-12 21:05:22 --> Security Class Initialized
DEBUG - 2024-02-12 21:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:05:22 --> Input Class Initialized
INFO - 2024-02-12 21:05:22 --> Language Class Initialized
INFO - 2024-02-12 21:05:22 --> Loader Class Initialized
INFO - 2024-02-12 21:05:22 --> Helper loaded: url_helper
INFO - 2024-02-12 21:05:22 --> Helper loaded: file_helper
INFO - 2024-02-12 21:05:22 --> Helper loaded: form_helper
INFO - 2024-02-12 21:05:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:05:22 --> Controller Class Initialized
INFO - 2024-02-12 21:05:22 --> Form Validation Class Initialized
INFO - 2024-02-12 21:05:22 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:05:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:05:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:05:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:05:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:05:24 --> Config Class Initialized
INFO - 2024-02-12 21:05:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:05:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:05:24 --> Utf8 Class Initialized
INFO - 2024-02-12 21:05:24 --> URI Class Initialized
INFO - 2024-02-12 21:05:24 --> Router Class Initialized
INFO - 2024-02-12 21:05:24 --> Output Class Initialized
INFO - 2024-02-12 21:05:24 --> Security Class Initialized
DEBUG - 2024-02-12 21:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:05:24 --> Input Class Initialized
INFO - 2024-02-12 21:05:24 --> Language Class Initialized
INFO - 2024-02-12 21:05:24 --> Loader Class Initialized
INFO - 2024-02-12 21:05:24 --> Helper loaded: url_helper
INFO - 2024-02-12 21:05:24 --> Helper loaded: file_helper
INFO - 2024-02-12 21:05:24 --> Helper loaded: form_helper
INFO - 2024-02-12 21:05:24 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:05:24 --> Controller Class Initialized
INFO - 2024-02-12 21:05:24 --> Form Validation Class Initialized
INFO - 2024-02-12 21:05:24 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:05:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:05:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:05:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:05:41 --> Config Class Initialized
INFO - 2024-02-12 21:05:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:05:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:05:41 --> Utf8 Class Initialized
INFO - 2024-02-12 21:05:41 --> URI Class Initialized
INFO - 2024-02-12 21:05:41 --> Router Class Initialized
INFO - 2024-02-12 21:05:41 --> Output Class Initialized
INFO - 2024-02-12 21:05:41 --> Security Class Initialized
DEBUG - 2024-02-12 21:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:05:41 --> Input Class Initialized
INFO - 2024-02-12 21:05:41 --> Language Class Initialized
INFO - 2024-02-12 21:05:41 --> Loader Class Initialized
INFO - 2024-02-12 21:05:41 --> Helper loaded: url_helper
INFO - 2024-02-12 21:05:41 --> Helper loaded: file_helper
INFO - 2024-02-12 21:05:41 --> Helper loaded: form_helper
INFO - 2024-02-12 21:05:41 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:05:41 --> Controller Class Initialized
INFO - 2024-02-12 21:05:41 --> Form Validation Class Initialized
INFO - 2024-02-12 21:05:41 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:05:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:05:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:05:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:05:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:05:44 --> Config Class Initialized
INFO - 2024-02-12 21:05:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:05:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:05:44 --> Utf8 Class Initialized
INFO - 2024-02-12 21:05:44 --> URI Class Initialized
INFO - 2024-02-12 21:05:44 --> Router Class Initialized
INFO - 2024-02-12 21:05:44 --> Output Class Initialized
INFO - 2024-02-12 21:05:44 --> Security Class Initialized
DEBUG - 2024-02-12 21:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:05:44 --> Input Class Initialized
INFO - 2024-02-12 21:05:44 --> Language Class Initialized
INFO - 2024-02-12 21:05:44 --> Loader Class Initialized
INFO - 2024-02-12 21:05:44 --> Helper loaded: url_helper
INFO - 2024-02-12 21:05:44 --> Helper loaded: file_helper
INFO - 2024-02-12 21:05:44 --> Helper loaded: form_helper
INFO - 2024-02-12 21:05:44 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:05:44 --> Controller Class Initialized
INFO - 2024-02-12 21:05:44 --> Form Validation Class Initialized
INFO - 2024-02-12 21:05:44 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:05:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:05:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:05:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:06:22 --> Config Class Initialized
INFO - 2024-02-12 21:06:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:06:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:06:22 --> Utf8 Class Initialized
INFO - 2024-02-12 21:06:22 --> URI Class Initialized
INFO - 2024-02-12 21:06:22 --> Router Class Initialized
INFO - 2024-02-12 21:06:22 --> Output Class Initialized
INFO - 2024-02-12 21:06:22 --> Security Class Initialized
DEBUG - 2024-02-12 21:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:06:22 --> Input Class Initialized
INFO - 2024-02-12 21:06:22 --> Language Class Initialized
INFO - 2024-02-12 21:06:22 --> Loader Class Initialized
INFO - 2024-02-12 21:06:22 --> Helper loaded: url_helper
INFO - 2024-02-12 21:06:22 --> Helper loaded: file_helper
INFO - 2024-02-12 21:06:22 --> Helper loaded: form_helper
INFO - 2024-02-12 21:06:22 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:06:22 --> Controller Class Initialized
INFO - 2024-02-12 21:06:22 --> Form Validation Class Initialized
INFO - 2024-02-12 21:06:22 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:06:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:06:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:06:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:06:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 21:06:22 --> Final output sent to browser
DEBUG - 2024-02-12 21:06:22 --> Total execution time: 0.0282
ERROR - 2024-02-12 21:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:06:30 --> Config Class Initialized
INFO - 2024-02-12 21:06:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:06:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:06:30 --> Utf8 Class Initialized
INFO - 2024-02-12 21:06:30 --> URI Class Initialized
INFO - 2024-02-12 21:06:30 --> Router Class Initialized
INFO - 2024-02-12 21:06:30 --> Output Class Initialized
INFO - 2024-02-12 21:06:30 --> Security Class Initialized
DEBUG - 2024-02-12 21:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:06:30 --> Input Class Initialized
INFO - 2024-02-12 21:06:30 --> Language Class Initialized
INFO - 2024-02-12 21:06:30 --> Loader Class Initialized
INFO - 2024-02-12 21:06:30 --> Helper loaded: url_helper
INFO - 2024-02-12 21:06:30 --> Helper loaded: file_helper
INFO - 2024-02-12 21:06:30 --> Helper loaded: form_helper
INFO - 2024-02-12 21:06:30 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:06:30 --> Controller Class Initialized
INFO - 2024-02-12 21:06:30 --> Form Validation Class Initialized
INFO - 2024-02-12 21:06:30 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:06:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:06:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:06:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:06:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 21:06:30 --> Final output sent to browser
DEBUG - 2024-02-12 21:06:30 --> Total execution time: 0.0338
ERROR - 2024-02-12 21:06:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:06:36 --> Config Class Initialized
INFO - 2024-02-12 21:06:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:06:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:06:36 --> Utf8 Class Initialized
INFO - 2024-02-12 21:06:36 --> URI Class Initialized
INFO - 2024-02-12 21:06:36 --> Router Class Initialized
INFO - 2024-02-12 21:06:36 --> Output Class Initialized
INFO - 2024-02-12 21:06:36 --> Security Class Initialized
DEBUG - 2024-02-12 21:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:06:36 --> Input Class Initialized
INFO - 2024-02-12 21:06:36 --> Language Class Initialized
INFO - 2024-02-12 21:06:36 --> Loader Class Initialized
INFO - 2024-02-12 21:06:36 --> Helper loaded: url_helper
INFO - 2024-02-12 21:06:36 --> Helper loaded: file_helper
INFO - 2024-02-12 21:06:36 --> Helper loaded: form_helper
INFO - 2024-02-12 21:06:36 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:06:36 --> Controller Class Initialized
INFO - 2024-02-12 21:06:36 --> Form Validation Class Initialized
INFO - 2024-02-12 21:06:36 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:06:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:06:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:06:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:06:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 21:06:36 --> Final output sent to browser
DEBUG - 2024-02-12 21:06:36 --> Total execution time: 0.0341
ERROR - 2024-02-12 21:07:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:07:29 --> Config Class Initialized
INFO - 2024-02-12 21:07:29 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:07:29 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:07:29 --> Utf8 Class Initialized
INFO - 2024-02-12 21:07:29 --> URI Class Initialized
INFO - 2024-02-12 21:07:29 --> Router Class Initialized
INFO - 2024-02-12 21:07:29 --> Output Class Initialized
INFO - 2024-02-12 21:07:29 --> Security Class Initialized
DEBUG - 2024-02-12 21:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:07:29 --> Input Class Initialized
INFO - 2024-02-12 21:07:29 --> Language Class Initialized
INFO - 2024-02-12 21:07:29 --> Loader Class Initialized
INFO - 2024-02-12 21:07:29 --> Helper loaded: url_helper
INFO - 2024-02-12 21:07:29 --> Helper loaded: file_helper
INFO - 2024-02-12 21:07:29 --> Helper loaded: form_helper
INFO - 2024-02-12 21:07:29 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:07:29 --> Controller Class Initialized
INFO - 2024-02-12 21:07:29 --> Form Validation Class Initialized
INFO - 2024-02-12 21:07:29 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:07:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:07:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:07:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:07:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-12 21:07:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-12 21:07:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-12 21:07:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-12 21:07:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-12 21:07:29 --> Final output sent to browser
DEBUG - 2024-02-12 21:07:29 --> Total execution time: 0.0222
ERROR - 2024-02-12 21:07:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:07:34 --> Config Class Initialized
INFO - 2024-02-12 21:07:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:07:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:07:34 --> Utf8 Class Initialized
INFO - 2024-02-12 21:07:34 --> URI Class Initialized
INFO - 2024-02-12 21:07:34 --> Router Class Initialized
INFO - 2024-02-12 21:07:34 --> Output Class Initialized
INFO - 2024-02-12 21:07:34 --> Security Class Initialized
DEBUG - 2024-02-12 21:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:07:34 --> Input Class Initialized
INFO - 2024-02-12 21:07:34 --> Language Class Initialized
INFO - 2024-02-12 21:07:34 --> Loader Class Initialized
INFO - 2024-02-12 21:07:34 --> Helper loaded: url_helper
INFO - 2024-02-12 21:07:34 --> Helper loaded: file_helper
INFO - 2024-02-12 21:07:34 --> Helper loaded: form_helper
INFO - 2024-02-12 21:07:34 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:07:34 --> Controller Class Initialized
INFO - 2024-02-12 21:07:34 --> Form Validation Class Initialized
INFO - 2024-02-12 21:07:34 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:07:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:07:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:07:34 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:09:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:09:34 --> Config Class Initialized
INFO - 2024-02-12 21:09:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:09:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:09:34 --> Utf8 Class Initialized
INFO - 2024-02-12 21:09:34 --> URI Class Initialized
INFO - 2024-02-12 21:09:34 --> Router Class Initialized
INFO - 2024-02-12 21:09:34 --> Output Class Initialized
INFO - 2024-02-12 21:09:34 --> Security Class Initialized
DEBUG - 2024-02-12 21:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:09:34 --> Input Class Initialized
INFO - 2024-02-12 21:09:34 --> Language Class Initialized
INFO - 2024-02-12 21:09:34 --> Loader Class Initialized
INFO - 2024-02-12 21:09:34 --> Helper loaded: url_helper
INFO - 2024-02-12 21:09:34 --> Helper loaded: file_helper
INFO - 2024-02-12 21:09:34 --> Helper loaded: form_helper
INFO - 2024-02-12 21:09:34 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:09:34 --> Controller Class Initialized
INFO - 2024-02-12 21:09:34 --> Form Validation Class Initialized
INFO - 2024-02-12 21:09:34 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:09:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:09:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:09:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-12 21:09:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-12 21:09:34 --> Final output sent to browser
DEBUG - 2024-02-12 21:09:34 --> Total execution time: 0.0418
ERROR - 2024-02-12 21:09:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:09:38 --> Config Class Initialized
INFO - 2024-02-12 21:09:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:09:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:09:38 --> Utf8 Class Initialized
INFO - 2024-02-12 21:09:38 --> URI Class Initialized
INFO - 2024-02-12 21:09:38 --> Router Class Initialized
INFO - 2024-02-12 21:09:38 --> Output Class Initialized
INFO - 2024-02-12 21:09:38 --> Security Class Initialized
DEBUG - 2024-02-12 21:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:09:38 --> Input Class Initialized
INFO - 2024-02-12 21:09:38 --> Language Class Initialized
INFO - 2024-02-12 21:09:38 --> Loader Class Initialized
INFO - 2024-02-12 21:09:38 --> Helper loaded: url_helper
INFO - 2024-02-12 21:09:38 --> Helper loaded: file_helper
INFO - 2024-02-12 21:09:38 --> Helper loaded: form_helper
INFO - 2024-02-12 21:09:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:09:38 --> Controller Class Initialized
INFO - 2024-02-12 21:09:38 --> Form Validation Class Initialized
INFO - 2024-02-12 21:09:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:09:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:09:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:09:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-12 21:09:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-12 21:09:38 --> Config Class Initialized
INFO - 2024-02-12 21:09:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 21:09:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 21:09:38 --> Utf8 Class Initialized
INFO - 2024-02-12 21:09:38 --> URI Class Initialized
INFO - 2024-02-12 21:09:38 --> Router Class Initialized
INFO - 2024-02-12 21:09:38 --> Output Class Initialized
INFO - 2024-02-12 21:09:38 --> Security Class Initialized
DEBUG - 2024-02-12 21:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 21:09:38 --> Input Class Initialized
INFO - 2024-02-12 21:09:38 --> Language Class Initialized
INFO - 2024-02-12 21:09:38 --> Loader Class Initialized
INFO - 2024-02-12 21:09:38 --> Helper loaded: url_helper
INFO - 2024-02-12 21:09:38 --> Helper loaded: file_helper
INFO - 2024-02-12 21:09:38 --> Helper loaded: form_helper
INFO - 2024-02-12 21:09:38 --> Database Driver Class Initialized
DEBUG - 2024-02-12 21:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-12 21:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 21:09:38 --> Controller Class Initialized
INFO - 2024-02-12 21:09:38 --> Form Validation Class Initialized
INFO - 2024-02-12 21:09:38 --> Model "MasterModel" initialized
INFO - 2024-02-12 21:09:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-12 21:09:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-12 21:09:38 --> Model "ItemMasterModel" initialized
