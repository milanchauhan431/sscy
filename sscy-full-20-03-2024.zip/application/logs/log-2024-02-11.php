<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-11 10:55:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 10:55:12 --> Config Class Initialized
INFO - 2024-02-11 10:55:12 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:55:12 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:55:12 --> Utf8 Class Initialized
INFO - 2024-02-11 10:55:12 --> URI Class Initialized
INFO - 2024-02-11 10:55:12 --> Router Class Initialized
INFO - 2024-02-11 10:55:12 --> Output Class Initialized
INFO - 2024-02-11 10:55:12 --> Security Class Initialized
DEBUG - 2024-02-11 10:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:55:12 --> Input Class Initialized
INFO - 2024-02-11 10:55:12 --> Language Class Initialized
INFO - 2024-02-11 10:55:12 --> Loader Class Initialized
INFO - 2024-02-11 10:55:12 --> Helper loaded: url_helper
INFO - 2024-02-11 10:55:12 --> Helper loaded: file_helper
INFO - 2024-02-11 10:55:12 --> Helper loaded: form_helper
INFO - 2024-02-11 10:55:12 --> Database Driver Class Initialized
DEBUG - 2024-02-11 10:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 10:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:55:12 --> Controller Class Initialized
INFO - 2024-02-11 10:55:12 --> Model "LoginModel" initialized
INFO - 2024-02-11 10:55:12 --> Form Validation Class Initialized
INFO - 2024-02-11 10:55:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-11 10:55:12 --> Final output sent to browser
DEBUG - 2024-02-11 10:55:12 --> Total execution time: 0.0436
ERROR - 2024-02-11 10:55:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 10:55:19 --> Config Class Initialized
INFO - 2024-02-11 10:55:19 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:55:19 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:55:19 --> Utf8 Class Initialized
INFO - 2024-02-11 10:55:19 --> URI Class Initialized
INFO - 2024-02-11 10:55:19 --> Router Class Initialized
INFO - 2024-02-11 10:55:19 --> Output Class Initialized
INFO - 2024-02-11 10:55:19 --> Security Class Initialized
DEBUG - 2024-02-11 10:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:55:19 --> Input Class Initialized
INFO - 2024-02-11 10:55:19 --> Language Class Initialized
INFO - 2024-02-11 10:55:19 --> Loader Class Initialized
INFO - 2024-02-11 10:55:19 --> Helper loaded: url_helper
INFO - 2024-02-11 10:55:19 --> Helper loaded: file_helper
INFO - 2024-02-11 10:55:19 --> Helper loaded: form_helper
INFO - 2024-02-11 10:55:19 --> Database Driver Class Initialized
DEBUG - 2024-02-11 10:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 10:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:55:19 --> Controller Class Initialized
INFO - 2024-02-11 10:55:19 --> Model "LoginModel" initialized
INFO - 2024-02-11 10:55:19 --> Form Validation Class Initialized
INFO - 2024-02-11 10:55:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-11 10:55:19 --> Severity: Notice --> Undefined property: stdClass::$emp_role D:\xampp\htdocs\sscy\application\models\LoginModel.php 18
ERROR - 2024-02-11 10:55:19 --> Severity: Notice --> Undefined variable: empRole D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-11 10:55:19 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-11 10:55:19 --> Severity: Notice --> Undefined property: stdClass::$emp_name D:\xampp\htdocs\sscy\application\models\LoginModel.php 20
ERROR - 2024-02-11 10:55:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 10:55:20 --> Config Class Initialized
INFO - 2024-02-11 10:55:20 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:55:20 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:55:20 --> Utf8 Class Initialized
INFO - 2024-02-11 10:55:20 --> URI Class Initialized
INFO - 2024-02-11 10:55:20 --> Router Class Initialized
INFO - 2024-02-11 10:55:20 --> Output Class Initialized
INFO - 2024-02-11 10:55:20 --> Security Class Initialized
DEBUG - 2024-02-11 10:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:55:20 --> Input Class Initialized
INFO - 2024-02-11 10:55:20 --> Language Class Initialized
INFO - 2024-02-11 10:55:20 --> Loader Class Initialized
INFO - 2024-02-11 10:55:20 --> Helper loaded: url_helper
INFO - 2024-02-11 10:55:20 --> Helper loaded: file_helper
INFO - 2024-02-11 10:55:20 --> Helper loaded: form_helper
INFO - 2024-02-11 10:55:20 --> Database Driver Class Initialized
DEBUG - 2024-02-11 10:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 10:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:55:20 --> Controller Class Initialized
INFO - 2024-02-11 10:55:20 --> Form Validation Class Initialized
INFO - 2024-02-11 10:55:20 --> Model "MasterModel" initialized
INFO - 2024-02-11 10:55:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 10:55:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 10:55:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 10:55:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 10:55:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 10:55:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 10:55:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 10:55:20 --> Final output sent to browser
DEBUG - 2024-02-11 10:55:20 --> Total execution time: 0.0457
ERROR - 2024-02-11 10:55:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 10:55:24 --> Config Class Initialized
INFO - 2024-02-11 10:55:24 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:55:24 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:55:24 --> Utf8 Class Initialized
INFO - 2024-02-11 10:55:24 --> URI Class Initialized
INFO - 2024-02-11 10:55:24 --> Router Class Initialized
INFO - 2024-02-11 10:55:24 --> Output Class Initialized
INFO - 2024-02-11 10:55:24 --> Security Class Initialized
DEBUG - 2024-02-11 10:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:55:24 --> Input Class Initialized
INFO - 2024-02-11 10:55:24 --> Language Class Initialized
INFO - 2024-02-11 10:55:24 --> Loader Class Initialized
INFO - 2024-02-11 10:55:24 --> Helper loaded: url_helper
INFO - 2024-02-11 10:55:24 --> Helper loaded: file_helper
INFO - 2024-02-11 10:55:24 --> Helper loaded: form_helper
INFO - 2024-02-11 10:55:24 --> Database Driver Class Initialized
DEBUG - 2024-02-11 10:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 10:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:55:24 --> Controller Class Initialized
INFO - 2024-02-11 10:55:24 --> Form Validation Class Initialized
INFO - 2024-02-11 10:55:24 --> Model "MasterModel" initialized
INFO - 2024-02-11 10:55:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 10:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 10:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 10:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 10:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 10:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 10:55:24 --> Final output sent to browser
DEBUG - 2024-02-11 10:55:24 --> Total execution time: 0.0354
ERROR - 2024-02-11 10:55:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 10:55:24 --> Config Class Initialized
INFO - 2024-02-11 10:55:24 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:55:24 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:55:24 --> Utf8 Class Initialized
INFO - 2024-02-11 10:55:24 --> URI Class Initialized
INFO - 2024-02-11 10:55:24 --> Router Class Initialized
INFO - 2024-02-11 10:55:24 --> Output Class Initialized
INFO - 2024-02-11 10:55:24 --> Security Class Initialized
DEBUG - 2024-02-11 10:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:55:24 --> Input Class Initialized
INFO - 2024-02-11 10:55:24 --> Language Class Initialized
INFO - 2024-02-11 10:55:24 --> Loader Class Initialized
INFO - 2024-02-11 10:55:24 --> Helper loaded: url_helper
INFO - 2024-02-11 10:55:24 --> Helper loaded: file_helper
INFO - 2024-02-11 10:55:24 --> Helper loaded: form_helper
INFO - 2024-02-11 10:55:24 --> Database Driver Class Initialized
DEBUG - 2024-02-11 10:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 10:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:55:24 --> Controller Class Initialized
INFO - 2024-02-11 10:55:24 --> Form Validation Class Initialized
INFO - 2024-02-11 10:55:24 --> Model "MasterModel" initialized
INFO - 2024-02-11 10:55:24 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 10:57:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 10:57:42 --> Config Class Initialized
INFO - 2024-02-11 10:57:42 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:57:42 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:57:42 --> Utf8 Class Initialized
INFO - 2024-02-11 10:57:42 --> URI Class Initialized
INFO - 2024-02-11 10:57:42 --> Router Class Initialized
INFO - 2024-02-11 10:57:42 --> Output Class Initialized
INFO - 2024-02-11 10:57:42 --> Security Class Initialized
DEBUG - 2024-02-11 10:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:57:42 --> Input Class Initialized
INFO - 2024-02-11 10:57:42 --> Language Class Initialized
INFO - 2024-02-11 10:57:42 --> Loader Class Initialized
INFO - 2024-02-11 10:57:42 --> Helper loaded: url_helper
INFO - 2024-02-11 10:57:42 --> Helper loaded: file_helper
INFO - 2024-02-11 10:57:42 --> Helper loaded: form_helper
INFO - 2024-02-11 10:57:42 --> Database Driver Class Initialized
DEBUG - 2024-02-11 10:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 10:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:57:42 --> Controller Class Initialized
INFO - 2024-02-11 10:57:42 --> Form Validation Class Initialized
INFO - 2024-02-11 10:57:42 --> Model "MasterModel" initialized
INFO - 2024-02-11 10:57:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 10:57:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 10:57:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 10:57:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 10:57:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 10:57:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 10:57:42 --> Final output sent to browser
DEBUG - 2024-02-11 10:57:42 --> Total execution time: 0.0276
ERROR - 2024-02-11 10:57:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 10:57:42 --> Config Class Initialized
INFO - 2024-02-11 10:57:42 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:57:42 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:57:42 --> Utf8 Class Initialized
INFO - 2024-02-11 10:57:42 --> URI Class Initialized
INFO - 2024-02-11 10:57:42 --> Router Class Initialized
INFO - 2024-02-11 10:57:42 --> Output Class Initialized
INFO - 2024-02-11 10:57:42 --> Security Class Initialized
DEBUG - 2024-02-11 10:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:57:42 --> Input Class Initialized
INFO - 2024-02-11 10:57:42 --> Language Class Initialized
INFO - 2024-02-11 10:57:42 --> Loader Class Initialized
INFO - 2024-02-11 10:57:42 --> Helper loaded: url_helper
INFO - 2024-02-11 10:57:42 --> Helper loaded: file_helper
INFO - 2024-02-11 10:57:42 --> Helper loaded: form_helper
INFO - 2024-02-11 10:57:42 --> Database Driver Class Initialized
DEBUG - 2024-02-11 10:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 10:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:57:42 --> Controller Class Initialized
INFO - 2024-02-11 10:57:42 --> Form Validation Class Initialized
INFO - 2024-02-11 10:57:42 --> Model "MasterModel" initialized
INFO - 2024-02-11 10:57:42 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 10:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 10:59:11 --> Config Class Initialized
INFO - 2024-02-11 10:59:11 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:59:11 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:59:11 --> Utf8 Class Initialized
INFO - 2024-02-11 10:59:11 --> URI Class Initialized
INFO - 2024-02-11 10:59:11 --> Router Class Initialized
INFO - 2024-02-11 10:59:11 --> Output Class Initialized
INFO - 2024-02-11 10:59:11 --> Security Class Initialized
DEBUG - 2024-02-11 10:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:59:11 --> Input Class Initialized
INFO - 2024-02-11 10:59:11 --> Language Class Initialized
INFO - 2024-02-11 10:59:11 --> Loader Class Initialized
INFO - 2024-02-11 10:59:11 --> Helper loaded: url_helper
INFO - 2024-02-11 10:59:11 --> Helper loaded: file_helper
INFO - 2024-02-11 10:59:11 --> Helper loaded: form_helper
INFO - 2024-02-11 10:59:11 --> Database Driver Class Initialized
DEBUG - 2024-02-11 10:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 10:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:59:11 --> Controller Class Initialized
INFO - 2024-02-11 10:59:11 --> Form Validation Class Initialized
INFO - 2024-02-11 10:59:11 --> Model "MasterModel" initialized
INFO - 2024-02-11 10:59:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 10:59:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 10:59:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 10:59:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 10:59:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 10:59:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 10:59:11 --> Final output sent to browser
DEBUG - 2024-02-11 10:59:11 --> Total execution time: 0.0251
ERROR - 2024-02-11 10:59:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 10:59:12 --> Config Class Initialized
INFO - 2024-02-11 10:59:12 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:59:12 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:59:12 --> Utf8 Class Initialized
INFO - 2024-02-11 10:59:12 --> URI Class Initialized
INFO - 2024-02-11 10:59:12 --> Router Class Initialized
INFO - 2024-02-11 10:59:12 --> Output Class Initialized
INFO - 2024-02-11 10:59:12 --> Security Class Initialized
DEBUG - 2024-02-11 10:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:59:12 --> Input Class Initialized
INFO - 2024-02-11 10:59:12 --> Language Class Initialized
INFO - 2024-02-11 10:59:12 --> Loader Class Initialized
INFO - 2024-02-11 10:59:12 --> Helper loaded: url_helper
INFO - 2024-02-11 10:59:12 --> Helper loaded: file_helper
INFO - 2024-02-11 10:59:12 --> Helper loaded: form_helper
INFO - 2024-02-11 10:59:12 --> Database Driver Class Initialized
DEBUG - 2024-02-11 10:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 10:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:59:12 --> Controller Class Initialized
INFO - 2024-02-11 10:59:12 --> Form Validation Class Initialized
INFO - 2024-02-11 10:59:12 --> Model "MasterModel" initialized
INFO - 2024-02-11 10:59:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:00:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:00:47 --> Config Class Initialized
INFO - 2024-02-11 11:00:47 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:00:47 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:00:47 --> Utf8 Class Initialized
INFO - 2024-02-11 11:00:47 --> URI Class Initialized
INFO - 2024-02-11 11:00:47 --> Router Class Initialized
INFO - 2024-02-11 11:00:47 --> Output Class Initialized
INFO - 2024-02-11 11:00:47 --> Security Class Initialized
DEBUG - 2024-02-11 11:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:00:47 --> Input Class Initialized
INFO - 2024-02-11 11:00:47 --> Language Class Initialized
INFO - 2024-02-11 11:00:47 --> Loader Class Initialized
INFO - 2024-02-11 11:00:47 --> Helper loaded: url_helper
INFO - 2024-02-11 11:00:47 --> Helper loaded: file_helper
INFO - 2024-02-11 11:00:47 --> Helper loaded: form_helper
INFO - 2024-02-11 11:00:47 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:00:47 --> Controller Class Initialized
INFO - 2024-02-11 11:00:47 --> Form Validation Class Initialized
INFO - 2024-02-11 11:00:47 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:00:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:00:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:00:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:00:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:00:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:00:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:00:47 --> Final output sent to browser
DEBUG - 2024-02-11 11:00:47 --> Total execution time: 0.0396
ERROR - 2024-02-11 11:00:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:00:48 --> Config Class Initialized
INFO - 2024-02-11 11:00:48 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:00:48 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:00:48 --> Utf8 Class Initialized
INFO - 2024-02-11 11:00:48 --> URI Class Initialized
INFO - 2024-02-11 11:00:48 --> Router Class Initialized
INFO - 2024-02-11 11:00:48 --> Output Class Initialized
INFO - 2024-02-11 11:00:48 --> Security Class Initialized
DEBUG - 2024-02-11 11:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:00:48 --> Input Class Initialized
INFO - 2024-02-11 11:00:48 --> Language Class Initialized
INFO - 2024-02-11 11:00:48 --> Loader Class Initialized
INFO - 2024-02-11 11:00:48 --> Helper loaded: url_helper
INFO - 2024-02-11 11:00:48 --> Helper loaded: file_helper
INFO - 2024-02-11 11:00:48 --> Helper loaded: form_helper
INFO - 2024-02-11 11:00:48 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:00:48 --> Controller Class Initialized
INFO - 2024-02-11 11:00:48 --> Form Validation Class Initialized
INFO - 2024-02-11 11:00:48 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:00:48 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:00:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:00:56 --> Config Class Initialized
INFO - 2024-02-11 11:00:56 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:00:56 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:00:56 --> Utf8 Class Initialized
INFO - 2024-02-11 11:00:56 --> URI Class Initialized
INFO - 2024-02-11 11:00:56 --> Router Class Initialized
INFO - 2024-02-11 11:00:56 --> Output Class Initialized
INFO - 2024-02-11 11:00:56 --> Security Class Initialized
DEBUG - 2024-02-11 11:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:00:56 --> Input Class Initialized
INFO - 2024-02-11 11:00:56 --> Language Class Initialized
INFO - 2024-02-11 11:00:56 --> Loader Class Initialized
INFO - 2024-02-11 11:00:56 --> Helper loaded: url_helper
INFO - 2024-02-11 11:00:56 --> Helper loaded: file_helper
INFO - 2024-02-11 11:00:56 --> Helper loaded: form_helper
INFO - 2024-02-11 11:00:56 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:00:56 --> Controller Class Initialized
INFO - 2024-02-11 11:00:56 --> Form Validation Class Initialized
INFO - 2024-02-11 11:00:56 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:00:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:00:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:00:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:00:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:00:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:00:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:00:56 --> Final output sent to browser
DEBUG - 2024-02-11 11:00:56 --> Total execution time: 0.0302
ERROR - 2024-02-11 11:00:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:00:56 --> Config Class Initialized
INFO - 2024-02-11 11:00:56 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:00:56 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:00:56 --> Utf8 Class Initialized
INFO - 2024-02-11 11:00:56 --> URI Class Initialized
INFO - 2024-02-11 11:00:56 --> Router Class Initialized
INFO - 2024-02-11 11:00:56 --> Output Class Initialized
INFO - 2024-02-11 11:00:56 --> Security Class Initialized
DEBUG - 2024-02-11 11:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:00:56 --> Input Class Initialized
INFO - 2024-02-11 11:00:56 --> Language Class Initialized
INFO - 2024-02-11 11:00:56 --> Loader Class Initialized
INFO - 2024-02-11 11:00:56 --> Helper loaded: url_helper
INFO - 2024-02-11 11:00:56 --> Helper loaded: file_helper
INFO - 2024-02-11 11:00:56 --> Helper loaded: form_helper
INFO - 2024-02-11 11:00:56 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:00:56 --> Controller Class Initialized
INFO - 2024-02-11 11:00:56 --> Form Validation Class Initialized
INFO - 2024-02-11 11:00:56 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:00:56 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:02:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:02:05 --> Config Class Initialized
INFO - 2024-02-11 11:02:05 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:02:05 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:02:05 --> Utf8 Class Initialized
INFO - 2024-02-11 11:02:05 --> URI Class Initialized
INFO - 2024-02-11 11:02:05 --> Router Class Initialized
INFO - 2024-02-11 11:02:05 --> Output Class Initialized
INFO - 2024-02-11 11:02:05 --> Security Class Initialized
DEBUG - 2024-02-11 11:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:02:05 --> Input Class Initialized
INFO - 2024-02-11 11:02:05 --> Language Class Initialized
INFO - 2024-02-11 11:02:05 --> Loader Class Initialized
INFO - 2024-02-11 11:02:05 --> Helper loaded: url_helper
INFO - 2024-02-11 11:02:05 --> Helper loaded: file_helper
INFO - 2024-02-11 11:02:05 --> Helper loaded: form_helper
INFO - 2024-02-11 11:02:05 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:02:05 --> Controller Class Initialized
INFO - 2024-02-11 11:02:05 --> Form Validation Class Initialized
INFO - 2024-02-11 11:02:05 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:02:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:02:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:02:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:02:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:02:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:02:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:02:05 --> Final output sent to browser
DEBUG - 2024-02-11 11:02:05 --> Total execution time: 0.0267
ERROR - 2024-02-11 11:02:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:02:06 --> Config Class Initialized
INFO - 2024-02-11 11:02:06 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:02:06 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:02:06 --> Utf8 Class Initialized
INFO - 2024-02-11 11:02:06 --> URI Class Initialized
INFO - 2024-02-11 11:02:06 --> Router Class Initialized
INFO - 2024-02-11 11:02:06 --> Output Class Initialized
INFO - 2024-02-11 11:02:06 --> Security Class Initialized
DEBUG - 2024-02-11 11:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:02:06 --> Input Class Initialized
INFO - 2024-02-11 11:02:06 --> Language Class Initialized
INFO - 2024-02-11 11:02:06 --> Loader Class Initialized
INFO - 2024-02-11 11:02:06 --> Helper loaded: url_helper
INFO - 2024-02-11 11:02:06 --> Helper loaded: file_helper
INFO - 2024-02-11 11:02:06 --> Helper loaded: form_helper
INFO - 2024-02-11 11:02:06 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:02:06 --> Controller Class Initialized
INFO - 2024-02-11 11:02:06 --> Form Validation Class Initialized
INFO - 2024-02-11 11:02:06 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:02:06 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:02:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:02:33 --> Config Class Initialized
INFO - 2024-02-11 11:02:33 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:02:33 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:02:33 --> Utf8 Class Initialized
INFO - 2024-02-11 11:02:33 --> URI Class Initialized
INFO - 2024-02-11 11:02:33 --> Router Class Initialized
INFO - 2024-02-11 11:02:33 --> Output Class Initialized
INFO - 2024-02-11 11:02:33 --> Security Class Initialized
DEBUG - 2024-02-11 11:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:02:33 --> Input Class Initialized
INFO - 2024-02-11 11:02:33 --> Language Class Initialized
INFO - 2024-02-11 11:02:33 --> Loader Class Initialized
INFO - 2024-02-11 11:02:33 --> Helper loaded: url_helper
INFO - 2024-02-11 11:02:33 --> Helper loaded: file_helper
INFO - 2024-02-11 11:02:33 --> Helper loaded: form_helper
INFO - 2024-02-11 11:02:33 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:02:33 --> Controller Class Initialized
INFO - 2024-02-11 11:02:33 --> Form Validation Class Initialized
INFO - 2024-02-11 11:02:33 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:02:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:02:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:02:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:02:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:02:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:02:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:02:33 --> Final output sent to browser
DEBUG - 2024-02-11 11:02:33 --> Total execution time: 0.0462
ERROR - 2024-02-11 11:02:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:02:33 --> Config Class Initialized
INFO - 2024-02-11 11:02:33 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:02:33 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:02:33 --> Utf8 Class Initialized
INFO - 2024-02-11 11:02:33 --> URI Class Initialized
INFO - 2024-02-11 11:02:33 --> Router Class Initialized
INFO - 2024-02-11 11:02:33 --> Output Class Initialized
INFO - 2024-02-11 11:02:33 --> Security Class Initialized
DEBUG - 2024-02-11 11:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:02:33 --> Input Class Initialized
INFO - 2024-02-11 11:02:33 --> Language Class Initialized
INFO - 2024-02-11 11:02:33 --> Loader Class Initialized
INFO - 2024-02-11 11:02:33 --> Helper loaded: url_helper
INFO - 2024-02-11 11:02:33 --> Helper loaded: file_helper
INFO - 2024-02-11 11:02:33 --> Helper loaded: form_helper
INFO - 2024-02-11 11:02:33 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:02:33 --> Controller Class Initialized
INFO - 2024-02-11 11:02:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-02-11 11:02:33 --> Final output sent to browser
DEBUG - 2024-02-11 11:02:33 --> Total execution time: 0.0273
ERROR - 2024-02-11 11:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:02:39 --> Config Class Initialized
INFO - 2024-02-11 11:02:39 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:02:39 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:02:39 --> Utf8 Class Initialized
INFO - 2024-02-11 11:02:39 --> URI Class Initialized
INFO - 2024-02-11 11:02:39 --> Router Class Initialized
INFO - 2024-02-11 11:02:39 --> Output Class Initialized
INFO - 2024-02-11 11:02:39 --> Security Class Initialized
DEBUG - 2024-02-11 11:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:02:39 --> Input Class Initialized
INFO - 2024-02-11 11:02:39 --> Language Class Initialized
INFO - 2024-02-11 11:02:39 --> Loader Class Initialized
INFO - 2024-02-11 11:02:39 --> Helper loaded: url_helper
INFO - 2024-02-11 11:02:39 --> Helper loaded: file_helper
INFO - 2024-02-11 11:02:39 --> Helper loaded: form_helper
INFO - 2024-02-11 11:02:39 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:02:39 --> Controller Class Initialized
INFO - 2024-02-11 11:02:39 --> Model "LoginModel" initialized
INFO - 2024-02-11 11:02:39 --> Form Validation Class Initialized
INFO - 2024-02-11 11:02:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-11 11:02:39 --> Final output sent to browser
DEBUG - 2024-02-11 11:02:39 --> Total execution time: 0.0229
ERROR - 2024-02-11 11:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:02:52 --> Config Class Initialized
INFO - 2024-02-11 11:02:52 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:02:52 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:02:52 --> Utf8 Class Initialized
INFO - 2024-02-11 11:02:52 --> URI Class Initialized
INFO - 2024-02-11 11:02:52 --> Router Class Initialized
INFO - 2024-02-11 11:02:52 --> Output Class Initialized
INFO - 2024-02-11 11:02:52 --> Security Class Initialized
DEBUG - 2024-02-11 11:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:02:52 --> Input Class Initialized
INFO - 2024-02-11 11:02:52 --> Language Class Initialized
INFO - 2024-02-11 11:02:52 --> Loader Class Initialized
INFO - 2024-02-11 11:02:52 --> Helper loaded: url_helper
INFO - 2024-02-11 11:02:52 --> Helper loaded: file_helper
INFO - 2024-02-11 11:02:52 --> Helper loaded: form_helper
INFO - 2024-02-11 11:02:52 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:02:52 --> Controller Class Initialized
INFO - 2024-02-11 11:02:52 --> Model "LoginModel" initialized
INFO - 2024-02-11 11:02:52 --> Form Validation Class Initialized
INFO - 2024-02-11 11:02:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-11 11:02:52 --> Severity: Notice --> Undefined property: stdClass::$emp_role D:\xampp\htdocs\sscy\application\models\LoginModel.php 18
ERROR - 2024-02-11 11:02:52 --> Severity: Notice --> Undefined variable: empRole D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-11 11:02:52 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-11 11:02:52 --> Severity: Notice --> Undefined property: stdClass::$emp_name D:\xampp\htdocs\sscy\application\models\LoginModel.php 20
ERROR - 2024-02-11 11:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:02:52 --> Config Class Initialized
INFO - 2024-02-11 11:02:52 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:02:52 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:02:52 --> Utf8 Class Initialized
INFO - 2024-02-11 11:02:52 --> URI Class Initialized
INFO - 2024-02-11 11:02:52 --> Router Class Initialized
INFO - 2024-02-11 11:02:52 --> Output Class Initialized
INFO - 2024-02-11 11:02:52 --> Security Class Initialized
DEBUG - 2024-02-11 11:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:02:52 --> Input Class Initialized
INFO - 2024-02-11 11:02:52 --> Language Class Initialized
INFO - 2024-02-11 11:02:52 --> Loader Class Initialized
INFO - 2024-02-11 11:02:52 --> Helper loaded: url_helper
INFO - 2024-02-11 11:02:52 --> Helper loaded: file_helper
INFO - 2024-02-11 11:02:52 --> Helper loaded: form_helper
INFO - 2024-02-11 11:02:52 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:02:52 --> Controller Class Initialized
INFO - 2024-02-11 11:02:52 --> Form Validation Class Initialized
INFO - 2024-02-11 11:02:52 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:02:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:02:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:02:52 --> Final output sent to browser
DEBUG - 2024-02-11 11:02:52 --> Total execution time: 0.0234
ERROR - 2024-02-11 11:02:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:02:57 --> Config Class Initialized
INFO - 2024-02-11 11:02:57 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:02:57 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:02:57 --> Utf8 Class Initialized
INFO - 2024-02-11 11:02:57 --> URI Class Initialized
INFO - 2024-02-11 11:02:57 --> Router Class Initialized
INFO - 2024-02-11 11:02:57 --> Output Class Initialized
INFO - 2024-02-11 11:02:57 --> Security Class Initialized
DEBUG - 2024-02-11 11:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:02:57 --> Input Class Initialized
INFO - 2024-02-11 11:02:57 --> Language Class Initialized
INFO - 2024-02-11 11:02:57 --> Loader Class Initialized
INFO - 2024-02-11 11:02:57 --> Helper loaded: url_helper
INFO - 2024-02-11 11:02:57 --> Helper loaded: file_helper
INFO - 2024-02-11 11:02:57 --> Helper loaded: form_helper
INFO - 2024-02-11 11:02:57 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:02:57 --> Controller Class Initialized
INFO - 2024-02-11 11:02:57 --> Form Validation Class Initialized
INFO - 2024-02-11 11:02:57 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:02:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:02:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:02:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:02:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:02:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:02:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:02:57 --> Final output sent to browser
DEBUG - 2024-02-11 11:02:57 --> Total execution time: 0.0274
ERROR - 2024-02-11 11:02:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:02:57 --> Config Class Initialized
INFO - 2024-02-11 11:02:57 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:02:57 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:02:57 --> Utf8 Class Initialized
INFO - 2024-02-11 11:02:57 --> URI Class Initialized
INFO - 2024-02-11 11:02:57 --> Router Class Initialized
INFO - 2024-02-11 11:02:57 --> Output Class Initialized
INFO - 2024-02-11 11:02:57 --> Security Class Initialized
DEBUG - 2024-02-11 11:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:02:57 --> Input Class Initialized
INFO - 2024-02-11 11:02:57 --> Language Class Initialized
INFO - 2024-02-11 11:02:57 --> Loader Class Initialized
INFO - 2024-02-11 11:02:57 --> Helper loaded: url_helper
INFO - 2024-02-11 11:02:57 --> Helper loaded: file_helper
INFO - 2024-02-11 11:02:57 --> Helper loaded: form_helper
INFO - 2024-02-11 11:02:57 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:02:57 --> Controller Class Initialized
INFO - 2024-02-11 11:02:57 --> Form Validation Class Initialized
INFO - 2024-02-11 11:02:57 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:02:57 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:05:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:05:35 --> Config Class Initialized
INFO - 2024-02-11 11:05:35 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:05:35 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:05:35 --> Utf8 Class Initialized
INFO - 2024-02-11 11:05:35 --> URI Class Initialized
INFO - 2024-02-11 11:05:35 --> Router Class Initialized
INFO - 2024-02-11 11:05:35 --> Output Class Initialized
INFO - 2024-02-11 11:05:35 --> Security Class Initialized
DEBUG - 2024-02-11 11:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:05:35 --> Input Class Initialized
INFO - 2024-02-11 11:05:35 --> Language Class Initialized
INFO - 2024-02-11 11:05:35 --> Loader Class Initialized
INFO - 2024-02-11 11:05:35 --> Helper loaded: url_helper
INFO - 2024-02-11 11:05:35 --> Helper loaded: file_helper
INFO - 2024-02-11 11:05:35 --> Helper loaded: form_helper
INFO - 2024-02-11 11:05:35 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:05:35 --> Controller Class Initialized
INFO - 2024-02-11 11:05:35 --> Form Validation Class Initialized
INFO - 2024-02-11 11:05:35 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:05:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:05:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:05:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:05:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:05:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:05:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:05:35 --> Final output sent to browser
DEBUG - 2024-02-11 11:05:35 --> Total execution time: 0.0296
ERROR - 2024-02-11 11:05:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:05:36 --> Config Class Initialized
INFO - 2024-02-11 11:05:36 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:05:36 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:05:36 --> Utf8 Class Initialized
INFO - 2024-02-11 11:05:36 --> URI Class Initialized
INFO - 2024-02-11 11:05:36 --> Router Class Initialized
INFO - 2024-02-11 11:05:36 --> Output Class Initialized
INFO - 2024-02-11 11:05:36 --> Security Class Initialized
DEBUG - 2024-02-11 11:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:05:36 --> Input Class Initialized
INFO - 2024-02-11 11:05:36 --> Language Class Initialized
INFO - 2024-02-11 11:05:36 --> Loader Class Initialized
INFO - 2024-02-11 11:05:36 --> Helper loaded: url_helper
INFO - 2024-02-11 11:05:36 --> Helper loaded: file_helper
INFO - 2024-02-11 11:05:36 --> Helper loaded: form_helper
INFO - 2024-02-11 11:05:36 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:05:36 --> Controller Class Initialized
INFO - 2024-02-11 11:05:36 --> Form Validation Class Initialized
INFO - 2024-02-11 11:05:36 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:05:36 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:06:40 --> Config Class Initialized
INFO - 2024-02-11 11:06:40 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:06:40 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:06:40 --> Utf8 Class Initialized
INFO - 2024-02-11 11:06:40 --> URI Class Initialized
INFO - 2024-02-11 11:06:40 --> Router Class Initialized
INFO - 2024-02-11 11:06:40 --> Output Class Initialized
INFO - 2024-02-11 11:06:40 --> Security Class Initialized
DEBUG - 2024-02-11 11:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:06:40 --> Input Class Initialized
INFO - 2024-02-11 11:06:40 --> Language Class Initialized
INFO - 2024-02-11 11:06:40 --> Loader Class Initialized
INFO - 2024-02-11 11:06:40 --> Helper loaded: url_helper
INFO - 2024-02-11 11:06:40 --> Helper loaded: file_helper
INFO - 2024-02-11 11:06:40 --> Helper loaded: form_helper
INFO - 2024-02-11 11:06:40 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:06:40 --> Controller Class Initialized
INFO - 2024-02-11 11:06:40 --> Form Validation Class Initialized
INFO - 2024-02-11 11:06:40 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:06:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:06:40 --> Final output sent to browser
DEBUG - 2024-02-11 11:06:40 --> Total execution time: 0.0280
ERROR - 2024-02-11 11:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:06:40 --> Config Class Initialized
INFO - 2024-02-11 11:06:40 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:06:40 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:06:40 --> Utf8 Class Initialized
INFO - 2024-02-11 11:06:40 --> URI Class Initialized
INFO - 2024-02-11 11:06:40 --> Router Class Initialized
INFO - 2024-02-11 11:06:40 --> Output Class Initialized
INFO - 2024-02-11 11:06:40 --> Security Class Initialized
DEBUG - 2024-02-11 11:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:06:40 --> Input Class Initialized
INFO - 2024-02-11 11:06:40 --> Language Class Initialized
INFO - 2024-02-11 11:06:40 --> Loader Class Initialized
INFO - 2024-02-11 11:06:40 --> Helper loaded: url_helper
INFO - 2024-02-11 11:06:40 --> Helper loaded: file_helper
INFO - 2024-02-11 11:06:40 --> Helper loaded: form_helper
INFO - 2024-02-11 11:06:40 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:06:40 --> Controller Class Initialized
INFO - 2024-02-11 11:06:40 --> Form Validation Class Initialized
INFO - 2024-02-11 11:06:40 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:06:40 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:06:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:06:42 --> Config Class Initialized
INFO - 2024-02-11 11:06:42 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:06:42 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:06:42 --> Utf8 Class Initialized
INFO - 2024-02-11 11:06:42 --> URI Class Initialized
INFO - 2024-02-11 11:06:42 --> Router Class Initialized
INFO - 2024-02-11 11:06:42 --> Output Class Initialized
INFO - 2024-02-11 11:06:42 --> Security Class Initialized
DEBUG - 2024-02-11 11:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:06:42 --> Input Class Initialized
INFO - 2024-02-11 11:06:42 --> Language Class Initialized
INFO - 2024-02-11 11:06:42 --> Loader Class Initialized
INFO - 2024-02-11 11:06:42 --> Helper loaded: url_helper
INFO - 2024-02-11 11:06:42 --> Helper loaded: file_helper
INFO - 2024-02-11 11:06:42 --> Helper loaded: form_helper
INFO - 2024-02-11 11:06:42 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:06:42 --> Controller Class Initialized
INFO - 2024-02-11 11:06:42 --> Form Validation Class Initialized
INFO - 2024-02-11 11:06:42 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:06:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:06:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-11 11:06:42 --> Final output sent to browser
DEBUG - 2024-02-11 11:06:42 --> Total execution time: 0.0332
ERROR - 2024-02-11 11:06:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:06:50 --> Config Class Initialized
INFO - 2024-02-11 11:06:50 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:06:50 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:06:50 --> Utf8 Class Initialized
INFO - 2024-02-11 11:06:50 --> URI Class Initialized
INFO - 2024-02-11 11:06:50 --> Router Class Initialized
INFO - 2024-02-11 11:06:50 --> Output Class Initialized
INFO - 2024-02-11 11:06:50 --> Security Class Initialized
DEBUG - 2024-02-11 11:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:06:50 --> Input Class Initialized
INFO - 2024-02-11 11:06:50 --> Language Class Initialized
INFO - 2024-02-11 11:06:50 --> Loader Class Initialized
INFO - 2024-02-11 11:06:50 --> Helper loaded: url_helper
INFO - 2024-02-11 11:06:50 --> Helper loaded: file_helper
INFO - 2024-02-11 11:06:50 --> Helper loaded: form_helper
INFO - 2024-02-11 11:06:50 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:06:50 --> Controller Class Initialized
INFO - 2024-02-11 11:06:50 --> Form Validation Class Initialized
INFO - 2024-02-11 11:06:50 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:06:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:06:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-11 11:06:50 --> Final output sent to browser
DEBUG - 2024-02-11 11:06:50 --> Total execution time: 0.0393
ERROR - 2024-02-11 11:06:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:06:56 --> Config Class Initialized
INFO - 2024-02-11 11:06:56 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:06:56 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:06:56 --> Utf8 Class Initialized
INFO - 2024-02-11 11:06:56 --> URI Class Initialized
INFO - 2024-02-11 11:06:56 --> Router Class Initialized
INFO - 2024-02-11 11:06:56 --> Output Class Initialized
INFO - 2024-02-11 11:06:56 --> Security Class Initialized
DEBUG - 2024-02-11 11:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:06:56 --> Input Class Initialized
INFO - 2024-02-11 11:06:56 --> Language Class Initialized
INFO - 2024-02-11 11:06:56 --> Loader Class Initialized
INFO - 2024-02-11 11:06:56 --> Helper loaded: url_helper
INFO - 2024-02-11 11:06:56 --> Helper loaded: file_helper
INFO - 2024-02-11 11:06:56 --> Helper loaded: form_helper
INFO - 2024-02-11 11:06:56 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:06:56 --> Controller Class Initialized
INFO - 2024-02-11 11:06:56 --> Form Validation Class Initialized
INFO - 2024-02-11 11:06:56 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:06:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:06:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-11 11:06:56 --> Final output sent to browser
DEBUG - 2024-02-11 11:06:56 --> Total execution time: 0.0298
ERROR - 2024-02-11 11:06:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:06:57 --> Config Class Initialized
INFO - 2024-02-11 11:06:57 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:06:57 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:06:57 --> Utf8 Class Initialized
INFO - 2024-02-11 11:06:57 --> URI Class Initialized
INFO - 2024-02-11 11:06:57 --> Router Class Initialized
INFO - 2024-02-11 11:06:57 --> Output Class Initialized
INFO - 2024-02-11 11:06:57 --> Security Class Initialized
DEBUG - 2024-02-11 11:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:06:57 --> Input Class Initialized
INFO - 2024-02-11 11:06:57 --> Language Class Initialized
INFO - 2024-02-11 11:06:57 --> Loader Class Initialized
INFO - 2024-02-11 11:06:57 --> Helper loaded: url_helper
INFO - 2024-02-11 11:06:57 --> Helper loaded: file_helper
INFO - 2024-02-11 11:06:57 --> Helper loaded: form_helper
INFO - 2024-02-11 11:06:57 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:06:57 --> Controller Class Initialized
INFO - 2024-02-11 11:06:57 --> Form Validation Class Initialized
INFO - 2024-02-11 11:06:57 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:06:57 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:07:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:07:10 --> Config Class Initialized
INFO - 2024-02-11 11:07:10 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:07:10 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:07:10 --> Utf8 Class Initialized
INFO - 2024-02-11 11:07:10 --> URI Class Initialized
INFO - 2024-02-11 11:07:10 --> Router Class Initialized
INFO - 2024-02-11 11:07:10 --> Output Class Initialized
INFO - 2024-02-11 11:07:10 --> Security Class Initialized
DEBUG - 2024-02-11 11:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:07:10 --> Input Class Initialized
INFO - 2024-02-11 11:07:10 --> Language Class Initialized
INFO - 2024-02-11 11:07:10 --> Loader Class Initialized
INFO - 2024-02-11 11:07:10 --> Helper loaded: url_helper
INFO - 2024-02-11 11:07:10 --> Helper loaded: file_helper
INFO - 2024-02-11 11:07:10 --> Helper loaded: form_helper
INFO - 2024-02-11 11:07:10 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:07:10 --> Controller Class Initialized
INFO - 2024-02-11 11:07:10 --> Form Validation Class Initialized
INFO - 2024-02-11 11:07:10 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:07:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:07:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:07:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:07:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:07:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:07:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:07:10 --> Final output sent to browser
DEBUG - 2024-02-11 11:07:10 --> Total execution time: 0.0291
ERROR - 2024-02-11 11:07:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:07:10 --> Config Class Initialized
INFO - 2024-02-11 11:07:10 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:07:10 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:07:10 --> Utf8 Class Initialized
INFO - 2024-02-11 11:07:10 --> URI Class Initialized
INFO - 2024-02-11 11:07:10 --> Router Class Initialized
INFO - 2024-02-11 11:07:10 --> Output Class Initialized
INFO - 2024-02-11 11:07:10 --> Security Class Initialized
DEBUG - 2024-02-11 11:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:07:10 --> Input Class Initialized
INFO - 2024-02-11 11:07:10 --> Language Class Initialized
INFO - 2024-02-11 11:07:10 --> Loader Class Initialized
INFO - 2024-02-11 11:07:10 --> Helper loaded: url_helper
INFO - 2024-02-11 11:07:10 --> Helper loaded: file_helper
INFO - 2024-02-11 11:07:10 --> Helper loaded: form_helper
INFO - 2024-02-11 11:07:10 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:07:10 --> Controller Class Initialized
INFO - 2024-02-11 11:07:10 --> Form Validation Class Initialized
INFO - 2024-02-11 11:07:10 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:07:10 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:07:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:07:16 --> Config Class Initialized
INFO - 2024-02-11 11:07:16 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:07:16 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:07:16 --> Utf8 Class Initialized
INFO - 2024-02-11 11:07:16 --> URI Class Initialized
INFO - 2024-02-11 11:07:16 --> Router Class Initialized
INFO - 2024-02-11 11:07:16 --> Output Class Initialized
INFO - 2024-02-11 11:07:16 --> Security Class Initialized
DEBUG - 2024-02-11 11:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:07:16 --> Input Class Initialized
INFO - 2024-02-11 11:07:16 --> Language Class Initialized
INFO - 2024-02-11 11:07:16 --> Loader Class Initialized
INFO - 2024-02-11 11:07:16 --> Helper loaded: url_helper
INFO - 2024-02-11 11:07:16 --> Helper loaded: file_helper
INFO - 2024-02-11 11:07:16 --> Helper loaded: form_helper
INFO - 2024-02-11 11:07:16 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:07:16 --> Controller Class Initialized
INFO - 2024-02-11 11:07:16 --> Form Validation Class Initialized
INFO - 2024-02-11 11:07:16 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:07:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:07:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-11 11:07:16 --> Final output sent to browser
DEBUG - 2024-02-11 11:07:16 --> Total execution time: 0.0330
ERROR - 2024-02-11 11:07:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:07:22 --> Config Class Initialized
INFO - 2024-02-11 11:07:22 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:07:22 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:07:22 --> Utf8 Class Initialized
INFO - 2024-02-11 11:07:22 --> URI Class Initialized
INFO - 2024-02-11 11:07:22 --> Router Class Initialized
INFO - 2024-02-11 11:07:22 --> Output Class Initialized
INFO - 2024-02-11 11:07:22 --> Security Class Initialized
DEBUG - 2024-02-11 11:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:07:22 --> Input Class Initialized
INFO - 2024-02-11 11:07:22 --> Language Class Initialized
INFO - 2024-02-11 11:07:22 --> Loader Class Initialized
INFO - 2024-02-11 11:07:22 --> Helper loaded: url_helper
INFO - 2024-02-11 11:07:22 --> Helper loaded: file_helper
INFO - 2024-02-11 11:07:22 --> Helper loaded: form_helper
INFO - 2024-02-11 11:07:22 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:07:22 --> Controller Class Initialized
INFO - 2024-02-11 11:07:22 --> Form Validation Class Initialized
INFO - 2024-02-11 11:07:22 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:07:22 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:07:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:07:26 --> Config Class Initialized
INFO - 2024-02-11 11:07:26 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:07:26 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:07:26 --> Utf8 Class Initialized
INFO - 2024-02-11 11:07:26 --> URI Class Initialized
INFO - 2024-02-11 11:07:26 --> Router Class Initialized
INFO - 2024-02-11 11:07:26 --> Output Class Initialized
INFO - 2024-02-11 11:07:26 --> Security Class Initialized
DEBUG - 2024-02-11 11:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:07:26 --> Input Class Initialized
INFO - 2024-02-11 11:07:26 --> Language Class Initialized
INFO - 2024-02-11 11:07:26 --> Loader Class Initialized
INFO - 2024-02-11 11:07:26 --> Helper loaded: url_helper
INFO - 2024-02-11 11:07:26 --> Helper loaded: file_helper
INFO - 2024-02-11 11:07:26 --> Helper loaded: form_helper
INFO - 2024-02-11 11:07:26 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:07:26 --> Controller Class Initialized
INFO - 2024-02-11 11:07:26 --> Form Validation Class Initialized
INFO - 2024-02-11 11:07:26 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:07:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:07:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:07:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:07:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:07:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:07:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:07:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:07:26 --> Final output sent to browser
DEBUG - 2024-02-11 11:07:26 --> Total execution time: 0.0331
ERROR - 2024-02-11 11:07:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:07:30 --> Config Class Initialized
INFO - 2024-02-11 11:07:30 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:07:30 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:07:30 --> Utf8 Class Initialized
INFO - 2024-02-11 11:07:30 --> URI Class Initialized
INFO - 2024-02-11 11:07:30 --> Router Class Initialized
INFO - 2024-02-11 11:07:30 --> Output Class Initialized
INFO - 2024-02-11 11:07:30 --> Security Class Initialized
DEBUG - 2024-02-11 11:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:07:30 --> Input Class Initialized
INFO - 2024-02-11 11:07:30 --> Language Class Initialized
INFO - 2024-02-11 11:07:30 --> Loader Class Initialized
INFO - 2024-02-11 11:07:30 --> Helper loaded: url_helper
INFO - 2024-02-11 11:07:30 --> Helper loaded: file_helper
INFO - 2024-02-11 11:07:30 --> Helper loaded: form_helper
INFO - 2024-02-11 11:07:30 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:07:30 --> Controller Class Initialized
INFO - 2024-02-11 11:07:30 --> Form Validation Class Initialized
INFO - 2024-02-11 11:07:30 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:07:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:07:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:07:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:07:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:07:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:07:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:07:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:07:30 --> Final output sent to browser
DEBUG - 2024-02-11 11:07:30 --> Total execution time: 0.0285
ERROR - 2024-02-11 11:07:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:07:42 --> Config Class Initialized
INFO - 2024-02-11 11:07:42 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:07:42 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:07:42 --> Utf8 Class Initialized
INFO - 2024-02-11 11:07:42 --> URI Class Initialized
INFO - 2024-02-11 11:07:42 --> Router Class Initialized
INFO - 2024-02-11 11:07:42 --> Output Class Initialized
INFO - 2024-02-11 11:07:42 --> Security Class Initialized
DEBUG - 2024-02-11 11:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:07:42 --> Input Class Initialized
INFO - 2024-02-11 11:07:42 --> Language Class Initialized
INFO - 2024-02-11 11:07:43 --> Loader Class Initialized
INFO - 2024-02-11 11:07:43 --> Helper loaded: url_helper
INFO - 2024-02-11 11:07:43 --> Helper loaded: file_helper
INFO - 2024-02-11 11:07:43 --> Helper loaded: form_helper
INFO - 2024-02-11 11:07:43 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:07:43 --> Controller Class Initialized
INFO - 2024-02-11 11:07:43 --> Form Validation Class Initialized
INFO - 2024-02-11 11:07:43 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:07:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:07:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:07:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:07:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:07:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:07:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:07:43 --> Final output sent to browser
DEBUG - 2024-02-11 11:07:43 --> Total execution time: 0.0371
ERROR - 2024-02-11 11:07:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:07:43 --> Config Class Initialized
INFO - 2024-02-11 11:07:43 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:07:43 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:07:43 --> Utf8 Class Initialized
INFO - 2024-02-11 11:07:43 --> URI Class Initialized
INFO - 2024-02-11 11:07:43 --> Router Class Initialized
INFO - 2024-02-11 11:07:43 --> Output Class Initialized
INFO - 2024-02-11 11:07:43 --> Security Class Initialized
DEBUG - 2024-02-11 11:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:07:43 --> Input Class Initialized
INFO - 2024-02-11 11:07:43 --> Language Class Initialized
INFO - 2024-02-11 11:07:43 --> Loader Class Initialized
INFO - 2024-02-11 11:07:43 --> Helper loaded: url_helper
INFO - 2024-02-11 11:07:43 --> Helper loaded: file_helper
INFO - 2024-02-11 11:07:43 --> Helper loaded: form_helper
INFO - 2024-02-11 11:07:43 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:07:43 --> Controller Class Initialized
INFO - 2024-02-11 11:07:43 --> Form Validation Class Initialized
INFO - 2024-02-11 11:07:43 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:07:43 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:07:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:07:45 --> Config Class Initialized
INFO - 2024-02-11 11:07:45 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:07:45 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:07:45 --> Utf8 Class Initialized
INFO - 2024-02-11 11:07:45 --> URI Class Initialized
INFO - 2024-02-11 11:07:45 --> Router Class Initialized
INFO - 2024-02-11 11:07:45 --> Output Class Initialized
INFO - 2024-02-11 11:07:45 --> Security Class Initialized
DEBUG - 2024-02-11 11:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:07:45 --> Input Class Initialized
INFO - 2024-02-11 11:07:45 --> Language Class Initialized
INFO - 2024-02-11 11:07:45 --> Loader Class Initialized
INFO - 2024-02-11 11:07:45 --> Helper loaded: url_helper
INFO - 2024-02-11 11:07:45 --> Helper loaded: file_helper
INFO - 2024-02-11 11:07:45 --> Helper loaded: form_helper
INFO - 2024-02-11 11:07:45 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:07:45 --> Controller Class Initialized
INFO - 2024-02-11 11:07:45 --> Form Validation Class Initialized
INFO - 2024-02-11 11:07:45 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:07:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:07:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-11 11:07:45 --> Final output sent to browser
DEBUG - 2024-02-11 11:07:45 --> Total execution time: 0.0287
ERROR - 2024-02-11 11:08:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:08:17 --> Config Class Initialized
INFO - 2024-02-11 11:08:17 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:08:17 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:08:17 --> Utf8 Class Initialized
INFO - 2024-02-11 11:08:17 --> URI Class Initialized
INFO - 2024-02-11 11:08:17 --> Router Class Initialized
INFO - 2024-02-11 11:08:17 --> Output Class Initialized
INFO - 2024-02-11 11:08:17 --> Security Class Initialized
DEBUG - 2024-02-11 11:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:08:17 --> Input Class Initialized
INFO - 2024-02-11 11:08:17 --> Language Class Initialized
INFO - 2024-02-11 11:08:17 --> Loader Class Initialized
INFO - 2024-02-11 11:08:17 --> Helper loaded: url_helper
INFO - 2024-02-11 11:08:17 --> Helper loaded: file_helper
INFO - 2024-02-11 11:08:17 --> Helper loaded: form_helper
INFO - 2024-02-11 11:08:17 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:08:17 --> Controller Class Initialized
INFO - 2024-02-11 11:08:17 --> Form Validation Class Initialized
INFO - 2024-02-11 11:08:17 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:08:17 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:08:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:08:17 --> Config Class Initialized
INFO - 2024-02-11 11:08:17 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:08:17 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:08:17 --> Utf8 Class Initialized
INFO - 2024-02-11 11:08:17 --> URI Class Initialized
INFO - 2024-02-11 11:08:17 --> Router Class Initialized
INFO - 2024-02-11 11:08:17 --> Output Class Initialized
INFO - 2024-02-11 11:08:17 --> Security Class Initialized
DEBUG - 2024-02-11 11:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:08:17 --> Input Class Initialized
INFO - 2024-02-11 11:08:17 --> Language Class Initialized
INFO - 2024-02-11 11:08:17 --> Loader Class Initialized
INFO - 2024-02-11 11:08:17 --> Helper loaded: url_helper
INFO - 2024-02-11 11:08:17 --> Helper loaded: file_helper
INFO - 2024-02-11 11:08:17 --> Helper loaded: form_helper
INFO - 2024-02-11 11:08:17 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:08:17 --> Controller Class Initialized
INFO - 2024-02-11 11:08:17 --> Form Validation Class Initialized
INFO - 2024-02-11 11:08:17 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:08:17 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:08:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:08:22 --> Config Class Initialized
INFO - 2024-02-11 11:08:22 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:08:22 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:08:22 --> Utf8 Class Initialized
INFO - 2024-02-11 11:08:22 --> URI Class Initialized
INFO - 2024-02-11 11:08:22 --> Router Class Initialized
INFO - 2024-02-11 11:08:22 --> Output Class Initialized
INFO - 2024-02-11 11:08:22 --> Security Class Initialized
DEBUG - 2024-02-11 11:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:08:22 --> Input Class Initialized
INFO - 2024-02-11 11:08:22 --> Language Class Initialized
INFO - 2024-02-11 11:08:22 --> Loader Class Initialized
INFO - 2024-02-11 11:08:22 --> Helper loaded: url_helper
INFO - 2024-02-11 11:08:22 --> Helper loaded: file_helper
INFO - 2024-02-11 11:08:22 --> Helper loaded: form_helper
INFO - 2024-02-11 11:08:22 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:08:22 --> Controller Class Initialized
INFO - 2024-02-11 11:08:22 --> Form Validation Class Initialized
INFO - 2024-02-11 11:08:22 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:08:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:08:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:08:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:08:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:08:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:08:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:08:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:08:22 --> Final output sent to browser
DEBUG - 2024-02-11 11:08:22 --> Total execution time: 0.0359
ERROR - 2024-02-11 11:08:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:08:27 --> Config Class Initialized
INFO - 2024-02-11 11:08:27 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:08:27 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:08:27 --> Utf8 Class Initialized
INFO - 2024-02-11 11:08:27 --> URI Class Initialized
INFO - 2024-02-11 11:08:27 --> Router Class Initialized
INFO - 2024-02-11 11:08:27 --> Output Class Initialized
INFO - 2024-02-11 11:08:27 --> Security Class Initialized
DEBUG - 2024-02-11 11:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:08:27 --> Input Class Initialized
INFO - 2024-02-11 11:08:27 --> Language Class Initialized
INFO - 2024-02-11 11:08:27 --> Loader Class Initialized
INFO - 2024-02-11 11:08:27 --> Helper loaded: url_helper
INFO - 2024-02-11 11:08:27 --> Helper loaded: file_helper
INFO - 2024-02-11 11:08:27 --> Helper loaded: form_helper
INFO - 2024-02-11 11:08:27 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:08:27 --> Controller Class Initialized
INFO - 2024-02-11 11:08:27 --> Model "LoginModel" initialized
INFO - 2024-02-11 11:08:27 --> Form Validation Class Initialized
ERROR - 2024-02-11 11:08:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:08:27 --> Config Class Initialized
INFO - 2024-02-11 11:08:27 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:08:27 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:08:27 --> Utf8 Class Initialized
INFO - 2024-02-11 11:08:27 --> URI Class Initialized
INFO - 2024-02-11 11:08:27 --> Router Class Initialized
INFO - 2024-02-11 11:08:27 --> Output Class Initialized
INFO - 2024-02-11 11:08:27 --> Security Class Initialized
DEBUG - 2024-02-11 11:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:08:27 --> Input Class Initialized
INFO - 2024-02-11 11:08:27 --> Language Class Initialized
INFO - 2024-02-11 11:08:27 --> Loader Class Initialized
INFO - 2024-02-11 11:08:27 --> Helper loaded: url_helper
INFO - 2024-02-11 11:08:27 --> Helper loaded: file_helper
INFO - 2024-02-11 11:08:27 --> Helper loaded: form_helper
INFO - 2024-02-11 11:08:27 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:08:27 --> Controller Class Initialized
INFO - 2024-02-11 11:08:27 --> Model "LoginModel" initialized
INFO - 2024-02-11 11:08:27 --> Form Validation Class Initialized
INFO - 2024-02-11 11:08:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-11 11:08:27 --> Final output sent to browser
DEBUG - 2024-02-11 11:08:27 --> Total execution time: 0.0260
ERROR - 2024-02-11 11:08:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:08:39 --> Config Class Initialized
INFO - 2024-02-11 11:08:39 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:08:39 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:08:39 --> Utf8 Class Initialized
INFO - 2024-02-11 11:08:39 --> URI Class Initialized
INFO - 2024-02-11 11:08:39 --> Router Class Initialized
INFO - 2024-02-11 11:08:39 --> Output Class Initialized
INFO - 2024-02-11 11:08:39 --> Security Class Initialized
DEBUG - 2024-02-11 11:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:08:39 --> Input Class Initialized
INFO - 2024-02-11 11:08:39 --> Language Class Initialized
INFO - 2024-02-11 11:08:39 --> Loader Class Initialized
INFO - 2024-02-11 11:08:39 --> Helper loaded: url_helper
INFO - 2024-02-11 11:08:39 --> Helper loaded: file_helper
INFO - 2024-02-11 11:08:39 --> Helper loaded: form_helper
INFO - 2024-02-11 11:08:39 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:08:39 --> Controller Class Initialized
INFO - 2024-02-11 11:08:39 --> Model "LoginModel" initialized
INFO - 2024-02-11 11:08:39 --> Form Validation Class Initialized
INFO - 2024-02-11 11:08:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-11 11:08:39 --> Severity: Notice --> Undefined property: stdClass::$emp_role D:\xampp\htdocs\sscy\application\models\LoginModel.php 18
ERROR - 2024-02-11 11:08:39 --> Severity: Notice --> Undefined variable: empRole D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-11 11:08:39 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-11 11:08:39 --> Severity: Notice --> Undefined property: stdClass::$emp_name D:\xampp\htdocs\sscy\application\models\LoginModel.php 20
ERROR - 2024-02-11 11:08:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:08:39 --> Config Class Initialized
INFO - 2024-02-11 11:08:39 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:08:39 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:08:39 --> Utf8 Class Initialized
INFO - 2024-02-11 11:08:39 --> URI Class Initialized
INFO - 2024-02-11 11:08:39 --> Router Class Initialized
INFO - 2024-02-11 11:08:39 --> Output Class Initialized
INFO - 2024-02-11 11:08:39 --> Security Class Initialized
DEBUG - 2024-02-11 11:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:08:39 --> Input Class Initialized
INFO - 2024-02-11 11:08:39 --> Language Class Initialized
INFO - 2024-02-11 11:08:39 --> Loader Class Initialized
INFO - 2024-02-11 11:08:39 --> Helper loaded: url_helper
INFO - 2024-02-11 11:08:39 --> Helper loaded: file_helper
INFO - 2024-02-11 11:08:39 --> Helper loaded: form_helper
INFO - 2024-02-11 11:08:39 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:08:39 --> Controller Class Initialized
INFO - 2024-02-11 11:08:39 --> Form Validation Class Initialized
INFO - 2024-02-11 11:08:40 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:08:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:08:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:08:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:08:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:08:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:08:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:08:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:08:40 --> Final output sent to browser
DEBUG - 2024-02-11 11:08:40 --> Total execution time: 0.0209
ERROR - 2024-02-11 11:08:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:08:41 --> Config Class Initialized
INFO - 2024-02-11 11:08:41 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:08:41 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:08:41 --> Utf8 Class Initialized
INFO - 2024-02-11 11:08:41 --> URI Class Initialized
INFO - 2024-02-11 11:08:41 --> Router Class Initialized
INFO - 2024-02-11 11:08:41 --> Output Class Initialized
INFO - 2024-02-11 11:08:41 --> Security Class Initialized
DEBUG - 2024-02-11 11:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:08:41 --> Input Class Initialized
INFO - 2024-02-11 11:08:41 --> Language Class Initialized
INFO - 2024-02-11 11:08:41 --> Loader Class Initialized
INFO - 2024-02-11 11:08:41 --> Helper loaded: url_helper
INFO - 2024-02-11 11:08:41 --> Helper loaded: file_helper
INFO - 2024-02-11 11:08:41 --> Helper loaded: form_helper
INFO - 2024-02-11 11:08:41 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:08:41 --> Controller Class Initialized
INFO - 2024-02-11 11:08:41 --> Form Validation Class Initialized
INFO - 2024-02-11 11:08:41 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:08:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:08:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:08:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:08:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:08:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:08:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:08:41 --> Final output sent to browser
DEBUG - 2024-02-11 11:08:41 --> Total execution time: 0.0313
ERROR - 2024-02-11 11:08:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:08:42 --> Config Class Initialized
INFO - 2024-02-11 11:08:42 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:08:42 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:08:42 --> Utf8 Class Initialized
INFO - 2024-02-11 11:08:42 --> URI Class Initialized
INFO - 2024-02-11 11:08:42 --> Router Class Initialized
INFO - 2024-02-11 11:08:42 --> Output Class Initialized
INFO - 2024-02-11 11:08:42 --> Security Class Initialized
DEBUG - 2024-02-11 11:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:08:42 --> Input Class Initialized
INFO - 2024-02-11 11:08:42 --> Language Class Initialized
INFO - 2024-02-11 11:08:42 --> Loader Class Initialized
INFO - 2024-02-11 11:08:42 --> Helper loaded: url_helper
INFO - 2024-02-11 11:08:42 --> Helper loaded: file_helper
INFO - 2024-02-11 11:08:42 --> Helper loaded: form_helper
INFO - 2024-02-11 11:08:42 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:08:42 --> Controller Class Initialized
INFO - 2024-02-11 11:08:42 --> Form Validation Class Initialized
INFO - 2024-02-11 11:08:42 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:08:42 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:34:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:34:02 --> Config Class Initialized
INFO - 2024-02-11 11:34:02 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:34:02 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:34:02 --> Utf8 Class Initialized
INFO - 2024-02-11 11:34:02 --> URI Class Initialized
INFO - 2024-02-11 11:34:02 --> Router Class Initialized
INFO - 2024-02-11 11:34:02 --> Output Class Initialized
INFO - 2024-02-11 11:34:02 --> Security Class Initialized
DEBUG - 2024-02-11 11:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:34:02 --> Input Class Initialized
INFO - 2024-02-11 11:34:02 --> Language Class Initialized
INFO - 2024-02-11 11:34:02 --> Loader Class Initialized
INFO - 2024-02-11 11:34:02 --> Helper loaded: url_helper
INFO - 2024-02-11 11:34:02 --> Helper loaded: file_helper
INFO - 2024-02-11 11:34:02 --> Helper loaded: form_helper
INFO - 2024-02-11 11:34:02 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:34:02 --> Controller Class Initialized
INFO - 2024-02-11 11:34:02 --> Form Validation Class Initialized
INFO - 2024-02-11 11:34:02 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:34:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:34:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:34:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:34:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:34:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:34:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:34:02 --> Final output sent to browser
DEBUG - 2024-02-11 11:34:02 --> Total execution time: 0.0305
ERROR - 2024-02-11 11:34:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:34:02 --> Config Class Initialized
INFO - 2024-02-11 11:34:02 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:34:02 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:34:02 --> Utf8 Class Initialized
INFO - 2024-02-11 11:34:02 --> URI Class Initialized
INFO - 2024-02-11 11:34:02 --> Router Class Initialized
INFO - 2024-02-11 11:34:02 --> Output Class Initialized
INFO - 2024-02-11 11:34:02 --> Security Class Initialized
DEBUG - 2024-02-11 11:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:34:02 --> Input Class Initialized
INFO - 2024-02-11 11:34:02 --> Language Class Initialized
INFO - 2024-02-11 11:34:02 --> Loader Class Initialized
INFO - 2024-02-11 11:34:02 --> Helper loaded: url_helper
INFO - 2024-02-11 11:34:02 --> Helper loaded: file_helper
INFO - 2024-02-11 11:34:02 --> Helper loaded: form_helper
INFO - 2024-02-11 11:34:02 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:34:02 --> Controller Class Initialized
INFO - 2024-02-11 11:34:02 --> Form Validation Class Initialized
INFO - 2024-02-11 11:34:02 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:34:02 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:34:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:34:10 --> Config Class Initialized
INFO - 2024-02-11 11:34:10 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:34:10 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:34:10 --> Utf8 Class Initialized
INFO - 2024-02-11 11:34:10 --> URI Class Initialized
INFO - 2024-02-11 11:34:10 --> Router Class Initialized
INFO - 2024-02-11 11:34:10 --> Output Class Initialized
INFO - 2024-02-11 11:34:10 --> Security Class Initialized
DEBUG - 2024-02-11 11:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:34:10 --> Input Class Initialized
INFO - 2024-02-11 11:34:10 --> Language Class Initialized
INFO - 2024-02-11 11:34:10 --> Loader Class Initialized
INFO - 2024-02-11 11:34:10 --> Helper loaded: url_helper
INFO - 2024-02-11 11:34:10 --> Helper loaded: file_helper
INFO - 2024-02-11 11:34:10 --> Helper loaded: form_helper
INFO - 2024-02-11 11:34:10 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:34:10 --> Controller Class Initialized
INFO - 2024-02-11 11:34:10 --> Form Validation Class Initialized
INFO - 2024-02-11 11:34:10 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:34:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:34:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:34:10 --> Final output sent to browser
DEBUG - 2024-02-11 11:34:10 --> Total execution time: 0.0302
ERROR - 2024-02-11 11:34:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:34:15 --> Config Class Initialized
INFO - 2024-02-11 11:34:15 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:34:15 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:34:15 --> Utf8 Class Initialized
INFO - 2024-02-11 11:34:15 --> URI Class Initialized
INFO - 2024-02-11 11:34:15 --> Router Class Initialized
INFO - 2024-02-11 11:34:15 --> Output Class Initialized
INFO - 2024-02-11 11:34:15 --> Security Class Initialized
DEBUG - 2024-02-11 11:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:34:15 --> Input Class Initialized
INFO - 2024-02-11 11:34:15 --> Language Class Initialized
INFO - 2024-02-11 11:34:15 --> Loader Class Initialized
INFO - 2024-02-11 11:34:15 --> Helper loaded: url_helper
INFO - 2024-02-11 11:34:15 --> Helper loaded: file_helper
INFO - 2024-02-11 11:34:15 --> Helper loaded: form_helper
INFO - 2024-02-11 11:34:15 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:34:15 --> Controller Class Initialized
INFO - 2024-02-11 11:34:15 --> Form Validation Class Initialized
INFO - 2024-02-11 11:34:15 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:34:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:34:15 --> Final output sent to browser
DEBUG - 2024-02-11 11:34:15 --> Total execution time: 0.0310
ERROR - 2024-02-11 11:34:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:34:20 --> Config Class Initialized
INFO - 2024-02-11 11:34:20 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:34:20 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:34:20 --> Utf8 Class Initialized
INFO - 2024-02-11 11:34:20 --> URI Class Initialized
INFO - 2024-02-11 11:34:20 --> Router Class Initialized
INFO - 2024-02-11 11:34:20 --> Output Class Initialized
INFO - 2024-02-11 11:34:20 --> Security Class Initialized
DEBUG - 2024-02-11 11:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:34:20 --> Input Class Initialized
INFO - 2024-02-11 11:34:20 --> Language Class Initialized
INFO - 2024-02-11 11:34:20 --> Loader Class Initialized
INFO - 2024-02-11 11:34:20 --> Helper loaded: url_helper
INFO - 2024-02-11 11:34:20 --> Helper loaded: file_helper
INFO - 2024-02-11 11:34:20 --> Helper loaded: form_helper
INFO - 2024-02-11 11:34:20 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:34:20 --> Controller Class Initialized
INFO - 2024-02-11 11:34:20 --> Form Validation Class Initialized
INFO - 2024-02-11 11:34:20 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:34:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:34:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:34:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:34:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:34:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:34:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:34:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:34:20 --> Final output sent to browser
DEBUG - 2024-02-11 11:34:20 --> Total execution time: 0.0254
ERROR - 2024-02-11 11:35:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:35:07 --> Config Class Initialized
INFO - 2024-02-11 11:35:07 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:35:07 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:35:07 --> Utf8 Class Initialized
INFO - 2024-02-11 11:35:07 --> URI Class Initialized
INFO - 2024-02-11 11:35:07 --> Router Class Initialized
INFO - 2024-02-11 11:35:07 --> Output Class Initialized
INFO - 2024-02-11 11:35:07 --> Security Class Initialized
DEBUG - 2024-02-11 11:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:35:07 --> Input Class Initialized
INFO - 2024-02-11 11:35:07 --> Language Class Initialized
INFO - 2024-02-11 11:35:07 --> Loader Class Initialized
INFO - 2024-02-11 11:35:07 --> Helper loaded: url_helper
INFO - 2024-02-11 11:35:07 --> Helper loaded: file_helper
INFO - 2024-02-11 11:35:07 --> Helper loaded: form_helper
INFO - 2024-02-11 11:35:07 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:35:07 --> Controller Class Initialized
INFO - 2024-02-11 11:35:07 --> Form Validation Class Initialized
INFO - 2024-02-11 11:35:07 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:35:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:35:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:35:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:35:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:35:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:35:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:35:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:35:07 --> Final output sent to browser
DEBUG - 2024-02-11 11:35:07 --> Total execution time: 0.0318
ERROR - 2024-02-11 11:35:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:35:31 --> Config Class Initialized
INFO - 2024-02-11 11:35:31 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:35:31 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:35:31 --> Utf8 Class Initialized
INFO - 2024-02-11 11:35:31 --> URI Class Initialized
INFO - 2024-02-11 11:35:31 --> Router Class Initialized
INFO - 2024-02-11 11:35:31 --> Output Class Initialized
INFO - 2024-02-11 11:35:31 --> Security Class Initialized
DEBUG - 2024-02-11 11:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:35:31 --> Input Class Initialized
INFO - 2024-02-11 11:35:31 --> Language Class Initialized
INFO - 2024-02-11 11:35:31 --> Loader Class Initialized
INFO - 2024-02-11 11:35:31 --> Helper loaded: url_helper
INFO - 2024-02-11 11:35:31 --> Helper loaded: file_helper
INFO - 2024-02-11 11:35:31 --> Helper loaded: form_helper
INFO - 2024-02-11 11:35:31 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:35:31 --> Controller Class Initialized
INFO - 2024-02-11 11:35:31 --> Form Validation Class Initialized
INFO - 2024-02-11 11:35:31 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:35:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:35:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:35:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:35:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:35:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:35:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:35:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:35:31 --> Final output sent to browser
DEBUG - 2024-02-11 11:35:31 --> Total execution time: 0.0254
ERROR - 2024-02-11 11:35:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:35:34 --> Config Class Initialized
INFO - 2024-02-11 11:35:34 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:35:34 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:35:34 --> Utf8 Class Initialized
INFO - 2024-02-11 11:35:34 --> URI Class Initialized
INFO - 2024-02-11 11:35:34 --> Router Class Initialized
INFO - 2024-02-11 11:35:34 --> Output Class Initialized
INFO - 2024-02-11 11:35:34 --> Security Class Initialized
DEBUG - 2024-02-11 11:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:35:34 --> Input Class Initialized
INFO - 2024-02-11 11:35:34 --> Language Class Initialized
INFO - 2024-02-11 11:35:34 --> Loader Class Initialized
INFO - 2024-02-11 11:35:34 --> Helper loaded: url_helper
INFO - 2024-02-11 11:35:34 --> Helper loaded: file_helper
INFO - 2024-02-11 11:35:34 --> Helper loaded: form_helper
INFO - 2024-02-11 11:35:34 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:35:34 --> Controller Class Initialized
INFO - 2024-02-11 11:35:34 --> Form Validation Class Initialized
INFO - 2024-02-11 11:35:34 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:35:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:35:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:35:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:35:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:35:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:35:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:35:34 --> Final output sent to browser
DEBUG - 2024-02-11 11:35:34 --> Total execution time: 0.0295
ERROR - 2024-02-11 11:35:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:35:35 --> Config Class Initialized
INFO - 2024-02-11 11:35:35 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:35:35 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:35:35 --> Utf8 Class Initialized
INFO - 2024-02-11 11:35:35 --> URI Class Initialized
INFO - 2024-02-11 11:35:35 --> Router Class Initialized
INFO - 2024-02-11 11:35:35 --> Output Class Initialized
INFO - 2024-02-11 11:35:35 --> Security Class Initialized
DEBUG - 2024-02-11 11:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:35:35 --> Input Class Initialized
INFO - 2024-02-11 11:35:35 --> Language Class Initialized
INFO - 2024-02-11 11:35:35 --> Loader Class Initialized
INFO - 2024-02-11 11:35:35 --> Helper loaded: url_helper
INFO - 2024-02-11 11:35:35 --> Helper loaded: file_helper
INFO - 2024-02-11 11:35:35 --> Helper loaded: form_helper
INFO - 2024-02-11 11:35:35 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:35:35 --> Controller Class Initialized
INFO - 2024-02-11 11:35:35 --> Form Validation Class Initialized
INFO - 2024-02-11 11:35:35 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:35:35 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:35:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:35:37 --> Config Class Initialized
INFO - 2024-02-11 11:35:37 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:35:37 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:35:37 --> Utf8 Class Initialized
INFO - 2024-02-11 11:35:37 --> URI Class Initialized
INFO - 2024-02-11 11:35:37 --> Router Class Initialized
INFO - 2024-02-11 11:35:37 --> Output Class Initialized
INFO - 2024-02-11 11:35:37 --> Security Class Initialized
DEBUG - 2024-02-11 11:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:35:37 --> Input Class Initialized
INFO - 2024-02-11 11:35:37 --> Language Class Initialized
INFO - 2024-02-11 11:35:37 --> Loader Class Initialized
INFO - 2024-02-11 11:35:37 --> Helper loaded: url_helper
INFO - 2024-02-11 11:35:37 --> Helper loaded: file_helper
INFO - 2024-02-11 11:35:37 --> Helper loaded: form_helper
INFO - 2024-02-11 11:35:37 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:35:37 --> Controller Class Initialized
INFO - 2024-02-11 11:35:37 --> Form Validation Class Initialized
INFO - 2024-02-11 11:35:37 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:35:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:35:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:35:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:35:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:35:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:35:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:35:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:35:37 --> Final output sent to browser
DEBUG - 2024-02-11 11:35:37 --> Total execution time: 0.0232
ERROR - 2024-02-11 11:35:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:35:43 --> Config Class Initialized
INFO - 2024-02-11 11:35:43 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:35:43 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:35:43 --> Utf8 Class Initialized
INFO - 2024-02-11 11:35:43 --> URI Class Initialized
INFO - 2024-02-11 11:35:43 --> Router Class Initialized
INFO - 2024-02-11 11:35:43 --> Output Class Initialized
INFO - 2024-02-11 11:35:43 --> Security Class Initialized
DEBUG - 2024-02-11 11:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:35:43 --> Input Class Initialized
INFO - 2024-02-11 11:35:43 --> Language Class Initialized
INFO - 2024-02-11 11:35:43 --> Loader Class Initialized
INFO - 2024-02-11 11:35:43 --> Helper loaded: url_helper
INFO - 2024-02-11 11:35:43 --> Helper loaded: file_helper
INFO - 2024-02-11 11:35:43 --> Helper loaded: form_helper
INFO - 2024-02-11 11:35:43 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:35:43 --> Controller Class Initialized
INFO - 2024-02-11 11:35:43 --> Form Validation Class Initialized
INFO - 2024-02-11 11:35:43 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:35:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:35:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:35:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:35:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:35:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:35:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:35:43 --> Final output sent to browser
DEBUG - 2024-02-11 11:35:43 --> Total execution time: 0.0355
ERROR - 2024-02-11 11:35:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:35:43 --> Config Class Initialized
INFO - 2024-02-11 11:35:43 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:35:43 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:35:43 --> Utf8 Class Initialized
INFO - 2024-02-11 11:35:43 --> URI Class Initialized
INFO - 2024-02-11 11:35:43 --> Router Class Initialized
INFO - 2024-02-11 11:35:43 --> Output Class Initialized
INFO - 2024-02-11 11:35:43 --> Security Class Initialized
DEBUG - 2024-02-11 11:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:35:43 --> Input Class Initialized
INFO - 2024-02-11 11:35:43 --> Language Class Initialized
INFO - 2024-02-11 11:35:43 --> Loader Class Initialized
INFO - 2024-02-11 11:35:43 --> Helper loaded: url_helper
INFO - 2024-02-11 11:35:43 --> Helper loaded: file_helper
INFO - 2024-02-11 11:35:43 --> Helper loaded: form_helper
INFO - 2024-02-11 11:35:43 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:35:43 --> Controller Class Initialized
INFO - 2024-02-11 11:35:43 --> Form Validation Class Initialized
INFO - 2024-02-11 11:35:43 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:35:43 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:35:45 --> Config Class Initialized
INFO - 2024-02-11 11:35:45 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:35:45 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:35:45 --> Utf8 Class Initialized
INFO - 2024-02-11 11:35:45 --> URI Class Initialized
INFO - 2024-02-11 11:35:45 --> Router Class Initialized
INFO - 2024-02-11 11:35:45 --> Output Class Initialized
INFO - 2024-02-11 11:35:45 --> Security Class Initialized
DEBUG - 2024-02-11 11:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:35:45 --> Input Class Initialized
INFO - 2024-02-11 11:35:45 --> Language Class Initialized
INFO - 2024-02-11 11:35:45 --> Loader Class Initialized
INFO - 2024-02-11 11:35:45 --> Helper loaded: url_helper
INFO - 2024-02-11 11:35:45 --> Helper loaded: file_helper
INFO - 2024-02-11 11:35:45 --> Helper loaded: form_helper
INFO - 2024-02-11 11:35:45 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:35:45 --> Controller Class Initialized
INFO - 2024-02-11 11:35:45 --> Form Validation Class Initialized
INFO - 2024-02-11 11:35:45 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:35:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:35:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:35:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:35:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:35:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:35:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:35:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:35:45 --> Final output sent to browser
DEBUG - 2024-02-11 11:35:45 --> Total execution time: 0.0286
ERROR - 2024-02-11 11:35:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:35:58 --> Config Class Initialized
INFO - 2024-02-11 11:35:58 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:35:58 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:35:58 --> Utf8 Class Initialized
INFO - 2024-02-11 11:35:58 --> URI Class Initialized
INFO - 2024-02-11 11:35:58 --> Router Class Initialized
INFO - 2024-02-11 11:35:58 --> Output Class Initialized
INFO - 2024-02-11 11:35:58 --> Security Class Initialized
DEBUG - 2024-02-11 11:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:35:58 --> Input Class Initialized
INFO - 2024-02-11 11:35:58 --> Language Class Initialized
INFO - 2024-02-11 11:35:58 --> Loader Class Initialized
INFO - 2024-02-11 11:35:58 --> Helper loaded: url_helper
INFO - 2024-02-11 11:35:58 --> Helper loaded: file_helper
INFO - 2024-02-11 11:35:58 --> Helper loaded: form_helper
INFO - 2024-02-11 11:35:58 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:35:58 --> Controller Class Initialized
INFO - 2024-02-11 11:35:58 --> Form Validation Class Initialized
INFO - 2024-02-11 11:35:58 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:35:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:35:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:35:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:35:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:35:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:35:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:35:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:35:58 --> Final output sent to browser
DEBUG - 2024-02-11 11:35:58 --> Total execution time: 0.0259
ERROR - 2024-02-11 11:36:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:36:14 --> Config Class Initialized
INFO - 2024-02-11 11:36:14 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:36:14 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:36:14 --> Utf8 Class Initialized
INFO - 2024-02-11 11:36:14 --> URI Class Initialized
INFO - 2024-02-11 11:36:14 --> Router Class Initialized
INFO - 2024-02-11 11:36:14 --> Output Class Initialized
INFO - 2024-02-11 11:36:14 --> Security Class Initialized
DEBUG - 2024-02-11 11:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:36:14 --> Input Class Initialized
INFO - 2024-02-11 11:36:14 --> Language Class Initialized
INFO - 2024-02-11 11:36:14 --> Loader Class Initialized
INFO - 2024-02-11 11:36:14 --> Helper loaded: url_helper
INFO - 2024-02-11 11:36:14 --> Helper loaded: file_helper
INFO - 2024-02-11 11:36:14 --> Helper loaded: form_helper
INFO - 2024-02-11 11:36:14 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:36:14 --> Controller Class Initialized
INFO - 2024-02-11 11:36:14 --> Form Validation Class Initialized
INFO - 2024-02-11 11:36:14 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:36:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:36:14 --> Final output sent to browser
DEBUG - 2024-02-11 11:36:14 --> Total execution time: 0.0355
ERROR - 2024-02-11 11:36:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:36:14 --> Config Class Initialized
INFO - 2024-02-11 11:36:14 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:36:14 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:36:14 --> Utf8 Class Initialized
INFO - 2024-02-11 11:36:14 --> URI Class Initialized
INFO - 2024-02-11 11:36:14 --> Router Class Initialized
INFO - 2024-02-11 11:36:14 --> Output Class Initialized
INFO - 2024-02-11 11:36:14 --> Security Class Initialized
DEBUG - 2024-02-11 11:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:36:14 --> Input Class Initialized
INFO - 2024-02-11 11:36:14 --> Language Class Initialized
INFO - 2024-02-11 11:36:14 --> Loader Class Initialized
INFO - 2024-02-11 11:36:14 --> Helper loaded: url_helper
INFO - 2024-02-11 11:36:14 --> Helper loaded: file_helper
INFO - 2024-02-11 11:36:14 --> Helper loaded: form_helper
INFO - 2024-02-11 11:36:14 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:36:14 --> Controller Class Initialized
INFO - 2024-02-11 11:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-02-11 11:36:14 --> Final output sent to browser
DEBUG - 2024-02-11 11:36:14 --> Total execution time: 0.0322
ERROR - 2024-02-11 11:36:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:36:19 --> Config Class Initialized
INFO - 2024-02-11 11:36:19 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:36:19 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:36:19 --> Utf8 Class Initialized
INFO - 2024-02-11 11:36:19 --> URI Class Initialized
INFO - 2024-02-11 11:36:19 --> Router Class Initialized
INFO - 2024-02-11 11:36:19 --> Output Class Initialized
INFO - 2024-02-11 11:36:19 --> Security Class Initialized
DEBUG - 2024-02-11 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:36:19 --> Input Class Initialized
INFO - 2024-02-11 11:36:19 --> Language Class Initialized
INFO - 2024-02-11 11:36:19 --> Loader Class Initialized
INFO - 2024-02-11 11:36:19 --> Helper loaded: url_helper
INFO - 2024-02-11 11:36:19 --> Helper loaded: file_helper
INFO - 2024-02-11 11:36:19 --> Helper loaded: form_helper
INFO - 2024-02-11 11:36:19 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:36:19 --> Controller Class Initialized
INFO - 2024-02-11 11:36:19 --> Model "LoginModel" initialized
INFO - 2024-02-11 11:36:19 --> Form Validation Class Initialized
INFO - 2024-02-11 11:36:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-11 11:36:19 --> Final output sent to browser
DEBUG - 2024-02-11 11:36:19 --> Total execution time: 0.0249
ERROR - 2024-02-11 11:36:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:36:30 --> Config Class Initialized
INFO - 2024-02-11 11:36:30 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:36:30 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:36:30 --> Utf8 Class Initialized
INFO - 2024-02-11 11:36:30 --> URI Class Initialized
INFO - 2024-02-11 11:36:30 --> Router Class Initialized
INFO - 2024-02-11 11:36:30 --> Output Class Initialized
INFO - 2024-02-11 11:36:30 --> Security Class Initialized
DEBUG - 2024-02-11 11:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:36:30 --> Input Class Initialized
INFO - 2024-02-11 11:36:30 --> Language Class Initialized
INFO - 2024-02-11 11:36:30 --> Loader Class Initialized
INFO - 2024-02-11 11:36:30 --> Helper loaded: url_helper
INFO - 2024-02-11 11:36:30 --> Helper loaded: file_helper
INFO - 2024-02-11 11:36:30 --> Helper loaded: form_helper
INFO - 2024-02-11 11:36:30 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:36:30 --> Controller Class Initialized
INFO - 2024-02-11 11:36:30 --> Model "LoginModel" initialized
INFO - 2024-02-11 11:36:30 --> Form Validation Class Initialized
INFO - 2024-02-11 11:36:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-11 11:36:30 --> Severity: Notice --> Undefined property: stdClass::$emp_role D:\xampp\htdocs\sscy\application\models\LoginModel.php 18
ERROR - 2024-02-11 11:36:30 --> Severity: Notice --> Undefined variable: empRole D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-11 11:36:30 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-11 11:36:30 --> Severity: Notice --> Undefined property: stdClass::$emp_name D:\xampp\htdocs\sscy\application\models\LoginModel.php 20
ERROR - 2024-02-11 11:36:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:36:30 --> Config Class Initialized
INFO - 2024-02-11 11:36:30 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:36:30 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:36:30 --> Utf8 Class Initialized
INFO - 2024-02-11 11:36:30 --> URI Class Initialized
INFO - 2024-02-11 11:36:30 --> Router Class Initialized
INFO - 2024-02-11 11:36:30 --> Output Class Initialized
INFO - 2024-02-11 11:36:30 --> Security Class Initialized
DEBUG - 2024-02-11 11:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:36:30 --> Input Class Initialized
INFO - 2024-02-11 11:36:30 --> Language Class Initialized
INFO - 2024-02-11 11:36:30 --> Loader Class Initialized
INFO - 2024-02-11 11:36:30 --> Helper loaded: url_helper
INFO - 2024-02-11 11:36:30 --> Helper loaded: file_helper
INFO - 2024-02-11 11:36:30 --> Helper loaded: form_helper
INFO - 2024-02-11 11:36:30 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:36:30 --> Controller Class Initialized
INFO - 2024-02-11 11:36:30 --> Form Validation Class Initialized
INFO - 2024-02-11 11:36:30 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:36:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:36:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:36:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:36:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:36:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:36:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:36:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:36:30 --> Final output sent to browser
DEBUG - 2024-02-11 11:36:30 --> Total execution time: 0.0264
ERROR - 2024-02-11 11:36:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:36:33 --> Config Class Initialized
INFO - 2024-02-11 11:36:33 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:36:33 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:36:33 --> Utf8 Class Initialized
INFO - 2024-02-11 11:36:33 --> URI Class Initialized
INFO - 2024-02-11 11:36:33 --> Router Class Initialized
INFO - 2024-02-11 11:36:33 --> Output Class Initialized
INFO - 2024-02-11 11:36:33 --> Security Class Initialized
DEBUG - 2024-02-11 11:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:36:33 --> Input Class Initialized
INFO - 2024-02-11 11:36:33 --> Language Class Initialized
INFO - 2024-02-11 11:36:33 --> Loader Class Initialized
INFO - 2024-02-11 11:36:33 --> Helper loaded: url_helper
INFO - 2024-02-11 11:36:33 --> Helper loaded: file_helper
INFO - 2024-02-11 11:36:33 --> Helper loaded: form_helper
INFO - 2024-02-11 11:36:33 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:36:33 --> Controller Class Initialized
INFO - 2024-02-11 11:36:33 --> Form Validation Class Initialized
INFO - 2024-02-11 11:36:33 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:36:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:36:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:36:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:36:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:36:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:36:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-11 11:36:33 --> Final output sent to browser
DEBUG - 2024-02-11 11:36:33 --> Total execution time: 0.0276
ERROR - 2024-02-11 11:36:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:36:34 --> Config Class Initialized
INFO - 2024-02-11 11:36:34 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:36:34 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:36:34 --> Utf8 Class Initialized
INFO - 2024-02-11 11:36:34 --> URI Class Initialized
INFO - 2024-02-11 11:36:34 --> Router Class Initialized
INFO - 2024-02-11 11:36:34 --> Output Class Initialized
INFO - 2024-02-11 11:36:34 --> Security Class Initialized
DEBUG - 2024-02-11 11:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:36:34 --> Input Class Initialized
INFO - 2024-02-11 11:36:34 --> Language Class Initialized
INFO - 2024-02-11 11:36:34 --> Loader Class Initialized
INFO - 2024-02-11 11:36:34 --> Helper loaded: url_helper
INFO - 2024-02-11 11:36:34 --> Helper loaded: file_helper
INFO - 2024-02-11 11:36:34 --> Helper loaded: form_helper
INFO - 2024-02-11 11:36:34 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:36:34 --> Controller Class Initialized
INFO - 2024-02-11 11:36:34 --> Form Validation Class Initialized
INFO - 2024-02-11 11:36:34 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:36:34 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:36:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:36:36 --> Config Class Initialized
INFO - 2024-02-11 11:36:36 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:36:36 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:36:36 --> Utf8 Class Initialized
INFO - 2024-02-11 11:36:36 --> URI Class Initialized
INFO - 2024-02-11 11:36:36 --> Router Class Initialized
INFO - 2024-02-11 11:36:36 --> Output Class Initialized
INFO - 2024-02-11 11:36:36 --> Security Class Initialized
DEBUG - 2024-02-11 11:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:36:36 --> Input Class Initialized
INFO - 2024-02-11 11:36:36 --> Language Class Initialized
INFO - 2024-02-11 11:36:36 --> Loader Class Initialized
INFO - 2024-02-11 11:36:36 --> Helper loaded: url_helper
INFO - 2024-02-11 11:36:36 --> Helper loaded: file_helper
INFO - 2024-02-11 11:36:36 --> Helper loaded: form_helper
INFO - 2024-02-11 11:36:36 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:36:36 --> Controller Class Initialized
INFO - 2024-02-11 11:36:36 --> Form Validation Class Initialized
INFO - 2024-02-11 11:36:36 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:36:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:36:36 --> Final output sent to browser
DEBUG - 2024-02-11 11:36:36 --> Total execution time: 0.0328
ERROR - 2024-02-11 11:37:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:37:09 --> Config Class Initialized
INFO - 2024-02-11 11:37:09 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:37:09 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:37:09 --> Utf8 Class Initialized
INFO - 2024-02-11 11:37:09 --> URI Class Initialized
INFO - 2024-02-11 11:37:09 --> Router Class Initialized
INFO - 2024-02-11 11:37:09 --> Output Class Initialized
INFO - 2024-02-11 11:37:09 --> Security Class Initialized
DEBUG - 2024-02-11 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:37:09 --> Input Class Initialized
INFO - 2024-02-11 11:37:09 --> Language Class Initialized
INFO - 2024-02-11 11:37:09 --> Loader Class Initialized
INFO - 2024-02-11 11:37:09 --> Helper loaded: url_helper
INFO - 2024-02-11 11:37:09 --> Helper loaded: file_helper
INFO - 2024-02-11 11:37:09 --> Helper loaded: form_helper
INFO - 2024-02-11 11:37:09 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:37:09 --> Controller Class Initialized
INFO - 2024-02-11 11:37:09 --> Form Validation Class Initialized
INFO - 2024-02-11 11:37:09 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:37:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:37:09 --> Final output sent to browser
DEBUG - 2024-02-11 11:37:09 --> Total execution time: 0.0296
ERROR - 2024-02-11 11:37:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:37:11 --> Config Class Initialized
INFO - 2024-02-11 11:37:11 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:37:11 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:37:11 --> Utf8 Class Initialized
INFO - 2024-02-11 11:37:11 --> URI Class Initialized
INFO - 2024-02-11 11:37:11 --> Router Class Initialized
INFO - 2024-02-11 11:37:11 --> Output Class Initialized
INFO - 2024-02-11 11:37:11 --> Security Class Initialized
DEBUG - 2024-02-11 11:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:37:11 --> Input Class Initialized
INFO - 2024-02-11 11:37:11 --> Language Class Initialized
INFO - 2024-02-11 11:37:11 --> Loader Class Initialized
INFO - 2024-02-11 11:37:11 --> Helper loaded: url_helper
INFO - 2024-02-11 11:37:11 --> Helper loaded: file_helper
INFO - 2024-02-11 11:37:11 --> Helper loaded: form_helper
INFO - 2024-02-11 11:37:11 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:37:11 --> Controller Class Initialized
INFO - 2024-02-11 11:37:11 --> Form Validation Class Initialized
INFO - 2024-02-11 11:37:11 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:37:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:37:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:37:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:37:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:37:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:37:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:37:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:37:11 --> Final output sent to browser
DEBUG - 2024-02-11 11:37:11 --> Total execution time: 0.0324
ERROR - 2024-02-11 11:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:38:24 --> Config Class Initialized
INFO - 2024-02-11 11:38:24 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:38:24 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:38:24 --> Utf8 Class Initialized
INFO - 2024-02-11 11:38:24 --> URI Class Initialized
INFO - 2024-02-11 11:38:24 --> Router Class Initialized
INFO - 2024-02-11 11:38:24 --> Output Class Initialized
INFO - 2024-02-11 11:38:24 --> Security Class Initialized
DEBUG - 2024-02-11 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:38:24 --> Input Class Initialized
INFO - 2024-02-11 11:38:24 --> Language Class Initialized
INFO - 2024-02-11 11:38:24 --> Loader Class Initialized
INFO - 2024-02-11 11:38:24 --> Helper loaded: url_helper
INFO - 2024-02-11 11:38:24 --> Helper loaded: file_helper
INFO - 2024-02-11 11:38:24 --> Helper loaded: form_helper
INFO - 2024-02-11 11:38:24 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:38:24 --> Controller Class Initialized
INFO - 2024-02-11 11:38:24 --> Model "LoginModel" initialized
INFO - 2024-02-11 11:38:24 --> Form Validation Class Initialized
ERROR - 2024-02-11 11:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:38:24 --> Config Class Initialized
INFO - 2024-02-11 11:38:24 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:38:24 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:38:24 --> Utf8 Class Initialized
INFO - 2024-02-11 11:38:24 --> URI Class Initialized
INFO - 2024-02-11 11:38:24 --> Router Class Initialized
INFO - 2024-02-11 11:38:24 --> Output Class Initialized
INFO - 2024-02-11 11:38:24 --> Security Class Initialized
DEBUG - 2024-02-11 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:38:24 --> Input Class Initialized
INFO - 2024-02-11 11:38:24 --> Language Class Initialized
INFO - 2024-02-11 11:38:24 --> Loader Class Initialized
INFO - 2024-02-11 11:38:24 --> Helper loaded: url_helper
INFO - 2024-02-11 11:38:24 --> Helper loaded: file_helper
INFO - 2024-02-11 11:38:24 --> Helper loaded: form_helper
INFO - 2024-02-11 11:38:24 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:38:24 --> Controller Class Initialized
INFO - 2024-02-11 11:38:24 --> Model "LoginModel" initialized
INFO - 2024-02-11 11:38:24 --> Form Validation Class Initialized
INFO - 2024-02-11 11:38:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-11 11:38:24 --> Final output sent to browser
DEBUG - 2024-02-11 11:38:24 --> Total execution time: 0.0258
ERROR - 2024-02-11 11:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:38:27 --> Config Class Initialized
INFO - 2024-02-11 11:38:27 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:38:27 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:38:27 --> Utf8 Class Initialized
INFO - 2024-02-11 11:38:27 --> URI Class Initialized
INFO - 2024-02-11 11:38:27 --> Router Class Initialized
INFO - 2024-02-11 11:38:27 --> Output Class Initialized
INFO - 2024-02-11 11:38:27 --> Security Class Initialized
DEBUG - 2024-02-11 11:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:38:27 --> Input Class Initialized
INFO - 2024-02-11 11:38:27 --> Language Class Initialized
INFO - 2024-02-11 11:38:27 --> Loader Class Initialized
INFO - 2024-02-11 11:38:27 --> Helper loaded: url_helper
INFO - 2024-02-11 11:38:27 --> Helper loaded: file_helper
INFO - 2024-02-11 11:38:27 --> Helper loaded: form_helper
INFO - 2024-02-11 11:38:27 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:38:27 --> Controller Class Initialized
INFO - 2024-02-11 11:38:27 --> Model "LoginModel" initialized
INFO - 2024-02-11 11:38:27 --> Form Validation Class Initialized
INFO - 2024-02-11 11:38:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-11 11:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:38:27 --> Config Class Initialized
INFO - 2024-02-11 11:38:27 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:38:27 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:38:27 --> Utf8 Class Initialized
INFO - 2024-02-11 11:38:27 --> URI Class Initialized
INFO - 2024-02-11 11:38:27 --> Router Class Initialized
INFO - 2024-02-11 11:38:27 --> Output Class Initialized
INFO - 2024-02-11 11:38:27 --> Security Class Initialized
DEBUG - 2024-02-11 11:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:38:27 --> Input Class Initialized
INFO - 2024-02-11 11:38:27 --> Language Class Initialized
INFO - 2024-02-11 11:38:27 --> Loader Class Initialized
INFO - 2024-02-11 11:38:27 --> Helper loaded: url_helper
INFO - 2024-02-11 11:38:27 --> Helper loaded: file_helper
INFO - 2024-02-11 11:38:27 --> Helper loaded: form_helper
INFO - 2024-02-11 11:38:27 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:38:27 --> Controller Class Initialized
INFO - 2024-02-11 11:38:27 --> Form Validation Class Initialized
INFO - 2024-02-11 11:38:27 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:38:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:38:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:38:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:38:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:38:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:38:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:38:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:38:27 --> Final output sent to browser
DEBUG - 2024-02-11 11:38:27 --> Total execution time: 0.0260
ERROR - 2024-02-11 11:38:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:38:31 --> Config Class Initialized
INFO - 2024-02-11 11:38:31 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:38:31 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:38:31 --> Utf8 Class Initialized
INFO - 2024-02-11 11:38:31 --> URI Class Initialized
INFO - 2024-02-11 11:38:31 --> Router Class Initialized
INFO - 2024-02-11 11:38:31 --> Output Class Initialized
INFO - 2024-02-11 11:38:31 --> Security Class Initialized
DEBUG - 2024-02-11 11:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:38:31 --> Input Class Initialized
INFO - 2024-02-11 11:38:31 --> Language Class Initialized
INFO - 2024-02-11 11:38:31 --> Loader Class Initialized
INFO - 2024-02-11 11:38:31 --> Helper loaded: url_helper
INFO - 2024-02-11 11:38:31 --> Helper loaded: file_helper
INFO - 2024-02-11 11:38:31 --> Helper loaded: form_helper
INFO - 2024-02-11 11:38:31 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:38:31 --> Controller Class Initialized
INFO - 2024-02-11 11:38:31 --> Form Validation Class Initialized
INFO - 2024-02-11 11:38:31 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:38:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:38:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:38:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:38:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:38:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:38:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:38:31 --> Final output sent to browser
DEBUG - 2024-02-11 11:38:31 --> Total execution time: 0.0273
ERROR - 2024-02-11 11:38:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:38:31 --> Config Class Initialized
INFO - 2024-02-11 11:38:31 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:38:31 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:38:31 --> Utf8 Class Initialized
INFO - 2024-02-11 11:38:31 --> URI Class Initialized
INFO - 2024-02-11 11:38:31 --> Router Class Initialized
INFO - 2024-02-11 11:38:31 --> Output Class Initialized
INFO - 2024-02-11 11:38:31 --> Security Class Initialized
DEBUG - 2024-02-11 11:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:38:31 --> Input Class Initialized
INFO - 2024-02-11 11:38:31 --> Language Class Initialized
INFO - 2024-02-11 11:38:31 --> Loader Class Initialized
INFO - 2024-02-11 11:38:31 --> Helper loaded: url_helper
INFO - 2024-02-11 11:38:31 --> Helper loaded: file_helper
INFO - 2024-02-11 11:38:31 --> Helper loaded: form_helper
INFO - 2024-02-11 11:38:31 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:38:31 --> Controller Class Initialized
INFO - 2024-02-11 11:38:31 --> Form Validation Class Initialized
INFO - 2024-02-11 11:38:31 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:38:31 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:38:31 --> Severity: Notice --> Undefined property: ItemCategory::$itemCategory D:\xampp\htdocs\sscy\application\controllers\app\ItemCategory.php 18
ERROR - 2024-02-11 11:38:31 --> Severity: error --> Exception: Call to a member function getDTRows() on null D:\xampp\htdocs\sscy\application\controllers\app\ItemCategory.php 18
ERROR - 2024-02-11 11:38:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:38:42 --> Config Class Initialized
INFO - 2024-02-11 11:38:42 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:38:42 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:38:42 --> Utf8 Class Initialized
INFO - 2024-02-11 11:38:42 --> URI Class Initialized
INFO - 2024-02-11 11:38:42 --> Router Class Initialized
INFO - 2024-02-11 11:38:42 --> Output Class Initialized
INFO - 2024-02-11 11:38:42 --> Security Class Initialized
DEBUG - 2024-02-11 11:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:38:42 --> Input Class Initialized
INFO - 2024-02-11 11:38:42 --> Language Class Initialized
INFO - 2024-02-11 11:38:42 --> Loader Class Initialized
INFO - 2024-02-11 11:38:42 --> Helper loaded: url_helper
INFO - 2024-02-11 11:38:42 --> Helper loaded: file_helper
INFO - 2024-02-11 11:38:42 --> Helper loaded: form_helper
INFO - 2024-02-11 11:38:42 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:38:42 --> Controller Class Initialized
INFO - 2024-02-11 11:38:42 --> Form Validation Class Initialized
INFO - 2024-02-11 11:38:42 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:38:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:38:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:38:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:38:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:38:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:38:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:38:42 --> Final output sent to browser
DEBUG - 2024-02-11 11:38:42 --> Total execution time: 0.0374
ERROR - 2024-02-11 11:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:39:13 --> Config Class Initialized
INFO - 2024-02-11 11:39:13 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:39:13 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:39:13 --> Utf8 Class Initialized
INFO - 2024-02-11 11:39:13 --> URI Class Initialized
INFO - 2024-02-11 11:39:13 --> Router Class Initialized
INFO - 2024-02-11 11:39:13 --> Output Class Initialized
INFO - 2024-02-11 11:39:13 --> Security Class Initialized
DEBUG - 2024-02-11 11:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:39:13 --> Input Class Initialized
INFO - 2024-02-11 11:39:13 --> Language Class Initialized
INFO - 2024-02-11 11:39:13 --> Loader Class Initialized
INFO - 2024-02-11 11:39:13 --> Helper loaded: url_helper
INFO - 2024-02-11 11:39:13 --> Helper loaded: file_helper
INFO - 2024-02-11 11:39:13 --> Helper loaded: form_helper
INFO - 2024-02-11 11:39:13 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:39:13 --> Controller Class Initialized
INFO - 2024-02-11 11:39:13 --> Form Validation Class Initialized
INFO - 2024-02-11 11:39:13 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:39:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:39:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:39:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:39:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:39:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:39:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:39:13 --> Final output sent to browser
DEBUG - 2024-02-11 11:39:13 --> Total execution time: 0.0272
ERROR - 2024-02-11 11:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:39:13 --> Config Class Initialized
INFO - 2024-02-11 11:39:13 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:39:13 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:39:13 --> Utf8 Class Initialized
INFO - 2024-02-11 11:39:13 --> URI Class Initialized
INFO - 2024-02-11 11:39:13 --> Router Class Initialized
INFO - 2024-02-11 11:39:13 --> Output Class Initialized
INFO - 2024-02-11 11:39:13 --> Security Class Initialized
DEBUG - 2024-02-11 11:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:39:13 --> Input Class Initialized
INFO - 2024-02-11 11:39:13 --> Language Class Initialized
INFO - 2024-02-11 11:39:13 --> Loader Class Initialized
INFO - 2024-02-11 11:39:13 --> Helper loaded: url_helper
INFO - 2024-02-11 11:39:13 --> Helper loaded: file_helper
INFO - 2024-02-11 11:39:13 --> Helper loaded: form_helper
INFO - 2024-02-11 11:39:13 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:39:13 --> Controller Class Initialized
INFO - 2024-02-11 11:39:13 --> Form Validation Class Initialized
INFO - 2024-02-11 11:39:13 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:39:13 --> Model "UserMasterModel" initialized
ERROR - 2024-02-11 11:39:13 --> Severity: Notice --> Undefined property: ItemCategory::$itemCategory D:\xampp\htdocs\sscy\application\controllers\app\ItemCategory.php 18
ERROR - 2024-02-11 11:39:13 --> Severity: error --> Exception: Call to a member function getDTRows() on null D:\xampp\htdocs\sscy\application\controllers\app\ItemCategory.php 18
ERROR - 2024-02-11 11:39:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:39:18 --> Config Class Initialized
INFO - 2024-02-11 11:39:18 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:39:18 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:39:18 --> Utf8 Class Initialized
INFO - 2024-02-11 11:39:18 --> URI Class Initialized
INFO - 2024-02-11 11:39:18 --> Router Class Initialized
INFO - 2024-02-11 11:39:18 --> Output Class Initialized
INFO - 2024-02-11 11:39:18 --> Security Class Initialized
DEBUG - 2024-02-11 11:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:39:18 --> Input Class Initialized
INFO - 2024-02-11 11:39:18 --> Language Class Initialized
INFO - 2024-02-11 11:39:18 --> Loader Class Initialized
INFO - 2024-02-11 11:39:18 --> Helper loaded: url_helper
INFO - 2024-02-11 11:39:18 --> Helper loaded: file_helper
INFO - 2024-02-11 11:39:18 --> Helper loaded: form_helper
INFO - 2024-02-11 11:39:18 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:39:18 --> Controller Class Initialized
INFO - 2024-02-11 11:39:18 --> Form Validation Class Initialized
INFO - 2024-02-11 11:39:18 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:39:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:39:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:39:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:39:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:39:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:39:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:39:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:39:18 --> Final output sent to browser
DEBUG - 2024-02-11 11:39:18 --> Total execution time: 0.0300
ERROR - 2024-02-11 11:39:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:39:18 --> Config Class Initialized
INFO - 2024-02-11 11:39:18 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:39:18 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:39:18 --> Utf8 Class Initialized
INFO - 2024-02-11 11:39:18 --> URI Class Initialized
INFO - 2024-02-11 11:39:18 --> Router Class Initialized
INFO - 2024-02-11 11:39:18 --> Output Class Initialized
INFO - 2024-02-11 11:39:18 --> Security Class Initialized
DEBUG - 2024-02-11 11:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:39:18 --> Input Class Initialized
INFO - 2024-02-11 11:39:18 --> Language Class Initialized
INFO - 2024-02-11 11:39:18 --> Loader Class Initialized
INFO - 2024-02-11 11:39:18 --> Helper loaded: url_helper
INFO - 2024-02-11 11:39:18 --> Helper loaded: file_helper
INFO - 2024-02-11 11:39:18 --> Helper loaded: form_helper
INFO - 2024-02-11 11:39:18 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:39:18 --> Controller Class Initialized
INFO - 2024-02-11 11:39:18 --> Form Validation Class Initialized
INFO - 2024-02-11 11:39:18 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:39:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:39:18 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:39:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:39:23 --> Config Class Initialized
INFO - 2024-02-11 11:39:23 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:39:23 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:39:23 --> Utf8 Class Initialized
INFO - 2024-02-11 11:39:23 --> URI Class Initialized
INFO - 2024-02-11 11:39:23 --> Router Class Initialized
INFO - 2024-02-11 11:39:23 --> Output Class Initialized
INFO - 2024-02-11 11:39:23 --> Security Class Initialized
DEBUG - 2024-02-11 11:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:39:23 --> Input Class Initialized
INFO - 2024-02-11 11:39:23 --> Language Class Initialized
INFO - 2024-02-11 11:39:23 --> Loader Class Initialized
INFO - 2024-02-11 11:39:23 --> Helper loaded: url_helper
INFO - 2024-02-11 11:39:23 --> Helper loaded: file_helper
INFO - 2024-02-11 11:39:23 --> Helper loaded: form_helper
INFO - 2024-02-11 11:39:23 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:39:23 --> Controller Class Initialized
INFO - 2024-02-11 11:39:23 --> Form Validation Class Initialized
INFO - 2024-02-11 11:39:23 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:39:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:39:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:39:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:39:23 --> Final output sent to browser
DEBUG - 2024-02-11 11:39:23 --> Total execution time: 0.0226
ERROR - 2024-02-11 11:42:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:42:43 --> Config Class Initialized
INFO - 2024-02-11 11:42:43 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:42:43 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:42:43 --> Utf8 Class Initialized
INFO - 2024-02-11 11:42:43 --> URI Class Initialized
INFO - 2024-02-11 11:42:43 --> Router Class Initialized
INFO - 2024-02-11 11:42:43 --> Output Class Initialized
INFO - 2024-02-11 11:42:43 --> Security Class Initialized
DEBUG - 2024-02-11 11:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:42:43 --> Input Class Initialized
INFO - 2024-02-11 11:42:43 --> Language Class Initialized
INFO - 2024-02-11 11:42:43 --> Loader Class Initialized
INFO - 2024-02-11 11:42:43 --> Helper loaded: url_helper
INFO - 2024-02-11 11:42:43 --> Helper loaded: file_helper
INFO - 2024-02-11 11:42:43 --> Helper loaded: form_helper
INFO - 2024-02-11 11:42:43 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:42:43 --> Controller Class Initialized
INFO - 2024-02-11 11:42:43 --> Form Validation Class Initialized
INFO - 2024-02-11 11:42:43 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:42:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:42:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:42:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:42:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:42:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:42:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:42:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:42:43 --> Final output sent to browser
DEBUG - 2024-02-11 11:42:43 --> Total execution time: 0.0294
ERROR - 2024-02-11 11:42:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:42:43 --> Config Class Initialized
INFO - 2024-02-11 11:42:43 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:42:43 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:42:43 --> Utf8 Class Initialized
INFO - 2024-02-11 11:42:43 --> URI Class Initialized
INFO - 2024-02-11 11:42:43 --> Router Class Initialized
INFO - 2024-02-11 11:42:43 --> Output Class Initialized
INFO - 2024-02-11 11:42:43 --> Security Class Initialized
DEBUG - 2024-02-11 11:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:42:43 --> Input Class Initialized
INFO - 2024-02-11 11:42:43 --> Language Class Initialized
INFO - 2024-02-11 11:42:43 --> Loader Class Initialized
INFO - 2024-02-11 11:42:43 --> Helper loaded: url_helper
INFO - 2024-02-11 11:42:43 --> Helper loaded: file_helper
INFO - 2024-02-11 11:42:43 --> Helper loaded: form_helper
INFO - 2024-02-11 11:42:43 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:42:43 --> Controller Class Initialized
INFO - 2024-02-11 11:42:43 --> Form Validation Class Initialized
INFO - 2024-02-11 11:42:43 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:42:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:42:43 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:42:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:42:46 --> Config Class Initialized
INFO - 2024-02-11 11:42:46 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:42:46 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:42:46 --> Utf8 Class Initialized
INFO - 2024-02-11 11:42:46 --> URI Class Initialized
INFO - 2024-02-11 11:42:46 --> Router Class Initialized
INFO - 2024-02-11 11:42:46 --> Output Class Initialized
INFO - 2024-02-11 11:42:46 --> Security Class Initialized
DEBUG - 2024-02-11 11:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:42:46 --> Input Class Initialized
INFO - 2024-02-11 11:42:46 --> Language Class Initialized
INFO - 2024-02-11 11:42:46 --> Loader Class Initialized
INFO - 2024-02-11 11:42:46 --> Helper loaded: url_helper
INFO - 2024-02-11 11:42:46 --> Helper loaded: file_helper
INFO - 2024-02-11 11:42:46 --> Helper loaded: form_helper
INFO - 2024-02-11 11:42:46 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:42:46 --> Controller Class Initialized
INFO - 2024-02-11 11:42:46 --> Form Validation Class Initialized
INFO - 2024-02-11 11:42:46 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:42:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:42:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:42:46 --> Final output sent to browser
DEBUG - 2024-02-11 11:42:46 --> Total execution time: 0.0309
ERROR - 2024-02-11 11:42:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:42:58 --> Config Class Initialized
INFO - 2024-02-11 11:42:58 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:42:58 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:42:58 --> Utf8 Class Initialized
INFO - 2024-02-11 11:42:58 --> URI Class Initialized
INFO - 2024-02-11 11:42:58 --> Router Class Initialized
INFO - 2024-02-11 11:42:58 --> Output Class Initialized
INFO - 2024-02-11 11:42:58 --> Security Class Initialized
DEBUG - 2024-02-11 11:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:42:58 --> Input Class Initialized
INFO - 2024-02-11 11:42:58 --> Language Class Initialized
INFO - 2024-02-11 11:42:58 --> Loader Class Initialized
INFO - 2024-02-11 11:42:58 --> Helper loaded: url_helper
INFO - 2024-02-11 11:42:58 --> Helper loaded: file_helper
INFO - 2024-02-11 11:42:58 --> Helper loaded: form_helper
INFO - 2024-02-11 11:42:58 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:42:58 --> Controller Class Initialized
INFO - 2024-02-11 11:42:58 --> Form Validation Class Initialized
INFO - 2024-02-11 11:42:58 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:42:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:42:58 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:42:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:42:58 --> Config Class Initialized
INFO - 2024-02-11 11:42:58 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:42:58 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:42:58 --> Utf8 Class Initialized
INFO - 2024-02-11 11:42:58 --> URI Class Initialized
INFO - 2024-02-11 11:42:58 --> Router Class Initialized
INFO - 2024-02-11 11:42:58 --> Output Class Initialized
INFO - 2024-02-11 11:42:58 --> Security Class Initialized
DEBUG - 2024-02-11 11:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:42:58 --> Input Class Initialized
INFO - 2024-02-11 11:42:58 --> Language Class Initialized
INFO - 2024-02-11 11:42:58 --> Loader Class Initialized
INFO - 2024-02-11 11:42:58 --> Helper loaded: url_helper
INFO - 2024-02-11 11:42:58 --> Helper loaded: file_helper
INFO - 2024-02-11 11:42:58 --> Helper loaded: form_helper
INFO - 2024-02-11 11:42:58 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:42:58 --> Controller Class Initialized
INFO - 2024-02-11 11:42:58 --> Form Validation Class Initialized
INFO - 2024-02-11 11:42:58 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:42:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:42:58 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:43:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:43:15 --> Config Class Initialized
INFO - 2024-02-11 11:43:15 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:43:15 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:43:15 --> Utf8 Class Initialized
INFO - 2024-02-11 11:43:15 --> URI Class Initialized
INFO - 2024-02-11 11:43:15 --> Router Class Initialized
INFO - 2024-02-11 11:43:15 --> Output Class Initialized
INFO - 2024-02-11 11:43:15 --> Security Class Initialized
DEBUG - 2024-02-11 11:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:43:15 --> Input Class Initialized
INFO - 2024-02-11 11:43:15 --> Language Class Initialized
INFO - 2024-02-11 11:43:15 --> Loader Class Initialized
INFO - 2024-02-11 11:43:15 --> Helper loaded: url_helper
INFO - 2024-02-11 11:43:15 --> Helper loaded: file_helper
INFO - 2024-02-11 11:43:15 --> Helper loaded: form_helper
INFO - 2024-02-11 11:43:15 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:43:15 --> Controller Class Initialized
INFO - 2024-02-11 11:43:15 --> Form Validation Class Initialized
INFO - 2024-02-11 11:43:15 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:43:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:43:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:43:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:43:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:43:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:43:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:43:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:43:15 --> Final output sent to browser
DEBUG - 2024-02-11 11:43:15 --> Total execution time: 0.0444
ERROR - 2024-02-11 11:43:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:43:15 --> Config Class Initialized
INFO - 2024-02-11 11:43:15 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:43:15 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:43:15 --> Utf8 Class Initialized
INFO - 2024-02-11 11:43:15 --> URI Class Initialized
INFO - 2024-02-11 11:43:15 --> Router Class Initialized
INFO - 2024-02-11 11:43:15 --> Output Class Initialized
INFO - 2024-02-11 11:43:15 --> Security Class Initialized
DEBUG - 2024-02-11 11:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:43:15 --> Input Class Initialized
INFO - 2024-02-11 11:43:15 --> Language Class Initialized
INFO - 2024-02-11 11:43:15 --> Loader Class Initialized
INFO - 2024-02-11 11:43:15 --> Helper loaded: url_helper
INFO - 2024-02-11 11:43:15 --> Helper loaded: file_helper
INFO - 2024-02-11 11:43:15 --> Helper loaded: form_helper
INFO - 2024-02-11 11:43:15 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:43:15 --> Controller Class Initialized
INFO - 2024-02-11 11:43:15 --> Form Validation Class Initialized
INFO - 2024-02-11 11:43:15 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:43:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:43:15 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:43:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:43:21 --> Config Class Initialized
INFO - 2024-02-11 11:43:21 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:43:21 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:43:21 --> Utf8 Class Initialized
INFO - 2024-02-11 11:43:21 --> URI Class Initialized
INFO - 2024-02-11 11:43:21 --> Router Class Initialized
INFO - 2024-02-11 11:43:21 --> Output Class Initialized
INFO - 2024-02-11 11:43:21 --> Security Class Initialized
DEBUG - 2024-02-11 11:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:43:21 --> Input Class Initialized
INFO - 2024-02-11 11:43:21 --> Language Class Initialized
INFO - 2024-02-11 11:43:21 --> Loader Class Initialized
INFO - 2024-02-11 11:43:21 --> Helper loaded: url_helper
INFO - 2024-02-11 11:43:21 --> Helper loaded: file_helper
INFO - 2024-02-11 11:43:21 --> Helper loaded: form_helper
INFO - 2024-02-11 11:43:21 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:43:21 --> Controller Class Initialized
INFO - 2024-02-11 11:43:21 --> Form Validation Class Initialized
INFO - 2024-02-11 11:43:21 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:43:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:43:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:43:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:43:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:43:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:43:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:43:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:43:21 --> Final output sent to browser
DEBUG - 2024-02-11 11:43:21 --> Total execution time: 0.0286
ERROR - 2024-02-11 11:43:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:43:46 --> Config Class Initialized
INFO - 2024-02-11 11:43:46 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:43:46 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:43:46 --> Utf8 Class Initialized
INFO - 2024-02-11 11:43:46 --> URI Class Initialized
INFO - 2024-02-11 11:43:46 --> Router Class Initialized
INFO - 2024-02-11 11:43:46 --> Output Class Initialized
INFO - 2024-02-11 11:43:46 --> Security Class Initialized
DEBUG - 2024-02-11 11:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:43:46 --> Input Class Initialized
INFO - 2024-02-11 11:43:46 --> Language Class Initialized
INFO - 2024-02-11 11:43:46 --> Loader Class Initialized
INFO - 2024-02-11 11:43:46 --> Helper loaded: url_helper
INFO - 2024-02-11 11:43:46 --> Helper loaded: file_helper
INFO - 2024-02-11 11:43:46 --> Helper loaded: form_helper
INFO - 2024-02-11 11:43:46 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:43:46 --> Controller Class Initialized
INFO - 2024-02-11 11:43:46 --> Form Validation Class Initialized
INFO - 2024-02-11 11:43:46 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:43:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:43:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:43:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:43:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:43:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:43:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:43:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:43:46 --> Final output sent to browser
DEBUG - 2024-02-11 11:43:46 --> Total execution time: 0.0402
ERROR - 2024-02-11 11:43:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:43:46 --> Config Class Initialized
INFO - 2024-02-11 11:43:46 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:43:46 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:43:46 --> Utf8 Class Initialized
INFO - 2024-02-11 11:43:46 --> URI Class Initialized
INFO - 2024-02-11 11:43:46 --> Router Class Initialized
INFO - 2024-02-11 11:43:46 --> Output Class Initialized
INFO - 2024-02-11 11:43:46 --> Security Class Initialized
DEBUG - 2024-02-11 11:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:43:46 --> Input Class Initialized
INFO - 2024-02-11 11:43:46 --> Language Class Initialized
INFO - 2024-02-11 11:43:46 --> Loader Class Initialized
INFO - 2024-02-11 11:43:46 --> Helper loaded: url_helper
INFO - 2024-02-11 11:43:46 --> Helper loaded: file_helper
INFO - 2024-02-11 11:43:46 --> Helper loaded: form_helper
INFO - 2024-02-11 11:43:46 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:43:46 --> Controller Class Initialized
INFO - 2024-02-11 11:43:46 --> Form Validation Class Initialized
INFO - 2024-02-11 11:43:46 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:43:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:43:46 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:43:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:43:50 --> Config Class Initialized
INFO - 2024-02-11 11:43:50 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:43:50 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:43:50 --> Utf8 Class Initialized
INFO - 2024-02-11 11:43:50 --> URI Class Initialized
INFO - 2024-02-11 11:43:50 --> Router Class Initialized
INFO - 2024-02-11 11:43:50 --> Output Class Initialized
INFO - 2024-02-11 11:43:50 --> Security Class Initialized
DEBUG - 2024-02-11 11:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:43:50 --> Input Class Initialized
INFO - 2024-02-11 11:43:50 --> Language Class Initialized
INFO - 2024-02-11 11:43:50 --> Loader Class Initialized
INFO - 2024-02-11 11:43:50 --> Helper loaded: url_helper
INFO - 2024-02-11 11:43:50 --> Helper loaded: file_helper
INFO - 2024-02-11 11:43:50 --> Helper loaded: form_helper
INFO - 2024-02-11 11:43:50 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:43:50 --> Controller Class Initialized
INFO - 2024-02-11 11:43:50 --> Form Validation Class Initialized
INFO - 2024-02-11 11:43:50 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:43:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:43:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:43:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:43:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:43:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:43:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:43:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:43:50 --> Final output sent to browser
DEBUG - 2024-02-11 11:43:50 --> Total execution time: 0.0284
ERROR - 2024-02-11 11:43:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:43:51 --> Config Class Initialized
INFO - 2024-02-11 11:43:51 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:43:51 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:43:51 --> Utf8 Class Initialized
INFO - 2024-02-11 11:43:51 --> URI Class Initialized
INFO - 2024-02-11 11:43:51 --> Router Class Initialized
INFO - 2024-02-11 11:43:51 --> Output Class Initialized
INFO - 2024-02-11 11:43:51 --> Security Class Initialized
DEBUG - 2024-02-11 11:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:43:51 --> Input Class Initialized
INFO - 2024-02-11 11:43:51 --> Language Class Initialized
INFO - 2024-02-11 11:43:51 --> Loader Class Initialized
INFO - 2024-02-11 11:43:51 --> Helper loaded: url_helper
INFO - 2024-02-11 11:43:51 --> Helper loaded: file_helper
INFO - 2024-02-11 11:43:51 --> Helper loaded: form_helper
INFO - 2024-02-11 11:43:51 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:43:51 --> Controller Class Initialized
INFO - 2024-02-11 11:43:51 --> Form Validation Class Initialized
INFO - 2024-02-11 11:43:51 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:43:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:43:51 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:43:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:43:56 --> Config Class Initialized
INFO - 2024-02-11 11:43:56 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:43:56 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:43:56 --> Utf8 Class Initialized
INFO - 2024-02-11 11:43:56 --> URI Class Initialized
INFO - 2024-02-11 11:43:56 --> Router Class Initialized
INFO - 2024-02-11 11:43:56 --> Output Class Initialized
INFO - 2024-02-11 11:43:56 --> Security Class Initialized
DEBUG - 2024-02-11 11:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:43:56 --> Input Class Initialized
INFO - 2024-02-11 11:43:56 --> Language Class Initialized
INFO - 2024-02-11 11:43:56 --> Loader Class Initialized
INFO - 2024-02-11 11:43:56 --> Helper loaded: url_helper
INFO - 2024-02-11 11:43:56 --> Helper loaded: file_helper
INFO - 2024-02-11 11:43:56 --> Helper loaded: form_helper
INFO - 2024-02-11 11:43:56 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:43:56 --> Controller Class Initialized
INFO - 2024-02-11 11:43:56 --> Form Validation Class Initialized
INFO - 2024-02-11 11:43:56 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:43:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:43:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:43:56 --> Final output sent to browser
DEBUG - 2024-02-11 11:43:56 --> Total execution time: 0.0361
ERROR - 2024-02-11 11:43:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:43:56 --> Config Class Initialized
INFO - 2024-02-11 11:43:56 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:43:56 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:43:56 --> Utf8 Class Initialized
INFO - 2024-02-11 11:43:56 --> URI Class Initialized
INFO - 2024-02-11 11:43:56 --> Router Class Initialized
INFO - 2024-02-11 11:43:56 --> Output Class Initialized
INFO - 2024-02-11 11:43:56 --> Security Class Initialized
DEBUG - 2024-02-11 11:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:43:56 --> Input Class Initialized
INFO - 2024-02-11 11:43:56 --> Language Class Initialized
INFO - 2024-02-11 11:43:56 --> Loader Class Initialized
INFO - 2024-02-11 11:43:56 --> Helper loaded: url_helper
INFO - 2024-02-11 11:43:56 --> Helper loaded: file_helper
INFO - 2024-02-11 11:43:56 --> Helper loaded: form_helper
INFO - 2024-02-11 11:43:56 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:43:56 --> Controller Class Initialized
INFO - 2024-02-11 11:43:56 --> Form Validation Class Initialized
INFO - 2024-02-11 11:43:56 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:43:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:43:56 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:00 --> Config Class Initialized
INFO - 2024-02-11 11:44:00 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:00 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:00 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:00 --> URI Class Initialized
INFO - 2024-02-11 11:44:00 --> Router Class Initialized
INFO - 2024-02-11 11:44:00 --> Output Class Initialized
INFO - 2024-02-11 11:44:00 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:00 --> Input Class Initialized
INFO - 2024-02-11 11:44:00 --> Language Class Initialized
INFO - 2024-02-11 11:44:00 --> Loader Class Initialized
INFO - 2024-02-11 11:44:00 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:00 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:00 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:00 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:00 --> Controller Class Initialized
INFO - 2024-02-11 11:44:00 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:00 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:44:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:44:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:44:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:44:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:44:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:44:00 --> Final output sent to browser
DEBUG - 2024-02-11 11:44:00 --> Total execution time: 0.0230
ERROR - 2024-02-11 11:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:00 --> Config Class Initialized
INFO - 2024-02-11 11:44:00 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:00 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:00 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:00 --> URI Class Initialized
INFO - 2024-02-11 11:44:00 --> Router Class Initialized
INFO - 2024-02-11 11:44:00 --> Output Class Initialized
INFO - 2024-02-11 11:44:00 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:01 --> Input Class Initialized
INFO - 2024-02-11 11:44:01 --> Language Class Initialized
INFO - 2024-02-11 11:44:01 --> Loader Class Initialized
INFO - 2024-02-11 11:44:01 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:01 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:01 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:01 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:01 --> Controller Class Initialized
INFO - 2024-02-11 11:44:01 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:01 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:01 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:44:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:04 --> Config Class Initialized
INFO - 2024-02-11 11:44:04 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:04 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:04 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:04 --> URI Class Initialized
INFO - 2024-02-11 11:44:04 --> Router Class Initialized
INFO - 2024-02-11 11:44:04 --> Output Class Initialized
INFO - 2024-02-11 11:44:04 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:04 --> Input Class Initialized
INFO - 2024-02-11 11:44:04 --> Language Class Initialized
INFO - 2024-02-11 11:44:04 --> Loader Class Initialized
INFO - 2024-02-11 11:44:04 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:04 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:04 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:04 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:04 --> Controller Class Initialized
INFO - 2024-02-11 11:44:04 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:04 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:44:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:44:04 --> Final output sent to browser
DEBUG - 2024-02-11 11:44:04 --> Total execution time: 0.0318
ERROR - 2024-02-11 11:44:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:05 --> Config Class Initialized
INFO - 2024-02-11 11:44:05 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:05 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:05 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:05 --> URI Class Initialized
INFO - 2024-02-11 11:44:05 --> Router Class Initialized
INFO - 2024-02-11 11:44:05 --> Output Class Initialized
INFO - 2024-02-11 11:44:05 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:05 --> Input Class Initialized
INFO - 2024-02-11 11:44:05 --> Language Class Initialized
INFO - 2024-02-11 11:44:05 --> Loader Class Initialized
INFO - 2024-02-11 11:44:05 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:05 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:05 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:05 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:05 --> Controller Class Initialized
INFO - 2024-02-11 11:44:05 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:05 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:05 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:44:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:06 --> Config Class Initialized
INFO - 2024-02-11 11:44:06 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:06 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:06 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:06 --> URI Class Initialized
INFO - 2024-02-11 11:44:06 --> Router Class Initialized
INFO - 2024-02-11 11:44:06 --> Output Class Initialized
INFO - 2024-02-11 11:44:06 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:06 --> Input Class Initialized
INFO - 2024-02-11 11:44:06 --> Language Class Initialized
INFO - 2024-02-11 11:44:06 --> Loader Class Initialized
INFO - 2024-02-11 11:44:06 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:06 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:06 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:06 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:06 --> Controller Class Initialized
INFO - 2024-02-11 11:44:06 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:06 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:44:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:44:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:44:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:44:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:44:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:44:06 --> Final output sent to browser
DEBUG - 2024-02-11 11:44:06 --> Total execution time: 0.0417
ERROR - 2024-02-11 11:44:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:06 --> Config Class Initialized
INFO - 2024-02-11 11:44:06 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:06 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:06 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:06 --> URI Class Initialized
INFO - 2024-02-11 11:44:06 --> Router Class Initialized
INFO - 2024-02-11 11:44:06 --> Output Class Initialized
INFO - 2024-02-11 11:44:06 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:06 --> Input Class Initialized
INFO - 2024-02-11 11:44:06 --> Language Class Initialized
INFO - 2024-02-11 11:44:06 --> Loader Class Initialized
INFO - 2024-02-11 11:44:06 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:06 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:06 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:06 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:06 --> Controller Class Initialized
INFO - 2024-02-11 11:44:06 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:06 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:44:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:44:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:44:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:44:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:44:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:44:06 --> Final output sent to browser
DEBUG - 2024-02-11 11:44:06 --> Total execution time: 0.0446
ERROR - 2024-02-11 11:44:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:07 --> Config Class Initialized
INFO - 2024-02-11 11:44:07 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:07 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:07 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:07 --> URI Class Initialized
INFO - 2024-02-11 11:44:07 --> Router Class Initialized
INFO - 2024-02-11 11:44:07 --> Output Class Initialized
INFO - 2024-02-11 11:44:07 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:07 --> Input Class Initialized
INFO - 2024-02-11 11:44:07 --> Language Class Initialized
INFO - 2024-02-11 11:44:07 --> Loader Class Initialized
INFO - 2024-02-11 11:44:07 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:07 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:07 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:07 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:07 --> Controller Class Initialized
INFO - 2024-02-11 11:44:07 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:07 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:44:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:44:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:44:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:44:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:44:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:44:07 --> Final output sent to browser
DEBUG - 2024-02-11 11:44:07 --> Total execution time: 0.0513
ERROR - 2024-02-11 11:44:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:07 --> Config Class Initialized
INFO - 2024-02-11 11:44:07 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:07 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:07 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:07 --> URI Class Initialized
INFO - 2024-02-11 11:44:07 --> Router Class Initialized
INFO - 2024-02-11 11:44:07 --> Output Class Initialized
INFO - 2024-02-11 11:44:07 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:07 --> Input Class Initialized
INFO - 2024-02-11 11:44:07 --> Language Class Initialized
INFO - 2024-02-11 11:44:07 --> Loader Class Initialized
INFO - 2024-02-11 11:44:07 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:07 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:07 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:07 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:07 --> Controller Class Initialized
INFO - 2024-02-11 11:44:07 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:07 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:07 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:44:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:16 --> Config Class Initialized
INFO - 2024-02-11 11:44:16 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:16 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:16 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:16 --> URI Class Initialized
INFO - 2024-02-11 11:44:16 --> Router Class Initialized
INFO - 2024-02-11 11:44:16 --> Output Class Initialized
INFO - 2024-02-11 11:44:16 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:16 --> Input Class Initialized
INFO - 2024-02-11 11:44:16 --> Language Class Initialized
INFO - 2024-02-11 11:44:16 --> Loader Class Initialized
INFO - 2024-02-11 11:44:16 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:16 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:16 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:16 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:16 --> Controller Class Initialized
INFO - 2024-02-11 11:44:16 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:16 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:44:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:44:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:44:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:44:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:44:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:44:16 --> Final output sent to browser
DEBUG - 2024-02-11 11:44:16 --> Total execution time: 0.0278
ERROR - 2024-02-11 11:44:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:17 --> Config Class Initialized
INFO - 2024-02-11 11:44:17 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:17 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:17 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:17 --> URI Class Initialized
INFO - 2024-02-11 11:44:17 --> Router Class Initialized
INFO - 2024-02-11 11:44:17 --> Output Class Initialized
INFO - 2024-02-11 11:44:17 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:17 --> Input Class Initialized
INFO - 2024-02-11 11:44:17 --> Language Class Initialized
INFO - 2024-02-11 11:44:17 --> Loader Class Initialized
INFO - 2024-02-11 11:44:17 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:17 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:17 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:17 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:17 --> Controller Class Initialized
INFO - 2024-02-11 11:44:17 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:17 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:17 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:44:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:29 --> Config Class Initialized
INFO - 2024-02-11 11:44:29 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:29 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:29 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:29 --> URI Class Initialized
INFO - 2024-02-11 11:44:29 --> Router Class Initialized
INFO - 2024-02-11 11:44:29 --> Output Class Initialized
INFO - 2024-02-11 11:44:29 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:29 --> Input Class Initialized
INFO - 2024-02-11 11:44:29 --> Language Class Initialized
INFO - 2024-02-11 11:44:29 --> Loader Class Initialized
INFO - 2024-02-11 11:44:29 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:29 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:29 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:29 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:29 --> Controller Class Initialized
INFO - 2024-02-11 11:44:29 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:29 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:44:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:44:29 --> Final output sent to browser
DEBUG - 2024-02-11 11:44:29 --> Total execution time: 0.0267
ERROR - 2024-02-11 11:44:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:32 --> Config Class Initialized
INFO - 2024-02-11 11:44:32 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:32 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:32 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:32 --> URI Class Initialized
INFO - 2024-02-11 11:44:32 --> Router Class Initialized
INFO - 2024-02-11 11:44:32 --> Output Class Initialized
INFO - 2024-02-11 11:44:32 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:32 --> Input Class Initialized
INFO - 2024-02-11 11:44:32 --> Language Class Initialized
INFO - 2024-02-11 11:44:32 --> Loader Class Initialized
INFO - 2024-02-11 11:44:32 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:32 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:32 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:32 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:32 --> Controller Class Initialized
INFO - 2024-02-11 11:44:32 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:32 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:32 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:44:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:32 --> Config Class Initialized
INFO - 2024-02-11 11:44:32 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:32 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:32 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:32 --> URI Class Initialized
INFO - 2024-02-11 11:44:32 --> Router Class Initialized
INFO - 2024-02-11 11:44:32 --> Output Class Initialized
INFO - 2024-02-11 11:44:32 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:32 --> Input Class Initialized
INFO - 2024-02-11 11:44:32 --> Language Class Initialized
INFO - 2024-02-11 11:44:32 --> Loader Class Initialized
INFO - 2024-02-11 11:44:32 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:32 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:32 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:32 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:32 --> Controller Class Initialized
INFO - 2024-02-11 11:44:32 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:32 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:32 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:42 --> Config Class Initialized
INFO - 2024-02-11 11:44:42 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:42 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:42 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:42 --> URI Class Initialized
INFO - 2024-02-11 11:44:42 --> Router Class Initialized
INFO - 2024-02-11 11:44:42 --> Output Class Initialized
INFO - 2024-02-11 11:44:42 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:42 --> Input Class Initialized
INFO - 2024-02-11 11:44:42 --> Language Class Initialized
INFO - 2024-02-11 11:44:42 --> Loader Class Initialized
INFO - 2024-02-11 11:44:42 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:42 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:42 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:42 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:42 --> Controller Class Initialized
INFO - 2024-02-11 11:44:42 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:42 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:42 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:42 --> Config Class Initialized
INFO - 2024-02-11 11:44:42 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:42 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:42 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:42 --> URI Class Initialized
INFO - 2024-02-11 11:44:42 --> Router Class Initialized
INFO - 2024-02-11 11:44:42 --> Output Class Initialized
INFO - 2024-02-11 11:44:42 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:42 --> Input Class Initialized
INFO - 2024-02-11 11:44:42 --> Language Class Initialized
INFO - 2024-02-11 11:44:42 --> Loader Class Initialized
INFO - 2024-02-11 11:44:42 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:42 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:42 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:42 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:42 --> Controller Class Initialized
INFO - 2024-02-11 11:44:42 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:42 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:42 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:44:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:44:46 --> Config Class Initialized
INFO - 2024-02-11 11:44:46 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:44:46 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:44:46 --> Utf8 Class Initialized
INFO - 2024-02-11 11:44:46 --> URI Class Initialized
INFO - 2024-02-11 11:44:46 --> Router Class Initialized
INFO - 2024-02-11 11:44:46 --> Output Class Initialized
INFO - 2024-02-11 11:44:46 --> Security Class Initialized
DEBUG - 2024-02-11 11:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:44:46 --> Input Class Initialized
INFO - 2024-02-11 11:44:46 --> Language Class Initialized
INFO - 2024-02-11 11:44:46 --> Loader Class Initialized
INFO - 2024-02-11 11:44:46 --> Helper loaded: url_helper
INFO - 2024-02-11 11:44:46 --> Helper loaded: file_helper
INFO - 2024-02-11 11:44:46 --> Helper loaded: form_helper
INFO - 2024-02-11 11:44:46 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:44:46 --> Controller Class Initialized
INFO - 2024-02-11 11:44:46 --> Form Validation Class Initialized
INFO - 2024-02-11 11:44:46 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:44:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:44:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:44:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:44:46 --> Final output sent to browser
DEBUG - 2024-02-11 11:44:46 --> Total execution time: 0.0263
ERROR - 2024-02-11 11:45:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:02 --> Config Class Initialized
INFO - 2024-02-11 11:45:02 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:02 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:02 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:02 --> URI Class Initialized
INFO - 2024-02-11 11:45:02 --> Router Class Initialized
INFO - 2024-02-11 11:45:02 --> Output Class Initialized
INFO - 2024-02-11 11:45:02 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:02 --> Input Class Initialized
INFO - 2024-02-11 11:45:02 --> Language Class Initialized
INFO - 2024-02-11 11:45:02 --> Loader Class Initialized
INFO - 2024-02-11 11:45:02 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:02 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:02 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:02 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:02 --> Controller Class Initialized
INFO - 2024-02-11 11:45:02 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:02 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:02 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:45:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:02 --> Config Class Initialized
INFO - 2024-02-11 11:45:02 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:02 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:02 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:02 --> URI Class Initialized
INFO - 2024-02-11 11:45:02 --> Router Class Initialized
INFO - 2024-02-11 11:45:02 --> Output Class Initialized
INFO - 2024-02-11 11:45:02 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:02 --> Input Class Initialized
INFO - 2024-02-11 11:45:02 --> Language Class Initialized
INFO - 2024-02-11 11:45:02 --> Loader Class Initialized
INFO - 2024-02-11 11:45:02 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:02 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:02 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:02 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:02 --> Controller Class Initialized
INFO - 2024-02-11 11:45:02 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:02 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:02 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:45:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:13 --> Config Class Initialized
INFO - 2024-02-11 11:45:13 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:13 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:13 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:13 --> URI Class Initialized
INFO - 2024-02-11 11:45:13 --> Router Class Initialized
INFO - 2024-02-11 11:45:13 --> Output Class Initialized
INFO - 2024-02-11 11:45:13 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:13 --> Input Class Initialized
INFO - 2024-02-11 11:45:13 --> Language Class Initialized
INFO - 2024-02-11 11:45:13 --> Loader Class Initialized
INFO - 2024-02-11 11:45:13 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:13 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:13 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:13 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:13 --> Controller Class Initialized
INFO - 2024-02-11 11:45:13 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:13 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:45:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:45:13 --> Final output sent to browser
DEBUG - 2024-02-11 11:45:13 --> Total execution time: 0.0236
ERROR - 2024-02-11 11:45:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:22 --> Config Class Initialized
INFO - 2024-02-11 11:45:22 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:22 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:22 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:22 --> URI Class Initialized
INFO - 2024-02-11 11:45:22 --> Router Class Initialized
INFO - 2024-02-11 11:45:22 --> Output Class Initialized
INFO - 2024-02-11 11:45:22 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:22 --> Input Class Initialized
INFO - 2024-02-11 11:45:22 --> Language Class Initialized
INFO - 2024-02-11 11:45:22 --> Loader Class Initialized
INFO - 2024-02-11 11:45:22 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:22 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:22 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:22 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:22 --> Controller Class Initialized
INFO - 2024-02-11 11:45:22 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:22 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:22 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:45:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:23 --> Config Class Initialized
INFO - 2024-02-11 11:45:23 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:23 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:23 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:23 --> URI Class Initialized
INFO - 2024-02-11 11:45:23 --> Router Class Initialized
INFO - 2024-02-11 11:45:23 --> Output Class Initialized
INFO - 2024-02-11 11:45:23 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:23 --> Input Class Initialized
INFO - 2024-02-11 11:45:23 --> Language Class Initialized
INFO - 2024-02-11 11:45:23 --> Loader Class Initialized
INFO - 2024-02-11 11:45:23 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:23 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:23 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:23 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:23 --> Controller Class Initialized
INFO - 2024-02-11 11:45:23 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:23 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:23 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:28 --> Config Class Initialized
INFO - 2024-02-11 11:45:28 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:28 --> URI Class Initialized
INFO - 2024-02-11 11:45:28 --> Router Class Initialized
INFO - 2024-02-11 11:45:28 --> Output Class Initialized
INFO - 2024-02-11 11:45:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:28 --> Input Class Initialized
INFO - 2024-02-11 11:45:28 --> Language Class Initialized
INFO - 2024-02-11 11:45:28 --> Loader Class Initialized
INFO - 2024-02-11 11:45:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:28 --> Controller Class Initialized
INFO - 2024-02-11 11:45:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:45:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:45:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:45:28 --> Total execution time: 0.0228
ERROR - 2024-02-11 11:45:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:33 --> Config Class Initialized
INFO - 2024-02-11 11:45:33 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:33 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:33 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:33 --> URI Class Initialized
INFO - 2024-02-11 11:45:33 --> Router Class Initialized
INFO - 2024-02-11 11:45:33 --> Output Class Initialized
INFO - 2024-02-11 11:45:33 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:33 --> Input Class Initialized
INFO - 2024-02-11 11:45:33 --> Language Class Initialized
INFO - 2024-02-11 11:45:33 --> Loader Class Initialized
INFO - 2024-02-11 11:45:33 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:33 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:33 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:33 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:33 --> Controller Class Initialized
INFO - 2024-02-11 11:45:33 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:33 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:33 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:45:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:33 --> Config Class Initialized
INFO - 2024-02-11 11:45:33 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:33 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:33 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:33 --> URI Class Initialized
INFO - 2024-02-11 11:45:33 --> Router Class Initialized
INFO - 2024-02-11 11:45:33 --> Output Class Initialized
INFO - 2024-02-11 11:45:33 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:33 --> Input Class Initialized
INFO - 2024-02-11 11:45:33 --> Language Class Initialized
INFO - 2024-02-11 11:45:33 --> Loader Class Initialized
INFO - 2024-02-11 11:45:33 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:33 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:33 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:33 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:33 --> Controller Class Initialized
INFO - 2024-02-11 11:45:33 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:33 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:33 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:45:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:35 --> Config Class Initialized
INFO - 2024-02-11 11:45:35 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:35 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:35 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:35 --> URI Class Initialized
INFO - 2024-02-11 11:45:35 --> Router Class Initialized
INFO - 2024-02-11 11:45:35 --> Output Class Initialized
INFO - 2024-02-11 11:45:35 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:35 --> Input Class Initialized
INFO - 2024-02-11 11:45:35 --> Language Class Initialized
INFO - 2024-02-11 11:45:35 --> Loader Class Initialized
INFO - 2024-02-11 11:45:35 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:35 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:35 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:35 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:35 --> Controller Class Initialized
INFO - 2024-02-11 11:45:35 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:35 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:45:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:45:35 --> Final output sent to browser
DEBUG - 2024-02-11 11:45:35 --> Total execution time: 0.0247
ERROR - 2024-02-11 11:45:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:38 --> Config Class Initialized
INFO - 2024-02-11 11:45:38 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:38 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:38 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:38 --> URI Class Initialized
INFO - 2024-02-11 11:45:38 --> Router Class Initialized
INFO - 2024-02-11 11:45:38 --> Output Class Initialized
INFO - 2024-02-11 11:45:38 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:38 --> Input Class Initialized
INFO - 2024-02-11 11:45:38 --> Language Class Initialized
INFO - 2024-02-11 11:45:38 --> Loader Class Initialized
INFO - 2024-02-11 11:45:38 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:38 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:38 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:38 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:38 --> Controller Class Initialized
INFO - 2024-02-11 11:45:38 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:38 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:38 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:45:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:43 --> Config Class Initialized
INFO - 2024-02-11 11:45:43 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:43 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:43 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:43 --> URI Class Initialized
INFO - 2024-02-11 11:45:43 --> Router Class Initialized
INFO - 2024-02-11 11:45:43 --> Output Class Initialized
INFO - 2024-02-11 11:45:43 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:43 --> Input Class Initialized
INFO - 2024-02-11 11:45:43 --> Language Class Initialized
INFO - 2024-02-11 11:45:43 --> Loader Class Initialized
INFO - 2024-02-11 11:45:43 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:43 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:43 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:43 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:43 --> Controller Class Initialized
INFO - 2024-02-11 11:45:43 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:43 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:43 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:45:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:50 --> Config Class Initialized
INFO - 2024-02-11 11:45:50 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:50 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:50 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:50 --> URI Class Initialized
INFO - 2024-02-11 11:45:50 --> Router Class Initialized
INFO - 2024-02-11 11:45:50 --> Output Class Initialized
INFO - 2024-02-11 11:45:50 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:50 --> Input Class Initialized
INFO - 2024-02-11 11:45:50 --> Language Class Initialized
INFO - 2024-02-11 11:45:50 --> Loader Class Initialized
INFO - 2024-02-11 11:45:50 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:50 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:50 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:50 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:50 --> Controller Class Initialized
INFO - 2024-02-11 11:45:50 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:50 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:50 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:45:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:50 --> Config Class Initialized
INFO - 2024-02-11 11:45:50 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:50 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:50 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:50 --> URI Class Initialized
INFO - 2024-02-11 11:45:50 --> Router Class Initialized
INFO - 2024-02-11 11:45:50 --> Output Class Initialized
INFO - 2024-02-11 11:45:50 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:50 --> Input Class Initialized
INFO - 2024-02-11 11:45:50 --> Language Class Initialized
INFO - 2024-02-11 11:45:50 --> Loader Class Initialized
INFO - 2024-02-11 11:45:50 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:50 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:50 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:50 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:50 --> Controller Class Initialized
INFO - 2024-02-11 11:45:50 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:50 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:50 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:45:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:54 --> Config Class Initialized
INFO - 2024-02-11 11:45:54 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:54 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:54 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:54 --> URI Class Initialized
INFO - 2024-02-11 11:45:54 --> Router Class Initialized
INFO - 2024-02-11 11:45:54 --> Output Class Initialized
INFO - 2024-02-11 11:45:54 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:54 --> Input Class Initialized
INFO - 2024-02-11 11:45:54 --> Language Class Initialized
INFO - 2024-02-11 11:45:54 --> Loader Class Initialized
INFO - 2024-02-11 11:45:54 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:54 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:54 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:54 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:54 --> Controller Class Initialized
INFO - 2024-02-11 11:45:54 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:54 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:45:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:45:54 --> Final output sent to browser
DEBUG - 2024-02-11 11:45:54 --> Total execution time: 0.0222
ERROR - 2024-02-11 11:45:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:59 --> Config Class Initialized
INFO - 2024-02-11 11:45:59 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:59 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:59 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:59 --> URI Class Initialized
INFO - 2024-02-11 11:45:59 --> Router Class Initialized
INFO - 2024-02-11 11:45:59 --> Output Class Initialized
INFO - 2024-02-11 11:45:59 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:59 --> Input Class Initialized
INFO - 2024-02-11 11:45:59 --> Language Class Initialized
INFO - 2024-02-11 11:45:59 --> Loader Class Initialized
INFO - 2024-02-11 11:45:59 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:59 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:59 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:59 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:59 --> Controller Class Initialized
INFO - 2024-02-11 11:45:59 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:59 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:59 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:45:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:45:59 --> Config Class Initialized
INFO - 2024-02-11 11:45:59 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:45:59 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:45:59 --> Utf8 Class Initialized
INFO - 2024-02-11 11:45:59 --> URI Class Initialized
INFO - 2024-02-11 11:45:59 --> Router Class Initialized
INFO - 2024-02-11 11:45:59 --> Output Class Initialized
INFO - 2024-02-11 11:45:59 --> Security Class Initialized
DEBUG - 2024-02-11 11:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:45:59 --> Input Class Initialized
INFO - 2024-02-11 11:45:59 --> Language Class Initialized
INFO - 2024-02-11 11:45:59 --> Loader Class Initialized
INFO - 2024-02-11 11:45:59 --> Helper loaded: url_helper
INFO - 2024-02-11 11:45:59 --> Helper loaded: file_helper
INFO - 2024-02-11 11:45:59 --> Helper loaded: form_helper
INFO - 2024-02-11 11:45:59 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:45:59 --> Controller Class Initialized
INFO - 2024-02-11 11:45:59 --> Form Validation Class Initialized
INFO - 2024-02-11 11:45:59 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:45:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:45:59 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:01 --> Config Class Initialized
INFO - 2024-02-11 11:46:01 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:01 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:01 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:01 --> URI Class Initialized
INFO - 2024-02-11 11:46:01 --> Router Class Initialized
INFO - 2024-02-11 11:46:01 --> Output Class Initialized
INFO - 2024-02-11 11:46:01 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:01 --> Input Class Initialized
INFO - 2024-02-11 11:46:01 --> Language Class Initialized
INFO - 2024-02-11 11:46:01 --> Loader Class Initialized
INFO - 2024-02-11 11:46:01 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:01 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:01 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:01 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:01 --> Controller Class Initialized
INFO - 2024-02-11 11:46:01 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:01 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:46:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:46:01 --> Final output sent to browser
DEBUG - 2024-02-11 11:46:01 --> Total execution time: 0.0216
ERROR - 2024-02-11 11:46:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:06 --> Config Class Initialized
INFO - 2024-02-11 11:46:06 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:06 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:06 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:06 --> URI Class Initialized
INFO - 2024-02-11 11:46:06 --> Router Class Initialized
INFO - 2024-02-11 11:46:06 --> Output Class Initialized
INFO - 2024-02-11 11:46:06 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:06 --> Input Class Initialized
INFO - 2024-02-11 11:46:06 --> Language Class Initialized
INFO - 2024-02-11 11:46:06 --> Loader Class Initialized
INFO - 2024-02-11 11:46:06 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:06 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:06 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:06 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:06 --> Controller Class Initialized
INFO - 2024-02-11 11:46:06 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:06 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:06 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:06 --> Config Class Initialized
INFO - 2024-02-11 11:46:06 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:06 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:06 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:06 --> URI Class Initialized
INFO - 2024-02-11 11:46:06 --> Router Class Initialized
INFO - 2024-02-11 11:46:06 --> Output Class Initialized
INFO - 2024-02-11 11:46:06 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:06 --> Input Class Initialized
INFO - 2024-02-11 11:46:06 --> Language Class Initialized
INFO - 2024-02-11 11:46:06 --> Loader Class Initialized
INFO - 2024-02-11 11:46:06 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:06 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:06 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:06 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:06 --> Controller Class Initialized
INFO - 2024-02-11 11:46:06 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:06 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:06 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:09 --> Config Class Initialized
INFO - 2024-02-11 11:46:09 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:09 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:09 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:09 --> URI Class Initialized
INFO - 2024-02-11 11:46:09 --> Router Class Initialized
INFO - 2024-02-11 11:46:09 --> Output Class Initialized
INFO - 2024-02-11 11:46:09 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:09 --> Input Class Initialized
INFO - 2024-02-11 11:46:09 --> Language Class Initialized
INFO - 2024-02-11 11:46:09 --> Loader Class Initialized
INFO - 2024-02-11 11:46:09 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:09 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:09 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:09 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:09 --> Controller Class Initialized
INFO - 2024-02-11 11:46:09 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:09 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:46:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:46:09 --> Final output sent to browser
DEBUG - 2024-02-11 11:46:09 --> Total execution time: 0.0251
ERROR - 2024-02-11 11:46:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:14 --> Config Class Initialized
INFO - 2024-02-11 11:46:14 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:14 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:14 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:14 --> URI Class Initialized
INFO - 2024-02-11 11:46:14 --> Router Class Initialized
INFO - 2024-02-11 11:46:14 --> Output Class Initialized
INFO - 2024-02-11 11:46:14 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:14 --> Input Class Initialized
INFO - 2024-02-11 11:46:14 --> Language Class Initialized
INFO - 2024-02-11 11:46:14 --> Loader Class Initialized
INFO - 2024-02-11 11:46:14 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:14 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:14 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:14 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:14 --> Controller Class Initialized
INFO - 2024-02-11 11:46:14 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:14 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:14 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:14 --> Config Class Initialized
INFO - 2024-02-11 11:46:14 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:14 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:14 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:14 --> URI Class Initialized
INFO - 2024-02-11 11:46:14 --> Router Class Initialized
INFO - 2024-02-11 11:46:14 --> Output Class Initialized
INFO - 2024-02-11 11:46:14 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:14 --> Input Class Initialized
INFO - 2024-02-11 11:46:14 --> Language Class Initialized
INFO - 2024-02-11 11:46:14 --> Loader Class Initialized
INFO - 2024-02-11 11:46:14 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:14 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:14 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:14 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:14 --> Controller Class Initialized
INFO - 2024-02-11 11:46:14 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:14 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:14 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:16 --> Config Class Initialized
INFO - 2024-02-11 11:46:16 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:16 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:16 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:16 --> URI Class Initialized
INFO - 2024-02-11 11:46:16 --> Router Class Initialized
INFO - 2024-02-11 11:46:16 --> Output Class Initialized
INFO - 2024-02-11 11:46:16 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:16 --> Input Class Initialized
INFO - 2024-02-11 11:46:16 --> Language Class Initialized
INFO - 2024-02-11 11:46:16 --> Loader Class Initialized
INFO - 2024-02-11 11:46:16 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:16 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:16 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:16 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:16 --> Controller Class Initialized
INFO - 2024-02-11 11:46:16 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:16 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:46:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:46:16 --> Final output sent to browser
DEBUG - 2024-02-11 11:46:16 --> Total execution time: 0.0254
ERROR - 2024-02-11 11:46:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:21 --> Config Class Initialized
INFO - 2024-02-11 11:46:21 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:21 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:21 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:21 --> URI Class Initialized
INFO - 2024-02-11 11:46:21 --> Router Class Initialized
INFO - 2024-02-11 11:46:21 --> Output Class Initialized
INFO - 2024-02-11 11:46:21 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:21 --> Input Class Initialized
INFO - 2024-02-11 11:46:21 --> Language Class Initialized
INFO - 2024-02-11 11:46:21 --> Loader Class Initialized
INFO - 2024-02-11 11:46:21 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:21 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:21 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:21 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:21 --> Controller Class Initialized
INFO - 2024-02-11 11:46:21 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:21 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:21 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:21 --> Config Class Initialized
INFO - 2024-02-11 11:46:21 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:21 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:21 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:21 --> URI Class Initialized
INFO - 2024-02-11 11:46:21 --> Router Class Initialized
INFO - 2024-02-11 11:46:21 --> Output Class Initialized
INFO - 2024-02-11 11:46:21 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:21 --> Input Class Initialized
INFO - 2024-02-11 11:46:21 --> Language Class Initialized
INFO - 2024-02-11 11:46:21 --> Loader Class Initialized
INFO - 2024-02-11 11:46:21 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:21 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:21 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:21 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:21 --> Controller Class Initialized
INFO - 2024-02-11 11:46:21 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:21 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:21 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:23 --> Config Class Initialized
INFO - 2024-02-11 11:46:23 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:23 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:23 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:23 --> URI Class Initialized
INFO - 2024-02-11 11:46:23 --> Router Class Initialized
INFO - 2024-02-11 11:46:23 --> Output Class Initialized
INFO - 2024-02-11 11:46:23 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:23 --> Input Class Initialized
INFO - 2024-02-11 11:46:23 --> Language Class Initialized
INFO - 2024-02-11 11:46:23 --> Loader Class Initialized
INFO - 2024-02-11 11:46:23 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:23 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:23 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:23 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:23 --> Controller Class Initialized
INFO - 2024-02-11 11:46:23 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:23 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:46:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:46:23 --> Final output sent to browser
DEBUG - 2024-02-11 11:46:23 --> Total execution time: 0.0224
ERROR - 2024-02-11 11:46:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:27 --> Config Class Initialized
INFO - 2024-02-11 11:46:27 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:27 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:27 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:27 --> URI Class Initialized
INFO - 2024-02-11 11:46:27 --> Router Class Initialized
INFO - 2024-02-11 11:46:27 --> Output Class Initialized
INFO - 2024-02-11 11:46:27 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:27 --> Input Class Initialized
INFO - 2024-02-11 11:46:27 --> Language Class Initialized
INFO - 2024-02-11 11:46:27 --> Loader Class Initialized
INFO - 2024-02-11 11:46:27 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:27 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:27 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:27 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:27 --> Controller Class Initialized
INFO - 2024-02-11 11:46:27 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:27 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:27 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:27 --> Config Class Initialized
INFO - 2024-02-11 11:46:27 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:27 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:27 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:27 --> URI Class Initialized
INFO - 2024-02-11 11:46:27 --> Router Class Initialized
INFO - 2024-02-11 11:46:27 --> Output Class Initialized
INFO - 2024-02-11 11:46:27 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:27 --> Input Class Initialized
INFO - 2024-02-11 11:46:27 --> Language Class Initialized
INFO - 2024-02-11 11:46:27 --> Loader Class Initialized
INFO - 2024-02-11 11:46:27 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:27 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:27 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:27 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:27 --> Controller Class Initialized
INFO - 2024-02-11 11:46:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:28 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:31 --> Config Class Initialized
INFO - 2024-02-11 11:46:31 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:31 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:31 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:31 --> URI Class Initialized
INFO - 2024-02-11 11:46:31 --> Router Class Initialized
INFO - 2024-02-11 11:46:31 --> Output Class Initialized
INFO - 2024-02-11 11:46:31 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:31 --> Input Class Initialized
INFO - 2024-02-11 11:46:31 --> Language Class Initialized
INFO - 2024-02-11 11:46:31 --> Loader Class Initialized
INFO - 2024-02-11 11:46:31 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:31 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:31 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:31 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:31 --> Controller Class Initialized
INFO - 2024-02-11 11:46:31 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:31 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:46:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:46:31 --> Final output sent to browser
DEBUG - 2024-02-11 11:46:31 --> Total execution time: 0.0229
ERROR - 2024-02-11 11:46:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:36 --> Config Class Initialized
INFO - 2024-02-11 11:46:36 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:36 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:36 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:36 --> URI Class Initialized
INFO - 2024-02-11 11:46:36 --> Router Class Initialized
INFO - 2024-02-11 11:46:36 --> Output Class Initialized
INFO - 2024-02-11 11:46:36 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:36 --> Input Class Initialized
INFO - 2024-02-11 11:46:36 --> Language Class Initialized
INFO - 2024-02-11 11:46:36 --> Loader Class Initialized
INFO - 2024-02-11 11:46:36 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:36 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:36 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:36 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:36 --> Controller Class Initialized
INFO - 2024-02-11 11:46:36 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:36 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:36 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:36 --> Config Class Initialized
INFO - 2024-02-11 11:46:36 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:36 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:36 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:36 --> URI Class Initialized
INFO - 2024-02-11 11:46:36 --> Router Class Initialized
INFO - 2024-02-11 11:46:36 --> Output Class Initialized
INFO - 2024-02-11 11:46:36 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:36 --> Input Class Initialized
INFO - 2024-02-11 11:46:36 --> Language Class Initialized
INFO - 2024-02-11 11:46:36 --> Loader Class Initialized
INFO - 2024-02-11 11:46:36 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:36 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:36 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:36 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:36 --> Controller Class Initialized
INFO - 2024-02-11 11:46:36 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:36 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:36 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:39 --> Config Class Initialized
INFO - 2024-02-11 11:46:39 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:39 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:39 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:39 --> URI Class Initialized
INFO - 2024-02-11 11:46:39 --> Router Class Initialized
INFO - 2024-02-11 11:46:39 --> Output Class Initialized
INFO - 2024-02-11 11:46:39 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:39 --> Input Class Initialized
INFO - 2024-02-11 11:46:39 --> Language Class Initialized
INFO - 2024-02-11 11:46:39 --> Loader Class Initialized
INFO - 2024-02-11 11:46:39 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:39 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:39 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:39 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:39 --> Controller Class Initialized
INFO - 2024-02-11 11:46:39 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:39 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:39 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:41 --> Config Class Initialized
INFO - 2024-02-11 11:46:41 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:41 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:41 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:41 --> URI Class Initialized
INFO - 2024-02-11 11:46:41 --> Router Class Initialized
INFO - 2024-02-11 11:46:41 --> Output Class Initialized
INFO - 2024-02-11 11:46:41 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:41 --> Input Class Initialized
INFO - 2024-02-11 11:46:41 --> Language Class Initialized
INFO - 2024-02-11 11:46:41 --> Loader Class Initialized
INFO - 2024-02-11 11:46:41 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:41 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:41 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:41 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:41 --> Controller Class Initialized
INFO - 2024-02-11 11:46:41 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:41 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:41 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:43 --> Config Class Initialized
INFO - 2024-02-11 11:46:43 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:43 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:43 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:43 --> URI Class Initialized
INFO - 2024-02-11 11:46:43 --> Router Class Initialized
INFO - 2024-02-11 11:46:43 --> Output Class Initialized
INFO - 2024-02-11 11:46:43 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:43 --> Input Class Initialized
INFO - 2024-02-11 11:46:43 --> Language Class Initialized
INFO - 2024-02-11 11:46:43 --> Loader Class Initialized
INFO - 2024-02-11 11:46:43 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:43 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:43 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:43 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:43 --> Controller Class Initialized
INFO - 2024-02-11 11:46:43 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:43 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:43 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:45 --> Config Class Initialized
INFO - 2024-02-11 11:46:45 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:45 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:45 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:45 --> URI Class Initialized
INFO - 2024-02-11 11:46:45 --> Router Class Initialized
INFO - 2024-02-11 11:46:45 --> Output Class Initialized
INFO - 2024-02-11 11:46:45 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:45 --> Input Class Initialized
INFO - 2024-02-11 11:46:45 --> Language Class Initialized
INFO - 2024-02-11 11:46:45 --> Loader Class Initialized
INFO - 2024-02-11 11:46:45 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:45 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:45 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:45 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:45 --> Controller Class Initialized
INFO - 2024-02-11 11:46:45 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:45 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:45 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:46:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:46:59 --> Config Class Initialized
INFO - 2024-02-11 11:46:59 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:46:59 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:46:59 --> Utf8 Class Initialized
INFO - 2024-02-11 11:46:59 --> URI Class Initialized
INFO - 2024-02-11 11:46:59 --> Router Class Initialized
INFO - 2024-02-11 11:46:59 --> Output Class Initialized
INFO - 2024-02-11 11:46:59 --> Security Class Initialized
DEBUG - 2024-02-11 11:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:46:59 --> Input Class Initialized
INFO - 2024-02-11 11:46:59 --> Language Class Initialized
INFO - 2024-02-11 11:46:59 --> Loader Class Initialized
INFO - 2024-02-11 11:46:59 --> Helper loaded: url_helper
INFO - 2024-02-11 11:46:59 --> Helper loaded: file_helper
INFO - 2024-02-11 11:46:59 --> Helper loaded: form_helper
INFO - 2024-02-11 11:46:59 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:46:59 --> Controller Class Initialized
INFO - 2024-02-11 11:46:59 --> Form Validation Class Initialized
INFO - 2024-02-11 11:46:59 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:46:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:46:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:46:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:46:59 --> Final output sent to browser
DEBUG - 2024-02-11 11:46:59 --> Total execution time: 0.0266
ERROR - 2024-02-11 11:47:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:47:34 --> Config Class Initialized
INFO - 2024-02-11 11:47:34 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:47:34 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:47:34 --> Utf8 Class Initialized
INFO - 2024-02-11 11:47:34 --> URI Class Initialized
INFO - 2024-02-11 11:47:34 --> Router Class Initialized
INFO - 2024-02-11 11:47:34 --> Output Class Initialized
INFO - 2024-02-11 11:47:34 --> Security Class Initialized
DEBUG - 2024-02-11 11:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:47:34 --> Input Class Initialized
INFO - 2024-02-11 11:47:34 --> Language Class Initialized
INFO - 2024-02-11 11:47:34 --> Loader Class Initialized
INFO - 2024-02-11 11:47:34 --> Helper loaded: url_helper
INFO - 2024-02-11 11:47:34 --> Helper loaded: file_helper
INFO - 2024-02-11 11:47:34 --> Helper loaded: form_helper
INFO - 2024-02-11 11:47:34 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:47:34 --> Controller Class Initialized
INFO - 2024-02-11 11:47:34 --> Form Validation Class Initialized
INFO - 2024-02-11 11:47:34 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:47:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:47:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:47:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:47:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:47:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:47:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:47:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:47:34 --> Final output sent to browser
DEBUG - 2024-02-11 11:47:34 --> Total execution time: 0.0290
ERROR - 2024-02-11 11:47:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:47:35 --> Config Class Initialized
INFO - 2024-02-11 11:47:35 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:47:35 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:47:35 --> Utf8 Class Initialized
INFO - 2024-02-11 11:47:35 --> URI Class Initialized
INFO - 2024-02-11 11:47:35 --> Router Class Initialized
INFO - 2024-02-11 11:47:35 --> Output Class Initialized
INFO - 2024-02-11 11:47:35 --> Security Class Initialized
DEBUG - 2024-02-11 11:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:47:35 --> Input Class Initialized
INFO - 2024-02-11 11:47:35 --> Language Class Initialized
INFO - 2024-02-11 11:47:35 --> Loader Class Initialized
INFO - 2024-02-11 11:47:35 --> Helper loaded: url_helper
INFO - 2024-02-11 11:47:35 --> Helper loaded: file_helper
INFO - 2024-02-11 11:47:35 --> Helper loaded: form_helper
INFO - 2024-02-11 11:47:35 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:47:35 --> Controller Class Initialized
INFO - 2024-02-11 11:47:35 --> Form Validation Class Initialized
INFO - 2024-02-11 11:47:35 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:47:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:47:35 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:47:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:47:40 --> Config Class Initialized
INFO - 2024-02-11 11:47:40 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:47:40 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:47:40 --> Utf8 Class Initialized
INFO - 2024-02-11 11:47:40 --> URI Class Initialized
INFO - 2024-02-11 11:47:40 --> Router Class Initialized
INFO - 2024-02-11 11:47:40 --> Output Class Initialized
INFO - 2024-02-11 11:47:40 --> Security Class Initialized
DEBUG - 2024-02-11 11:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:47:40 --> Input Class Initialized
INFO - 2024-02-11 11:47:40 --> Language Class Initialized
INFO - 2024-02-11 11:47:40 --> Loader Class Initialized
INFO - 2024-02-11 11:47:40 --> Helper loaded: url_helper
INFO - 2024-02-11 11:47:40 --> Helper loaded: file_helper
INFO - 2024-02-11 11:47:40 --> Helper loaded: form_helper
INFO - 2024-02-11 11:47:40 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:47:40 --> Controller Class Initialized
INFO - 2024-02-11 11:47:40 --> Form Validation Class Initialized
INFO - 2024-02-11 11:47:40 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:47:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:47:40 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:47:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:47:42 --> Config Class Initialized
INFO - 2024-02-11 11:47:42 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:47:42 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:47:42 --> Utf8 Class Initialized
INFO - 2024-02-11 11:47:42 --> URI Class Initialized
INFO - 2024-02-11 11:47:42 --> Router Class Initialized
INFO - 2024-02-11 11:47:42 --> Output Class Initialized
INFO - 2024-02-11 11:47:42 --> Security Class Initialized
DEBUG - 2024-02-11 11:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:47:42 --> Input Class Initialized
INFO - 2024-02-11 11:47:42 --> Language Class Initialized
INFO - 2024-02-11 11:47:42 --> Loader Class Initialized
INFO - 2024-02-11 11:47:42 --> Helper loaded: url_helper
INFO - 2024-02-11 11:47:42 --> Helper loaded: file_helper
INFO - 2024-02-11 11:47:42 --> Helper loaded: form_helper
INFO - 2024-02-11 11:47:42 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:47:42 --> Controller Class Initialized
INFO - 2024-02-11 11:47:42 --> Form Validation Class Initialized
INFO - 2024-02-11 11:47:42 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:47:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:47:42 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:47:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:47:53 --> Config Class Initialized
INFO - 2024-02-11 11:47:53 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:47:53 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:47:53 --> Utf8 Class Initialized
INFO - 2024-02-11 11:47:53 --> URI Class Initialized
INFO - 2024-02-11 11:47:53 --> Router Class Initialized
INFO - 2024-02-11 11:47:53 --> Output Class Initialized
INFO - 2024-02-11 11:47:53 --> Security Class Initialized
DEBUG - 2024-02-11 11:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:47:53 --> Input Class Initialized
INFO - 2024-02-11 11:47:53 --> Language Class Initialized
INFO - 2024-02-11 11:47:53 --> Loader Class Initialized
INFO - 2024-02-11 11:47:53 --> Helper loaded: url_helper
INFO - 2024-02-11 11:47:53 --> Helper loaded: file_helper
INFO - 2024-02-11 11:47:53 --> Helper loaded: form_helper
INFO - 2024-02-11 11:47:53 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:47:53 --> Controller Class Initialized
INFO - 2024-02-11 11:47:53 --> Form Validation Class Initialized
INFO - 2024-02-11 11:47:53 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:47:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:47:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:47:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:47:53 --> Final output sent to browser
DEBUG - 2024-02-11 11:47:53 --> Total execution time: 0.0269
ERROR - 2024-02-11 11:48:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:48:54 --> Config Class Initialized
INFO - 2024-02-11 11:48:54 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:48:54 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:48:54 --> Utf8 Class Initialized
INFO - 2024-02-11 11:48:54 --> URI Class Initialized
INFO - 2024-02-11 11:48:54 --> Router Class Initialized
INFO - 2024-02-11 11:48:54 --> Output Class Initialized
INFO - 2024-02-11 11:48:54 --> Security Class Initialized
DEBUG - 2024-02-11 11:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:48:54 --> Input Class Initialized
INFO - 2024-02-11 11:48:54 --> Language Class Initialized
INFO - 2024-02-11 11:48:54 --> Loader Class Initialized
INFO - 2024-02-11 11:48:54 --> Helper loaded: url_helper
INFO - 2024-02-11 11:48:54 --> Helper loaded: file_helper
INFO - 2024-02-11 11:48:54 --> Helper loaded: form_helper
INFO - 2024-02-11 11:48:54 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:48:54 --> Controller Class Initialized
INFO - 2024-02-11 11:48:54 --> Form Validation Class Initialized
INFO - 2024-02-11 11:48:54 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:48:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:48:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:48:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:48:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:48:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:48:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:48:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:48:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:48:54 --> Final output sent to browser
DEBUG - 2024-02-11 11:48:54 --> Total execution time: 0.0250
ERROR - 2024-02-11 11:48:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:48:56 --> Config Class Initialized
INFO - 2024-02-11 11:48:56 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:48:56 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:48:56 --> Utf8 Class Initialized
INFO - 2024-02-11 11:48:56 --> URI Class Initialized
INFO - 2024-02-11 11:48:56 --> Router Class Initialized
INFO - 2024-02-11 11:48:56 --> Output Class Initialized
INFO - 2024-02-11 11:48:56 --> Security Class Initialized
DEBUG - 2024-02-11 11:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:48:56 --> Input Class Initialized
INFO - 2024-02-11 11:48:56 --> Language Class Initialized
INFO - 2024-02-11 11:48:56 --> Loader Class Initialized
INFO - 2024-02-11 11:48:56 --> Helper loaded: url_helper
INFO - 2024-02-11 11:48:56 --> Helper loaded: file_helper
INFO - 2024-02-11 11:48:56 --> Helper loaded: form_helper
INFO - 2024-02-11 11:48:56 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:48:56 --> Controller Class Initialized
INFO - 2024-02-11 11:48:56 --> Form Validation Class Initialized
INFO - 2024-02-11 11:48:56 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:48:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:48:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:48:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:48:56 --> Final output sent to browser
DEBUG - 2024-02-11 11:48:56 --> Total execution time: 0.0274
ERROR - 2024-02-11 11:48:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:48:56 --> Config Class Initialized
INFO - 2024-02-11 11:48:56 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:48:56 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:48:56 --> Utf8 Class Initialized
INFO - 2024-02-11 11:48:56 --> URI Class Initialized
INFO - 2024-02-11 11:48:56 --> Router Class Initialized
INFO - 2024-02-11 11:48:56 --> Output Class Initialized
INFO - 2024-02-11 11:48:56 --> Security Class Initialized
DEBUG - 2024-02-11 11:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:48:56 --> Input Class Initialized
INFO - 2024-02-11 11:48:56 --> Language Class Initialized
INFO - 2024-02-11 11:48:56 --> Loader Class Initialized
INFO - 2024-02-11 11:48:56 --> Helper loaded: url_helper
INFO - 2024-02-11 11:48:56 --> Helper loaded: file_helper
INFO - 2024-02-11 11:48:56 --> Helper loaded: form_helper
INFO - 2024-02-11 11:48:56 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:48:56 --> Controller Class Initialized
INFO - 2024-02-11 11:48:56 --> Form Validation Class Initialized
INFO - 2024-02-11 11:48:56 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:48:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:48:56 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:48:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:48:58 --> Config Class Initialized
INFO - 2024-02-11 11:48:58 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:48:58 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:48:58 --> Utf8 Class Initialized
INFO - 2024-02-11 11:48:58 --> URI Class Initialized
INFO - 2024-02-11 11:48:58 --> Router Class Initialized
INFO - 2024-02-11 11:48:58 --> Output Class Initialized
INFO - 2024-02-11 11:48:58 --> Security Class Initialized
DEBUG - 2024-02-11 11:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:48:58 --> Input Class Initialized
INFO - 2024-02-11 11:48:58 --> Language Class Initialized
INFO - 2024-02-11 11:48:58 --> Loader Class Initialized
INFO - 2024-02-11 11:48:59 --> Helper loaded: url_helper
INFO - 2024-02-11 11:48:59 --> Helper loaded: file_helper
INFO - 2024-02-11 11:48:59 --> Helper loaded: form_helper
INFO - 2024-02-11 11:48:59 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:48:59 --> Controller Class Initialized
INFO - 2024-02-11 11:48:59 --> Form Validation Class Initialized
INFO - 2024-02-11 11:48:59 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:48:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:48:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:48:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:48:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:48:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:48:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:48:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:48:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:48:59 --> Final output sent to browser
DEBUG - 2024-02-11 11:48:59 --> Total execution time: 0.0295
ERROR - 2024-02-11 11:49:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:49:10 --> Config Class Initialized
INFO - 2024-02-11 11:49:10 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:49:10 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:49:10 --> Utf8 Class Initialized
INFO - 2024-02-11 11:49:10 --> URI Class Initialized
INFO - 2024-02-11 11:49:10 --> Router Class Initialized
INFO - 2024-02-11 11:49:10 --> Output Class Initialized
INFO - 2024-02-11 11:49:10 --> Security Class Initialized
DEBUG - 2024-02-11 11:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:49:10 --> Input Class Initialized
INFO - 2024-02-11 11:49:10 --> Language Class Initialized
INFO - 2024-02-11 11:49:10 --> Loader Class Initialized
INFO - 2024-02-11 11:49:10 --> Helper loaded: url_helper
INFO - 2024-02-11 11:49:11 --> Helper loaded: file_helper
INFO - 2024-02-11 11:49:11 --> Helper loaded: form_helper
INFO - 2024-02-11 11:49:11 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:49:11 --> Controller Class Initialized
INFO - 2024-02-11 11:49:11 --> Form Validation Class Initialized
INFO - 2024-02-11 11:49:11 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:49:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:49:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:49:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:49:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:49:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:49:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:49:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:49:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:49:11 --> Final output sent to browser
DEBUG - 2024-02-11 11:49:11 --> Total execution time: 0.0351
ERROR - 2024-02-11 11:52:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:01 --> Config Class Initialized
INFO - 2024-02-11 11:52:01 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:01 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:01 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:01 --> URI Class Initialized
INFO - 2024-02-11 11:52:01 --> Router Class Initialized
INFO - 2024-02-11 11:52:01 --> Output Class Initialized
INFO - 2024-02-11 11:52:01 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:01 --> Input Class Initialized
INFO - 2024-02-11 11:52:01 --> Language Class Initialized
INFO - 2024-02-11 11:52:01 --> Loader Class Initialized
INFO - 2024-02-11 11:52:01 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:01 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:01 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:01 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:01 --> Controller Class Initialized
INFO - 2024-02-11 11:52:01 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:01 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:01 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:01 --> Total execution time: 0.0334
ERROR - 2024-02-11 11:52:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:10 --> Config Class Initialized
INFO - 2024-02-11 11:52:10 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:10 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:10 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:10 --> URI Class Initialized
INFO - 2024-02-11 11:52:10 --> Router Class Initialized
INFO - 2024-02-11 11:52:10 --> Output Class Initialized
INFO - 2024-02-11 11:52:10 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:10 --> Input Class Initialized
INFO - 2024-02-11 11:52:10 --> Language Class Initialized
INFO - 2024-02-11 11:52:10 --> Loader Class Initialized
INFO - 2024-02-11 11:52:10 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:10 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:10 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:10 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:10 --> Controller Class Initialized
INFO - 2024-02-11 11:52:10 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:10 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:10 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:10 --> Total execution time: 0.0237
ERROR - 2024-02-11 11:52:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:14 --> Config Class Initialized
INFO - 2024-02-11 11:52:14 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:14 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:14 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:14 --> URI Class Initialized
INFO - 2024-02-11 11:52:14 --> Router Class Initialized
INFO - 2024-02-11 11:52:14 --> Output Class Initialized
INFO - 2024-02-11 11:52:14 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:14 --> Input Class Initialized
INFO - 2024-02-11 11:52:14 --> Language Class Initialized
INFO - 2024-02-11 11:52:14 --> Loader Class Initialized
INFO - 2024-02-11 11:52:14 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:14 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:14 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:14 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:14 --> Controller Class Initialized
INFO - 2024-02-11 11:52:14 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:14 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:14 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:14 --> Total execution time: 0.0448
ERROR - 2024-02-11 11:52:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:27 --> Config Class Initialized
INFO - 2024-02-11 11:52:27 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:27 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:27 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:27 --> URI Class Initialized
INFO - 2024-02-11 11:52:27 --> Router Class Initialized
INFO - 2024-02-11 11:52:27 --> Output Class Initialized
INFO - 2024-02-11 11:52:27 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:27 --> Input Class Initialized
INFO - 2024-02-11 11:52:27 --> Language Class Initialized
INFO - 2024-02-11 11:52:27 --> Loader Class Initialized
INFO - 2024-02-11 11:52:27 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:27 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:27 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:27 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:27 --> Controller Class Initialized
INFO - 2024-02-11 11:52:27 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:27 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:27 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:27 --> Total execution time: 0.0329
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0364
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0355
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0337
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0442
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0547
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0449
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0430
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0327
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0285
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0269
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0407
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0339
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0263
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0335
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0292
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0255
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0300
ERROR - 2024-02-11 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:52:28 --> Config Class Initialized
INFO - 2024-02-11 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-11 11:52:28 --> URI Class Initialized
INFO - 2024-02-11 11:52:28 --> Router Class Initialized
INFO - 2024-02-11 11:52:28 --> Output Class Initialized
INFO - 2024-02-11 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:52:28 --> Input Class Initialized
INFO - 2024-02-11 11:52:28 --> Language Class Initialized
INFO - 2024-02-11 11:52:28 --> Loader Class Initialized
INFO - 2024-02-11 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-11 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-11 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:52:28 --> Controller Class Initialized
INFO - 2024-02-11 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-11 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-11 11:52:28 --> Total execution time: 0.0232
ERROR - 2024-02-11 11:53:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:53:07 --> Config Class Initialized
INFO - 2024-02-11 11:53:07 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:53:07 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:53:07 --> Utf8 Class Initialized
INFO - 2024-02-11 11:53:07 --> URI Class Initialized
INFO - 2024-02-11 11:53:07 --> Router Class Initialized
INFO - 2024-02-11 11:53:07 --> Output Class Initialized
INFO - 2024-02-11 11:53:07 --> Security Class Initialized
DEBUG - 2024-02-11 11:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:53:07 --> Input Class Initialized
INFO - 2024-02-11 11:53:07 --> Language Class Initialized
INFO - 2024-02-11 11:53:07 --> Loader Class Initialized
INFO - 2024-02-11 11:53:07 --> Helper loaded: url_helper
INFO - 2024-02-11 11:53:07 --> Helper loaded: file_helper
INFO - 2024-02-11 11:53:07 --> Helper loaded: form_helper
INFO - 2024-02-11 11:53:07 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:53:07 --> Controller Class Initialized
INFO - 2024-02-11 11:53:07 --> Form Validation Class Initialized
INFO - 2024-02-11 11:53:07 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:53:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:53:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:53:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:53:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:53:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:53:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:53:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:53:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:53:07 --> Final output sent to browser
DEBUG - 2024-02-11 11:53:07 --> Total execution time: 0.0257
ERROR - 2024-02-11 11:53:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:53:12 --> Config Class Initialized
INFO - 2024-02-11 11:53:12 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:53:12 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:53:12 --> Utf8 Class Initialized
INFO - 2024-02-11 11:53:12 --> URI Class Initialized
INFO - 2024-02-11 11:53:12 --> Router Class Initialized
INFO - 2024-02-11 11:53:12 --> Output Class Initialized
INFO - 2024-02-11 11:53:12 --> Security Class Initialized
DEBUG - 2024-02-11 11:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:53:12 --> Input Class Initialized
INFO - 2024-02-11 11:53:12 --> Language Class Initialized
INFO - 2024-02-11 11:53:12 --> Loader Class Initialized
INFO - 2024-02-11 11:53:12 --> Helper loaded: url_helper
INFO - 2024-02-11 11:53:12 --> Helper loaded: file_helper
INFO - 2024-02-11 11:53:12 --> Helper loaded: form_helper
INFO - 2024-02-11 11:53:12 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:53:12 --> Controller Class Initialized
INFO - 2024-02-11 11:53:12 --> Form Validation Class Initialized
INFO - 2024-02-11 11:53:12 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:53:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:53:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:53:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:53:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:53:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:53:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:53:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:53:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:53:12 --> Final output sent to browser
DEBUG - 2024-02-11 11:53:12 --> Total execution time: 0.0287
ERROR - 2024-02-11 11:53:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:53:39 --> Config Class Initialized
INFO - 2024-02-11 11:53:39 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:53:39 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:53:39 --> Utf8 Class Initialized
INFO - 2024-02-11 11:53:39 --> URI Class Initialized
INFO - 2024-02-11 11:53:39 --> Router Class Initialized
INFO - 2024-02-11 11:53:39 --> Output Class Initialized
INFO - 2024-02-11 11:53:39 --> Security Class Initialized
DEBUG - 2024-02-11 11:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:53:39 --> Input Class Initialized
INFO - 2024-02-11 11:53:39 --> Language Class Initialized
INFO - 2024-02-11 11:53:39 --> Loader Class Initialized
INFO - 2024-02-11 11:53:39 --> Helper loaded: url_helper
INFO - 2024-02-11 11:53:39 --> Helper loaded: file_helper
INFO - 2024-02-11 11:53:39 --> Helper loaded: form_helper
INFO - 2024-02-11 11:53:39 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:53:39 --> Controller Class Initialized
INFO - 2024-02-11 11:53:39 --> Form Validation Class Initialized
INFO - 2024-02-11 11:53:39 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:53:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:53:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:53:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:53:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:53:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:53:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:53:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:53:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:53:39 --> Final output sent to browser
DEBUG - 2024-02-11 11:53:39 --> Total execution time: 0.0279
ERROR - 2024-02-11 11:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:53:46 --> Config Class Initialized
INFO - 2024-02-11 11:53:46 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:53:46 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:53:46 --> Utf8 Class Initialized
INFO - 2024-02-11 11:53:46 --> URI Class Initialized
INFO - 2024-02-11 11:53:46 --> Router Class Initialized
INFO - 2024-02-11 11:53:46 --> Output Class Initialized
INFO - 2024-02-11 11:53:46 --> Security Class Initialized
DEBUG - 2024-02-11 11:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:53:46 --> Input Class Initialized
INFO - 2024-02-11 11:53:46 --> Language Class Initialized
INFO - 2024-02-11 11:53:46 --> Loader Class Initialized
INFO - 2024-02-11 11:53:46 --> Helper loaded: url_helper
INFO - 2024-02-11 11:53:46 --> Helper loaded: file_helper
INFO - 2024-02-11 11:53:46 --> Helper loaded: form_helper
INFO - 2024-02-11 11:53:46 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:53:46 --> Controller Class Initialized
INFO - 2024-02-11 11:53:46 --> Form Validation Class Initialized
INFO - 2024-02-11 11:53:46 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:53:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:53:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:53:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:53:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:53:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:53:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:53:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:53:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:53:46 --> Final output sent to browser
DEBUG - 2024-02-11 11:53:46 --> Total execution time: 0.0305
ERROR - 2024-02-11 11:54:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:54:30 --> Config Class Initialized
INFO - 2024-02-11 11:54:30 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:54:30 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:54:30 --> Utf8 Class Initialized
INFO - 2024-02-11 11:54:30 --> URI Class Initialized
INFO - 2024-02-11 11:54:30 --> Router Class Initialized
INFO - 2024-02-11 11:54:30 --> Output Class Initialized
INFO - 2024-02-11 11:54:30 --> Security Class Initialized
DEBUG - 2024-02-11 11:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:54:30 --> Input Class Initialized
INFO - 2024-02-11 11:54:30 --> Language Class Initialized
INFO - 2024-02-11 11:54:30 --> Loader Class Initialized
INFO - 2024-02-11 11:54:30 --> Helper loaded: url_helper
INFO - 2024-02-11 11:54:30 --> Helper loaded: file_helper
INFO - 2024-02-11 11:54:30 --> Helper loaded: form_helper
INFO - 2024-02-11 11:54:30 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:54:30 --> Controller Class Initialized
INFO - 2024-02-11 11:54:30 --> Form Validation Class Initialized
INFO - 2024-02-11 11:54:30 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:54:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:54:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:54:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:54:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:54:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:54:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:54:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:54:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:54:30 --> Final output sent to browser
DEBUG - 2024-02-11 11:54:30 --> Total execution time: 0.0317
ERROR - 2024-02-11 11:54:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:54:31 --> Config Class Initialized
INFO - 2024-02-11 11:54:31 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:54:31 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:54:31 --> Utf8 Class Initialized
INFO - 2024-02-11 11:54:31 --> URI Class Initialized
INFO - 2024-02-11 11:54:31 --> Router Class Initialized
INFO - 2024-02-11 11:54:31 --> Output Class Initialized
INFO - 2024-02-11 11:54:31 --> Security Class Initialized
DEBUG - 2024-02-11 11:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:54:31 --> Input Class Initialized
INFO - 2024-02-11 11:54:31 --> Language Class Initialized
INFO - 2024-02-11 11:54:31 --> Loader Class Initialized
INFO - 2024-02-11 11:54:31 --> Helper loaded: url_helper
INFO - 2024-02-11 11:54:31 --> Helper loaded: file_helper
INFO - 2024-02-11 11:54:31 --> Helper loaded: form_helper
INFO - 2024-02-11 11:54:31 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:54:31 --> Controller Class Initialized
ERROR - 2024-02-11 11:54:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:54:31 --> Form Validation Class Initialized
INFO - 2024-02-11 11:54:31 --> Config Class Initialized
INFO - 2024-02-11 11:54:31 --> Hooks Class Initialized
INFO - 2024-02-11 11:54:31 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:54:31 --> Model "UserMasterModel" initialized
DEBUG - 2024-02-11 11:54:31 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:54:31 --> Utf8 Class Initialized
INFO - 2024-02-11 11:54:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:54:31 --> URI Class Initialized
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:54:31 --> Router Class Initialized
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:54:31 --> Final output sent to browser
DEBUG - 2024-02-11 11:54:31 --> Total execution time: 0.0465
INFO - 2024-02-11 11:54:31 --> Output Class Initialized
INFO - 2024-02-11 11:54:31 --> Security Class Initialized
DEBUG - 2024-02-11 11:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:54:31 --> Input Class Initialized
INFO - 2024-02-11 11:54:31 --> Language Class Initialized
INFO - 2024-02-11 11:54:31 --> Loader Class Initialized
INFO - 2024-02-11 11:54:31 --> Helper loaded: url_helper
INFO - 2024-02-11 11:54:31 --> Helper loaded: file_helper
INFO - 2024-02-11 11:54:31 --> Helper loaded: form_helper
INFO - 2024-02-11 11:54:31 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:54:31 --> Controller Class Initialized
ERROR - 2024-02-11 11:54:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:54:31 --> Form Validation Class Initialized
INFO - 2024-02-11 11:54:31 --> Config Class Initialized
INFO - 2024-02-11 11:54:31 --> Hooks Class Initialized
INFO - 2024-02-11 11:54:31 --> Model "MasterModel" initialized
DEBUG - 2024-02-11 11:54:31 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:54:31 --> Utf8 Class Initialized
INFO - 2024-02-11 11:54:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:54:31 --> URI Class Initialized
INFO - 2024-02-11 11:54:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:54:31 --> Router Class Initialized
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:54:31 --> Output Class Initialized
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:54:31 --> Security Class Initialized
INFO - 2024-02-11 11:54:31 --> Final output sent to browser
DEBUG - 2024-02-11 11:54:31 --> Total execution time: 0.0544
DEBUG - 2024-02-11 11:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:54:31 --> Input Class Initialized
INFO - 2024-02-11 11:54:31 --> Language Class Initialized
INFO - 2024-02-11 11:54:31 --> Loader Class Initialized
INFO - 2024-02-11 11:54:31 --> Helper loaded: url_helper
INFO - 2024-02-11 11:54:31 --> Helper loaded: file_helper
INFO - 2024-02-11 11:54:31 --> Helper loaded: form_helper
INFO - 2024-02-11 11:54:31 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:54:31 --> Controller Class Initialized
INFO - 2024-02-11 11:54:31 --> Form Validation Class Initialized
INFO - 2024-02-11 11:54:31 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:54:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:54:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:54:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:54:31 --> Final output sent to browser
DEBUG - 2024-02-11 11:54:31 --> Total execution time: 0.0284
ERROR - 2024-02-11 11:56:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:56:39 --> Config Class Initialized
INFO - 2024-02-11 11:56:39 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:56:39 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:56:39 --> Utf8 Class Initialized
INFO - 2024-02-11 11:56:39 --> URI Class Initialized
INFO - 2024-02-11 11:56:39 --> Router Class Initialized
INFO - 2024-02-11 11:56:39 --> Output Class Initialized
INFO - 2024-02-11 11:56:39 --> Security Class Initialized
DEBUG - 2024-02-11 11:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:56:39 --> Input Class Initialized
INFO - 2024-02-11 11:56:39 --> Language Class Initialized
INFO - 2024-02-11 11:56:39 --> Loader Class Initialized
INFO - 2024-02-11 11:56:39 --> Helper loaded: url_helper
INFO - 2024-02-11 11:56:39 --> Helper loaded: file_helper
INFO - 2024-02-11 11:56:39 --> Helper loaded: form_helper
INFO - 2024-02-11 11:56:39 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:56:39 --> Controller Class Initialized
INFO - 2024-02-11 11:56:39 --> Form Validation Class Initialized
INFO - 2024-02-11 11:56:39 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:56:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:56:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:56:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:56:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:56:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:56:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:56:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:56:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:56:39 --> Final output sent to browser
DEBUG - 2024-02-11 11:56:39 --> Total execution time: 0.0278
ERROR - 2024-02-11 11:56:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:56:43 --> Config Class Initialized
INFO - 2024-02-11 11:56:43 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:56:43 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:56:43 --> Utf8 Class Initialized
INFO - 2024-02-11 11:56:43 --> URI Class Initialized
INFO - 2024-02-11 11:56:43 --> Router Class Initialized
INFO - 2024-02-11 11:56:43 --> Output Class Initialized
INFO - 2024-02-11 11:56:43 --> Security Class Initialized
DEBUG - 2024-02-11 11:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:56:43 --> Input Class Initialized
INFO - 2024-02-11 11:56:43 --> Language Class Initialized
INFO - 2024-02-11 11:56:43 --> Loader Class Initialized
INFO - 2024-02-11 11:56:43 --> Helper loaded: url_helper
INFO - 2024-02-11 11:56:43 --> Helper loaded: file_helper
INFO - 2024-02-11 11:56:43 --> Helper loaded: form_helper
INFO - 2024-02-11 11:56:43 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:56:43 --> Controller Class Initialized
INFO - 2024-02-11 11:56:43 --> Form Validation Class Initialized
INFO - 2024-02-11 11:56:43 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:56:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:56:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:56:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:56:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:56:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:56:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:56:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:56:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:56:43 --> Final output sent to browser
DEBUG - 2024-02-11 11:56:43 --> Total execution time: 0.0286
ERROR - 2024-02-11 11:57:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:57:01 --> Config Class Initialized
INFO - 2024-02-11 11:57:01 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:57:01 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:57:01 --> Utf8 Class Initialized
INFO - 2024-02-11 11:57:01 --> URI Class Initialized
INFO - 2024-02-11 11:57:01 --> Router Class Initialized
INFO - 2024-02-11 11:57:01 --> Output Class Initialized
INFO - 2024-02-11 11:57:01 --> Security Class Initialized
DEBUG - 2024-02-11 11:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:57:01 --> Input Class Initialized
INFO - 2024-02-11 11:57:01 --> Language Class Initialized
INFO - 2024-02-11 11:57:01 --> Loader Class Initialized
INFO - 2024-02-11 11:57:01 --> Helper loaded: url_helper
INFO - 2024-02-11 11:57:01 --> Helper loaded: file_helper
INFO - 2024-02-11 11:57:01 --> Helper loaded: form_helper
INFO - 2024-02-11 11:57:01 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:57:01 --> Controller Class Initialized
INFO - 2024-02-11 11:57:01 --> Form Validation Class Initialized
INFO - 2024-02-11 11:57:01 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:57:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:57:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:57:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:57:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:57:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:57:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:57:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:57:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:57:01 --> Final output sent to browser
DEBUG - 2024-02-11 11:57:01 --> Total execution time: 0.0251
ERROR - 2024-02-11 11:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:57:04 --> Config Class Initialized
INFO - 2024-02-11 11:57:04 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:57:04 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:57:04 --> Utf8 Class Initialized
INFO - 2024-02-11 11:57:04 --> URI Class Initialized
INFO - 2024-02-11 11:57:04 --> Router Class Initialized
INFO - 2024-02-11 11:57:04 --> Output Class Initialized
INFO - 2024-02-11 11:57:04 --> Security Class Initialized
DEBUG - 2024-02-11 11:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:57:04 --> Input Class Initialized
INFO - 2024-02-11 11:57:04 --> Language Class Initialized
INFO - 2024-02-11 11:57:04 --> Loader Class Initialized
INFO - 2024-02-11 11:57:04 --> Helper loaded: url_helper
INFO - 2024-02-11 11:57:04 --> Helper loaded: file_helper
INFO - 2024-02-11 11:57:04 --> Helper loaded: form_helper
INFO - 2024-02-11 11:57:04 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:57:04 --> Controller Class Initialized
INFO - 2024-02-11 11:57:04 --> Form Validation Class Initialized
INFO - 2024-02-11 11:57:04 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:57:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:57:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:57:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:57:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:57:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:57:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:57:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:57:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:57:04 --> Final output sent to browser
DEBUG - 2024-02-11 11:57:04 --> Total execution time: 0.0247
ERROR - 2024-02-11 11:57:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:57:24 --> Config Class Initialized
INFO - 2024-02-11 11:57:24 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:57:24 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:57:24 --> Utf8 Class Initialized
INFO - 2024-02-11 11:57:24 --> URI Class Initialized
INFO - 2024-02-11 11:57:24 --> Router Class Initialized
INFO - 2024-02-11 11:57:24 --> Output Class Initialized
INFO - 2024-02-11 11:57:24 --> Security Class Initialized
DEBUG - 2024-02-11 11:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:57:24 --> Input Class Initialized
INFO - 2024-02-11 11:57:24 --> Language Class Initialized
INFO - 2024-02-11 11:57:24 --> Loader Class Initialized
INFO - 2024-02-11 11:57:24 --> Helper loaded: url_helper
INFO - 2024-02-11 11:57:24 --> Helper loaded: file_helper
INFO - 2024-02-11 11:57:24 --> Helper loaded: form_helper
INFO - 2024-02-11 11:57:24 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:57:24 --> Controller Class Initialized
INFO - 2024-02-11 11:57:24 --> Form Validation Class Initialized
INFO - 2024-02-11 11:57:24 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:57:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:57:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:57:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:57:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:57:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:57:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:57:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:57:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:57:24 --> Final output sent to browser
DEBUG - 2024-02-11 11:57:24 --> Total execution time: 0.0263
ERROR - 2024-02-11 11:57:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:57:30 --> Config Class Initialized
INFO - 2024-02-11 11:57:30 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:57:30 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:57:30 --> Utf8 Class Initialized
INFO - 2024-02-11 11:57:30 --> URI Class Initialized
INFO - 2024-02-11 11:57:30 --> Router Class Initialized
INFO - 2024-02-11 11:57:30 --> Output Class Initialized
INFO - 2024-02-11 11:57:30 --> Security Class Initialized
DEBUG - 2024-02-11 11:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:57:30 --> Input Class Initialized
INFO - 2024-02-11 11:57:30 --> Language Class Initialized
INFO - 2024-02-11 11:57:30 --> Loader Class Initialized
INFO - 2024-02-11 11:57:30 --> Helper loaded: url_helper
INFO - 2024-02-11 11:57:30 --> Helper loaded: file_helper
INFO - 2024-02-11 11:57:30 --> Helper loaded: form_helper
INFO - 2024-02-11 11:57:30 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:57:30 --> Controller Class Initialized
INFO - 2024-02-11 11:57:30 --> Form Validation Class Initialized
INFO - 2024-02-11 11:57:30 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:57:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:57:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:57:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:57:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:57:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:57:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:57:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:57:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:57:30 --> Final output sent to browser
DEBUG - 2024-02-11 11:57:30 --> Total execution time: 0.0264
ERROR - 2024-02-11 11:57:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:57:38 --> Config Class Initialized
INFO - 2024-02-11 11:57:38 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:57:38 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:57:38 --> Utf8 Class Initialized
INFO - 2024-02-11 11:57:38 --> URI Class Initialized
INFO - 2024-02-11 11:57:38 --> Router Class Initialized
INFO - 2024-02-11 11:57:38 --> Output Class Initialized
INFO - 2024-02-11 11:57:38 --> Security Class Initialized
DEBUG - 2024-02-11 11:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:57:38 --> Input Class Initialized
INFO - 2024-02-11 11:57:38 --> Language Class Initialized
INFO - 2024-02-11 11:57:38 --> Loader Class Initialized
INFO - 2024-02-11 11:57:38 --> Helper loaded: url_helper
INFO - 2024-02-11 11:57:38 --> Helper loaded: file_helper
INFO - 2024-02-11 11:57:38 --> Helper loaded: form_helper
INFO - 2024-02-11 11:57:38 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:57:38 --> Controller Class Initialized
INFO - 2024-02-11 11:57:38 --> Form Validation Class Initialized
INFO - 2024-02-11 11:57:38 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:57:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:57:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:57:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:57:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:57:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:57:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:57:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:57:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:57:38 --> Final output sent to browser
DEBUG - 2024-02-11 11:57:38 --> Total execution time: 0.0292
ERROR - 2024-02-11 11:57:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:57:57 --> Config Class Initialized
INFO - 2024-02-11 11:57:57 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:57:57 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:57:57 --> Utf8 Class Initialized
INFO - 2024-02-11 11:57:57 --> URI Class Initialized
INFO - 2024-02-11 11:57:57 --> Router Class Initialized
INFO - 2024-02-11 11:57:57 --> Output Class Initialized
INFO - 2024-02-11 11:57:57 --> Security Class Initialized
DEBUG - 2024-02-11 11:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:57:57 --> Input Class Initialized
INFO - 2024-02-11 11:57:57 --> Language Class Initialized
INFO - 2024-02-11 11:57:57 --> Loader Class Initialized
INFO - 2024-02-11 11:57:57 --> Helper loaded: url_helper
INFO - 2024-02-11 11:57:57 --> Helper loaded: file_helper
INFO - 2024-02-11 11:57:57 --> Helper loaded: form_helper
INFO - 2024-02-11 11:57:57 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:57:57 --> Controller Class Initialized
INFO - 2024-02-11 11:57:57 --> Form Validation Class Initialized
INFO - 2024-02-11 11:57:57 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:57:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:57:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:57:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:57:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:57:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:57:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:57:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:57:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:57:57 --> Final output sent to browser
DEBUG - 2024-02-11 11:57:57 --> Total execution time: 0.0315
ERROR - 2024-02-11 11:57:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:57:57 --> Config Class Initialized
INFO - 2024-02-11 11:57:57 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:57:57 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:57:57 --> Utf8 Class Initialized
INFO - 2024-02-11 11:57:57 --> URI Class Initialized
INFO - 2024-02-11 11:57:57 --> Router Class Initialized
INFO - 2024-02-11 11:57:57 --> Output Class Initialized
INFO - 2024-02-11 11:57:57 --> Security Class Initialized
DEBUG - 2024-02-11 11:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:57:57 --> Input Class Initialized
INFO - 2024-02-11 11:57:57 --> Language Class Initialized
INFO - 2024-02-11 11:57:57 --> Loader Class Initialized
INFO - 2024-02-11 11:57:57 --> Helper loaded: url_helper
INFO - 2024-02-11 11:57:57 --> Helper loaded: file_helper
INFO - 2024-02-11 11:57:57 --> Helper loaded: form_helper
INFO - 2024-02-11 11:57:57 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:57:57 --> Controller Class Initialized
INFO - 2024-02-11 11:57:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-02-11 11:57:57 --> Final output sent to browser
DEBUG - 2024-02-11 11:57:57 --> Total execution time: 0.0241
ERROR - 2024-02-11 11:58:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:58:00 --> Config Class Initialized
INFO - 2024-02-11 11:58:00 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:58:00 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:58:00 --> Utf8 Class Initialized
INFO - 2024-02-11 11:58:01 --> URI Class Initialized
INFO - 2024-02-11 11:58:01 --> Router Class Initialized
INFO - 2024-02-11 11:58:01 --> Output Class Initialized
INFO - 2024-02-11 11:58:01 --> Security Class Initialized
DEBUG - 2024-02-11 11:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:58:01 --> Input Class Initialized
INFO - 2024-02-11 11:58:01 --> Language Class Initialized
INFO - 2024-02-11 11:58:01 --> Loader Class Initialized
INFO - 2024-02-11 11:58:01 --> Helper loaded: url_helper
INFO - 2024-02-11 11:58:01 --> Helper loaded: file_helper
INFO - 2024-02-11 11:58:01 --> Helper loaded: form_helper
INFO - 2024-02-11 11:58:01 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:58:01 --> Controller Class Initialized
INFO - 2024-02-11 11:58:01 --> Model "LoginModel" initialized
INFO - 2024-02-11 11:58:01 --> Form Validation Class Initialized
INFO - 2024-02-11 11:58:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-11 11:58:01 --> Final output sent to browser
DEBUG - 2024-02-11 11:58:01 --> Total execution time: 0.0318
ERROR - 2024-02-11 11:58:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:58:16 --> Config Class Initialized
INFO - 2024-02-11 11:58:16 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:58:16 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:58:16 --> Utf8 Class Initialized
INFO - 2024-02-11 11:58:16 --> URI Class Initialized
INFO - 2024-02-11 11:58:16 --> Router Class Initialized
INFO - 2024-02-11 11:58:16 --> Output Class Initialized
INFO - 2024-02-11 11:58:16 --> Security Class Initialized
DEBUG - 2024-02-11 11:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:58:16 --> Input Class Initialized
INFO - 2024-02-11 11:58:16 --> Language Class Initialized
INFO - 2024-02-11 11:58:16 --> Loader Class Initialized
INFO - 2024-02-11 11:58:16 --> Helper loaded: url_helper
INFO - 2024-02-11 11:58:16 --> Helper loaded: file_helper
INFO - 2024-02-11 11:58:16 --> Helper loaded: form_helper
INFO - 2024-02-11 11:58:16 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:58:16 --> Controller Class Initialized
INFO - 2024-02-11 11:58:16 --> Model "LoginModel" initialized
INFO - 2024-02-11 11:58:16 --> Form Validation Class Initialized
INFO - 2024-02-11 11:58:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-11 11:58:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:58:16 --> Config Class Initialized
INFO - 2024-02-11 11:58:16 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:58:16 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:58:16 --> Utf8 Class Initialized
INFO - 2024-02-11 11:58:16 --> URI Class Initialized
INFO - 2024-02-11 11:58:16 --> Router Class Initialized
INFO - 2024-02-11 11:58:16 --> Output Class Initialized
INFO - 2024-02-11 11:58:16 --> Security Class Initialized
DEBUG - 2024-02-11 11:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:58:16 --> Input Class Initialized
INFO - 2024-02-11 11:58:16 --> Language Class Initialized
INFO - 2024-02-11 11:58:16 --> Loader Class Initialized
INFO - 2024-02-11 11:58:16 --> Helper loaded: url_helper
INFO - 2024-02-11 11:58:16 --> Helper loaded: file_helper
INFO - 2024-02-11 11:58:16 --> Helper loaded: form_helper
INFO - 2024-02-11 11:58:16 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:58:16 --> Controller Class Initialized
INFO - 2024-02-11 11:58:16 --> Form Validation Class Initialized
INFO - 2024-02-11 11:58:16 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:58:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:58:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:58:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:58:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-11 11:58:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:58:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:58:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:58:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-11 11:58:16 --> Final output sent to browser
DEBUG - 2024-02-11 11:58:16 --> Total execution time: 0.0267
ERROR - 2024-02-11 11:58:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:58:41 --> Config Class Initialized
INFO - 2024-02-11 11:58:41 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:58:41 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:58:41 --> Utf8 Class Initialized
INFO - 2024-02-11 11:58:41 --> URI Class Initialized
INFO - 2024-02-11 11:58:41 --> Router Class Initialized
INFO - 2024-02-11 11:58:41 --> Output Class Initialized
INFO - 2024-02-11 11:58:41 --> Security Class Initialized
DEBUG - 2024-02-11 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:58:41 --> Input Class Initialized
INFO - 2024-02-11 11:58:41 --> Language Class Initialized
INFO - 2024-02-11 11:58:41 --> Loader Class Initialized
INFO - 2024-02-11 11:58:41 --> Helper loaded: url_helper
INFO - 2024-02-11 11:58:41 --> Helper loaded: file_helper
INFO - 2024-02-11 11:58:41 --> Helper loaded: form_helper
INFO - 2024-02-11 11:58:41 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:58:41 --> Controller Class Initialized
INFO - 2024-02-11 11:58:41 --> Form Validation Class Initialized
INFO - 2024-02-11 11:58:41 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:58:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:58:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:58:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 11:58:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 11:58:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 11:58:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 11:58:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 11:58:41 --> Final output sent to browser
DEBUG - 2024-02-11 11:58:41 --> Total execution time: 0.0248
ERROR - 2024-02-11 11:58:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:58:41 --> Config Class Initialized
INFO - 2024-02-11 11:58:41 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:58:41 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:58:41 --> Utf8 Class Initialized
INFO - 2024-02-11 11:58:41 --> URI Class Initialized
INFO - 2024-02-11 11:58:41 --> Router Class Initialized
INFO - 2024-02-11 11:58:41 --> Output Class Initialized
INFO - 2024-02-11 11:58:41 --> Security Class Initialized
DEBUG - 2024-02-11 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:58:41 --> Input Class Initialized
INFO - 2024-02-11 11:58:41 --> Language Class Initialized
INFO - 2024-02-11 11:58:41 --> Loader Class Initialized
INFO - 2024-02-11 11:58:41 --> Helper loaded: url_helper
INFO - 2024-02-11 11:58:41 --> Helper loaded: file_helper
INFO - 2024-02-11 11:58:41 --> Helper loaded: form_helper
INFO - 2024-02-11 11:58:41 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:58:41 --> Controller Class Initialized
INFO - 2024-02-11 11:58:41 --> Form Validation Class Initialized
INFO - 2024-02-11 11:58:41 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:58:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:58:41 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:58:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:58:46 --> Config Class Initialized
INFO - 2024-02-11 11:58:46 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:58:46 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:58:46 --> Utf8 Class Initialized
INFO - 2024-02-11 11:58:46 --> URI Class Initialized
INFO - 2024-02-11 11:58:46 --> Router Class Initialized
INFO - 2024-02-11 11:58:46 --> Output Class Initialized
INFO - 2024-02-11 11:58:46 --> Security Class Initialized
DEBUG - 2024-02-11 11:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:58:46 --> Input Class Initialized
INFO - 2024-02-11 11:58:46 --> Language Class Initialized
INFO - 2024-02-11 11:58:46 --> Loader Class Initialized
INFO - 2024-02-11 11:58:46 --> Helper loaded: url_helper
INFO - 2024-02-11 11:58:46 --> Helper loaded: file_helper
INFO - 2024-02-11 11:58:46 --> Helper loaded: form_helper
INFO - 2024-02-11 11:58:46 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:58:46 --> Controller Class Initialized
INFO - 2024-02-11 11:58:46 --> Form Validation Class Initialized
INFO - 2024-02-11 11:58:46 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:58:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:58:46 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:58:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:58:47 --> Config Class Initialized
INFO - 2024-02-11 11:58:47 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:58:47 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:58:47 --> Utf8 Class Initialized
INFO - 2024-02-11 11:58:47 --> URI Class Initialized
INFO - 2024-02-11 11:58:47 --> Router Class Initialized
INFO - 2024-02-11 11:58:47 --> Output Class Initialized
INFO - 2024-02-11 11:58:47 --> Security Class Initialized
DEBUG - 2024-02-11 11:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:58:47 --> Input Class Initialized
INFO - 2024-02-11 11:58:47 --> Language Class Initialized
INFO - 2024-02-11 11:58:47 --> Loader Class Initialized
INFO - 2024-02-11 11:58:47 --> Helper loaded: url_helper
INFO - 2024-02-11 11:58:47 --> Helper loaded: file_helper
INFO - 2024-02-11 11:58:47 --> Helper loaded: form_helper
INFO - 2024-02-11 11:58:47 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:58:47 --> Controller Class Initialized
INFO - 2024-02-11 11:58:47 --> Form Validation Class Initialized
INFO - 2024-02-11 11:58:47 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:58:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:58:47 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:58:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:58:50 --> Config Class Initialized
INFO - 2024-02-11 11:58:50 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:58:50 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:58:50 --> Utf8 Class Initialized
INFO - 2024-02-11 11:58:50 --> URI Class Initialized
INFO - 2024-02-11 11:58:50 --> Router Class Initialized
INFO - 2024-02-11 11:58:50 --> Output Class Initialized
INFO - 2024-02-11 11:58:50 --> Security Class Initialized
DEBUG - 2024-02-11 11:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:58:50 --> Input Class Initialized
INFO - 2024-02-11 11:58:50 --> Language Class Initialized
INFO - 2024-02-11 11:58:50 --> Loader Class Initialized
INFO - 2024-02-11 11:58:50 --> Helper loaded: url_helper
INFO - 2024-02-11 11:58:50 --> Helper loaded: file_helper
INFO - 2024-02-11 11:58:50 --> Helper loaded: form_helper
INFO - 2024-02-11 11:58:50 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:58:50 --> Controller Class Initialized
INFO - 2024-02-11 11:58:50 --> Form Validation Class Initialized
INFO - 2024-02-11 11:58:50 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:58:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:58:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 11:58:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-11 11:58:51 --> Final output sent to browser
DEBUG - 2024-02-11 11:58:51 --> Total execution time: 0.0269
ERROR - 2024-02-11 11:58:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:58:58 --> Config Class Initialized
INFO - 2024-02-11 11:58:58 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:58:58 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:58:58 --> Utf8 Class Initialized
INFO - 2024-02-11 11:58:58 --> URI Class Initialized
INFO - 2024-02-11 11:58:58 --> Router Class Initialized
INFO - 2024-02-11 11:58:58 --> Output Class Initialized
INFO - 2024-02-11 11:58:58 --> Security Class Initialized
DEBUG - 2024-02-11 11:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:58:58 --> Input Class Initialized
INFO - 2024-02-11 11:58:58 --> Language Class Initialized
INFO - 2024-02-11 11:58:58 --> Loader Class Initialized
INFO - 2024-02-11 11:58:58 --> Helper loaded: url_helper
INFO - 2024-02-11 11:58:58 --> Helper loaded: file_helper
INFO - 2024-02-11 11:58:58 --> Helper loaded: form_helper
INFO - 2024-02-11 11:58:58 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:58:58 --> Controller Class Initialized
INFO - 2024-02-11 11:58:58 --> Form Validation Class Initialized
INFO - 2024-02-11 11:58:58 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:58:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:58:58 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:58:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:58:58 --> Config Class Initialized
INFO - 2024-02-11 11:58:58 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:58:58 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:58:58 --> Utf8 Class Initialized
INFO - 2024-02-11 11:58:58 --> URI Class Initialized
INFO - 2024-02-11 11:58:58 --> Router Class Initialized
INFO - 2024-02-11 11:58:58 --> Output Class Initialized
INFO - 2024-02-11 11:58:58 --> Security Class Initialized
DEBUG - 2024-02-11 11:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:58:58 --> Input Class Initialized
INFO - 2024-02-11 11:58:58 --> Language Class Initialized
INFO - 2024-02-11 11:58:58 --> Loader Class Initialized
INFO - 2024-02-11 11:58:58 --> Helper loaded: url_helper
INFO - 2024-02-11 11:58:58 --> Helper loaded: file_helper
INFO - 2024-02-11 11:58:58 --> Helper loaded: form_helper
INFO - 2024-02-11 11:58:58 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:58:58 --> Controller Class Initialized
INFO - 2024-02-11 11:58:58 --> Form Validation Class Initialized
INFO - 2024-02-11 11:58:58 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:58:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:58:58 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:58:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:58:58 --> Config Class Initialized
INFO - 2024-02-11 11:58:58 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:58:58 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:58:58 --> Utf8 Class Initialized
INFO - 2024-02-11 11:58:58 --> URI Class Initialized
INFO - 2024-02-11 11:58:58 --> Router Class Initialized
INFO - 2024-02-11 11:58:58 --> Output Class Initialized
INFO - 2024-02-11 11:58:58 --> Security Class Initialized
DEBUG - 2024-02-11 11:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:58:58 --> Input Class Initialized
INFO - 2024-02-11 11:58:58 --> Language Class Initialized
INFO - 2024-02-11 11:58:58 --> Loader Class Initialized
INFO - 2024-02-11 11:58:58 --> Helper loaded: url_helper
INFO - 2024-02-11 11:58:58 --> Helper loaded: file_helper
INFO - 2024-02-11 11:58:58 --> Helper loaded: form_helper
INFO - 2024-02-11 11:58:58 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:58:58 --> Controller Class Initialized
INFO - 2024-02-11 11:58:58 --> Form Validation Class Initialized
INFO - 2024-02-11 11:58:58 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:58:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:58:58 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:58:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:58:58 --> Config Class Initialized
INFO - 2024-02-11 11:58:58 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:58:58 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:58:58 --> Utf8 Class Initialized
INFO - 2024-02-11 11:58:58 --> URI Class Initialized
INFO - 2024-02-11 11:58:58 --> Router Class Initialized
INFO - 2024-02-11 11:58:58 --> Output Class Initialized
INFO - 2024-02-11 11:58:58 --> Security Class Initialized
DEBUG - 2024-02-11 11:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:58:58 --> Input Class Initialized
INFO - 2024-02-11 11:58:58 --> Language Class Initialized
INFO - 2024-02-11 11:58:58 --> Loader Class Initialized
INFO - 2024-02-11 11:58:58 --> Helper loaded: url_helper
INFO - 2024-02-11 11:58:58 --> Helper loaded: file_helper
INFO - 2024-02-11 11:58:58 --> Helper loaded: form_helper
INFO - 2024-02-11 11:58:58 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:58:58 --> Controller Class Initialized
INFO - 2024-02-11 11:58:58 --> Form Validation Class Initialized
INFO - 2024-02-11 11:58:58 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:58:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:58:58 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:59:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:59:01 --> Config Class Initialized
INFO - 2024-02-11 11:59:01 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:59:01 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:59:01 --> Utf8 Class Initialized
INFO - 2024-02-11 11:59:01 --> URI Class Initialized
INFO - 2024-02-11 11:59:01 --> Router Class Initialized
INFO - 2024-02-11 11:59:01 --> Output Class Initialized
INFO - 2024-02-11 11:59:01 --> Security Class Initialized
DEBUG - 2024-02-11 11:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:59:01 --> Input Class Initialized
INFO - 2024-02-11 11:59:01 --> Language Class Initialized
INFO - 2024-02-11 11:59:01 --> Loader Class Initialized
INFO - 2024-02-11 11:59:01 --> Helper loaded: url_helper
INFO - 2024-02-11 11:59:01 --> Helper loaded: file_helper
INFO - 2024-02-11 11:59:01 --> Helper loaded: form_helper
INFO - 2024-02-11 11:59:01 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:59:01 --> Controller Class Initialized
INFO - 2024-02-11 11:59:01 --> Form Validation Class Initialized
INFO - 2024-02-11 11:59:01 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:59:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:59:01 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:59:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:59:01 --> Config Class Initialized
INFO - 2024-02-11 11:59:01 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:59:01 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:59:01 --> Utf8 Class Initialized
INFO - 2024-02-11 11:59:01 --> URI Class Initialized
INFO - 2024-02-11 11:59:01 --> Router Class Initialized
INFO - 2024-02-11 11:59:01 --> Output Class Initialized
INFO - 2024-02-11 11:59:01 --> Security Class Initialized
DEBUG - 2024-02-11 11:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:59:01 --> Input Class Initialized
INFO - 2024-02-11 11:59:01 --> Language Class Initialized
INFO - 2024-02-11 11:59:01 --> Loader Class Initialized
INFO - 2024-02-11 11:59:01 --> Helper loaded: url_helper
INFO - 2024-02-11 11:59:01 --> Helper loaded: file_helper
INFO - 2024-02-11 11:59:01 --> Helper loaded: form_helper
INFO - 2024-02-11 11:59:01 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:59:01 --> Controller Class Initialized
INFO - 2024-02-11 11:59:01 --> Form Validation Class Initialized
INFO - 2024-02-11 11:59:01 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:59:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:59:01 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:59:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:59:01 --> Config Class Initialized
INFO - 2024-02-11 11:59:01 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:59:01 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:59:01 --> Utf8 Class Initialized
INFO - 2024-02-11 11:59:01 --> URI Class Initialized
INFO - 2024-02-11 11:59:01 --> Router Class Initialized
INFO - 2024-02-11 11:59:01 --> Output Class Initialized
INFO - 2024-02-11 11:59:01 --> Security Class Initialized
DEBUG - 2024-02-11 11:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:59:01 --> Input Class Initialized
INFO - 2024-02-11 11:59:01 --> Language Class Initialized
INFO - 2024-02-11 11:59:01 --> Loader Class Initialized
INFO - 2024-02-11 11:59:01 --> Helper loaded: url_helper
INFO - 2024-02-11 11:59:01 --> Helper loaded: file_helper
INFO - 2024-02-11 11:59:01 --> Helper loaded: form_helper
INFO - 2024-02-11 11:59:01 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:59:01 --> Controller Class Initialized
INFO - 2024-02-11 11:59:01 --> Form Validation Class Initialized
INFO - 2024-02-11 11:59:01 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:59:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:59:01 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:59:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:59:02 --> Config Class Initialized
INFO - 2024-02-11 11:59:02 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:59:02 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:59:02 --> Utf8 Class Initialized
INFO - 2024-02-11 11:59:02 --> URI Class Initialized
INFO - 2024-02-11 11:59:02 --> Router Class Initialized
INFO - 2024-02-11 11:59:02 --> Output Class Initialized
INFO - 2024-02-11 11:59:02 --> Security Class Initialized
DEBUG - 2024-02-11 11:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:59:02 --> Input Class Initialized
INFO - 2024-02-11 11:59:02 --> Language Class Initialized
INFO - 2024-02-11 11:59:02 --> Loader Class Initialized
INFO - 2024-02-11 11:59:02 --> Helper loaded: url_helper
INFO - 2024-02-11 11:59:02 --> Helper loaded: file_helper
INFO - 2024-02-11 11:59:02 --> Helper loaded: form_helper
INFO - 2024-02-11 11:59:02 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:59:02 --> Controller Class Initialized
INFO - 2024-02-11 11:59:02 --> Form Validation Class Initialized
INFO - 2024-02-11 11:59:02 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:59:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:59:02 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:59:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:59:03 --> Config Class Initialized
INFO - 2024-02-11 11:59:03 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:59:03 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:59:03 --> Utf8 Class Initialized
INFO - 2024-02-11 11:59:03 --> URI Class Initialized
INFO - 2024-02-11 11:59:03 --> Router Class Initialized
INFO - 2024-02-11 11:59:03 --> Output Class Initialized
INFO - 2024-02-11 11:59:03 --> Security Class Initialized
DEBUG - 2024-02-11 11:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:59:03 --> Input Class Initialized
INFO - 2024-02-11 11:59:03 --> Language Class Initialized
INFO - 2024-02-11 11:59:03 --> Loader Class Initialized
INFO - 2024-02-11 11:59:03 --> Helper loaded: url_helper
INFO - 2024-02-11 11:59:03 --> Helper loaded: file_helper
INFO - 2024-02-11 11:59:03 --> Helper loaded: form_helper
INFO - 2024-02-11 11:59:03 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:59:03 --> Controller Class Initialized
INFO - 2024-02-11 11:59:03 --> Form Validation Class Initialized
INFO - 2024-02-11 11:59:03 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:59:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:59:03 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:59:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:59:04 --> Config Class Initialized
INFO - 2024-02-11 11:59:04 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:59:04 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:59:04 --> Utf8 Class Initialized
INFO - 2024-02-11 11:59:04 --> URI Class Initialized
INFO - 2024-02-11 11:59:04 --> Router Class Initialized
INFO - 2024-02-11 11:59:04 --> Output Class Initialized
INFO - 2024-02-11 11:59:04 --> Security Class Initialized
DEBUG - 2024-02-11 11:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:59:04 --> Input Class Initialized
INFO - 2024-02-11 11:59:04 --> Language Class Initialized
INFO - 2024-02-11 11:59:04 --> Loader Class Initialized
INFO - 2024-02-11 11:59:04 --> Helper loaded: url_helper
INFO - 2024-02-11 11:59:04 --> Helper loaded: file_helper
INFO - 2024-02-11 11:59:04 --> Helper loaded: form_helper
INFO - 2024-02-11 11:59:04 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:59:04 --> Controller Class Initialized
INFO - 2024-02-11 11:59:04 --> Form Validation Class Initialized
INFO - 2024-02-11 11:59:04 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:59:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:59:04 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:59:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:59:12 --> Config Class Initialized
INFO - 2024-02-11 11:59:12 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:59:12 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:59:12 --> Utf8 Class Initialized
INFO - 2024-02-11 11:59:12 --> URI Class Initialized
INFO - 2024-02-11 11:59:12 --> Router Class Initialized
INFO - 2024-02-11 11:59:12 --> Output Class Initialized
INFO - 2024-02-11 11:59:12 --> Security Class Initialized
DEBUG - 2024-02-11 11:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:59:12 --> Input Class Initialized
INFO - 2024-02-11 11:59:12 --> Language Class Initialized
INFO - 2024-02-11 11:59:12 --> Loader Class Initialized
INFO - 2024-02-11 11:59:12 --> Helper loaded: url_helper
INFO - 2024-02-11 11:59:12 --> Helper loaded: file_helper
INFO - 2024-02-11 11:59:12 --> Helper loaded: form_helper
INFO - 2024-02-11 11:59:12 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:59:12 --> Controller Class Initialized
INFO - 2024-02-11 11:59:12 --> Form Validation Class Initialized
INFO - 2024-02-11 11:59:12 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:59:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:59:12 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:59:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:59:14 --> Config Class Initialized
INFO - 2024-02-11 11:59:14 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:59:14 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:59:14 --> Utf8 Class Initialized
INFO - 2024-02-11 11:59:14 --> URI Class Initialized
INFO - 2024-02-11 11:59:14 --> Router Class Initialized
INFO - 2024-02-11 11:59:14 --> Output Class Initialized
INFO - 2024-02-11 11:59:14 --> Security Class Initialized
DEBUG - 2024-02-11 11:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:59:14 --> Input Class Initialized
INFO - 2024-02-11 11:59:14 --> Language Class Initialized
INFO - 2024-02-11 11:59:14 --> Loader Class Initialized
INFO - 2024-02-11 11:59:14 --> Helper loaded: url_helper
INFO - 2024-02-11 11:59:14 --> Helper loaded: file_helper
INFO - 2024-02-11 11:59:14 --> Helper loaded: form_helper
INFO - 2024-02-11 11:59:14 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:59:14 --> Controller Class Initialized
INFO - 2024-02-11 11:59:14 --> Form Validation Class Initialized
INFO - 2024-02-11 11:59:14 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:59:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:59:14 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:59:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:59:14 --> Config Class Initialized
INFO - 2024-02-11 11:59:14 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:59:14 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:59:14 --> Utf8 Class Initialized
INFO - 2024-02-11 11:59:14 --> URI Class Initialized
INFO - 2024-02-11 11:59:14 --> Router Class Initialized
INFO - 2024-02-11 11:59:14 --> Output Class Initialized
INFO - 2024-02-11 11:59:14 --> Security Class Initialized
DEBUG - 2024-02-11 11:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:59:14 --> Input Class Initialized
INFO - 2024-02-11 11:59:14 --> Language Class Initialized
INFO - 2024-02-11 11:59:14 --> Loader Class Initialized
INFO - 2024-02-11 11:59:14 --> Helper loaded: url_helper
INFO - 2024-02-11 11:59:14 --> Helper loaded: file_helper
INFO - 2024-02-11 11:59:14 --> Helper loaded: form_helper
INFO - 2024-02-11 11:59:14 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:59:14 --> Controller Class Initialized
INFO - 2024-02-11 11:59:14 --> Form Validation Class Initialized
INFO - 2024-02-11 11:59:14 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:59:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:59:14 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 11:59:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 11:59:17 --> Config Class Initialized
INFO - 2024-02-11 11:59:17 --> Hooks Class Initialized
DEBUG - 2024-02-11 11:59:17 --> UTF-8 Support Enabled
INFO - 2024-02-11 11:59:17 --> Utf8 Class Initialized
INFO - 2024-02-11 11:59:17 --> URI Class Initialized
INFO - 2024-02-11 11:59:17 --> Router Class Initialized
INFO - 2024-02-11 11:59:17 --> Output Class Initialized
INFO - 2024-02-11 11:59:17 --> Security Class Initialized
DEBUG - 2024-02-11 11:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 11:59:17 --> Input Class Initialized
INFO - 2024-02-11 11:59:17 --> Language Class Initialized
INFO - 2024-02-11 11:59:17 --> Loader Class Initialized
INFO - 2024-02-11 11:59:17 --> Helper loaded: url_helper
INFO - 2024-02-11 11:59:17 --> Helper loaded: file_helper
INFO - 2024-02-11 11:59:17 --> Helper loaded: form_helper
INFO - 2024-02-11 11:59:17 --> Database Driver Class Initialized
DEBUG - 2024-02-11 11:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 11:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 11:59:17 --> Controller Class Initialized
INFO - 2024-02-11 11:59:17 --> Form Validation Class Initialized
INFO - 2024-02-11 11:59:17 --> Model "MasterModel" initialized
INFO - 2024-02-11 11:59:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 11:59:17 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 12:00:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 12:00:49 --> Config Class Initialized
INFO - 2024-02-11 12:00:49 --> Hooks Class Initialized
DEBUG - 2024-02-11 12:00:49 --> UTF-8 Support Enabled
INFO - 2024-02-11 12:00:49 --> Utf8 Class Initialized
INFO - 2024-02-11 12:00:49 --> URI Class Initialized
INFO - 2024-02-11 12:00:49 --> Router Class Initialized
INFO - 2024-02-11 12:00:49 --> Output Class Initialized
INFO - 2024-02-11 12:00:49 --> Security Class Initialized
DEBUG - 2024-02-11 12:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 12:00:49 --> Input Class Initialized
INFO - 2024-02-11 12:00:49 --> Language Class Initialized
INFO - 2024-02-11 12:00:49 --> Loader Class Initialized
INFO - 2024-02-11 12:00:49 --> Helper loaded: url_helper
INFO - 2024-02-11 12:00:49 --> Helper loaded: file_helper
INFO - 2024-02-11 12:00:49 --> Helper loaded: form_helper
INFO - 2024-02-11 12:00:49 --> Database Driver Class Initialized
DEBUG - 2024-02-11 12:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 12:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 12:00:49 --> Controller Class Initialized
INFO - 2024-02-11 12:00:49 --> Form Validation Class Initialized
INFO - 2024-02-11 12:00:49 --> Model "MasterModel" initialized
INFO - 2024-02-11 12:00:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 12:00:49 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 12:00:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 12:00:53 --> Config Class Initialized
INFO - 2024-02-11 12:00:53 --> Hooks Class Initialized
DEBUG - 2024-02-11 12:00:53 --> UTF-8 Support Enabled
INFO - 2024-02-11 12:00:53 --> Utf8 Class Initialized
INFO - 2024-02-11 12:00:53 --> URI Class Initialized
INFO - 2024-02-11 12:00:53 --> Router Class Initialized
INFO - 2024-02-11 12:00:53 --> Output Class Initialized
INFO - 2024-02-11 12:00:53 --> Security Class Initialized
DEBUG - 2024-02-11 12:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 12:00:53 --> Input Class Initialized
INFO - 2024-02-11 12:00:53 --> Language Class Initialized
INFO - 2024-02-11 12:00:53 --> Loader Class Initialized
INFO - 2024-02-11 12:00:53 --> Helper loaded: url_helper
INFO - 2024-02-11 12:00:53 --> Helper loaded: file_helper
INFO - 2024-02-11 12:00:53 --> Helper loaded: form_helper
INFO - 2024-02-11 12:00:53 --> Database Driver Class Initialized
DEBUG - 2024-02-11 12:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 12:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 12:00:53 --> Controller Class Initialized
INFO - 2024-02-11 12:00:53 --> Form Validation Class Initialized
INFO - 2024-02-11 12:00:53 --> Model "MasterModel" initialized
INFO - 2024-02-11 12:00:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 12:00:53 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 12:00:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 12:00:55 --> Config Class Initialized
INFO - 2024-02-11 12:00:55 --> Hooks Class Initialized
DEBUG - 2024-02-11 12:00:55 --> UTF-8 Support Enabled
INFO - 2024-02-11 12:00:55 --> Utf8 Class Initialized
INFO - 2024-02-11 12:00:55 --> URI Class Initialized
INFO - 2024-02-11 12:00:55 --> Router Class Initialized
INFO - 2024-02-11 12:00:55 --> Output Class Initialized
INFO - 2024-02-11 12:00:55 --> Security Class Initialized
DEBUG - 2024-02-11 12:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 12:00:55 --> Input Class Initialized
INFO - 2024-02-11 12:00:55 --> Language Class Initialized
INFO - 2024-02-11 12:00:55 --> Loader Class Initialized
INFO - 2024-02-11 12:00:55 --> Helper loaded: url_helper
INFO - 2024-02-11 12:00:55 --> Helper loaded: file_helper
INFO - 2024-02-11 12:00:55 --> Helper loaded: form_helper
INFO - 2024-02-11 12:00:55 --> Database Driver Class Initialized
DEBUG - 2024-02-11 12:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 12:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 12:00:55 --> Controller Class Initialized
INFO - 2024-02-11 12:00:55 --> Form Validation Class Initialized
INFO - 2024-02-11 12:00:55 --> Model "MasterModel" initialized
INFO - 2024-02-11 12:00:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 12:00:55 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 16:49:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 16:49:18 --> Config Class Initialized
INFO - 2024-02-11 16:49:18 --> Hooks Class Initialized
DEBUG - 2024-02-11 16:49:18 --> UTF-8 Support Enabled
INFO - 2024-02-11 16:49:18 --> Utf8 Class Initialized
INFO - 2024-02-11 16:49:18 --> URI Class Initialized
INFO - 2024-02-11 16:49:18 --> Router Class Initialized
INFO - 2024-02-11 16:49:18 --> Output Class Initialized
INFO - 2024-02-11 16:49:18 --> Security Class Initialized
DEBUG - 2024-02-11 16:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 16:49:18 --> Input Class Initialized
INFO - 2024-02-11 16:49:18 --> Language Class Initialized
INFO - 2024-02-11 16:49:18 --> Loader Class Initialized
INFO - 2024-02-11 16:49:18 --> Helper loaded: url_helper
INFO - 2024-02-11 16:49:18 --> Helper loaded: file_helper
INFO - 2024-02-11 16:49:18 --> Helper loaded: form_helper
INFO - 2024-02-11 16:49:18 --> Database Driver Class Initialized
DEBUG - 2024-02-11 16:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 16:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 16:49:18 --> Controller Class Initialized
INFO - 2024-02-11 16:49:18 --> Form Validation Class Initialized
INFO - 2024-02-11 16:49:18 --> Model "MasterModel" initialized
INFO - 2024-02-11 16:49:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 16:49:18 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-11 18:31:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:31:07 --> Config Class Initialized
INFO - 2024-02-11 18:31:07 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:31:07 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:31:07 --> Utf8 Class Initialized
INFO - 2024-02-11 18:31:07 --> URI Class Initialized
INFO - 2024-02-11 18:31:07 --> Router Class Initialized
INFO - 2024-02-11 18:31:07 --> Output Class Initialized
INFO - 2024-02-11 18:31:07 --> Security Class Initialized
DEBUG - 2024-02-11 18:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:31:07 --> Input Class Initialized
INFO - 2024-02-11 18:31:07 --> Language Class Initialized
INFO - 2024-02-11 18:31:07 --> Loader Class Initialized
INFO - 2024-02-11 18:31:07 --> Helper loaded: url_helper
INFO - 2024-02-11 18:31:07 --> Helper loaded: file_helper
INFO - 2024-02-11 18:31:07 --> Helper loaded: form_helper
INFO - 2024-02-11 18:31:07 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:31:07 --> Controller Class Initialized
INFO - 2024-02-11 18:31:07 --> Form Validation Class Initialized
INFO - 2024-02-11 18:31:07 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:31:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:31:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:31:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-11 18:31:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 18:31:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 18:31:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 18:31:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 18:31:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-11 18:31:07 --> Final output sent to browser
DEBUG - 2024-02-11 18:31:07 --> Total execution time: 0.0415
ERROR - 2024-02-11 18:31:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:31:10 --> Config Class Initialized
INFO - 2024-02-11 18:31:10 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:31:10 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:31:10 --> Utf8 Class Initialized
INFO - 2024-02-11 18:31:10 --> URI Class Initialized
INFO - 2024-02-11 18:31:10 --> Router Class Initialized
INFO - 2024-02-11 18:31:10 --> Output Class Initialized
INFO - 2024-02-11 18:31:10 --> Security Class Initialized
DEBUG - 2024-02-11 18:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:31:10 --> Input Class Initialized
INFO - 2024-02-11 18:31:10 --> Language Class Initialized
INFO - 2024-02-11 18:31:10 --> Loader Class Initialized
INFO - 2024-02-11 18:31:10 --> Helper loaded: url_helper
INFO - 2024-02-11 18:31:10 --> Helper loaded: file_helper
INFO - 2024-02-11 18:31:10 --> Helper loaded: form_helper
INFO - 2024-02-11 18:31:10 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:31:10 --> Controller Class Initialized
INFO - 2024-02-11 18:31:10 --> Form Validation Class Initialized
INFO - 2024-02-11 18:31:10 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:31:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:31:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:31:10 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:31:15 --> Config Class Initialized
INFO - 2024-02-11 18:31:15 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:31:15 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:31:15 --> Utf8 Class Initialized
INFO - 2024-02-11 18:31:15 --> URI Class Initialized
INFO - 2024-02-11 18:31:15 --> Router Class Initialized
INFO - 2024-02-11 18:31:15 --> Output Class Initialized
INFO - 2024-02-11 18:31:15 --> Security Class Initialized
DEBUG - 2024-02-11 18:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:31:15 --> Input Class Initialized
INFO - 2024-02-11 18:31:15 --> Language Class Initialized
INFO - 2024-02-11 18:31:15 --> Loader Class Initialized
INFO - 2024-02-11 18:31:15 --> Helper loaded: url_helper
INFO - 2024-02-11 18:31:15 --> Helper loaded: file_helper
INFO - 2024-02-11 18:31:15 --> Helper loaded: form_helper
INFO - 2024-02-11 18:31:15 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:31:15 --> Controller Class Initialized
INFO - 2024-02-11 18:31:15 --> Form Validation Class Initialized
INFO - 2024-02-11 18:31:15 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:31:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:31:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:31:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-11 18:31:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 18:31:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 18:31:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 18:31:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 18:31:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-11 18:31:15 --> Final output sent to browser
DEBUG - 2024-02-11 18:31:15 --> Total execution time: 0.0372
ERROR - 2024-02-11 18:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:31:15 --> Config Class Initialized
INFO - 2024-02-11 18:31:15 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:31:15 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:31:15 --> Utf8 Class Initialized
INFO - 2024-02-11 18:31:16 --> URI Class Initialized
INFO - 2024-02-11 18:31:16 --> Router Class Initialized
INFO - 2024-02-11 18:31:16 --> Output Class Initialized
INFO - 2024-02-11 18:31:16 --> Security Class Initialized
DEBUG - 2024-02-11 18:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:31:16 --> Input Class Initialized
INFO - 2024-02-11 18:31:16 --> Language Class Initialized
INFO - 2024-02-11 18:31:16 --> Loader Class Initialized
INFO - 2024-02-11 18:31:16 --> Helper loaded: url_helper
INFO - 2024-02-11 18:31:16 --> Helper loaded: file_helper
INFO - 2024-02-11 18:31:16 --> Helper loaded: form_helper
INFO - 2024-02-11 18:31:16 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:31:16 --> Controller Class Initialized
INFO - 2024-02-11 18:31:16 --> Form Validation Class Initialized
INFO - 2024-02-11 18:31:16 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:31:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:31:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:31:16 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:31:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:31:17 --> Config Class Initialized
INFO - 2024-02-11 18:31:17 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:31:17 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:31:17 --> Utf8 Class Initialized
INFO - 2024-02-11 18:31:17 --> URI Class Initialized
INFO - 2024-02-11 18:31:17 --> Router Class Initialized
INFO - 2024-02-11 18:31:17 --> Output Class Initialized
INFO - 2024-02-11 18:31:17 --> Security Class Initialized
DEBUG - 2024-02-11 18:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:31:17 --> Input Class Initialized
INFO - 2024-02-11 18:31:17 --> Language Class Initialized
INFO - 2024-02-11 18:31:17 --> Loader Class Initialized
INFO - 2024-02-11 18:31:17 --> Helper loaded: url_helper
INFO - 2024-02-11 18:31:17 --> Helper loaded: file_helper
INFO - 2024-02-11 18:31:17 --> Helper loaded: form_helper
INFO - 2024-02-11 18:31:17 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:31:17 --> Controller Class Initialized
INFO - 2024-02-11 18:31:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-11 18:31:17 --> Final output sent to browser
DEBUG - 2024-02-11 18:31:17 --> Total execution time: 0.0264
ERROR - 2024-02-11 18:31:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:31:21 --> Config Class Initialized
INFO - 2024-02-11 18:31:21 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:31:21 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:31:21 --> Utf8 Class Initialized
INFO - 2024-02-11 18:31:21 --> URI Class Initialized
INFO - 2024-02-11 18:31:21 --> Router Class Initialized
INFO - 2024-02-11 18:31:21 --> Output Class Initialized
INFO - 2024-02-11 18:31:21 --> Security Class Initialized
DEBUG - 2024-02-11 18:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:31:21 --> Input Class Initialized
INFO - 2024-02-11 18:31:21 --> Language Class Initialized
INFO - 2024-02-11 18:31:21 --> Loader Class Initialized
INFO - 2024-02-11 18:31:21 --> Helper loaded: url_helper
INFO - 2024-02-11 18:31:21 --> Helper loaded: file_helper
INFO - 2024-02-11 18:31:21 --> Helper loaded: form_helper
INFO - 2024-02-11 18:31:21 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:31:21 --> Controller Class Initialized
INFO - 2024-02-11 18:31:21 --> Form Validation Class Initialized
INFO - 2024-02-11 18:31:21 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:31:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:31:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:31:21 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:31:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:31:22 --> Config Class Initialized
INFO - 2024-02-11 18:31:22 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:31:22 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:31:22 --> Utf8 Class Initialized
INFO - 2024-02-11 18:31:22 --> URI Class Initialized
INFO - 2024-02-11 18:31:22 --> Router Class Initialized
INFO - 2024-02-11 18:31:22 --> Output Class Initialized
INFO - 2024-02-11 18:31:22 --> Security Class Initialized
DEBUG - 2024-02-11 18:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:31:22 --> Input Class Initialized
INFO - 2024-02-11 18:31:22 --> Language Class Initialized
INFO - 2024-02-11 18:31:22 --> Loader Class Initialized
INFO - 2024-02-11 18:31:22 --> Helper loaded: url_helper
INFO - 2024-02-11 18:31:22 --> Helper loaded: file_helper
INFO - 2024-02-11 18:31:22 --> Helper loaded: form_helper
INFO - 2024-02-11 18:31:22 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:31:22 --> Controller Class Initialized
INFO - 2024-02-11 18:31:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-11 18:31:22 --> Final output sent to browser
DEBUG - 2024-02-11 18:31:22 --> Total execution time: 0.0324
ERROR - 2024-02-11 18:31:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:31:54 --> Config Class Initialized
INFO - 2024-02-11 18:31:54 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:31:54 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:31:54 --> Utf8 Class Initialized
INFO - 2024-02-11 18:31:54 --> URI Class Initialized
INFO - 2024-02-11 18:31:54 --> Router Class Initialized
INFO - 2024-02-11 18:31:54 --> Output Class Initialized
INFO - 2024-02-11 18:31:54 --> Security Class Initialized
DEBUG - 2024-02-11 18:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:31:54 --> Input Class Initialized
INFO - 2024-02-11 18:31:54 --> Language Class Initialized
INFO - 2024-02-11 18:31:54 --> Loader Class Initialized
INFO - 2024-02-11 18:31:54 --> Helper loaded: url_helper
INFO - 2024-02-11 18:31:54 --> Helper loaded: file_helper
INFO - 2024-02-11 18:31:54 --> Helper loaded: form_helper
INFO - 2024-02-11 18:31:54 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:31:54 --> Controller Class Initialized
INFO - 2024-02-11 18:31:54 --> Form Validation Class Initialized
INFO - 2024-02-11 18:31:54 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:31:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:31:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:31:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-11 18:31:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 18:31:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 18:31:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 18:31:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 18:31:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-11 18:31:54 --> Final output sent to browser
DEBUG - 2024-02-11 18:31:54 --> Total execution time: 0.0435
ERROR - 2024-02-11 18:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:31:56 --> Config Class Initialized
INFO - 2024-02-11 18:31:56 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:31:56 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:31:56 --> Utf8 Class Initialized
INFO - 2024-02-11 18:31:56 --> URI Class Initialized
INFO - 2024-02-11 18:31:56 --> Router Class Initialized
INFO - 2024-02-11 18:31:56 --> Output Class Initialized
INFO - 2024-02-11 18:31:56 --> Security Class Initialized
DEBUG - 2024-02-11 18:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:31:56 --> Input Class Initialized
INFO - 2024-02-11 18:31:56 --> Language Class Initialized
INFO - 2024-02-11 18:31:56 --> Loader Class Initialized
INFO - 2024-02-11 18:31:56 --> Helper loaded: url_helper
INFO - 2024-02-11 18:31:56 --> Helper loaded: file_helper
INFO - 2024-02-11 18:31:56 --> Helper loaded: form_helper
INFO - 2024-02-11 18:31:56 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:31:56 --> Controller Class Initialized
INFO - 2024-02-11 18:31:56 --> Form Validation Class Initialized
INFO - 2024-02-11 18:31:56 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:31:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:31:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:31:56 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:32:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:32:09 --> Config Class Initialized
INFO - 2024-02-11 18:32:09 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:32:09 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:32:09 --> Utf8 Class Initialized
INFO - 2024-02-11 18:32:09 --> URI Class Initialized
INFO - 2024-02-11 18:32:09 --> Router Class Initialized
INFO - 2024-02-11 18:32:09 --> Output Class Initialized
INFO - 2024-02-11 18:32:09 --> Security Class Initialized
DEBUG - 2024-02-11 18:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:32:09 --> Input Class Initialized
INFO - 2024-02-11 18:32:09 --> Language Class Initialized
INFO - 2024-02-11 18:32:09 --> Loader Class Initialized
INFO - 2024-02-11 18:32:09 --> Helper loaded: url_helper
INFO - 2024-02-11 18:32:09 --> Helper loaded: file_helper
INFO - 2024-02-11 18:32:09 --> Helper loaded: form_helper
INFO - 2024-02-11 18:32:09 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:32:09 --> Controller Class Initialized
INFO - 2024-02-11 18:32:09 --> Form Validation Class Initialized
INFO - 2024-02-11 18:32:09 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:32:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:32:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:32:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-11 18:32:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 18:32:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 18:32:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 18:32:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 18:32:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-11 18:32:09 --> Final output sent to browser
DEBUG - 2024-02-11 18:32:09 --> Total execution time: 0.0435
ERROR - 2024-02-11 18:32:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:32:40 --> Config Class Initialized
INFO - 2024-02-11 18:32:40 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:32:40 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:32:40 --> Utf8 Class Initialized
INFO - 2024-02-11 18:32:40 --> URI Class Initialized
INFO - 2024-02-11 18:32:40 --> Router Class Initialized
INFO - 2024-02-11 18:32:40 --> Output Class Initialized
INFO - 2024-02-11 18:32:40 --> Security Class Initialized
DEBUG - 2024-02-11 18:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:32:40 --> Input Class Initialized
INFO - 2024-02-11 18:32:40 --> Language Class Initialized
INFO - 2024-02-11 18:32:40 --> Loader Class Initialized
INFO - 2024-02-11 18:32:40 --> Helper loaded: url_helper
INFO - 2024-02-11 18:32:40 --> Helper loaded: file_helper
INFO - 2024-02-11 18:32:40 --> Helper loaded: form_helper
INFO - 2024-02-11 18:32:40 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:32:40 --> Controller Class Initialized
INFO - 2024-02-11 18:32:40 --> Form Validation Class Initialized
INFO - 2024-02-11 18:32:40 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:32:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:32:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:32:40 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:32:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:32:48 --> Config Class Initialized
INFO - 2024-02-11 18:32:48 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:32:48 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:32:48 --> Utf8 Class Initialized
INFO - 2024-02-11 18:32:48 --> URI Class Initialized
INFO - 2024-02-11 18:32:48 --> Router Class Initialized
INFO - 2024-02-11 18:32:48 --> Output Class Initialized
INFO - 2024-02-11 18:32:48 --> Security Class Initialized
DEBUG - 2024-02-11 18:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:32:48 --> Input Class Initialized
INFO - 2024-02-11 18:32:48 --> Language Class Initialized
INFO - 2024-02-11 18:32:48 --> Loader Class Initialized
INFO - 2024-02-11 18:32:48 --> Helper loaded: url_helper
INFO - 2024-02-11 18:32:48 --> Helper loaded: file_helper
INFO - 2024-02-11 18:32:48 --> Helper loaded: form_helper
INFO - 2024-02-11 18:32:48 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:32:48 --> Controller Class Initialized
INFO - 2024-02-11 18:32:48 --> Form Validation Class Initialized
INFO - 2024-02-11 18:32:48 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:32:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:32:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:32:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:32:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-11 18:32:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-11 18:32:48 --> Final output sent to browser
DEBUG - 2024-02-11 18:32:48 --> Total execution time: 0.0559
ERROR - 2024-02-11 18:34:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:34:12 --> Config Class Initialized
INFO - 2024-02-11 18:34:12 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:34:12 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:34:12 --> Utf8 Class Initialized
INFO - 2024-02-11 18:34:12 --> URI Class Initialized
INFO - 2024-02-11 18:34:12 --> Router Class Initialized
INFO - 2024-02-11 18:34:12 --> Output Class Initialized
INFO - 2024-02-11 18:34:12 --> Security Class Initialized
DEBUG - 2024-02-11 18:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:34:12 --> Input Class Initialized
INFO - 2024-02-11 18:34:12 --> Language Class Initialized
INFO - 2024-02-11 18:34:12 --> Loader Class Initialized
INFO - 2024-02-11 18:34:12 --> Helper loaded: url_helper
INFO - 2024-02-11 18:34:12 --> Helper loaded: file_helper
INFO - 2024-02-11 18:34:12 --> Helper loaded: form_helper
INFO - 2024-02-11 18:34:12 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:34:12 --> Controller Class Initialized
INFO - 2024-02-11 18:34:12 --> Form Validation Class Initialized
INFO - 2024-02-11 18:34:12 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:34:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:34:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:34:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-11 18:34:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 18:34:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 18:34:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 18:34:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 18:34:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-11 18:34:12 --> Final output sent to browser
DEBUG - 2024-02-11 18:34:12 --> Total execution time: 0.0448
ERROR - 2024-02-11 18:34:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:34:14 --> Config Class Initialized
INFO - 2024-02-11 18:34:14 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:34:14 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:34:14 --> Utf8 Class Initialized
INFO - 2024-02-11 18:34:14 --> URI Class Initialized
INFO - 2024-02-11 18:34:14 --> Router Class Initialized
INFO - 2024-02-11 18:34:14 --> Output Class Initialized
INFO - 2024-02-11 18:34:14 --> Security Class Initialized
DEBUG - 2024-02-11 18:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:34:14 --> Input Class Initialized
INFO - 2024-02-11 18:34:14 --> Language Class Initialized
INFO - 2024-02-11 18:34:14 --> Loader Class Initialized
INFO - 2024-02-11 18:34:14 --> Helper loaded: url_helper
INFO - 2024-02-11 18:34:14 --> Helper loaded: file_helper
INFO - 2024-02-11 18:34:14 --> Helper loaded: form_helper
INFO - 2024-02-11 18:34:14 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:34:14 --> Controller Class Initialized
INFO - 2024-02-11 18:34:14 --> Form Validation Class Initialized
INFO - 2024-02-11 18:34:14 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:34:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:34:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:34:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:34:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:34:25 --> Config Class Initialized
INFO - 2024-02-11 18:34:25 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:34:25 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:34:25 --> Utf8 Class Initialized
INFO - 2024-02-11 18:34:25 --> URI Class Initialized
INFO - 2024-02-11 18:34:25 --> Router Class Initialized
INFO - 2024-02-11 18:34:25 --> Output Class Initialized
INFO - 2024-02-11 18:34:25 --> Security Class Initialized
DEBUG - 2024-02-11 18:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:34:25 --> Input Class Initialized
INFO - 2024-02-11 18:34:25 --> Language Class Initialized
INFO - 2024-02-11 18:34:25 --> Loader Class Initialized
INFO - 2024-02-11 18:34:25 --> Helper loaded: url_helper
INFO - 2024-02-11 18:34:25 --> Helper loaded: file_helper
INFO - 2024-02-11 18:34:25 --> Helper loaded: form_helper
INFO - 2024-02-11 18:34:25 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:34:25 --> Controller Class Initialized
INFO - 2024-02-11 18:34:25 --> Form Validation Class Initialized
INFO - 2024-02-11 18:34:25 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:34:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:34:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:34:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:34:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-11 18:34:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-11 18:34:25 --> Final output sent to browser
DEBUG - 2024-02-11 18:34:25 --> Total execution time: 0.0402
ERROR - 2024-02-11 18:36:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:36:09 --> Config Class Initialized
INFO - 2024-02-11 18:36:09 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:36:09 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:36:09 --> Utf8 Class Initialized
INFO - 2024-02-11 18:36:09 --> URI Class Initialized
INFO - 2024-02-11 18:36:09 --> Router Class Initialized
INFO - 2024-02-11 18:36:09 --> Output Class Initialized
INFO - 2024-02-11 18:36:09 --> Security Class Initialized
DEBUG - 2024-02-11 18:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:36:09 --> Input Class Initialized
INFO - 2024-02-11 18:36:09 --> Language Class Initialized
INFO - 2024-02-11 18:36:09 --> Loader Class Initialized
INFO - 2024-02-11 18:36:09 --> Helper loaded: url_helper
INFO - 2024-02-11 18:36:09 --> Helper loaded: file_helper
INFO - 2024-02-11 18:36:09 --> Helper loaded: form_helper
INFO - 2024-02-11 18:36:09 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:36:09 --> Controller Class Initialized
INFO - 2024-02-11 18:36:09 --> Form Validation Class Initialized
INFO - 2024-02-11 18:36:09 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:36:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:36:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:36:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-11 18:36:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 18:36:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 18:36:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 18:36:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 18:36:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-11 18:36:09 --> Final output sent to browser
DEBUG - 2024-02-11 18:36:09 --> Total execution time: 0.0439
ERROR - 2024-02-11 18:36:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:36:10 --> Config Class Initialized
INFO - 2024-02-11 18:36:10 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:36:10 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:36:10 --> Utf8 Class Initialized
INFO - 2024-02-11 18:36:10 --> URI Class Initialized
INFO - 2024-02-11 18:36:10 --> Router Class Initialized
INFO - 2024-02-11 18:36:10 --> Output Class Initialized
INFO - 2024-02-11 18:36:10 --> Security Class Initialized
DEBUG - 2024-02-11 18:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:36:10 --> Input Class Initialized
INFO - 2024-02-11 18:36:10 --> Language Class Initialized
INFO - 2024-02-11 18:36:10 --> Loader Class Initialized
INFO - 2024-02-11 18:36:10 --> Helper loaded: url_helper
INFO - 2024-02-11 18:36:10 --> Helper loaded: file_helper
INFO - 2024-02-11 18:36:10 --> Helper loaded: form_helper
INFO - 2024-02-11 18:36:10 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:36:10 --> Controller Class Initialized
INFO - 2024-02-11 18:36:10 --> Form Validation Class Initialized
INFO - 2024-02-11 18:36:10 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:36:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:36:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:36:10 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:36:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:36:18 --> Config Class Initialized
INFO - 2024-02-11 18:36:18 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:36:18 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:36:18 --> Utf8 Class Initialized
INFO - 2024-02-11 18:36:18 --> URI Class Initialized
INFO - 2024-02-11 18:36:18 --> Router Class Initialized
INFO - 2024-02-11 18:36:18 --> Output Class Initialized
INFO - 2024-02-11 18:36:18 --> Security Class Initialized
DEBUG - 2024-02-11 18:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:36:18 --> Input Class Initialized
INFO - 2024-02-11 18:36:18 --> Language Class Initialized
INFO - 2024-02-11 18:36:18 --> Loader Class Initialized
INFO - 2024-02-11 18:36:18 --> Helper loaded: url_helper
INFO - 2024-02-11 18:36:18 --> Helper loaded: file_helper
INFO - 2024-02-11 18:36:18 --> Helper loaded: form_helper
INFO - 2024-02-11 18:36:18 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:36:18 --> Controller Class Initialized
INFO - 2024-02-11 18:36:18 --> Form Validation Class Initialized
INFO - 2024-02-11 18:36:18 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:36:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:36:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:36:18 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:36:18 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-11 18:36:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-11 18:36:18 --> Final output sent to browser
DEBUG - 2024-02-11 18:36:18 --> Total execution time: 0.0667
ERROR - 2024-02-11 18:43:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:43:19 --> Config Class Initialized
INFO - 2024-02-11 18:43:19 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:43:19 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:43:19 --> Utf8 Class Initialized
INFO - 2024-02-11 18:43:19 --> URI Class Initialized
INFO - 2024-02-11 18:43:19 --> Router Class Initialized
INFO - 2024-02-11 18:43:19 --> Output Class Initialized
INFO - 2024-02-11 18:43:19 --> Security Class Initialized
DEBUG - 2024-02-11 18:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:43:19 --> Input Class Initialized
INFO - 2024-02-11 18:43:19 --> Language Class Initialized
INFO - 2024-02-11 18:43:19 --> Loader Class Initialized
INFO - 2024-02-11 18:43:19 --> Helper loaded: url_helper
INFO - 2024-02-11 18:43:19 --> Helper loaded: file_helper
INFO - 2024-02-11 18:43:19 --> Helper loaded: form_helper
INFO - 2024-02-11 18:43:19 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:43:19 --> Controller Class Initialized
INFO - 2024-02-11 18:43:19 --> Form Validation Class Initialized
INFO - 2024-02-11 18:43:19 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:43:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:43:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:43:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-11 18:43:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 18:43:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 18:43:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 18:43:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 18:43:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-11 18:43:19 --> Final output sent to browser
DEBUG - 2024-02-11 18:43:19 --> Total execution time: 0.0377
ERROR - 2024-02-11 18:43:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:43:20 --> Config Class Initialized
INFO - 2024-02-11 18:43:20 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:43:20 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:43:20 --> Utf8 Class Initialized
INFO - 2024-02-11 18:43:20 --> URI Class Initialized
INFO - 2024-02-11 18:43:20 --> Router Class Initialized
INFO - 2024-02-11 18:43:20 --> Output Class Initialized
INFO - 2024-02-11 18:43:20 --> Security Class Initialized
DEBUG - 2024-02-11 18:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:43:20 --> Input Class Initialized
INFO - 2024-02-11 18:43:20 --> Language Class Initialized
INFO - 2024-02-11 18:43:20 --> Loader Class Initialized
INFO - 2024-02-11 18:43:20 --> Helper loaded: url_helper
INFO - 2024-02-11 18:43:20 --> Helper loaded: file_helper
INFO - 2024-02-11 18:43:20 --> Helper loaded: form_helper
INFO - 2024-02-11 18:43:20 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:43:20 --> Controller Class Initialized
INFO - 2024-02-11 18:43:20 --> Form Validation Class Initialized
INFO - 2024-02-11 18:43:20 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:43:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:43:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:43:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:43:25 --> Config Class Initialized
INFO - 2024-02-11 18:43:25 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:43:25 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:43:25 --> Utf8 Class Initialized
INFO - 2024-02-11 18:43:25 --> URI Class Initialized
INFO - 2024-02-11 18:43:25 --> Router Class Initialized
INFO - 2024-02-11 18:43:25 --> Output Class Initialized
INFO - 2024-02-11 18:43:25 --> Security Class Initialized
DEBUG - 2024-02-11 18:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:43:25 --> Input Class Initialized
INFO - 2024-02-11 18:43:25 --> Language Class Initialized
INFO - 2024-02-11 18:43:25 --> Loader Class Initialized
INFO - 2024-02-11 18:43:25 --> Helper loaded: url_helper
INFO - 2024-02-11 18:43:25 --> Helper loaded: file_helper
INFO - 2024-02-11 18:43:25 --> Helper loaded: form_helper
INFO - 2024-02-11 18:43:25 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:43:25 --> Controller Class Initialized
INFO - 2024-02-11 18:43:25 --> Form Validation Class Initialized
INFO - 2024-02-11 18:43:25 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:43:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:43:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:43:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:43:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-11 18:43:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-11 18:43:25 --> Final output sent to browser
DEBUG - 2024-02-11 18:43:25 --> Total execution time: 0.0492
ERROR - 2024-02-11 18:45:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:45:03 --> Config Class Initialized
INFO - 2024-02-11 18:45:03 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:45:03 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:45:03 --> Utf8 Class Initialized
INFO - 2024-02-11 18:45:03 --> URI Class Initialized
INFO - 2024-02-11 18:45:03 --> Router Class Initialized
INFO - 2024-02-11 18:45:03 --> Output Class Initialized
INFO - 2024-02-11 18:45:03 --> Security Class Initialized
DEBUG - 2024-02-11 18:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:45:03 --> Input Class Initialized
INFO - 2024-02-11 18:45:03 --> Language Class Initialized
INFO - 2024-02-11 18:45:03 --> Loader Class Initialized
INFO - 2024-02-11 18:45:03 --> Helper loaded: url_helper
INFO - 2024-02-11 18:45:03 --> Helper loaded: file_helper
INFO - 2024-02-11 18:45:03 --> Helper loaded: form_helper
INFO - 2024-02-11 18:45:03 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:45:03 --> Controller Class Initialized
INFO - 2024-02-11 18:45:03 --> Form Validation Class Initialized
INFO - 2024-02-11 18:45:03 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:45:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:45:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:45:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-11 18:45:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 18:45:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 18:45:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 18:45:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 18:45:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-11 18:45:03 --> Final output sent to browser
DEBUG - 2024-02-11 18:45:03 --> Total execution time: 0.0486
ERROR - 2024-02-11 18:45:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:45:03 --> Config Class Initialized
INFO - 2024-02-11 18:45:03 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:45:03 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:45:03 --> Utf8 Class Initialized
INFO - 2024-02-11 18:45:03 --> URI Class Initialized
INFO - 2024-02-11 18:45:03 --> Router Class Initialized
INFO - 2024-02-11 18:45:03 --> Output Class Initialized
INFO - 2024-02-11 18:45:03 --> Security Class Initialized
DEBUG - 2024-02-11 18:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:45:03 --> Input Class Initialized
INFO - 2024-02-11 18:45:03 --> Language Class Initialized
INFO - 2024-02-11 18:45:03 --> Loader Class Initialized
INFO - 2024-02-11 18:45:03 --> Helper loaded: url_helper
INFO - 2024-02-11 18:45:03 --> Helper loaded: file_helper
INFO - 2024-02-11 18:45:03 --> Helper loaded: form_helper
INFO - 2024-02-11 18:45:03 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:45:03 --> Controller Class Initialized
INFO - 2024-02-11 18:45:03 --> Form Validation Class Initialized
INFO - 2024-02-11 18:45:03 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:45:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:45:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:45:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:45:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:45:06 --> Config Class Initialized
INFO - 2024-02-11 18:45:06 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:45:06 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:45:06 --> Utf8 Class Initialized
INFO - 2024-02-11 18:45:06 --> URI Class Initialized
INFO - 2024-02-11 18:45:06 --> Router Class Initialized
INFO - 2024-02-11 18:45:06 --> Output Class Initialized
INFO - 2024-02-11 18:45:06 --> Security Class Initialized
DEBUG - 2024-02-11 18:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:45:06 --> Input Class Initialized
INFO - 2024-02-11 18:45:06 --> Language Class Initialized
INFO - 2024-02-11 18:45:06 --> Loader Class Initialized
INFO - 2024-02-11 18:45:06 --> Helper loaded: url_helper
INFO - 2024-02-11 18:45:06 --> Helper loaded: file_helper
INFO - 2024-02-11 18:45:06 --> Helper loaded: form_helper
INFO - 2024-02-11 18:45:06 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:45:06 --> Controller Class Initialized
INFO - 2024-02-11 18:45:06 --> Form Validation Class Initialized
INFO - 2024-02-11 18:45:06 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:45:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:45:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:45:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:45:06 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-11 18:45:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-11 18:45:06 --> Final output sent to browser
DEBUG - 2024-02-11 18:45:06 --> Total execution time: 0.0490
ERROR - 2024-02-11 18:46:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:46:21 --> Config Class Initialized
INFO - 2024-02-11 18:46:21 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:46:21 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:46:21 --> Utf8 Class Initialized
INFO - 2024-02-11 18:46:21 --> URI Class Initialized
INFO - 2024-02-11 18:46:21 --> Router Class Initialized
INFO - 2024-02-11 18:46:21 --> Output Class Initialized
INFO - 2024-02-11 18:46:21 --> Security Class Initialized
DEBUG - 2024-02-11 18:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:46:21 --> Input Class Initialized
INFO - 2024-02-11 18:46:21 --> Language Class Initialized
INFO - 2024-02-11 18:46:21 --> Loader Class Initialized
INFO - 2024-02-11 18:46:21 --> Helper loaded: url_helper
INFO - 2024-02-11 18:46:21 --> Helper loaded: file_helper
INFO - 2024-02-11 18:46:21 --> Helper loaded: form_helper
INFO - 2024-02-11 18:46:21 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:46:21 --> Controller Class Initialized
INFO - 2024-02-11 18:46:21 --> Form Validation Class Initialized
INFO - 2024-02-11 18:46:21 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:46:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:46:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:46:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-11 18:46:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 18:46:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 18:46:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 18:46:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 18:46:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-11 18:46:21 --> Final output sent to browser
DEBUG - 2024-02-11 18:46:21 --> Total execution time: 0.0374
ERROR - 2024-02-11 18:46:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:46:22 --> Config Class Initialized
INFO - 2024-02-11 18:46:22 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:46:22 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:46:22 --> Utf8 Class Initialized
INFO - 2024-02-11 18:46:22 --> URI Class Initialized
INFO - 2024-02-11 18:46:22 --> Router Class Initialized
INFO - 2024-02-11 18:46:22 --> Output Class Initialized
INFO - 2024-02-11 18:46:22 --> Security Class Initialized
DEBUG - 2024-02-11 18:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:46:22 --> Input Class Initialized
INFO - 2024-02-11 18:46:22 --> Language Class Initialized
INFO - 2024-02-11 18:46:22 --> Loader Class Initialized
INFO - 2024-02-11 18:46:22 --> Helper loaded: url_helper
INFO - 2024-02-11 18:46:22 --> Helper loaded: file_helper
INFO - 2024-02-11 18:46:22 --> Helper loaded: form_helper
INFO - 2024-02-11 18:46:22 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:46:22 --> Controller Class Initialized
INFO - 2024-02-11 18:46:22 --> Form Validation Class Initialized
INFO - 2024-02-11 18:46:22 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:46:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:46:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:46:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:46:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:46:25 --> Config Class Initialized
INFO - 2024-02-11 18:46:25 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:46:25 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:46:25 --> Utf8 Class Initialized
INFO - 2024-02-11 18:46:25 --> URI Class Initialized
INFO - 2024-02-11 18:46:25 --> Router Class Initialized
INFO - 2024-02-11 18:46:25 --> Output Class Initialized
INFO - 2024-02-11 18:46:25 --> Security Class Initialized
DEBUG - 2024-02-11 18:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:46:25 --> Input Class Initialized
INFO - 2024-02-11 18:46:25 --> Language Class Initialized
INFO - 2024-02-11 18:46:25 --> Loader Class Initialized
INFO - 2024-02-11 18:46:25 --> Helper loaded: url_helper
INFO - 2024-02-11 18:46:25 --> Helper loaded: file_helper
INFO - 2024-02-11 18:46:25 --> Helper loaded: form_helper
INFO - 2024-02-11 18:46:25 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:46:25 --> Controller Class Initialized
INFO - 2024-02-11 18:46:25 --> Form Validation Class Initialized
INFO - 2024-02-11 18:46:25 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:46:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:46:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:46:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:46:25 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-11 18:46:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-11 18:46:25 --> Final output sent to browser
DEBUG - 2024-02-11 18:46:25 --> Total execution time: 0.0476
ERROR - 2024-02-11 18:47:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:47:31 --> Config Class Initialized
INFO - 2024-02-11 18:47:31 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:47:31 --> Utf8 Class Initialized
INFO - 2024-02-11 18:47:31 --> URI Class Initialized
INFO - 2024-02-11 18:47:31 --> Router Class Initialized
INFO - 2024-02-11 18:47:31 --> Output Class Initialized
INFO - 2024-02-11 18:47:31 --> Security Class Initialized
DEBUG - 2024-02-11 18:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:47:31 --> Input Class Initialized
INFO - 2024-02-11 18:47:31 --> Language Class Initialized
INFO - 2024-02-11 18:47:31 --> Loader Class Initialized
INFO - 2024-02-11 18:47:31 --> Helper loaded: url_helper
INFO - 2024-02-11 18:47:31 --> Helper loaded: file_helper
INFO - 2024-02-11 18:47:31 --> Helper loaded: form_helper
INFO - 2024-02-11 18:47:31 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:47:31 --> Controller Class Initialized
INFO - 2024-02-11 18:47:31 --> Form Validation Class Initialized
INFO - 2024-02-11 18:47:31 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:47:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:47:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:47:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-11 18:47:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-11 18:47:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-11 18:47:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-11 18:47:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-11 18:47:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-11 18:47:31 --> Final output sent to browser
DEBUG - 2024-02-11 18:47:31 --> Total execution time: 0.0467
ERROR - 2024-02-11 18:47:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:47:31 --> Config Class Initialized
INFO - 2024-02-11 18:47:31 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:47:31 --> Utf8 Class Initialized
INFO - 2024-02-11 18:47:31 --> URI Class Initialized
INFO - 2024-02-11 18:47:31 --> Router Class Initialized
INFO - 2024-02-11 18:47:31 --> Output Class Initialized
INFO - 2024-02-11 18:47:31 --> Security Class Initialized
DEBUG - 2024-02-11 18:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:47:31 --> Input Class Initialized
INFO - 2024-02-11 18:47:31 --> Language Class Initialized
INFO - 2024-02-11 18:47:31 --> Loader Class Initialized
INFO - 2024-02-11 18:47:31 --> Helper loaded: url_helper
INFO - 2024-02-11 18:47:31 --> Helper loaded: file_helper
INFO - 2024-02-11 18:47:31 --> Helper loaded: form_helper
INFO - 2024-02-11 18:47:31 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:47:31 --> Controller Class Initialized
INFO - 2024-02-11 18:47:31 --> Form Validation Class Initialized
INFO - 2024-02-11 18:47:31 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:47:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:47:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:47:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:47:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-11 18:47:35 --> Config Class Initialized
INFO - 2024-02-11 18:47:35 --> Hooks Class Initialized
DEBUG - 2024-02-11 18:47:35 --> UTF-8 Support Enabled
INFO - 2024-02-11 18:47:35 --> Utf8 Class Initialized
INFO - 2024-02-11 18:47:35 --> URI Class Initialized
INFO - 2024-02-11 18:47:35 --> Router Class Initialized
INFO - 2024-02-11 18:47:35 --> Output Class Initialized
INFO - 2024-02-11 18:47:35 --> Security Class Initialized
DEBUG - 2024-02-11 18:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 18:47:35 --> Input Class Initialized
INFO - 2024-02-11 18:47:35 --> Language Class Initialized
INFO - 2024-02-11 18:47:35 --> Loader Class Initialized
INFO - 2024-02-11 18:47:35 --> Helper loaded: url_helper
INFO - 2024-02-11 18:47:35 --> Helper loaded: file_helper
INFO - 2024-02-11 18:47:35 --> Helper loaded: form_helper
INFO - 2024-02-11 18:47:35 --> Database Driver Class Initialized
DEBUG - 2024-02-11 18:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-11 18:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 18:47:35 --> Controller Class Initialized
INFO - 2024-02-11 18:47:35 --> Form Validation Class Initialized
INFO - 2024-02-11 18:47:35 --> Model "MasterModel" initialized
INFO - 2024-02-11 18:47:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-11 18:47:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-11 18:47:35 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
ERROR - 2024-02-11 18:47:35 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 36
INFO - 2024-02-11 18:47:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-11 18:47:35 --> Final output sent to browser
DEBUG - 2024-02-11 18:47:35 --> Total execution time: 0.0478
