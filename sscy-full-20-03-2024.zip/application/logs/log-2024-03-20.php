<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-20 12:07:55 --> Config Class Initialized
INFO - 2024-03-20 12:07:55 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:07:55 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:07:55 --> Utf8 Class Initialized
INFO - 2024-03-20 12:07:55 --> URI Class Initialized
INFO - 2024-03-20 12:07:55 --> Router Class Initialized
INFO - 2024-03-20 12:07:55 --> Output Class Initialized
INFO - 2024-03-20 12:07:55 --> Security Class Initialized
DEBUG - 2024-03-20 12:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:07:55 --> Input Class Initialized
INFO - 2024-03-20 12:07:55 --> Language Class Initialized
INFO - 2024-03-20 12:07:55 --> Loader Class Initialized
INFO - 2024-03-20 12:07:55 --> Helper loaded: url_helper
INFO - 2024-03-20 12:07:55 --> Helper loaded: file_helper
INFO - 2024-03-20 12:07:55 --> Helper loaded: form_helper
INFO - 2024-03-20 12:07:55 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:07:55 --> Controller Class Initialized
INFO - 2024-03-20 12:07:55 --> Form Validation Class Initialized
INFO - 2024-03-20 12:07:55 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:07:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 12:07:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-20 12:07:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 12:07:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 12:07:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 12:07:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 12:07:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-20 12:07:55 --> Final output sent to browser
DEBUG - 2024-03-20 12:07:55 --> Total execution time: 0.0339
INFO - 2024-03-20 12:07:55 --> Config Class Initialized
INFO - 2024-03-20 12:07:55 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:07:55 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:07:55 --> Utf8 Class Initialized
INFO - 2024-03-20 12:07:55 --> URI Class Initialized
INFO - 2024-03-20 12:07:55 --> Router Class Initialized
INFO - 2024-03-20 12:07:55 --> Output Class Initialized
INFO - 2024-03-20 12:07:55 --> Security Class Initialized
DEBUG - 2024-03-20 12:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:07:55 --> Input Class Initialized
INFO - 2024-03-20 12:07:55 --> Language Class Initialized
INFO - 2024-03-20 12:07:55 --> Loader Class Initialized
INFO - 2024-03-20 12:07:55 --> Helper loaded: url_helper
INFO - 2024-03-20 12:07:55 --> Helper loaded: file_helper
INFO - 2024-03-20 12:07:55 --> Helper loaded: form_helper
INFO - 2024-03-20 12:07:55 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:07:55 --> Controller Class Initialized
INFO - 2024-03-20 12:07:55 --> Form Validation Class Initialized
INFO - 2024-03-20 12:07:55 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:07:55 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:07:58 --> Config Class Initialized
INFO - 2024-03-20 12:07:58 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:07:58 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:07:58 --> Utf8 Class Initialized
INFO - 2024-03-20 12:07:58 --> URI Class Initialized
INFO - 2024-03-20 12:07:58 --> Router Class Initialized
INFO - 2024-03-20 12:07:58 --> Output Class Initialized
INFO - 2024-03-20 12:07:58 --> Security Class Initialized
DEBUG - 2024-03-20 12:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:07:58 --> Input Class Initialized
INFO - 2024-03-20 12:07:58 --> Language Class Initialized
INFO - 2024-03-20 12:07:58 --> Loader Class Initialized
INFO - 2024-03-20 12:07:58 --> Helper loaded: url_helper
INFO - 2024-03-20 12:07:58 --> Helper loaded: file_helper
INFO - 2024-03-20 12:07:58 --> Helper loaded: form_helper
INFO - 2024-03-20 12:07:58 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:07:58 --> Controller Class Initialized
INFO - 2024-03-20 12:07:58 --> Form Validation Class Initialized
INFO - 2024-03-20 12:07:58 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:07:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 12:07:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 12:07:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 12:07:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 12:07:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 12:07:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-03-20 12:07:58 --> Final output sent to browser
DEBUG - 2024-03-20 12:07:58 --> Total execution time: 0.0146
INFO - 2024-03-20 12:07:58 --> Config Class Initialized
INFO - 2024-03-20 12:07:58 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:07:58 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:07:58 --> Utf8 Class Initialized
INFO - 2024-03-20 12:07:58 --> URI Class Initialized
INFO - 2024-03-20 12:07:58 --> Router Class Initialized
INFO - 2024-03-20 12:07:58 --> Output Class Initialized
INFO - 2024-03-20 12:07:58 --> Security Class Initialized
DEBUG - 2024-03-20 12:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:07:58 --> Input Class Initialized
INFO - 2024-03-20 12:07:58 --> Language Class Initialized
INFO - 2024-03-20 12:07:58 --> Loader Class Initialized
INFO - 2024-03-20 12:07:58 --> Helper loaded: url_helper
INFO - 2024-03-20 12:07:58 --> Helper loaded: file_helper
INFO - 2024-03-20 12:07:58 --> Helper loaded: form_helper
INFO - 2024-03-20 12:07:58 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:07:58 --> Controller Class Initialized
INFO - 2024-03-20 12:07:58 --> Form Validation Class Initialized
INFO - 2024-03-20 12:07:58 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:07:58 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:00 --> Config Class Initialized
INFO - 2024-03-20 12:08:00 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:00 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:00 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:00 --> URI Class Initialized
INFO - 2024-03-20 12:08:00 --> Router Class Initialized
INFO - 2024-03-20 12:08:00 --> Output Class Initialized
INFO - 2024-03-20 12:08:00 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:00 --> Input Class Initialized
INFO - 2024-03-20 12:08:00 --> Language Class Initialized
INFO - 2024-03-20 12:08:00 --> Loader Class Initialized
INFO - 2024-03-20 12:08:00 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:00 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:00 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:00 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:00 --> Controller Class Initialized
INFO - 2024-03-20 12:08:00 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:00 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 12:08:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 12:08:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 12:08:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 12:08:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 12:08:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-20 12:08:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-20 12:08:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-20 12:08:00 --> Final output sent to browser
DEBUG - 2024-03-20 12:08:00 --> Total execution time: 0.0166
INFO - 2024-03-20 12:08:00 --> Config Class Initialized
INFO - 2024-03-20 12:08:00 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:00 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:00 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:00 --> URI Class Initialized
INFO - 2024-03-20 12:08:00 --> Router Class Initialized
INFO - 2024-03-20 12:08:00 --> Output Class Initialized
INFO - 2024-03-20 12:08:00 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:00 --> Input Class Initialized
INFO - 2024-03-20 12:08:00 --> Language Class Initialized
INFO - 2024-03-20 12:08:00 --> Loader Class Initialized
INFO - 2024-03-20 12:08:00 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:00 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:00 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:00 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:00 --> Controller Class Initialized
INFO - 2024-03-20 12:08:00 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:00 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:00 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:03 --> Config Class Initialized
INFO - 2024-03-20 12:08:03 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:03 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:03 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:03 --> URI Class Initialized
INFO - 2024-03-20 12:08:03 --> Router Class Initialized
INFO - 2024-03-20 12:08:03 --> Output Class Initialized
INFO - 2024-03-20 12:08:03 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:03 --> Input Class Initialized
INFO - 2024-03-20 12:08:03 --> Language Class Initialized
INFO - 2024-03-20 12:08:03 --> Loader Class Initialized
INFO - 2024-03-20 12:08:03 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:03 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:03 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:03 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:03 --> Controller Class Initialized
INFO - 2024-03-20 12:08:03 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:03 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:03 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:03 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:03 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:03 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:03 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:03 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:03 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:06 --> Config Class Initialized
INFO - 2024-03-20 12:08:06 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:06 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:06 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:06 --> URI Class Initialized
INFO - 2024-03-20 12:08:06 --> Router Class Initialized
INFO - 2024-03-20 12:08:06 --> Output Class Initialized
INFO - 2024-03-20 12:08:06 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:06 --> Input Class Initialized
INFO - 2024-03-20 12:08:06 --> Language Class Initialized
INFO - 2024-03-20 12:08:06 --> Loader Class Initialized
INFO - 2024-03-20 12:08:06 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:06 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:06 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:06 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:06 --> Controller Class Initialized
INFO - 2024-03-20 12:08:06 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:06 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:06 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:06 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:06 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:06 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:08 --> Config Class Initialized
INFO - 2024-03-20 12:08:08 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:08 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:08 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:08 --> URI Class Initialized
INFO - 2024-03-20 12:08:08 --> Router Class Initialized
INFO - 2024-03-20 12:08:08 --> Output Class Initialized
INFO - 2024-03-20 12:08:08 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:08 --> Input Class Initialized
INFO - 2024-03-20 12:08:08 --> Language Class Initialized
INFO - 2024-03-20 12:08:08 --> Loader Class Initialized
INFO - 2024-03-20 12:08:08 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:08 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:08 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:08 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:08 --> Controller Class Initialized
INFO - 2024-03-20 12:08:08 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:08 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:08 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:08 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:08 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:08 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:11 --> Config Class Initialized
INFO - 2024-03-20 12:08:11 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:11 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:11 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:11 --> URI Class Initialized
INFO - 2024-03-20 12:08:11 --> Router Class Initialized
INFO - 2024-03-20 12:08:11 --> Output Class Initialized
INFO - 2024-03-20 12:08:11 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:11 --> Input Class Initialized
INFO - 2024-03-20 12:08:11 --> Language Class Initialized
INFO - 2024-03-20 12:08:11 --> Loader Class Initialized
INFO - 2024-03-20 12:08:11 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:11 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:11 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:11 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:11 --> Controller Class Initialized
INFO - 2024-03-20 12:08:11 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:11 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:11 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:11 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:11 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:11 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:11 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:11 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:11 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:12 --> Config Class Initialized
INFO - 2024-03-20 12:08:12 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:12 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:12 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:12 --> URI Class Initialized
INFO - 2024-03-20 12:08:12 --> Router Class Initialized
INFO - 2024-03-20 12:08:12 --> Output Class Initialized
INFO - 2024-03-20 12:08:12 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:12 --> Input Class Initialized
INFO - 2024-03-20 12:08:12 --> Language Class Initialized
INFO - 2024-03-20 12:08:12 --> Loader Class Initialized
INFO - 2024-03-20 12:08:12 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:12 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:12 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:12 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:12 --> Controller Class Initialized
INFO - 2024-03-20 12:08:12 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:12 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:12 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:12 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:12 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:12 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:14 --> Config Class Initialized
INFO - 2024-03-20 12:08:14 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:14 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:14 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:14 --> URI Class Initialized
INFO - 2024-03-20 12:08:14 --> Router Class Initialized
INFO - 2024-03-20 12:08:14 --> Output Class Initialized
INFO - 2024-03-20 12:08:14 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:14 --> Input Class Initialized
INFO - 2024-03-20 12:08:14 --> Language Class Initialized
INFO - 2024-03-20 12:08:14 --> Loader Class Initialized
INFO - 2024-03-20 12:08:14 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:14 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:14 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:14 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:14 --> Controller Class Initialized
INFO - 2024-03-20 12:08:14 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:14 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:14 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:14 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:14 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:14 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:16 --> Config Class Initialized
INFO - 2024-03-20 12:08:16 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:16 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:16 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:16 --> URI Class Initialized
INFO - 2024-03-20 12:08:16 --> Router Class Initialized
INFO - 2024-03-20 12:08:16 --> Output Class Initialized
INFO - 2024-03-20 12:08:16 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:16 --> Input Class Initialized
INFO - 2024-03-20 12:08:16 --> Language Class Initialized
INFO - 2024-03-20 12:08:16 --> Loader Class Initialized
INFO - 2024-03-20 12:08:16 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:16 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:16 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:16 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:16 --> Controller Class Initialized
INFO - 2024-03-20 12:08:16 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:16 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:16 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:16 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:16 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:16 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:22 --> Config Class Initialized
INFO - 2024-03-20 12:08:22 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:22 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:22 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:22 --> URI Class Initialized
INFO - 2024-03-20 12:08:22 --> Router Class Initialized
INFO - 2024-03-20 12:08:22 --> Output Class Initialized
INFO - 2024-03-20 12:08:22 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:22 --> Input Class Initialized
INFO - 2024-03-20 12:08:22 --> Language Class Initialized
INFO - 2024-03-20 12:08:22 --> Loader Class Initialized
INFO - 2024-03-20 12:08:22 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:22 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:22 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:22 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:22 --> Controller Class Initialized
INFO - 2024-03-20 12:08:22 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:22 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:22 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:22 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:22 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:22 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:24 --> Config Class Initialized
INFO - 2024-03-20 12:08:24 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:24 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:24 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:24 --> URI Class Initialized
INFO - 2024-03-20 12:08:24 --> Router Class Initialized
INFO - 2024-03-20 12:08:24 --> Output Class Initialized
INFO - 2024-03-20 12:08:24 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:24 --> Input Class Initialized
INFO - 2024-03-20 12:08:24 --> Language Class Initialized
INFO - 2024-03-20 12:08:24 --> Loader Class Initialized
INFO - 2024-03-20 12:08:24 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:24 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:24 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:24 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:24 --> Controller Class Initialized
INFO - 2024-03-20 12:08:24 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:24 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:24 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:24 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:24 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:24 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:26 --> Config Class Initialized
INFO - 2024-03-20 12:08:26 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:26 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:26 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:26 --> URI Class Initialized
INFO - 2024-03-20 12:08:26 --> Router Class Initialized
INFO - 2024-03-20 12:08:26 --> Output Class Initialized
INFO - 2024-03-20 12:08:26 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:26 --> Input Class Initialized
INFO - 2024-03-20 12:08:26 --> Language Class Initialized
INFO - 2024-03-20 12:08:26 --> Loader Class Initialized
INFO - 2024-03-20 12:08:26 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:26 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:26 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:26 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:26 --> Controller Class Initialized
INFO - 2024-03-20 12:08:26 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:26 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:26 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:26 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:26 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:26 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:27 --> Config Class Initialized
INFO - 2024-03-20 12:08:27 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:27 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:27 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:27 --> URI Class Initialized
INFO - 2024-03-20 12:08:27 --> Router Class Initialized
INFO - 2024-03-20 12:08:27 --> Output Class Initialized
INFO - 2024-03-20 12:08:27 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:27 --> Input Class Initialized
INFO - 2024-03-20 12:08:27 --> Language Class Initialized
INFO - 2024-03-20 12:08:27 --> Loader Class Initialized
INFO - 2024-03-20 12:08:27 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:27 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:27 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:27 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:27 --> Controller Class Initialized
INFO - 2024-03-20 12:08:27 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:27 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:27 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:27 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:27 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:27 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:08:30 --> Config Class Initialized
INFO - 2024-03-20 12:08:30 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:08:30 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:08:30 --> Utf8 Class Initialized
INFO - 2024-03-20 12:08:30 --> URI Class Initialized
INFO - 2024-03-20 12:08:30 --> Router Class Initialized
INFO - 2024-03-20 12:08:30 --> Output Class Initialized
INFO - 2024-03-20 12:08:30 --> Security Class Initialized
DEBUG - 2024-03-20 12:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:08:30 --> Input Class Initialized
INFO - 2024-03-20 12:08:30 --> Language Class Initialized
INFO - 2024-03-20 12:08:30 --> Loader Class Initialized
INFO - 2024-03-20 12:08:30 --> Helper loaded: url_helper
INFO - 2024-03-20 12:08:30 --> Helper loaded: file_helper
INFO - 2024-03-20 12:08:30 --> Helper loaded: form_helper
INFO - 2024-03-20 12:08:30 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:08:30 --> Controller Class Initialized
INFO - 2024-03-20 12:08:30 --> Form Validation Class Initialized
INFO - 2024-03-20 12:08:30 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:08:30 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:08:30 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:08:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:08:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:08:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:08:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:08:30 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:08:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:08:30 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:16:17 --> Config Class Initialized
INFO - 2024-03-20 12:16:17 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:16:17 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:16:17 --> Utf8 Class Initialized
INFO - 2024-03-20 12:16:17 --> URI Class Initialized
INFO - 2024-03-20 12:16:17 --> Router Class Initialized
INFO - 2024-03-20 12:16:17 --> Output Class Initialized
INFO - 2024-03-20 12:16:17 --> Security Class Initialized
DEBUG - 2024-03-20 12:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:16:17 --> Input Class Initialized
INFO - 2024-03-20 12:16:17 --> Language Class Initialized
INFO - 2024-03-20 12:16:17 --> Loader Class Initialized
INFO - 2024-03-20 12:16:17 --> Helper loaded: url_helper
INFO - 2024-03-20 12:16:17 --> Helper loaded: file_helper
INFO - 2024-03-20 12:16:17 --> Helper loaded: form_helper
INFO - 2024-03-20 12:16:17 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:16:17 --> Controller Class Initialized
INFO - 2024-03-20 12:16:17 --> Form Validation Class Initialized
INFO - 2024-03-20 12:16:17 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:16:17 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:16:17 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:16:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:16:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:16:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:16:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:16:17 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:16:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:16:17 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-03-20 12:16:17 --> Final output sent to browser
DEBUG - 2024-03-20 12:16:17 --> Total execution time: 0.0171
INFO - 2024-03-20 12:18:39 --> Config Class Initialized
INFO - 2024-03-20 12:18:39 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:18:39 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:18:39 --> Utf8 Class Initialized
INFO - 2024-03-20 12:18:39 --> URI Class Initialized
INFO - 2024-03-20 12:18:39 --> Router Class Initialized
INFO - 2024-03-20 12:18:39 --> Output Class Initialized
INFO - 2024-03-20 12:18:39 --> Security Class Initialized
DEBUG - 2024-03-20 12:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:18:39 --> Input Class Initialized
INFO - 2024-03-20 12:18:39 --> Language Class Initialized
INFO - 2024-03-20 12:18:39 --> Loader Class Initialized
INFO - 2024-03-20 12:18:39 --> Helper loaded: url_helper
INFO - 2024-03-20 12:18:39 --> Helper loaded: file_helper
INFO - 2024-03-20 12:18:39 --> Helper loaded: form_helper
INFO - 2024-03-20 12:18:39 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:18:39 --> Controller Class Initialized
INFO - 2024-03-20 12:18:39 --> Form Validation Class Initialized
INFO - 2024-03-20 12:18:39 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:18:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 12:18:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 12:18:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 12:18:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 12:18:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 12:18:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 12:18:39 --> Final output sent to browser
DEBUG - 2024-03-20 12:18:39 --> Total execution time: 0.0218
INFO - 2024-03-20 12:18:39 --> Config Class Initialized
INFO - 2024-03-20 12:18:39 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:18:39 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:18:39 --> Utf8 Class Initialized
INFO - 2024-03-20 12:18:39 --> URI Class Initialized
INFO - 2024-03-20 12:18:39 --> Router Class Initialized
INFO - 2024-03-20 12:18:39 --> Output Class Initialized
INFO - 2024-03-20 12:18:39 --> Security Class Initialized
DEBUG - 2024-03-20 12:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:18:39 --> Input Class Initialized
INFO - 2024-03-20 12:18:39 --> Language Class Initialized
INFO - 2024-03-20 12:18:39 --> Loader Class Initialized
INFO - 2024-03-20 12:18:39 --> Helper loaded: url_helper
INFO - 2024-03-20 12:18:39 --> Helper loaded: file_helper
INFO - 2024-03-20 12:18:39 --> Helper loaded: form_helper
INFO - 2024-03-20 12:18:39 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:18:39 --> Controller Class Initialized
INFO - 2024-03-20 12:18:39 --> Form Validation Class Initialized
INFO - 2024-03-20 12:18:39 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:18:39 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:22:12 --> Config Class Initialized
INFO - 2024-03-20 12:22:12 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:22:12 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:22:12 --> Utf8 Class Initialized
INFO - 2024-03-20 12:22:12 --> URI Class Initialized
INFO - 2024-03-20 12:22:12 --> Router Class Initialized
INFO - 2024-03-20 12:22:12 --> Output Class Initialized
INFO - 2024-03-20 12:22:12 --> Security Class Initialized
DEBUG - 2024-03-20 12:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:22:12 --> Input Class Initialized
INFO - 2024-03-20 12:22:12 --> Language Class Initialized
INFO - 2024-03-20 12:22:12 --> Loader Class Initialized
INFO - 2024-03-20 12:22:12 --> Helper loaded: url_helper
INFO - 2024-03-20 12:22:12 --> Helper loaded: file_helper
INFO - 2024-03-20 12:22:12 --> Helper loaded: form_helper
INFO - 2024-03-20 12:22:12 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:22:12 --> Controller Class Initialized
INFO - 2024-03-20 12:22:12 --> Form Validation Class Initialized
INFO - 2024-03-20 12:22:12 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 12:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 12:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 12:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 12:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 12:22:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 12:22:12 --> Final output sent to browser
DEBUG - 2024-03-20 12:22:12 --> Total execution time: 0.0190
INFO - 2024-03-20 12:22:12 --> Config Class Initialized
INFO - 2024-03-20 12:22:12 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:22:12 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:22:12 --> Utf8 Class Initialized
INFO - 2024-03-20 12:22:12 --> URI Class Initialized
INFO - 2024-03-20 12:22:12 --> Router Class Initialized
INFO - 2024-03-20 12:22:12 --> Output Class Initialized
INFO - 2024-03-20 12:22:12 --> Security Class Initialized
DEBUG - 2024-03-20 12:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:22:12 --> Input Class Initialized
INFO - 2024-03-20 12:22:12 --> Language Class Initialized
INFO - 2024-03-20 12:22:12 --> Loader Class Initialized
INFO - 2024-03-20 12:22:12 --> Helper loaded: url_helper
INFO - 2024-03-20 12:22:12 --> Helper loaded: file_helper
INFO - 2024-03-20 12:22:12 --> Helper loaded: form_helper
INFO - 2024-03-20 12:22:12 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:22:12 --> Controller Class Initialized
INFO - 2024-03-20 12:22:12 --> Form Validation Class Initialized
INFO - 2024-03-20 12:22:12 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:22:12 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:22:28 --> Config Class Initialized
INFO - 2024-03-20 12:22:28 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:22:28 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:22:28 --> Utf8 Class Initialized
INFO - 2024-03-20 12:22:28 --> URI Class Initialized
INFO - 2024-03-20 12:22:28 --> Router Class Initialized
INFO - 2024-03-20 12:22:28 --> Output Class Initialized
INFO - 2024-03-20 12:22:28 --> Security Class Initialized
DEBUG - 2024-03-20 12:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:22:28 --> Input Class Initialized
INFO - 2024-03-20 12:22:28 --> Language Class Initialized
INFO - 2024-03-20 12:22:28 --> Loader Class Initialized
INFO - 2024-03-20 12:22:28 --> Helper loaded: url_helper
INFO - 2024-03-20 12:22:28 --> Helper loaded: file_helper
INFO - 2024-03-20 12:22:28 --> Helper loaded: form_helper
INFO - 2024-03-20 12:22:28 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:22:28 --> Controller Class Initialized
INFO - 2024-03-20 12:22:28 --> Form Validation Class Initialized
INFO - 2024-03-20 12:22:28 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:22:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 12:22:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 12:22:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 12:22:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 12:22:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 12:22:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 12:22:28 --> Final output sent to browser
DEBUG - 2024-03-20 12:22:28 --> Total execution time: 0.0168
INFO - 2024-03-20 12:22:28 --> Config Class Initialized
INFO - 2024-03-20 12:22:28 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:22:28 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:22:28 --> Utf8 Class Initialized
INFO - 2024-03-20 12:22:28 --> URI Class Initialized
INFO - 2024-03-20 12:22:28 --> Router Class Initialized
INFO - 2024-03-20 12:22:28 --> Output Class Initialized
INFO - 2024-03-20 12:22:28 --> Security Class Initialized
DEBUG - 2024-03-20 12:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:22:28 --> Input Class Initialized
INFO - 2024-03-20 12:22:28 --> Language Class Initialized
INFO - 2024-03-20 12:22:28 --> Loader Class Initialized
INFO - 2024-03-20 12:22:28 --> Helper loaded: url_helper
INFO - 2024-03-20 12:22:28 --> Helper loaded: file_helper
INFO - 2024-03-20 12:22:28 --> Helper loaded: form_helper
INFO - 2024-03-20 12:22:28 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:22:28 --> Controller Class Initialized
INFO - 2024-03-20 12:22:28 --> Form Validation Class Initialized
INFO - 2024-03-20 12:22:28 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:22:28 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:31:45 --> Config Class Initialized
INFO - 2024-03-20 12:31:45 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:31:45 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:31:45 --> Utf8 Class Initialized
INFO - 2024-03-20 12:31:45 --> URI Class Initialized
INFO - 2024-03-20 12:31:45 --> Router Class Initialized
INFO - 2024-03-20 12:31:45 --> Output Class Initialized
INFO - 2024-03-20 12:31:45 --> Security Class Initialized
DEBUG - 2024-03-20 12:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:31:45 --> Input Class Initialized
INFO - 2024-03-20 12:31:45 --> Language Class Initialized
INFO - 2024-03-20 12:31:45 --> Loader Class Initialized
INFO - 2024-03-20 12:31:45 --> Helper loaded: url_helper
INFO - 2024-03-20 12:31:45 --> Helper loaded: file_helper
INFO - 2024-03-20 12:31:45 --> Helper loaded: form_helper
INFO - 2024-03-20 12:31:45 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:31:45 --> Controller Class Initialized
INFO - 2024-03-20 12:31:46 --> Form Validation Class Initialized
INFO - 2024-03-20 12:31:46 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:31:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 12:31:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 12:31:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 12:31:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 12:31:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
ERROR - 2024-03-20 12:31:46 --> Severity: Notice --> Undefined variable: userList D:\xampp\htdocs\sscy\application\views\app\orders\print_form.php 25
ERROR - 2024-03-20 12:31:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\sscy\application\views\app\orders\print_form.php 25
INFO - 2024-03-20 12:31:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 12:31:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 12:31:46 --> Final output sent to browser
DEBUG - 2024-03-20 12:31:46 --> Total execution time: 0.0193
INFO - 2024-03-20 12:31:46 --> Config Class Initialized
INFO - 2024-03-20 12:31:46 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:31:46 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:31:46 --> Utf8 Class Initialized
INFO - 2024-03-20 12:31:46 --> URI Class Initialized
INFO - 2024-03-20 12:31:46 --> Router Class Initialized
INFO - 2024-03-20 12:31:46 --> Output Class Initialized
INFO - 2024-03-20 12:31:46 --> Security Class Initialized
DEBUG - 2024-03-20 12:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:31:46 --> Input Class Initialized
INFO - 2024-03-20 12:31:46 --> Language Class Initialized
INFO - 2024-03-20 12:31:46 --> Loader Class Initialized
INFO - 2024-03-20 12:31:46 --> Helper loaded: url_helper
INFO - 2024-03-20 12:31:46 --> Helper loaded: file_helper
INFO - 2024-03-20 12:31:46 --> Helper loaded: form_helper
INFO - 2024-03-20 12:31:46 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:31:46 --> Controller Class Initialized
INFO - 2024-03-20 12:31:46 --> Form Validation Class Initialized
INFO - 2024-03-20 12:31:46 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:31:46 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:32:29 --> Config Class Initialized
INFO - 2024-03-20 12:32:29 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:32:29 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:32:29 --> Utf8 Class Initialized
INFO - 2024-03-20 12:32:29 --> URI Class Initialized
INFO - 2024-03-20 12:32:29 --> Router Class Initialized
INFO - 2024-03-20 12:32:29 --> Output Class Initialized
INFO - 2024-03-20 12:32:29 --> Security Class Initialized
DEBUG - 2024-03-20 12:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:32:29 --> Input Class Initialized
INFO - 2024-03-20 12:32:29 --> Language Class Initialized
INFO - 2024-03-20 12:32:29 --> Loader Class Initialized
INFO - 2024-03-20 12:32:29 --> Helper loaded: url_helper
INFO - 2024-03-20 12:32:29 --> Helper loaded: file_helper
INFO - 2024-03-20 12:32:29 --> Helper loaded: form_helper
INFO - 2024-03-20 12:32:29 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:32:29 --> Controller Class Initialized
INFO - 2024-03-20 12:32:29 --> Form Validation Class Initialized
INFO - 2024-03-20 12:32:29 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:32:29 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:32:29 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:32:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:32:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:32:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:32:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:32:29 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:32:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:32:29 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:32:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 12:32:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 12:32:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 12:32:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 12:32:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
ERROR - 2024-03-20 12:32:29 --> Severity: Notice --> Undefined variable: userList D:\xampp\htdocs\sscy\application\views\app\orders\print_form.php 25
ERROR - 2024-03-20 12:32:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\sscy\application\views\app\orders\print_form.php 25
INFO - 2024-03-20 12:32:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 12:32:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 12:32:29 --> Final output sent to browser
DEBUG - 2024-03-20 12:32:29 --> Total execution time: 0.0206
INFO - 2024-03-20 12:32:53 --> Config Class Initialized
INFO - 2024-03-20 12:32:53 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:32:53 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:32:53 --> Utf8 Class Initialized
INFO - 2024-03-20 12:32:53 --> URI Class Initialized
INFO - 2024-03-20 12:32:53 --> Router Class Initialized
INFO - 2024-03-20 12:32:53 --> Output Class Initialized
INFO - 2024-03-20 12:32:53 --> Security Class Initialized
DEBUG - 2024-03-20 12:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:32:53 --> Input Class Initialized
INFO - 2024-03-20 12:32:53 --> Language Class Initialized
INFO - 2024-03-20 12:32:53 --> Loader Class Initialized
INFO - 2024-03-20 12:32:53 --> Helper loaded: url_helper
INFO - 2024-03-20 12:32:53 --> Helper loaded: file_helper
INFO - 2024-03-20 12:32:53 --> Helper loaded: form_helper
INFO - 2024-03-20 12:32:53 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:32:53 --> Controller Class Initialized
INFO - 2024-03-20 12:32:53 --> Form Validation Class Initialized
INFO - 2024-03-20 12:32:53 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:32:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 12:32:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 12:32:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 12:32:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 12:32:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 12:32:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 12:32:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 12:32:53 --> Final output sent to browser
DEBUG - 2024-03-20 12:32:53 --> Total execution time: 0.0196
INFO - 2024-03-20 12:32:53 --> Config Class Initialized
INFO - 2024-03-20 12:32:53 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:32:53 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:32:53 --> Utf8 Class Initialized
INFO - 2024-03-20 12:32:53 --> URI Class Initialized
INFO - 2024-03-20 12:32:53 --> Router Class Initialized
INFO - 2024-03-20 12:32:53 --> Output Class Initialized
INFO - 2024-03-20 12:32:53 --> Security Class Initialized
DEBUG - 2024-03-20 12:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:32:53 --> Input Class Initialized
INFO - 2024-03-20 12:32:53 --> Language Class Initialized
INFO - 2024-03-20 12:32:53 --> Loader Class Initialized
INFO - 2024-03-20 12:32:53 --> Helper loaded: url_helper
INFO - 2024-03-20 12:32:53 --> Helper loaded: file_helper
INFO - 2024-03-20 12:32:53 --> Helper loaded: form_helper
INFO - 2024-03-20 12:32:53 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:32:53 --> Controller Class Initialized
INFO - 2024-03-20 12:32:53 --> Form Validation Class Initialized
INFO - 2024-03-20 12:32:53 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:32:53 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:58:10 --> Config Class Initialized
INFO - 2024-03-20 12:58:10 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:58:10 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:58:10 --> Utf8 Class Initialized
INFO - 2024-03-20 12:58:10 --> URI Class Initialized
INFO - 2024-03-20 12:58:10 --> Router Class Initialized
INFO - 2024-03-20 12:58:10 --> Output Class Initialized
INFO - 2024-03-20 12:58:10 --> Security Class Initialized
DEBUG - 2024-03-20 12:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:58:10 --> Input Class Initialized
INFO - 2024-03-20 12:58:10 --> Language Class Initialized
INFO - 2024-03-20 12:58:10 --> Loader Class Initialized
INFO - 2024-03-20 12:58:10 --> Helper loaded: url_helper
INFO - 2024-03-20 12:58:10 --> Helper loaded: file_helper
INFO - 2024-03-20 12:58:10 --> Helper loaded: form_helper
INFO - 2024-03-20 12:58:10 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:58:10 --> Controller Class Initialized
INFO - 2024-03-20 12:58:10 --> Form Validation Class Initialized
INFO - 2024-03-20 12:58:10 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:58:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 12:58:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 12:58:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 12:58:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 12:58:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 12:58:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 12:58:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 12:58:10 --> Final output sent to browser
DEBUG - 2024-03-20 12:58:10 --> Total execution time: 0.0171
INFO - 2024-03-20 12:58:10 --> Config Class Initialized
INFO - 2024-03-20 12:58:10 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:58:10 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:58:10 --> Utf8 Class Initialized
INFO - 2024-03-20 12:58:10 --> URI Class Initialized
INFO - 2024-03-20 12:58:10 --> Router Class Initialized
INFO - 2024-03-20 12:58:10 --> Output Class Initialized
INFO - 2024-03-20 12:58:10 --> Security Class Initialized
DEBUG - 2024-03-20 12:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:58:10 --> Input Class Initialized
INFO - 2024-03-20 12:58:10 --> Language Class Initialized
INFO - 2024-03-20 12:58:10 --> Loader Class Initialized
INFO - 2024-03-20 12:58:10 --> Helper loaded: url_helper
INFO - 2024-03-20 12:58:10 --> Helper loaded: file_helper
INFO - 2024-03-20 12:58:10 --> Helper loaded: form_helper
INFO - 2024-03-20 12:58:10 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:58:10 --> Controller Class Initialized
INFO - 2024-03-20 12:58:10 --> Form Validation Class Initialized
INFO - 2024-03-20 12:58:10 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:58:10 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:58:15 --> Config Class Initialized
INFO - 2024-03-20 12:58:15 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:58:15 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:58:15 --> Utf8 Class Initialized
INFO - 2024-03-20 12:58:15 --> URI Class Initialized
INFO - 2024-03-20 12:58:15 --> Router Class Initialized
INFO - 2024-03-20 12:58:15 --> Output Class Initialized
INFO - 2024-03-20 12:58:15 --> Security Class Initialized
DEBUG - 2024-03-20 12:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:58:15 --> Input Class Initialized
INFO - 2024-03-20 12:58:15 --> Language Class Initialized
INFO - 2024-03-20 12:58:15 --> Loader Class Initialized
INFO - 2024-03-20 12:58:15 --> Helper loaded: url_helper
INFO - 2024-03-20 12:58:15 --> Helper loaded: file_helper
INFO - 2024-03-20 12:58:15 --> Helper loaded: form_helper
INFO - 2024-03-20 12:58:15 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:58:15 --> Controller Class Initialized
INFO - 2024-03-20 12:58:15 --> Form Validation Class Initialized
INFO - 2024-03-20 12:58:15 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:58:15 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:58:15 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:58:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:58:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:58:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:58:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:58:15 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:58:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:58:15 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:58:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 12:58:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 12:58:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 12:58:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 12:58:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 12:58:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 12:58:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 12:58:15 --> Final output sent to browser
DEBUG - 2024-03-20 12:58:15 --> Total execution time: 0.0246
INFO - 2024-03-20 12:58:24 --> Config Class Initialized
INFO - 2024-03-20 12:58:24 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:58:24 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:58:24 --> Utf8 Class Initialized
INFO - 2024-03-20 12:58:24 --> URI Class Initialized
INFO - 2024-03-20 12:58:24 --> Router Class Initialized
INFO - 2024-03-20 12:58:24 --> Output Class Initialized
INFO - 2024-03-20 12:58:24 --> Security Class Initialized
DEBUG - 2024-03-20 12:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:58:24 --> Input Class Initialized
INFO - 2024-03-20 12:58:24 --> Language Class Initialized
INFO - 2024-03-20 12:58:24 --> Loader Class Initialized
INFO - 2024-03-20 12:58:24 --> Helper loaded: url_helper
INFO - 2024-03-20 12:58:24 --> Helper loaded: file_helper
INFO - 2024-03-20 12:58:24 --> Helper loaded: form_helper
INFO - 2024-03-20 12:58:24 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:58:24 --> Controller Class Initialized
INFO - 2024-03-20 12:58:24 --> Form Validation Class Initialized
INFO - 2024-03-20 12:58:24 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:58:24 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:58:24 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:58:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:58:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:58:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:58:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:58:25 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:58:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:58:25 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:59:01 --> Config Class Initialized
INFO - 2024-03-20 12:59:01 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:59:01 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:59:01 --> Utf8 Class Initialized
INFO - 2024-03-20 12:59:01 --> URI Class Initialized
INFO - 2024-03-20 12:59:01 --> Router Class Initialized
INFO - 2024-03-20 12:59:01 --> Output Class Initialized
INFO - 2024-03-20 12:59:01 --> Security Class Initialized
DEBUG - 2024-03-20 12:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:59:01 --> Input Class Initialized
INFO - 2024-03-20 12:59:01 --> Language Class Initialized
INFO - 2024-03-20 12:59:01 --> Loader Class Initialized
INFO - 2024-03-20 12:59:01 --> Helper loaded: url_helper
INFO - 2024-03-20 12:59:01 --> Helper loaded: file_helper
INFO - 2024-03-20 12:59:01 --> Helper loaded: form_helper
INFO - 2024-03-20 12:59:01 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:59:01 --> Controller Class Initialized
INFO - 2024-03-20 12:59:01 --> Form Validation Class Initialized
INFO - 2024-03-20 12:59:01 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "ReportModel" initialized
INFO - 2024-03-20 12:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 12:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 12:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 12:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 12:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 12:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 12:59:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 12:59:01 --> Final output sent to browser
DEBUG - 2024-03-20 12:59:01 --> Total execution time: 0.0231
INFO - 2024-03-20 12:59:01 --> Config Class Initialized
INFO - 2024-03-20 12:59:01 --> Hooks Class Initialized
DEBUG - 2024-03-20 12:59:01 --> UTF-8 Support Enabled
INFO - 2024-03-20 12:59:01 --> Utf8 Class Initialized
INFO - 2024-03-20 12:59:01 --> URI Class Initialized
INFO - 2024-03-20 12:59:01 --> Router Class Initialized
INFO - 2024-03-20 12:59:01 --> Output Class Initialized
INFO - 2024-03-20 12:59:01 --> Security Class Initialized
DEBUG - 2024-03-20 12:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 12:59:01 --> Input Class Initialized
INFO - 2024-03-20 12:59:01 --> Language Class Initialized
INFO - 2024-03-20 12:59:01 --> Loader Class Initialized
INFO - 2024-03-20 12:59:01 --> Helper loaded: url_helper
INFO - 2024-03-20 12:59:01 --> Helper loaded: file_helper
INFO - 2024-03-20 12:59:01 --> Helper loaded: form_helper
INFO - 2024-03-20 12:59:01 --> Database Driver Class Initialized
DEBUG - 2024-03-20 12:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 12:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 12:59:01 --> Controller Class Initialized
INFO - 2024-03-20 12:59:01 --> Form Validation Class Initialized
INFO - 2024-03-20 12:59:01 --> Model "MasterModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "NotificationModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "DashboardModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "OrderModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 12:59:01 --> Model "ReportModel" initialized
INFO - 2024-03-20 15:46:37 --> Config Class Initialized
INFO - 2024-03-20 15:46:37 --> Hooks Class Initialized
DEBUG - 2024-03-20 15:46:37 --> UTF-8 Support Enabled
INFO - 2024-03-20 15:46:37 --> Utf8 Class Initialized
INFO - 2024-03-20 15:46:37 --> URI Class Initialized
INFO - 2024-03-20 15:46:37 --> Router Class Initialized
INFO - 2024-03-20 15:46:37 --> Output Class Initialized
INFO - 2024-03-20 15:46:37 --> Security Class Initialized
DEBUG - 2024-03-20 15:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 15:46:37 --> Input Class Initialized
INFO - 2024-03-20 15:46:37 --> Language Class Initialized
INFO - 2024-03-20 15:46:37 --> Loader Class Initialized
INFO - 2024-03-20 15:46:37 --> Helper loaded: url_helper
INFO - 2024-03-20 15:46:37 --> Helper loaded: file_helper
INFO - 2024-03-20 15:46:37 --> Helper loaded: form_helper
INFO - 2024-03-20 15:46:37 --> Database Driver Class Initialized
DEBUG - 2024-03-20 15:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 15:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 15:46:37 --> Controller Class Initialized
INFO - 2024-03-20 15:46:37 --> Form Validation Class Initialized
INFO - 2024-03-20 15:46:37 --> Model "MasterModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "NotificationModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "DashboardModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "OrderModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "ReportModel" initialized
INFO - 2024-03-20 15:46:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 15:46:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 15:46:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 15:46:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 15:46:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 15:46:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 15:46:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 15:46:37 --> Final output sent to browser
DEBUG - 2024-03-20 15:46:37 --> Total execution time: 0.0525
INFO - 2024-03-20 15:46:37 --> Config Class Initialized
INFO - 2024-03-20 15:46:37 --> Hooks Class Initialized
DEBUG - 2024-03-20 15:46:37 --> UTF-8 Support Enabled
INFO - 2024-03-20 15:46:37 --> Utf8 Class Initialized
INFO - 2024-03-20 15:46:37 --> URI Class Initialized
INFO - 2024-03-20 15:46:37 --> Router Class Initialized
INFO - 2024-03-20 15:46:37 --> Output Class Initialized
INFO - 2024-03-20 15:46:37 --> Security Class Initialized
DEBUG - 2024-03-20 15:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 15:46:37 --> Input Class Initialized
INFO - 2024-03-20 15:46:37 --> Language Class Initialized
INFO - 2024-03-20 15:46:37 --> Loader Class Initialized
INFO - 2024-03-20 15:46:37 --> Helper loaded: url_helper
INFO - 2024-03-20 15:46:37 --> Helper loaded: file_helper
INFO - 2024-03-20 15:46:37 --> Helper loaded: form_helper
INFO - 2024-03-20 15:46:37 --> Database Driver Class Initialized
DEBUG - 2024-03-20 15:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 15:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 15:46:37 --> Controller Class Initialized
INFO - 2024-03-20 15:46:37 --> Form Validation Class Initialized
INFO - 2024-03-20 15:46:37 --> Model "MasterModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "NotificationModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "DashboardModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "OrderModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 15:46:37 --> Model "ReportModel" initialized
INFO - 2024-03-20 15:46:41 --> Config Class Initialized
INFO - 2024-03-20 15:46:41 --> Hooks Class Initialized
DEBUG - 2024-03-20 15:46:41 --> UTF-8 Support Enabled
INFO - 2024-03-20 15:46:41 --> Utf8 Class Initialized
INFO - 2024-03-20 15:46:41 --> URI Class Initialized
INFO - 2024-03-20 15:46:41 --> Router Class Initialized
INFO - 2024-03-20 15:46:41 --> Output Class Initialized
INFO - 2024-03-20 15:46:41 --> Security Class Initialized
DEBUG - 2024-03-20 15:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 15:46:41 --> Input Class Initialized
INFO - 2024-03-20 15:46:41 --> Language Class Initialized
INFO - 2024-03-20 15:46:41 --> Loader Class Initialized
INFO - 2024-03-20 15:46:41 --> Helper loaded: url_helper
INFO - 2024-03-20 15:46:41 --> Helper loaded: file_helper
INFO - 2024-03-20 15:46:41 --> Helper loaded: form_helper
INFO - 2024-03-20 15:46:41 --> Database Driver Class Initialized
DEBUG - 2024-03-20 15:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 15:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 15:46:41 --> Controller Class Initialized
INFO - 2024-03-20 15:46:41 --> Form Validation Class Initialized
INFO - 2024-03-20 15:46:41 --> Model "MasterModel" initialized
INFO - 2024-03-20 15:46:41 --> Model "NotificationModel" initialized
INFO - 2024-03-20 15:46:41 --> Model "DashboardModel" initialized
INFO - 2024-03-20 15:46:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 15:46:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 15:46:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 15:46:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 15:46:41 --> Model "OrderModel" initialized
INFO - 2024-03-20 15:46:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 15:46:41 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:26:28 --> Config Class Initialized
INFO - 2024-03-20 16:26:28 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:26:28 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:26:28 --> Utf8 Class Initialized
INFO - 2024-03-20 16:26:28 --> URI Class Initialized
INFO - 2024-03-20 16:26:28 --> Router Class Initialized
INFO - 2024-03-20 16:26:28 --> Output Class Initialized
INFO - 2024-03-20 16:26:28 --> Security Class Initialized
DEBUG - 2024-03-20 16:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:26:28 --> Input Class Initialized
INFO - 2024-03-20 16:26:28 --> Language Class Initialized
INFO - 2024-03-20 16:26:28 --> Loader Class Initialized
INFO - 2024-03-20 16:26:28 --> Helper loaded: url_helper
INFO - 2024-03-20 16:26:28 --> Helper loaded: file_helper
INFO - 2024-03-20 16:26:28 --> Helper loaded: form_helper
INFO - 2024-03-20 16:26:28 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:26:28 --> Controller Class Initialized
INFO - 2024-03-20 16:26:28 --> Form Validation Class Initialized
INFO - 2024-03-20 16:26:28 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:26:28 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:26:28 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:26:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:26:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:26:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:26:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:26:28 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:26:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:26:28 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:26:37 --> Config Class Initialized
INFO - 2024-03-20 16:26:37 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:26:37 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:26:37 --> Utf8 Class Initialized
INFO - 2024-03-20 16:26:37 --> URI Class Initialized
INFO - 2024-03-20 16:26:37 --> Router Class Initialized
INFO - 2024-03-20 16:26:37 --> Output Class Initialized
INFO - 2024-03-20 16:26:37 --> Security Class Initialized
DEBUG - 2024-03-20 16:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:26:37 --> Input Class Initialized
INFO - 2024-03-20 16:26:37 --> Language Class Initialized
INFO - 2024-03-20 16:26:37 --> Loader Class Initialized
INFO - 2024-03-20 16:26:37 --> Helper loaded: url_helper
INFO - 2024-03-20 16:26:37 --> Helper loaded: file_helper
INFO - 2024-03-20 16:26:37 --> Helper loaded: form_helper
INFO - 2024-03-20 16:26:37 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:26:37 --> Controller Class Initialized
INFO - 2024-03-20 16:26:37 --> Form Validation Class Initialized
INFO - 2024-03-20 16:26:37 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:26:37 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:26:37 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:26:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:26:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:26:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:26:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:26:37 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:26:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:26:37 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:42:29 --> Config Class Initialized
INFO - 2024-03-20 16:42:29 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:42:29 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:42:29 --> Utf8 Class Initialized
INFO - 2024-03-20 16:42:29 --> URI Class Initialized
INFO - 2024-03-20 16:42:29 --> Router Class Initialized
INFO - 2024-03-20 16:42:29 --> Output Class Initialized
INFO - 2024-03-20 16:42:29 --> Security Class Initialized
DEBUG - 2024-03-20 16:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:42:29 --> Input Class Initialized
INFO - 2024-03-20 16:42:29 --> Language Class Initialized
INFO - 2024-03-20 16:42:29 --> Loader Class Initialized
INFO - 2024-03-20 16:42:29 --> Helper loaded: url_helper
INFO - 2024-03-20 16:42:29 --> Helper loaded: file_helper
INFO - 2024-03-20 16:42:29 --> Helper loaded: form_helper
INFO - 2024-03-20 16:42:29 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:42:29 --> Controller Class Initialized
INFO - 2024-03-20 16:42:29 --> Form Validation Class Initialized
INFO - 2024-03-20 16:42:29 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:42:29 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:42:29 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:42:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:42:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:42:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:42:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:42:29 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:42:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:42:29 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:42:34 --> Config Class Initialized
INFO - 2024-03-20 16:42:34 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:42:34 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:42:34 --> Utf8 Class Initialized
INFO - 2024-03-20 16:42:34 --> URI Class Initialized
INFO - 2024-03-20 16:42:34 --> Router Class Initialized
INFO - 2024-03-20 16:42:34 --> Output Class Initialized
INFO - 2024-03-20 16:42:34 --> Security Class Initialized
DEBUG - 2024-03-20 16:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:42:34 --> Input Class Initialized
INFO - 2024-03-20 16:42:34 --> Language Class Initialized
INFO - 2024-03-20 16:42:34 --> Loader Class Initialized
INFO - 2024-03-20 16:42:34 --> Helper loaded: url_helper
INFO - 2024-03-20 16:42:34 --> Helper loaded: file_helper
INFO - 2024-03-20 16:42:34 --> Helper loaded: form_helper
INFO - 2024-03-20 16:42:34 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:42:34 --> Controller Class Initialized
INFO - 2024-03-20 16:42:34 --> Form Validation Class Initialized
INFO - 2024-03-20 16:42:34 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:42:34 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:42:34 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:42:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:42:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:42:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:42:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:42:34 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:42:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:42:34 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:42:51 --> Config Class Initialized
INFO - 2024-03-20 16:42:51 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:42:51 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:42:51 --> Utf8 Class Initialized
INFO - 2024-03-20 16:42:51 --> URI Class Initialized
INFO - 2024-03-20 16:42:51 --> Router Class Initialized
INFO - 2024-03-20 16:42:51 --> Output Class Initialized
INFO - 2024-03-20 16:42:51 --> Security Class Initialized
DEBUG - 2024-03-20 16:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:42:51 --> Input Class Initialized
INFO - 2024-03-20 16:42:51 --> Language Class Initialized
INFO - 2024-03-20 16:42:51 --> Loader Class Initialized
INFO - 2024-03-20 16:42:51 --> Helper loaded: url_helper
INFO - 2024-03-20 16:42:51 --> Helper loaded: file_helper
INFO - 2024-03-20 16:42:51 --> Helper loaded: form_helper
INFO - 2024-03-20 16:42:51 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:42:51 --> Controller Class Initialized
INFO - 2024-03-20 16:42:51 --> Form Validation Class Initialized
INFO - 2024-03-20 16:42:51 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:42:51 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:42:51 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:42:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:42:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:42:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:42:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:42:51 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:42:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:42:51 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:47:21 --> Config Class Initialized
INFO - 2024-03-20 16:47:21 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:47:21 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:47:21 --> Utf8 Class Initialized
INFO - 2024-03-20 16:47:21 --> URI Class Initialized
INFO - 2024-03-20 16:47:21 --> Router Class Initialized
INFO - 2024-03-20 16:47:21 --> Output Class Initialized
INFO - 2024-03-20 16:47:21 --> Security Class Initialized
DEBUG - 2024-03-20 16:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:47:21 --> Input Class Initialized
INFO - 2024-03-20 16:47:21 --> Language Class Initialized
INFO - 2024-03-20 16:47:21 --> Loader Class Initialized
INFO - 2024-03-20 16:47:21 --> Helper loaded: url_helper
INFO - 2024-03-20 16:47:21 --> Helper loaded: file_helper
INFO - 2024-03-20 16:47:21 --> Helper loaded: form_helper
INFO - 2024-03-20 16:47:21 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:47:21 --> Controller Class Initialized
INFO - 2024-03-20 16:47:21 --> Form Validation Class Initialized
INFO - 2024-03-20 16:47:21 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:47:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 16:47:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 16:47:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 16:47:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 16:47:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 16:47:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 16:47:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 16:47:21 --> Final output sent to browser
DEBUG - 2024-03-20 16:47:21 --> Total execution time: 0.0341
INFO - 2024-03-20 16:47:21 --> Config Class Initialized
INFO - 2024-03-20 16:47:21 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:47:21 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:47:21 --> Utf8 Class Initialized
INFO - 2024-03-20 16:47:21 --> URI Class Initialized
INFO - 2024-03-20 16:47:21 --> Router Class Initialized
INFO - 2024-03-20 16:47:21 --> Output Class Initialized
INFO - 2024-03-20 16:47:21 --> Security Class Initialized
DEBUG - 2024-03-20 16:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:47:21 --> Input Class Initialized
INFO - 2024-03-20 16:47:21 --> Language Class Initialized
INFO - 2024-03-20 16:47:21 --> Loader Class Initialized
INFO - 2024-03-20 16:47:21 --> Helper loaded: url_helper
INFO - 2024-03-20 16:47:21 --> Helper loaded: file_helper
INFO - 2024-03-20 16:47:21 --> Helper loaded: form_helper
INFO - 2024-03-20 16:47:21 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:47:21 --> Controller Class Initialized
INFO - 2024-03-20 16:47:21 --> Form Validation Class Initialized
INFO - 2024-03-20 16:47:21 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:47:21 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:47:38 --> Config Class Initialized
INFO - 2024-03-20 16:47:38 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:47:38 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:47:38 --> Utf8 Class Initialized
INFO - 2024-03-20 16:47:38 --> URI Class Initialized
INFO - 2024-03-20 16:47:38 --> Router Class Initialized
INFO - 2024-03-20 16:47:38 --> Output Class Initialized
INFO - 2024-03-20 16:47:38 --> Security Class Initialized
DEBUG - 2024-03-20 16:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:47:38 --> Input Class Initialized
INFO - 2024-03-20 16:47:38 --> Language Class Initialized
INFO - 2024-03-20 16:47:38 --> Loader Class Initialized
INFO - 2024-03-20 16:47:38 --> Helper loaded: url_helper
INFO - 2024-03-20 16:47:38 --> Helper loaded: file_helper
INFO - 2024-03-20 16:47:38 --> Helper loaded: form_helper
INFO - 2024-03-20 16:47:38 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:47:38 --> Controller Class Initialized
INFO - 2024-03-20 16:47:38 --> Form Validation Class Initialized
INFO - 2024-03-20 16:47:38 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:47:38 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:47:38 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:47:38 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:47:38 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:47:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:47:38 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:47:38 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:47:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:47:38 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:47:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 16:47:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 16:47:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 16:47:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 16:47:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 16:47:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 16:47:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 16:47:38 --> Final output sent to browser
DEBUG - 2024-03-20 16:47:38 --> Total execution time: 0.0686
INFO - 2024-03-20 16:47:42 --> Config Class Initialized
INFO - 2024-03-20 16:47:42 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:47:42 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:47:42 --> Utf8 Class Initialized
INFO - 2024-03-20 16:47:42 --> URI Class Initialized
INFO - 2024-03-20 16:47:42 --> Router Class Initialized
INFO - 2024-03-20 16:47:42 --> Output Class Initialized
INFO - 2024-03-20 16:47:42 --> Security Class Initialized
DEBUG - 2024-03-20 16:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:47:42 --> Input Class Initialized
INFO - 2024-03-20 16:47:42 --> Language Class Initialized
INFO - 2024-03-20 16:47:42 --> Loader Class Initialized
INFO - 2024-03-20 16:47:42 --> Helper loaded: url_helper
INFO - 2024-03-20 16:47:42 --> Helper loaded: file_helper
INFO - 2024-03-20 16:47:42 --> Helper loaded: form_helper
INFO - 2024-03-20 16:47:42 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:47:42 --> Controller Class Initialized
INFO - 2024-03-20 16:47:42 --> Form Validation Class Initialized
INFO - 2024-03-20 16:47:42 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:47:42 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:47:42 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:47:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:47:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:47:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:47:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:47:42 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:47:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:47:42 --> Model "ReportModel" initialized
ERROR - 2024-03-20 16:47:42 --> Severity: error --> Exception: Call to undefined function formatDate() D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 15
INFO - 2024-03-20 16:48:14 --> Config Class Initialized
INFO - 2024-03-20 16:48:14 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:48:14 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:48:14 --> Utf8 Class Initialized
INFO - 2024-03-20 16:48:14 --> URI Class Initialized
INFO - 2024-03-20 16:48:14 --> Router Class Initialized
INFO - 2024-03-20 16:48:14 --> Output Class Initialized
INFO - 2024-03-20 16:48:14 --> Security Class Initialized
DEBUG - 2024-03-20 16:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:48:14 --> Input Class Initialized
INFO - 2024-03-20 16:48:14 --> Language Class Initialized
INFO - 2024-03-20 16:48:14 --> Loader Class Initialized
INFO - 2024-03-20 16:48:14 --> Helper loaded: url_helper
INFO - 2024-03-20 16:48:14 --> Helper loaded: file_helper
INFO - 2024-03-20 16:48:14 --> Helper loaded: form_helper
INFO - 2024-03-20 16:48:14 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:48:14 --> Controller Class Initialized
INFO - 2024-03-20 16:48:14 --> Form Validation Class Initialized
INFO - 2024-03-20 16:48:14 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:48:14 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:48:14 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:48:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:48:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:48:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:48:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:48:14 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:48:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:48:14 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:48:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 16:49:10 --> Config Class Initialized
INFO - 2024-03-20 16:49:10 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:49:10 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:49:10 --> Utf8 Class Initialized
INFO - 2024-03-20 16:49:10 --> URI Class Initialized
INFO - 2024-03-20 16:49:10 --> Router Class Initialized
INFO - 2024-03-20 16:49:10 --> Output Class Initialized
INFO - 2024-03-20 16:49:10 --> Security Class Initialized
DEBUG - 2024-03-20 16:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:49:10 --> Input Class Initialized
INFO - 2024-03-20 16:49:10 --> Language Class Initialized
INFO - 2024-03-20 16:49:10 --> Loader Class Initialized
INFO - 2024-03-20 16:49:10 --> Helper loaded: url_helper
INFO - 2024-03-20 16:49:10 --> Helper loaded: file_helper
INFO - 2024-03-20 16:49:10 --> Helper loaded: form_helper
INFO - 2024-03-20 16:49:10 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:49:10 --> Controller Class Initialized
INFO - 2024-03-20 16:49:10 --> Form Validation Class Initialized
INFO - 2024-03-20 16:49:10 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:49:10 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:49:10 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:49:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:49:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:49:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:49:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:49:10 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:49:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:49:10 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:49:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 16:58:08 --> Config Class Initialized
INFO - 2024-03-20 16:58:08 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:58:08 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:58:08 --> Utf8 Class Initialized
INFO - 2024-03-20 16:58:08 --> URI Class Initialized
INFO - 2024-03-20 16:58:08 --> Router Class Initialized
INFO - 2024-03-20 16:58:08 --> Output Class Initialized
INFO - 2024-03-20 16:58:08 --> Security Class Initialized
DEBUG - 2024-03-20 16:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:58:08 --> Input Class Initialized
INFO - 2024-03-20 16:58:08 --> Language Class Initialized
INFO - 2024-03-20 16:58:08 --> Loader Class Initialized
INFO - 2024-03-20 16:58:08 --> Helper loaded: url_helper
INFO - 2024-03-20 16:58:08 --> Helper loaded: file_helper
INFO - 2024-03-20 16:58:08 --> Helper loaded: form_helper
INFO - 2024-03-20 16:58:08 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:58:08 --> Controller Class Initialized
INFO - 2024-03-20 16:58:08 --> Form Validation Class Initialized
INFO - 2024-03-20 16:58:08 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:58:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 16:58:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 16:58:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 16:58:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 16:58:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 16:58:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 16:58:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 16:58:08 --> Final output sent to browser
DEBUG - 2024-03-20 16:58:08 --> Total execution time: 0.0483
INFO - 2024-03-20 16:58:08 --> Config Class Initialized
INFO - 2024-03-20 16:58:08 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:58:08 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:58:08 --> Utf8 Class Initialized
INFO - 2024-03-20 16:58:08 --> URI Class Initialized
INFO - 2024-03-20 16:58:08 --> Router Class Initialized
INFO - 2024-03-20 16:58:08 --> Output Class Initialized
INFO - 2024-03-20 16:58:08 --> Security Class Initialized
DEBUG - 2024-03-20 16:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:58:08 --> Input Class Initialized
INFO - 2024-03-20 16:58:08 --> Language Class Initialized
INFO - 2024-03-20 16:58:08 --> Loader Class Initialized
INFO - 2024-03-20 16:58:08 --> Helper loaded: url_helper
INFO - 2024-03-20 16:58:08 --> Helper loaded: file_helper
INFO - 2024-03-20 16:58:08 --> Helper loaded: form_helper
INFO - 2024-03-20 16:58:08 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:58:08 --> Controller Class Initialized
INFO - 2024-03-20 16:58:08 --> Form Validation Class Initialized
INFO - 2024-03-20 16:58:08 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:58:08 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:58:48 --> Config Class Initialized
INFO - 2024-03-20 16:58:48 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:58:48 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:58:48 --> Utf8 Class Initialized
INFO - 2024-03-20 16:58:48 --> URI Class Initialized
INFO - 2024-03-20 16:58:48 --> Router Class Initialized
INFO - 2024-03-20 16:58:48 --> Output Class Initialized
INFO - 2024-03-20 16:58:48 --> Security Class Initialized
DEBUG - 2024-03-20 16:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:58:48 --> Input Class Initialized
INFO - 2024-03-20 16:58:48 --> Language Class Initialized
INFO - 2024-03-20 16:58:48 --> Loader Class Initialized
INFO - 2024-03-20 16:58:48 --> Helper loaded: url_helper
INFO - 2024-03-20 16:58:48 --> Helper loaded: file_helper
INFO - 2024-03-20 16:58:48 --> Helper loaded: form_helper
INFO - 2024-03-20 16:58:48 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:58:48 --> Controller Class Initialized
INFO - 2024-03-20 16:58:48 --> Form Validation Class Initialized
INFO - 2024-03-20 16:58:48 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:58:48 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:58:48 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:58:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:58:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:58:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:58:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:58:48 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:58:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:58:48 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:58:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 16:58:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 16:58:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 16:58:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 16:58:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 16:58:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 16:58:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 16:58:48 --> Final output sent to browser
DEBUG - 2024-03-20 16:58:48 --> Total execution time: 0.0389
INFO - 2024-03-20 16:58:49 --> Config Class Initialized
INFO - 2024-03-20 16:58:49 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:58:49 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:58:49 --> Utf8 Class Initialized
INFO - 2024-03-20 16:58:49 --> URI Class Initialized
INFO - 2024-03-20 16:58:49 --> Router Class Initialized
INFO - 2024-03-20 16:58:49 --> Output Class Initialized
INFO - 2024-03-20 16:58:49 --> Security Class Initialized
DEBUG - 2024-03-20 16:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:58:49 --> Input Class Initialized
INFO - 2024-03-20 16:58:49 --> Language Class Initialized
INFO - 2024-03-20 16:58:49 --> Loader Class Initialized
INFO - 2024-03-20 16:58:49 --> Helper loaded: url_helper
INFO - 2024-03-20 16:58:49 --> Helper loaded: file_helper
INFO - 2024-03-20 16:58:49 --> Helper loaded: form_helper
INFO - 2024-03-20 16:58:49 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:58:49 --> Controller Class Initialized
INFO - 2024-03-20 16:58:49 --> Form Validation Class Initialized
INFO - 2024-03-20 16:58:49 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:58:49 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:58:49 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:58:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:58:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:58:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:58:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:58:49 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:58:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:58:49 --> Model "ReportModel" initialized
INFO - 2024-03-20 16:58:58 --> Config Class Initialized
INFO - 2024-03-20 16:58:58 --> Hooks Class Initialized
DEBUG - 2024-03-20 16:58:58 --> UTF-8 Support Enabled
INFO - 2024-03-20 16:58:58 --> Utf8 Class Initialized
INFO - 2024-03-20 16:58:58 --> URI Class Initialized
INFO - 2024-03-20 16:58:58 --> Router Class Initialized
INFO - 2024-03-20 16:58:58 --> Output Class Initialized
INFO - 2024-03-20 16:58:58 --> Security Class Initialized
DEBUG - 2024-03-20 16:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 16:58:58 --> Input Class Initialized
INFO - 2024-03-20 16:58:58 --> Language Class Initialized
INFO - 2024-03-20 16:58:58 --> Loader Class Initialized
INFO - 2024-03-20 16:58:58 --> Helper loaded: url_helper
INFO - 2024-03-20 16:58:58 --> Helper loaded: file_helper
INFO - 2024-03-20 16:58:58 --> Helper loaded: form_helper
INFO - 2024-03-20 16:58:58 --> Database Driver Class Initialized
DEBUG - 2024-03-20 16:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 16:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 16:58:58 --> Controller Class Initialized
INFO - 2024-03-20 16:58:58 --> Form Validation Class Initialized
INFO - 2024-03-20 16:58:58 --> Model "MasterModel" initialized
INFO - 2024-03-20 16:58:58 --> Model "NotificationModel" initialized
INFO - 2024-03-20 16:58:58 --> Model "DashboardModel" initialized
INFO - 2024-03-20 16:58:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 16:58:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 16:58:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 16:58:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 16:58:58 --> Model "OrderModel" initialized
INFO - 2024-03-20 16:58:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 16:58:58 --> Model "ReportModel" initialized
ERROR - 2024-03-20 16:58:58 --> Severity: error --> Exception: Call to undefined function decodeURL() D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 116
INFO - 2024-03-20 17:06:34 --> Config Class Initialized
INFO - 2024-03-20 17:06:34 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:06:34 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:06:34 --> Utf8 Class Initialized
INFO - 2024-03-20 17:06:34 --> URI Class Initialized
INFO - 2024-03-20 17:06:34 --> Router Class Initialized
INFO - 2024-03-20 17:06:34 --> Output Class Initialized
INFO - 2024-03-20 17:06:34 --> Security Class Initialized
DEBUG - 2024-03-20 17:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:06:34 --> Input Class Initialized
INFO - 2024-03-20 17:06:34 --> Language Class Initialized
INFO - 2024-03-20 17:06:34 --> Loader Class Initialized
INFO - 2024-03-20 17:06:34 --> Helper loaded: url_helper
INFO - 2024-03-20 17:06:34 --> Helper loaded: file_helper
INFO - 2024-03-20 17:06:34 --> Helper loaded: form_helper
INFO - 2024-03-20 17:06:34 --> Helper loaded: general_helper
INFO - 2024-03-20 17:06:34 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:06:34 --> Controller Class Initialized
INFO - 2024-03-20 17:06:34 --> Form Validation Class Initialized
INFO - 2024-03-20 17:06:34 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:06:34 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:06:34 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:06:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:06:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:06:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:06:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:06:34 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:06:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:06:34 --> Model "ReportModel" initialized
INFO - 2024-03-20 17:06:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 17:06:34 --> Final output sent to browser
DEBUG - 2024-03-20 17:06:34 --> Total execution time: 0.4418
INFO - 2024-03-20 17:06:39 --> Config Class Initialized
INFO - 2024-03-20 17:06:39 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:06:39 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:06:39 --> Utf8 Class Initialized
INFO - 2024-03-20 17:06:39 --> URI Class Initialized
INFO - 2024-03-20 17:06:39 --> Router Class Initialized
INFO - 2024-03-20 17:06:39 --> Output Class Initialized
INFO - 2024-03-20 17:06:39 --> Security Class Initialized
DEBUG - 2024-03-20 17:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:06:39 --> Input Class Initialized
INFO - 2024-03-20 17:06:39 --> Language Class Initialized
INFO - 2024-03-20 17:06:39 --> Loader Class Initialized
INFO - 2024-03-20 17:06:39 --> Helper loaded: url_helper
INFO - 2024-03-20 17:06:39 --> Helper loaded: file_helper
INFO - 2024-03-20 17:06:39 --> Helper loaded: form_helper
INFO - 2024-03-20 17:06:39 --> Helper loaded: general_helper
INFO - 2024-03-20 17:06:39 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:06:39 --> Controller Class Initialized
INFO - 2024-03-20 17:06:39 --> Form Validation Class Initialized
INFO - 2024-03-20 17:06:39 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:06:39 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:06:39 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:06:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:06:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:06:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:06:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:06:39 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:06:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:06:39 --> Model "ReportModel" initialized
INFO - 2024-03-20 17:06:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 17:06:39 --> Final output sent to browser
DEBUG - 2024-03-20 17:06:39 --> Total execution time: 0.4537
INFO - 2024-03-20 17:06:40 --> Config Class Initialized
INFO - 2024-03-20 17:06:40 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:06:40 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:06:40 --> Utf8 Class Initialized
INFO - 2024-03-20 17:06:40 --> URI Class Initialized
INFO - 2024-03-20 17:06:40 --> Router Class Initialized
INFO - 2024-03-20 17:06:40 --> Output Class Initialized
INFO - 2024-03-20 17:06:40 --> Security Class Initialized
DEBUG - 2024-03-20 17:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:06:40 --> Input Class Initialized
INFO - 2024-03-20 17:06:40 --> Language Class Initialized
INFO - 2024-03-20 17:06:40 --> Loader Class Initialized
INFO - 2024-03-20 17:06:40 --> Helper loaded: url_helper
INFO - 2024-03-20 17:06:40 --> Helper loaded: file_helper
INFO - 2024-03-20 17:06:40 --> Helper loaded: form_helper
INFO - 2024-03-20 17:06:40 --> Helper loaded: general_helper
INFO - 2024-03-20 17:06:40 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:06:40 --> Controller Class Initialized
INFO - 2024-03-20 17:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-03-20 17:06:40 --> Final output sent to browser
DEBUG - 2024-03-20 17:06:40 --> Total execution time: 0.0484
INFO - 2024-03-20 17:06:40 --> Config Class Initialized
INFO - 2024-03-20 17:06:40 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:06:40 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:06:40 --> Utf8 Class Initialized
INFO - 2024-03-20 17:06:40 --> URI Class Initialized
INFO - 2024-03-20 17:06:40 --> Router Class Initialized
INFO - 2024-03-20 17:06:40 --> Output Class Initialized
INFO - 2024-03-20 17:06:40 --> Security Class Initialized
DEBUG - 2024-03-20 17:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:06:40 --> Input Class Initialized
INFO - 2024-03-20 17:06:40 --> Language Class Initialized
INFO - 2024-03-20 17:06:40 --> Loader Class Initialized
INFO - 2024-03-20 17:06:40 --> Helper loaded: url_helper
INFO - 2024-03-20 17:06:40 --> Helper loaded: file_helper
INFO - 2024-03-20 17:06:40 --> Helper loaded: form_helper
INFO - 2024-03-20 17:06:40 --> Helper loaded: general_helper
INFO - 2024-03-20 17:06:40 --> Config Class Initialized
INFO - 2024-03-20 17:06:40 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:06:40 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:06:40 --> Utf8 Class Initialized
INFO - 2024-03-20 17:06:40 --> Database Driver Class Initialized
INFO - 2024-03-20 17:06:40 --> URI Class Initialized
DEBUG - 2024-03-20 17:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:06:40 --> Router Class Initialized
INFO - 2024-03-20 17:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:06:40 --> Controller Class Initialized
INFO - 2024-03-20 17:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-03-20 17:06:40 --> Final output sent to browser
DEBUG - 2024-03-20 17:06:40 --> Total execution time: 0.0251
INFO - 2024-03-20 17:06:40 --> Output Class Initialized
INFO - 2024-03-20 17:06:40 --> Security Class Initialized
DEBUG - 2024-03-20 17:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:06:40 --> Input Class Initialized
INFO - 2024-03-20 17:06:40 --> Language Class Initialized
INFO - 2024-03-20 17:06:40 --> Loader Class Initialized
INFO - 2024-03-20 17:06:40 --> Helper loaded: url_helper
INFO - 2024-03-20 17:06:40 --> Helper loaded: file_helper
INFO - 2024-03-20 17:06:40 --> Helper loaded: form_helper
INFO - 2024-03-20 17:06:40 --> Helper loaded: general_helper
INFO - 2024-03-20 17:06:40 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:06:40 --> Controller Class Initialized
INFO - 2024-03-20 17:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-03-20 17:06:40 --> Final output sent to browser
DEBUG - 2024-03-20 17:06:40 --> Total execution time: 0.0305
INFO - 2024-03-20 17:07:32 --> Config Class Initialized
INFO - 2024-03-20 17:07:32 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:07:32 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:07:32 --> Utf8 Class Initialized
INFO - 2024-03-20 17:07:32 --> URI Class Initialized
INFO - 2024-03-20 17:07:32 --> Router Class Initialized
INFO - 2024-03-20 17:07:32 --> Output Class Initialized
INFO - 2024-03-20 17:07:32 --> Security Class Initialized
DEBUG - 2024-03-20 17:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:07:32 --> Input Class Initialized
INFO - 2024-03-20 17:07:32 --> Language Class Initialized
INFO - 2024-03-20 17:07:32 --> Loader Class Initialized
INFO - 2024-03-20 17:07:32 --> Helper loaded: url_helper
INFO - 2024-03-20 17:07:32 --> Helper loaded: file_helper
INFO - 2024-03-20 17:07:32 --> Helper loaded: form_helper
INFO - 2024-03-20 17:07:32 --> Helper loaded: general_helper
INFO - 2024-03-20 17:07:32 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:07:32 --> Controller Class Initialized
INFO - 2024-03-20 17:07:32 --> Form Validation Class Initialized
INFO - 2024-03-20 17:07:32 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "ReportModel" initialized
INFO - 2024-03-20 17:07:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 17:07:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 17:07:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 17:07:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 17:07:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 17:07:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 17:07:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 17:07:32 --> Final output sent to browser
DEBUG - 2024-03-20 17:07:32 --> Total execution time: 0.0384
INFO - 2024-03-20 17:07:32 --> Config Class Initialized
INFO - 2024-03-20 17:07:32 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:07:32 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:07:32 --> Utf8 Class Initialized
INFO - 2024-03-20 17:07:32 --> URI Class Initialized
INFO - 2024-03-20 17:07:32 --> Router Class Initialized
INFO - 2024-03-20 17:07:32 --> Output Class Initialized
INFO - 2024-03-20 17:07:32 --> Security Class Initialized
DEBUG - 2024-03-20 17:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:07:32 --> Input Class Initialized
INFO - 2024-03-20 17:07:32 --> Language Class Initialized
INFO - 2024-03-20 17:07:32 --> Loader Class Initialized
INFO - 2024-03-20 17:07:32 --> Helper loaded: url_helper
INFO - 2024-03-20 17:07:32 --> Helper loaded: file_helper
INFO - 2024-03-20 17:07:32 --> Helper loaded: form_helper
INFO - 2024-03-20 17:07:32 --> Helper loaded: general_helper
INFO - 2024-03-20 17:07:32 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:07:32 --> Controller Class Initialized
INFO - 2024-03-20 17:07:32 --> Form Validation Class Initialized
INFO - 2024-03-20 17:07:32 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:07:32 --> Model "ReportModel" initialized
INFO - 2024-03-20 17:07:46 --> Config Class Initialized
INFO - 2024-03-20 17:07:46 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:07:46 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:07:46 --> Utf8 Class Initialized
INFO - 2024-03-20 17:07:46 --> URI Class Initialized
INFO - 2024-03-20 17:07:46 --> Router Class Initialized
INFO - 2024-03-20 17:07:46 --> Output Class Initialized
INFO - 2024-03-20 17:07:46 --> Security Class Initialized
DEBUG - 2024-03-20 17:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:07:46 --> Input Class Initialized
INFO - 2024-03-20 17:07:46 --> Language Class Initialized
INFO - 2024-03-20 17:07:46 --> Loader Class Initialized
INFO - 2024-03-20 17:07:46 --> Helper loaded: url_helper
INFO - 2024-03-20 17:07:46 --> Helper loaded: file_helper
INFO - 2024-03-20 17:07:46 --> Helper loaded: form_helper
INFO - 2024-03-20 17:07:46 --> Helper loaded: general_helper
INFO - 2024-03-20 17:07:46 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:07:46 --> Controller Class Initialized
INFO - 2024-03-20 17:07:46 --> Form Validation Class Initialized
INFO - 2024-03-20 17:07:46 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:07:46 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:07:46 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:07:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:07:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:07:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:07:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:07:46 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:07:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:07:46 --> Model "ReportModel" initialized
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:07:46 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
INFO - 2024-03-20 17:07:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 17:07:46 --> Config Class Initialized
INFO - 2024-03-20 17:07:46 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:07:46 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:07:46 --> Utf8 Class Initialized
INFO - 2024-03-20 17:07:46 --> URI Class Initialized
INFO - 2024-03-20 17:07:46 --> Router Class Initialized
INFO - 2024-03-20 17:07:46 --> Output Class Initialized
INFO - 2024-03-20 17:07:46 --> Security Class Initialized
DEBUG - 2024-03-20 17:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:07:46 --> Input Class Initialized
INFO - 2024-03-20 17:07:46 --> Language Class Initialized
INFO - 2024-03-20 17:07:46 --> Loader Class Initialized
INFO - 2024-03-20 17:07:46 --> Helper loaded: url_helper
INFO - 2024-03-20 17:07:46 --> Helper loaded: file_helper
INFO - 2024-03-20 17:07:46 --> Helper loaded: form_helper
INFO - 2024-03-20 17:07:46 --> Helper loaded: general_helper
INFO - 2024-03-20 17:07:46 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:07:46 --> Controller Class Initialized
INFO - 2024-03-20 17:07:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-03-20 17:07:46 --> Final output sent to browser
DEBUG - 2024-03-20 17:07:46 --> Total execution time: 0.0220
INFO - 2024-03-20 17:07:48 --> Final output sent to browser
DEBUG - 2024-03-20 17:07:48 --> Total execution time: 2.1747
INFO - 2024-03-20 17:08:48 --> Config Class Initialized
INFO - 2024-03-20 17:08:48 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:08:48 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:08:48 --> Utf8 Class Initialized
INFO - 2024-03-20 17:08:48 --> URI Class Initialized
INFO - 2024-03-20 17:08:48 --> Router Class Initialized
INFO - 2024-03-20 17:08:48 --> Output Class Initialized
INFO - 2024-03-20 17:08:48 --> Security Class Initialized
DEBUG - 2024-03-20 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:08:48 --> Input Class Initialized
INFO - 2024-03-20 17:08:48 --> Language Class Initialized
INFO - 2024-03-20 17:08:48 --> Loader Class Initialized
INFO - 2024-03-20 17:08:48 --> Helper loaded: url_helper
INFO - 2024-03-20 17:08:48 --> Helper loaded: file_helper
INFO - 2024-03-20 17:08:48 --> Helper loaded: form_helper
INFO - 2024-03-20 17:08:48 --> Helper loaded: general_helper
INFO - 2024-03-20 17:08:48 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:08:48 --> Controller Class Initialized
INFO - 2024-03-20 17:08:48 --> Form Validation Class Initialized
INFO - 2024-03-20 17:08:48 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:08:48 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:08:48 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:08:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:08:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:08:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:08:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:08:48 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:08:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:08:48 --> Model "ReportModel" initialized
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:08:48 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
INFO - 2024-03-20 17:08:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 17:09:16 --> Config Class Initialized
INFO - 2024-03-20 17:09:16 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:09:16 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:09:16 --> Utf8 Class Initialized
INFO - 2024-03-20 17:09:16 --> URI Class Initialized
INFO - 2024-03-20 17:09:16 --> Router Class Initialized
INFO - 2024-03-20 17:09:16 --> Output Class Initialized
INFO - 2024-03-20 17:09:16 --> Security Class Initialized
DEBUG - 2024-03-20 17:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:09:16 --> Input Class Initialized
INFO - 2024-03-20 17:09:16 --> Language Class Initialized
INFO - 2024-03-20 17:09:16 --> Loader Class Initialized
INFO - 2024-03-20 17:09:16 --> Helper loaded: url_helper
INFO - 2024-03-20 17:09:16 --> Helper loaded: file_helper
INFO - 2024-03-20 17:09:16 --> Helper loaded: form_helper
INFO - 2024-03-20 17:09:16 --> Helper loaded: general_helper
INFO - 2024-03-20 17:09:16 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:09:16 --> Controller Class Initialized
INFO - 2024-03-20 17:09:16 --> Form Validation Class Initialized
INFO - 2024-03-20 17:09:16 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:09:16 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:09:16 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:09:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:09:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:09:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:09:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:09:16 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:09:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:09:16 --> Model "ReportModel" initialized
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:16 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
INFO - 2024-03-20 17:09:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 17:09:56 --> Config Class Initialized
INFO - 2024-03-20 17:09:56 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:09:56 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:09:56 --> Utf8 Class Initialized
INFO - 2024-03-20 17:09:56 --> URI Class Initialized
INFO - 2024-03-20 17:09:56 --> Router Class Initialized
INFO - 2024-03-20 17:09:56 --> Output Class Initialized
INFO - 2024-03-20 17:09:56 --> Security Class Initialized
DEBUG - 2024-03-20 17:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:09:56 --> Input Class Initialized
INFO - 2024-03-20 17:09:56 --> Language Class Initialized
INFO - 2024-03-20 17:09:56 --> Loader Class Initialized
INFO - 2024-03-20 17:09:56 --> Helper loaded: url_helper
INFO - 2024-03-20 17:09:56 --> Helper loaded: file_helper
INFO - 2024-03-20 17:09:56 --> Helper loaded: form_helper
INFO - 2024-03-20 17:09:56 --> Helper loaded: general_helper
INFO - 2024-03-20 17:09:56 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:09:56 --> Controller Class Initialized
INFO - 2024-03-20 17:09:56 --> Form Validation Class Initialized
INFO - 2024-03-20 17:09:56 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:09:56 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:09:56 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:09:56 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:09:56 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:09:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:09:56 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:09:56 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:09:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:09:56 --> Model "ReportModel" initialized
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_image' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 41
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'item_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 42
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'group_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 43
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'category_name' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 44
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'trans_number' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 45
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'qty' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 46
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'order_status' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 47
ERROR - 2024-03-20 17:09:56 --> Severity: Notice --> Trying to get property 'remark' of non-object D:\xampp\htdocs\sscy\application\views\app\orders\order_print.php 48
INFO - 2024-03-20 17:09:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 17:10:48 --> Config Class Initialized
INFO - 2024-03-20 17:10:48 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:10:48 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:10:48 --> Utf8 Class Initialized
INFO - 2024-03-20 17:10:48 --> URI Class Initialized
INFO - 2024-03-20 17:10:48 --> Router Class Initialized
INFO - 2024-03-20 17:10:48 --> Output Class Initialized
INFO - 2024-03-20 17:10:48 --> Security Class Initialized
DEBUG - 2024-03-20 17:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:10:48 --> Input Class Initialized
INFO - 2024-03-20 17:10:48 --> Language Class Initialized
INFO - 2024-03-20 17:10:48 --> Loader Class Initialized
INFO - 2024-03-20 17:10:48 --> Helper loaded: url_helper
INFO - 2024-03-20 17:10:48 --> Helper loaded: file_helper
INFO - 2024-03-20 17:10:48 --> Helper loaded: form_helper
INFO - 2024-03-20 17:10:48 --> Helper loaded: general_helper
INFO - 2024-03-20 17:10:48 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:10:48 --> Controller Class Initialized
INFO - 2024-03-20 17:10:48 --> Form Validation Class Initialized
INFO - 2024-03-20 17:10:48 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:10:48 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:10:48 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:10:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:10:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:10:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:10:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:10:48 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:10:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:10:48 --> Model "ReportModel" initialized
INFO - 2024-03-20 17:10:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 17:10:58 --> Config Class Initialized
INFO - 2024-03-20 17:10:58 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:10:58 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:10:58 --> Utf8 Class Initialized
INFO - 2024-03-20 17:10:58 --> URI Class Initialized
INFO - 2024-03-20 17:10:58 --> Router Class Initialized
INFO - 2024-03-20 17:10:58 --> Output Class Initialized
INFO - 2024-03-20 17:10:58 --> Security Class Initialized
DEBUG - 2024-03-20 17:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:10:58 --> Input Class Initialized
INFO - 2024-03-20 17:10:58 --> Language Class Initialized
INFO - 2024-03-20 17:10:58 --> Loader Class Initialized
INFO - 2024-03-20 17:10:58 --> Helper loaded: url_helper
INFO - 2024-03-20 17:10:58 --> Helper loaded: file_helper
INFO - 2024-03-20 17:10:58 --> Helper loaded: form_helper
INFO - 2024-03-20 17:10:58 --> Helper loaded: general_helper
INFO - 2024-03-20 17:10:58 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:10:58 --> Controller Class Initialized
INFO - 2024-03-20 17:10:58 --> Form Validation Class Initialized
INFO - 2024-03-20 17:10:58 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:10:58 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:10:58 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:10:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:10:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:10:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:10:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:10:58 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:10:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:10:58 --> Model "ReportModel" initialized
INFO - 2024-03-20 17:10:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 17:10:58 --> Final output sent to browser
DEBUG - 2024-03-20 17:10:58 --> Total execution time: 0.5230
INFO - 2024-03-20 17:12:41 --> Config Class Initialized
INFO - 2024-03-20 17:12:41 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:12:41 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:12:41 --> Utf8 Class Initialized
INFO - 2024-03-20 17:12:41 --> URI Class Initialized
INFO - 2024-03-20 17:12:41 --> Router Class Initialized
INFO - 2024-03-20 17:12:41 --> Output Class Initialized
INFO - 2024-03-20 17:12:41 --> Security Class Initialized
DEBUG - 2024-03-20 17:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:12:41 --> Input Class Initialized
INFO - 2024-03-20 17:12:41 --> Language Class Initialized
INFO - 2024-03-20 17:12:41 --> Loader Class Initialized
INFO - 2024-03-20 17:12:41 --> Helper loaded: url_helper
INFO - 2024-03-20 17:12:41 --> Helper loaded: file_helper
INFO - 2024-03-20 17:12:41 --> Helper loaded: form_helper
INFO - 2024-03-20 17:12:41 --> Helper loaded: general_helper
INFO - 2024-03-20 17:12:41 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:12:41 --> Controller Class Initialized
INFO - 2024-03-20 17:12:41 --> Form Validation Class Initialized
INFO - 2024-03-20 17:12:41 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:12:41 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:12:41 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:12:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:12:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:12:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:12:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:12:41 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:12:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:12:41 --> Model "ReportModel" initialized
INFO - 2024-03-20 17:12:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 17:12:42 --> Final output sent to browser
DEBUG - 2024-03-20 17:12:42 --> Total execution time: 0.5239
INFO - 2024-03-20 17:13:35 --> Config Class Initialized
INFO - 2024-03-20 17:13:35 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:13:35 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:13:35 --> Utf8 Class Initialized
INFO - 2024-03-20 17:13:35 --> URI Class Initialized
INFO - 2024-03-20 17:13:35 --> Router Class Initialized
INFO - 2024-03-20 17:13:35 --> Output Class Initialized
INFO - 2024-03-20 17:13:35 --> Security Class Initialized
DEBUG - 2024-03-20 17:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:13:35 --> Input Class Initialized
INFO - 2024-03-20 17:13:35 --> Language Class Initialized
INFO - 2024-03-20 17:13:35 --> Loader Class Initialized
INFO - 2024-03-20 17:13:35 --> Helper loaded: url_helper
INFO - 2024-03-20 17:13:35 --> Helper loaded: file_helper
INFO - 2024-03-20 17:13:35 --> Helper loaded: form_helper
INFO - 2024-03-20 17:13:35 --> Helper loaded: general_helper
INFO - 2024-03-20 17:13:35 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:13:35 --> Controller Class Initialized
INFO - 2024-03-20 17:13:35 --> Form Validation Class Initialized
INFO - 2024-03-20 17:13:35 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:13:35 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:13:35 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:13:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:13:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:13:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:13:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:13:35 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:13:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:13:35 --> Model "ReportModel" initialized
INFO - 2024-03-20 17:13:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 17:13:36 --> Final output sent to browser
DEBUG - 2024-03-20 17:13:36 --> Total execution time: 0.5361
INFO - 2024-03-20 17:15:27 --> Config Class Initialized
INFO - 2024-03-20 17:15:27 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:15:27 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:15:27 --> Utf8 Class Initialized
INFO - 2024-03-20 17:15:27 --> URI Class Initialized
INFO - 2024-03-20 17:15:27 --> Router Class Initialized
INFO - 2024-03-20 17:15:27 --> Output Class Initialized
INFO - 2024-03-20 17:15:27 --> Security Class Initialized
DEBUG - 2024-03-20 17:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:15:27 --> Input Class Initialized
INFO - 2024-03-20 17:15:27 --> Language Class Initialized
INFO - 2024-03-20 17:15:27 --> Loader Class Initialized
INFO - 2024-03-20 17:15:27 --> Helper loaded: url_helper
INFO - 2024-03-20 17:15:27 --> Helper loaded: file_helper
INFO - 2024-03-20 17:15:27 --> Helper loaded: form_helper
INFO - 2024-03-20 17:15:27 --> Helper loaded: general_helper
INFO - 2024-03-20 17:15:27 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:15:27 --> Controller Class Initialized
INFO - 2024-03-20 17:15:27 --> Form Validation Class Initialized
INFO - 2024-03-20 17:15:27 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "ReportModel" initialized
INFO - 2024-03-20 17:15:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-20 17:15:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-20 17:15:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-20 17:15:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-20 17:15:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-20 17:15:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-20 17:15:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-20 17:15:27 --> Final output sent to browser
DEBUG - 2024-03-20 17:15:27 --> Total execution time: 0.0402
INFO - 2024-03-20 17:15:27 --> Config Class Initialized
INFO - 2024-03-20 17:15:27 --> Hooks Class Initialized
DEBUG - 2024-03-20 17:15:27 --> UTF-8 Support Enabled
INFO - 2024-03-20 17:15:27 --> Utf8 Class Initialized
INFO - 2024-03-20 17:15:27 --> URI Class Initialized
INFO - 2024-03-20 17:15:27 --> Router Class Initialized
INFO - 2024-03-20 17:15:27 --> Output Class Initialized
INFO - 2024-03-20 17:15:27 --> Security Class Initialized
DEBUG - 2024-03-20 17:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 17:15:27 --> Input Class Initialized
INFO - 2024-03-20 17:15:27 --> Language Class Initialized
INFO - 2024-03-20 17:15:27 --> Loader Class Initialized
INFO - 2024-03-20 17:15:27 --> Helper loaded: url_helper
INFO - 2024-03-20 17:15:27 --> Helper loaded: file_helper
INFO - 2024-03-20 17:15:27 --> Helper loaded: form_helper
INFO - 2024-03-20 17:15:27 --> Helper loaded: general_helper
INFO - 2024-03-20 17:15:27 --> Database Driver Class Initialized
DEBUG - 2024-03-20 17:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 17:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 17:15:27 --> Controller Class Initialized
INFO - 2024-03-20 17:15:27 --> Form Validation Class Initialized
INFO - 2024-03-20 17:15:27 --> Model "MasterModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "NotificationModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "DashboardModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "OrderModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 17:15:27 --> Model "ReportModel" initialized
ERROR - 2024-03-20 18:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-20 18:00:58 --> Config Class Initialized
INFO - 2024-03-20 18:00:58 --> Hooks Class Initialized
DEBUG - 2024-03-20 18:00:58 --> UTF-8 Support Enabled
INFO - 2024-03-20 18:00:58 --> Utf8 Class Initialized
INFO - 2024-03-20 18:00:58 --> URI Class Initialized
INFO - 2024-03-20 18:00:58 --> Router Class Initialized
INFO - 2024-03-20 18:00:58 --> Output Class Initialized
INFO - 2024-03-20 18:00:58 --> Security Class Initialized
DEBUG - 2024-03-20 18:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 18:00:58 --> Input Class Initialized
INFO - 2024-03-20 18:00:58 --> Language Class Initialized
INFO - 2024-03-20 18:00:58 --> Loader Class Initialized
INFO - 2024-03-20 18:00:58 --> Helper loaded: url_helper
INFO - 2024-03-20 18:00:58 --> Helper loaded: file_helper
INFO - 2024-03-20 18:00:58 --> Helper loaded: form_helper
INFO - 2024-03-20 18:00:58 --> Helper loaded: general_helper
INFO - 2024-03-20 18:00:58 --> Database Driver Class Initialized
DEBUG - 2024-03-20 18:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 18:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 18:00:58 --> Controller Class Initialized
INFO - 2024-03-20 18:00:58 --> Form Validation Class Initialized
INFO - 2024-03-20 18:00:58 --> Model "MasterModel" initialized
INFO - 2024-03-20 18:00:58 --> Model "NotificationModel" initialized
INFO - 2024-03-20 18:00:58 --> Model "DashboardModel" initialized
INFO - 2024-03-20 18:00:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 18:00:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 18:00:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 18:00:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 18:00:58 --> Model "OrderModel" initialized
INFO - 2024-03-20 18:00:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 18:00:58 --> Model "ReportModel" initialized
INFO - 2024-03-20 18:00:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
ERROR - 2024-03-20 18:00:58 --> Severity: error --> Exception: Class 'Mpdf\Mpdf' not found D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 125
ERROR - 2024-03-20 18:01:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-20 18:01:02 --> Config Class Initialized
INFO - 2024-03-20 18:01:02 --> Hooks Class Initialized
DEBUG - 2024-03-20 18:01:02 --> UTF-8 Support Enabled
INFO - 2024-03-20 18:01:02 --> Utf8 Class Initialized
INFO - 2024-03-20 18:01:02 --> URI Class Initialized
INFO - 2024-03-20 18:01:02 --> Router Class Initialized
INFO - 2024-03-20 18:01:02 --> Output Class Initialized
INFO - 2024-03-20 18:01:02 --> Security Class Initialized
DEBUG - 2024-03-20 18:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 18:01:02 --> Input Class Initialized
INFO - 2024-03-20 18:01:02 --> Language Class Initialized
INFO - 2024-03-20 18:01:02 --> Loader Class Initialized
INFO - 2024-03-20 18:01:02 --> Helper loaded: url_helper
INFO - 2024-03-20 18:01:02 --> Helper loaded: file_helper
INFO - 2024-03-20 18:01:02 --> Helper loaded: form_helper
INFO - 2024-03-20 18:01:02 --> Helper loaded: general_helper
INFO - 2024-03-20 18:01:02 --> Database Driver Class Initialized
DEBUG - 2024-03-20 18:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 18:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 18:01:02 --> Controller Class Initialized
INFO - 2024-03-20 18:01:02 --> Form Validation Class Initialized
INFO - 2024-03-20 18:01:02 --> Model "MasterModel" initialized
INFO - 2024-03-20 18:01:02 --> Model "NotificationModel" initialized
INFO - 2024-03-20 18:01:02 --> Model "DashboardModel" initialized
INFO - 2024-03-20 18:01:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 18:01:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 18:01:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 18:01:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 18:01:02 --> Model "OrderModel" initialized
INFO - 2024-03-20 18:01:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 18:01:02 --> Model "ReportModel" initialized
INFO - 2024-03-20 18:01:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
ERROR - 2024-03-20 18:01:02 --> Severity: error --> Exception: Class 'Mpdf\Mpdf' not found D:\xampp\htdocs\sscy\application\controllers\app\Orders.php 125
INFO - 2024-03-20 18:07:02 --> Config Class Initialized
INFO - 2024-03-20 18:07:02 --> Hooks Class Initialized
DEBUG - 2024-03-20 18:07:02 --> UTF-8 Support Enabled
INFO - 2024-03-20 18:07:02 --> Utf8 Class Initialized
INFO - 2024-03-20 18:07:02 --> URI Class Initialized
INFO - 2024-03-20 18:07:02 --> Router Class Initialized
INFO - 2024-03-20 18:07:02 --> Output Class Initialized
INFO - 2024-03-20 18:07:02 --> Security Class Initialized
DEBUG - 2024-03-20 18:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 18:07:02 --> Input Class Initialized
INFO - 2024-03-20 18:07:02 --> Language Class Initialized
INFO - 2024-03-20 18:07:02 --> Loader Class Initialized
INFO - 2024-03-20 18:07:02 --> Helper loaded: url_helper
INFO - 2024-03-20 18:07:02 --> Helper loaded: file_helper
INFO - 2024-03-20 18:07:02 --> Helper loaded: form_helper
INFO - 2024-03-20 18:07:02 --> Helper loaded: general_helper
INFO - 2024-03-20 18:07:02 --> Database Driver Class Initialized
DEBUG - 2024-03-20 18:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-20 18:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 18:07:02 --> Controller Class Initialized
INFO - 2024-03-20 18:07:02 --> Form Validation Class Initialized
INFO - 2024-03-20 18:07:02 --> Model "MasterModel" initialized
INFO - 2024-03-20 18:07:02 --> Model "NotificationModel" initialized
INFO - 2024-03-20 18:07:02 --> Model "DashboardModel" initialized
INFO - 2024-03-20 18:07:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-20 18:07:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-20 18:07:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-20 18:07:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-20 18:07:02 --> Model "OrderModel" initialized
INFO - 2024-03-20 18:07:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-20 18:07:02 --> Model "ReportModel" initialized
INFO - 2024-03-20 18:07:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-20 18:07:03 --> Final output sent to browser
DEBUG - 2024-03-20 18:07:03 --> Total execution time: 0.6178
