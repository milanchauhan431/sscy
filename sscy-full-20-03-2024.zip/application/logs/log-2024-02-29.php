<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-29 00:00:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-29 00:00:30 --> Config Class Initialized
INFO - 2024-02-29 00:00:30 --> Hooks Class Initialized
DEBUG - 2024-02-29 00:00:30 --> UTF-8 Support Enabled
INFO - 2024-02-29 00:00:30 --> Utf8 Class Initialized
INFO - 2024-02-29 00:00:30 --> URI Class Initialized
INFO - 2024-02-29 00:00:30 --> Router Class Initialized
INFO - 2024-02-29 00:00:30 --> Output Class Initialized
INFO - 2024-02-29 00:00:30 --> Security Class Initialized
DEBUG - 2024-02-29 00:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 00:00:30 --> Input Class Initialized
INFO - 2024-02-29 00:00:30 --> Language Class Initialized
INFO - 2024-02-29 00:00:30 --> Loader Class Initialized
INFO - 2024-02-29 00:00:30 --> Helper loaded: url_helper
INFO - 2024-02-29 00:00:30 --> Helper loaded: file_helper
INFO - 2024-02-29 00:00:30 --> Helper loaded: form_helper
INFO - 2024-02-29 00:00:30 --> Database Driver Class Initialized
DEBUG - 2024-02-29 00:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-29 00:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 00:00:30 --> Controller Class Initialized
INFO - 2024-02-29 00:00:30 --> Form Validation Class Initialized
INFO - 2024-02-29 00:00:30 --> Model "MasterModel" initialized
INFO - 2024-02-29 00:00:30 --> Model "DashboardModel" initialized
INFO - 2024-02-29 00:00:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-29 00:00:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-29 00:00:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-29 00:00:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-29 00:00:30 --> Model "OrderModel" initialized
INFO - 2024-02-29 00:00:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-29 00:00:30 --> Model "ReportModel" initialized
INFO - 2024-02-29 00:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-29 00:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-29 00:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-29 00:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-29 00:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-29 00:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-29 00:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-29 00:00:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-29 00:00:30 --> Final output sent to browser
DEBUG - 2024-02-29 00:00:30 --> Total execution time: 0.0526
ERROR - 2024-02-29 00:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-29 00:00:32 --> Config Class Initialized
INFO - 2024-02-29 00:00:32 --> Hooks Class Initialized
DEBUG - 2024-02-29 00:00:32 --> UTF-8 Support Enabled
INFO - 2024-02-29 00:00:32 --> Utf8 Class Initialized
INFO - 2024-02-29 00:00:32 --> URI Class Initialized
INFO - 2024-02-29 00:00:32 --> Router Class Initialized
INFO - 2024-02-29 00:00:32 --> Output Class Initialized
INFO - 2024-02-29 00:00:32 --> Security Class Initialized
DEBUG - 2024-02-29 00:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 00:00:32 --> Input Class Initialized
INFO - 2024-02-29 00:00:32 --> Language Class Initialized
INFO - 2024-02-29 00:00:32 --> Loader Class Initialized
INFO - 2024-02-29 00:00:32 --> Helper loaded: url_helper
INFO - 2024-02-29 00:00:32 --> Helper loaded: file_helper
INFO - 2024-02-29 00:00:32 --> Helper loaded: form_helper
INFO - 2024-02-29 00:00:32 --> Database Driver Class Initialized
DEBUG - 2024-02-29 00:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-29 00:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 00:00:32 --> Controller Class Initialized
INFO - 2024-02-29 00:00:32 --> Form Validation Class Initialized
INFO - 2024-02-29 00:00:32 --> Model "MasterModel" initialized
INFO - 2024-02-29 00:00:32 --> Model "DashboardModel" initialized
INFO - 2024-02-29 00:00:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-29 00:00:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-29 00:00:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-29 00:00:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-29 00:00:32 --> Model "OrderModel" initialized
INFO - 2024-02-29 00:00:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-29 00:00:32 --> Model "ReportModel" initialized
ERROR - 2024-02-29 00:00:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-29 00:00:35 --> Config Class Initialized
INFO - 2024-02-29 00:00:35 --> Hooks Class Initialized
DEBUG - 2024-02-29 00:00:35 --> UTF-8 Support Enabled
INFO - 2024-02-29 00:00:35 --> Utf8 Class Initialized
INFO - 2024-02-29 00:00:35 --> URI Class Initialized
INFO - 2024-02-29 00:00:35 --> Router Class Initialized
INFO - 2024-02-29 00:00:35 --> Output Class Initialized
INFO - 2024-02-29 00:00:35 --> Security Class Initialized
DEBUG - 2024-02-29 00:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 00:00:35 --> Input Class Initialized
INFO - 2024-02-29 00:00:35 --> Language Class Initialized
INFO - 2024-02-29 00:00:35 --> Loader Class Initialized
INFO - 2024-02-29 00:00:35 --> Helper loaded: url_helper
INFO - 2024-02-29 00:00:35 --> Helper loaded: file_helper
INFO - 2024-02-29 00:00:35 --> Helper loaded: form_helper
INFO - 2024-02-29 00:00:35 --> Database Driver Class Initialized
DEBUG - 2024-02-29 00:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-29 00:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 00:00:35 --> Controller Class Initialized
INFO - 2024-02-29 00:00:35 --> Form Validation Class Initialized
INFO - 2024-02-29 00:00:35 --> Model "MasterModel" initialized
INFO - 2024-02-29 00:00:35 --> Model "DashboardModel" initialized
INFO - 2024-02-29 00:00:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-29 00:00:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-29 00:00:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-29 00:00:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-29 00:00:35 --> Model "OrderModel" initialized
INFO - 2024-02-29 00:00:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-29 00:00:35 --> Model "ReportModel" initialized
INFO - 2024-02-29 00:00:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/item_detail.php
INFO - 2024-02-29 00:00:35 --> Final output sent to browser
DEBUG - 2024-02-29 00:00:35 --> Total execution time: 0.0336
ERROR - 2024-02-29 00:01:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-29 00:01:10 --> Config Class Initialized
INFO - 2024-02-29 00:01:10 --> Hooks Class Initialized
DEBUG - 2024-02-29 00:01:10 --> UTF-8 Support Enabled
INFO - 2024-02-29 00:01:10 --> Utf8 Class Initialized
INFO - 2024-02-29 00:01:10 --> URI Class Initialized
INFO - 2024-02-29 00:01:10 --> Router Class Initialized
INFO - 2024-02-29 00:01:10 --> Output Class Initialized
INFO - 2024-02-29 00:01:10 --> Security Class Initialized
DEBUG - 2024-02-29 00:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 00:01:10 --> Input Class Initialized
INFO - 2024-02-29 00:01:10 --> Language Class Initialized
INFO - 2024-02-29 00:01:10 --> Loader Class Initialized
INFO - 2024-02-29 00:01:10 --> Helper loaded: url_helper
INFO - 2024-02-29 00:01:10 --> Helper loaded: file_helper
INFO - 2024-02-29 00:01:10 --> Helper loaded: form_helper
INFO - 2024-02-29 00:01:10 --> Database Driver Class Initialized
DEBUG - 2024-02-29 00:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-29 00:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 00:01:10 --> Controller Class Initialized
INFO - 2024-02-29 00:01:10 --> Form Validation Class Initialized
INFO - 2024-02-29 00:01:10 --> Model "MasterModel" initialized
INFO - 2024-02-29 00:01:10 --> Model "DashboardModel" initialized
INFO - 2024-02-29 00:01:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-29 00:01:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-29 00:01:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-29 00:01:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-29 00:01:10 --> Model "OrderModel" initialized
INFO - 2024-02-29 00:01:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-29 00:01:10 --> Model "ReportModel" initialized
INFO - 2024-02-29 00:01:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-29 00:01:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-29 00:01:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-29 00:01:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-29 00:01:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-29 00:01:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-29 00:01:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-29 00:01:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-29 00:01:10 --> Final output sent to browser
DEBUG - 2024-02-29 00:01:10 --> Total execution time: 0.0336
ERROR - 2024-02-29 00:01:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-29 00:01:11 --> Config Class Initialized
INFO - 2024-02-29 00:01:11 --> Hooks Class Initialized
DEBUG - 2024-02-29 00:01:11 --> UTF-8 Support Enabled
INFO - 2024-02-29 00:01:11 --> Utf8 Class Initialized
INFO - 2024-02-29 00:01:11 --> URI Class Initialized
INFO - 2024-02-29 00:01:11 --> Router Class Initialized
INFO - 2024-02-29 00:01:11 --> Output Class Initialized
INFO - 2024-02-29 00:01:11 --> Security Class Initialized
DEBUG - 2024-02-29 00:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 00:01:11 --> Input Class Initialized
INFO - 2024-02-29 00:01:11 --> Language Class Initialized
INFO - 2024-02-29 00:01:11 --> Loader Class Initialized
INFO - 2024-02-29 00:01:11 --> Helper loaded: url_helper
INFO - 2024-02-29 00:01:11 --> Helper loaded: file_helper
INFO - 2024-02-29 00:01:11 --> Helper loaded: form_helper
INFO - 2024-02-29 00:01:11 --> Database Driver Class Initialized
DEBUG - 2024-02-29 00:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-29 00:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 00:01:11 --> Controller Class Initialized
INFO - 2024-02-29 00:01:11 --> Form Validation Class Initialized
INFO - 2024-02-29 00:01:11 --> Model "MasterModel" initialized
INFO - 2024-02-29 00:01:11 --> Model "DashboardModel" initialized
INFO - 2024-02-29 00:01:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-29 00:01:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-29 00:01:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-29 00:01:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-29 00:01:11 --> Model "OrderModel" initialized
INFO - 2024-02-29 00:01:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-29 00:01:11 --> Model "ReportModel" initialized
ERROR - 2024-02-29 00:01:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-29 00:01:41 --> Config Class Initialized
INFO - 2024-02-29 00:01:41 --> Hooks Class Initialized
DEBUG - 2024-02-29 00:01:41 --> UTF-8 Support Enabled
INFO - 2024-02-29 00:01:41 --> Utf8 Class Initialized
INFO - 2024-02-29 00:01:41 --> URI Class Initialized
INFO - 2024-02-29 00:01:41 --> Router Class Initialized
INFO - 2024-02-29 00:01:41 --> Output Class Initialized
INFO - 2024-02-29 00:01:41 --> Security Class Initialized
DEBUG - 2024-02-29 00:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 00:01:41 --> Input Class Initialized
INFO - 2024-02-29 00:01:41 --> Language Class Initialized
INFO - 2024-02-29 00:01:41 --> Loader Class Initialized
INFO - 2024-02-29 00:01:41 --> Helper loaded: url_helper
INFO - 2024-02-29 00:01:41 --> Helper loaded: file_helper
INFO - 2024-02-29 00:01:41 --> Helper loaded: form_helper
INFO - 2024-02-29 00:01:41 --> Database Driver Class Initialized
DEBUG - 2024-02-29 00:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-29 00:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 00:01:41 --> Controller Class Initialized
INFO - 2024-02-29 00:01:41 --> Form Validation Class Initialized
INFO - 2024-02-29 00:01:41 --> Model "MasterModel" initialized
INFO - 2024-02-29 00:01:41 --> Model "DashboardModel" initialized
INFO - 2024-02-29 00:01:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-29 00:01:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-29 00:01:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-29 00:01:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-29 00:01:41 --> Model "OrderModel" initialized
INFO - 2024-02-29 00:01:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-29 00:01:41 --> Model "ReportModel" initialized
INFO - 2024-02-29 00:01:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-29 00:01:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-29 00:01:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-29 00:01:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-29 00:01:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-29 00:01:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-29 00:01:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-29 00:01:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-29 00:01:41 --> Final output sent to browser
DEBUG - 2024-02-29 00:01:41 --> Total execution time: 0.0462
ERROR - 2024-02-29 00:01:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-29 00:01:42 --> Config Class Initialized
INFO - 2024-02-29 00:01:42 --> Hooks Class Initialized
DEBUG - 2024-02-29 00:01:42 --> UTF-8 Support Enabled
INFO - 2024-02-29 00:01:42 --> Utf8 Class Initialized
INFO - 2024-02-29 00:01:42 --> URI Class Initialized
INFO - 2024-02-29 00:01:42 --> Router Class Initialized
INFO - 2024-02-29 00:01:42 --> Output Class Initialized
INFO - 2024-02-29 00:01:42 --> Security Class Initialized
DEBUG - 2024-02-29 00:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 00:01:42 --> Input Class Initialized
INFO - 2024-02-29 00:01:42 --> Language Class Initialized
INFO - 2024-02-29 00:01:42 --> Loader Class Initialized
INFO - 2024-02-29 00:01:42 --> Helper loaded: url_helper
INFO - 2024-02-29 00:01:42 --> Helper loaded: file_helper
INFO - 2024-02-29 00:01:42 --> Helper loaded: form_helper
INFO - 2024-02-29 00:01:42 --> Database Driver Class Initialized
DEBUG - 2024-02-29 00:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-29 00:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 00:01:42 --> Controller Class Initialized
INFO - 2024-02-29 00:01:42 --> Form Validation Class Initialized
INFO - 2024-02-29 00:01:42 --> Model "MasterModel" initialized
INFO - 2024-02-29 00:01:42 --> Model "DashboardModel" initialized
INFO - 2024-02-29 00:01:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-29 00:01:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-29 00:01:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-29 00:01:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-29 00:01:42 --> Model "OrderModel" initialized
INFO - 2024-02-29 00:01:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-29 00:01:42 --> Model "ReportModel" initialized
ERROR - 2024-02-29 00:06:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-29 00:06:38 --> Config Class Initialized
INFO - 2024-02-29 00:06:38 --> Hooks Class Initialized
DEBUG - 2024-02-29 00:06:38 --> UTF-8 Support Enabled
INFO - 2024-02-29 00:06:38 --> Utf8 Class Initialized
INFO - 2024-02-29 00:06:38 --> URI Class Initialized
INFO - 2024-02-29 00:06:38 --> Router Class Initialized
INFO - 2024-02-29 00:06:38 --> Output Class Initialized
INFO - 2024-02-29 00:06:38 --> Security Class Initialized
DEBUG - 2024-02-29 00:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 00:06:38 --> Input Class Initialized
INFO - 2024-02-29 00:06:38 --> Language Class Initialized
INFO - 2024-02-29 00:06:38 --> Loader Class Initialized
INFO - 2024-02-29 00:06:38 --> Helper loaded: url_helper
INFO - 2024-02-29 00:06:38 --> Helper loaded: file_helper
INFO - 2024-02-29 00:06:38 --> Helper loaded: form_helper
INFO - 2024-02-29 00:06:38 --> Database Driver Class Initialized
DEBUG - 2024-02-29 00:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-29 00:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 00:06:38 --> Controller Class Initialized
INFO - 2024-02-29 00:06:38 --> Form Validation Class Initialized
INFO - 2024-02-29 00:06:38 --> Model "MasterModel" initialized
INFO - 2024-02-29 00:06:38 --> Model "DashboardModel" initialized
INFO - 2024-02-29 00:06:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-29 00:06:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-29 00:06:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-29 00:06:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-29 00:06:38 --> Model "OrderModel" initialized
INFO - 2024-02-29 00:06:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-29 00:06:38 --> Model "ReportModel" initialized
