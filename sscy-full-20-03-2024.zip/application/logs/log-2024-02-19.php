<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-19 10:59:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 10:59:42 --> Config Class Initialized
INFO - 2024-02-19 10:59:42 --> Hooks Class Initialized
DEBUG - 2024-02-19 10:59:42 --> UTF-8 Support Enabled
INFO - 2024-02-19 10:59:42 --> Utf8 Class Initialized
INFO - 2024-02-19 10:59:42 --> URI Class Initialized
INFO - 2024-02-19 10:59:42 --> Router Class Initialized
INFO - 2024-02-19 10:59:42 --> Output Class Initialized
INFO - 2024-02-19 10:59:42 --> Security Class Initialized
DEBUG - 2024-02-19 10:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 10:59:42 --> Input Class Initialized
INFO - 2024-02-19 10:59:42 --> Language Class Initialized
INFO - 2024-02-19 10:59:42 --> Loader Class Initialized
INFO - 2024-02-19 10:59:42 --> Helper loaded: url_helper
INFO - 2024-02-19 10:59:42 --> Helper loaded: file_helper
INFO - 2024-02-19 10:59:42 --> Helper loaded: form_helper
INFO - 2024-02-19 10:59:42 --> Database Driver Class Initialized
DEBUG - 2024-02-19 10:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 10:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 10:59:42 --> Controller Class Initialized
INFO - 2024-02-19 10:59:42 --> Model "LoginModel" initialized
INFO - 2024-02-19 10:59:42 --> Form Validation Class Initialized
INFO - 2024-02-19 10:59:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-19 10:59:42 --> Final output sent to browser
DEBUG - 2024-02-19 10:59:42 --> Total execution time: 0.0299
ERROR - 2024-02-19 11:14:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:14 --> Config Class Initialized
INFO - 2024-02-19 11:14:14 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:14 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:14 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:14 --> URI Class Initialized
INFO - 2024-02-19 11:14:14 --> Router Class Initialized
INFO - 2024-02-19 11:14:14 --> Output Class Initialized
INFO - 2024-02-19 11:14:14 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:14 --> Input Class Initialized
INFO - 2024-02-19 11:14:14 --> Language Class Initialized
INFO - 2024-02-19 11:14:14 --> Loader Class Initialized
INFO - 2024-02-19 11:14:14 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:14 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:14 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:14 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:14 --> Controller Class Initialized
INFO - 2024-02-19 11:14:14 --> Model "LoginModel" initialized
INFO - 2024-02-19 11:14:14 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-19 11:14:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:14 --> Config Class Initialized
INFO - 2024-02-19 11:14:14 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:14 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:14 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:14 --> URI Class Initialized
INFO - 2024-02-19 11:14:14 --> Router Class Initialized
INFO - 2024-02-19 11:14:14 --> Output Class Initialized
INFO - 2024-02-19 11:14:14 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:14 --> Input Class Initialized
INFO - 2024-02-19 11:14:14 --> Language Class Initialized
INFO - 2024-02-19 11:14:14 --> Loader Class Initialized
INFO - 2024-02-19 11:14:14 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:14 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:14 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:14 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:14 --> Controller Class Initialized
INFO - 2024-02-19 11:14:14 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:14 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:14:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:14:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:14:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:14:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-19 11:14:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-19 11:14:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-19 11:14:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-19 11:14:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-19 11:14:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-19 11:14:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-19 11:14:14 --> Final output sent to browser
DEBUG - 2024-02-19 11:14:14 --> Total execution time: 0.0272
ERROR - 2024-02-19 11:14:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:30 --> Config Class Initialized
INFO - 2024-02-19 11:14:30 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:30 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:30 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:30 --> URI Class Initialized
INFO - 2024-02-19 11:14:30 --> Router Class Initialized
INFO - 2024-02-19 11:14:30 --> Output Class Initialized
INFO - 2024-02-19 11:14:30 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:30 --> Input Class Initialized
INFO - 2024-02-19 11:14:30 --> Language Class Initialized
INFO - 2024-02-19 11:14:30 --> Loader Class Initialized
INFO - 2024-02-19 11:14:30 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:30 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:30 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:30 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:30 --> Controller Class Initialized
INFO - 2024-02-19 11:14:30 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:30 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:14:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:14:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:14:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:14:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-19 11:14:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-19 11:14:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-19 11:14:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-19 11:14:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-19 11:14:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/index.php
INFO - 2024-02-19 11:14:30 --> Final output sent to browser
DEBUG - 2024-02-19 11:14:30 --> Total execution time: 0.0326
ERROR - 2024-02-19 11:14:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:30 --> Config Class Initialized
INFO - 2024-02-19 11:14:30 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:30 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:30 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:30 --> URI Class Initialized
INFO - 2024-02-19 11:14:30 --> Router Class Initialized
INFO - 2024-02-19 11:14:30 --> Output Class Initialized
INFO - 2024-02-19 11:14:30 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:30 --> Input Class Initialized
INFO - 2024-02-19 11:14:30 --> Language Class Initialized
INFO - 2024-02-19 11:14:30 --> Loader Class Initialized
INFO - 2024-02-19 11:14:30 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:30 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:30 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:30 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:30 --> Controller Class Initialized
INFO - 2024-02-19 11:14:30 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:30 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:14:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:14:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:14:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:14:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-19 11:14:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:32 --> Config Class Initialized
INFO - 2024-02-19 11:14:32 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:32 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:32 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:32 --> URI Class Initialized
INFO - 2024-02-19 11:14:32 --> Router Class Initialized
INFO - 2024-02-19 11:14:32 --> Output Class Initialized
INFO - 2024-02-19 11:14:32 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:32 --> Input Class Initialized
INFO - 2024-02-19 11:14:32 --> Language Class Initialized
INFO - 2024-02-19 11:14:32 --> Loader Class Initialized
INFO - 2024-02-19 11:14:32 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:32 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:32 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:32 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:32 --> Controller Class Initialized
INFO - 2024-02-19 11:14:32 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:32 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:14:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:14:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:14:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:14:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-19 11:14:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-19 11:14:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-19 11:14:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-19 11:14:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-19 11:14:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-19 11:14:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-19 11:14:32 --> Final output sent to browser
DEBUG - 2024-02-19 11:14:32 --> Total execution time: 0.0268
ERROR - 2024-02-19 11:14:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:35 --> Config Class Initialized
INFO - 2024-02-19 11:14:35 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:35 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:35 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:35 --> URI Class Initialized
INFO - 2024-02-19 11:14:35 --> Router Class Initialized
INFO - 2024-02-19 11:14:35 --> Output Class Initialized
INFO - 2024-02-19 11:14:35 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:35 --> Input Class Initialized
INFO - 2024-02-19 11:14:35 --> Language Class Initialized
INFO - 2024-02-19 11:14:35 --> Loader Class Initialized
INFO - 2024-02-19 11:14:35 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:35 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:35 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:35 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:35 --> Controller Class Initialized
INFO - 2024-02-19 11:14:35 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:35 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:14:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:14:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:14:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:14:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-19 11:14:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-19 11:14:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-19 11:14:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-19 11:14:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-19 11:14:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-19 11:14:35 --> Final output sent to browser
DEBUG - 2024-02-19 11:14:35 --> Total execution time: 0.0288
ERROR - 2024-02-19 11:14:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:35 --> Config Class Initialized
INFO - 2024-02-19 11:14:35 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:35 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:35 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:35 --> URI Class Initialized
INFO - 2024-02-19 11:14:35 --> Router Class Initialized
INFO - 2024-02-19 11:14:35 --> Output Class Initialized
INFO - 2024-02-19 11:14:35 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:35 --> Input Class Initialized
INFO - 2024-02-19 11:14:35 --> Language Class Initialized
INFO - 2024-02-19 11:14:35 --> Loader Class Initialized
INFO - 2024-02-19 11:14:35 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:35 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:35 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:35 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:35 --> Controller Class Initialized
INFO - 2024-02-19 11:14:35 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:35 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:14:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:14:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:14:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:14:35 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-19 11:14:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:42 --> Config Class Initialized
INFO - 2024-02-19 11:14:42 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:42 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:42 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:42 --> URI Class Initialized
INFO - 2024-02-19 11:14:42 --> Router Class Initialized
INFO - 2024-02-19 11:14:42 --> Output Class Initialized
INFO - 2024-02-19 11:14:42 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:42 --> Input Class Initialized
INFO - 2024-02-19 11:14:42 --> Language Class Initialized
INFO - 2024-02-19 11:14:42 --> Loader Class Initialized
INFO - 2024-02-19 11:14:42 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:42 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:42 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:42 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:42 --> Controller Class Initialized
INFO - 2024-02-19 11:14:42 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:42 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:14:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:14:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:14:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:14:42 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-19 11:14:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:45 --> Config Class Initialized
INFO - 2024-02-19 11:14:45 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:45 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:45 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:45 --> URI Class Initialized
INFO - 2024-02-19 11:14:45 --> Router Class Initialized
INFO - 2024-02-19 11:14:45 --> Output Class Initialized
INFO - 2024-02-19 11:14:45 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:45 --> Input Class Initialized
INFO - 2024-02-19 11:14:45 --> Language Class Initialized
INFO - 2024-02-19 11:14:45 --> Loader Class Initialized
INFO - 2024-02-19 11:14:45 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:45 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:45 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:45 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:45 --> Controller Class Initialized
INFO - 2024-02-19 11:14:45 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:45 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:14:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:14:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:14:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:14:45 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-19 11:14:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:49 --> Config Class Initialized
INFO - 2024-02-19 11:14:49 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:49 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:49 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:49 --> URI Class Initialized
INFO - 2024-02-19 11:14:49 --> Router Class Initialized
INFO - 2024-02-19 11:14:49 --> Output Class Initialized
INFO - 2024-02-19 11:14:49 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:49 --> Input Class Initialized
INFO - 2024-02-19 11:14:49 --> Language Class Initialized
INFO - 2024-02-19 11:14:49 --> Loader Class Initialized
INFO - 2024-02-19 11:14:49 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:49 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:49 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:49 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:49 --> Controller Class Initialized
INFO - 2024-02-19 11:14:49 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:49 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:14:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:14:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:14:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:14:49 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-19 11:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:53 --> Config Class Initialized
INFO - 2024-02-19 11:14:53 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:53 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:53 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:53 --> URI Class Initialized
INFO - 2024-02-19 11:14:53 --> Router Class Initialized
INFO - 2024-02-19 11:14:53 --> Output Class Initialized
INFO - 2024-02-19 11:14:53 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:53 --> Input Class Initialized
INFO - 2024-02-19 11:14:53 --> Language Class Initialized
INFO - 2024-02-19 11:14:53 --> Loader Class Initialized
INFO - 2024-02-19 11:14:53 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:53 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:53 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:53 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:53 --> Controller Class Initialized
INFO - 2024-02-19 11:14:53 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:53 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:14:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:14:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:14:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:14:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-19 11:14:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:55 --> Config Class Initialized
INFO - 2024-02-19 11:14:55 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:55 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:55 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:55 --> URI Class Initialized
INFO - 2024-02-19 11:14:55 --> Router Class Initialized
INFO - 2024-02-19 11:14:55 --> Output Class Initialized
INFO - 2024-02-19 11:14:55 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:55 --> Input Class Initialized
INFO - 2024-02-19 11:14:55 --> Language Class Initialized
INFO - 2024-02-19 11:14:55 --> Loader Class Initialized
INFO - 2024-02-19 11:14:55 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:55 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:55 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:55 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:55 --> Controller Class Initialized
INFO - 2024-02-19 11:14:55 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:55 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:14:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:14:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:14:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:14:55 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-19 11:14:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:14:57 --> Config Class Initialized
INFO - 2024-02-19 11:14:57 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:14:57 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:14:57 --> Utf8 Class Initialized
INFO - 2024-02-19 11:14:57 --> URI Class Initialized
INFO - 2024-02-19 11:14:57 --> Router Class Initialized
INFO - 2024-02-19 11:14:57 --> Output Class Initialized
INFO - 2024-02-19 11:14:57 --> Security Class Initialized
DEBUG - 2024-02-19 11:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:14:57 --> Input Class Initialized
INFO - 2024-02-19 11:14:57 --> Language Class Initialized
INFO - 2024-02-19 11:14:57 --> Loader Class Initialized
INFO - 2024-02-19 11:14:57 --> Helper loaded: url_helper
INFO - 2024-02-19 11:14:57 --> Helper loaded: file_helper
INFO - 2024-02-19 11:14:57 --> Helper loaded: form_helper
INFO - 2024-02-19 11:14:57 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:14:57 --> Controller Class Initialized
INFO - 2024-02-19 11:14:57 --> Form Validation Class Initialized
INFO - 2024-02-19 11:14:57 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:14:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:14:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:14:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:14:57 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-19 11:15:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:15:02 --> Config Class Initialized
INFO - 2024-02-19 11:15:02 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:15:02 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:15:02 --> Utf8 Class Initialized
INFO - 2024-02-19 11:15:02 --> URI Class Initialized
INFO - 2024-02-19 11:15:02 --> Router Class Initialized
INFO - 2024-02-19 11:15:02 --> Output Class Initialized
INFO - 2024-02-19 11:15:02 --> Security Class Initialized
DEBUG - 2024-02-19 11:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:15:02 --> Input Class Initialized
INFO - 2024-02-19 11:15:02 --> Language Class Initialized
INFO - 2024-02-19 11:15:02 --> Loader Class Initialized
INFO - 2024-02-19 11:15:02 --> Helper loaded: url_helper
INFO - 2024-02-19 11:15:02 --> Helper loaded: file_helper
INFO - 2024-02-19 11:15:02 --> Helper loaded: form_helper
INFO - 2024-02-19 11:15:02 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:15:02 --> Controller Class Initialized
INFO - 2024-02-19 11:15:02 --> Form Validation Class Initialized
INFO - 2024-02-19 11:15:02 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:15:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:15:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:15:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:15:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-19 11:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-19 11:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-19 11:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-19 11:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-19 11:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-19 11:15:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-19 11:15:02 --> Final output sent to browser
DEBUG - 2024-02-19 11:15:02 --> Total execution time: 0.0246
ERROR - 2024-02-19 11:16:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 11:16:07 --> Config Class Initialized
INFO - 2024-02-19 11:16:07 --> Hooks Class Initialized
DEBUG - 2024-02-19 11:16:07 --> UTF-8 Support Enabled
INFO - 2024-02-19 11:16:07 --> Utf8 Class Initialized
INFO - 2024-02-19 11:16:07 --> URI Class Initialized
INFO - 2024-02-19 11:16:07 --> Router Class Initialized
INFO - 2024-02-19 11:16:07 --> Output Class Initialized
INFO - 2024-02-19 11:16:07 --> Security Class Initialized
DEBUG - 2024-02-19 11:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 11:16:07 --> Input Class Initialized
INFO - 2024-02-19 11:16:07 --> Language Class Initialized
INFO - 2024-02-19 11:16:07 --> Loader Class Initialized
INFO - 2024-02-19 11:16:07 --> Helper loaded: url_helper
INFO - 2024-02-19 11:16:07 --> Helper loaded: file_helper
INFO - 2024-02-19 11:16:07 --> Helper loaded: form_helper
INFO - 2024-02-19 11:16:07 --> Database Driver Class Initialized
DEBUG - 2024-02-19 11:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 11:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 11:16:07 --> Controller Class Initialized
INFO - 2024-02-19 11:16:07 --> Form Validation Class Initialized
INFO - 2024-02-19 11:16:07 --> Model "MasterModel" initialized
INFO - 2024-02-19 11:16:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 11:16:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 11:16:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 11:16:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-19 11:16:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-19 11:16:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-19 11:16:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-19 11:16:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-19 11:16:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-19 11:16:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-19 11:16:07 --> Final output sent to browser
DEBUG - 2024-02-19 11:16:07 --> Total execution time: 0.0283
ERROR - 2024-02-19 12:12:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 12:12:47 --> Config Class Initialized
INFO - 2024-02-19 12:12:47 --> Hooks Class Initialized
DEBUG - 2024-02-19 12:12:47 --> UTF-8 Support Enabled
INFO - 2024-02-19 12:12:47 --> Utf8 Class Initialized
INFO - 2024-02-19 12:12:47 --> URI Class Initialized
INFO - 2024-02-19 12:12:47 --> Router Class Initialized
INFO - 2024-02-19 12:12:47 --> Output Class Initialized
INFO - 2024-02-19 12:12:47 --> Security Class Initialized
DEBUG - 2024-02-19 12:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 12:12:47 --> Input Class Initialized
INFO - 2024-02-19 12:12:47 --> Language Class Initialized
INFO - 2024-02-19 12:12:47 --> Loader Class Initialized
INFO - 2024-02-19 12:12:47 --> Helper loaded: url_helper
INFO - 2024-02-19 12:12:47 --> Helper loaded: file_helper
INFO - 2024-02-19 12:12:47 --> Helper loaded: form_helper
INFO - 2024-02-19 12:12:47 --> Database Driver Class Initialized
DEBUG - 2024-02-19 12:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 12:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 12:12:47 --> Controller Class Initialized
INFO - 2024-02-19 12:12:47 --> Model "LoginModel" initialized
INFO - 2024-02-19 12:12:47 --> Form Validation Class Initialized
INFO - 2024-02-19 12:12:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-19 12:12:47 --> Final output sent to browser
DEBUG - 2024-02-19 12:12:47 --> Total execution time: 0.0267
ERROR - 2024-02-19 12:52:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 12:52:13 --> Config Class Initialized
INFO - 2024-02-19 12:52:13 --> Hooks Class Initialized
DEBUG - 2024-02-19 12:52:13 --> UTF-8 Support Enabled
INFO - 2024-02-19 12:52:13 --> Utf8 Class Initialized
INFO - 2024-02-19 12:52:13 --> URI Class Initialized
INFO - 2024-02-19 12:52:13 --> Router Class Initialized
INFO - 2024-02-19 12:52:13 --> Output Class Initialized
INFO - 2024-02-19 12:52:13 --> Security Class Initialized
DEBUG - 2024-02-19 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 12:52:13 --> Input Class Initialized
INFO - 2024-02-19 12:52:13 --> Language Class Initialized
INFO - 2024-02-19 12:52:13 --> Loader Class Initialized
INFO - 2024-02-19 12:52:13 --> Helper loaded: url_helper
INFO - 2024-02-19 12:52:13 --> Helper loaded: file_helper
INFO - 2024-02-19 12:52:13 --> Helper loaded: form_helper
INFO - 2024-02-19 12:52:13 --> Database Driver Class Initialized
DEBUG - 2024-02-19 12:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 12:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 12:52:13 --> Controller Class Initialized
INFO - 2024-02-19 12:52:13 --> Model "LoginModel" initialized
INFO - 2024-02-19 12:52:13 --> Form Validation Class Initialized
ERROR - 2024-02-19 12:52:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-19 12:52:13 --> Config Class Initialized
INFO - 2024-02-19 12:52:13 --> Hooks Class Initialized
DEBUG - 2024-02-19 12:52:13 --> UTF-8 Support Enabled
INFO - 2024-02-19 12:52:13 --> Utf8 Class Initialized
INFO - 2024-02-19 12:52:13 --> URI Class Initialized
INFO - 2024-02-19 12:52:13 --> Router Class Initialized
INFO - 2024-02-19 12:52:13 --> Output Class Initialized
INFO - 2024-02-19 12:52:13 --> Security Class Initialized
DEBUG - 2024-02-19 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-19 12:52:13 --> Input Class Initialized
INFO - 2024-02-19 12:52:13 --> Language Class Initialized
INFO - 2024-02-19 12:52:13 --> Loader Class Initialized
INFO - 2024-02-19 12:52:13 --> Helper loaded: url_helper
INFO - 2024-02-19 12:52:13 --> Helper loaded: file_helper
INFO - 2024-02-19 12:52:13 --> Helper loaded: form_helper
INFO - 2024-02-19 12:52:13 --> Database Driver Class Initialized
DEBUG - 2024-02-19 12:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-19 12:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-19 12:52:13 --> Controller Class Initialized
INFO - 2024-02-19 12:52:13 --> Form Validation Class Initialized
INFO - 2024-02-19 12:52:13 --> Model "MasterModel" initialized
INFO - 2024-02-19 12:52:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-19 12:52:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-19 12:52:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-19 12:52:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-19 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-19 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-19 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-19 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-19 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-19 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-19 12:52:13 --> Final output sent to browser
DEBUG - 2024-02-19 12:52:13 --> Total execution time: 0.0269
