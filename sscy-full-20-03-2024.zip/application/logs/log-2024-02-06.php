<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-06 11:22:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:22:27 --> Config Class Initialized
INFO - 2024-02-06 11:22:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:22:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:22:27 --> Utf8 Class Initialized
INFO - 2024-02-06 11:22:27 --> URI Class Initialized
INFO - 2024-02-06 11:22:27 --> Router Class Initialized
INFO - 2024-02-06 11:22:27 --> Output Class Initialized
INFO - 2024-02-06 11:22:27 --> Security Class Initialized
DEBUG - 2024-02-06 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:22:27 --> Input Class Initialized
INFO - 2024-02-06 11:22:27 --> Language Class Initialized
INFO - 2024-02-06 11:22:27 --> Loader Class Initialized
INFO - 2024-02-06 11:22:27 --> Helper loaded: url_helper
INFO - 2024-02-06 11:22:27 --> Helper loaded: file_helper
INFO - 2024-02-06 11:22:27 --> Helper loaded: form_helper
INFO - 2024-02-06 11:22:27 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:22:27 --> Controller Class Initialized
INFO - 2024-02-06 11:22:27 --> Model "LoginModel" initialized
INFO - 2024-02-06 11:22:27 --> Form Validation Class Initialized
ERROR - 2024-02-06 11:22:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:22:27 --> Config Class Initialized
INFO - 2024-02-06 11:22:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:22:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:22:27 --> Utf8 Class Initialized
INFO - 2024-02-06 11:22:27 --> URI Class Initialized
INFO - 2024-02-06 11:22:27 --> Router Class Initialized
INFO - 2024-02-06 11:22:27 --> Output Class Initialized
INFO - 2024-02-06 11:22:27 --> Security Class Initialized
DEBUG - 2024-02-06 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:22:27 --> Input Class Initialized
INFO - 2024-02-06 11:22:27 --> Language Class Initialized
INFO - 2024-02-06 11:22:27 --> Loader Class Initialized
INFO - 2024-02-06 11:22:27 --> Helper loaded: url_helper
INFO - 2024-02-06 11:22:27 --> Helper loaded: file_helper
INFO - 2024-02-06 11:22:27 --> Helper loaded: form_helper
INFO - 2024-02-06 11:22:27 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:22:27 --> Controller Class Initialized
INFO - 2024-02-06 11:22:27 --> Form Validation Class Initialized
INFO - 2024-02-06 11:22:27 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:22:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-06 11:22:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-06 11:22:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-06 11:22:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-06 11:22:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-06 11:22:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-06 11:22:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-06 11:22:27 --> Final output sent to browser
DEBUG - 2024-02-06 11:22:27 --> Total execution time: 0.0326
ERROR - 2024-02-06 11:22:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:22:28 --> Config Class Initialized
INFO - 2024-02-06 11:22:28 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:22:28 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:22:28 --> Utf8 Class Initialized
INFO - 2024-02-06 11:22:28 --> URI Class Initialized
INFO - 2024-02-06 11:22:28 --> Router Class Initialized
INFO - 2024-02-06 11:22:28 --> Output Class Initialized
INFO - 2024-02-06 11:22:28 --> Security Class Initialized
DEBUG - 2024-02-06 11:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:22:28 --> Input Class Initialized
INFO - 2024-02-06 11:22:28 --> Language Class Initialized
INFO - 2024-02-06 11:22:28 --> Loader Class Initialized
INFO - 2024-02-06 11:22:28 --> Helper loaded: url_helper
INFO - 2024-02-06 11:22:28 --> Helper loaded: file_helper
INFO - 2024-02-06 11:22:28 --> Helper loaded: form_helper
INFO - 2024-02-06 11:22:28 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:22:28 --> Controller Class Initialized
INFO - 2024-02-06 11:22:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-06 11:22:28 --> Final output sent to browser
DEBUG - 2024-02-06 11:22:28 --> Total execution time: 0.0293
ERROR - 2024-02-06 11:38:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:38:31 --> Config Class Initialized
INFO - 2024-02-06 11:38:31 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:38:31 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:38:31 --> Utf8 Class Initialized
INFO - 2024-02-06 11:38:31 --> URI Class Initialized
INFO - 2024-02-06 11:38:31 --> Router Class Initialized
INFO - 2024-02-06 11:38:31 --> Output Class Initialized
INFO - 2024-02-06 11:38:31 --> Security Class Initialized
DEBUG - 2024-02-06 11:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:38:31 --> Input Class Initialized
INFO - 2024-02-06 11:38:31 --> Language Class Initialized
INFO - 2024-02-06 11:38:31 --> Loader Class Initialized
INFO - 2024-02-06 11:38:31 --> Helper loaded: url_helper
INFO - 2024-02-06 11:38:31 --> Helper loaded: file_helper
INFO - 2024-02-06 11:38:31 --> Helper loaded: form_helper
INFO - 2024-02-06 11:38:31 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:38:31 --> Controller Class Initialized
INFO - 2024-02-06 11:38:31 --> Model "LoginModel" initialized
INFO - 2024-02-06 11:38:31 --> Form Validation Class Initialized
INFO - 2024-02-06 11:38:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-06 11:38:31 --> Final output sent to browser
DEBUG - 2024-02-06 11:38:31 --> Total execution time: 0.0278
ERROR - 2024-02-06 11:38:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:38:46 --> Config Class Initialized
INFO - 2024-02-06 11:38:46 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:38:46 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:38:46 --> Utf8 Class Initialized
INFO - 2024-02-06 11:38:46 --> URI Class Initialized
INFO - 2024-02-06 11:38:46 --> Router Class Initialized
INFO - 2024-02-06 11:38:46 --> Output Class Initialized
INFO - 2024-02-06 11:38:46 --> Security Class Initialized
DEBUG - 2024-02-06 11:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:38:46 --> Input Class Initialized
INFO - 2024-02-06 11:38:46 --> Language Class Initialized
INFO - 2024-02-06 11:38:46 --> Loader Class Initialized
INFO - 2024-02-06 11:38:46 --> Helper loaded: url_helper
INFO - 2024-02-06 11:38:46 --> Helper loaded: file_helper
INFO - 2024-02-06 11:38:46 --> Helper loaded: form_helper
INFO - 2024-02-06 11:38:46 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:38:46 --> Controller Class Initialized
INFO - 2024-02-06 11:38:46 --> Model "LoginModel" initialized
INFO - 2024-02-06 11:38:46 --> Form Validation Class Initialized
INFO - 2024-02-06 11:38:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-06 11:38:46 --> Severity: Notice --> Undefined property: stdClass::$emp_role D:\xampp\htdocs\sscy\application\models\LoginModel.php 18
ERROR - 2024-02-06 11:38:46 --> Severity: Notice --> Undefined variable: empRole D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-06 11:38:46 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\sscy\application\models\LoginModel.php 19
ERROR - 2024-02-06 11:38:46 --> Severity: Notice --> Undefined property: stdClass::$emp_name D:\xampp\htdocs\sscy\application\models\LoginModel.php 20
ERROR - 2024-02-06 11:38:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:38:46 --> Config Class Initialized
INFO - 2024-02-06 11:38:46 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:38:46 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:38:46 --> Utf8 Class Initialized
INFO - 2024-02-06 11:38:46 --> URI Class Initialized
INFO - 2024-02-06 11:38:46 --> Router Class Initialized
INFO - 2024-02-06 11:38:46 --> Output Class Initialized
INFO - 2024-02-06 11:38:46 --> Security Class Initialized
DEBUG - 2024-02-06 11:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:38:46 --> Input Class Initialized
INFO - 2024-02-06 11:38:46 --> Language Class Initialized
INFO - 2024-02-06 11:38:46 --> Loader Class Initialized
INFO - 2024-02-06 11:38:46 --> Helper loaded: url_helper
INFO - 2024-02-06 11:38:46 --> Helper loaded: file_helper
INFO - 2024-02-06 11:38:46 --> Helper loaded: form_helper
INFO - 2024-02-06 11:38:46 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:38:46 --> Controller Class Initialized
INFO - 2024-02-06 11:38:46 --> Form Validation Class Initialized
INFO - 2024-02-06 11:38:46 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:38:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-06 11:38:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-06 11:38:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-06 11:38:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-06 11:38:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-06 11:38:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-06 11:38:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-06 11:38:46 --> Final output sent to browser
DEBUG - 2024-02-06 11:38:46 --> Total execution time: 0.0334
ERROR - 2024-02-06 11:38:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:38:49 --> Config Class Initialized
INFO - 2024-02-06 11:38:49 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:38:49 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:38:49 --> Utf8 Class Initialized
INFO - 2024-02-06 11:38:49 --> URI Class Initialized
INFO - 2024-02-06 11:38:49 --> Router Class Initialized
INFO - 2024-02-06 11:38:49 --> Output Class Initialized
INFO - 2024-02-06 11:38:49 --> Security Class Initialized
DEBUG - 2024-02-06 11:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:38:49 --> Input Class Initialized
INFO - 2024-02-06 11:38:49 --> Language Class Initialized
INFO - 2024-02-06 11:38:49 --> Loader Class Initialized
INFO - 2024-02-06 11:38:49 --> Helper loaded: url_helper
INFO - 2024-02-06 11:38:49 --> Helper loaded: file_helper
INFO - 2024-02-06 11:38:49 --> Helper loaded: form_helper
INFO - 2024-02-06 11:38:49 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:38:49 --> Controller Class Initialized
INFO - 2024-02-06 11:38:49 --> Form Validation Class Initialized
INFO - 2024-02-06 11:38:49 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:38:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-06 11:38:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-06 11:38:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-06 11:38:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-06 11:38:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-06 11:38:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-06 11:38:49 --> Final output sent to browser
DEBUG - 2024-02-06 11:38:49 --> Total execution time: 0.0435
ERROR - 2024-02-06 11:38:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:38:49 --> Config Class Initialized
INFO - 2024-02-06 11:38:49 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:38:49 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:38:49 --> Utf8 Class Initialized
INFO - 2024-02-06 11:38:49 --> URI Class Initialized
INFO - 2024-02-06 11:38:49 --> Router Class Initialized
INFO - 2024-02-06 11:38:49 --> Output Class Initialized
INFO - 2024-02-06 11:38:49 --> Security Class Initialized
DEBUG - 2024-02-06 11:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:38:49 --> Input Class Initialized
INFO - 2024-02-06 11:38:49 --> Language Class Initialized
INFO - 2024-02-06 11:38:49 --> Loader Class Initialized
INFO - 2024-02-06 11:38:49 --> Helper loaded: url_helper
INFO - 2024-02-06 11:38:49 --> Helper loaded: file_helper
INFO - 2024-02-06 11:38:49 --> Helper loaded: form_helper
INFO - 2024-02-06 11:38:49 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:38:49 --> Controller Class Initialized
INFO - 2024-02-06 11:38:49 --> Form Validation Class Initialized
INFO - 2024-02-06 11:38:49 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:38:49 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:38:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:38:54 --> Config Class Initialized
INFO - 2024-02-06 11:38:54 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:38:54 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:38:54 --> Utf8 Class Initialized
INFO - 2024-02-06 11:38:54 --> URI Class Initialized
INFO - 2024-02-06 11:38:54 --> Router Class Initialized
INFO - 2024-02-06 11:38:54 --> Output Class Initialized
INFO - 2024-02-06 11:38:54 --> Security Class Initialized
DEBUG - 2024-02-06 11:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:38:54 --> Input Class Initialized
INFO - 2024-02-06 11:38:54 --> Language Class Initialized
INFO - 2024-02-06 11:38:54 --> Loader Class Initialized
INFO - 2024-02-06 11:38:54 --> Helper loaded: url_helper
INFO - 2024-02-06 11:38:54 --> Helper loaded: file_helper
INFO - 2024-02-06 11:38:54 --> Helper loaded: form_helper
INFO - 2024-02-06 11:38:54 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:38:54 --> Controller Class Initialized
INFO - 2024-02-06 11:38:54 --> Form Validation Class Initialized
INFO - 2024-02-06 11:38:54 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:38:54 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:38:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:38:59 --> Config Class Initialized
INFO - 2024-02-06 11:38:59 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:38:59 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:38:59 --> Utf8 Class Initialized
INFO - 2024-02-06 11:38:59 --> URI Class Initialized
INFO - 2024-02-06 11:38:59 --> Router Class Initialized
INFO - 2024-02-06 11:38:59 --> Output Class Initialized
INFO - 2024-02-06 11:38:59 --> Security Class Initialized
DEBUG - 2024-02-06 11:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:38:59 --> Input Class Initialized
INFO - 2024-02-06 11:38:59 --> Language Class Initialized
INFO - 2024-02-06 11:38:59 --> Loader Class Initialized
INFO - 2024-02-06 11:38:59 --> Helper loaded: url_helper
INFO - 2024-02-06 11:38:59 --> Helper loaded: file_helper
INFO - 2024-02-06 11:38:59 --> Helper loaded: form_helper
INFO - 2024-02-06 11:38:59 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:38:59 --> Controller Class Initialized
INFO - 2024-02-06 11:38:59 --> Form Validation Class Initialized
INFO - 2024-02-06 11:38:59 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:38:59 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:39:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:39:05 --> Config Class Initialized
INFO - 2024-02-06 11:39:05 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:39:05 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:39:05 --> Utf8 Class Initialized
INFO - 2024-02-06 11:39:05 --> URI Class Initialized
INFO - 2024-02-06 11:39:05 --> Router Class Initialized
INFO - 2024-02-06 11:39:05 --> Output Class Initialized
INFO - 2024-02-06 11:39:05 --> Security Class Initialized
DEBUG - 2024-02-06 11:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:39:05 --> Input Class Initialized
INFO - 2024-02-06 11:39:05 --> Language Class Initialized
INFO - 2024-02-06 11:39:05 --> Loader Class Initialized
INFO - 2024-02-06 11:39:05 --> Helper loaded: url_helper
INFO - 2024-02-06 11:39:05 --> Helper loaded: file_helper
INFO - 2024-02-06 11:39:05 --> Helper loaded: form_helper
INFO - 2024-02-06 11:39:05 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:39:05 --> Controller Class Initialized
INFO - 2024-02-06 11:39:05 --> Form Validation Class Initialized
INFO - 2024-02-06 11:39:05 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:39:05 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:39:13 --> Config Class Initialized
INFO - 2024-02-06 11:39:13 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:39:13 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:39:13 --> Utf8 Class Initialized
INFO - 2024-02-06 11:39:13 --> URI Class Initialized
INFO - 2024-02-06 11:39:13 --> Router Class Initialized
INFO - 2024-02-06 11:39:13 --> Output Class Initialized
INFO - 2024-02-06 11:39:13 --> Security Class Initialized
DEBUG - 2024-02-06 11:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:39:13 --> Input Class Initialized
INFO - 2024-02-06 11:39:13 --> Language Class Initialized
INFO - 2024-02-06 11:39:13 --> Loader Class Initialized
INFO - 2024-02-06 11:39:13 --> Helper loaded: url_helper
INFO - 2024-02-06 11:39:13 --> Helper loaded: file_helper
INFO - 2024-02-06 11:39:13 --> Helper loaded: form_helper
INFO - 2024-02-06 11:39:13 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:39:13 --> Controller Class Initialized
INFO - 2024-02-06 11:39:13 --> Form Validation Class Initialized
INFO - 2024-02-06 11:39:13 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:39:13 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:39:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:39:18 --> Config Class Initialized
INFO - 2024-02-06 11:39:18 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:39:18 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:39:18 --> Utf8 Class Initialized
INFO - 2024-02-06 11:39:18 --> URI Class Initialized
INFO - 2024-02-06 11:39:18 --> Router Class Initialized
INFO - 2024-02-06 11:39:18 --> Output Class Initialized
INFO - 2024-02-06 11:39:18 --> Security Class Initialized
DEBUG - 2024-02-06 11:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:39:18 --> Input Class Initialized
INFO - 2024-02-06 11:39:18 --> Language Class Initialized
INFO - 2024-02-06 11:39:18 --> Loader Class Initialized
INFO - 2024-02-06 11:39:18 --> Helper loaded: url_helper
INFO - 2024-02-06 11:39:18 --> Helper loaded: file_helper
INFO - 2024-02-06 11:39:18 --> Helper loaded: form_helper
INFO - 2024-02-06 11:39:18 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:39:18 --> Controller Class Initialized
INFO - 2024-02-06 11:39:18 --> Form Validation Class Initialized
INFO - 2024-02-06 11:39:18 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:39:18 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:39:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:39:21 --> Config Class Initialized
INFO - 2024-02-06 11:39:21 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:39:21 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:39:21 --> Utf8 Class Initialized
INFO - 2024-02-06 11:39:21 --> URI Class Initialized
INFO - 2024-02-06 11:39:21 --> Router Class Initialized
INFO - 2024-02-06 11:39:21 --> Output Class Initialized
INFO - 2024-02-06 11:39:21 --> Security Class Initialized
DEBUG - 2024-02-06 11:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:39:21 --> Input Class Initialized
INFO - 2024-02-06 11:39:21 --> Language Class Initialized
INFO - 2024-02-06 11:39:21 --> Loader Class Initialized
INFO - 2024-02-06 11:39:21 --> Helper loaded: url_helper
INFO - 2024-02-06 11:39:21 --> Helper loaded: file_helper
INFO - 2024-02-06 11:39:21 --> Helper loaded: form_helper
INFO - 2024-02-06 11:39:21 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:39:21 --> Controller Class Initialized
INFO - 2024-02-06 11:39:21 --> Form Validation Class Initialized
INFO - 2024-02-06 11:39:21 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:39:21 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:39:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:39:43 --> Config Class Initialized
INFO - 2024-02-06 11:39:43 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:39:43 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:39:43 --> Utf8 Class Initialized
INFO - 2024-02-06 11:39:43 --> URI Class Initialized
INFO - 2024-02-06 11:39:43 --> Router Class Initialized
INFO - 2024-02-06 11:39:43 --> Output Class Initialized
INFO - 2024-02-06 11:39:43 --> Security Class Initialized
DEBUG - 2024-02-06 11:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:39:43 --> Input Class Initialized
INFO - 2024-02-06 11:39:43 --> Language Class Initialized
INFO - 2024-02-06 11:39:43 --> Loader Class Initialized
INFO - 2024-02-06 11:39:43 --> Helper loaded: url_helper
INFO - 2024-02-06 11:39:43 --> Helper loaded: file_helper
INFO - 2024-02-06 11:39:43 --> Helper loaded: form_helper
INFO - 2024-02-06 11:39:43 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:39:43 --> Controller Class Initialized
INFO - 2024-02-06 11:39:43 --> Form Validation Class Initialized
INFO - 2024-02-06 11:39:43 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:39:43 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:39:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:39:52 --> Config Class Initialized
INFO - 2024-02-06 11:39:52 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:39:52 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:39:52 --> Utf8 Class Initialized
INFO - 2024-02-06 11:39:52 --> URI Class Initialized
INFO - 2024-02-06 11:39:52 --> Router Class Initialized
INFO - 2024-02-06 11:39:52 --> Output Class Initialized
INFO - 2024-02-06 11:39:52 --> Security Class Initialized
DEBUG - 2024-02-06 11:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:39:52 --> Input Class Initialized
INFO - 2024-02-06 11:39:52 --> Language Class Initialized
INFO - 2024-02-06 11:39:52 --> Loader Class Initialized
INFO - 2024-02-06 11:39:52 --> Helper loaded: url_helper
INFO - 2024-02-06 11:39:52 --> Helper loaded: file_helper
INFO - 2024-02-06 11:39:52 --> Helper loaded: form_helper
INFO - 2024-02-06 11:39:52 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:39:52 --> Controller Class Initialized
INFO - 2024-02-06 11:39:52 --> Form Validation Class Initialized
INFO - 2024-02-06 11:39:52 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:39:52 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:40:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:40:02 --> Config Class Initialized
INFO - 2024-02-06 11:40:02 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:40:02 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:40:02 --> Utf8 Class Initialized
INFO - 2024-02-06 11:40:02 --> URI Class Initialized
INFO - 2024-02-06 11:40:02 --> Router Class Initialized
INFO - 2024-02-06 11:40:02 --> Output Class Initialized
INFO - 2024-02-06 11:40:02 --> Security Class Initialized
DEBUG - 2024-02-06 11:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:40:02 --> Input Class Initialized
INFO - 2024-02-06 11:40:02 --> Language Class Initialized
INFO - 2024-02-06 11:40:02 --> Loader Class Initialized
INFO - 2024-02-06 11:40:02 --> Helper loaded: url_helper
INFO - 2024-02-06 11:40:02 --> Helper loaded: file_helper
INFO - 2024-02-06 11:40:02 --> Helper loaded: form_helper
INFO - 2024-02-06 11:40:02 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:40:02 --> Controller Class Initialized
INFO - 2024-02-06 11:40:02 --> Form Validation Class Initialized
INFO - 2024-02-06 11:40:02 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:40:02 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:40:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:40:27 --> Config Class Initialized
INFO - 2024-02-06 11:40:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:40:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:40:27 --> Utf8 Class Initialized
INFO - 2024-02-06 11:40:27 --> URI Class Initialized
INFO - 2024-02-06 11:40:27 --> Router Class Initialized
INFO - 2024-02-06 11:40:27 --> Output Class Initialized
INFO - 2024-02-06 11:40:27 --> Security Class Initialized
DEBUG - 2024-02-06 11:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:40:27 --> Input Class Initialized
INFO - 2024-02-06 11:40:27 --> Language Class Initialized
INFO - 2024-02-06 11:40:27 --> Loader Class Initialized
INFO - 2024-02-06 11:40:27 --> Helper loaded: url_helper
INFO - 2024-02-06 11:40:27 --> Helper loaded: file_helper
INFO - 2024-02-06 11:40:27 --> Helper loaded: form_helper
INFO - 2024-02-06 11:40:27 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:40:27 --> Controller Class Initialized
INFO - 2024-02-06 11:40:27 --> Form Validation Class Initialized
INFO - 2024-02-06 11:40:27 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:40:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-06 11:40:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-06 11:40:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-06 11:40:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-06 11:40:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-06 11:40:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-06 11:40:27 --> Final output sent to browser
DEBUG - 2024-02-06 11:40:27 --> Total execution time: 0.0345
ERROR - 2024-02-06 11:40:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:40:27 --> Config Class Initialized
INFO - 2024-02-06 11:40:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:40:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:40:27 --> Utf8 Class Initialized
INFO - 2024-02-06 11:40:27 --> URI Class Initialized
INFO - 2024-02-06 11:40:27 --> Router Class Initialized
INFO - 2024-02-06 11:40:27 --> Output Class Initialized
INFO - 2024-02-06 11:40:27 --> Security Class Initialized
DEBUG - 2024-02-06 11:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:40:27 --> Input Class Initialized
INFO - 2024-02-06 11:40:27 --> Language Class Initialized
INFO - 2024-02-06 11:40:27 --> Loader Class Initialized
INFO - 2024-02-06 11:40:27 --> Helper loaded: url_helper
INFO - 2024-02-06 11:40:27 --> Helper loaded: file_helper
INFO - 2024-02-06 11:40:27 --> Helper loaded: form_helper
INFO - 2024-02-06 11:40:27 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:40:27 --> Controller Class Initialized
INFO - 2024-02-06 11:40:27 --> Form Validation Class Initialized
INFO - 2024-02-06 11:40:27 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:40:27 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:40:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:40:32 --> Config Class Initialized
INFO - 2024-02-06 11:40:32 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:40:32 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:40:32 --> Utf8 Class Initialized
INFO - 2024-02-06 11:40:32 --> URI Class Initialized
INFO - 2024-02-06 11:40:32 --> Router Class Initialized
INFO - 2024-02-06 11:40:32 --> Output Class Initialized
INFO - 2024-02-06 11:40:32 --> Security Class Initialized
DEBUG - 2024-02-06 11:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:40:32 --> Input Class Initialized
INFO - 2024-02-06 11:40:32 --> Language Class Initialized
INFO - 2024-02-06 11:40:32 --> Loader Class Initialized
INFO - 2024-02-06 11:40:32 --> Helper loaded: url_helper
INFO - 2024-02-06 11:40:32 --> Helper loaded: file_helper
INFO - 2024-02-06 11:40:32 --> Helper loaded: form_helper
INFO - 2024-02-06 11:40:32 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:40:32 --> Controller Class Initialized
INFO - 2024-02-06 11:40:32 --> Form Validation Class Initialized
INFO - 2024-02-06 11:40:32 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:40:32 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:40:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:40:37 --> Config Class Initialized
INFO - 2024-02-06 11:40:37 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:40:37 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:40:37 --> Utf8 Class Initialized
INFO - 2024-02-06 11:40:37 --> URI Class Initialized
INFO - 2024-02-06 11:40:37 --> Router Class Initialized
INFO - 2024-02-06 11:40:37 --> Output Class Initialized
INFO - 2024-02-06 11:40:37 --> Security Class Initialized
DEBUG - 2024-02-06 11:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:40:37 --> Input Class Initialized
INFO - 2024-02-06 11:40:37 --> Language Class Initialized
INFO - 2024-02-06 11:40:37 --> Loader Class Initialized
INFO - 2024-02-06 11:40:37 --> Helper loaded: url_helper
INFO - 2024-02-06 11:40:37 --> Helper loaded: file_helper
INFO - 2024-02-06 11:40:37 --> Helper loaded: form_helper
INFO - 2024-02-06 11:40:37 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:40:37 --> Controller Class Initialized
INFO - 2024-02-06 11:40:37 --> Form Validation Class Initialized
INFO - 2024-02-06 11:40:37 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:40:37 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:40:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:40:44 --> Config Class Initialized
INFO - 2024-02-06 11:40:44 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:40:44 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:40:44 --> Utf8 Class Initialized
INFO - 2024-02-06 11:40:44 --> URI Class Initialized
INFO - 2024-02-06 11:40:44 --> Router Class Initialized
INFO - 2024-02-06 11:40:44 --> Output Class Initialized
INFO - 2024-02-06 11:40:44 --> Security Class Initialized
DEBUG - 2024-02-06 11:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:40:44 --> Input Class Initialized
INFO - 2024-02-06 11:40:44 --> Language Class Initialized
INFO - 2024-02-06 11:40:44 --> Loader Class Initialized
INFO - 2024-02-06 11:40:44 --> Helper loaded: url_helper
INFO - 2024-02-06 11:40:44 --> Helper loaded: file_helper
INFO - 2024-02-06 11:40:44 --> Helper loaded: form_helper
INFO - 2024-02-06 11:40:44 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:40:44 --> Controller Class Initialized
INFO - 2024-02-06 11:40:44 --> Form Validation Class Initialized
INFO - 2024-02-06 11:40:44 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:40:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-06 11:40:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-06 11:40:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-06 11:40:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-06 11:40:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-06 11:40:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-06 11:40:44 --> Final output sent to browser
DEBUG - 2024-02-06 11:40:44 --> Total execution time: 0.0246
ERROR - 2024-02-06 11:40:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:40:44 --> Config Class Initialized
INFO - 2024-02-06 11:40:44 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:40:44 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:40:44 --> Utf8 Class Initialized
INFO - 2024-02-06 11:40:44 --> URI Class Initialized
INFO - 2024-02-06 11:40:44 --> Router Class Initialized
INFO - 2024-02-06 11:40:44 --> Output Class Initialized
INFO - 2024-02-06 11:40:44 --> Security Class Initialized
DEBUG - 2024-02-06 11:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:40:44 --> Input Class Initialized
INFO - 2024-02-06 11:40:44 --> Language Class Initialized
INFO - 2024-02-06 11:40:44 --> Loader Class Initialized
INFO - 2024-02-06 11:40:44 --> Helper loaded: url_helper
INFO - 2024-02-06 11:40:44 --> Helper loaded: file_helper
INFO - 2024-02-06 11:40:44 --> Helper loaded: form_helper
INFO - 2024-02-06 11:40:44 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:40:44 --> Controller Class Initialized
INFO - 2024-02-06 11:40:44 --> Form Validation Class Initialized
INFO - 2024-02-06 11:40:44 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:40:44 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:40:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:40:49 --> Config Class Initialized
INFO - 2024-02-06 11:40:49 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:40:49 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:40:49 --> Utf8 Class Initialized
INFO - 2024-02-06 11:40:49 --> URI Class Initialized
INFO - 2024-02-06 11:40:49 --> Router Class Initialized
INFO - 2024-02-06 11:40:49 --> Output Class Initialized
INFO - 2024-02-06 11:40:49 --> Security Class Initialized
DEBUG - 2024-02-06 11:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:40:49 --> Input Class Initialized
INFO - 2024-02-06 11:40:49 --> Language Class Initialized
INFO - 2024-02-06 11:40:49 --> Loader Class Initialized
INFO - 2024-02-06 11:40:49 --> Helper loaded: url_helper
INFO - 2024-02-06 11:40:49 --> Helper loaded: file_helper
INFO - 2024-02-06 11:40:49 --> Helper loaded: form_helper
INFO - 2024-02-06 11:40:49 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:40:49 --> Controller Class Initialized
INFO - 2024-02-06 11:40:49 --> Form Validation Class Initialized
INFO - 2024-02-06 11:40:49 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:40:49 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:40:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:40:53 --> Config Class Initialized
INFO - 2024-02-06 11:40:53 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:40:53 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:40:53 --> Utf8 Class Initialized
INFO - 2024-02-06 11:40:53 --> URI Class Initialized
INFO - 2024-02-06 11:40:53 --> Router Class Initialized
INFO - 2024-02-06 11:40:53 --> Output Class Initialized
INFO - 2024-02-06 11:40:53 --> Security Class Initialized
DEBUG - 2024-02-06 11:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:40:53 --> Input Class Initialized
INFO - 2024-02-06 11:40:53 --> Language Class Initialized
INFO - 2024-02-06 11:40:53 --> Loader Class Initialized
INFO - 2024-02-06 11:40:53 --> Helper loaded: url_helper
INFO - 2024-02-06 11:40:53 --> Helper loaded: file_helper
INFO - 2024-02-06 11:40:53 --> Helper loaded: form_helper
INFO - 2024-02-06 11:40:53 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:40:53 --> Controller Class Initialized
INFO - 2024-02-06 11:40:53 --> Form Validation Class Initialized
INFO - 2024-02-06 11:40:53 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:40:53 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:40:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:40:58 --> Config Class Initialized
INFO - 2024-02-06 11:40:58 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:40:58 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:40:58 --> Utf8 Class Initialized
INFO - 2024-02-06 11:40:58 --> URI Class Initialized
INFO - 2024-02-06 11:40:58 --> Router Class Initialized
INFO - 2024-02-06 11:40:58 --> Output Class Initialized
INFO - 2024-02-06 11:40:58 --> Security Class Initialized
DEBUG - 2024-02-06 11:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:40:58 --> Input Class Initialized
INFO - 2024-02-06 11:40:58 --> Language Class Initialized
INFO - 2024-02-06 11:40:58 --> Loader Class Initialized
INFO - 2024-02-06 11:40:58 --> Helper loaded: url_helper
INFO - 2024-02-06 11:40:58 --> Helper loaded: file_helper
INFO - 2024-02-06 11:40:58 --> Helper loaded: form_helper
INFO - 2024-02-06 11:40:58 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:40:58 --> Controller Class Initialized
INFO - 2024-02-06 11:40:58 --> Form Validation Class Initialized
INFO - 2024-02-06 11:40:58 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:40:58 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:41:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:41:02 --> Config Class Initialized
INFO - 2024-02-06 11:41:02 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:41:02 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:41:02 --> Utf8 Class Initialized
INFO - 2024-02-06 11:41:02 --> URI Class Initialized
INFO - 2024-02-06 11:41:02 --> Router Class Initialized
INFO - 2024-02-06 11:41:02 --> Output Class Initialized
INFO - 2024-02-06 11:41:02 --> Security Class Initialized
DEBUG - 2024-02-06 11:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:41:02 --> Input Class Initialized
INFO - 2024-02-06 11:41:02 --> Language Class Initialized
INFO - 2024-02-06 11:41:02 --> Loader Class Initialized
INFO - 2024-02-06 11:41:02 --> Helper loaded: url_helper
INFO - 2024-02-06 11:41:02 --> Helper loaded: file_helper
INFO - 2024-02-06 11:41:02 --> Helper loaded: form_helper
INFO - 2024-02-06 11:41:02 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:41:02 --> Controller Class Initialized
INFO - 2024-02-06 11:41:02 --> Form Validation Class Initialized
INFO - 2024-02-06 11:41:02 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:41:02 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:41:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:41:07 --> Config Class Initialized
INFO - 2024-02-06 11:41:07 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:41:07 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:41:07 --> Utf8 Class Initialized
INFO - 2024-02-06 11:41:07 --> URI Class Initialized
INFO - 2024-02-06 11:41:07 --> Router Class Initialized
INFO - 2024-02-06 11:41:07 --> Output Class Initialized
INFO - 2024-02-06 11:41:07 --> Security Class Initialized
DEBUG - 2024-02-06 11:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:41:07 --> Input Class Initialized
INFO - 2024-02-06 11:41:07 --> Language Class Initialized
INFO - 2024-02-06 11:41:07 --> Loader Class Initialized
INFO - 2024-02-06 11:41:07 --> Helper loaded: url_helper
INFO - 2024-02-06 11:41:07 --> Helper loaded: file_helper
INFO - 2024-02-06 11:41:07 --> Helper loaded: form_helper
INFO - 2024-02-06 11:41:07 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:41:07 --> Controller Class Initialized
INFO - 2024-02-06 11:41:07 --> Form Validation Class Initialized
INFO - 2024-02-06 11:41:07 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:41:07 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:41:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:41:13 --> Config Class Initialized
INFO - 2024-02-06 11:41:13 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:41:13 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:41:13 --> Utf8 Class Initialized
INFO - 2024-02-06 11:41:13 --> URI Class Initialized
INFO - 2024-02-06 11:41:13 --> Router Class Initialized
INFO - 2024-02-06 11:41:13 --> Output Class Initialized
INFO - 2024-02-06 11:41:13 --> Security Class Initialized
DEBUG - 2024-02-06 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:41:13 --> Input Class Initialized
INFO - 2024-02-06 11:41:13 --> Language Class Initialized
INFO - 2024-02-06 11:41:13 --> Loader Class Initialized
INFO - 2024-02-06 11:41:13 --> Helper loaded: url_helper
INFO - 2024-02-06 11:41:13 --> Helper loaded: file_helper
INFO - 2024-02-06 11:41:13 --> Helper loaded: form_helper
INFO - 2024-02-06 11:41:13 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:41:13 --> Controller Class Initialized
INFO - 2024-02-06 11:41:13 --> Form Validation Class Initialized
INFO - 2024-02-06 11:41:13 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:41:13 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:41:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:41:17 --> Config Class Initialized
INFO - 2024-02-06 11:41:17 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:41:17 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:41:17 --> Utf8 Class Initialized
INFO - 2024-02-06 11:41:17 --> URI Class Initialized
INFO - 2024-02-06 11:41:17 --> Router Class Initialized
INFO - 2024-02-06 11:41:17 --> Output Class Initialized
INFO - 2024-02-06 11:41:17 --> Security Class Initialized
DEBUG - 2024-02-06 11:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:41:17 --> Input Class Initialized
INFO - 2024-02-06 11:41:17 --> Language Class Initialized
INFO - 2024-02-06 11:41:17 --> Loader Class Initialized
INFO - 2024-02-06 11:41:17 --> Helper loaded: url_helper
INFO - 2024-02-06 11:41:17 --> Helper loaded: file_helper
INFO - 2024-02-06 11:41:17 --> Helper loaded: form_helper
INFO - 2024-02-06 11:41:17 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:41:17 --> Controller Class Initialized
INFO - 2024-02-06 11:41:17 --> Form Validation Class Initialized
INFO - 2024-02-06 11:41:17 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:41:17 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:41:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:41:20 --> Config Class Initialized
INFO - 2024-02-06 11:41:20 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:41:20 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:41:20 --> Utf8 Class Initialized
INFO - 2024-02-06 11:41:20 --> URI Class Initialized
INFO - 2024-02-06 11:41:20 --> Router Class Initialized
INFO - 2024-02-06 11:41:20 --> Output Class Initialized
INFO - 2024-02-06 11:41:20 --> Security Class Initialized
DEBUG - 2024-02-06 11:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:41:20 --> Input Class Initialized
INFO - 2024-02-06 11:41:20 --> Language Class Initialized
INFO - 2024-02-06 11:41:20 --> Loader Class Initialized
INFO - 2024-02-06 11:41:20 --> Helper loaded: url_helper
INFO - 2024-02-06 11:41:20 --> Helper loaded: file_helper
INFO - 2024-02-06 11:41:20 --> Helper loaded: form_helper
INFO - 2024-02-06 11:41:20 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:41:20 --> Controller Class Initialized
INFO - 2024-02-06 11:41:20 --> Form Validation Class Initialized
INFO - 2024-02-06 11:41:20 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:41:20 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:41:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:41:23 --> Config Class Initialized
INFO - 2024-02-06 11:41:23 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:41:23 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:41:23 --> Utf8 Class Initialized
INFO - 2024-02-06 11:41:23 --> URI Class Initialized
INFO - 2024-02-06 11:41:23 --> Router Class Initialized
INFO - 2024-02-06 11:41:23 --> Output Class Initialized
INFO - 2024-02-06 11:41:23 --> Security Class Initialized
DEBUG - 2024-02-06 11:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:41:23 --> Input Class Initialized
INFO - 2024-02-06 11:41:23 --> Language Class Initialized
INFO - 2024-02-06 11:41:23 --> Loader Class Initialized
INFO - 2024-02-06 11:41:23 --> Helper loaded: url_helper
INFO - 2024-02-06 11:41:23 --> Helper loaded: file_helper
INFO - 2024-02-06 11:41:23 --> Helper loaded: form_helper
INFO - 2024-02-06 11:41:23 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:41:23 --> Controller Class Initialized
INFO - 2024-02-06 11:41:23 --> Form Validation Class Initialized
INFO - 2024-02-06 11:41:23 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:41:23 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:41:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:41:47 --> Config Class Initialized
INFO - 2024-02-06 11:41:47 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:41:47 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:41:47 --> Utf8 Class Initialized
INFO - 2024-02-06 11:41:47 --> URI Class Initialized
INFO - 2024-02-06 11:41:47 --> Router Class Initialized
INFO - 2024-02-06 11:41:47 --> Output Class Initialized
INFO - 2024-02-06 11:41:47 --> Security Class Initialized
DEBUG - 2024-02-06 11:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:41:47 --> Input Class Initialized
INFO - 2024-02-06 11:41:47 --> Language Class Initialized
INFO - 2024-02-06 11:41:47 --> Loader Class Initialized
INFO - 2024-02-06 11:41:47 --> Helper loaded: url_helper
INFO - 2024-02-06 11:41:47 --> Helper loaded: file_helper
INFO - 2024-02-06 11:41:47 --> Helper loaded: form_helper
INFO - 2024-02-06 11:41:47 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:41:47 --> Controller Class Initialized
INFO - 2024-02-06 11:41:47 --> Form Validation Class Initialized
INFO - 2024-02-06 11:41:47 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:41:47 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:41:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:41:50 --> Config Class Initialized
INFO - 2024-02-06 11:41:50 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:41:50 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:41:50 --> Utf8 Class Initialized
INFO - 2024-02-06 11:41:50 --> URI Class Initialized
INFO - 2024-02-06 11:41:50 --> Router Class Initialized
INFO - 2024-02-06 11:41:50 --> Output Class Initialized
INFO - 2024-02-06 11:41:50 --> Security Class Initialized
DEBUG - 2024-02-06 11:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:41:50 --> Input Class Initialized
INFO - 2024-02-06 11:41:50 --> Language Class Initialized
INFO - 2024-02-06 11:41:50 --> Loader Class Initialized
INFO - 2024-02-06 11:41:50 --> Helper loaded: url_helper
INFO - 2024-02-06 11:41:50 --> Helper loaded: file_helper
INFO - 2024-02-06 11:41:50 --> Helper loaded: form_helper
INFO - 2024-02-06 11:41:50 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:41:50 --> Controller Class Initialized
INFO - 2024-02-06 11:41:50 --> Form Validation Class Initialized
INFO - 2024-02-06 11:41:50 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:41:50 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:41:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:41:53 --> Config Class Initialized
INFO - 2024-02-06 11:41:53 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:41:53 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:41:53 --> Utf8 Class Initialized
INFO - 2024-02-06 11:41:53 --> URI Class Initialized
INFO - 2024-02-06 11:41:53 --> Router Class Initialized
INFO - 2024-02-06 11:41:53 --> Output Class Initialized
INFO - 2024-02-06 11:41:53 --> Security Class Initialized
DEBUG - 2024-02-06 11:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:41:53 --> Input Class Initialized
INFO - 2024-02-06 11:41:53 --> Language Class Initialized
INFO - 2024-02-06 11:41:53 --> Loader Class Initialized
INFO - 2024-02-06 11:41:53 --> Helper loaded: url_helper
INFO - 2024-02-06 11:41:53 --> Helper loaded: file_helper
INFO - 2024-02-06 11:41:53 --> Helper loaded: form_helper
INFO - 2024-02-06 11:41:53 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:41:53 --> Controller Class Initialized
INFO - 2024-02-06 11:41:53 --> Form Validation Class Initialized
INFO - 2024-02-06 11:41:53 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:41:53 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:45:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:45:03 --> Config Class Initialized
INFO - 2024-02-06 11:45:03 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:45:03 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:45:03 --> Utf8 Class Initialized
INFO - 2024-02-06 11:45:03 --> URI Class Initialized
INFO - 2024-02-06 11:45:03 --> Router Class Initialized
INFO - 2024-02-06 11:45:03 --> Output Class Initialized
INFO - 2024-02-06 11:45:03 --> Security Class Initialized
DEBUG - 2024-02-06 11:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:45:03 --> Input Class Initialized
INFO - 2024-02-06 11:45:03 --> Language Class Initialized
INFO - 2024-02-06 11:45:03 --> Loader Class Initialized
INFO - 2024-02-06 11:45:03 --> Helper loaded: url_helper
INFO - 2024-02-06 11:45:03 --> Helper loaded: file_helper
INFO - 2024-02-06 11:45:04 --> Helper loaded: form_helper
INFO - 2024-02-06 11:45:04 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:45:04 --> Controller Class Initialized
INFO - 2024-02-06 11:45:04 --> Form Validation Class Initialized
INFO - 2024-02-06 11:45:04 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:45:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-06 11:45:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-06 11:45:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-06 11:45:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-06 11:45:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-06 11:45:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-06 11:45:04 --> Final output sent to browser
DEBUG - 2024-02-06 11:45:04 --> Total execution time: 0.0368
ERROR - 2024-02-06 11:46:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:46:55 --> Config Class Initialized
INFO - 2024-02-06 11:46:55 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:46:55 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:46:55 --> Utf8 Class Initialized
INFO - 2024-02-06 11:46:55 --> URI Class Initialized
INFO - 2024-02-06 11:46:55 --> Router Class Initialized
INFO - 2024-02-06 11:46:55 --> Output Class Initialized
INFO - 2024-02-06 11:46:55 --> Security Class Initialized
DEBUG - 2024-02-06 11:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:46:55 --> Input Class Initialized
INFO - 2024-02-06 11:46:55 --> Language Class Initialized
INFO - 2024-02-06 11:46:55 --> Loader Class Initialized
INFO - 2024-02-06 11:46:55 --> Helper loaded: url_helper
INFO - 2024-02-06 11:46:55 --> Helper loaded: file_helper
INFO - 2024-02-06 11:46:55 --> Helper loaded: form_helper
INFO - 2024-02-06 11:46:55 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:46:55 --> Controller Class Initialized
INFO - 2024-02-06 11:46:55 --> Form Validation Class Initialized
INFO - 2024-02-06 11:46:55 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:46:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-06 11:46:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-06 11:46:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-06 11:46:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-06 11:46:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-06 11:46:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-06 11:46:55 --> Final output sent to browser
DEBUG - 2024-02-06 11:46:55 --> Total execution time: 0.0326
ERROR - 2024-02-06 11:46:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:46:55 --> Config Class Initialized
INFO - 2024-02-06 11:46:55 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:46:55 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:46:55 --> Utf8 Class Initialized
INFO - 2024-02-06 11:46:55 --> URI Class Initialized
INFO - 2024-02-06 11:46:55 --> Router Class Initialized
INFO - 2024-02-06 11:46:55 --> Output Class Initialized
INFO - 2024-02-06 11:46:55 --> Security Class Initialized
DEBUG - 2024-02-06 11:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:46:55 --> Input Class Initialized
INFO - 2024-02-06 11:46:55 --> Language Class Initialized
INFO - 2024-02-06 11:46:55 --> Loader Class Initialized
INFO - 2024-02-06 11:46:55 --> Helper loaded: url_helper
INFO - 2024-02-06 11:46:55 --> Helper loaded: file_helper
INFO - 2024-02-06 11:46:55 --> Helper loaded: form_helper
INFO - 2024-02-06 11:46:55 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:46:55 --> Controller Class Initialized
INFO - 2024-02-06 11:46:55 --> Form Validation Class Initialized
INFO - 2024-02-06 11:46:55 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:46:55 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:47:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:47:12 --> Config Class Initialized
INFO - 2024-02-06 11:47:12 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:47:12 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:47:12 --> Utf8 Class Initialized
INFO - 2024-02-06 11:47:12 --> URI Class Initialized
INFO - 2024-02-06 11:47:12 --> Router Class Initialized
INFO - 2024-02-06 11:47:12 --> Output Class Initialized
INFO - 2024-02-06 11:47:12 --> Security Class Initialized
DEBUG - 2024-02-06 11:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:47:12 --> Input Class Initialized
INFO - 2024-02-06 11:47:12 --> Language Class Initialized
INFO - 2024-02-06 11:47:12 --> Loader Class Initialized
INFO - 2024-02-06 11:47:12 --> Helper loaded: url_helper
INFO - 2024-02-06 11:47:12 --> Helper loaded: file_helper
INFO - 2024-02-06 11:47:12 --> Helper loaded: form_helper
INFO - 2024-02-06 11:47:12 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:47:12 --> Controller Class Initialized
INFO - 2024-02-06 11:47:12 --> Form Validation Class Initialized
INFO - 2024-02-06 11:47:12 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:47:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-06 11:47:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-06 11:47:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-06 11:47:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-06 11:47:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-06 11:47:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-06 11:47:12 --> Final output sent to browser
DEBUG - 2024-02-06 11:47:12 --> Total execution time: 0.0374
ERROR - 2024-02-06 11:47:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:47:12 --> Config Class Initialized
INFO - 2024-02-06 11:47:12 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:47:12 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:47:12 --> Utf8 Class Initialized
INFO - 2024-02-06 11:47:12 --> URI Class Initialized
INFO - 2024-02-06 11:47:12 --> Router Class Initialized
INFO - 2024-02-06 11:47:12 --> Output Class Initialized
INFO - 2024-02-06 11:47:12 --> Security Class Initialized
DEBUG - 2024-02-06 11:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:47:12 --> Input Class Initialized
INFO - 2024-02-06 11:47:12 --> Language Class Initialized
INFO - 2024-02-06 11:47:12 --> Loader Class Initialized
INFO - 2024-02-06 11:47:12 --> Helper loaded: url_helper
INFO - 2024-02-06 11:47:12 --> Helper loaded: file_helper
INFO - 2024-02-06 11:47:12 --> Helper loaded: form_helper
INFO - 2024-02-06 11:47:12 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:47:12 --> Controller Class Initialized
INFO - 2024-02-06 11:47:12 --> Form Validation Class Initialized
INFO - 2024-02-06 11:47:12 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:47:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:48:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:48:09 --> Config Class Initialized
INFO - 2024-02-06 11:48:09 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:48:09 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:48:09 --> Utf8 Class Initialized
INFO - 2024-02-06 11:48:09 --> URI Class Initialized
INFO - 2024-02-06 11:48:09 --> Router Class Initialized
INFO - 2024-02-06 11:48:09 --> Output Class Initialized
INFO - 2024-02-06 11:48:09 --> Security Class Initialized
DEBUG - 2024-02-06 11:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:48:09 --> Input Class Initialized
INFO - 2024-02-06 11:48:09 --> Language Class Initialized
INFO - 2024-02-06 11:48:09 --> Loader Class Initialized
INFO - 2024-02-06 11:48:09 --> Helper loaded: url_helper
INFO - 2024-02-06 11:48:09 --> Helper loaded: file_helper
INFO - 2024-02-06 11:48:09 --> Helper loaded: form_helper
INFO - 2024-02-06 11:48:09 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:48:09 --> Controller Class Initialized
INFO - 2024-02-06 11:48:09 --> Form Validation Class Initialized
INFO - 2024-02-06 11:48:09 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:48:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-06 11:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-06 11:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-06 11:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-06 11:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-06 11:48:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-06 11:48:09 --> Final output sent to browser
DEBUG - 2024-02-06 11:48:09 --> Total execution time: 0.0196
ERROR - 2024-02-06 11:48:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:48:09 --> Config Class Initialized
INFO - 2024-02-06 11:48:09 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:48:09 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:48:09 --> Utf8 Class Initialized
INFO - 2024-02-06 11:48:09 --> URI Class Initialized
INFO - 2024-02-06 11:48:09 --> Router Class Initialized
INFO - 2024-02-06 11:48:09 --> Output Class Initialized
INFO - 2024-02-06 11:48:09 --> Security Class Initialized
DEBUG - 2024-02-06 11:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:48:09 --> Input Class Initialized
INFO - 2024-02-06 11:48:09 --> Language Class Initialized
INFO - 2024-02-06 11:48:09 --> Loader Class Initialized
INFO - 2024-02-06 11:48:09 --> Helper loaded: url_helper
INFO - 2024-02-06 11:48:09 --> Helper loaded: file_helper
INFO - 2024-02-06 11:48:09 --> Helper loaded: form_helper
INFO - 2024-02-06 11:48:09 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:48:09 --> Controller Class Initialized
INFO - 2024-02-06 11:48:09 --> Form Validation Class Initialized
INFO - 2024-02-06 11:48:09 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:48:09 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:48:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:48:28 --> Config Class Initialized
INFO - 2024-02-06 11:48:28 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:48:28 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:48:28 --> Utf8 Class Initialized
INFO - 2024-02-06 11:48:28 --> URI Class Initialized
INFO - 2024-02-06 11:48:28 --> Router Class Initialized
INFO - 2024-02-06 11:48:28 --> Output Class Initialized
INFO - 2024-02-06 11:48:28 --> Security Class Initialized
DEBUG - 2024-02-06 11:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:48:28 --> Input Class Initialized
INFO - 2024-02-06 11:48:28 --> Language Class Initialized
INFO - 2024-02-06 11:48:28 --> Loader Class Initialized
INFO - 2024-02-06 11:48:28 --> Helper loaded: url_helper
INFO - 2024-02-06 11:48:28 --> Helper loaded: file_helper
INFO - 2024-02-06 11:48:28 --> Helper loaded: form_helper
INFO - 2024-02-06 11:48:28 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:48:28 --> Controller Class Initialized
INFO - 2024-02-06 11:48:28 --> Form Validation Class Initialized
INFO - 2024-02-06 11:48:28 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:48:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-06 11:48:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-06 11:48:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-06 11:48:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-06 11:48:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-06 11:48:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-06 11:48:28 --> Final output sent to browser
DEBUG - 2024-02-06 11:48:28 --> Total execution time: 0.0332
ERROR - 2024-02-06 11:48:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:48:28 --> Config Class Initialized
INFO - 2024-02-06 11:48:28 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:48:28 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:48:28 --> Utf8 Class Initialized
INFO - 2024-02-06 11:48:28 --> URI Class Initialized
INFO - 2024-02-06 11:48:28 --> Router Class Initialized
INFO - 2024-02-06 11:48:28 --> Output Class Initialized
INFO - 2024-02-06 11:48:28 --> Security Class Initialized
DEBUG - 2024-02-06 11:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:48:28 --> Input Class Initialized
INFO - 2024-02-06 11:48:28 --> Language Class Initialized
INFO - 2024-02-06 11:48:28 --> Loader Class Initialized
INFO - 2024-02-06 11:48:28 --> Helper loaded: url_helper
INFO - 2024-02-06 11:48:28 --> Helper loaded: file_helper
INFO - 2024-02-06 11:48:28 --> Helper loaded: form_helper
INFO - 2024-02-06 11:48:28 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:48:28 --> Controller Class Initialized
INFO - 2024-02-06 11:48:28 --> Form Validation Class Initialized
INFO - 2024-02-06 11:48:28 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:48:28 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:48:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:48:38 --> Config Class Initialized
INFO - 2024-02-06 11:48:38 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:48:38 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:48:38 --> Utf8 Class Initialized
INFO - 2024-02-06 11:48:38 --> URI Class Initialized
INFO - 2024-02-06 11:48:38 --> Router Class Initialized
INFO - 2024-02-06 11:48:38 --> Output Class Initialized
INFO - 2024-02-06 11:48:38 --> Security Class Initialized
DEBUG - 2024-02-06 11:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:48:38 --> Input Class Initialized
INFO - 2024-02-06 11:48:38 --> Language Class Initialized
INFO - 2024-02-06 11:48:38 --> Loader Class Initialized
INFO - 2024-02-06 11:48:38 --> Helper loaded: url_helper
INFO - 2024-02-06 11:48:38 --> Helper loaded: file_helper
INFO - 2024-02-06 11:48:38 --> Helper loaded: form_helper
INFO - 2024-02-06 11:48:38 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:48:38 --> Controller Class Initialized
INFO - 2024-02-06 11:48:38 --> Form Validation Class Initialized
INFO - 2024-02-06 11:48:38 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:48:38 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:48:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:48:43 --> Config Class Initialized
INFO - 2024-02-06 11:48:43 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:48:43 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:48:43 --> Utf8 Class Initialized
INFO - 2024-02-06 11:48:43 --> URI Class Initialized
INFO - 2024-02-06 11:48:43 --> Router Class Initialized
INFO - 2024-02-06 11:48:43 --> Output Class Initialized
INFO - 2024-02-06 11:48:43 --> Security Class Initialized
DEBUG - 2024-02-06 11:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:48:43 --> Input Class Initialized
INFO - 2024-02-06 11:48:43 --> Language Class Initialized
INFO - 2024-02-06 11:48:43 --> Loader Class Initialized
INFO - 2024-02-06 11:48:43 --> Helper loaded: url_helper
INFO - 2024-02-06 11:48:43 --> Helper loaded: file_helper
INFO - 2024-02-06 11:48:43 --> Helper loaded: form_helper
INFO - 2024-02-06 11:48:43 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:48:43 --> Controller Class Initialized
INFO - 2024-02-06 11:48:43 --> Form Validation Class Initialized
INFO - 2024-02-06 11:48:43 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:48:43 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:48:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:48:48 --> Config Class Initialized
INFO - 2024-02-06 11:48:48 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:48:48 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:48:48 --> Utf8 Class Initialized
INFO - 2024-02-06 11:48:48 --> URI Class Initialized
INFO - 2024-02-06 11:48:48 --> Router Class Initialized
INFO - 2024-02-06 11:48:48 --> Output Class Initialized
INFO - 2024-02-06 11:48:48 --> Security Class Initialized
DEBUG - 2024-02-06 11:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:48:48 --> Input Class Initialized
INFO - 2024-02-06 11:48:48 --> Language Class Initialized
INFO - 2024-02-06 11:48:48 --> Loader Class Initialized
INFO - 2024-02-06 11:48:48 --> Helper loaded: url_helper
INFO - 2024-02-06 11:48:48 --> Helper loaded: file_helper
INFO - 2024-02-06 11:48:48 --> Helper loaded: form_helper
INFO - 2024-02-06 11:48:48 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:48:48 --> Controller Class Initialized
INFO - 2024-02-06 11:48:48 --> Form Validation Class Initialized
INFO - 2024-02-06 11:48:48 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:48:48 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:48:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:48:53 --> Config Class Initialized
INFO - 2024-02-06 11:48:53 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:48:53 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:48:53 --> Utf8 Class Initialized
INFO - 2024-02-06 11:48:53 --> URI Class Initialized
INFO - 2024-02-06 11:48:53 --> Router Class Initialized
INFO - 2024-02-06 11:48:53 --> Output Class Initialized
INFO - 2024-02-06 11:48:53 --> Security Class Initialized
DEBUG - 2024-02-06 11:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:48:53 --> Input Class Initialized
INFO - 2024-02-06 11:48:53 --> Language Class Initialized
INFO - 2024-02-06 11:48:53 --> Loader Class Initialized
INFO - 2024-02-06 11:48:53 --> Helper loaded: url_helper
INFO - 2024-02-06 11:48:53 --> Helper loaded: file_helper
INFO - 2024-02-06 11:48:53 --> Helper loaded: form_helper
INFO - 2024-02-06 11:48:53 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:48:53 --> Controller Class Initialized
INFO - 2024-02-06 11:48:53 --> Form Validation Class Initialized
INFO - 2024-02-06 11:48:53 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:48:53 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:48:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:48:58 --> Config Class Initialized
INFO - 2024-02-06 11:48:58 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:48:58 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:48:58 --> Utf8 Class Initialized
INFO - 2024-02-06 11:48:58 --> URI Class Initialized
INFO - 2024-02-06 11:48:58 --> Router Class Initialized
INFO - 2024-02-06 11:48:58 --> Output Class Initialized
INFO - 2024-02-06 11:48:58 --> Security Class Initialized
DEBUG - 2024-02-06 11:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:48:58 --> Input Class Initialized
INFO - 2024-02-06 11:48:58 --> Language Class Initialized
INFO - 2024-02-06 11:48:58 --> Loader Class Initialized
INFO - 2024-02-06 11:48:58 --> Helper loaded: url_helper
INFO - 2024-02-06 11:48:58 --> Helper loaded: file_helper
INFO - 2024-02-06 11:48:58 --> Helper loaded: form_helper
INFO - 2024-02-06 11:48:58 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:48:58 --> Controller Class Initialized
INFO - 2024-02-06 11:48:58 --> Form Validation Class Initialized
INFO - 2024-02-06 11:48:58 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:48:58 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:49:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:49:01 --> Config Class Initialized
INFO - 2024-02-06 11:49:01 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:49:01 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:49:01 --> Utf8 Class Initialized
INFO - 2024-02-06 11:49:01 --> URI Class Initialized
INFO - 2024-02-06 11:49:01 --> Router Class Initialized
INFO - 2024-02-06 11:49:01 --> Output Class Initialized
INFO - 2024-02-06 11:49:01 --> Security Class Initialized
DEBUG - 2024-02-06 11:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:49:01 --> Input Class Initialized
INFO - 2024-02-06 11:49:01 --> Language Class Initialized
INFO - 2024-02-06 11:49:01 --> Loader Class Initialized
INFO - 2024-02-06 11:49:01 --> Helper loaded: url_helper
INFO - 2024-02-06 11:49:01 --> Helper loaded: file_helper
INFO - 2024-02-06 11:49:01 --> Helper loaded: form_helper
INFO - 2024-02-06 11:49:01 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:49:01 --> Controller Class Initialized
INFO - 2024-02-06 11:49:01 --> Form Validation Class Initialized
INFO - 2024-02-06 11:49:01 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:49:01 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:49:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:49:04 --> Config Class Initialized
INFO - 2024-02-06 11:49:04 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:49:04 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:49:04 --> Utf8 Class Initialized
INFO - 2024-02-06 11:49:04 --> URI Class Initialized
INFO - 2024-02-06 11:49:04 --> Router Class Initialized
INFO - 2024-02-06 11:49:04 --> Output Class Initialized
INFO - 2024-02-06 11:49:04 --> Security Class Initialized
DEBUG - 2024-02-06 11:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:49:04 --> Input Class Initialized
INFO - 2024-02-06 11:49:04 --> Language Class Initialized
INFO - 2024-02-06 11:49:04 --> Loader Class Initialized
INFO - 2024-02-06 11:49:04 --> Helper loaded: url_helper
INFO - 2024-02-06 11:49:04 --> Helper loaded: file_helper
INFO - 2024-02-06 11:49:04 --> Helper loaded: form_helper
INFO - 2024-02-06 11:49:04 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:49:04 --> Controller Class Initialized
INFO - 2024-02-06 11:49:04 --> Form Validation Class Initialized
INFO - 2024-02-06 11:49:04 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:49:04 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:49:08 --> Config Class Initialized
INFO - 2024-02-06 11:49:08 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:49:08 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:49:08 --> Utf8 Class Initialized
INFO - 2024-02-06 11:49:08 --> URI Class Initialized
INFO - 2024-02-06 11:49:08 --> Router Class Initialized
INFO - 2024-02-06 11:49:08 --> Output Class Initialized
INFO - 2024-02-06 11:49:08 --> Security Class Initialized
DEBUG - 2024-02-06 11:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:49:08 --> Input Class Initialized
INFO - 2024-02-06 11:49:08 --> Language Class Initialized
INFO - 2024-02-06 11:49:08 --> Loader Class Initialized
INFO - 2024-02-06 11:49:08 --> Helper loaded: url_helper
INFO - 2024-02-06 11:49:08 --> Helper loaded: file_helper
INFO - 2024-02-06 11:49:08 --> Helper loaded: form_helper
INFO - 2024-02-06 11:49:08 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:49:08 --> Controller Class Initialized
INFO - 2024-02-06 11:49:08 --> Form Validation Class Initialized
INFO - 2024-02-06 11:49:08 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:49:08 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 11:49:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 11:49:10 --> Config Class Initialized
INFO - 2024-02-06 11:49:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 11:49:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 11:49:10 --> Utf8 Class Initialized
INFO - 2024-02-06 11:49:10 --> URI Class Initialized
INFO - 2024-02-06 11:49:10 --> Router Class Initialized
INFO - 2024-02-06 11:49:10 --> Output Class Initialized
INFO - 2024-02-06 11:49:10 --> Security Class Initialized
DEBUG - 2024-02-06 11:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 11:49:10 --> Input Class Initialized
INFO - 2024-02-06 11:49:10 --> Language Class Initialized
INFO - 2024-02-06 11:49:10 --> Loader Class Initialized
INFO - 2024-02-06 11:49:10 --> Helper loaded: url_helper
INFO - 2024-02-06 11:49:10 --> Helper loaded: file_helper
INFO - 2024-02-06 11:49:10 --> Helper loaded: form_helper
INFO - 2024-02-06 11:49:10 --> Database Driver Class Initialized
DEBUG - 2024-02-06 11:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 11:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 11:49:10 --> Controller Class Initialized
INFO - 2024-02-06 11:49:10 --> Form Validation Class Initialized
INFO - 2024-02-06 11:49:10 --> Model "MasterModel" initialized
INFO - 2024-02-06 11:49:10 --> Model "UserMasterModel" initialized
ERROR - 2024-02-06 17:12:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 17:12:33 --> Config Class Initialized
INFO - 2024-02-06 17:12:33 --> Hooks Class Initialized
DEBUG - 2024-02-06 17:12:33 --> UTF-8 Support Enabled
INFO - 2024-02-06 17:12:33 --> Utf8 Class Initialized
INFO - 2024-02-06 17:12:33 --> URI Class Initialized
INFO - 2024-02-06 17:12:33 --> Router Class Initialized
INFO - 2024-02-06 17:12:33 --> Output Class Initialized
INFO - 2024-02-06 17:12:33 --> Security Class Initialized
DEBUG - 2024-02-06 17:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 17:12:33 --> Input Class Initialized
INFO - 2024-02-06 17:12:33 --> Language Class Initialized
INFO - 2024-02-06 17:12:33 --> Loader Class Initialized
INFO - 2024-02-06 17:12:33 --> Helper loaded: url_helper
INFO - 2024-02-06 17:12:33 --> Helper loaded: file_helper
INFO - 2024-02-06 17:12:33 --> Helper loaded: form_helper
INFO - 2024-02-06 17:12:33 --> Database Driver Class Initialized
DEBUG - 2024-02-06 17:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 17:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 17:12:33 --> Controller Class Initialized
INFO - 2024-02-06 17:12:33 --> Model "LoginModel" initialized
INFO - 2024-02-06 17:12:33 --> Form Validation Class Initialized
ERROR - 2024-02-06 17:12:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 17:12:34 --> Config Class Initialized
INFO - 2024-02-06 17:12:34 --> Hooks Class Initialized
DEBUG - 2024-02-06 17:12:34 --> UTF-8 Support Enabled
INFO - 2024-02-06 17:12:34 --> Utf8 Class Initialized
INFO - 2024-02-06 17:12:34 --> URI Class Initialized
INFO - 2024-02-06 17:12:34 --> Router Class Initialized
INFO - 2024-02-06 17:12:34 --> Output Class Initialized
INFO - 2024-02-06 17:12:34 --> Security Class Initialized
DEBUG - 2024-02-06 17:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 17:12:34 --> Input Class Initialized
INFO - 2024-02-06 17:12:34 --> Language Class Initialized
INFO - 2024-02-06 17:12:34 --> Loader Class Initialized
INFO - 2024-02-06 17:12:34 --> Helper loaded: url_helper
INFO - 2024-02-06 17:12:34 --> Helper loaded: file_helper
INFO - 2024-02-06 17:12:34 --> Helper loaded: form_helper
INFO - 2024-02-06 17:12:34 --> Database Driver Class Initialized
DEBUG - 2024-02-06 17:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 17:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 17:12:34 --> Controller Class Initialized
INFO - 2024-02-06 17:12:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-06 17:12:34 --> Final output sent to browser
DEBUG - 2024-02-06 17:12:34 --> Total execution time: 0.0184
ERROR - 2024-02-06 18:41:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 18:41:51 --> Config Class Initialized
INFO - 2024-02-06 18:41:51 --> Hooks Class Initialized
DEBUG - 2024-02-06 18:41:51 --> UTF-8 Support Enabled
INFO - 2024-02-06 18:41:51 --> Utf8 Class Initialized
INFO - 2024-02-06 18:41:51 --> URI Class Initialized
INFO - 2024-02-06 18:41:51 --> Router Class Initialized
INFO - 2024-02-06 18:41:51 --> Output Class Initialized
INFO - 2024-02-06 18:41:51 --> Security Class Initialized
DEBUG - 2024-02-06 18:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 18:41:51 --> Input Class Initialized
INFO - 2024-02-06 18:41:51 --> Language Class Initialized
INFO - 2024-02-06 18:41:51 --> Loader Class Initialized
INFO - 2024-02-06 18:41:51 --> Helper loaded: url_helper
INFO - 2024-02-06 18:41:51 --> Helper loaded: file_helper
INFO - 2024-02-06 18:41:52 --> Helper loaded: form_helper
INFO - 2024-02-06 18:41:52 --> Database Driver Class Initialized
DEBUG - 2024-02-06 18:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 18:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 18:41:52 --> Controller Class Initialized
INFO - 2024-02-06 18:41:52 --> Model "LoginModel" initialized
INFO - 2024-02-06 18:41:52 --> Form Validation Class Initialized
ERROR - 2024-02-06 18:41:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 18:41:52 --> Config Class Initialized
INFO - 2024-02-06 18:41:52 --> Hooks Class Initialized
DEBUG - 2024-02-06 18:41:52 --> UTF-8 Support Enabled
INFO - 2024-02-06 18:41:52 --> Utf8 Class Initialized
INFO - 2024-02-06 18:41:52 --> URI Class Initialized
INFO - 2024-02-06 18:41:52 --> Router Class Initialized
INFO - 2024-02-06 18:41:52 --> Output Class Initialized
INFO - 2024-02-06 18:41:52 --> Security Class Initialized
DEBUG - 2024-02-06 18:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 18:41:52 --> Input Class Initialized
INFO - 2024-02-06 18:41:52 --> Language Class Initialized
INFO - 2024-02-06 18:41:52 --> Loader Class Initialized
INFO - 2024-02-06 18:41:52 --> Helper loaded: url_helper
INFO - 2024-02-06 18:41:52 --> Helper loaded: file_helper
INFO - 2024-02-06 18:41:52 --> Helper loaded: form_helper
INFO - 2024-02-06 18:41:52 --> Database Driver Class Initialized
DEBUG - 2024-02-06 18:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 18:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 18:41:52 --> Controller Class Initialized
INFO - 2024-02-06 18:41:52 --> Form Validation Class Initialized
INFO - 2024-02-06 18:41:52 --> Model "MasterModel" initialized
INFO - 2024-02-06 18:41:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-06 18:41:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-06 18:41:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-06 18:41:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-06 18:41:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-06 18:41:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-06 18:41:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-06 18:41:52 --> Final output sent to browser
DEBUG - 2024-02-06 18:41:52 --> Total execution time: 0.0313
ERROR - 2024-02-06 18:41:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-06 18:41:53 --> Config Class Initialized
INFO - 2024-02-06 18:41:53 --> Hooks Class Initialized
DEBUG - 2024-02-06 18:41:53 --> UTF-8 Support Enabled
INFO - 2024-02-06 18:41:53 --> Utf8 Class Initialized
INFO - 2024-02-06 18:41:53 --> URI Class Initialized
INFO - 2024-02-06 18:41:53 --> Router Class Initialized
INFO - 2024-02-06 18:41:53 --> Output Class Initialized
INFO - 2024-02-06 18:41:53 --> Security Class Initialized
DEBUG - 2024-02-06 18:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 18:41:53 --> Input Class Initialized
INFO - 2024-02-06 18:41:53 --> Language Class Initialized
INFO - 2024-02-06 18:41:53 --> Loader Class Initialized
INFO - 2024-02-06 18:41:53 --> Helper loaded: url_helper
INFO - 2024-02-06 18:41:53 --> Helper loaded: file_helper
INFO - 2024-02-06 18:41:53 --> Helper loaded: form_helper
INFO - 2024-02-06 18:41:53 --> Database Driver Class Initialized
DEBUG - 2024-02-06 18:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 18:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 18:41:53 --> Controller Class Initialized
INFO - 2024-02-06 18:41:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-06 18:41:53 --> Final output sent to browser
DEBUG - 2024-02-06 18:41:53 --> Total execution time: 0.0239
