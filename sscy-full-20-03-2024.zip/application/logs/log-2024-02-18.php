<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-18 11:09:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:09:19 --> Config Class Initialized
INFO - 2024-02-18 11:09:19 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:09:19 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:09:19 --> Utf8 Class Initialized
INFO - 2024-02-18 11:09:19 --> URI Class Initialized
INFO - 2024-02-18 11:09:19 --> Router Class Initialized
INFO - 2024-02-18 11:09:19 --> Output Class Initialized
INFO - 2024-02-18 11:09:19 --> Security Class Initialized
DEBUG - 2024-02-18 11:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:09:19 --> Input Class Initialized
INFO - 2024-02-18 11:09:19 --> Language Class Initialized
INFO - 2024-02-18 11:09:19 --> Loader Class Initialized
INFO - 2024-02-18 11:09:19 --> Helper loaded: url_helper
INFO - 2024-02-18 11:09:19 --> Helper loaded: file_helper
INFO - 2024-02-18 11:09:19 --> Helper loaded: form_helper
INFO - 2024-02-18 11:09:19 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:09:19 --> Controller Class Initialized
INFO - 2024-02-18 11:09:19 --> Model "LoginModel" initialized
INFO - 2024-02-18 11:09:19 --> Form Validation Class Initialized
INFO - 2024-02-18 11:09:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-18 11:09:19 --> Final output sent to browser
DEBUG - 2024-02-18 11:09:19 --> Total execution time: 0.0535
ERROR - 2024-02-18 11:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:09:26 --> Config Class Initialized
INFO - 2024-02-18 11:09:26 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:09:26 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:09:26 --> Utf8 Class Initialized
INFO - 2024-02-18 11:09:26 --> URI Class Initialized
INFO - 2024-02-18 11:09:26 --> Router Class Initialized
INFO - 2024-02-18 11:09:26 --> Output Class Initialized
INFO - 2024-02-18 11:09:26 --> Security Class Initialized
DEBUG - 2024-02-18 11:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:09:26 --> Input Class Initialized
INFO - 2024-02-18 11:09:26 --> Language Class Initialized
INFO - 2024-02-18 11:09:26 --> Loader Class Initialized
INFO - 2024-02-18 11:09:26 --> Helper loaded: url_helper
INFO - 2024-02-18 11:09:26 --> Helper loaded: file_helper
INFO - 2024-02-18 11:09:26 --> Helper loaded: form_helper
INFO - 2024-02-18 11:09:26 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:09:26 --> Controller Class Initialized
INFO - 2024-02-18 11:09:26 --> Model "LoginModel" initialized
INFO - 2024-02-18 11:09:26 --> Form Validation Class Initialized
INFO - 2024-02-18 11:09:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-18 11:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:09:26 --> Config Class Initialized
INFO - 2024-02-18 11:09:26 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:09:26 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:09:26 --> Utf8 Class Initialized
INFO - 2024-02-18 11:09:26 --> URI Class Initialized
INFO - 2024-02-18 11:09:26 --> Router Class Initialized
INFO - 2024-02-18 11:09:26 --> Output Class Initialized
INFO - 2024-02-18 11:09:26 --> Security Class Initialized
DEBUG - 2024-02-18 11:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:09:26 --> Input Class Initialized
INFO - 2024-02-18 11:09:26 --> Language Class Initialized
INFO - 2024-02-18 11:09:26 --> Loader Class Initialized
INFO - 2024-02-18 11:09:26 --> Helper loaded: url_helper
INFO - 2024-02-18 11:09:26 --> Helper loaded: file_helper
INFO - 2024-02-18 11:09:26 --> Helper loaded: form_helper
INFO - 2024-02-18 11:09:26 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:09:26 --> Controller Class Initialized
INFO - 2024-02-18 11:09:26 --> Form Validation Class Initialized
INFO - 2024-02-18 11:09:26 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:09:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:09:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:09:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-18 11:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:09:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-18 11:09:26 --> Final output sent to browser
DEBUG - 2024-02-18 11:09:26 --> Total execution time: 0.0430
ERROR - 2024-02-18 11:09:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:09:30 --> Config Class Initialized
INFO - 2024-02-18 11:09:30 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:09:30 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:09:30 --> Utf8 Class Initialized
INFO - 2024-02-18 11:09:30 --> URI Class Initialized
INFO - 2024-02-18 11:09:30 --> Router Class Initialized
INFO - 2024-02-18 11:09:30 --> Output Class Initialized
INFO - 2024-02-18 11:09:30 --> Security Class Initialized
DEBUG - 2024-02-18 11:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:09:30 --> Input Class Initialized
INFO - 2024-02-18 11:09:30 --> Language Class Initialized
INFO - 2024-02-18 11:09:30 --> Loader Class Initialized
INFO - 2024-02-18 11:09:30 --> Helper loaded: url_helper
INFO - 2024-02-18 11:09:30 --> Helper loaded: file_helper
INFO - 2024-02-18 11:09:30 --> Helper loaded: form_helper
INFO - 2024-02-18 11:09:30 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:09:30 --> Controller Class Initialized
INFO - 2024-02-18 11:09:30 --> Form Validation Class Initialized
INFO - 2024-02-18 11:09:30 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:09:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:09:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:09:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:09:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:09:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:09:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:09:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:09:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-18 11:09:30 --> Final output sent to browser
DEBUG - 2024-02-18 11:09:30 --> Total execution time: 0.0273
ERROR - 2024-02-18 11:09:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:09:30 --> Config Class Initialized
INFO - 2024-02-18 11:09:30 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:09:30 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:09:30 --> Utf8 Class Initialized
INFO - 2024-02-18 11:09:30 --> URI Class Initialized
INFO - 2024-02-18 11:09:30 --> Router Class Initialized
INFO - 2024-02-18 11:09:30 --> Output Class Initialized
INFO - 2024-02-18 11:09:30 --> Security Class Initialized
DEBUG - 2024-02-18 11:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:09:30 --> Input Class Initialized
INFO - 2024-02-18 11:09:30 --> Language Class Initialized
INFO - 2024-02-18 11:09:30 --> Loader Class Initialized
INFO - 2024-02-18 11:09:30 --> Helper loaded: url_helper
INFO - 2024-02-18 11:09:30 --> Helper loaded: file_helper
INFO - 2024-02-18 11:09:30 --> Helper loaded: form_helper
INFO - 2024-02-18 11:09:30 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:09:30 --> Controller Class Initialized
INFO - 2024-02-18 11:09:30 --> Form Validation Class Initialized
INFO - 2024-02-18 11:09:30 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:09:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:09:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:09:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:09:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:09:35 --> Config Class Initialized
INFO - 2024-02-18 11:09:35 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:09:35 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:09:35 --> Utf8 Class Initialized
INFO - 2024-02-18 11:09:35 --> URI Class Initialized
INFO - 2024-02-18 11:09:35 --> Router Class Initialized
INFO - 2024-02-18 11:09:35 --> Output Class Initialized
INFO - 2024-02-18 11:09:35 --> Security Class Initialized
DEBUG - 2024-02-18 11:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:09:35 --> Input Class Initialized
INFO - 2024-02-18 11:09:35 --> Language Class Initialized
INFO - 2024-02-18 11:09:35 --> Loader Class Initialized
INFO - 2024-02-18 11:09:35 --> Helper loaded: url_helper
INFO - 2024-02-18 11:09:35 --> Helper loaded: file_helper
INFO - 2024-02-18 11:09:35 --> Helper loaded: form_helper
INFO - 2024-02-18 11:09:35 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:09:35 --> Controller Class Initialized
INFO - 2024-02-18 11:09:35 --> Form Validation Class Initialized
INFO - 2024-02-18 11:09:35 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:09:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:09:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:09:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:09:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-18 11:09:35 --> Final output sent to browser
DEBUG - 2024-02-18 11:09:35 --> Total execution time: 0.0312
ERROR - 2024-02-18 11:10:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:10:14 --> Config Class Initialized
INFO - 2024-02-18 11:10:14 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:10:14 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:10:14 --> Utf8 Class Initialized
INFO - 2024-02-18 11:10:14 --> URI Class Initialized
INFO - 2024-02-18 11:10:14 --> Router Class Initialized
INFO - 2024-02-18 11:10:14 --> Output Class Initialized
INFO - 2024-02-18 11:10:14 --> Security Class Initialized
DEBUG - 2024-02-18 11:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:10:14 --> Input Class Initialized
INFO - 2024-02-18 11:10:14 --> Language Class Initialized
INFO - 2024-02-18 11:10:14 --> Loader Class Initialized
INFO - 2024-02-18 11:10:14 --> Helper loaded: url_helper
INFO - 2024-02-18 11:10:14 --> Helper loaded: file_helper
INFO - 2024-02-18 11:10:14 --> Helper loaded: form_helper
INFO - 2024-02-18 11:10:14 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:10:14 --> Controller Class Initialized
INFO - 2024-02-18 11:10:14 --> Form Validation Class Initialized
INFO - 2024-02-18 11:10:14 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:10:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:10:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:10:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:10:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:10:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:10:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:10:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:10:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-18 11:10:14 --> Final output sent to browser
DEBUG - 2024-02-18 11:10:14 --> Total execution time: 0.0543
ERROR - 2024-02-18 11:37:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:37:09 --> Config Class Initialized
INFO - 2024-02-18 11:37:09 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:09 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:09 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:09 --> URI Class Initialized
INFO - 2024-02-18 11:37:09 --> Router Class Initialized
INFO - 2024-02-18 11:37:09 --> Output Class Initialized
INFO - 2024-02-18 11:37:09 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:09 --> Input Class Initialized
INFO - 2024-02-18 11:37:09 --> Language Class Initialized
INFO - 2024-02-18 11:37:09 --> Loader Class Initialized
INFO - 2024-02-18 11:37:09 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:09 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:09 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:09 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:09 --> Controller Class Initialized
INFO - 2024-02-18 11:37:09 --> Model "LoginModel" initialized
INFO - 2024-02-18 11:37:09 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-18 11:37:09 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:09 --> Total execution time: 0.0413
ERROR - 2024-02-18 11:37:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:37:24 --> Config Class Initialized
INFO - 2024-02-18 11:37:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:24 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:24 --> URI Class Initialized
INFO - 2024-02-18 11:37:24 --> Router Class Initialized
INFO - 2024-02-18 11:37:24 --> Output Class Initialized
INFO - 2024-02-18 11:37:24 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:24 --> Input Class Initialized
INFO - 2024-02-18 11:37:24 --> Language Class Initialized
INFO - 2024-02-18 11:37:24 --> Loader Class Initialized
INFO - 2024-02-18 11:37:24 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:24 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:24 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:24 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:24 --> Controller Class Initialized
INFO - 2024-02-18 11:37:24 --> Model "LoginModel" initialized
INFO - 2024-02-18 11:37:24 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-18 11:37:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:37:24 --> Config Class Initialized
INFO - 2024-02-18 11:37:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:24 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:24 --> URI Class Initialized
INFO - 2024-02-18 11:37:24 --> Router Class Initialized
INFO - 2024-02-18 11:37:24 --> Output Class Initialized
INFO - 2024-02-18 11:37:24 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:24 --> Input Class Initialized
INFO - 2024-02-18 11:37:24 --> Language Class Initialized
INFO - 2024-02-18 11:37:24 --> Loader Class Initialized
INFO - 2024-02-18 11:37:24 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:24 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:24 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:24 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:24 --> Controller Class Initialized
INFO - 2024-02-18 11:37:24 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:24 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:37:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:37:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:37:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:37:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:37:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-18 11:37:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:37:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:37:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:37:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-18 11:37:24 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:24 --> Total execution time: 0.0216
ERROR - 2024-02-18 11:37:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:37:30 --> Config Class Initialized
INFO - 2024-02-18 11:37:30 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:30 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:30 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:30 --> URI Class Initialized
INFO - 2024-02-18 11:37:30 --> Router Class Initialized
INFO - 2024-02-18 11:37:30 --> Output Class Initialized
INFO - 2024-02-18 11:37:30 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:30 --> Input Class Initialized
INFO - 2024-02-18 11:37:30 --> Language Class Initialized
INFO - 2024-02-18 11:37:30 --> Loader Class Initialized
INFO - 2024-02-18 11:37:30 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:30 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:30 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:30 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:30 --> Controller Class Initialized
INFO - 2024-02-18 11:37:30 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:30 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:37:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:37:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:37:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:37:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:37:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-18 11:37:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:37:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:37:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:37:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-18 11:37:30 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:30 --> Total execution time: 0.0340
ERROR - 2024-02-18 11:37:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:37:32 --> Config Class Initialized
INFO - 2024-02-18 11:37:32 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:32 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:32 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:32 --> URI Class Initialized
INFO - 2024-02-18 11:37:32 --> Router Class Initialized
INFO - 2024-02-18 11:37:32 --> Output Class Initialized
INFO - 2024-02-18 11:37:32 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:32 --> Input Class Initialized
INFO - 2024-02-18 11:37:32 --> Language Class Initialized
INFO - 2024-02-18 11:37:32 --> Loader Class Initialized
INFO - 2024-02-18 11:37:32 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:32 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:32 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:32 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:32 --> Controller Class Initialized
INFO - 2024-02-18 11:37:32 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:32 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:37:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:37:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:37:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:37:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:37:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-18 11:37:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:37:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:37:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:37:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-18 11:37:32 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:32 --> Total execution time: 0.0395
ERROR - 2024-02-18 11:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:37:37 --> Config Class Initialized
INFO - 2024-02-18 11:37:37 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:37 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:37 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:37 --> URI Class Initialized
INFO - 2024-02-18 11:37:37 --> Router Class Initialized
INFO - 2024-02-18 11:37:37 --> Output Class Initialized
INFO - 2024-02-18 11:37:37 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:37 --> Input Class Initialized
INFO - 2024-02-18 11:37:37 --> Language Class Initialized
INFO - 2024-02-18 11:37:37 --> Loader Class Initialized
INFO - 2024-02-18 11:37:37 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:37 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:37 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:37 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:37 --> Controller Class Initialized
INFO - 2024-02-18 11:37:37 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:37 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:37:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:37:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:37:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:37:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:37:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:37:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:37:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:37:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/index.php
INFO - 2024-02-18 11:37:37 --> Final output sent to browser
DEBUG - 2024-02-18 11:37:37 --> Total execution time: 0.0337
ERROR - 2024-02-18 11:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:37:37 --> Config Class Initialized
INFO - 2024-02-18 11:37:37 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:37:37 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:37:37 --> Utf8 Class Initialized
INFO - 2024-02-18 11:37:37 --> URI Class Initialized
INFO - 2024-02-18 11:37:37 --> Router Class Initialized
INFO - 2024-02-18 11:37:37 --> Output Class Initialized
INFO - 2024-02-18 11:37:37 --> Security Class Initialized
DEBUG - 2024-02-18 11:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:37:37 --> Input Class Initialized
INFO - 2024-02-18 11:37:37 --> Language Class Initialized
INFO - 2024-02-18 11:37:37 --> Loader Class Initialized
INFO - 2024-02-18 11:37:37 --> Helper loaded: url_helper
INFO - 2024-02-18 11:37:37 --> Helper loaded: file_helper
INFO - 2024-02-18 11:37:37 --> Helper loaded: form_helper
INFO - 2024-02-18 11:37:37 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:37:37 --> Controller Class Initialized
INFO - 2024-02-18 11:37:37 --> Form Validation Class Initialized
INFO - 2024-02-18 11:37:37 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:37:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:37:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:37:37 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:37:37 --> Severity: Notice --> Undefined property: ItemGroup::$itemGroup D:\xampp\htdocs\sscy\application\controllers\app\ItemGroup.php 18
ERROR - 2024-02-18 11:37:37 --> Severity: error --> Exception: Call to a member function getDTRows() on null D:\xampp\htdocs\sscy\application\controllers\app\ItemGroup.php 18
ERROR - 2024-02-18 11:38:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:38:02 --> Config Class Initialized
INFO - 2024-02-18 11:38:02 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:02 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:02 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:02 --> URI Class Initialized
INFO - 2024-02-18 11:38:02 --> Router Class Initialized
INFO - 2024-02-18 11:38:02 --> Output Class Initialized
INFO - 2024-02-18 11:38:02 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:02 --> Input Class Initialized
INFO - 2024-02-18 11:38:02 --> Language Class Initialized
INFO - 2024-02-18 11:38:02 --> Loader Class Initialized
INFO - 2024-02-18 11:38:02 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:02 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:02 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:02 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:02 --> Controller Class Initialized
INFO - 2024-02-18 11:38:02 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:02 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:38:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:38:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:38:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:38:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:38:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:38:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:38:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:38:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/index.php
INFO - 2024-02-18 11:38:02 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:02 --> Total execution time: 0.0277
ERROR - 2024-02-18 11:38:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:38:16 --> Config Class Initialized
INFO - 2024-02-18 11:38:16 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:16 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:16 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:16 --> URI Class Initialized
INFO - 2024-02-18 11:38:16 --> Router Class Initialized
INFO - 2024-02-18 11:38:16 --> Output Class Initialized
INFO - 2024-02-18 11:38:16 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:16 --> Input Class Initialized
INFO - 2024-02-18 11:38:16 --> Language Class Initialized
INFO - 2024-02-18 11:38:16 --> Loader Class Initialized
INFO - 2024-02-18 11:38:16 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:16 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:16 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:16 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:16 --> Controller Class Initialized
INFO - 2024-02-18 11:38:16 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:16 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:38:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:38:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:38:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:38:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:38:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:38:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:38:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:38:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/index.php
INFO - 2024-02-18 11:38:16 --> Final output sent to browser
DEBUG - 2024-02-18 11:38:16 --> Total execution time: 0.0371
ERROR - 2024-02-18 11:38:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:38:16 --> Config Class Initialized
INFO - 2024-02-18 11:38:16 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:38:16 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:38:16 --> Utf8 Class Initialized
INFO - 2024-02-18 11:38:16 --> URI Class Initialized
INFO - 2024-02-18 11:38:16 --> Router Class Initialized
INFO - 2024-02-18 11:38:16 --> Output Class Initialized
INFO - 2024-02-18 11:38:16 --> Security Class Initialized
DEBUG - 2024-02-18 11:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:38:16 --> Input Class Initialized
INFO - 2024-02-18 11:38:16 --> Language Class Initialized
INFO - 2024-02-18 11:38:16 --> Loader Class Initialized
INFO - 2024-02-18 11:38:16 --> Helper loaded: url_helper
INFO - 2024-02-18 11:38:16 --> Helper loaded: file_helper
INFO - 2024-02-18 11:38:16 --> Helper loaded: form_helper
INFO - 2024-02-18 11:38:16 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:38:16 --> Controller Class Initialized
INFO - 2024-02-18 11:38:16 --> Form Validation Class Initialized
INFO - 2024-02-18 11:38:16 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:38:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:38:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:38:16 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:38:16 --> Severity: Notice --> Undefined property: ItemGroup::$itemGroup D:\xampp\htdocs\sscy\application\controllers\app\ItemGroup.php 18
ERROR - 2024-02-18 11:38:16 --> Severity: error --> Exception: Call to a member function getDTRows() on null D:\xampp\htdocs\sscy\application\controllers\app\ItemGroup.php 18
ERROR - 2024-02-18 11:39:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:39:18 --> Config Class Initialized
INFO - 2024-02-18 11:39:18 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:18 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:18 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:18 --> URI Class Initialized
INFO - 2024-02-18 11:39:18 --> Router Class Initialized
INFO - 2024-02-18 11:39:18 --> Output Class Initialized
INFO - 2024-02-18 11:39:18 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:18 --> Input Class Initialized
INFO - 2024-02-18 11:39:18 --> Language Class Initialized
INFO - 2024-02-18 11:39:18 --> Loader Class Initialized
INFO - 2024-02-18 11:39:18 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:18 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:18 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:18 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:18 --> Controller Class Initialized
INFO - 2024-02-18 11:39:18 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:18 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:39:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:39:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:39:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:39:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:39:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:39:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:39:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:39:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:39:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/index.php
INFO - 2024-02-18 11:39:18 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:18 --> Total execution time: 0.0526
ERROR - 2024-02-18 11:39:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:39:20 --> Config Class Initialized
INFO - 2024-02-18 11:39:20 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:20 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:20 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:20 --> URI Class Initialized
INFO - 2024-02-18 11:39:20 --> Router Class Initialized
INFO - 2024-02-18 11:39:20 --> Output Class Initialized
INFO - 2024-02-18 11:39:20 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:20 --> Input Class Initialized
INFO - 2024-02-18 11:39:20 --> Language Class Initialized
INFO - 2024-02-18 11:39:20 --> Loader Class Initialized
INFO - 2024-02-18 11:39:20 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:20 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:20 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:20 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:20 --> Controller Class Initialized
INFO - 2024-02-18 11:39:20 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:20 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:39:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:39:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:39:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:39:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:39:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:39:31 --> Config Class Initialized
INFO - 2024-02-18 11:39:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:31 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:31 --> URI Class Initialized
INFO - 2024-02-18 11:39:31 --> Router Class Initialized
INFO - 2024-02-18 11:39:31 --> Output Class Initialized
INFO - 2024-02-18 11:39:31 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:31 --> Input Class Initialized
INFO - 2024-02-18 11:39:31 --> Language Class Initialized
INFO - 2024-02-18 11:39:31 --> Loader Class Initialized
INFO - 2024-02-18 11:39:31 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:31 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:31 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:31 --> Controller Class Initialized
INFO - 2024-02-18 11:39:31 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:31 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:39:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:39:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:39:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:39:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:39:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/form.php
INFO - 2024-02-18 11:39:31 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:31 --> Total execution time: 0.0297
ERROR - 2024-02-18 11:39:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:39:47 --> Config Class Initialized
INFO - 2024-02-18 11:39:47 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:47 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:47 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:47 --> URI Class Initialized
INFO - 2024-02-18 11:39:47 --> Router Class Initialized
INFO - 2024-02-18 11:39:47 --> Output Class Initialized
INFO - 2024-02-18 11:39:47 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:47 --> Input Class Initialized
INFO - 2024-02-18 11:39:47 --> Language Class Initialized
INFO - 2024-02-18 11:39:47 --> Loader Class Initialized
INFO - 2024-02-18 11:39:47 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:47 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:47 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:47 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:47 --> Controller Class Initialized
INFO - 2024-02-18 11:39:47 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:47 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:39:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:39:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:39:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:39:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:39:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:39:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:39:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:39:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:39:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/index.php
INFO - 2024-02-18 11:39:47 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:47 --> Total execution time: 0.0354
ERROR - 2024-02-18 11:39:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:39:48 --> Config Class Initialized
INFO - 2024-02-18 11:39:48 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:48 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:48 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:48 --> URI Class Initialized
INFO - 2024-02-18 11:39:48 --> Router Class Initialized
INFO - 2024-02-18 11:39:48 --> Output Class Initialized
INFO - 2024-02-18 11:39:48 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:48 --> Input Class Initialized
INFO - 2024-02-18 11:39:48 --> Language Class Initialized
INFO - 2024-02-18 11:39:48 --> Loader Class Initialized
INFO - 2024-02-18 11:39:48 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:48 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:48 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:48 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:48 --> Controller Class Initialized
INFO - 2024-02-18 11:39:48 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:48 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:39:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:39:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:39:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:39:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:39:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:39:51 --> Config Class Initialized
INFO - 2024-02-18 11:39:51 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:39:51 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:39:51 --> Utf8 Class Initialized
INFO - 2024-02-18 11:39:51 --> URI Class Initialized
INFO - 2024-02-18 11:39:51 --> Router Class Initialized
INFO - 2024-02-18 11:39:51 --> Output Class Initialized
INFO - 2024-02-18 11:39:51 --> Security Class Initialized
DEBUG - 2024-02-18 11:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:39:51 --> Input Class Initialized
INFO - 2024-02-18 11:39:51 --> Language Class Initialized
INFO - 2024-02-18 11:39:51 --> Loader Class Initialized
INFO - 2024-02-18 11:39:51 --> Helper loaded: url_helper
INFO - 2024-02-18 11:39:51 --> Helper loaded: file_helper
INFO - 2024-02-18 11:39:51 --> Helper loaded: form_helper
INFO - 2024-02-18 11:39:51 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:39:51 --> Controller Class Initialized
INFO - 2024-02-18 11:39:51 --> Form Validation Class Initialized
INFO - 2024-02-18 11:39:51 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:39:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:39:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:39:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:39:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:39:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/form.php
INFO - 2024-02-18 11:39:51 --> Final output sent to browser
DEBUG - 2024-02-18 11:39:51 --> Total execution time: 0.0459
ERROR - 2024-02-18 11:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:40:00 --> Config Class Initialized
INFO - 2024-02-18 11:40:00 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:40:00 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:40:00 --> Utf8 Class Initialized
INFO - 2024-02-18 11:40:00 --> URI Class Initialized
INFO - 2024-02-18 11:40:00 --> Router Class Initialized
INFO - 2024-02-18 11:40:00 --> Output Class Initialized
INFO - 2024-02-18 11:40:00 --> Security Class Initialized
DEBUG - 2024-02-18 11:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:40:00 --> Input Class Initialized
INFO - 2024-02-18 11:40:00 --> Language Class Initialized
INFO - 2024-02-18 11:40:00 --> Loader Class Initialized
INFO - 2024-02-18 11:40:00 --> Helper loaded: url_helper
INFO - 2024-02-18 11:40:00 --> Helper loaded: file_helper
INFO - 2024-02-18 11:40:00 --> Helper loaded: form_helper
INFO - 2024-02-18 11:40:00 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:40:00 --> Controller Class Initialized
INFO - 2024-02-18 11:40:00 --> Form Validation Class Initialized
INFO - 2024-02-18 11:40:00 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:40:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:40:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:40:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:40:00 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:40:00 --> Config Class Initialized
INFO - 2024-02-18 11:40:00 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:40:00 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:40:00 --> Utf8 Class Initialized
INFO - 2024-02-18 11:40:00 --> URI Class Initialized
INFO - 2024-02-18 11:40:00 --> Router Class Initialized
INFO - 2024-02-18 11:40:00 --> Output Class Initialized
INFO - 2024-02-18 11:40:00 --> Security Class Initialized
DEBUG - 2024-02-18 11:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:40:00 --> Input Class Initialized
INFO - 2024-02-18 11:40:00 --> Language Class Initialized
INFO - 2024-02-18 11:40:00 --> Loader Class Initialized
INFO - 2024-02-18 11:40:00 --> Helper loaded: url_helper
INFO - 2024-02-18 11:40:00 --> Helper loaded: file_helper
INFO - 2024-02-18 11:40:00 --> Helper loaded: form_helper
INFO - 2024-02-18 11:40:00 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:40:00 --> Controller Class Initialized
INFO - 2024-02-18 11:40:00 --> Form Validation Class Initialized
INFO - 2024-02-18 11:40:00 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:40:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:40:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:40:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:40:00 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:40:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:40:03 --> Config Class Initialized
INFO - 2024-02-18 11:40:03 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:40:03 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:40:03 --> Utf8 Class Initialized
INFO - 2024-02-18 11:40:03 --> URI Class Initialized
INFO - 2024-02-18 11:40:03 --> Router Class Initialized
INFO - 2024-02-18 11:40:03 --> Output Class Initialized
INFO - 2024-02-18 11:40:03 --> Security Class Initialized
DEBUG - 2024-02-18 11:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:40:03 --> Input Class Initialized
INFO - 2024-02-18 11:40:03 --> Language Class Initialized
INFO - 2024-02-18 11:40:03 --> Loader Class Initialized
INFO - 2024-02-18 11:40:03 --> Helper loaded: url_helper
INFO - 2024-02-18 11:40:03 --> Helper loaded: file_helper
INFO - 2024-02-18 11:40:03 --> Helper loaded: form_helper
INFO - 2024-02-18 11:40:03 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:40:03 --> Controller Class Initialized
INFO - 2024-02-18 11:40:03 --> Form Validation Class Initialized
INFO - 2024-02-18 11:40:03 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:40:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:40:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:40:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:40:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:40:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/form.php
INFO - 2024-02-18 11:40:03 --> Final output sent to browser
DEBUG - 2024-02-18 11:40:03 --> Total execution time: 0.0439
ERROR - 2024-02-18 11:40:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:40:11 --> Config Class Initialized
INFO - 2024-02-18 11:40:11 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:40:11 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:40:11 --> Utf8 Class Initialized
INFO - 2024-02-18 11:40:11 --> URI Class Initialized
INFO - 2024-02-18 11:40:11 --> Router Class Initialized
INFO - 2024-02-18 11:40:11 --> Output Class Initialized
INFO - 2024-02-18 11:40:11 --> Security Class Initialized
DEBUG - 2024-02-18 11:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:40:11 --> Input Class Initialized
INFO - 2024-02-18 11:40:11 --> Language Class Initialized
INFO - 2024-02-18 11:40:11 --> Loader Class Initialized
INFO - 2024-02-18 11:40:11 --> Helper loaded: url_helper
INFO - 2024-02-18 11:40:11 --> Helper loaded: file_helper
INFO - 2024-02-18 11:40:11 --> Helper loaded: form_helper
INFO - 2024-02-18 11:40:11 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:40:11 --> Controller Class Initialized
INFO - 2024-02-18 11:40:11 --> Form Validation Class Initialized
INFO - 2024-02-18 11:40:11 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:40:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:40:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:40:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:40:11 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:40:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:40:11 --> Config Class Initialized
INFO - 2024-02-18 11:40:11 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:40:11 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:40:11 --> Utf8 Class Initialized
INFO - 2024-02-18 11:40:11 --> URI Class Initialized
INFO - 2024-02-18 11:40:11 --> Router Class Initialized
INFO - 2024-02-18 11:40:11 --> Output Class Initialized
INFO - 2024-02-18 11:40:11 --> Security Class Initialized
DEBUG - 2024-02-18 11:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:40:11 --> Input Class Initialized
INFO - 2024-02-18 11:40:11 --> Language Class Initialized
INFO - 2024-02-18 11:40:11 --> Loader Class Initialized
INFO - 2024-02-18 11:40:11 --> Helper loaded: url_helper
INFO - 2024-02-18 11:40:11 --> Helper loaded: file_helper
INFO - 2024-02-18 11:40:11 --> Helper loaded: form_helper
INFO - 2024-02-18 11:40:11 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:40:11 --> Controller Class Initialized
INFO - 2024-02-18 11:40:11 --> Form Validation Class Initialized
INFO - 2024-02-18 11:40:11 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:40:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:40:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:40:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:40:11 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:40:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:40:15 --> Config Class Initialized
INFO - 2024-02-18 11:40:15 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:40:15 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:40:15 --> Utf8 Class Initialized
INFO - 2024-02-18 11:40:15 --> URI Class Initialized
INFO - 2024-02-18 11:40:15 --> Router Class Initialized
INFO - 2024-02-18 11:40:15 --> Output Class Initialized
INFO - 2024-02-18 11:40:15 --> Security Class Initialized
DEBUG - 2024-02-18 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:40:15 --> Input Class Initialized
INFO - 2024-02-18 11:40:15 --> Language Class Initialized
INFO - 2024-02-18 11:40:15 --> Loader Class Initialized
INFO - 2024-02-18 11:40:15 --> Helper loaded: url_helper
INFO - 2024-02-18 11:40:15 --> Helper loaded: file_helper
INFO - 2024-02-18 11:40:15 --> Helper loaded: form_helper
INFO - 2024-02-18 11:40:15 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:40:15 --> Controller Class Initialized
INFO - 2024-02-18 11:40:15 --> Form Validation Class Initialized
INFO - 2024-02-18 11:40:15 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:40:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:40:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:40:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:40:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:40:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_group/form.php
INFO - 2024-02-18 11:40:15 --> Final output sent to browser
DEBUG - 2024-02-18 11:40:15 --> Total execution time: 0.0550
ERROR - 2024-02-18 11:40:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:40:24 --> Config Class Initialized
INFO - 2024-02-18 11:40:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:40:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:40:24 --> Utf8 Class Initialized
INFO - 2024-02-18 11:40:24 --> URI Class Initialized
INFO - 2024-02-18 11:40:24 --> Router Class Initialized
INFO - 2024-02-18 11:40:24 --> Output Class Initialized
INFO - 2024-02-18 11:40:24 --> Security Class Initialized
DEBUG - 2024-02-18 11:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:40:24 --> Input Class Initialized
INFO - 2024-02-18 11:40:24 --> Language Class Initialized
INFO - 2024-02-18 11:40:24 --> Loader Class Initialized
INFO - 2024-02-18 11:40:24 --> Helper loaded: url_helper
INFO - 2024-02-18 11:40:24 --> Helper loaded: file_helper
INFO - 2024-02-18 11:40:24 --> Helper loaded: form_helper
INFO - 2024-02-18 11:40:24 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:40:24 --> Controller Class Initialized
INFO - 2024-02-18 11:40:24 --> Form Validation Class Initialized
INFO - 2024-02-18 11:40:24 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:40:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:40:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:40:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:40:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:40:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:40:24 --> Config Class Initialized
INFO - 2024-02-18 11:40:24 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:40:24 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:40:24 --> Utf8 Class Initialized
INFO - 2024-02-18 11:40:24 --> URI Class Initialized
INFO - 2024-02-18 11:40:24 --> Router Class Initialized
INFO - 2024-02-18 11:40:24 --> Output Class Initialized
INFO - 2024-02-18 11:40:24 --> Security Class Initialized
DEBUG - 2024-02-18 11:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:40:24 --> Input Class Initialized
INFO - 2024-02-18 11:40:24 --> Language Class Initialized
INFO - 2024-02-18 11:40:24 --> Loader Class Initialized
INFO - 2024-02-18 11:40:24 --> Helper loaded: url_helper
INFO - 2024-02-18 11:40:24 --> Helper loaded: file_helper
INFO - 2024-02-18 11:40:24 --> Helper loaded: form_helper
INFO - 2024-02-18 11:40:24 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:40:24 --> Controller Class Initialized
INFO - 2024-02-18 11:40:24 --> Form Validation Class Initialized
INFO - 2024-02-18 11:40:24 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:40:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:40:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:40:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:40:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:45:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:45:54 --> Config Class Initialized
INFO - 2024-02-18 11:45:54 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:45:54 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:45:54 --> Utf8 Class Initialized
INFO - 2024-02-18 11:45:54 --> URI Class Initialized
INFO - 2024-02-18 11:45:54 --> Router Class Initialized
INFO - 2024-02-18 11:45:54 --> Output Class Initialized
INFO - 2024-02-18 11:45:54 --> Security Class Initialized
DEBUG - 2024-02-18 11:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:45:54 --> Input Class Initialized
INFO - 2024-02-18 11:45:54 --> Language Class Initialized
INFO - 2024-02-18 11:45:54 --> Loader Class Initialized
INFO - 2024-02-18 11:45:54 --> Helper loaded: url_helper
INFO - 2024-02-18 11:45:54 --> Helper loaded: file_helper
INFO - 2024-02-18 11:45:54 --> Helper loaded: form_helper
INFO - 2024-02-18 11:45:54 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:45:54 --> Controller Class Initialized
INFO - 2024-02-18 11:45:54 --> Form Validation Class Initialized
INFO - 2024-02-18 11:45:54 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:45:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:45:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:45:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:45:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:45:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:45:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:45:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:45:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:45:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-18 11:45:54 --> Final output sent to browser
DEBUG - 2024-02-18 11:45:54 --> Total execution time: 0.0349
ERROR - 2024-02-18 11:45:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:45:55 --> Config Class Initialized
INFO - 2024-02-18 11:45:55 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:45:55 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:45:55 --> Utf8 Class Initialized
INFO - 2024-02-18 11:45:55 --> URI Class Initialized
INFO - 2024-02-18 11:45:55 --> Router Class Initialized
INFO - 2024-02-18 11:45:55 --> Output Class Initialized
INFO - 2024-02-18 11:45:55 --> Security Class Initialized
DEBUG - 2024-02-18 11:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:45:55 --> Input Class Initialized
INFO - 2024-02-18 11:45:55 --> Language Class Initialized
INFO - 2024-02-18 11:45:55 --> Loader Class Initialized
INFO - 2024-02-18 11:45:55 --> Helper loaded: url_helper
INFO - 2024-02-18 11:45:55 --> Helper loaded: file_helper
INFO - 2024-02-18 11:45:55 --> Helper loaded: form_helper
INFO - 2024-02-18 11:45:55 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:45:55 --> Controller Class Initialized
INFO - 2024-02-18 11:45:55 --> Form Validation Class Initialized
INFO - 2024-02-18 11:45:55 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:45:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:45:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:45:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:45:55 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:46:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:46:02 --> Config Class Initialized
INFO - 2024-02-18 11:46:02 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:46:02 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:46:02 --> Utf8 Class Initialized
INFO - 2024-02-18 11:46:02 --> URI Class Initialized
INFO - 2024-02-18 11:46:02 --> Router Class Initialized
INFO - 2024-02-18 11:46:02 --> Output Class Initialized
INFO - 2024-02-18 11:46:02 --> Security Class Initialized
DEBUG - 2024-02-18 11:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:46:02 --> Input Class Initialized
INFO - 2024-02-18 11:46:02 --> Language Class Initialized
INFO - 2024-02-18 11:46:02 --> Loader Class Initialized
INFO - 2024-02-18 11:46:02 --> Helper loaded: url_helper
INFO - 2024-02-18 11:46:02 --> Helper loaded: file_helper
INFO - 2024-02-18 11:46:02 --> Helper loaded: form_helper
INFO - 2024-02-18 11:46:02 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:46:02 --> Controller Class Initialized
INFO - 2024-02-18 11:46:02 --> Form Validation Class Initialized
INFO - 2024-02-18 11:46:02 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:46:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:46:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:46:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:46:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:46:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-18 11:46:02 --> Final output sent to browser
DEBUG - 2024-02-18 11:46:02 --> Total execution time: 0.0319
ERROR - 2024-02-18 11:54:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:54:58 --> Config Class Initialized
INFO - 2024-02-18 11:54:58 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:54:58 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:54:58 --> Utf8 Class Initialized
INFO - 2024-02-18 11:54:58 --> URI Class Initialized
INFO - 2024-02-18 11:54:58 --> Router Class Initialized
INFO - 2024-02-18 11:54:58 --> Output Class Initialized
INFO - 2024-02-18 11:54:58 --> Security Class Initialized
DEBUG - 2024-02-18 11:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:54:58 --> Input Class Initialized
INFO - 2024-02-18 11:54:58 --> Language Class Initialized
INFO - 2024-02-18 11:54:58 --> Loader Class Initialized
INFO - 2024-02-18 11:54:58 --> Helper loaded: url_helper
INFO - 2024-02-18 11:54:58 --> Helper loaded: file_helper
INFO - 2024-02-18 11:54:58 --> Helper loaded: form_helper
INFO - 2024-02-18 11:54:58 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:54:58 --> Controller Class Initialized
INFO - 2024-02-18 11:54:58 --> Form Validation Class Initialized
INFO - 2024-02-18 11:54:58 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:54:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:54:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:54:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:54:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:54:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-18 11:54:58 --> Final output sent to browser
DEBUG - 2024-02-18 11:54:58 --> Total execution time: 0.0376
ERROR - 2024-02-18 11:55:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:55:14 --> Config Class Initialized
INFO - 2024-02-18 11:55:14 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:55:14 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:55:14 --> Utf8 Class Initialized
INFO - 2024-02-18 11:55:14 --> URI Class Initialized
INFO - 2024-02-18 11:55:14 --> Router Class Initialized
INFO - 2024-02-18 11:55:14 --> Output Class Initialized
INFO - 2024-02-18 11:55:14 --> Security Class Initialized
DEBUG - 2024-02-18 11:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:55:14 --> Input Class Initialized
INFO - 2024-02-18 11:55:14 --> Language Class Initialized
INFO - 2024-02-18 11:55:14 --> Loader Class Initialized
INFO - 2024-02-18 11:55:14 --> Helper loaded: url_helper
INFO - 2024-02-18 11:55:14 --> Helper loaded: file_helper
INFO - 2024-02-18 11:55:14 --> Helper loaded: form_helper
INFO - 2024-02-18 11:55:14 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:55:14 --> Controller Class Initialized
INFO - 2024-02-18 11:55:14 --> Form Validation Class Initialized
INFO - 2024-02-18 11:55:14 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:55:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:55:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:55:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:55:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:55:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:55:14 --> Config Class Initialized
INFO - 2024-02-18 11:55:14 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:55:14 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:55:14 --> Utf8 Class Initialized
INFO - 2024-02-18 11:55:14 --> URI Class Initialized
INFO - 2024-02-18 11:55:14 --> Router Class Initialized
INFO - 2024-02-18 11:55:14 --> Output Class Initialized
INFO - 2024-02-18 11:55:14 --> Security Class Initialized
DEBUG - 2024-02-18 11:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:55:14 --> Input Class Initialized
INFO - 2024-02-18 11:55:14 --> Language Class Initialized
INFO - 2024-02-18 11:55:14 --> Loader Class Initialized
INFO - 2024-02-18 11:55:14 --> Helper loaded: url_helper
INFO - 2024-02-18 11:55:14 --> Helper loaded: file_helper
INFO - 2024-02-18 11:55:14 --> Helper loaded: form_helper
INFO - 2024-02-18 11:55:14 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:55:14 --> Controller Class Initialized
INFO - 2024-02-18 11:55:14 --> Form Validation Class Initialized
INFO - 2024-02-18 11:55:14 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:55:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:55:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:55:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:55:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 11:59:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:59:46 --> Config Class Initialized
INFO - 2024-02-18 11:59:46 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:59:46 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:59:46 --> Utf8 Class Initialized
INFO - 2024-02-18 11:59:46 --> URI Class Initialized
INFO - 2024-02-18 11:59:46 --> Router Class Initialized
INFO - 2024-02-18 11:59:46 --> Output Class Initialized
INFO - 2024-02-18 11:59:46 --> Security Class Initialized
DEBUG - 2024-02-18 11:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:59:46 --> Input Class Initialized
INFO - 2024-02-18 11:59:46 --> Language Class Initialized
INFO - 2024-02-18 11:59:46 --> Loader Class Initialized
INFO - 2024-02-18 11:59:46 --> Helper loaded: url_helper
INFO - 2024-02-18 11:59:46 --> Helper loaded: file_helper
INFO - 2024-02-18 11:59:46 --> Helper loaded: form_helper
INFO - 2024-02-18 11:59:46 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:59:46 --> Controller Class Initialized
INFO - 2024-02-18 11:59:46 --> Form Validation Class Initialized
INFO - 2024-02-18 11:59:46 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:59:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:59:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:59:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:59:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 11:59:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 11:59:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 11:59:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 11:59:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 11:59:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-18 11:59:46 --> Final output sent to browser
DEBUG - 2024-02-18 11:59:46 --> Total execution time: 0.0336
ERROR - 2024-02-18 11:59:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 11:59:48 --> Config Class Initialized
INFO - 2024-02-18 11:59:48 --> Hooks Class Initialized
DEBUG - 2024-02-18 11:59:48 --> UTF-8 Support Enabled
INFO - 2024-02-18 11:59:48 --> Utf8 Class Initialized
INFO - 2024-02-18 11:59:48 --> URI Class Initialized
INFO - 2024-02-18 11:59:48 --> Router Class Initialized
INFO - 2024-02-18 11:59:48 --> Output Class Initialized
INFO - 2024-02-18 11:59:48 --> Security Class Initialized
DEBUG - 2024-02-18 11:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 11:59:48 --> Input Class Initialized
INFO - 2024-02-18 11:59:48 --> Language Class Initialized
INFO - 2024-02-18 11:59:48 --> Loader Class Initialized
INFO - 2024-02-18 11:59:48 --> Helper loaded: url_helper
INFO - 2024-02-18 11:59:48 --> Helper loaded: file_helper
INFO - 2024-02-18 11:59:48 --> Helper loaded: form_helper
INFO - 2024-02-18 11:59:48 --> Database Driver Class Initialized
DEBUG - 2024-02-18 11:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 11:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 11:59:48 --> Controller Class Initialized
INFO - 2024-02-18 11:59:48 --> Form Validation Class Initialized
INFO - 2024-02-18 11:59:48 --> Model "MasterModel" initialized
INFO - 2024-02-18 11:59:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 11:59:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 11:59:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 11:59:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:01:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:01:15 --> Config Class Initialized
INFO - 2024-02-18 12:01:15 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:01:15 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:01:15 --> Utf8 Class Initialized
INFO - 2024-02-18 12:01:15 --> URI Class Initialized
INFO - 2024-02-18 12:01:15 --> Router Class Initialized
INFO - 2024-02-18 12:01:15 --> Output Class Initialized
INFO - 2024-02-18 12:01:15 --> Security Class Initialized
DEBUG - 2024-02-18 12:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:01:15 --> Input Class Initialized
INFO - 2024-02-18 12:01:15 --> Language Class Initialized
INFO - 2024-02-18 12:01:15 --> Loader Class Initialized
INFO - 2024-02-18 12:01:15 --> Helper loaded: url_helper
INFO - 2024-02-18 12:01:15 --> Helper loaded: file_helper
INFO - 2024-02-18 12:01:15 --> Helper loaded: form_helper
INFO - 2024-02-18 12:01:15 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:01:15 --> Controller Class Initialized
INFO - 2024-02-18 12:01:15 --> Form Validation Class Initialized
INFO - 2024-02-18 12:01:15 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:01:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:01:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:01:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:01:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 12:01:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-18 12:01:15 --> Final output sent to browser
DEBUG - 2024-02-18 12:01:15 --> Total execution time: 0.0282
ERROR - 2024-02-18 12:01:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:01:23 --> Config Class Initialized
INFO - 2024-02-18 12:01:23 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:01:23 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:01:23 --> Utf8 Class Initialized
INFO - 2024-02-18 12:01:23 --> URI Class Initialized
INFO - 2024-02-18 12:01:23 --> Router Class Initialized
INFO - 2024-02-18 12:01:23 --> Output Class Initialized
INFO - 2024-02-18 12:01:23 --> Security Class Initialized
DEBUG - 2024-02-18 12:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:01:23 --> Input Class Initialized
INFO - 2024-02-18 12:01:23 --> Language Class Initialized
INFO - 2024-02-18 12:01:23 --> Loader Class Initialized
INFO - 2024-02-18 12:01:23 --> Helper loaded: url_helper
INFO - 2024-02-18 12:01:23 --> Helper loaded: file_helper
INFO - 2024-02-18 12:01:23 --> Helper loaded: form_helper
INFO - 2024-02-18 12:01:23 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:01:23 --> Controller Class Initialized
INFO - 2024-02-18 12:01:23 --> Form Validation Class Initialized
INFO - 2024-02-18 12:01:23 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:01:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:01:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:01:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:01:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:01:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:01:33 --> Config Class Initialized
INFO - 2024-02-18 12:01:33 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:01:33 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:01:33 --> Utf8 Class Initialized
INFO - 2024-02-18 12:01:33 --> URI Class Initialized
INFO - 2024-02-18 12:01:33 --> Router Class Initialized
INFO - 2024-02-18 12:01:33 --> Output Class Initialized
INFO - 2024-02-18 12:01:33 --> Security Class Initialized
DEBUG - 2024-02-18 12:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:01:33 --> Input Class Initialized
INFO - 2024-02-18 12:01:33 --> Language Class Initialized
INFO - 2024-02-18 12:01:33 --> Loader Class Initialized
INFO - 2024-02-18 12:01:33 --> Helper loaded: url_helper
INFO - 2024-02-18 12:01:33 --> Helper loaded: file_helper
INFO - 2024-02-18 12:01:33 --> Helper loaded: form_helper
INFO - 2024-02-18 12:01:33 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:01:33 --> Controller Class Initialized
INFO - 2024-02-18 12:01:33 --> Form Validation Class Initialized
INFO - 2024-02-18 12:01:33 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:01:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:01:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:01:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:01:33 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:01:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:01:33 --> Config Class Initialized
INFO - 2024-02-18 12:01:33 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:01:33 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:01:33 --> Utf8 Class Initialized
INFO - 2024-02-18 12:01:33 --> URI Class Initialized
INFO - 2024-02-18 12:01:33 --> Router Class Initialized
INFO - 2024-02-18 12:01:33 --> Output Class Initialized
INFO - 2024-02-18 12:01:33 --> Security Class Initialized
DEBUG - 2024-02-18 12:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:01:33 --> Input Class Initialized
INFO - 2024-02-18 12:01:33 --> Language Class Initialized
INFO - 2024-02-18 12:01:33 --> Loader Class Initialized
INFO - 2024-02-18 12:01:33 --> Helper loaded: url_helper
INFO - 2024-02-18 12:01:33 --> Helper loaded: file_helper
INFO - 2024-02-18 12:01:33 --> Helper loaded: form_helper
INFO - 2024-02-18 12:01:33 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:01:33 --> Controller Class Initialized
INFO - 2024-02-18 12:01:33 --> Form Validation Class Initialized
INFO - 2024-02-18 12:01:33 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:01:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:01:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:01:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:01:33 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:01:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:01:40 --> Config Class Initialized
INFO - 2024-02-18 12:01:40 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:01:40 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:01:40 --> Utf8 Class Initialized
INFO - 2024-02-18 12:01:40 --> URI Class Initialized
INFO - 2024-02-18 12:01:40 --> Router Class Initialized
INFO - 2024-02-18 12:01:40 --> Output Class Initialized
INFO - 2024-02-18 12:01:40 --> Security Class Initialized
DEBUG - 2024-02-18 12:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:01:40 --> Input Class Initialized
INFO - 2024-02-18 12:01:40 --> Language Class Initialized
INFO - 2024-02-18 12:01:40 --> Loader Class Initialized
INFO - 2024-02-18 12:01:40 --> Helper loaded: url_helper
INFO - 2024-02-18 12:01:40 --> Helper loaded: file_helper
INFO - 2024-02-18 12:01:40 --> Helper loaded: form_helper
INFO - 2024-02-18 12:01:40 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:01:40 --> Controller Class Initialized
INFO - 2024-02-18 12:01:40 --> Form Validation Class Initialized
INFO - 2024-02-18 12:01:40 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:01:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:01:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:01:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:01:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 12:01:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-18 12:01:40 --> Final output sent to browser
DEBUG - 2024-02-18 12:01:40 --> Total execution time: 0.0298
ERROR - 2024-02-18 12:03:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:03:40 --> Config Class Initialized
INFO - 2024-02-18 12:03:40 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:03:40 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:03:40 --> Utf8 Class Initialized
INFO - 2024-02-18 12:03:40 --> URI Class Initialized
INFO - 2024-02-18 12:03:40 --> Router Class Initialized
INFO - 2024-02-18 12:03:40 --> Output Class Initialized
INFO - 2024-02-18 12:03:40 --> Security Class Initialized
DEBUG - 2024-02-18 12:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:03:40 --> Input Class Initialized
INFO - 2024-02-18 12:03:40 --> Language Class Initialized
INFO - 2024-02-18 12:03:40 --> Loader Class Initialized
INFO - 2024-02-18 12:03:40 --> Helper loaded: url_helper
INFO - 2024-02-18 12:03:40 --> Helper loaded: file_helper
INFO - 2024-02-18 12:03:40 --> Helper loaded: form_helper
INFO - 2024-02-18 12:03:40 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:03:40 --> Controller Class Initialized
INFO - 2024-02-18 12:03:40 --> Form Validation Class Initialized
INFO - 2024-02-18 12:03:40 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:03:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:03:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:03:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:03:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 12:03:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-18 12:03:40 --> Final output sent to browser
DEBUG - 2024-02-18 12:03:40 --> Total execution time: 0.0384
ERROR - 2024-02-18 12:03:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:03:42 --> Config Class Initialized
INFO - 2024-02-18 12:03:42 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:03:42 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:03:42 --> Utf8 Class Initialized
INFO - 2024-02-18 12:03:42 --> URI Class Initialized
INFO - 2024-02-18 12:03:42 --> Router Class Initialized
INFO - 2024-02-18 12:03:42 --> Output Class Initialized
INFO - 2024-02-18 12:03:42 --> Security Class Initialized
DEBUG - 2024-02-18 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:03:42 --> Input Class Initialized
INFO - 2024-02-18 12:03:42 --> Language Class Initialized
INFO - 2024-02-18 12:03:42 --> Loader Class Initialized
INFO - 2024-02-18 12:03:42 --> Helper loaded: url_helper
INFO - 2024-02-18 12:03:42 --> Helper loaded: file_helper
INFO - 2024-02-18 12:03:42 --> Helper loaded: form_helper
INFO - 2024-02-18 12:03:42 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:03:42 --> Controller Class Initialized
INFO - 2024-02-18 12:03:42 --> Form Validation Class Initialized
INFO - 2024-02-18 12:03:42 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:03:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:03:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:03:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:03:42 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:03:48 --> Config Class Initialized
INFO - 2024-02-18 12:03:48 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:03:48 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:03:48 --> Utf8 Class Initialized
INFO - 2024-02-18 12:03:48 --> URI Class Initialized
INFO - 2024-02-18 12:03:48 --> Router Class Initialized
INFO - 2024-02-18 12:03:48 --> Output Class Initialized
INFO - 2024-02-18 12:03:48 --> Security Class Initialized
DEBUG - 2024-02-18 12:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:03:48 --> Input Class Initialized
INFO - 2024-02-18 12:03:48 --> Language Class Initialized
INFO - 2024-02-18 12:03:48 --> Loader Class Initialized
INFO - 2024-02-18 12:03:48 --> Helper loaded: url_helper
INFO - 2024-02-18 12:03:48 --> Helper loaded: file_helper
INFO - 2024-02-18 12:03:48 --> Helper loaded: form_helper
INFO - 2024-02-18 12:03:48 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:03:48 --> Controller Class Initialized
INFO - 2024-02-18 12:03:48 --> Form Validation Class Initialized
INFO - 2024-02-18 12:03:48 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:03:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:03:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:03:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:03:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:03:48 --> Config Class Initialized
INFO - 2024-02-18 12:03:48 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:03:48 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:03:48 --> Utf8 Class Initialized
INFO - 2024-02-18 12:03:48 --> URI Class Initialized
INFO - 2024-02-18 12:03:48 --> Router Class Initialized
INFO - 2024-02-18 12:03:48 --> Output Class Initialized
INFO - 2024-02-18 12:03:48 --> Security Class Initialized
DEBUG - 2024-02-18 12:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:03:48 --> Input Class Initialized
INFO - 2024-02-18 12:03:48 --> Language Class Initialized
INFO - 2024-02-18 12:03:48 --> Loader Class Initialized
INFO - 2024-02-18 12:03:48 --> Helper loaded: url_helper
INFO - 2024-02-18 12:03:48 --> Helper loaded: file_helper
INFO - 2024-02-18 12:03:48 --> Helper loaded: form_helper
INFO - 2024-02-18 12:03:48 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:03:48 --> Controller Class Initialized
INFO - 2024-02-18 12:03:48 --> Form Validation Class Initialized
INFO - 2024-02-18 12:03:48 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:03:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:03:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:03:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:03:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:03:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:03:56 --> Config Class Initialized
INFO - 2024-02-18 12:03:56 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:03:56 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:03:56 --> Utf8 Class Initialized
INFO - 2024-02-18 12:03:56 --> URI Class Initialized
INFO - 2024-02-18 12:03:56 --> Router Class Initialized
INFO - 2024-02-18 12:03:56 --> Output Class Initialized
INFO - 2024-02-18 12:03:56 --> Security Class Initialized
DEBUG - 2024-02-18 12:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:03:56 --> Input Class Initialized
INFO - 2024-02-18 12:03:56 --> Language Class Initialized
INFO - 2024-02-18 12:03:56 --> Loader Class Initialized
INFO - 2024-02-18 12:03:56 --> Helper loaded: url_helper
INFO - 2024-02-18 12:03:56 --> Helper loaded: file_helper
INFO - 2024-02-18 12:03:56 --> Helper loaded: form_helper
INFO - 2024-02-18 12:03:56 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:03:56 --> Controller Class Initialized
INFO - 2024-02-18 12:03:56 --> Form Validation Class Initialized
INFO - 2024-02-18 12:03:56 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:03:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:03:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:03:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:03:56 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:03:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:03:57 --> Config Class Initialized
INFO - 2024-02-18 12:03:57 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:03:57 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:03:57 --> Utf8 Class Initialized
INFO - 2024-02-18 12:03:57 --> URI Class Initialized
INFO - 2024-02-18 12:03:57 --> Router Class Initialized
INFO - 2024-02-18 12:03:57 --> Output Class Initialized
INFO - 2024-02-18 12:03:57 --> Security Class Initialized
DEBUG - 2024-02-18 12:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:03:57 --> Input Class Initialized
INFO - 2024-02-18 12:03:57 --> Language Class Initialized
INFO - 2024-02-18 12:03:57 --> Loader Class Initialized
INFO - 2024-02-18 12:03:57 --> Helper loaded: url_helper
INFO - 2024-02-18 12:03:57 --> Helper loaded: file_helper
INFO - 2024-02-18 12:03:57 --> Helper loaded: form_helper
INFO - 2024-02-18 12:03:57 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:03:57 --> Controller Class Initialized
INFO - 2024-02-18 12:03:57 --> Form Validation Class Initialized
INFO - 2024-02-18 12:03:57 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:03:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:03:57 --> Config Class Initialized
INFO - 2024-02-18 12:03:57 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:03:57 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:03:57 --> Utf8 Class Initialized
INFO - 2024-02-18 12:03:57 --> URI Class Initialized
INFO - 2024-02-18 12:03:57 --> Router Class Initialized
INFO - 2024-02-18 12:03:57 --> Output Class Initialized
INFO - 2024-02-18 12:03:57 --> Security Class Initialized
DEBUG - 2024-02-18 12:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:03:57 --> Input Class Initialized
INFO - 2024-02-18 12:03:57 --> Language Class Initialized
INFO - 2024-02-18 12:03:57 --> Loader Class Initialized
INFO - 2024-02-18 12:03:57 --> Helper loaded: url_helper
INFO - 2024-02-18 12:03:57 --> Helper loaded: file_helper
INFO - 2024-02-18 12:03:57 --> Helper loaded: form_helper
INFO - 2024-02-18 12:03:57 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:03:57 --> Controller Class Initialized
INFO - 2024-02-18 12:03:57 --> Form Validation Class Initialized
INFO - 2024-02-18 12:03:57 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:03:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:03:57 --> Config Class Initialized
INFO - 2024-02-18 12:03:57 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:03:57 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:03:57 --> Utf8 Class Initialized
INFO - 2024-02-18 12:03:57 --> URI Class Initialized
INFO - 2024-02-18 12:03:57 --> Router Class Initialized
INFO - 2024-02-18 12:03:57 --> Output Class Initialized
INFO - 2024-02-18 12:03:57 --> Security Class Initialized
DEBUG - 2024-02-18 12:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:03:57 --> Input Class Initialized
INFO - 2024-02-18 12:03:57 --> Language Class Initialized
INFO - 2024-02-18 12:03:57 --> Loader Class Initialized
INFO - 2024-02-18 12:03:57 --> Helper loaded: url_helper
INFO - 2024-02-18 12:03:57 --> Helper loaded: file_helper
INFO - 2024-02-18 12:03:57 --> Helper loaded: form_helper
INFO - 2024-02-18 12:03:57 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:03:57 --> Controller Class Initialized
INFO - 2024-02-18 12:03:57 --> Form Validation Class Initialized
INFO - 2024-02-18 12:03:57 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:03:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:03:57 --> Config Class Initialized
INFO - 2024-02-18 12:03:57 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:03:57 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:03:57 --> Utf8 Class Initialized
INFO - 2024-02-18 12:03:57 --> URI Class Initialized
INFO - 2024-02-18 12:03:57 --> Router Class Initialized
INFO - 2024-02-18 12:03:57 --> Output Class Initialized
INFO - 2024-02-18 12:03:57 --> Security Class Initialized
DEBUG - 2024-02-18 12:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:03:57 --> Input Class Initialized
INFO - 2024-02-18 12:03:57 --> Language Class Initialized
INFO - 2024-02-18 12:03:57 --> Loader Class Initialized
INFO - 2024-02-18 12:03:57 --> Helper loaded: url_helper
INFO - 2024-02-18 12:03:57 --> Helper loaded: file_helper
INFO - 2024-02-18 12:03:57 --> Helper loaded: form_helper
INFO - 2024-02-18 12:03:57 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:03:57 --> Controller Class Initialized
INFO - 2024-02-18 12:03:57 --> Form Validation Class Initialized
INFO - 2024-02-18 12:03:57 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:03:57 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:03:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:03:58 --> Config Class Initialized
INFO - 2024-02-18 12:03:58 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:03:58 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:03:58 --> Utf8 Class Initialized
INFO - 2024-02-18 12:03:58 --> URI Class Initialized
INFO - 2024-02-18 12:03:58 --> Router Class Initialized
INFO - 2024-02-18 12:03:58 --> Output Class Initialized
INFO - 2024-02-18 12:03:58 --> Security Class Initialized
DEBUG - 2024-02-18 12:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:03:58 --> Input Class Initialized
INFO - 2024-02-18 12:03:58 --> Language Class Initialized
INFO - 2024-02-18 12:03:58 --> Loader Class Initialized
INFO - 2024-02-18 12:03:58 --> Helper loaded: url_helper
INFO - 2024-02-18 12:03:58 --> Helper loaded: file_helper
INFO - 2024-02-18 12:03:58 --> Helper loaded: form_helper
INFO - 2024-02-18 12:03:58 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:03:58 --> Controller Class Initialized
INFO - 2024-02-18 12:03:58 --> Form Validation Class Initialized
INFO - 2024-02-18 12:03:58 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:03:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:03:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:03:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:03:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:03:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:03:58 --> Config Class Initialized
INFO - 2024-02-18 12:03:58 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:03:58 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:03:58 --> Utf8 Class Initialized
INFO - 2024-02-18 12:03:58 --> URI Class Initialized
INFO - 2024-02-18 12:03:58 --> Router Class Initialized
INFO - 2024-02-18 12:03:58 --> Output Class Initialized
INFO - 2024-02-18 12:03:58 --> Security Class Initialized
DEBUG - 2024-02-18 12:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:03:58 --> Input Class Initialized
INFO - 2024-02-18 12:03:58 --> Language Class Initialized
INFO - 2024-02-18 12:03:58 --> Loader Class Initialized
INFO - 2024-02-18 12:03:58 --> Helper loaded: url_helper
INFO - 2024-02-18 12:03:58 --> Helper loaded: file_helper
INFO - 2024-02-18 12:03:58 --> Helper loaded: form_helper
INFO - 2024-02-18 12:03:58 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:03:58 --> Controller Class Initialized
INFO - 2024-02-18 12:03:58 --> Form Validation Class Initialized
INFO - 2024-02-18 12:03:58 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:03:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:03:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:03:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:03:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:04:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:04:02 --> Config Class Initialized
INFO - 2024-02-18 12:04:02 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:04:02 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:04:02 --> Utf8 Class Initialized
INFO - 2024-02-18 12:04:02 --> URI Class Initialized
INFO - 2024-02-18 12:04:02 --> Router Class Initialized
INFO - 2024-02-18 12:04:02 --> Output Class Initialized
INFO - 2024-02-18 12:04:02 --> Security Class Initialized
DEBUG - 2024-02-18 12:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:04:02 --> Input Class Initialized
INFO - 2024-02-18 12:04:02 --> Language Class Initialized
INFO - 2024-02-18 12:04:02 --> Loader Class Initialized
INFO - 2024-02-18 12:04:02 --> Helper loaded: url_helper
INFO - 2024-02-18 12:04:02 --> Helper loaded: file_helper
INFO - 2024-02-18 12:04:02 --> Helper loaded: form_helper
INFO - 2024-02-18 12:04:02 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:04:02 --> Controller Class Initialized
INFO - 2024-02-18 12:04:02 --> Form Validation Class Initialized
INFO - 2024-02-18 12:04:02 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:04:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:04:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:04:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:04:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:04:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:04:02 --> Config Class Initialized
INFO - 2024-02-18 12:04:02 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:04:02 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:04:02 --> Utf8 Class Initialized
INFO - 2024-02-18 12:04:02 --> URI Class Initialized
INFO - 2024-02-18 12:04:02 --> Router Class Initialized
INFO - 2024-02-18 12:04:02 --> Output Class Initialized
INFO - 2024-02-18 12:04:02 --> Security Class Initialized
DEBUG - 2024-02-18 12:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:04:02 --> Input Class Initialized
INFO - 2024-02-18 12:04:02 --> Language Class Initialized
INFO - 2024-02-18 12:04:02 --> Loader Class Initialized
INFO - 2024-02-18 12:04:02 --> Helper loaded: url_helper
INFO - 2024-02-18 12:04:02 --> Helper loaded: file_helper
INFO - 2024-02-18 12:04:02 --> Helper loaded: form_helper
INFO - 2024-02-18 12:04:02 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:04:02 --> Controller Class Initialized
INFO - 2024-02-18 12:04:02 --> Form Validation Class Initialized
INFO - 2024-02-18 12:04:02 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:04:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:04:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:04:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:04:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:04:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:04:02 --> Config Class Initialized
INFO - 2024-02-18 12:04:02 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:04:02 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:04:02 --> Utf8 Class Initialized
INFO - 2024-02-18 12:04:02 --> URI Class Initialized
INFO - 2024-02-18 12:04:02 --> Router Class Initialized
INFO - 2024-02-18 12:04:02 --> Output Class Initialized
INFO - 2024-02-18 12:04:02 --> Security Class Initialized
DEBUG - 2024-02-18 12:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:04:02 --> Input Class Initialized
INFO - 2024-02-18 12:04:02 --> Language Class Initialized
INFO - 2024-02-18 12:04:02 --> Loader Class Initialized
INFO - 2024-02-18 12:04:02 --> Helper loaded: url_helper
INFO - 2024-02-18 12:04:02 --> Helper loaded: file_helper
INFO - 2024-02-18 12:04:02 --> Helper loaded: form_helper
INFO - 2024-02-18 12:04:02 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:04:02 --> Controller Class Initialized
INFO - 2024-02-18 12:04:02 --> Form Validation Class Initialized
INFO - 2024-02-18 12:04:02 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:04:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:04:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:04:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:04:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:04:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:04:03 --> Config Class Initialized
INFO - 2024-02-18 12:04:03 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:04:03 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:04:03 --> Utf8 Class Initialized
INFO - 2024-02-18 12:04:03 --> URI Class Initialized
INFO - 2024-02-18 12:04:03 --> Router Class Initialized
INFO - 2024-02-18 12:04:03 --> Output Class Initialized
INFO - 2024-02-18 12:04:03 --> Security Class Initialized
DEBUG - 2024-02-18 12:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:04:03 --> Input Class Initialized
INFO - 2024-02-18 12:04:03 --> Language Class Initialized
INFO - 2024-02-18 12:04:03 --> Loader Class Initialized
INFO - 2024-02-18 12:04:03 --> Helper loaded: url_helper
INFO - 2024-02-18 12:04:03 --> Helper loaded: file_helper
INFO - 2024-02-18 12:04:03 --> Helper loaded: form_helper
INFO - 2024-02-18 12:04:03 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:04:03 --> Controller Class Initialized
INFO - 2024-02-18 12:04:03 --> Form Validation Class Initialized
INFO - 2024-02-18 12:04:03 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:04:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:04:03 --> Config Class Initialized
INFO - 2024-02-18 12:04:03 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:04:03 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:04:03 --> Utf8 Class Initialized
INFO - 2024-02-18 12:04:03 --> URI Class Initialized
INFO - 2024-02-18 12:04:03 --> Router Class Initialized
INFO - 2024-02-18 12:04:03 --> Output Class Initialized
INFO - 2024-02-18 12:04:03 --> Security Class Initialized
DEBUG - 2024-02-18 12:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:04:03 --> Input Class Initialized
INFO - 2024-02-18 12:04:03 --> Language Class Initialized
INFO - 2024-02-18 12:04:03 --> Loader Class Initialized
INFO - 2024-02-18 12:04:03 --> Helper loaded: url_helper
INFO - 2024-02-18 12:04:03 --> Helper loaded: file_helper
INFO - 2024-02-18 12:04:03 --> Helper loaded: form_helper
INFO - 2024-02-18 12:04:03 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:04:03 --> Controller Class Initialized
INFO - 2024-02-18 12:04:03 --> Form Validation Class Initialized
INFO - 2024-02-18 12:04:03 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:04:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:04:03 --> Config Class Initialized
INFO - 2024-02-18 12:04:03 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:04:03 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:04:03 --> Utf8 Class Initialized
INFO - 2024-02-18 12:04:03 --> URI Class Initialized
INFO - 2024-02-18 12:04:03 --> Router Class Initialized
INFO - 2024-02-18 12:04:03 --> Output Class Initialized
INFO - 2024-02-18 12:04:03 --> Security Class Initialized
DEBUG - 2024-02-18 12:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:04:03 --> Input Class Initialized
INFO - 2024-02-18 12:04:03 --> Language Class Initialized
INFO - 2024-02-18 12:04:03 --> Loader Class Initialized
INFO - 2024-02-18 12:04:03 --> Helper loaded: url_helper
INFO - 2024-02-18 12:04:03 --> Helper loaded: file_helper
INFO - 2024-02-18 12:04:03 --> Helper loaded: form_helper
INFO - 2024-02-18 12:04:03 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:04:03 --> Controller Class Initialized
INFO - 2024-02-18 12:04:03 --> Form Validation Class Initialized
INFO - 2024-02-18 12:04:03 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 12:04:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 12:04:03 --> Config Class Initialized
INFO - 2024-02-18 12:04:03 --> Hooks Class Initialized
DEBUG - 2024-02-18 12:04:03 --> UTF-8 Support Enabled
INFO - 2024-02-18 12:04:03 --> Utf8 Class Initialized
INFO - 2024-02-18 12:04:03 --> URI Class Initialized
INFO - 2024-02-18 12:04:03 --> Router Class Initialized
INFO - 2024-02-18 12:04:03 --> Output Class Initialized
INFO - 2024-02-18 12:04:03 --> Security Class Initialized
DEBUG - 2024-02-18 12:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 12:04:03 --> Input Class Initialized
INFO - 2024-02-18 12:04:03 --> Language Class Initialized
INFO - 2024-02-18 12:04:03 --> Loader Class Initialized
INFO - 2024-02-18 12:04:03 --> Helper loaded: url_helper
INFO - 2024-02-18 12:04:03 --> Helper loaded: file_helper
INFO - 2024-02-18 12:04:03 --> Helper loaded: form_helper
INFO - 2024-02-18 12:04:03 --> Database Driver Class Initialized
DEBUG - 2024-02-18 12:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 12:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 12:04:03 --> Controller Class Initialized
INFO - 2024-02-18 12:04:03 --> Form Validation Class Initialized
INFO - 2024-02-18 12:04:03 --> Model "MasterModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 12:04:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 17:04:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:04:14 --> Config Class Initialized
INFO - 2024-02-18 17:04:14 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:04:14 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:04:14 --> Utf8 Class Initialized
INFO - 2024-02-18 17:04:14 --> URI Class Initialized
INFO - 2024-02-18 17:04:14 --> Router Class Initialized
INFO - 2024-02-18 17:04:14 --> Output Class Initialized
INFO - 2024-02-18 17:04:14 --> Security Class Initialized
DEBUG - 2024-02-18 17:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:04:14 --> Input Class Initialized
INFO - 2024-02-18 17:04:14 --> Language Class Initialized
INFO - 2024-02-18 17:04:14 --> Loader Class Initialized
INFO - 2024-02-18 17:04:14 --> Helper loaded: url_helper
INFO - 2024-02-18 17:04:14 --> Helper loaded: file_helper
INFO - 2024-02-18 17:04:14 --> Helper loaded: form_helper
INFO - 2024-02-18 17:04:14 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:04:14 --> Controller Class Initialized
INFO - 2024-02-18 17:04:14 --> Form Validation Class Initialized
INFO - 2024-02-18 17:04:14 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:04:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:04:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:04:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:04:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:04:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 17:04:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 17:04:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 17:04:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 17:04:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-18 17:04:14 --> Final output sent to browser
DEBUG - 2024-02-18 17:04:14 --> Total execution time: 0.0289
ERROR - 2024-02-18 17:04:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:04:14 --> Config Class Initialized
INFO - 2024-02-18 17:04:14 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:04:14 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:04:14 --> Utf8 Class Initialized
INFO - 2024-02-18 17:04:14 --> URI Class Initialized
INFO - 2024-02-18 17:04:14 --> Router Class Initialized
INFO - 2024-02-18 17:04:14 --> Output Class Initialized
INFO - 2024-02-18 17:04:14 --> Security Class Initialized
DEBUG - 2024-02-18 17:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:04:14 --> Input Class Initialized
INFO - 2024-02-18 17:04:14 --> Language Class Initialized
INFO - 2024-02-18 17:04:14 --> Loader Class Initialized
INFO - 2024-02-18 17:04:14 --> Helper loaded: url_helper
INFO - 2024-02-18 17:04:14 --> Helper loaded: file_helper
INFO - 2024-02-18 17:04:14 --> Helper loaded: form_helper
INFO - 2024-02-18 17:04:14 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:04:14 --> Controller Class Initialized
INFO - 2024-02-18 17:04:14 --> Form Validation Class Initialized
INFO - 2024-02-18 17:04:14 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:04:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:04:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:04:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:04:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 17:04:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:04:53 --> Config Class Initialized
INFO - 2024-02-18 17:04:53 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:04:53 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:04:53 --> Utf8 Class Initialized
INFO - 2024-02-18 17:04:53 --> URI Class Initialized
INFO - 2024-02-18 17:04:53 --> Router Class Initialized
INFO - 2024-02-18 17:04:53 --> Output Class Initialized
INFO - 2024-02-18 17:04:53 --> Security Class Initialized
DEBUG - 2024-02-18 17:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:04:53 --> Input Class Initialized
INFO - 2024-02-18 17:04:53 --> Language Class Initialized
INFO - 2024-02-18 17:04:53 --> Loader Class Initialized
INFO - 2024-02-18 17:04:53 --> Helper loaded: url_helper
INFO - 2024-02-18 17:04:53 --> Helper loaded: file_helper
INFO - 2024-02-18 17:04:53 --> Helper loaded: form_helper
INFO - 2024-02-18 17:04:53 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:04:53 --> Controller Class Initialized
INFO - 2024-02-18 17:04:53 --> Form Validation Class Initialized
INFO - 2024-02-18 17:04:53 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:04:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:04:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:04:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:04:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:04:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-18 17:04:53 --> Final output sent to browser
DEBUG - 2024-02-18 17:04:53 --> Total execution time: 0.0636
ERROR - 2024-02-18 17:24:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:24:26 --> Config Class Initialized
INFO - 2024-02-18 17:24:26 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:24:26 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:24:26 --> Utf8 Class Initialized
INFO - 2024-02-18 17:24:26 --> URI Class Initialized
INFO - 2024-02-18 17:24:26 --> Router Class Initialized
INFO - 2024-02-18 17:24:26 --> Output Class Initialized
INFO - 2024-02-18 17:24:26 --> Security Class Initialized
DEBUG - 2024-02-18 17:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:24:26 --> Input Class Initialized
INFO - 2024-02-18 17:24:26 --> Language Class Initialized
INFO - 2024-02-18 17:24:26 --> Loader Class Initialized
INFO - 2024-02-18 17:24:26 --> Helper loaded: url_helper
INFO - 2024-02-18 17:24:26 --> Helper loaded: file_helper
INFO - 2024-02-18 17:24:26 --> Helper loaded: form_helper
INFO - 2024-02-18 17:24:26 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:24:26 --> Controller Class Initialized
INFO - 2024-02-18 17:24:26 --> Form Validation Class Initialized
INFO - 2024-02-18 17:24:26 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:24:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:24:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:24:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:24:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:24:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 17:24:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 17:24:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 17:24:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 17:24:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-18 17:24:26 --> Final output sent to browser
DEBUG - 2024-02-18 17:24:26 --> Total execution time: 0.0275
ERROR - 2024-02-18 17:24:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:24:26 --> Config Class Initialized
INFO - 2024-02-18 17:24:26 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:24:26 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:24:26 --> Utf8 Class Initialized
INFO - 2024-02-18 17:24:26 --> URI Class Initialized
INFO - 2024-02-18 17:24:26 --> Router Class Initialized
INFO - 2024-02-18 17:24:26 --> Output Class Initialized
INFO - 2024-02-18 17:24:26 --> Security Class Initialized
DEBUG - 2024-02-18 17:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:24:26 --> Input Class Initialized
INFO - 2024-02-18 17:24:26 --> Language Class Initialized
INFO - 2024-02-18 17:24:26 --> Loader Class Initialized
INFO - 2024-02-18 17:24:26 --> Helper loaded: url_helper
INFO - 2024-02-18 17:24:26 --> Helper loaded: file_helper
INFO - 2024-02-18 17:24:26 --> Helper loaded: form_helper
INFO - 2024-02-18 17:24:26 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:24:26 --> Controller Class Initialized
INFO - 2024-02-18 17:24:26 --> Form Validation Class Initialized
INFO - 2024-02-18 17:24:26 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:24:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:24:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:24:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:24:26 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 17:24:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:24:29 --> Config Class Initialized
INFO - 2024-02-18 17:24:29 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:24:29 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:24:29 --> Utf8 Class Initialized
INFO - 2024-02-18 17:24:29 --> URI Class Initialized
INFO - 2024-02-18 17:24:29 --> Router Class Initialized
INFO - 2024-02-18 17:24:29 --> Output Class Initialized
INFO - 2024-02-18 17:24:29 --> Security Class Initialized
DEBUG - 2024-02-18 17:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:24:29 --> Input Class Initialized
INFO - 2024-02-18 17:24:29 --> Language Class Initialized
INFO - 2024-02-18 17:24:29 --> Loader Class Initialized
INFO - 2024-02-18 17:24:29 --> Helper loaded: url_helper
INFO - 2024-02-18 17:24:29 --> Helper loaded: file_helper
INFO - 2024-02-18 17:24:29 --> Helper loaded: form_helper
INFO - 2024-02-18 17:24:29 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:24:29 --> Controller Class Initialized
INFO - 2024-02-18 17:24:29 --> Form Validation Class Initialized
INFO - 2024-02-18 17:24:29 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:24:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:24:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:24:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:24:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:24:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-18 17:24:29 --> Final output sent to browser
DEBUG - 2024-02-18 17:24:29 --> Total execution time: 0.0306
ERROR - 2024-02-18 17:24:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:24:46 --> Config Class Initialized
INFO - 2024-02-18 17:24:46 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:24:46 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:24:46 --> Utf8 Class Initialized
INFO - 2024-02-18 17:24:46 --> URI Class Initialized
INFO - 2024-02-18 17:24:46 --> Router Class Initialized
INFO - 2024-02-18 17:24:46 --> Output Class Initialized
INFO - 2024-02-18 17:24:46 --> Security Class Initialized
DEBUG - 2024-02-18 17:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:24:46 --> Input Class Initialized
INFO - 2024-02-18 17:24:46 --> Language Class Initialized
INFO - 2024-02-18 17:24:46 --> Loader Class Initialized
INFO - 2024-02-18 17:24:46 --> Helper loaded: url_helper
INFO - 2024-02-18 17:24:46 --> Helper loaded: file_helper
INFO - 2024-02-18 17:24:46 --> Helper loaded: form_helper
INFO - 2024-02-18 17:24:46 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:24:46 --> Controller Class Initialized
INFO - 2024-02-18 17:24:46 --> Form Validation Class Initialized
INFO - 2024-02-18 17:24:46 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:24:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:24:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:24:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:24:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:24:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 17:24:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 17:24:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 17:24:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 17:24:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-18 17:24:46 --> Final output sent to browser
DEBUG - 2024-02-18 17:24:46 --> Total execution time: 0.0308
ERROR - 2024-02-18 17:24:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:24:47 --> Config Class Initialized
INFO - 2024-02-18 17:24:47 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:24:47 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:24:47 --> Utf8 Class Initialized
INFO - 2024-02-18 17:24:47 --> URI Class Initialized
INFO - 2024-02-18 17:24:47 --> Router Class Initialized
INFO - 2024-02-18 17:24:47 --> Output Class Initialized
INFO - 2024-02-18 17:24:47 --> Security Class Initialized
DEBUG - 2024-02-18 17:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:24:47 --> Input Class Initialized
INFO - 2024-02-18 17:24:47 --> Language Class Initialized
INFO - 2024-02-18 17:24:47 --> Loader Class Initialized
INFO - 2024-02-18 17:24:47 --> Helper loaded: url_helper
INFO - 2024-02-18 17:24:47 --> Helper loaded: file_helper
INFO - 2024-02-18 17:24:47 --> Helper loaded: form_helper
INFO - 2024-02-18 17:24:47 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:24:47 --> Controller Class Initialized
INFO - 2024-02-18 17:24:47 --> Form Validation Class Initialized
INFO - 2024-02-18 17:24:47 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:24:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:24:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:24:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:24:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 17:24:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:24:49 --> Config Class Initialized
INFO - 2024-02-18 17:24:49 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:24:49 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:24:49 --> Utf8 Class Initialized
INFO - 2024-02-18 17:24:49 --> URI Class Initialized
INFO - 2024-02-18 17:24:49 --> Router Class Initialized
INFO - 2024-02-18 17:24:49 --> Output Class Initialized
INFO - 2024-02-18 17:24:49 --> Security Class Initialized
DEBUG - 2024-02-18 17:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:24:49 --> Input Class Initialized
INFO - 2024-02-18 17:24:49 --> Language Class Initialized
INFO - 2024-02-18 17:24:49 --> Loader Class Initialized
INFO - 2024-02-18 17:24:49 --> Helper loaded: url_helper
INFO - 2024-02-18 17:24:49 --> Helper loaded: file_helper
INFO - 2024-02-18 17:24:49 --> Helper loaded: form_helper
INFO - 2024-02-18 17:24:49 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:24:49 --> Controller Class Initialized
INFO - 2024-02-18 17:24:49 --> Form Validation Class Initialized
INFO - 2024-02-18 17:24:49 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:24:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:24:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:24:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:24:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:24:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-18 17:24:49 --> Final output sent to browser
DEBUG - 2024-02-18 17:24:49 --> Total execution time: 0.0450
ERROR - 2024-02-18 17:27:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:27:23 --> Config Class Initialized
INFO - 2024-02-18 17:27:23 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:27:23 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:27:23 --> Utf8 Class Initialized
INFO - 2024-02-18 17:27:23 --> URI Class Initialized
INFO - 2024-02-18 17:27:23 --> Router Class Initialized
INFO - 2024-02-18 17:27:23 --> Output Class Initialized
INFO - 2024-02-18 17:27:23 --> Security Class Initialized
DEBUG - 2024-02-18 17:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:27:23 --> Input Class Initialized
INFO - 2024-02-18 17:27:23 --> Language Class Initialized
INFO - 2024-02-18 17:27:23 --> Loader Class Initialized
INFO - 2024-02-18 17:27:23 --> Helper loaded: url_helper
INFO - 2024-02-18 17:27:23 --> Helper loaded: file_helper
INFO - 2024-02-18 17:27:23 --> Helper loaded: form_helper
INFO - 2024-02-18 17:27:23 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:27:23 --> Controller Class Initialized
INFO - 2024-02-18 17:27:23 --> Form Validation Class Initialized
INFO - 2024-02-18 17:27:23 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:27:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:27:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:27:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:27:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:27:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 17:27:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 17:27:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 17:27:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 17:27:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-18 17:27:23 --> Final output sent to browser
DEBUG - 2024-02-18 17:27:23 --> Total execution time: 0.0365
ERROR - 2024-02-18 17:27:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:27:25 --> Config Class Initialized
INFO - 2024-02-18 17:27:25 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:27:25 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:27:25 --> Utf8 Class Initialized
INFO - 2024-02-18 17:27:25 --> URI Class Initialized
INFO - 2024-02-18 17:27:25 --> Router Class Initialized
INFO - 2024-02-18 17:27:25 --> Output Class Initialized
INFO - 2024-02-18 17:27:25 --> Security Class Initialized
DEBUG - 2024-02-18 17:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:27:25 --> Input Class Initialized
INFO - 2024-02-18 17:27:25 --> Language Class Initialized
INFO - 2024-02-18 17:27:25 --> Loader Class Initialized
INFO - 2024-02-18 17:27:25 --> Helper loaded: url_helper
INFO - 2024-02-18 17:27:25 --> Helper loaded: file_helper
INFO - 2024-02-18 17:27:25 --> Helper loaded: form_helper
INFO - 2024-02-18 17:27:25 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:27:25 --> Controller Class Initialized
INFO - 2024-02-18 17:27:25 --> Form Validation Class Initialized
INFO - 2024-02-18 17:27:25 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:27:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:27:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:27:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:27:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 17:27:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:27:27 --> Config Class Initialized
INFO - 2024-02-18 17:27:27 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:27:27 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:27:27 --> Utf8 Class Initialized
INFO - 2024-02-18 17:27:27 --> URI Class Initialized
INFO - 2024-02-18 17:27:27 --> Router Class Initialized
INFO - 2024-02-18 17:27:27 --> Output Class Initialized
INFO - 2024-02-18 17:27:27 --> Security Class Initialized
DEBUG - 2024-02-18 17:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:27:27 --> Input Class Initialized
INFO - 2024-02-18 17:27:27 --> Language Class Initialized
INFO - 2024-02-18 17:27:27 --> Loader Class Initialized
INFO - 2024-02-18 17:27:27 --> Helper loaded: url_helper
INFO - 2024-02-18 17:27:28 --> Helper loaded: file_helper
INFO - 2024-02-18 17:27:28 --> Helper loaded: form_helper
INFO - 2024-02-18 17:27:28 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:27:28 --> Controller Class Initialized
INFO - 2024-02-18 17:27:28 --> Form Validation Class Initialized
INFO - 2024-02-18 17:27:28 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:27:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:27:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:27:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:27:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:27:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-18 17:27:28 --> Final output sent to browser
DEBUG - 2024-02-18 17:27:28 --> Total execution time: 0.0358
ERROR - 2024-02-18 17:38:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:38:22 --> Config Class Initialized
INFO - 2024-02-18 17:38:22 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:38:22 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:38:22 --> Utf8 Class Initialized
INFO - 2024-02-18 17:38:22 --> URI Class Initialized
INFO - 2024-02-18 17:38:22 --> Router Class Initialized
INFO - 2024-02-18 17:38:22 --> Output Class Initialized
INFO - 2024-02-18 17:38:22 --> Security Class Initialized
DEBUG - 2024-02-18 17:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:38:22 --> Input Class Initialized
INFO - 2024-02-18 17:38:22 --> Language Class Initialized
INFO - 2024-02-18 17:38:22 --> Loader Class Initialized
INFO - 2024-02-18 17:38:22 --> Helper loaded: url_helper
INFO - 2024-02-18 17:38:22 --> Helper loaded: file_helper
INFO - 2024-02-18 17:38:22 --> Helper loaded: form_helper
INFO - 2024-02-18 17:38:22 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:38:22 --> Controller Class Initialized
INFO - 2024-02-18 17:38:22 --> Form Validation Class Initialized
INFO - 2024-02-18 17:38:22 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:38:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:38:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:38:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:38:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:38:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 17:38:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 17:38:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 17:38:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 17:38:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-18 17:38:22 --> Final output sent to browser
DEBUG - 2024-02-18 17:38:22 --> Total execution time: 0.0439
ERROR - 2024-02-18 17:38:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:38:22 --> Config Class Initialized
INFO - 2024-02-18 17:38:22 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:38:22 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:38:22 --> Utf8 Class Initialized
INFO - 2024-02-18 17:38:22 --> URI Class Initialized
INFO - 2024-02-18 17:38:22 --> Router Class Initialized
INFO - 2024-02-18 17:38:22 --> Output Class Initialized
INFO - 2024-02-18 17:38:22 --> Security Class Initialized
DEBUG - 2024-02-18 17:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:38:22 --> Input Class Initialized
INFO - 2024-02-18 17:38:22 --> Language Class Initialized
INFO - 2024-02-18 17:38:22 --> Loader Class Initialized
INFO - 2024-02-18 17:38:22 --> Helper loaded: url_helper
INFO - 2024-02-18 17:38:22 --> Helper loaded: file_helper
INFO - 2024-02-18 17:38:22 --> Helper loaded: form_helper
INFO - 2024-02-18 17:38:22 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:38:22 --> Controller Class Initialized
INFO - 2024-02-18 17:38:22 --> Form Validation Class Initialized
INFO - 2024-02-18 17:38:22 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:38:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:38:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:38:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:38:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 17:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:38:27 --> Config Class Initialized
INFO - 2024-02-18 17:38:27 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:38:27 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:38:27 --> Utf8 Class Initialized
INFO - 2024-02-18 17:38:27 --> URI Class Initialized
INFO - 2024-02-18 17:38:27 --> Router Class Initialized
INFO - 2024-02-18 17:38:27 --> Output Class Initialized
INFO - 2024-02-18 17:38:27 --> Security Class Initialized
DEBUG - 2024-02-18 17:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:38:27 --> Input Class Initialized
INFO - 2024-02-18 17:38:27 --> Language Class Initialized
INFO - 2024-02-18 17:38:27 --> Loader Class Initialized
INFO - 2024-02-18 17:38:27 --> Helper loaded: url_helper
INFO - 2024-02-18 17:38:27 --> Helper loaded: file_helper
INFO - 2024-02-18 17:38:27 --> Helper loaded: form_helper
INFO - 2024-02-18 17:38:27 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:38:27 --> Controller Class Initialized
INFO - 2024-02-18 17:38:27 --> Form Validation Class Initialized
INFO - 2024-02-18 17:38:27 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:38:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:38:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:38:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:38:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 17:38:27 --> Severity: error --> Exception: Call to undefined function explod() D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 50
ERROR - 2024-02-18 17:40:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:40:54 --> Config Class Initialized
INFO - 2024-02-18 17:40:54 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:40:54 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:40:54 --> Utf8 Class Initialized
INFO - 2024-02-18 17:40:54 --> URI Class Initialized
INFO - 2024-02-18 17:40:54 --> Router Class Initialized
INFO - 2024-02-18 17:40:54 --> Output Class Initialized
INFO - 2024-02-18 17:40:54 --> Security Class Initialized
DEBUG - 2024-02-18 17:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:40:54 --> Input Class Initialized
INFO - 2024-02-18 17:40:54 --> Language Class Initialized
INFO - 2024-02-18 17:40:54 --> Loader Class Initialized
INFO - 2024-02-18 17:40:54 --> Helper loaded: url_helper
INFO - 2024-02-18 17:40:54 --> Helper loaded: file_helper
INFO - 2024-02-18 17:40:54 --> Helper loaded: form_helper
INFO - 2024-02-18 17:40:54 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:40:54 --> Controller Class Initialized
INFO - 2024-02-18 17:40:54 --> Form Validation Class Initialized
INFO - 2024-02-18 17:40:54 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:40:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:40:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:40:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:40:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:40:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 17:40:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 17:40:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 17:40:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 17:40:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-18 17:40:54 --> Final output sent to browser
DEBUG - 2024-02-18 17:40:54 --> Total execution time: 0.0430
ERROR - 2024-02-18 17:40:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:40:55 --> Config Class Initialized
INFO - 2024-02-18 17:40:55 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:40:55 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:40:55 --> Utf8 Class Initialized
INFO - 2024-02-18 17:40:55 --> URI Class Initialized
INFO - 2024-02-18 17:40:55 --> Router Class Initialized
INFO - 2024-02-18 17:40:55 --> Output Class Initialized
INFO - 2024-02-18 17:40:55 --> Security Class Initialized
DEBUG - 2024-02-18 17:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:40:55 --> Input Class Initialized
INFO - 2024-02-18 17:40:55 --> Language Class Initialized
INFO - 2024-02-18 17:40:55 --> Loader Class Initialized
INFO - 2024-02-18 17:40:55 --> Helper loaded: url_helper
INFO - 2024-02-18 17:40:55 --> Helper loaded: file_helper
INFO - 2024-02-18 17:40:55 --> Helper loaded: form_helper
INFO - 2024-02-18 17:40:55 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:40:55 --> Controller Class Initialized
INFO - 2024-02-18 17:40:55 --> Form Validation Class Initialized
INFO - 2024-02-18 17:40:55 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:40:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:40:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:40:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:40:55 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 17:40:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:40:59 --> Config Class Initialized
INFO - 2024-02-18 17:40:59 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:40:59 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:40:59 --> Utf8 Class Initialized
INFO - 2024-02-18 17:40:59 --> URI Class Initialized
INFO - 2024-02-18 17:40:59 --> Router Class Initialized
INFO - 2024-02-18 17:40:59 --> Output Class Initialized
INFO - 2024-02-18 17:40:59 --> Security Class Initialized
DEBUG - 2024-02-18 17:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:40:59 --> Input Class Initialized
INFO - 2024-02-18 17:40:59 --> Language Class Initialized
INFO - 2024-02-18 17:40:59 --> Loader Class Initialized
INFO - 2024-02-18 17:40:59 --> Helper loaded: url_helper
INFO - 2024-02-18 17:40:59 --> Helper loaded: file_helper
INFO - 2024-02-18 17:40:59 --> Helper loaded: form_helper
INFO - 2024-02-18 17:40:59 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:40:59 --> Controller Class Initialized
INFO - 2024-02-18 17:40:59 --> Form Validation Class Initialized
INFO - 2024-02-18 17:40:59 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:40:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:40:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:40:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:40:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:40:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-18 17:40:59 --> Final output sent to browser
DEBUG - 2024-02-18 17:40:59 --> Total execution time: 0.0522
ERROR - 2024-02-18 17:41:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:41:08 --> Config Class Initialized
INFO - 2024-02-18 17:41:08 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:41:08 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:41:08 --> Utf8 Class Initialized
INFO - 2024-02-18 17:41:08 --> URI Class Initialized
INFO - 2024-02-18 17:41:08 --> Router Class Initialized
INFO - 2024-02-18 17:41:08 --> Output Class Initialized
INFO - 2024-02-18 17:41:08 --> Security Class Initialized
DEBUG - 2024-02-18 17:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:41:08 --> Input Class Initialized
INFO - 2024-02-18 17:41:08 --> Language Class Initialized
INFO - 2024-02-18 17:41:08 --> Loader Class Initialized
INFO - 2024-02-18 17:41:08 --> Helper loaded: url_helper
INFO - 2024-02-18 17:41:08 --> Helper loaded: file_helper
INFO - 2024-02-18 17:41:08 --> Helper loaded: form_helper
INFO - 2024-02-18 17:41:08 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:41:08 --> Controller Class Initialized
INFO - 2024-02-18 17:41:08 --> Form Validation Class Initialized
INFO - 2024-02-18 17:41:08 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:41:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:41:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:41:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:41:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 17:41:08 --> Severity: error --> Exception: Call to undefined function explod() D:\xampp\htdocs\sscy\application\views\app\item_master\form.php 50
ERROR - 2024-02-18 17:50:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:50:31 --> Config Class Initialized
INFO - 2024-02-18 17:50:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:50:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:50:31 --> Utf8 Class Initialized
INFO - 2024-02-18 17:50:31 --> URI Class Initialized
INFO - 2024-02-18 17:50:31 --> Router Class Initialized
INFO - 2024-02-18 17:50:31 --> Output Class Initialized
INFO - 2024-02-18 17:50:31 --> Security Class Initialized
DEBUG - 2024-02-18 17:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:50:31 --> Input Class Initialized
INFO - 2024-02-18 17:50:31 --> Language Class Initialized
INFO - 2024-02-18 17:50:31 --> Loader Class Initialized
INFO - 2024-02-18 17:50:31 --> Helper loaded: url_helper
INFO - 2024-02-18 17:50:31 --> Helper loaded: file_helper
INFO - 2024-02-18 17:50:31 --> Helper loaded: form_helper
INFO - 2024-02-18 17:50:31 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:50:31 --> Controller Class Initialized
INFO - 2024-02-18 17:50:31 --> Form Validation Class Initialized
INFO - 2024-02-18 17:50:31 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:50:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:50:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:50:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:50:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:50:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 17:50:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 17:50:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 17:50:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 17:50:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-18 17:50:31 --> Final output sent to browser
DEBUG - 2024-02-18 17:50:31 --> Total execution time: 0.0577
ERROR - 2024-02-18 17:50:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:50:31 --> Config Class Initialized
INFO - 2024-02-18 17:50:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:50:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:50:31 --> Utf8 Class Initialized
INFO - 2024-02-18 17:50:31 --> URI Class Initialized
INFO - 2024-02-18 17:50:31 --> Router Class Initialized
INFO - 2024-02-18 17:50:31 --> Output Class Initialized
INFO - 2024-02-18 17:50:31 --> Security Class Initialized
DEBUG - 2024-02-18 17:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:50:31 --> Input Class Initialized
INFO - 2024-02-18 17:50:31 --> Language Class Initialized
INFO - 2024-02-18 17:50:31 --> Loader Class Initialized
INFO - 2024-02-18 17:50:31 --> Helper loaded: url_helper
INFO - 2024-02-18 17:50:31 --> Helper loaded: file_helper
INFO - 2024-02-18 17:50:31 --> Helper loaded: form_helper
INFO - 2024-02-18 17:50:31 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:50:31 --> Controller Class Initialized
INFO - 2024-02-18 17:50:31 --> Form Validation Class Initialized
INFO - 2024-02-18 17:50:31 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:50:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:50:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:50:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:50:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 17:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:50:36 --> Config Class Initialized
INFO - 2024-02-18 17:50:36 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:50:36 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:50:36 --> Utf8 Class Initialized
INFO - 2024-02-18 17:50:36 --> URI Class Initialized
INFO - 2024-02-18 17:50:36 --> Router Class Initialized
INFO - 2024-02-18 17:50:36 --> Output Class Initialized
INFO - 2024-02-18 17:50:36 --> Security Class Initialized
DEBUG - 2024-02-18 17:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:50:36 --> Input Class Initialized
INFO - 2024-02-18 17:50:36 --> Language Class Initialized
INFO - 2024-02-18 17:50:36 --> Loader Class Initialized
INFO - 2024-02-18 17:50:36 --> Helper loaded: url_helper
INFO - 2024-02-18 17:50:36 --> Helper loaded: file_helper
INFO - 2024-02-18 17:50:36 --> Helper loaded: form_helper
INFO - 2024-02-18 17:50:36 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:50:36 --> Controller Class Initialized
INFO - 2024-02-18 17:50:36 --> Form Validation Class Initialized
INFO - 2024-02-18 17:50:36 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:50:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:50:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:50:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:50:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:50:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-18 17:50:36 --> Final output sent to browser
DEBUG - 2024-02-18 17:50:36 --> Total execution time: 0.0569
ERROR - 2024-02-18 17:50:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:50:46 --> Config Class Initialized
INFO - 2024-02-18 17:50:46 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:50:46 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:50:46 --> Utf8 Class Initialized
INFO - 2024-02-18 17:50:46 --> URI Class Initialized
INFO - 2024-02-18 17:50:46 --> Router Class Initialized
INFO - 2024-02-18 17:50:46 --> Output Class Initialized
INFO - 2024-02-18 17:50:46 --> Security Class Initialized
DEBUG - 2024-02-18 17:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:50:46 --> Input Class Initialized
INFO - 2024-02-18 17:50:46 --> Language Class Initialized
INFO - 2024-02-18 17:50:46 --> Loader Class Initialized
INFO - 2024-02-18 17:50:46 --> Helper loaded: url_helper
INFO - 2024-02-18 17:50:46 --> Helper loaded: file_helper
INFO - 2024-02-18 17:50:46 --> Helper loaded: form_helper
INFO - 2024-02-18 17:50:46 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:50:46 --> Controller Class Initialized
INFO - 2024-02-18 17:50:46 --> Form Validation Class Initialized
INFO - 2024-02-18 17:50:46 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:50:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:50:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:50:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:50:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 17:50:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:50:46 --> Config Class Initialized
INFO - 2024-02-18 17:50:46 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:50:46 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:50:46 --> Utf8 Class Initialized
INFO - 2024-02-18 17:50:46 --> URI Class Initialized
INFO - 2024-02-18 17:50:46 --> Router Class Initialized
INFO - 2024-02-18 17:50:46 --> Output Class Initialized
INFO - 2024-02-18 17:50:46 --> Security Class Initialized
DEBUG - 2024-02-18 17:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:50:46 --> Input Class Initialized
INFO - 2024-02-18 17:50:46 --> Language Class Initialized
INFO - 2024-02-18 17:50:46 --> Loader Class Initialized
INFO - 2024-02-18 17:50:46 --> Helper loaded: url_helper
INFO - 2024-02-18 17:50:46 --> Helper loaded: file_helper
INFO - 2024-02-18 17:50:46 --> Helper loaded: form_helper
INFO - 2024-02-18 17:50:46 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:50:46 --> Controller Class Initialized
INFO - 2024-02-18 17:50:46 --> Form Validation Class Initialized
INFO - 2024-02-18 17:50:46 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:50:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:50:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:50:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:50:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-18 17:51:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:51:04 --> Config Class Initialized
INFO - 2024-02-18 17:51:04 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:51:04 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:51:04 --> Utf8 Class Initialized
INFO - 2024-02-18 17:51:04 --> URI Class Initialized
INFO - 2024-02-18 17:51:04 --> Router Class Initialized
INFO - 2024-02-18 17:51:04 --> Output Class Initialized
INFO - 2024-02-18 17:51:04 --> Security Class Initialized
DEBUG - 2024-02-18 17:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:51:04 --> Input Class Initialized
INFO - 2024-02-18 17:51:04 --> Language Class Initialized
INFO - 2024-02-18 17:51:04 --> Loader Class Initialized
INFO - 2024-02-18 17:51:04 --> Helper loaded: url_helper
INFO - 2024-02-18 17:51:04 --> Helper loaded: file_helper
INFO - 2024-02-18 17:51:04 --> Helper loaded: form_helper
INFO - 2024-02-18 17:51:04 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:51:04 --> Controller Class Initialized
INFO - 2024-02-18 17:51:04 --> Form Validation Class Initialized
INFO - 2024-02-18 17:51:04 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:51:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:51:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:51:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:51:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:51:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 17:51:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-18 17:51:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 17:51:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 17:51:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 17:51:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-18 17:51:04 --> Final output sent to browser
DEBUG - 2024-02-18 17:51:04 --> Total execution time: 0.0269
ERROR - 2024-02-18 17:51:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:51:09 --> Config Class Initialized
INFO - 2024-02-18 17:51:09 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:51:09 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:51:09 --> Utf8 Class Initialized
INFO - 2024-02-18 17:51:09 --> URI Class Initialized
INFO - 2024-02-18 17:51:09 --> Router Class Initialized
INFO - 2024-02-18 17:51:09 --> Output Class Initialized
INFO - 2024-02-18 17:51:09 --> Security Class Initialized
DEBUG - 2024-02-18 17:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:51:09 --> Input Class Initialized
INFO - 2024-02-18 17:51:09 --> Language Class Initialized
INFO - 2024-02-18 17:51:09 --> Loader Class Initialized
INFO - 2024-02-18 17:51:09 --> Helper loaded: url_helper
INFO - 2024-02-18 17:51:09 --> Helper loaded: file_helper
INFO - 2024-02-18 17:51:09 --> Helper loaded: form_helper
INFO - 2024-02-18 17:51:09 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:51:09 --> Controller Class Initialized
INFO - 2024-02-18 17:51:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-18 17:51:09 --> Final output sent to browser
DEBUG - 2024-02-18 17:51:09 --> Total execution time: 0.0303
ERROR - 2024-02-18 17:51:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:51:11 --> Config Class Initialized
INFO - 2024-02-18 17:51:11 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:51:11 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:51:11 --> Utf8 Class Initialized
INFO - 2024-02-18 17:51:11 --> URI Class Initialized
INFO - 2024-02-18 17:51:11 --> Router Class Initialized
INFO - 2024-02-18 17:51:11 --> Output Class Initialized
INFO - 2024-02-18 17:51:11 --> Security Class Initialized
DEBUG - 2024-02-18 17:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:51:11 --> Input Class Initialized
INFO - 2024-02-18 17:51:11 --> Language Class Initialized
INFO - 2024-02-18 17:51:11 --> Loader Class Initialized
INFO - 2024-02-18 17:51:11 --> Helper loaded: url_helper
INFO - 2024-02-18 17:51:11 --> Helper loaded: file_helper
INFO - 2024-02-18 17:51:11 --> Helper loaded: form_helper
INFO - 2024-02-18 17:51:11 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:51:11 --> Controller Class Initialized
INFO - 2024-02-18 17:51:11 --> Form Validation Class Initialized
INFO - 2024-02-18 17:51:11 --> Model "MasterModel" initialized
INFO - 2024-02-18 17:51:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-18 17:51:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-18 17:51:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-18 17:51:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-18 17:51:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-18 17:51:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-18 17:51:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-18 17:51:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-18 17:51:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-18 17:51:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-18 17:51:11 --> Final output sent to browser
DEBUG - 2024-02-18 17:51:11 --> Total execution time: 0.0333
ERROR - 2024-02-18 17:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:51:31 --> Config Class Initialized
INFO - 2024-02-18 17:51:31 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:51:31 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:51:31 --> Utf8 Class Initialized
INFO - 2024-02-18 17:51:31 --> URI Class Initialized
INFO - 2024-02-18 17:51:31 --> Router Class Initialized
INFO - 2024-02-18 17:51:31 --> Output Class Initialized
INFO - 2024-02-18 17:51:31 --> Security Class Initialized
DEBUG - 2024-02-18 17:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:51:32 --> Input Class Initialized
INFO - 2024-02-18 17:51:32 --> Language Class Initialized
INFO - 2024-02-18 17:51:32 --> Loader Class Initialized
INFO - 2024-02-18 17:51:32 --> Helper loaded: url_helper
INFO - 2024-02-18 17:51:32 --> Helper loaded: file_helper
INFO - 2024-02-18 17:51:32 --> Helper loaded: form_helper
INFO - 2024-02-18 17:51:32 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:51:32 --> Controller Class Initialized
INFO - 2024-02-18 17:51:32 --> Model "LoginModel" initialized
INFO - 2024-02-18 17:51:32 --> Form Validation Class Initialized
ERROR - 2024-02-18 17:51:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-18 17:51:32 --> Config Class Initialized
INFO - 2024-02-18 17:51:32 --> Hooks Class Initialized
DEBUG - 2024-02-18 17:51:32 --> UTF-8 Support Enabled
INFO - 2024-02-18 17:51:32 --> Utf8 Class Initialized
INFO - 2024-02-18 17:51:32 --> URI Class Initialized
INFO - 2024-02-18 17:51:32 --> Router Class Initialized
INFO - 2024-02-18 17:51:32 --> Output Class Initialized
INFO - 2024-02-18 17:51:32 --> Security Class Initialized
DEBUG - 2024-02-18 17:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-18 17:51:32 --> Input Class Initialized
INFO - 2024-02-18 17:51:32 --> Language Class Initialized
INFO - 2024-02-18 17:51:32 --> Loader Class Initialized
INFO - 2024-02-18 17:51:32 --> Helper loaded: url_helper
INFO - 2024-02-18 17:51:32 --> Helper loaded: file_helper
INFO - 2024-02-18 17:51:32 --> Helper loaded: form_helper
INFO - 2024-02-18 17:51:32 --> Database Driver Class Initialized
DEBUG - 2024-02-18 17:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-18 17:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-18 17:51:32 --> Controller Class Initialized
INFO - 2024-02-18 17:51:32 --> Model "LoginModel" initialized
INFO - 2024-02-18 17:51:32 --> Form Validation Class Initialized
INFO - 2024-02-18 17:51:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-18 17:51:32 --> Final output sent to browser
DEBUG - 2024-02-18 17:51:32 --> Total execution time: 0.0257
