<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-23 11:52:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:52:26 --> Config Class Initialized
INFO - 2024-02-23 11:52:26 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:52:26 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:52:26 --> Utf8 Class Initialized
INFO - 2024-02-23 11:52:26 --> URI Class Initialized
INFO - 2024-02-23 11:52:26 --> Router Class Initialized
INFO - 2024-02-23 11:52:26 --> Output Class Initialized
INFO - 2024-02-23 11:52:26 --> Security Class Initialized
DEBUG - 2024-02-23 11:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:52:26 --> Input Class Initialized
INFO - 2024-02-23 11:52:26 --> Language Class Initialized
INFO - 2024-02-23 11:52:26 --> Loader Class Initialized
INFO - 2024-02-23 11:52:26 --> Helper loaded: url_helper
INFO - 2024-02-23 11:52:26 --> Helper loaded: file_helper
INFO - 2024-02-23 11:52:26 --> Helper loaded: form_helper
INFO - 2024-02-23 11:52:26 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:52:26 --> Controller Class Initialized
INFO - 2024-02-23 11:52:26 --> Model "LoginModel" initialized
INFO - 2024-02-23 11:52:26 --> Form Validation Class Initialized
ERROR - 2024-02-23 11:52:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:52:26 --> Config Class Initialized
INFO - 2024-02-23 11:52:26 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:52:26 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:52:26 --> Utf8 Class Initialized
INFO - 2024-02-23 11:52:26 --> URI Class Initialized
INFO - 2024-02-23 11:52:26 --> Router Class Initialized
INFO - 2024-02-23 11:52:26 --> Output Class Initialized
INFO - 2024-02-23 11:52:26 --> Security Class Initialized
DEBUG - 2024-02-23 11:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:52:26 --> Input Class Initialized
INFO - 2024-02-23 11:52:26 --> Language Class Initialized
INFO - 2024-02-23 11:52:26 --> Loader Class Initialized
INFO - 2024-02-23 11:52:26 --> Helper loaded: url_helper
INFO - 2024-02-23 11:52:26 --> Helper loaded: file_helper
INFO - 2024-02-23 11:52:26 --> Helper loaded: form_helper
INFO - 2024-02-23 11:52:26 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:52:26 --> Controller Class Initialized
INFO - 2024-02-23 11:52:26 --> Form Validation Class Initialized
INFO - 2024-02-23 11:52:26 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:52:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:52:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:52:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:52:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 11:52:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 11:52:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-23 11:52:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 11:52:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 11:52:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 11:52:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-23 11:52:26 --> Final output sent to browser
DEBUG - 2024-02-23 11:52:26 --> Total execution time: 0.0216
ERROR - 2024-02-23 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:52:28 --> Config Class Initialized
INFO - 2024-02-23 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-23 11:52:28 --> URI Class Initialized
INFO - 2024-02-23 11:52:28 --> Router Class Initialized
INFO - 2024-02-23 11:52:28 --> Output Class Initialized
INFO - 2024-02-23 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-23 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:52:28 --> Input Class Initialized
INFO - 2024-02-23 11:52:28 --> Language Class Initialized
INFO - 2024-02-23 11:52:28 --> Loader Class Initialized
INFO - 2024-02-23 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-23 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-23 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-23 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:52:28 --> Controller Class Initialized
INFO - 2024-02-23 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-23 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:52:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:52:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 11:52:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 11:52:28 --> Final output sent to browser
DEBUG - 2024-02-23 11:52:28 --> Total execution time: 0.0320
ERROR - 2024-02-23 11:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:52:28 --> Config Class Initialized
INFO - 2024-02-23 11:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:52:28 --> Utf8 Class Initialized
INFO - 2024-02-23 11:52:28 --> URI Class Initialized
INFO - 2024-02-23 11:52:28 --> Router Class Initialized
INFO - 2024-02-23 11:52:28 --> Output Class Initialized
INFO - 2024-02-23 11:52:28 --> Security Class Initialized
DEBUG - 2024-02-23 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:52:28 --> Input Class Initialized
INFO - 2024-02-23 11:52:28 --> Language Class Initialized
INFO - 2024-02-23 11:52:28 --> Loader Class Initialized
INFO - 2024-02-23 11:52:28 --> Helper loaded: url_helper
INFO - 2024-02-23 11:52:28 --> Helper loaded: file_helper
INFO - 2024-02-23 11:52:28 --> Helper loaded: form_helper
INFO - 2024-02-23 11:52:28 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:52:28 --> Controller Class Initialized
INFO - 2024-02-23 11:52:28 --> Form Validation Class Initialized
INFO - 2024-02-23 11:52:28 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:52:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:52:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:52:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:52:28 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 11:54:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:54:12 --> Config Class Initialized
INFO - 2024-02-23 11:54:12 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:54:12 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:54:12 --> Utf8 Class Initialized
INFO - 2024-02-23 11:54:12 --> URI Class Initialized
INFO - 2024-02-23 11:54:12 --> Router Class Initialized
INFO - 2024-02-23 11:54:12 --> Output Class Initialized
INFO - 2024-02-23 11:54:12 --> Security Class Initialized
DEBUG - 2024-02-23 11:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:54:12 --> Input Class Initialized
INFO - 2024-02-23 11:54:12 --> Language Class Initialized
INFO - 2024-02-23 11:54:12 --> Loader Class Initialized
INFO - 2024-02-23 11:54:12 --> Helper loaded: url_helper
INFO - 2024-02-23 11:54:12 --> Helper loaded: file_helper
INFO - 2024-02-23 11:54:12 --> Helper loaded: form_helper
INFO - 2024-02-23 11:54:12 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:54:12 --> Controller Class Initialized
INFO - 2024-02-23 11:54:12 --> Form Validation Class Initialized
INFO - 2024-02-23 11:54:12 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:54:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:54:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:54:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:54:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 11:54:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 11:54:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 11:54:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 11:54:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 11:54:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 11:54:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 11:54:12 --> Final output sent to browser
DEBUG - 2024-02-23 11:54:12 --> Total execution time: 0.0314
ERROR - 2024-02-23 11:54:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:54:13 --> Config Class Initialized
INFO - 2024-02-23 11:54:13 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:54:13 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:54:13 --> Utf8 Class Initialized
INFO - 2024-02-23 11:54:13 --> URI Class Initialized
INFO - 2024-02-23 11:54:13 --> Router Class Initialized
INFO - 2024-02-23 11:54:13 --> Output Class Initialized
INFO - 2024-02-23 11:54:13 --> Security Class Initialized
DEBUG - 2024-02-23 11:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:54:13 --> Input Class Initialized
INFO - 2024-02-23 11:54:13 --> Language Class Initialized
INFO - 2024-02-23 11:54:13 --> Loader Class Initialized
INFO - 2024-02-23 11:54:13 --> Helper loaded: url_helper
INFO - 2024-02-23 11:54:13 --> Helper loaded: file_helper
INFO - 2024-02-23 11:54:13 --> Helper loaded: form_helper
INFO - 2024-02-23 11:54:13 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:54:13 --> Controller Class Initialized
INFO - 2024-02-23 11:54:13 --> Form Validation Class Initialized
INFO - 2024-02-23 11:54:13 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:54:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:54:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:54:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:54:13 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 11:55:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:55:58 --> Config Class Initialized
INFO - 2024-02-23 11:55:58 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:55:58 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:55:58 --> Utf8 Class Initialized
INFO - 2024-02-23 11:55:58 --> URI Class Initialized
INFO - 2024-02-23 11:55:58 --> Router Class Initialized
INFO - 2024-02-23 11:55:58 --> Output Class Initialized
INFO - 2024-02-23 11:55:58 --> Security Class Initialized
DEBUG - 2024-02-23 11:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:55:58 --> Input Class Initialized
INFO - 2024-02-23 11:55:58 --> Language Class Initialized
INFO - 2024-02-23 11:55:58 --> Loader Class Initialized
INFO - 2024-02-23 11:55:58 --> Helper loaded: url_helper
INFO - 2024-02-23 11:55:58 --> Helper loaded: file_helper
INFO - 2024-02-23 11:55:58 --> Helper loaded: form_helper
INFO - 2024-02-23 11:55:58 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:55:58 --> Controller Class Initialized
INFO - 2024-02-23 11:55:58 --> Form Validation Class Initialized
INFO - 2024-02-23 11:55:58 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:55:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:55:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:55:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:55:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 11:55:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 11:55:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 11:55:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 11:55:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 11:55:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-23 11:55:58 --> Final output sent to browser
DEBUG - 2024-02-23 11:55:58 --> Total execution time: 0.0632
ERROR - 2024-02-23 11:55:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:55:58 --> Config Class Initialized
INFO - 2024-02-23 11:55:58 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:55:58 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:55:58 --> Utf8 Class Initialized
INFO - 2024-02-23 11:55:58 --> URI Class Initialized
INFO - 2024-02-23 11:55:58 --> Router Class Initialized
INFO - 2024-02-23 11:55:58 --> Output Class Initialized
INFO - 2024-02-23 11:55:58 --> Security Class Initialized
DEBUG - 2024-02-23 11:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:55:58 --> Input Class Initialized
INFO - 2024-02-23 11:55:58 --> Language Class Initialized
INFO - 2024-02-23 11:55:58 --> Loader Class Initialized
INFO - 2024-02-23 11:55:58 --> Helper loaded: url_helper
INFO - 2024-02-23 11:55:58 --> Helper loaded: file_helper
INFO - 2024-02-23 11:55:58 --> Helper loaded: form_helper
INFO - 2024-02-23 11:55:58 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:55:58 --> Controller Class Initialized
INFO - 2024-02-23 11:55:58 --> Form Validation Class Initialized
INFO - 2024-02-23 11:55:58 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:55:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:55:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:55:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:55:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 11:56:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:56:02 --> Config Class Initialized
INFO - 2024-02-23 11:56:02 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:56:02 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:56:02 --> Utf8 Class Initialized
INFO - 2024-02-23 11:56:02 --> URI Class Initialized
INFO - 2024-02-23 11:56:02 --> Router Class Initialized
INFO - 2024-02-23 11:56:02 --> Output Class Initialized
INFO - 2024-02-23 11:56:02 --> Security Class Initialized
DEBUG - 2024-02-23 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:56:02 --> Input Class Initialized
INFO - 2024-02-23 11:56:02 --> Language Class Initialized
INFO - 2024-02-23 11:56:02 --> Loader Class Initialized
INFO - 2024-02-23 11:56:02 --> Helper loaded: url_helper
INFO - 2024-02-23 11:56:02 --> Helper loaded: file_helper
INFO - 2024-02-23 11:56:02 --> Helper loaded: form_helper
INFO - 2024-02-23 11:56:02 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:56:02 --> Controller Class Initialized
INFO - 2024-02-23 11:56:02 --> Form Validation Class Initialized
INFO - 2024-02-23 11:56:02 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:56:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:56:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:56:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:56:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 11:56:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-23 11:56:02 --> Final output sent to browser
DEBUG - 2024-02-23 11:56:02 --> Total execution time: 0.0455
ERROR - 2024-02-23 11:57:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:57:06 --> Config Class Initialized
INFO - 2024-02-23 11:57:06 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:57:06 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:57:06 --> Utf8 Class Initialized
INFO - 2024-02-23 11:57:06 --> URI Class Initialized
INFO - 2024-02-23 11:57:06 --> Router Class Initialized
INFO - 2024-02-23 11:57:06 --> Output Class Initialized
INFO - 2024-02-23 11:57:06 --> Security Class Initialized
DEBUG - 2024-02-23 11:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:57:06 --> Input Class Initialized
INFO - 2024-02-23 11:57:06 --> Language Class Initialized
INFO - 2024-02-23 11:57:06 --> Loader Class Initialized
INFO - 2024-02-23 11:57:06 --> Helper loaded: url_helper
INFO - 2024-02-23 11:57:06 --> Helper loaded: file_helper
INFO - 2024-02-23 11:57:06 --> Helper loaded: form_helper
INFO - 2024-02-23 11:57:06 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:57:06 --> Controller Class Initialized
INFO - 2024-02-23 11:57:06 --> Form Validation Class Initialized
INFO - 2024-02-23 11:57:06 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:57:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:57:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:57:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:57:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 11:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 11:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 11:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 11:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 11:57:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-23 11:57:06 --> Final output sent to browser
DEBUG - 2024-02-23 11:57:06 --> Total execution time: 0.0275
ERROR - 2024-02-23 11:57:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:57:06 --> Config Class Initialized
INFO - 2024-02-23 11:57:06 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:57:06 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:57:06 --> Utf8 Class Initialized
INFO - 2024-02-23 11:57:06 --> URI Class Initialized
INFO - 2024-02-23 11:57:06 --> Router Class Initialized
INFO - 2024-02-23 11:57:06 --> Output Class Initialized
INFO - 2024-02-23 11:57:06 --> Security Class Initialized
DEBUG - 2024-02-23 11:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:57:06 --> Input Class Initialized
INFO - 2024-02-23 11:57:06 --> Language Class Initialized
INFO - 2024-02-23 11:57:06 --> Loader Class Initialized
INFO - 2024-02-23 11:57:06 --> Helper loaded: url_helper
INFO - 2024-02-23 11:57:06 --> Helper loaded: file_helper
INFO - 2024-02-23 11:57:06 --> Helper loaded: form_helper
INFO - 2024-02-23 11:57:06 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:57:06 --> Controller Class Initialized
INFO - 2024-02-23 11:57:06 --> Form Validation Class Initialized
INFO - 2024-02-23 11:57:06 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:57:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:57:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:57:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:57:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 11:57:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:57:09 --> Config Class Initialized
INFO - 2024-02-23 11:57:09 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:57:09 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:57:09 --> Utf8 Class Initialized
INFO - 2024-02-23 11:57:09 --> URI Class Initialized
INFO - 2024-02-23 11:57:09 --> Router Class Initialized
INFO - 2024-02-23 11:57:09 --> Output Class Initialized
INFO - 2024-02-23 11:57:09 --> Security Class Initialized
DEBUG - 2024-02-23 11:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:57:09 --> Input Class Initialized
INFO - 2024-02-23 11:57:09 --> Language Class Initialized
INFO - 2024-02-23 11:57:09 --> Loader Class Initialized
INFO - 2024-02-23 11:57:09 --> Helper loaded: url_helper
INFO - 2024-02-23 11:57:09 --> Helper loaded: file_helper
INFO - 2024-02-23 11:57:09 --> Helper loaded: form_helper
INFO - 2024-02-23 11:57:09 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:57:09 --> Controller Class Initialized
INFO - 2024-02-23 11:57:09 --> Form Validation Class Initialized
INFO - 2024-02-23 11:57:09 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:57:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:57:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:57:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:57:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 11:57:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-23 11:57:09 --> Final output sent to browser
DEBUG - 2024-02-23 11:57:09 --> Total execution time: 0.0286
ERROR - 2024-02-23 11:57:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:57:24 --> Config Class Initialized
INFO - 2024-02-23 11:57:24 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:57:24 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:57:24 --> Utf8 Class Initialized
INFO - 2024-02-23 11:57:24 --> URI Class Initialized
INFO - 2024-02-23 11:57:24 --> Router Class Initialized
INFO - 2024-02-23 11:57:24 --> Output Class Initialized
INFO - 2024-02-23 11:57:24 --> Security Class Initialized
DEBUG - 2024-02-23 11:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:57:24 --> Input Class Initialized
INFO - 2024-02-23 11:57:24 --> Language Class Initialized
INFO - 2024-02-23 11:57:24 --> Loader Class Initialized
INFO - 2024-02-23 11:57:24 --> Helper loaded: url_helper
INFO - 2024-02-23 11:57:24 --> Helper loaded: file_helper
INFO - 2024-02-23 11:57:24 --> Helper loaded: form_helper
INFO - 2024-02-23 11:57:24 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:57:24 --> Controller Class Initialized
INFO - 2024-02-23 11:57:25 --> Form Validation Class Initialized
INFO - 2024-02-23 11:57:25 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:57:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:57:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:57:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:57:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 11:57:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-23 11:57:25 --> Final output sent to browser
DEBUG - 2024-02-23 11:57:25 --> Total execution time: 0.0381
ERROR - 2024-02-23 11:57:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:57:30 --> Config Class Initialized
INFO - 2024-02-23 11:57:30 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:57:30 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:57:30 --> Utf8 Class Initialized
INFO - 2024-02-23 11:57:30 --> URI Class Initialized
INFO - 2024-02-23 11:57:30 --> Router Class Initialized
INFO - 2024-02-23 11:57:30 --> Output Class Initialized
INFO - 2024-02-23 11:57:30 --> Security Class Initialized
DEBUG - 2024-02-23 11:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:57:30 --> Input Class Initialized
INFO - 2024-02-23 11:57:30 --> Language Class Initialized
INFO - 2024-02-23 11:57:30 --> Loader Class Initialized
INFO - 2024-02-23 11:57:30 --> Helper loaded: url_helper
INFO - 2024-02-23 11:57:30 --> Helper loaded: file_helper
INFO - 2024-02-23 11:57:30 --> Helper loaded: form_helper
INFO - 2024-02-23 11:57:30 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:57:30 --> Controller Class Initialized
INFO - 2024-02-23 11:57:30 --> Form Validation Class Initialized
INFO - 2024-02-23 11:57:30 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:57:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:57:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:57:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:57:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 11:57:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 11:57:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 11:57:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 11:57:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 11:57:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 11:57:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 11:57:30 --> Final output sent to browser
DEBUG - 2024-02-23 11:57:30 --> Total execution time: 0.0427
ERROR - 2024-02-23 11:57:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 11:57:30 --> Config Class Initialized
INFO - 2024-02-23 11:57:30 --> Hooks Class Initialized
DEBUG - 2024-02-23 11:57:30 --> UTF-8 Support Enabled
INFO - 2024-02-23 11:57:30 --> Utf8 Class Initialized
INFO - 2024-02-23 11:57:30 --> URI Class Initialized
INFO - 2024-02-23 11:57:30 --> Router Class Initialized
INFO - 2024-02-23 11:57:30 --> Output Class Initialized
INFO - 2024-02-23 11:57:30 --> Security Class Initialized
DEBUG - 2024-02-23 11:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 11:57:30 --> Input Class Initialized
INFO - 2024-02-23 11:57:30 --> Language Class Initialized
INFO - 2024-02-23 11:57:30 --> Loader Class Initialized
INFO - 2024-02-23 11:57:30 --> Helper loaded: url_helper
INFO - 2024-02-23 11:57:30 --> Helper loaded: file_helper
INFO - 2024-02-23 11:57:30 --> Helper loaded: form_helper
INFO - 2024-02-23 11:57:30 --> Database Driver Class Initialized
DEBUG - 2024-02-23 11:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 11:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 11:57:30 --> Controller Class Initialized
INFO - 2024-02-23 11:57:30 --> Form Validation Class Initialized
INFO - 2024-02-23 11:57:30 --> Model "MasterModel" initialized
INFO - 2024-02-23 11:57:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 11:57:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 11:57:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 11:57:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:02:43 --> Config Class Initialized
INFO - 2024-02-23 12:02:43 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:02:43 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:02:43 --> Utf8 Class Initialized
INFO - 2024-02-23 12:02:43 --> URI Class Initialized
INFO - 2024-02-23 12:02:43 --> Router Class Initialized
INFO - 2024-02-23 12:02:43 --> Output Class Initialized
INFO - 2024-02-23 12:02:43 --> Security Class Initialized
DEBUG - 2024-02-23 12:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:02:43 --> Input Class Initialized
INFO - 2024-02-23 12:02:43 --> Language Class Initialized
INFO - 2024-02-23 12:02:43 --> Loader Class Initialized
INFO - 2024-02-23 12:02:43 --> Helper loaded: url_helper
INFO - 2024-02-23 12:02:43 --> Helper loaded: file_helper
INFO - 2024-02-23 12:02:43 --> Helper loaded: form_helper
INFO - 2024-02-23 12:02:43 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:02:43 --> Controller Class Initialized
INFO - 2024-02-23 12:02:43 --> Form Validation Class Initialized
INFO - 2024-02-23 12:02:43 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:02:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:02:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:02:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:02:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:02:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:02:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:02:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:02:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:02:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:02:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:02:43 --> Final output sent to browser
DEBUG - 2024-02-23 12:02:43 --> Total execution time: 0.0292
ERROR - 2024-02-23 12:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:02:43 --> Config Class Initialized
INFO - 2024-02-23 12:02:43 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:02:43 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:02:43 --> Utf8 Class Initialized
INFO - 2024-02-23 12:02:43 --> URI Class Initialized
INFO - 2024-02-23 12:02:43 --> Router Class Initialized
INFO - 2024-02-23 12:02:43 --> Output Class Initialized
INFO - 2024-02-23 12:02:43 --> Security Class Initialized
DEBUG - 2024-02-23 12:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:02:43 --> Input Class Initialized
INFO - 2024-02-23 12:02:43 --> Language Class Initialized
INFO - 2024-02-23 12:02:43 --> Loader Class Initialized
INFO - 2024-02-23 12:02:43 --> Helper loaded: url_helper
INFO - 2024-02-23 12:02:43 --> Helper loaded: file_helper
INFO - 2024-02-23 12:02:43 --> Helper loaded: form_helper
INFO - 2024-02-23 12:02:43 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:02:43 --> Controller Class Initialized
INFO - 2024-02-23 12:02:43 --> Form Validation Class Initialized
INFO - 2024-02-23 12:02:43 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:02:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:02:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:02:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:02:43 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:04:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:04:14 --> Config Class Initialized
INFO - 2024-02-23 12:04:14 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:04:14 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:04:14 --> Utf8 Class Initialized
INFO - 2024-02-23 12:04:14 --> URI Class Initialized
INFO - 2024-02-23 12:04:14 --> Router Class Initialized
INFO - 2024-02-23 12:04:14 --> Output Class Initialized
INFO - 2024-02-23 12:04:14 --> Security Class Initialized
DEBUG - 2024-02-23 12:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:04:14 --> Input Class Initialized
INFO - 2024-02-23 12:04:14 --> Language Class Initialized
INFO - 2024-02-23 12:04:14 --> Loader Class Initialized
INFO - 2024-02-23 12:04:14 --> Helper loaded: url_helper
INFO - 2024-02-23 12:04:14 --> Helper loaded: file_helper
INFO - 2024-02-23 12:04:14 --> Helper loaded: form_helper
INFO - 2024-02-23 12:04:14 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:04:14 --> Controller Class Initialized
INFO - 2024-02-23 12:04:14 --> Form Validation Class Initialized
INFO - 2024-02-23 12:04:14 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:04:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:04:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:04:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:04:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:04:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:04:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:04:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:04:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:04:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:04:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:04:14 --> Final output sent to browser
DEBUG - 2024-02-23 12:04:14 --> Total execution time: 0.0345
ERROR - 2024-02-23 12:04:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:04:14 --> Config Class Initialized
INFO - 2024-02-23 12:04:14 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:04:14 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:04:14 --> Utf8 Class Initialized
INFO - 2024-02-23 12:04:14 --> URI Class Initialized
INFO - 2024-02-23 12:04:14 --> Router Class Initialized
INFO - 2024-02-23 12:04:14 --> Output Class Initialized
INFO - 2024-02-23 12:04:14 --> Security Class Initialized
DEBUG - 2024-02-23 12:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:04:14 --> Input Class Initialized
INFO - 2024-02-23 12:04:14 --> Language Class Initialized
INFO - 2024-02-23 12:04:14 --> Loader Class Initialized
INFO - 2024-02-23 12:04:14 --> Helper loaded: url_helper
INFO - 2024-02-23 12:04:14 --> Helper loaded: file_helper
INFO - 2024-02-23 12:04:14 --> Helper loaded: form_helper
INFO - 2024-02-23 12:04:14 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:04:14 --> Controller Class Initialized
INFO - 2024-02-23 12:04:14 --> Form Validation Class Initialized
INFO - 2024-02-23 12:04:14 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:04:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:04:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:04:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:04:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:04:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:04:25 --> Config Class Initialized
INFO - 2024-02-23 12:04:25 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:04:25 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:04:25 --> Utf8 Class Initialized
INFO - 2024-02-23 12:04:25 --> URI Class Initialized
INFO - 2024-02-23 12:04:25 --> Router Class Initialized
INFO - 2024-02-23 12:04:25 --> Output Class Initialized
INFO - 2024-02-23 12:04:25 --> Security Class Initialized
DEBUG - 2024-02-23 12:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:04:25 --> Input Class Initialized
INFO - 2024-02-23 12:04:25 --> Language Class Initialized
INFO - 2024-02-23 12:04:25 --> Loader Class Initialized
INFO - 2024-02-23 12:04:25 --> Helper loaded: url_helper
INFO - 2024-02-23 12:04:25 --> Helper loaded: file_helper
INFO - 2024-02-23 12:04:25 --> Helper loaded: form_helper
INFO - 2024-02-23 12:04:25 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:04:25 --> Controller Class Initialized
INFO - 2024-02-23 12:04:25 --> Form Validation Class Initialized
INFO - 2024-02-23 12:04:25 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:04:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:04:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:04:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:04:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:04:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:04:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:04:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:04:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:04:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:04:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:04:25 --> Final output sent to browser
DEBUG - 2024-02-23 12:04:25 --> Total execution time: 0.0389
ERROR - 2024-02-23 12:04:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:04:52 --> Config Class Initialized
INFO - 2024-02-23 12:04:52 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:04:52 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:04:52 --> Utf8 Class Initialized
INFO - 2024-02-23 12:04:52 --> URI Class Initialized
INFO - 2024-02-23 12:04:52 --> Router Class Initialized
INFO - 2024-02-23 12:04:52 --> Output Class Initialized
INFO - 2024-02-23 12:04:52 --> Security Class Initialized
DEBUG - 2024-02-23 12:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:04:52 --> Input Class Initialized
INFO - 2024-02-23 12:04:52 --> Language Class Initialized
INFO - 2024-02-23 12:04:52 --> Loader Class Initialized
INFO - 2024-02-23 12:04:52 --> Helper loaded: url_helper
INFO - 2024-02-23 12:04:52 --> Helper loaded: file_helper
INFO - 2024-02-23 12:04:52 --> Helper loaded: form_helper
INFO - 2024-02-23 12:04:52 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:04:52 --> Controller Class Initialized
INFO - 2024-02-23 12:04:52 --> Form Validation Class Initialized
INFO - 2024-02-23 12:04:52 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:04:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:04:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:04:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:04:52 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:04:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:04:54 --> Config Class Initialized
INFO - 2024-02-23 12:04:54 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:04:54 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:04:54 --> Utf8 Class Initialized
INFO - 2024-02-23 12:04:54 --> URI Class Initialized
INFO - 2024-02-23 12:04:54 --> Router Class Initialized
INFO - 2024-02-23 12:04:54 --> Output Class Initialized
INFO - 2024-02-23 12:04:54 --> Security Class Initialized
DEBUG - 2024-02-23 12:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:04:54 --> Input Class Initialized
INFO - 2024-02-23 12:04:54 --> Language Class Initialized
INFO - 2024-02-23 12:04:54 --> Loader Class Initialized
INFO - 2024-02-23 12:04:54 --> Helper loaded: url_helper
INFO - 2024-02-23 12:04:54 --> Helper loaded: file_helper
INFO - 2024-02-23 12:04:54 --> Helper loaded: form_helper
INFO - 2024-02-23 12:04:54 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:04:54 --> Controller Class Initialized
INFO - 2024-02-23 12:04:54 --> Form Validation Class Initialized
INFO - 2024-02-23 12:04:54 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:04:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:04:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:04:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:04:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:10:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:10:04 --> Config Class Initialized
INFO - 2024-02-23 12:10:04 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:10:04 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:10:04 --> Utf8 Class Initialized
INFO - 2024-02-23 12:10:04 --> URI Class Initialized
INFO - 2024-02-23 12:10:04 --> Router Class Initialized
INFO - 2024-02-23 12:10:04 --> Output Class Initialized
INFO - 2024-02-23 12:10:04 --> Security Class Initialized
DEBUG - 2024-02-23 12:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:10:04 --> Input Class Initialized
INFO - 2024-02-23 12:10:04 --> Language Class Initialized
INFO - 2024-02-23 12:10:04 --> Loader Class Initialized
INFO - 2024-02-23 12:10:04 --> Helper loaded: url_helper
INFO - 2024-02-23 12:10:04 --> Helper loaded: file_helper
INFO - 2024-02-23 12:10:04 --> Helper loaded: form_helper
INFO - 2024-02-23 12:10:04 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:10:04 --> Controller Class Initialized
INFO - 2024-02-23 12:10:04 --> Form Validation Class Initialized
INFO - 2024-02-23 12:10:04 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:10:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:10:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:10:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:10:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:10:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:10:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:10:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:10:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:10:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:10:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:10:04 --> Final output sent to browser
DEBUG - 2024-02-23 12:10:04 --> Total execution time: 0.0436
ERROR - 2024-02-23 12:10:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:10:05 --> Config Class Initialized
INFO - 2024-02-23 12:10:05 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:10:05 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:10:05 --> Utf8 Class Initialized
INFO - 2024-02-23 12:10:05 --> URI Class Initialized
INFO - 2024-02-23 12:10:05 --> Router Class Initialized
INFO - 2024-02-23 12:10:05 --> Output Class Initialized
INFO - 2024-02-23 12:10:05 --> Security Class Initialized
DEBUG - 2024-02-23 12:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:10:05 --> Input Class Initialized
INFO - 2024-02-23 12:10:05 --> Language Class Initialized
INFO - 2024-02-23 12:10:05 --> Loader Class Initialized
INFO - 2024-02-23 12:10:05 --> Helper loaded: url_helper
INFO - 2024-02-23 12:10:05 --> Helper loaded: file_helper
INFO - 2024-02-23 12:10:05 --> Helper loaded: form_helper
INFO - 2024-02-23 12:10:05 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:10:05 --> Controller Class Initialized
INFO - 2024-02-23 12:10:05 --> Form Validation Class Initialized
INFO - 2024-02-23 12:10:05 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:10:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:10:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:10:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:10:05 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:10:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:10:13 --> Config Class Initialized
INFO - 2024-02-23 12:10:13 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:10:13 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:10:13 --> Utf8 Class Initialized
INFO - 2024-02-23 12:10:13 --> URI Class Initialized
INFO - 2024-02-23 12:10:13 --> Router Class Initialized
INFO - 2024-02-23 12:10:13 --> Output Class Initialized
INFO - 2024-02-23 12:10:13 --> Security Class Initialized
DEBUG - 2024-02-23 12:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:10:13 --> Input Class Initialized
INFO - 2024-02-23 12:10:13 --> Language Class Initialized
INFO - 2024-02-23 12:10:13 --> Loader Class Initialized
INFO - 2024-02-23 12:10:13 --> Helper loaded: url_helper
INFO - 2024-02-23 12:10:13 --> Helper loaded: file_helper
INFO - 2024-02-23 12:10:13 --> Helper loaded: form_helper
INFO - 2024-02-23 12:10:13 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:10:13 --> Controller Class Initialized
INFO - 2024-02-23 12:10:13 --> Form Validation Class Initialized
INFO - 2024-02-23 12:10:13 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:10:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:10:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:10:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:10:13 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:10:36 --> Config Class Initialized
INFO - 2024-02-23 12:10:36 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:10:36 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:10:36 --> Utf8 Class Initialized
INFO - 2024-02-23 12:10:36 --> URI Class Initialized
INFO - 2024-02-23 12:10:36 --> Router Class Initialized
INFO - 2024-02-23 12:10:36 --> Output Class Initialized
INFO - 2024-02-23 12:10:36 --> Security Class Initialized
DEBUG - 2024-02-23 12:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:10:36 --> Input Class Initialized
INFO - 2024-02-23 12:10:36 --> Language Class Initialized
INFO - 2024-02-23 12:10:36 --> Loader Class Initialized
INFO - 2024-02-23 12:10:36 --> Helper loaded: url_helper
INFO - 2024-02-23 12:10:36 --> Helper loaded: file_helper
INFO - 2024-02-23 12:10:36 --> Helper loaded: form_helper
INFO - 2024-02-23 12:10:36 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:10:36 --> Controller Class Initialized
INFO - 2024-02-23 12:10:36 --> Form Validation Class Initialized
INFO - 2024-02-23 12:10:36 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:10:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:10:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:10:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:10:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:10:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:10:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:10:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:10:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:10:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:10:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:10:36 --> Final output sent to browser
DEBUG - 2024-02-23 12:10:36 --> Total execution time: 0.0559
ERROR - 2024-02-23 12:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:11:27 --> Config Class Initialized
INFO - 2024-02-23 12:11:27 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:11:27 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:11:27 --> Utf8 Class Initialized
INFO - 2024-02-23 12:11:27 --> URI Class Initialized
INFO - 2024-02-23 12:11:27 --> Router Class Initialized
INFO - 2024-02-23 12:11:27 --> Output Class Initialized
INFO - 2024-02-23 12:11:27 --> Security Class Initialized
DEBUG - 2024-02-23 12:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:11:27 --> Input Class Initialized
INFO - 2024-02-23 12:11:27 --> Language Class Initialized
INFO - 2024-02-23 12:11:27 --> Loader Class Initialized
INFO - 2024-02-23 12:11:27 --> Helper loaded: url_helper
INFO - 2024-02-23 12:11:27 --> Helper loaded: file_helper
INFO - 2024-02-23 12:11:27 --> Helper loaded: form_helper
INFO - 2024-02-23 12:11:27 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:11:27 --> Controller Class Initialized
INFO - 2024-02-23 12:11:27 --> Form Validation Class Initialized
INFO - 2024-02-23 12:11:27 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:11:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:11:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:11:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:11:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:11:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:11:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:11:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:11:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:11:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:11:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:11:27 --> Final output sent to browser
DEBUG - 2024-02-23 12:11:27 --> Total execution time: 0.0402
ERROR - 2024-02-23 12:11:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:11:31 --> Config Class Initialized
INFO - 2024-02-23 12:11:31 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:11:31 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:11:31 --> Utf8 Class Initialized
INFO - 2024-02-23 12:11:31 --> URI Class Initialized
INFO - 2024-02-23 12:11:31 --> Router Class Initialized
INFO - 2024-02-23 12:11:31 --> Output Class Initialized
INFO - 2024-02-23 12:11:31 --> Security Class Initialized
DEBUG - 2024-02-23 12:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:11:31 --> Input Class Initialized
INFO - 2024-02-23 12:11:31 --> Language Class Initialized
INFO - 2024-02-23 12:11:31 --> Loader Class Initialized
INFO - 2024-02-23 12:11:31 --> Helper loaded: url_helper
INFO - 2024-02-23 12:11:31 --> Helper loaded: file_helper
INFO - 2024-02-23 12:11:31 --> Helper loaded: form_helper
INFO - 2024-02-23 12:11:31 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:11:31 --> Controller Class Initialized
INFO - 2024-02-23 12:11:31 --> Form Validation Class Initialized
INFO - 2024-02-23 12:11:31 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:11:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:11:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:11:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:11:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:11:31 --> Final output sent to browser
DEBUG - 2024-02-23 12:11:31 --> Total execution time: 0.0330
ERROR - 2024-02-23 12:11:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:11:31 --> Config Class Initialized
INFO - 2024-02-23 12:11:31 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:11:31 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:11:31 --> Utf8 Class Initialized
INFO - 2024-02-23 12:11:31 --> URI Class Initialized
INFO - 2024-02-23 12:11:31 --> Router Class Initialized
INFO - 2024-02-23 12:11:31 --> Output Class Initialized
INFO - 2024-02-23 12:11:31 --> Security Class Initialized
DEBUG - 2024-02-23 12:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:11:31 --> Input Class Initialized
INFO - 2024-02-23 12:11:31 --> Language Class Initialized
INFO - 2024-02-23 12:11:31 --> Loader Class Initialized
INFO - 2024-02-23 12:11:31 --> Helper loaded: url_helper
INFO - 2024-02-23 12:11:31 --> Helper loaded: file_helper
INFO - 2024-02-23 12:11:31 --> Helper loaded: form_helper
INFO - 2024-02-23 12:11:31 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:11:31 --> Controller Class Initialized
INFO - 2024-02-23 12:11:31 --> Form Validation Class Initialized
INFO - 2024-02-23 12:11:31 --> Model "MasterModel" initialized
ERROR - 2024-02-23 12:11:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:11:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:11:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:11:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:11:31 --> Config Class Initialized
INFO - 2024-02-23 12:11:31 --> Hooks Class Initialized
INFO - 2024-02-23 12:11:31 --> Model "ItemMasterModel" initialized
DEBUG - 2024-02-23 12:11:31 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:11:31 --> Utf8 Class Initialized
INFO - 2024-02-23 12:11:31 --> URI Class Initialized
INFO - 2024-02-23 12:11:31 --> Router Class Initialized
INFO - 2024-02-23 12:11:31 --> Output Class Initialized
INFO - 2024-02-23 12:11:31 --> Security Class Initialized
DEBUG - 2024-02-23 12:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:11:31 --> Input Class Initialized
INFO - 2024-02-23 12:11:31 --> Language Class Initialized
INFO - 2024-02-23 12:11:31 --> Loader Class Initialized
INFO - 2024-02-23 12:11:31 --> Helper loaded: url_helper
INFO - 2024-02-23 12:11:31 --> Helper loaded: file_helper
INFO - 2024-02-23 12:11:31 --> Helper loaded: form_helper
INFO - 2024-02-23 12:11:31 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:11:31 --> Final output sent to browser
DEBUG - 2024-02-23 12:11:31 --> Total execution time: 0.0945
INFO - 2024-02-23 12:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:11:31 --> Controller Class Initialized
INFO - 2024-02-23 12:11:31 --> Form Validation Class Initialized
INFO - 2024-02-23 12:11:31 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:11:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:11:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:11:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:11:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:11:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:11:31 --> Final output sent to browser
DEBUG - 2024-02-23 12:11:31 --> Total execution time: 0.0486
ERROR - 2024-02-23 12:11:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:11:51 --> Config Class Initialized
INFO - 2024-02-23 12:11:51 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:11:51 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:11:51 --> Utf8 Class Initialized
INFO - 2024-02-23 12:11:51 --> URI Class Initialized
INFO - 2024-02-23 12:11:51 --> Router Class Initialized
INFO - 2024-02-23 12:11:51 --> Output Class Initialized
INFO - 2024-02-23 12:11:51 --> Security Class Initialized
DEBUG - 2024-02-23 12:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:11:51 --> Input Class Initialized
INFO - 2024-02-23 12:11:51 --> Language Class Initialized
INFO - 2024-02-23 12:11:51 --> Loader Class Initialized
INFO - 2024-02-23 12:11:51 --> Helper loaded: url_helper
INFO - 2024-02-23 12:11:51 --> Helper loaded: file_helper
INFO - 2024-02-23 12:11:51 --> Helper loaded: form_helper
INFO - 2024-02-23 12:11:51 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:11:51 --> Controller Class Initialized
INFO - 2024-02-23 12:11:51 --> Form Validation Class Initialized
INFO - 2024-02-23 12:11:51 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:11:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:11:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:11:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:11:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:11:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:11:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:11:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:11:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:11:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:11:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:11:51 --> Final output sent to browser
DEBUG - 2024-02-23 12:11:51 --> Total execution time: 0.0353
ERROR - 2024-02-23 12:12:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:12:01 --> Config Class Initialized
INFO - 2024-02-23 12:12:01 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:12:01 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:12:01 --> Utf8 Class Initialized
INFO - 2024-02-23 12:12:01 --> URI Class Initialized
INFO - 2024-02-23 12:12:01 --> Router Class Initialized
INFO - 2024-02-23 12:12:01 --> Output Class Initialized
INFO - 2024-02-23 12:12:01 --> Security Class Initialized
DEBUG - 2024-02-23 12:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:12:01 --> Input Class Initialized
INFO - 2024-02-23 12:12:01 --> Language Class Initialized
INFO - 2024-02-23 12:12:01 --> Loader Class Initialized
INFO - 2024-02-23 12:12:01 --> Helper loaded: url_helper
INFO - 2024-02-23 12:12:01 --> Helper loaded: file_helper
INFO - 2024-02-23 12:12:01 --> Helper loaded: form_helper
INFO - 2024-02-23 12:12:01 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:12:01 --> Controller Class Initialized
INFO - 2024-02-23 12:12:01 --> Form Validation Class Initialized
INFO - 2024-02-23 12:12:01 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:12:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:12:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:12:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:12:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:12:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:12:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:12:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:12:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:12:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:12:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:12:01 --> Final output sent to browser
DEBUG - 2024-02-23 12:12:01 --> Total execution time: 0.0295
ERROR - 2024-02-23 12:13:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:13:21 --> Config Class Initialized
INFO - 2024-02-23 12:13:21 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:13:21 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:13:21 --> Utf8 Class Initialized
INFO - 2024-02-23 12:13:21 --> URI Class Initialized
INFO - 2024-02-23 12:13:21 --> Router Class Initialized
INFO - 2024-02-23 12:13:21 --> Output Class Initialized
INFO - 2024-02-23 12:13:21 --> Security Class Initialized
DEBUG - 2024-02-23 12:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:13:21 --> Input Class Initialized
INFO - 2024-02-23 12:13:21 --> Language Class Initialized
INFO - 2024-02-23 12:13:21 --> Loader Class Initialized
INFO - 2024-02-23 12:13:21 --> Helper loaded: url_helper
INFO - 2024-02-23 12:13:21 --> Helper loaded: file_helper
INFO - 2024-02-23 12:13:21 --> Helper loaded: form_helper
INFO - 2024-02-23 12:13:21 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:13:21 --> Controller Class Initialized
INFO - 2024-02-23 12:13:21 --> Form Validation Class Initialized
INFO - 2024-02-23 12:13:21 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:13:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:13:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:13:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:13:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:13:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:13:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:13:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:13:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:13:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:13:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:13:21 --> Final output sent to browser
DEBUG - 2024-02-23 12:13:21 --> Total execution time: 0.0370
ERROR - 2024-02-23 12:13:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:13:26 --> Config Class Initialized
INFO - 2024-02-23 12:13:26 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:13:26 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:13:26 --> Utf8 Class Initialized
INFO - 2024-02-23 12:13:26 --> URI Class Initialized
INFO - 2024-02-23 12:13:26 --> Router Class Initialized
INFO - 2024-02-23 12:13:26 --> Output Class Initialized
INFO - 2024-02-23 12:13:26 --> Security Class Initialized
DEBUG - 2024-02-23 12:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:13:26 --> Input Class Initialized
INFO - 2024-02-23 12:13:26 --> Language Class Initialized
INFO - 2024-02-23 12:13:26 --> Loader Class Initialized
INFO - 2024-02-23 12:13:26 --> Helper loaded: url_helper
INFO - 2024-02-23 12:13:26 --> Helper loaded: file_helper
INFO - 2024-02-23 12:13:26 --> Helper loaded: form_helper
INFO - 2024-02-23 12:13:26 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:13:26 --> Controller Class Initialized
INFO - 2024-02-23 12:13:26 --> Form Validation Class Initialized
INFO - 2024-02-23 12:13:26 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:13:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:13:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:13:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:13:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:13:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:13:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:13:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:13:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:13:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:13:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:13:26 --> Final output sent to browser
DEBUG - 2024-02-23 12:13:26 --> Total execution time: 0.0321
ERROR - 2024-02-23 12:13:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:13:47 --> Config Class Initialized
INFO - 2024-02-23 12:13:47 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:13:47 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:13:47 --> Utf8 Class Initialized
INFO - 2024-02-23 12:13:47 --> URI Class Initialized
INFO - 2024-02-23 12:13:47 --> Router Class Initialized
INFO - 2024-02-23 12:13:47 --> Output Class Initialized
INFO - 2024-02-23 12:13:47 --> Security Class Initialized
DEBUG - 2024-02-23 12:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:13:47 --> Input Class Initialized
INFO - 2024-02-23 12:13:47 --> Language Class Initialized
INFO - 2024-02-23 12:13:47 --> Loader Class Initialized
INFO - 2024-02-23 12:13:47 --> Helper loaded: url_helper
INFO - 2024-02-23 12:13:47 --> Helper loaded: file_helper
INFO - 2024-02-23 12:13:47 --> Helper loaded: form_helper
INFO - 2024-02-23 12:13:47 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:13:47 --> Controller Class Initialized
INFO - 2024-02-23 12:13:47 --> Form Validation Class Initialized
INFO - 2024-02-23 12:13:47 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:13:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:13:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:13:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:13:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:13:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:13:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:13:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:13:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:13:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:13:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:13:47 --> Final output sent to browser
DEBUG - 2024-02-23 12:13:47 --> Total execution time: 0.0335
ERROR - 2024-02-23 12:15:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:15:04 --> Config Class Initialized
INFO - 2024-02-23 12:15:04 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:15:04 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:15:04 --> Utf8 Class Initialized
INFO - 2024-02-23 12:15:04 --> URI Class Initialized
INFO - 2024-02-23 12:15:04 --> Router Class Initialized
INFO - 2024-02-23 12:15:04 --> Output Class Initialized
INFO - 2024-02-23 12:15:04 --> Security Class Initialized
DEBUG - 2024-02-23 12:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:15:04 --> Input Class Initialized
INFO - 2024-02-23 12:15:04 --> Language Class Initialized
INFO - 2024-02-23 12:15:04 --> Loader Class Initialized
INFO - 2024-02-23 12:15:04 --> Helper loaded: url_helper
INFO - 2024-02-23 12:15:04 --> Helper loaded: file_helper
INFO - 2024-02-23 12:15:04 --> Helper loaded: form_helper
INFO - 2024-02-23 12:15:04 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:15:04 --> Controller Class Initialized
INFO - 2024-02-23 12:15:04 --> Form Validation Class Initialized
INFO - 2024-02-23 12:15:04 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:15:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:15:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:15:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:15:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:15:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:15:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:15:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:15:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:15:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:15:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:15:04 --> Final output sent to browser
DEBUG - 2024-02-23 12:15:04 --> Total execution time: 0.0353
ERROR - 2024-02-23 12:15:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:15:05 --> Config Class Initialized
INFO - 2024-02-23 12:15:05 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:15:05 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:15:05 --> Utf8 Class Initialized
INFO - 2024-02-23 12:15:05 --> URI Class Initialized
INFO - 2024-02-23 12:15:05 --> Router Class Initialized
INFO - 2024-02-23 12:15:05 --> Output Class Initialized
INFO - 2024-02-23 12:15:05 --> Security Class Initialized
DEBUG - 2024-02-23 12:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:15:05 --> Input Class Initialized
INFO - 2024-02-23 12:15:05 --> Language Class Initialized
INFO - 2024-02-23 12:15:05 --> Loader Class Initialized
INFO - 2024-02-23 12:15:05 --> Helper loaded: url_helper
INFO - 2024-02-23 12:15:05 --> Helper loaded: file_helper
INFO - 2024-02-23 12:15:05 --> Helper loaded: form_helper
INFO - 2024-02-23 12:15:05 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:15:05 --> Controller Class Initialized
INFO - 2024-02-23 12:15:05 --> Form Validation Class Initialized
INFO - 2024-02-23 12:15:05 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:15:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:15:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:15:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:15:05 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:15:05 --> Severity: Notice --> Undefined index: draw D:\xampp\htdocs\sscy\application\models\MasterModel.php 6
ERROR - 2024-02-23 12:15:05 --> Severity: Notice --> Undefined index: start D:\xampp\htdocs\sscy\application\models\MasterModel.php 7
ERROR - 2024-02-23 12:15:05 --> Severity: Notice --> Undefined index: length D:\xampp\htdocs\sscy\application\models\MasterModel.php 8
ERROR - 2024-02-23 12:15:05 --> Severity: Notice --> Undefined index: search D:\xampp\htdocs\sscy\application\models\MasterModel.php 9
ERROR - 2024-02-23 12:15:05 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\sscy\application\models\MasterModel.php 9
ERROR - 2024-02-23 12:15:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:15:30 --> Config Class Initialized
INFO - 2024-02-23 12:15:30 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:15:30 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:15:30 --> Utf8 Class Initialized
INFO - 2024-02-23 12:15:30 --> URI Class Initialized
INFO - 2024-02-23 12:15:30 --> Router Class Initialized
INFO - 2024-02-23 12:15:30 --> Output Class Initialized
INFO - 2024-02-23 12:15:30 --> Security Class Initialized
DEBUG - 2024-02-23 12:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:15:30 --> Input Class Initialized
INFO - 2024-02-23 12:15:30 --> Language Class Initialized
INFO - 2024-02-23 12:15:30 --> Loader Class Initialized
INFO - 2024-02-23 12:15:30 --> Helper loaded: url_helper
INFO - 2024-02-23 12:15:30 --> Helper loaded: file_helper
INFO - 2024-02-23 12:15:30 --> Helper loaded: form_helper
INFO - 2024-02-23 12:15:30 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:15:30 --> Controller Class Initialized
INFO - 2024-02-23 12:15:30 --> Form Validation Class Initialized
INFO - 2024-02-23 12:15:30 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:15:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:15:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:15:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:15:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:15:30 --> Final output sent to browser
DEBUG - 2024-02-23 12:15:30 --> Total execution time: 0.0369
ERROR - 2024-02-23 12:15:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:15:31 --> Config Class Initialized
INFO - 2024-02-23 12:15:31 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:15:31 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:15:31 --> Utf8 Class Initialized
INFO - 2024-02-23 12:15:31 --> URI Class Initialized
INFO - 2024-02-23 12:15:31 --> Router Class Initialized
INFO - 2024-02-23 12:15:31 --> Output Class Initialized
INFO - 2024-02-23 12:15:31 --> Security Class Initialized
DEBUG - 2024-02-23 12:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:15:31 --> Input Class Initialized
INFO - 2024-02-23 12:15:31 --> Language Class Initialized
INFO - 2024-02-23 12:15:31 --> Loader Class Initialized
INFO - 2024-02-23 12:15:31 --> Helper loaded: url_helper
INFO - 2024-02-23 12:15:31 --> Helper loaded: file_helper
INFO - 2024-02-23 12:15:31 --> Helper loaded: form_helper
INFO - 2024-02-23 12:15:31 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:15:31 --> Controller Class Initialized
INFO - 2024-02-23 12:15:31 --> Form Validation Class Initialized
INFO - 2024-02-23 12:15:31 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:15:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:15:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:15:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:15:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:15:31 --> Severity: Notice --> Undefined index: draw D:\xampp\htdocs\sscy\application\models\MasterModel.php 6
ERROR - 2024-02-23 12:15:31 --> Severity: Notice --> Undefined index: start D:\xampp\htdocs\sscy\application\models\MasterModel.php 7
ERROR - 2024-02-23 12:15:31 --> Severity: Notice --> Undefined index: length D:\xampp\htdocs\sscy\application\models\MasterModel.php 8
ERROR - 2024-02-23 12:15:31 --> Severity: Notice --> Undefined index: search D:\xampp\htdocs\sscy\application\models\MasterModel.php 9
ERROR - 2024-02-23 12:15:31 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\sscy\application\models\MasterModel.php 9
ERROR - 2024-02-23 12:16:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:16:04 --> Config Class Initialized
INFO - 2024-02-23 12:16:04 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:16:04 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:16:04 --> Utf8 Class Initialized
INFO - 2024-02-23 12:16:04 --> URI Class Initialized
INFO - 2024-02-23 12:16:04 --> Router Class Initialized
INFO - 2024-02-23 12:16:04 --> Output Class Initialized
INFO - 2024-02-23 12:16:04 --> Security Class Initialized
DEBUG - 2024-02-23 12:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:16:04 --> Input Class Initialized
INFO - 2024-02-23 12:16:04 --> Language Class Initialized
INFO - 2024-02-23 12:16:04 --> Loader Class Initialized
INFO - 2024-02-23 12:16:04 --> Helper loaded: url_helper
INFO - 2024-02-23 12:16:04 --> Helper loaded: file_helper
INFO - 2024-02-23 12:16:04 --> Helper loaded: form_helper
INFO - 2024-02-23 12:16:04 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:16:04 --> Controller Class Initialized
INFO - 2024-02-23 12:16:04 --> Form Validation Class Initialized
INFO - 2024-02-23 12:16:04 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:16:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:16:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:16:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:16:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:16:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:16:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:16:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:16:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:16:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:16:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:16:04 --> Final output sent to browser
DEBUG - 2024-02-23 12:16:04 --> Total execution time: 0.0498
ERROR - 2024-02-23 12:16:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:16:06 --> Config Class Initialized
INFO - 2024-02-23 12:16:06 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:16:06 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:16:06 --> Utf8 Class Initialized
INFO - 2024-02-23 12:16:06 --> URI Class Initialized
INFO - 2024-02-23 12:16:06 --> Router Class Initialized
INFO - 2024-02-23 12:16:06 --> Output Class Initialized
INFO - 2024-02-23 12:16:06 --> Security Class Initialized
DEBUG - 2024-02-23 12:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:16:06 --> Input Class Initialized
INFO - 2024-02-23 12:16:06 --> Language Class Initialized
INFO - 2024-02-23 12:16:06 --> Loader Class Initialized
INFO - 2024-02-23 12:16:06 --> Helper loaded: url_helper
INFO - 2024-02-23 12:16:06 --> Helper loaded: file_helper
INFO - 2024-02-23 12:16:06 --> Helper loaded: form_helper
INFO - 2024-02-23 12:16:06 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:16:06 --> Controller Class Initialized
INFO - 2024-02-23 12:16:06 --> Form Validation Class Initialized
INFO - 2024-02-23 12:16:06 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:16:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:16:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:16:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:16:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:16:06 --> Severity: Notice --> Undefined index: draw D:\xampp\htdocs\sscy\application\models\MasterModel.php 6
ERROR - 2024-02-23 12:16:06 --> Severity: Notice --> Undefined index: start D:\xampp\htdocs\sscy\application\models\MasterModel.php 7
ERROR - 2024-02-23 12:16:06 --> Severity: Notice --> Undefined index: length D:\xampp\htdocs\sscy\application\models\MasterModel.php 8
ERROR - 2024-02-23 12:16:06 --> Severity: Notice --> Undefined index: search D:\xampp\htdocs\sscy\application\models\MasterModel.php 9
ERROR - 2024-02-23 12:16:06 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\sscy\application\models\MasterModel.php 9
ERROR - 2024-02-23 12:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:16:17 --> Config Class Initialized
INFO - 2024-02-23 12:16:17 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:16:17 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:16:17 --> Utf8 Class Initialized
INFO - 2024-02-23 12:16:17 --> URI Class Initialized
INFO - 2024-02-23 12:16:17 --> Router Class Initialized
INFO - 2024-02-23 12:16:17 --> Output Class Initialized
INFO - 2024-02-23 12:16:17 --> Security Class Initialized
DEBUG - 2024-02-23 12:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:16:17 --> Input Class Initialized
INFO - 2024-02-23 12:16:17 --> Language Class Initialized
INFO - 2024-02-23 12:16:17 --> Loader Class Initialized
INFO - 2024-02-23 12:16:17 --> Helper loaded: url_helper
INFO - 2024-02-23 12:16:17 --> Helper loaded: file_helper
INFO - 2024-02-23 12:16:17 --> Helper loaded: form_helper
INFO - 2024-02-23 12:16:17 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:16:17 --> Controller Class Initialized
INFO - 2024-02-23 12:16:17 --> Form Validation Class Initialized
INFO - 2024-02-23 12:16:17 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:16:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:16:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:16:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:16:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:16:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:16:17 --> Final output sent to browser
DEBUG - 2024-02-23 12:16:17 --> Total execution time: 0.0345
ERROR - 2024-02-23 12:16:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:16:42 --> Config Class Initialized
INFO - 2024-02-23 12:16:42 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:16:42 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:16:42 --> Utf8 Class Initialized
INFO - 2024-02-23 12:16:42 --> URI Class Initialized
INFO - 2024-02-23 12:16:42 --> Router Class Initialized
INFO - 2024-02-23 12:16:42 --> Output Class Initialized
INFO - 2024-02-23 12:16:42 --> Security Class Initialized
DEBUG - 2024-02-23 12:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:16:42 --> Input Class Initialized
INFO - 2024-02-23 12:16:42 --> Language Class Initialized
INFO - 2024-02-23 12:16:42 --> Loader Class Initialized
INFO - 2024-02-23 12:16:42 --> Helper loaded: url_helper
INFO - 2024-02-23 12:16:42 --> Helper loaded: file_helper
INFO - 2024-02-23 12:16:42 --> Helper loaded: form_helper
INFO - 2024-02-23 12:16:42 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:16:42 --> Controller Class Initialized
INFO - 2024-02-23 12:16:42 --> Form Validation Class Initialized
INFO - 2024-02-23 12:16:42 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:16:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:16:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:16:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:16:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:16:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:16:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:16:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:16:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:16:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:16:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:16:42 --> Final output sent to browser
DEBUG - 2024-02-23 12:16:42 --> Total execution time: 0.0382
ERROR - 2024-02-23 12:17:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:17:05 --> Config Class Initialized
INFO - 2024-02-23 12:17:05 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:17:05 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:17:05 --> Utf8 Class Initialized
INFO - 2024-02-23 12:17:05 --> URI Class Initialized
INFO - 2024-02-23 12:17:05 --> Router Class Initialized
INFO - 2024-02-23 12:17:05 --> Output Class Initialized
INFO - 2024-02-23 12:17:05 --> Security Class Initialized
DEBUG - 2024-02-23 12:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:17:05 --> Input Class Initialized
INFO - 2024-02-23 12:17:05 --> Language Class Initialized
INFO - 2024-02-23 12:17:05 --> Loader Class Initialized
INFO - 2024-02-23 12:17:05 --> Helper loaded: url_helper
INFO - 2024-02-23 12:17:05 --> Helper loaded: file_helper
INFO - 2024-02-23 12:17:05 --> Helper loaded: form_helper
INFO - 2024-02-23 12:17:05 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:17:05 --> Controller Class Initialized
INFO - 2024-02-23 12:17:05 --> Form Validation Class Initialized
INFO - 2024-02-23 12:17:05 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:17:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:17:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:17:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:17:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:17:05 --> Final output sent to browser
DEBUG - 2024-02-23 12:17:05 --> Total execution time: 0.0484
ERROR - 2024-02-23 12:17:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:17:05 --> Config Class Initialized
INFO - 2024-02-23 12:17:05 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:17:05 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:17:05 --> Utf8 Class Initialized
INFO - 2024-02-23 12:17:05 --> URI Class Initialized
INFO - 2024-02-23 12:17:05 --> Router Class Initialized
INFO - 2024-02-23 12:17:05 --> Output Class Initialized
INFO - 2024-02-23 12:17:05 --> Security Class Initialized
DEBUG - 2024-02-23 12:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:17:05 --> Input Class Initialized
INFO - 2024-02-23 12:17:05 --> Language Class Initialized
INFO - 2024-02-23 12:17:05 --> Loader Class Initialized
INFO - 2024-02-23 12:17:05 --> Helper loaded: url_helper
INFO - 2024-02-23 12:17:05 --> Helper loaded: file_helper
INFO - 2024-02-23 12:17:05 --> Helper loaded: form_helper
INFO - 2024-02-23 12:17:05 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:17:05 --> Controller Class Initialized
INFO - 2024-02-23 12:17:05 --> Form Validation Class Initialized
INFO - 2024-02-23 12:17:05 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:17:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:17:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:17:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:17:05 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:18:28 --> Config Class Initialized
INFO - 2024-02-23 12:18:28 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:18:28 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:18:28 --> Utf8 Class Initialized
INFO - 2024-02-23 12:18:28 --> URI Class Initialized
INFO - 2024-02-23 12:18:28 --> Router Class Initialized
INFO - 2024-02-23 12:18:28 --> Output Class Initialized
INFO - 2024-02-23 12:18:28 --> Security Class Initialized
DEBUG - 2024-02-23 12:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:18:28 --> Input Class Initialized
INFO - 2024-02-23 12:18:28 --> Language Class Initialized
INFO - 2024-02-23 12:18:28 --> Loader Class Initialized
INFO - 2024-02-23 12:18:28 --> Helper loaded: url_helper
INFO - 2024-02-23 12:18:28 --> Helper loaded: file_helper
INFO - 2024-02-23 12:18:28 --> Helper loaded: form_helper
INFO - 2024-02-23 12:18:28 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:18:28 --> Controller Class Initialized
INFO - 2024-02-23 12:18:28 --> Form Validation Class Initialized
INFO - 2024-02-23 12:18:28 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:18:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:18:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:18:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:18:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:18:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:18:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:18:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:18:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:18:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:18:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:18:28 --> Final output sent to browser
DEBUG - 2024-02-23 12:18:28 --> Total execution time: 0.0304
ERROR - 2024-02-23 12:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:18:28 --> Config Class Initialized
INFO - 2024-02-23 12:18:28 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:18:28 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:18:28 --> Utf8 Class Initialized
INFO - 2024-02-23 12:18:28 --> URI Class Initialized
INFO - 2024-02-23 12:18:28 --> Router Class Initialized
INFO - 2024-02-23 12:18:28 --> Output Class Initialized
INFO - 2024-02-23 12:18:28 --> Security Class Initialized
DEBUG - 2024-02-23 12:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:18:28 --> Input Class Initialized
INFO - 2024-02-23 12:18:28 --> Language Class Initialized
INFO - 2024-02-23 12:18:28 --> Loader Class Initialized
INFO - 2024-02-23 12:18:28 --> Helper loaded: url_helper
INFO - 2024-02-23 12:18:28 --> Helper loaded: file_helper
INFO - 2024-02-23 12:18:28 --> Helper loaded: form_helper
INFO - 2024-02-23 12:18:28 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:18:28 --> Controller Class Initialized
INFO - 2024-02-23 12:18:28 --> Form Validation Class Initialized
INFO - 2024-02-23 12:18:28 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:18:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:18:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:18:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:18:28 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:18:57 --> Config Class Initialized
INFO - 2024-02-23 12:18:57 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:18:57 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:18:57 --> Utf8 Class Initialized
INFO - 2024-02-23 12:18:57 --> URI Class Initialized
INFO - 2024-02-23 12:18:57 --> Router Class Initialized
INFO - 2024-02-23 12:18:57 --> Output Class Initialized
INFO - 2024-02-23 12:18:57 --> Security Class Initialized
DEBUG - 2024-02-23 12:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:18:57 --> Input Class Initialized
INFO - 2024-02-23 12:18:57 --> Language Class Initialized
INFO - 2024-02-23 12:18:57 --> Loader Class Initialized
INFO - 2024-02-23 12:18:57 --> Helper loaded: url_helper
INFO - 2024-02-23 12:18:57 --> Helper loaded: file_helper
INFO - 2024-02-23 12:18:57 --> Helper loaded: form_helper
INFO - 2024-02-23 12:18:57 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:18:57 --> Controller Class Initialized
INFO - 2024-02-23 12:18:57 --> Form Validation Class Initialized
INFO - 2024-02-23 12:18:57 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:18:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:18:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:18:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:18:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:18:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:18:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:18:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:18:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:18:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-23 12:18:57 --> Final output sent to browser
DEBUG - 2024-02-23 12:18:57 --> Total execution time: 0.0287
ERROR - 2024-02-23 12:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:18:57 --> Config Class Initialized
INFO - 2024-02-23 12:18:57 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:18:57 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:18:57 --> Utf8 Class Initialized
INFO - 2024-02-23 12:18:57 --> URI Class Initialized
INFO - 2024-02-23 12:18:57 --> Router Class Initialized
INFO - 2024-02-23 12:18:57 --> Output Class Initialized
INFO - 2024-02-23 12:18:57 --> Security Class Initialized
DEBUG - 2024-02-23 12:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:18:57 --> Input Class Initialized
INFO - 2024-02-23 12:18:57 --> Language Class Initialized
INFO - 2024-02-23 12:18:57 --> Loader Class Initialized
INFO - 2024-02-23 12:18:57 --> Helper loaded: url_helper
INFO - 2024-02-23 12:18:57 --> Helper loaded: file_helper
INFO - 2024-02-23 12:18:57 --> Helper loaded: form_helper
INFO - 2024-02-23 12:18:57 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:18:57 --> Controller Class Initialized
INFO - 2024-02-23 12:18:57 --> Form Validation Class Initialized
INFO - 2024-02-23 12:18:57 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:18:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:18:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:18:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:18:57 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:20:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:20:08 --> Config Class Initialized
INFO - 2024-02-23 12:20:08 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:20:08 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:20:08 --> Utf8 Class Initialized
INFO - 2024-02-23 12:20:08 --> URI Class Initialized
INFO - 2024-02-23 12:20:08 --> Router Class Initialized
INFO - 2024-02-23 12:20:08 --> Output Class Initialized
INFO - 2024-02-23 12:20:08 --> Security Class Initialized
DEBUG - 2024-02-23 12:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:20:08 --> Input Class Initialized
INFO - 2024-02-23 12:20:08 --> Language Class Initialized
INFO - 2024-02-23 12:20:08 --> Loader Class Initialized
INFO - 2024-02-23 12:20:08 --> Helper loaded: url_helper
INFO - 2024-02-23 12:20:08 --> Helper loaded: file_helper
INFO - 2024-02-23 12:20:08 --> Helper loaded: form_helper
INFO - 2024-02-23 12:20:08 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:20:08 --> Controller Class Initialized
INFO - 2024-02-23 12:20:08 --> Form Validation Class Initialized
INFO - 2024-02-23 12:20:08 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:20:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:20:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:20:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:20:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:20:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:20:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:20:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:20:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:20:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-23 12:20:08 --> Final output sent to browser
DEBUG - 2024-02-23 12:20:08 --> Total execution time: 0.0316
ERROR - 2024-02-23 12:20:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:20:08 --> Config Class Initialized
INFO - 2024-02-23 12:20:08 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:20:08 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:20:08 --> Utf8 Class Initialized
INFO - 2024-02-23 12:20:08 --> URI Class Initialized
INFO - 2024-02-23 12:20:08 --> Router Class Initialized
INFO - 2024-02-23 12:20:08 --> Output Class Initialized
INFO - 2024-02-23 12:20:08 --> Security Class Initialized
DEBUG - 2024-02-23 12:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:20:08 --> Input Class Initialized
INFO - 2024-02-23 12:20:08 --> Language Class Initialized
INFO - 2024-02-23 12:20:08 --> Loader Class Initialized
INFO - 2024-02-23 12:20:08 --> Helper loaded: url_helper
INFO - 2024-02-23 12:20:08 --> Helper loaded: file_helper
INFO - 2024-02-23 12:20:08 --> Helper loaded: form_helper
INFO - 2024-02-23 12:20:08 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:20:08 --> Controller Class Initialized
INFO - 2024-02-23 12:20:08 --> Form Validation Class Initialized
INFO - 2024-02-23 12:20:08 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:20:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:20:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:20:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:20:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:20:12 --> Config Class Initialized
INFO - 2024-02-23 12:20:12 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:20:12 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:20:12 --> Utf8 Class Initialized
INFO - 2024-02-23 12:20:12 --> URI Class Initialized
INFO - 2024-02-23 12:20:12 --> Router Class Initialized
INFO - 2024-02-23 12:20:12 --> Output Class Initialized
INFO - 2024-02-23 12:20:12 --> Security Class Initialized
DEBUG - 2024-02-23 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:20:12 --> Input Class Initialized
INFO - 2024-02-23 12:20:12 --> Language Class Initialized
INFO - 2024-02-23 12:20:12 --> Loader Class Initialized
INFO - 2024-02-23 12:20:12 --> Helper loaded: url_helper
INFO - 2024-02-23 12:20:12 --> Helper loaded: file_helper
INFO - 2024-02-23 12:20:12 --> Helper loaded: form_helper
INFO - 2024-02-23 12:20:12 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:20:12 --> Controller Class Initialized
INFO - 2024-02-23 12:20:12 --> Form Validation Class Initialized
INFO - 2024-02-23 12:20:12 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:20:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:20:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:20:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:20:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:20:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:20:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:20:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:20:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:20:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:20:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:20:12 --> Final output sent to browser
DEBUG - 2024-02-23 12:20:12 --> Total execution time: 0.0311
ERROR - 2024-02-23 12:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:20:12 --> Config Class Initialized
INFO - 2024-02-23 12:20:12 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:20:12 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:20:12 --> Utf8 Class Initialized
INFO - 2024-02-23 12:20:12 --> URI Class Initialized
INFO - 2024-02-23 12:20:12 --> Router Class Initialized
INFO - 2024-02-23 12:20:12 --> Output Class Initialized
INFO - 2024-02-23 12:20:12 --> Security Class Initialized
DEBUG - 2024-02-23 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:20:12 --> Input Class Initialized
INFO - 2024-02-23 12:20:12 --> Language Class Initialized
INFO - 2024-02-23 12:20:12 --> Loader Class Initialized
INFO - 2024-02-23 12:20:12 --> Helper loaded: url_helper
INFO - 2024-02-23 12:20:12 --> Helper loaded: file_helper
INFO - 2024-02-23 12:20:12 --> Helper loaded: form_helper
INFO - 2024-02-23 12:20:12 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:20:12 --> Controller Class Initialized
INFO - 2024-02-23 12:20:12 --> Form Validation Class Initialized
INFO - 2024-02-23 12:20:12 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:20:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:20:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:20:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:20:12 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:21:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:21:45 --> Config Class Initialized
INFO - 2024-02-23 12:21:45 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:21:45 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:21:45 --> Utf8 Class Initialized
INFO - 2024-02-23 12:21:45 --> URI Class Initialized
INFO - 2024-02-23 12:21:45 --> Router Class Initialized
INFO - 2024-02-23 12:21:45 --> Output Class Initialized
INFO - 2024-02-23 12:21:45 --> Security Class Initialized
DEBUG - 2024-02-23 12:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:21:45 --> Input Class Initialized
INFO - 2024-02-23 12:21:45 --> Language Class Initialized
INFO - 2024-02-23 12:21:45 --> Loader Class Initialized
INFO - 2024-02-23 12:21:45 --> Helper loaded: url_helper
INFO - 2024-02-23 12:21:45 --> Helper loaded: file_helper
INFO - 2024-02-23 12:21:45 --> Helper loaded: form_helper
INFO - 2024-02-23 12:21:45 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:21:45 --> Controller Class Initialized
INFO - 2024-02-23 12:21:45 --> Form Validation Class Initialized
INFO - 2024-02-23 12:21:45 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:21:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:21:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:21:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:21:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:21:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:21:45 --> Final output sent to browser
DEBUG - 2024-02-23 12:21:45 --> Total execution time: 0.0404
ERROR - 2024-02-23 12:21:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:21:45 --> Config Class Initialized
INFO - 2024-02-23 12:21:45 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:21:45 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:21:45 --> Utf8 Class Initialized
INFO - 2024-02-23 12:21:45 --> URI Class Initialized
INFO - 2024-02-23 12:21:45 --> Router Class Initialized
INFO - 2024-02-23 12:21:45 --> Output Class Initialized
INFO - 2024-02-23 12:21:46 --> Security Class Initialized
DEBUG - 2024-02-23 12:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:21:46 --> Input Class Initialized
INFO - 2024-02-23 12:21:46 --> Language Class Initialized
INFO - 2024-02-23 12:21:46 --> Loader Class Initialized
INFO - 2024-02-23 12:21:46 --> Helper loaded: url_helper
INFO - 2024-02-23 12:21:46 --> Helper loaded: file_helper
INFO - 2024-02-23 12:21:46 --> Helper loaded: form_helper
INFO - 2024-02-23 12:21:46 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:21:46 --> Controller Class Initialized
INFO - 2024-02-23 12:21:46 --> Form Validation Class Initialized
INFO - 2024-02-23 12:21:46 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:21:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:21:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:21:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:21:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:21:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:21:53 --> Config Class Initialized
INFO - 2024-02-23 12:21:53 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:21:53 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:21:53 --> Utf8 Class Initialized
INFO - 2024-02-23 12:21:53 --> URI Class Initialized
INFO - 2024-02-23 12:21:53 --> Router Class Initialized
INFO - 2024-02-23 12:21:53 --> Output Class Initialized
INFO - 2024-02-23 12:21:53 --> Security Class Initialized
DEBUG - 2024-02-23 12:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:21:53 --> Input Class Initialized
INFO - 2024-02-23 12:21:53 --> Language Class Initialized
INFO - 2024-02-23 12:21:53 --> Loader Class Initialized
INFO - 2024-02-23 12:21:53 --> Helper loaded: url_helper
INFO - 2024-02-23 12:21:53 --> Helper loaded: file_helper
INFO - 2024-02-23 12:21:53 --> Helper loaded: form_helper
INFO - 2024-02-23 12:21:53 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:21:53 --> Controller Class Initialized
INFO - 2024-02-23 12:21:53 --> Form Validation Class Initialized
INFO - 2024-02-23 12:21:53 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:21:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:21:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:21:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:21:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:21:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:21:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:21:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:21:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:21:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:21:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:21:53 --> Final output sent to browser
DEBUG - 2024-02-23 12:21:53 --> Total execution time: 0.0324
ERROR - 2024-02-23 12:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:21:54 --> Config Class Initialized
INFO - 2024-02-23 12:21:54 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:21:54 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:21:54 --> Utf8 Class Initialized
INFO - 2024-02-23 12:21:54 --> URI Class Initialized
INFO - 2024-02-23 12:21:54 --> Router Class Initialized
INFO - 2024-02-23 12:21:54 --> Output Class Initialized
INFO - 2024-02-23 12:21:54 --> Security Class Initialized
DEBUG - 2024-02-23 12:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:21:54 --> Input Class Initialized
INFO - 2024-02-23 12:21:54 --> Language Class Initialized
INFO - 2024-02-23 12:21:54 --> Loader Class Initialized
INFO - 2024-02-23 12:21:54 --> Helper loaded: url_helper
INFO - 2024-02-23 12:21:54 --> Helper loaded: file_helper
INFO - 2024-02-23 12:21:54 --> Helper loaded: form_helper
INFO - 2024-02-23 12:21:54 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:21:54 --> Controller Class Initialized
INFO - 2024-02-23 12:21:54 --> Form Validation Class Initialized
INFO - 2024-02-23 12:21:54 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:21:54 --> Config Class Initialized
INFO - 2024-02-23 12:21:54 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:21:54 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:21:54 --> Utf8 Class Initialized
INFO - 2024-02-23 12:21:54 --> URI Class Initialized
INFO - 2024-02-23 12:21:54 --> Router Class Initialized
INFO - 2024-02-23 12:21:54 --> Output Class Initialized
INFO - 2024-02-23 12:21:54 --> Security Class Initialized
DEBUG - 2024-02-23 12:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:21:54 --> Input Class Initialized
INFO - 2024-02-23 12:21:54 --> Language Class Initialized
INFO - 2024-02-23 12:21:54 --> Loader Class Initialized
ERROR - 2024-02-23 12:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:21:54 --> Helper loaded: url_helper
INFO - 2024-02-23 12:21:54 --> Config Class Initialized
INFO - 2024-02-23 12:21:54 --> Hooks Class Initialized
INFO - 2024-02-23 12:21:54 --> Helper loaded: file_helper
DEBUG - 2024-02-23 12:21:54 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:21:54 --> Utf8 Class Initialized
INFO - 2024-02-23 12:21:54 --> URI Class Initialized
INFO - 2024-02-23 12:21:54 --> Helper loaded: form_helper
INFO - 2024-02-23 12:21:54 --> Router Class Initialized
INFO - 2024-02-23 12:21:54 --> Output Class Initialized
INFO - 2024-02-23 12:21:54 --> Security Class Initialized
DEBUG - 2024-02-23 12:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:21:54 --> Input Class Initialized
INFO - 2024-02-23 12:21:54 --> Language Class Initialized
INFO - 2024-02-23 12:21:54 --> Database Driver Class Initialized
INFO - 2024-02-23 12:21:54 --> Loader Class Initialized
INFO - 2024-02-23 12:21:54 --> Helper loaded: url_helper
DEBUG - 2024-02-23 12:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:21:54 --> Helper loaded: file_helper
INFO - 2024-02-23 12:21:54 --> Controller Class Initialized
INFO - 2024-02-23 12:21:54 --> Helper loaded: form_helper
INFO - 2024-02-23 12:21:54 --> Form Validation Class Initialized
INFO - 2024-02-23 12:21:54 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:21:54 --> Database Driver Class Initialized
INFO - 2024-02-23 12:21:54 --> Model "ItemMasterModel" initialized
DEBUG - 2024-02-23 12:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:21:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:21:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:21:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:21:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:21:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:21:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:21:54 --> Final output sent to browser
DEBUG - 2024-02-23 12:21:54 --> Total execution time: 0.0493
INFO - 2024-02-23 12:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:21:54 --> Controller Class Initialized
INFO - 2024-02-23 12:21:54 --> Form Validation Class Initialized
INFO - 2024-02-23 12:21:54 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:21:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:21:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:21:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:21:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:21:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:21:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:21:54 --> Final output sent to browser
DEBUG - 2024-02-23 12:21:54 --> Total execution time: 0.0642
ERROR - 2024-02-23 12:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:21:54 --> Config Class Initialized
INFO - 2024-02-23 12:21:54 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:21:54 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:21:54 --> Utf8 Class Initialized
INFO - 2024-02-23 12:21:54 --> URI Class Initialized
INFO - 2024-02-23 12:21:54 --> Router Class Initialized
INFO - 2024-02-23 12:21:54 --> Output Class Initialized
INFO - 2024-02-23 12:21:54 --> Security Class Initialized
DEBUG - 2024-02-23 12:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:21:54 --> Input Class Initialized
INFO - 2024-02-23 12:21:54 --> Language Class Initialized
INFO - 2024-02-23 12:21:54 --> Loader Class Initialized
INFO - 2024-02-23 12:21:54 --> Helper loaded: url_helper
INFO - 2024-02-23 12:21:54 --> Helper loaded: file_helper
INFO - 2024-02-23 12:21:54 --> Helper loaded: form_helper
INFO - 2024-02-23 12:21:54 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:21:54 --> Controller Class Initialized
INFO - 2024-02-23 12:21:54 --> Form Validation Class Initialized
INFO - 2024-02-23 12:21:54 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:21:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:22:35 --> Config Class Initialized
INFO - 2024-02-23 12:22:35 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:22:35 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:22:35 --> Utf8 Class Initialized
INFO - 2024-02-23 12:22:35 --> URI Class Initialized
INFO - 2024-02-23 12:22:35 --> Router Class Initialized
INFO - 2024-02-23 12:22:35 --> Output Class Initialized
INFO - 2024-02-23 12:22:35 --> Security Class Initialized
DEBUG - 2024-02-23 12:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:22:35 --> Input Class Initialized
INFO - 2024-02-23 12:22:35 --> Language Class Initialized
INFO - 2024-02-23 12:22:35 --> Loader Class Initialized
INFO - 2024-02-23 12:22:35 --> Helper loaded: url_helper
INFO - 2024-02-23 12:22:35 --> Helper loaded: file_helper
INFO - 2024-02-23 12:22:35 --> Helper loaded: form_helper
INFO - 2024-02-23 12:22:35 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:22:35 --> Controller Class Initialized
INFO - 2024-02-23 12:22:35 --> Form Validation Class Initialized
INFO - 2024-02-23 12:22:35 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:22:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:22:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:22:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:22:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:22:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:22:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:22:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:22:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:22:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:22:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:22:35 --> Final output sent to browser
DEBUG - 2024-02-23 12:22:35 --> Total execution time: 0.0350
ERROR - 2024-02-23 12:22:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:22:37 --> Config Class Initialized
INFO - 2024-02-23 12:22:37 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:22:37 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:22:37 --> Utf8 Class Initialized
INFO - 2024-02-23 12:22:37 --> URI Class Initialized
INFO - 2024-02-23 12:22:37 --> Router Class Initialized
INFO - 2024-02-23 12:22:37 --> Output Class Initialized
INFO - 2024-02-23 12:22:37 --> Security Class Initialized
DEBUG - 2024-02-23 12:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:22:37 --> Input Class Initialized
INFO - 2024-02-23 12:22:37 --> Language Class Initialized
INFO - 2024-02-23 12:22:37 --> Loader Class Initialized
INFO - 2024-02-23 12:22:37 --> Helper loaded: url_helper
INFO - 2024-02-23 12:22:37 --> Helper loaded: file_helper
INFO - 2024-02-23 12:22:37 --> Helper loaded: form_helper
INFO - 2024-02-23 12:22:37 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:22:37 --> Controller Class Initialized
INFO - 2024-02-23 12:22:37 --> Form Validation Class Initialized
INFO - 2024-02-23 12:22:37 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:22:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:22:37 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:22:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:22:37 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:22:53 --> Config Class Initialized
INFO - 2024-02-23 12:22:53 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:22:53 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:22:53 --> Utf8 Class Initialized
INFO - 2024-02-23 12:22:53 --> URI Class Initialized
INFO - 2024-02-23 12:22:53 --> Router Class Initialized
INFO - 2024-02-23 12:22:53 --> Output Class Initialized
INFO - 2024-02-23 12:22:53 --> Security Class Initialized
DEBUG - 2024-02-23 12:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:22:53 --> Input Class Initialized
INFO - 2024-02-23 12:22:53 --> Language Class Initialized
INFO - 2024-02-23 12:22:53 --> Loader Class Initialized
INFO - 2024-02-23 12:22:53 --> Helper loaded: url_helper
INFO - 2024-02-23 12:22:53 --> Helper loaded: file_helper
INFO - 2024-02-23 12:22:53 --> Helper loaded: form_helper
INFO - 2024-02-23 12:22:53 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:22:53 --> Controller Class Initialized
INFO - 2024-02-23 12:22:53 --> Form Validation Class Initialized
INFO - 2024-02-23 12:22:53 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:22:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:22:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:22:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:22:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:22:53 --> Final output sent to browser
DEBUG - 2024-02-23 12:22:53 --> Total execution time: 0.0329
ERROR - 2024-02-23 12:22:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:22:54 --> Config Class Initialized
INFO - 2024-02-23 12:22:54 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:22:54 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:22:54 --> Utf8 Class Initialized
INFO - 2024-02-23 12:22:54 --> URI Class Initialized
INFO - 2024-02-23 12:22:54 --> Router Class Initialized
INFO - 2024-02-23 12:22:54 --> Output Class Initialized
INFO - 2024-02-23 12:22:54 --> Security Class Initialized
DEBUG - 2024-02-23 12:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:22:54 --> Input Class Initialized
INFO - 2024-02-23 12:22:54 --> Language Class Initialized
INFO - 2024-02-23 12:22:54 --> Loader Class Initialized
INFO - 2024-02-23 12:22:54 --> Helper loaded: url_helper
INFO - 2024-02-23 12:22:54 --> Helper loaded: file_helper
INFO - 2024-02-23 12:22:54 --> Helper loaded: form_helper
INFO - 2024-02-23 12:22:54 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:22:54 --> Controller Class Initialized
INFO - 2024-02-23 12:22:54 --> Form Validation Class Initialized
INFO - 2024-02-23 12:22:54 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:22:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:22:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:22:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:22:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:23:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:23:18 --> Config Class Initialized
INFO - 2024-02-23 12:23:18 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:23:18 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:23:18 --> Utf8 Class Initialized
INFO - 2024-02-23 12:23:18 --> URI Class Initialized
INFO - 2024-02-23 12:23:18 --> Router Class Initialized
INFO - 2024-02-23 12:23:18 --> Output Class Initialized
INFO - 2024-02-23 12:23:18 --> Security Class Initialized
DEBUG - 2024-02-23 12:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:23:18 --> Input Class Initialized
INFO - 2024-02-23 12:23:18 --> Language Class Initialized
INFO - 2024-02-23 12:23:18 --> Loader Class Initialized
INFO - 2024-02-23 12:23:18 --> Helper loaded: url_helper
INFO - 2024-02-23 12:23:18 --> Helper loaded: file_helper
INFO - 2024-02-23 12:23:18 --> Helper loaded: form_helper
INFO - 2024-02-23 12:23:18 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:23:18 --> Controller Class Initialized
INFO - 2024-02-23 12:23:18 --> Form Validation Class Initialized
INFO - 2024-02-23 12:23:18 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:23:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:23:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:23:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:23:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:23:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:23:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:23:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:23:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:23:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:23:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:23:18 --> Final output sent to browser
DEBUG - 2024-02-23 12:23:18 --> Total execution time: 0.0388
ERROR - 2024-02-23 12:23:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:23:18 --> Config Class Initialized
INFO - 2024-02-23 12:23:18 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:23:18 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:23:18 --> Utf8 Class Initialized
INFO - 2024-02-23 12:23:18 --> URI Class Initialized
INFO - 2024-02-23 12:23:18 --> Router Class Initialized
INFO - 2024-02-23 12:23:18 --> Output Class Initialized
INFO - 2024-02-23 12:23:18 --> Security Class Initialized
DEBUG - 2024-02-23 12:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:23:18 --> Input Class Initialized
INFO - 2024-02-23 12:23:18 --> Language Class Initialized
INFO - 2024-02-23 12:23:18 --> Loader Class Initialized
INFO - 2024-02-23 12:23:18 --> Helper loaded: url_helper
INFO - 2024-02-23 12:23:18 --> Helper loaded: file_helper
INFO - 2024-02-23 12:23:18 --> Helper loaded: form_helper
INFO - 2024-02-23 12:23:18 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:23:18 --> Controller Class Initialized
INFO - 2024-02-23 12:23:18 --> Form Validation Class Initialized
INFO - 2024-02-23 12:23:18 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:23:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:23:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:23:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:23:18 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:23:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:23:43 --> Config Class Initialized
INFO - 2024-02-23 12:23:43 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:23:43 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:23:43 --> Utf8 Class Initialized
INFO - 2024-02-23 12:23:43 --> URI Class Initialized
INFO - 2024-02-23 12:23:43 --> Router Class Initialized
INFO - 2024-02-23 12:23:43 --> Output Class Initialized
INFO - 2024-02-23 12:23:43 --> Security Class Initialized
DEBUG - 2024-02-23 12:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:23:43 --> Input Class Initialized
INFO - 2024-02-23 12:23:43 --> Language Class Initialized
INFO - 2024-02-23 12:23:43 --> Loader Class Initialized
INFO - 2024-02-23 12:23:43 --> Helper loaded: url_helper
INFO - 2024-02-23 12:23:43 --> Helper loaded: file_helper
INFO - 2024-02-23 12:23:43 --> Helper loaded: form_helper
INFO - 2024-02-23 12:23:43 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:23:43 --> Controller Class Initialized
INFO - 2024-02-23 12:23:43 --> Form Validation Class Initialized
INFO - 2024-02-23 12:23:43 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:23:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:23:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:23:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:23:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:23:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:23:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:23:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:23:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:23:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:23:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:23:43 --> Final output sent to browser
DEBUG - 2024-02-23 12:23:43 --> Total execution time: 0.0321
ERROR - 2024-02-23 12:23:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:23:44 --> Config Class Initialized
INFO - 2024-02-23 12:23:44 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:23:44 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:23:44 --> Utf8 Class Initialized
INFO - 2024-02-23 12:23:44 --> URI Class Initialized
INFO - 2024-02-23 12:23:44 --> Router Class Initialized
INFO - 2024-02-23 12:23:44 --> Output Class Initialized
INFO - 2024-02-23 12:23:44 --> Security Class Initialized
DEBUG - 2024-02-23 12:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:23:44 --> Input Class Initialized
INFO - 2024-02-23 12:23:44 --> Language Class Initialized
INFO - 2024-02-23 12:23:44 --> Loader Class Initialized
INFO - 2024-02-23 12:23:44 --> Helper loaded: url_helper
INFO - 2024-02-23 12:23:44 --> Helper loaded: file_helper
INFO - 2024-02-23 12:23:44 --> Helper loaded: form_helper
INFO - 2024-02-23 12:23:44 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:23:44 --> Controller Class Initialized
INFO - 2024-02-23 12:23:44 --> Form Validation Class Initialized
INFO - 2024-02-23 12:23:44 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:23:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:23:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:23:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:23:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 12:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:25:24 --> Config Class Initialized
INFO - 2024-02-23 12:25:24 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:25:24 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:25:24 --> Utf8 Class Initialized
INFO - 2024-02-23 12:25:24 --> URI Class Initialized
INFO - 2024-02-23 12:25:24 --> Router Class Initialized
INFO - 2024-02-23 12:25:24 --> Output Class Initialized
INFO - 2024-02-23 12:25:24 --> Security Class Initialized
DEBUG - 2024-02-23 12:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:25:24 --> Input Class Initialized
INFO - 2024-02-23 12:25:24 --> Language Class Initialized
INFO - 2024-02-23 12:25:24 --> Loader Class Initialized
INFO - 2024-02-23 12:25:24 --> Helper loaded: url_helper
INFO - 2024-02-23 12:25:24 --> Helper loaded: file_helper
INFO - 2024-02-23 12:25:24 --> Helper loaded: form_helper
INFO - 2024-02-23 12:25:24 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:25:24 --> Controller Class Initialized
INFO - 2024-02-23 12:25:24 --> Form Validation Class Initialized
INFO - 2024-02-23 12:25:24 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:25:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:25:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:25:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:25:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 12:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 12:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 12:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 12:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 12:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 12:25:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 12:25:24 --> Final output sent to browser
DEBUG - 2024-02-23 12:25:24 --> Total execution time: 0.0342
ERROR - 2024-02-23 12:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 12:25:24 --> Config Class Initialized
INFO - 2024-02-23 12:25:24 --> Hooks Class Initialized
DEBUG - 2024-02-23 12:25:24 --> UTF-8 Support Enabled
INFO - 2024-02-23 12:25:24 --> Utf8 Class Initialized
INFO - 2024-02-23 12:25:24 --> URI Class Initialized
INFO - 2024-02-23 12:25:24 --> Router Class Initialized
INFO - 2024-02-23 12:25:24 --> Output Class Initialized
INFO - 2024-02-23 12:25:24 --> Security Class Initialized
DEBUG - 2024-02-23 12:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 12:25:24 --> Input Class Initialized
INFO - 2024-02-23 12:25:24 --> Language Class Initialized
INFO - 2024-02-23 12:25:24 --> Loader Class Initialized
INFO - 2024-02-23 12:25:24 --> Helper loaded: url_helper
INFO - 2024-02-23 12:25:24 --> Helper loaded: file_helper
INFO - 2024-02-23 12:25:24 --> Helper loaded: form_helper
INFO - 2024-02-23 12:25:24 --> Database Driver Class Initialized
DEBUG - 2024-02-23 12:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 12:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 12:25:24 --> Controller Class Initialized
INFO - 2024-02-23 12:25:24 --> Form Validation Class Initialized
INFO - 2024-02-23 12:25:24 --> Model "MasterModel" initialized
INFO - 2024-02-23 12:25:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 12:25:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 12:25:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 12:25:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:11:52 --> Config Class Initialized
INFO - 2024-02-23 13:11:52 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:11:52 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:11:52 --> Utf8 Class Initialized
INFO - 2024-02-23 13:11:52 --> URI Class Initialized
INFO - 2024-02-23 13:11:52 --> Router Class Initialized
INFO - 2024-02-23 13:11:52 --> Output Class Initialized
INFO - 2024-02-23 13:11:52 --> Security Class Initialized
DEBUG - 2024-02-23 13:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:11:52 --> Input Class Initialized
INFO - 2024-02-23 13:11:52 --> Language Class Initialized
INFO - 2024-02-23 13:11:52 --> Loader Class Initialized
INFO - 2024-02-23 13:11:52 --> Helper loaded: url_helper
INFO - 2024-02-23 13:11:52 --> Helper loaded: file_helper
INFO - 2024-02-23 13:11:52 --> Helper loaded: form_helper
INFO - 2024-02-23 13:11:52 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:11:52 --> Controller Class Initialized
INFO - 2024-02-23 13:11:52 --> Form Validation Class Initialized
INFO - 2024-02-23 13:11:52 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:11:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:11:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:11:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:11:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:11:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:11:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:11:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:11:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:11:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:11:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:11:52 --> Final output sent to browser
DEBUG - 2024-02-23 13:11:52 --> Total execution time: 0.0396
ERROR - 2024-02-23 13:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:11:52 --> Config Class Initialized
INFO - 2024-02-23 13:11:52 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:11:52 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:11:52 --> Utf8 Class Initialized
INFO - 2024-02-23 13:11:52 --> URI Class Initialized
INFO - 2024-02-23 13:11:52 --> Router Class Initialized
INFO - 2024-02-23 13:11:52 --> Output Class Initialized
INFO - 2024-02-23 13:11:52 --> Security Class Initialized
DEBUG - 2024-02-23 13:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:11:52 --> Input Class Initialized
INFO - 2024-02-23 13:11:52 --> Language Class Initialized
INFO - 2024-02-23 13:11:52 --> Loader Class Initialized
INFO - 2024-02-23 13:11:52 --> Helper loaded: url_helper
INFO - 2024-02-23 13:11:52 --> Helper loaded: file_helper
INFO - 2024-02-23 13:11:52 --> Helper loaded: form_helper
INFO - 2024-02-23 13:11:53 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:11:53 --> Controller Class Initialized
INFO - 2024-02-23 13:11:53 --> Form Validation Class Initialized
INFO - 2024-02-23 13:11:53 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:11:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:11:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:11:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:11:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:12:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:12:08 --> Config Class Initialized
INFO - 2024-02-23 13:12:08 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:12:08 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:12:08 --> Utf8 Class Initialized
INFO - 2024-02-23 13:12:08 --> URI Class Initialized
INFO - 2024-02-23 13:12:08 --> Router Class Initialized
INFO - 2024-02-23 13:12:08 --> Output Class Initialized
INFO - 2024-02-23 13:12:08 --> Security Class Initialized
DEBUG - 2024-02-23 13:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:12:08 --> Input Class Initialized
INFO - 2024-02-23 13:12:08 --> Language Class Initialized
INFO - 2024-02-23 13:12:08 --> Loader Class Initialized
INFO - 2024-02-23 13:12:08 --> Helper loaded: url_helper
INFO - 2024-02-23 13:12:08 --> Helper loaded: file_helper
INFO - 2024-02-23 13:12:08 --> Helper loaded: form_helper
INFO - 2024-02-23 13:12:08 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:12:08 --> Controller Class Initialized
INFO - 2024-02-23 13:12:08 --> Form Validation Class Initialized
INFO - 2024-02-23 13:12:08 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:12:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:12:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:12:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:12:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:12:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:12:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:12:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:12:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:12:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:12:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:12:08 --> Final output sent to browser
DEBUG - 2024-02-23 13:12:08 --> Total execution time: 0.0329
ERROR - 2024-02-23 13:12:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:12:08 --> Config Class Initialized
INFO - 2024-02-23 13:12:08 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:12:08 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:12:08 --> Utf8 Class Initialized
INFO - 2024-02-23 13:12:08 --> URI Class Initialized
INFO - 2024-02-23 13:12:08 --> Router Class Initialized
INFO - 2024-02-23 13:12:08 --> Output Class Initialized
INFO - 2024-02-23 13:12:08 --> Security Class Initialized
DEBUG - 2024-02-23 13:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:12:08 --> Input Class Initialized
INFO - 2024-02-23 13:12:08 --> Language Class Initialized
INFO - 2024-02-23 13:12:08 --> Loader Class Initialized
INFO - 2024-02-23 13:12:08 --> Helper loaded: url_helper
INFO - 2024-02-23 13:12:08 --> Helper loaded: file_helper
INFO - 2024-02-23 13:12:08 --> Helper loaded: form_helper
INFO - 2024-02-23 13:12:08 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:12:08 --> Controller Class Initialized
INFO - 2024-02-23 13:12:08 --> Form Validation Class Initialized
INFO - 2024-02-23 13:12:08 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:12:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:12:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:12:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:12:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:12:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:12:12 --> Config Class Initialized
INFO - 2024-02-23 13:12:12 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:12:12 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:12:12 --> Utf8 Class Initialized
INFO - 2024-02-23 13:12:12 --> URI Class Initialized
INFO - 2024-02-23 13:12:12 --> Router Class Initialized
INFO - 2024-02-23 13:12:12 --> Output Class Initialized
INFO - 2024-02-23 13:12:12 --> Security Class Initialized
DEBUG - 2024-02-23 13:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:12:12 --> Input Class Initialized
INFO - 2024-02-23 13:12:12 --> Language Class Initialized
INFO - 2024-02-23 13:12:12 --> Loader Class Initialized
INFO - 2024-02-23 13:12:12 --> Helper loaded: url_helper
INFO - 2024-02-23 13:12:12 --> Helper loaded: file_helper
INFO - 2024-02-23 13:12:12 --> Helper loaded: form_helper
INFO - 2024-02-23 13:12:12 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:12:12 --> Controller Class Initialized
INFO - 2024-02-23 13:12:12 --> Form Validation Class Initialized
INFO - 2024-02-23 13:12:12 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:12:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:12:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:12:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:12:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:12:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:12:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:12:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:12:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:12:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:12:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:12:12 --> Final output sent to browser
DEBUG - 2024-02-23 13:12:12 --> Total execution time: 0.0387
ERROR - 2024-02-23 13:12:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:12:13 --> Config Class Initialized
INFO - 2024-02-23 13:12:13 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:12:13 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:12:13 --> Utf8 Class Initialized
INFO - 2024-02-23 13:12:13 --> URI Class Initialized
INFO - 2024-02-23 13:12:13 --> Router Class Initialized
INFO - 2024-02-23 13:12:13 --> Output Class Initialized
INFO - 2024-02-23 13:12:13 --> Security Class Initialized
DEBUG - 2024-02-23 13:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:12:13 --> Input Class Initialized
INFO - 2024-02-23 13:12:13 --> Language Class Initialized
INFO - 2024-02-23 13:12:13 --> Loader Class Initialized
INFO - 2024-02-23 13:12:13 --> Helper loaded: url_helper
INFO - 2024-02-23 13:12:13 --> Helper loaded: file_helper
INFO - 2024-02-23 13:12:13 --> Helper loaded: form_helper
INFO - 2024-02-23 13:12:13 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:12:13 --> Controller Class Initialized
INFO - 2024-02-23 13:12:13 --> Form Validation Class Initialized
INFO - 2024-02-23 13:12:13 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:12:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:12:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:12:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:12:13 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:12:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:12:39 --> Config Class Initialized
INFO - 2024-02-23 13:12:39 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:12:39 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:12:39 --> Utf8 Class Initialized
INFO - 2024-02-23 13:12:39 --> URI Class Initialized
INFO - 2024-02-23 13:12:39 --> Router Class Initialized
INFO - 2024-02-23 13:12:39 --> Output Class Initialized
INFO - 2024-02-23 13:12:39 --> Security Class Initialized
DEBUG - 2024-02-23 13:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:12:39 --> Input Class Initialized
INFO - 2024-02-23 13:12:39 --> Language Class Initialized
INFO - 2024-02-23 13:12:39 --> Loader Class Initialized
INFO - 2024-02-23 13:12:39 --> Helper loaded: url_helper
INFO - 2024-02-23 13:12:39 --> Helper loaded: file_helper
INFO - 2024-02-23 13:12:39 --> Helper loaded: form_helper
INFO - 2024-02-23 13:12:39 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:12:39 --> Controller Class Initialized
INFO - 2024-02-23 13:12:39 --> Form Validation Class Initialized
INFO - 2024-02-23 13:12:39 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:12:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:12:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:12:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:12:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:12:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:12:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:12:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:12:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:12:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:12:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:12:39 --> Final output sent to browser
DEBUG - 2024-02-23 13:12:39 --> Total execution time: 0.0280
ERROR - 2024-02-23 13:12:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:12:40 --> Config Class Initialized
INFO - 2024-02-23 13:12:40 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:12:40 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:12:40 --> Utf8 Class Initialized
INFO - 2024-02-23 13:12:40 --> URI Class Initialized
INFO - 2024-02-23 13:12:40 --> Router Class Initialized
INFO - 2024-02-23 13:12:40 --> Output Class Initialized
INFO - 2024-02-23 13:12:40 --> Security Class Initialized
DEBUG - 2024-02-23 13:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:12:40 --> Input Class Initialized
INFO - 2024-02-23 13:12:40 --> Language Class Initialized
INFO - 2024-02-23 13:12:40 --> Loader Class Initialized
INFO - 2024-02-23 13:12:40 --> Helper loaded: url_helper
INFO - 2024-02-23 13:12:40 --> Helper loaded: file_helper
INFO - 2024-02-23 13:12:40 --> Helper loaded: form_helper
INFO - 2024-02-23 13:12:40 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:12:40 --> Controller Class Initialized
INFO - 2024-02-23 13:12:40 --> Form Validation Class Initialized
INFO - 2024-02-23 13:12:40 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:12:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:12:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:12:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:12:40 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:12:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:12:48 --> Config Class Initialized
INFO - 2024-02-23 13:12:48 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:12:48 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:12:48 --> Utf8 Class Initialized
INFO - 2024-02-23 13:12:48 --> URI Class Initialized
INFO - 2024-02-23 13:12:48 --> Router Class Initialized
INFO - 2024-02-23 13:12:48 --> Output Class Initialized
INFO - 2024-02-23 13:12:48 --> Security Class Initialized
DEBUG - 2024-02-23 13:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:12:48 --> Input Class Initialized
INFO - 2024-02-23 13:12:48 --> Language Class Initialized
INFO - 2024-02-23 13:12:48 --> Loader Class Initialized
INFO - 2024-02-23 13:12:48 --> Helper loaded: url_helper
INFO - 2024-02-23 13:12:48 --> Helper loaded: file_helper
INFO - 2024-02-23 13:12:48 --> Helper loaded: form_helper
INFO - 2024-02-23 13:12:48 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:12:48 --> Controller Class Initialized
INFO - 2024-02-23 13:12:48 --> Form Validation Class Initialized
INFO - 2024-02-23 13:12:48 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:12:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:12:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:12:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:12:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:12:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:12:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:12:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:12:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:12:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:12:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:12:48 --> Final output sent to browser
DEBUG - 2024-02-23 13:12:48 --> Total execution time: 0.0282
ERROR - 2024-02-23 13:12:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:12:48 --> Config Class Initialized
INFO - 2024-02-23 13:12:48 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:12:48 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:12:48 --> Utf8 Class Initialized
INFO - 2024-02-23 13:12:48 --> URI Class Initialized
INFO - 2024-02-23 13:12:48 --> Router Class Initialized
INFO - 2024-02-23 13:12:48 --> Output Class Initialized
INFO - 2024-02-23 13:12:48 --> Security Class Initialized
DEBUG - 2024-02-23 13:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:12:48 --> Input Class Initialized
INFO - 2024-02-23 13:12:48 --> Language Class Initialized
INFO - 2024-02-23 13:12:48 --> Loader Class Initialized
INFO - 2024-02-23 13:12:48 --> Helper loaded: url_helper
INFO - 2024-02-23 13:12:48 --> Helper loaded: file_helper
INFO - 2024-02-23 13:12:48 --> Helper loaded: form_helper
INFO - 2024-02-23 13:12:48 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:12:48 --> Controller Class Initialized
INFO - 2024-02-23 13:12:48 --> Form Validation Class Initialized
INFO - 2024-02-23 13:12:48 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:12:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:12:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:12:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:12:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:13:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:13:54 --> Config Class Initialized
INFO - 2024-02-23 13:13:54 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:13:54 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:13:54 --> Utf8 Class Initialized
INFO - 2024-02-23 13:13:54 --> URI Class Initialized
INFO - 2024-02-23 13:13:54 --> Router Class Initialized
INFO - 2024-02-23 13:13:54 --> Output Class Initialized
INFO - 2024-02-23 13:13:54 --> Security Class Initialized
DEBUG - 2024-02-23 13:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:13:54 --> Input Class Initialized
INFO - 2024-02-23 13:13:54 --> Language Class Initialized
INFO - 2024-02-23 13:13:54 --> Loader Class Initialized
INFO - 2024-02-23 13:13:54 --> Helper loaded: url_helper
INFO - 2024-02-23 13:13:54 --> Helper loaded: file_helper
INFO - 2024-02-23 13:13:54 --> Helper loaded: form_helper
INFO - 2024-02-23 13:13:54 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:13:54 --> Controller Class Initialized
INFO - 2024-02-23 13:13:54 --> Form Validation Class Initialized
INFO - 2024-02-23 13:13:54 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:13:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:13:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:13:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:13:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:13:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:13:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:13:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:13:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:13:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:13:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:13:54 --> Final output sent to browser
DEBUG - 2024-02-23 13:13:54 --> Total execution time: 0.0363
ERROR - 2024-02-23 13:13:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:13:54 --> Config Class Initialized
INFO - 2024-02-23 13:13:54 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:13:54 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:13:54 --> Utf8 Class Initialized
INFO - 2024-02-23 13:13:54 --> URI Class Initialized
INFO - 2024-02-23 13:13:54 --> Router Class Initialized
INFO - 2024-02-23 13:13:54 --> Output Class Initialized
INFO - 2024-02-23 13:13:54 --> Security Class Initialized
DEBUG - 2024-02-23 13:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:13:54 --> Input Class Initialized
INFO - 2024-02-23 13:13:54 --> Language Class Initialized
INFO - 2024-02-23 13:13:54 --> Loader Class Initialized
INFO - 2024-02-23 13:13:54 --> Helper loaded: url_helper
INFO - 2024-02-23 13:13:54 --> Helper loaded: file_helper
INFO - 2024-02-23 13:13:54 --> Helper loaded: form_helper
INFO - 2024-02-23 13:13:54 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:13:54 --> Controller Class Initialized
INFO - 2024-02-23 13:13:54 --> Form Validation Class Initialized
INFO - 2024-02-23 13:13:54 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:13:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:13:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:13:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:13:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:14:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:14:00 --> Config Class Initialized
INFO - 2024-02-23 13:14:00 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:14:00 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:14:00 --> Utf8 Class Initialized
INFO - 2024-02-23 13:14:00 --> URI Class Initialized
INFO - 2024-02-23 13:14:00 --> Router Class Initialized
INFO - 2024-02-23 13:14:00 --> Output Class Initialized
INFO - 2024-02-23 13:14:00 --> Security Class Initialized
DEBUG - 2024-02-23 13:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:14:00 --> Input Class Initialized
INFO - 2024-02-23 13:14:00 --> Language Class Initialized
INFO - 2024-02-23 13:14:00 --> Loader Class Initialized
INFO - 2024-02-23 13:14:00 --> Helper loaded: url_helper
INFO - 2024-02-23 13:14:00 --> Helper loaded: file_helper
INFO - 2024-02-23 13:14:00 --> Helper loaded: form_helper
INFO - 2024-02-23 13:14:00 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:14:00 --> Controller Class Initialized
INFO - 2024-02-23 13:14:00 --> Form Validation Class Initialized
INFO - 2024-02-23 13:14:00 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:14:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:14:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:14:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:14:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:14:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:14:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:14:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:14:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:14:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:14:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:14:00 --> Final output sent to browser
DEBUG - 2024-02-23 13:14:00 --> Total execution time: 0.0432
ERROR - 2024-02-23 13:14:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:14:00 --> Config Class Initialized
INFO - 2024-02-23 13:14:00 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:14:00 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:14:00 --> Utf8 Class Initialized
INFO - 2024-02-23 13:14:00 --> URI Class Initialized
INFO - 2024-02-23 13:14:00 --> Router Class Initialized
INFO - 2024-02-23 13:14:00 --> Output Class Initialized
INFO - 2024-02-23 13:14:00 --> Security Class Initialized
DEBUG - 2024-02-23 13:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:14:00 --> Input Class Initialized
INFO - 2024-02-23 13:14:00 --> Language Class Initialized
INFO - 2024-02-23 13:14:00 --> Loader Class Initialized
INFO - 2024-02-23 13:14:00 --> Helper loaded: url_helper
INFO - 2024-02-23 13:14:00 --> Helper loaded: file_helper
INFO - 2024-02-23 13:14:00 --> Helper loaded: form_helper
INFO - 2024-02-23 13:14:00 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:14:00 --> Controller Class Initialized
INFO - 2024-02-23 13:14:00 --> Form Validation Class Initialized
INFO - 2024-02-23 13:14:00 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:14:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:14:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:14:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:14:00 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:14:09 --> Config Class Initialized
INFO - 2024-02-23 13:14:09 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:14:09 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:14:09 --> Utf8 Class Initialized
INFO - 2024-02-23 13:14:09 --> URI Class Initialized
INFO - 2024-02-23 13:14:09 --> Router Class Initialized
INFO - 2024-02-23 13:14:09 --> Output Class Initialized
INFO - 2024-02-23 13:14:09 --> Security Class Initialized
DEBUG - 2024-02-23 13:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:14:09 --> Input Class Initialized
INFO - 2024-02-23 13:14:09 --> Language Class Initialized
INFO - 2024-02-23 13:14:09 --> Loader Class Initialized
INFO - 2024-02-23 13:14:09 --> Helper loaded: url_helper
INFO - 2024-02-23 13:14:09 --> Helper loaded: file_helper
INFO - 2024-02-23 13:14:09 --> Helper loaded: form_helper
INFO - 2024-02-23 13:14:09 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:14:09 --> Controller Class Initialized
INFO - 2024-02-23 13:14:09 --> Form Validation Class Initialized
INFO - 2024-02-23 13:14:09 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:14:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:14:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:14:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:14:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:14:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:14:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:14:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:14:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:14:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:14:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:14:09 --> Final output sent to browser
DEBUG - 2024-02-23 13:14:09 --> Total execution time: 0.0313
ERROR - 2024-02-23 13:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:14:09 --> Config Class Initialized
INFO - 2024-02-23 13:14:09 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:14:09 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:14:09 --> Utf8 Class Initialized
INFO - 2024-02-23 13:14:09 --> URI Class Initialized
INFO - 2024-02-23 13:14:09 --> Router Class Initialized
INFO - 2024-02-23 13:14:09 --> Output Class Initialized
INFO - 2024-02-23 13:14:09 --> Security Class Initialized
DEBUG - 2024-02-23 13:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:14:09 --> Input Class Initialized
INFO - 2024-02-23 13:14:09 --> Language Class Initialized
INFO - 2024-02-23 13:14:09 --> Loader Class Initialized
INFO - 2024-02-23 13:14:09 --> Helper loaded: url_helper
INFO - 2024-02-23 13:14:09 --> Helper loaded: file_helper
INFO - 2024-02-23 13:14:09 --> Helper loaded: form_helper
INFO - 2024-02-23 13:14:09 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:14:09 --> Controller Class Initialized
INFO - 2024-02-23 13:14:09 --> Form Validation Class Initialized
INFO - 2024-02-23 13:14:09 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:14:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:14:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:14:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:14:09 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:15:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:15:07 --> Config Class Initialized
INFO - 2024-02-23 13:15:07 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:15:07 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:15:07 --> Utf8 Class Initialized
INFO - 2024-02-23 13:15:07 --> URI Class Initialized
INFO - 2024-02-23 13:15:07 --> Router Class Initialized
INFO - 2024-02-23 13:15:07 --> Output Class Initialized
INFO - 2024-02-23 13:15:07 --> Security Class Initialized
DEBUG - 2024-02-23 13:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:15:07 --> Input Class Initialized
INFO - 2024-02-23 13:15:07 --> Language Class Initialized
INFO - 2024-02-23 13:15:07 --> Loader Class Initialized
INFO - 2024-02-23 13:15:07 --> Helper loaded: url_helper
INFO - 2024-02-23 13:15:07 --> Helper loaded: file_helper
INFO - 2024-02-23 13:15:07 --> Helper loaded: form_helper
INFO - 2024-02-23 13:15:07 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:15:07 --> Controller Class Initialized
INFO - 2024-02-23 13:15:07 --> Form Validation Class Initialized
INFO - 2024-02-23 13:15:07 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:15:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:15:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:15:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:15:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:15:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:15:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:15:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:15:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:15:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:15:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:15:07 --> Final output sent to browser
DEBUG - 2024-02-23 13:15:07 --> Total execution time: 0.0376
ERROR - 2024-02-23 13:15:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:15:08 --> Config Class Initialized
INFO - 2024-02-23 13:15:08 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:15:08 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:15:08 --> Utf8 Class Initialized
INFO - 2024-02-23 13:15:08 --> URI Class Initialized
INFO - 2024-02-23 13:15:08 --> Router Class Initialized
INFO - 2024-02-23 13:15:08 --> Output Class Initialized
INFO - 2024-02-23 13:15:08 --> Security Class Initialized
DEBUG - 2024-02-23 13:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:15:08 --> Input Class Initialized
INFO - 2024-02-23 13:15:08 --> Language Class Initialized
INFO - 2024-02-23 13:15:08 --> Loader Class Initialized
INFO - 2024-02-23 13:15:08 --> Helper loaded: url_helper
INFO - 2024-02-23 13:15:08 --> Helper loaded: file_helper
INFO - 2024-02-23 13:15:08 --> Helper loaded: form_helper
INFO - 2024-02-23 13:15:08 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:15:08 --> Controller Class Initialized
INFO - 2024-02-23 13:15:08 --> Form Validation Class Initialized
INFO - 2024-02-23 13:15:08 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:15:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:15:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:15:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:15:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:17:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:17:05 --> Config Class Initialized
INFO - 2024-02-23 13:17:05 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:17:05 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:17:05 --> Utf8 Class Initialized
INFO - 2024-02-23 13:17:05 --> URI Class Initialized
INFO - 2024-02-23 13:17:05 --> Router Class Initialized
INFO - 2024-02-23 13:17:05 --> Output Class Initialized
INFO - 2024-02-23 13:17:05 --> Security Class Initialized
DEBUG - 2024-02-23 13:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:17:05 --> Input Class Initialized
INFO - 2024-02-23 13:17:05 --> Language Class Initialized
INFO - 2024-02-23 13:17:05 --> Loader Class Initialized
INFO - 2024-02-23 13:17:05 --> Helper loaded: url_helper
INFO - 2024-02-23 13:17:05 --> Helper loaded: file_helper
INFO - 2024-02-23 13:17:05 --> Helper loaded: form_helper
INFO - 2024-02-23 13:17:05 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:17:05 --> Controller Class Initialized
INFO - 2024-02-23 13:17:05 --> Form Validation Class Initialized
INFO - 2024-02-23 13:17:05 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:17:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:17:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:17:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:17:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:17:05 --> Final output sent to browser
DEBUG - 2024-02-23 13:17:05 --> Total execution time: 0.0415
ERROR - 2024-02-23 13:17:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:17:06 --> Config Class Initialized
INFO - 2024-02-23 13:17:06 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:17:06 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:17:06 --> Utf8 Class Initialized
INFO - 2024-02-23 13:17:06 --> URI Class Initialized
INFO - 2024-02-23 13:17:06 --> Router Class Initialized
INFO - 2024-02-23 13:17:06 --> Output Class Initialized
INFO - 2024-02-23 13:17:06 --> Security Class Initialized
DEBUG - 2024-02-23 13:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:17:06 --> Input Class Initialized
INFO - 2024-02-23 13:17:06 --> Language Class Initialized
INFO - 2024-02-23 13:17:06 --> Loader Class Initialized
INFO - 2024-02-23 13:17:06 --> Helper loaded: url_helper
INFO - 2024-02-23 13:17:06 --> Helper loaded: file_helper
INFO - 2024-02-23 13:17:06 --> Helper loaded: form_helper
INFO - 2024-02-23 13:17:06 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:17:06 --> Controller Class Initialized
INFO - 2024-02-23 13:17:06 --> Form Validation Class Initialized
INFO - 2024-02-23 13:17:06 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:17:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:17:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:17:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:17:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:17:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:17:14 --> Config Class Initialized
INFO - 2024-02-23 13:17:14 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:17:14 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:17:14 --> Utf8 Class Initialized
INFO - 2024-02-23 13:17:14 --> URI Class Initialized
INFO - 2024-02-23 13:17:14 --> Router Class Initialized
INFO - 2024-02-23 13:17:14 --> Output Class Initialized
INFO - 2024-02-23 13:17:14 --> Security Class Initialized
DEBUG - 2024-02-23 13:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:17:14 --> Input Class Initialized
INFO - 2024-02-23 13:17:14 --> Language Class Initialized
INFO - 2024-02-23 13:17:14 --> Loader Class Initialized
INFO - 2024-02-23 13:17:14 --> Helper loaded: url_helper
INFO - 2024-02-23 13:17:14 --> Helper loaded: file_helper
INFO - 2024-02-23 13:17:14 --> Helper loaded: form_helper
INFO - 2024-02-23 13:17:14 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:17:14 --> Controller Class Initialized
INFO - 2024-02-23 13:17:14 --> Form Validation Class Initialized
INFO - 2024-02-23 13:17:14 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:17:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:17:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:17:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:17:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:17:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:17:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:17:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:17:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:17:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:17:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:17:14 --> Final output sent to browser
DEBUG - 2024-02-23 13:17:14 --> Total execution time: 0.0351
ERROR - 2024-02-23 13:17:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:17:14 --> Config Class Initialized
INFO - 2024-02-23 13:17:14 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:17:14 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:17:14 --> Utf8 Class Initialized
INFO - 2024-02-23 13:17:14 --> URI Class Initialized
INFO - 2024-02-23 13:17:14 --> Router Class Initialized
INFO - 2024-02-23 13:17:14 --> Output Class Initialized
INFO - 2024-02-23 13:17:14 --> Security Class Initialized
DEBUG - 2024-02-23 13:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:17:14 --> Input Class Initialized
INFO - 2024-02-23 13:17:14 --> Language Class Initialized
INFO - 2024-02-23 13:17:14 --> Loader Class Initialized
INFO - 2024-02-23 13:17:14 --> Helper loaded: url_helper
INFO - 2024-02-23 13:17:14 --> Helper loaded: file_helper
INFO - 2024-02-23 13:17:14 --> Helper loaded: form_helper
INFO - 2024-02-23 13:17:14 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:17:14 --> Controller Class Initialized
INFO - 2024-02-23 13:17:14 --> Form Validation Class Initialized
INFO - 2024-02-23 13:17:14 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:17:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:17:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:17:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:17:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:17:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:17:21 --> Config Class Initialized
INFO - 2024-02-23 13:17:21 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:17:21 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:17:21 --> Utf8 Class Initialized
INFO - 2024-02-23 13:17:21 --> URI Class Initialized
INFO - 2024-02-23 13:17:21 --> Router Class Initialized
INFO - 2024-02-23 13:17:21 --> Output Class Initialized
INFO - 2024-02-23 13:17:21 --> Security Class Initialized
DEBUG - 2024-02-23 13:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:17:21 --> Input Class Initialized
INFO - 2024-02-23 13:17:21 --> Language Class Initialized
INFO - 2024-02-23 13:17:21 --> Loader Class Initialized
INFO - 2024-02-23 13:17:21 --> Helper loaded: url_helper
INFO - 2024-02-23 13:17:21 --> Helper loaded: file_helper
INFO - 2024-02-23 13:17:21 --> Helper loaded: form_helper
INFO - 2024-02-23 13:17:21 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:17:21 --> Controller Class Initialized
INFO - 2024-02-23 13:17:21 --> Form Validation Class Initialized
INFO - 2024-02-23 13:17:21 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:17:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:17:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:17:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:17:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:17:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:17:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:17:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:17:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:17:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:17:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:17:21 --> Final output sent to browser
DEBUG - 2024-02-23 13:17:21 --> Total execution time: 0.0355
ERROR - 2024-02-23 13:17:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:17:22 --> Config Class Initialized
INFO - 2024-02-23 13:17:22 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:17:22 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:17:22 --> Utf8 Class Initialized
INFO - 2024-02-23 13:17:22 --> URI Class Initialized
INFO - 2024-02-23 13:17:22 --> Router Class Initialized
INFO - 2024-02-23 13:17:22 --> Output Class Initialized
INFO - 2024-02-23 13:17:22 --> Security Class Initialized
DEBUG - 2024-02-23 13:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:17:22 --> Input Class Initialized
INFO - 2024-02-23 13:17:22 --> Language Class Initialized
INFO - 2024-02-23 13:17:22 --> Loader Class Initialized
INFO - 2024-02-23 13:17:22 --> Helper loaded: url_helper
INFO - 2024-02-23 13:17:22 --> Helper loaded: file_helper
INFO - 2024-02-23 13:17:22 --> Helper loaded: form_helper
INFO - 2024-02-23 13:17:22 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:17:22 --> Controller Class Initialized
INFO - 2024-02-23 13:17:22 --> Form Validation Class Initialized
INFO - 2024-02-23 13:17:22 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:17:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:17:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:17:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:17:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:19:17 --> Config Class Initialized
INFO - 2024-02-23 13:19:17 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:19:17 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:19:17 --> Utf8 Class Initialized
INFO - 2024-02-23 13:19:17 --> URI Class Initialized
INFO - 2024-02-23 13:19:17 --> Router Class Initialized
INFO - 2024-02-23 13:19:17 --> Output Class Initialized
INFO - 2024-02-23 13:19:17 --> Security Class Initialized
DEBUG - 2024-02-23 13:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:19:17 --> Input Class Initialized
INFO - 2024-02-23 13:19:17 --> Language Class Initialized
INFO - 2024-02-23 13:19:17 --> Loader Class Initialized
INFO - 2024-02-23 13:19:17 --> Helper loaded: url_helper
INFO - 2024-02-23 13:19:17 --> Helper loaded: file_helper
INFO - 2024-02-23 13:19:17 --> Helper loaded: form_helper
INFO - 2024-02-23 13:19:17 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:19:17 --> Controller Class Initialized
INFO - 2024-02-23 13:19:17 --> Form Validation Class Initialized
INFO - 2024-02-23 13:19:17 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:19:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:19:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:19:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:19:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:19:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:19:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:19:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:19:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:19:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:19:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:19:17 --> Final output sent to browser
DEBUG - 2024-02-23 13:19:17 --> Total execution time: 0.0318
ERROR - 2024-02-23 13:19:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:19:18 --> Config Class Initialized
INFO - 2024-02-23 13:19:18 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:19:18 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:19:18 --> Utf8 Class Initialized
INFO - 2024-02-23 13:19:18 --> URI Class Initialized
INFO - 2024-02-23 13:19:18 --> Router Class Initialized
INFO - 2024-02-23 13:19:18 --> Output Class Initialized
INFO - 2024-02-23 13:19:18 --> Security Class Initialized
DEBUG - 2024-02-23 13:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:19:18 --> Input Class Initialized
INFO - 2024-02-23 13:19:18 --> Language Class Initialized
INFO - 2024-02-23 13:19:18 --> Loader Class Initialized
INFO - 2024-02-23 13:19:18 --> Helper loaded: url_helper
INFO - 2024-02-23 13:19:18 --> Helper loaded: file_helper
INFO - 2024-02-23 13:19:18 --> Helper loaded: form_helper
INFO - 2024-02-23 13:19:18 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:19:18 --> Controller Class Initialized
INFO - 2024-02-23 13:19:18 --> Form Validation Class Initialized
INFO - 2024-02-23 13:19:18 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:19:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:19:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:19:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:19:18 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:19:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:19:28 --> Config Class Initialized
INFO - 2024-02-23 13:19:28 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:19:28 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:19:28 --> Utf8 Class Initialized
INFO - 2024-02-23 13:19:28 --> URI Class Initialized
INFO - 2024-02-23 13:19:28 --> Router Class Initialized
INFO - 2024-02-23 13:19:28 --> Output Class Initialized
INFO - 2024-02-23 13:19:28 --> Security Class Initialized
DEBUG - 2024-02-23 13:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:19:28 --> Input Class Initialized
INFO - 2024-02-23 13:19:28 --> Language Class Initialized
INFO - 2024-02-23 13:19:28 --> Loader Class Initialized
INFO - 2024-02-23 13:19:28 --> Helper loaded: url_helper
INFO - 2024-02-23 13:19:28 --> Helper loaded: file_helper
INFO - 2024-02-23 13:19:28 --> Helper loaded: form_helper
INFO - 2024-02-23 13:19:28 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:19:28 --> Controller Class Initialized
INFO - 2024-02-23 13:19:28 --> Form Validation Class Initialized
INFO - 2024-02-23 13:19:28 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:19:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:19:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:19:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:19:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:19:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:19:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:19:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:19:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:19:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:19:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:19:28 --> Final output sent to browser
DEBUG - 2024-02-23 13:19:28 --> Total execution time: 0.0324
ERROR - 2024-02-23 13:19:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:19:28 --> Config Class Initialized
INFO - 2024-02-23 13:19:28 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:19:28 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:19:28 --> Utf8 Class Initialized
INFO - 2024-02-23 13:19:28 --> URI Class Initialized
INFO - 2024-02-23 13:19:28 --> Router Class Initialized
INFO - 2024-02-23 13:19:28 --> Output Class Initialized
INFO - 2024-02-23 13:19:28 --> Security Class Initialized
DEBUG - 2024-02-23 13:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:19:28 --> Input Class Initialized
INFO - 2024-02-23 13:19:28 --> Language Class Initialized
INFO - 2024-02-23 13:19:28 --> Loader Class Initialized
INFO - 2024-02-23 13:19:28 --> Helper loaded: url_helper
INFO - 2024-02-23 13:19:28 --> Helper loaded: file_helper
INFO - 2024-02-23 13:19:28 --> Helper loaded: form_helper
INFO - 2024-02-23 13:19:28 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:19:28 --> Controller Class Initialized
INFO - 2024-02-23 13:19:28 --> Form Validation Class Initialized
INFO - 2024-02-23 13:19:28 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:19:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:19:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:19:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:19:28 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:19:54 --> Config Class Initialized
INFO - 2024-02-23 13:19:54 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:19:54 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:19:54 --> Utf8 Class Initialized
INFO - 2024-02-23 13:19:54 --> URI Class Initialized
INFO - 2024-02-23 13:19:54 --> Router Class Initialized
INFO - 2024-02-23 13:19:54 --> Output Class Initialized
INFO - 2024-02-23 13:19:54 --> Security Class Initialized
DEBUG - 2024-02-23 13:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:19:54 --> Input Class Initialized
INFO - 2024-02-23 13:19:54 --> Language Class Initialized
INFO - 2024-02-23 13:19:54 --> Loader Class Initialized
INFO - 2024-02-23 13:19:54 --> Helper loaded: url_helper
INFO - 2024-02-23 13:19:54 --> Helper loaded: file_helper
INFO - 2024-02-23 13:19:54 --> Helper loaded: form_helper
INFO - 2024-02-23 13:19:54 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:19:54 --> Controller Class Initialized
INFO - 2024-02-23 13:19:54 --> Form Validation Class Initialized
INFO - 2024-02-23 13:19:54 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:19:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:19:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:19:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:19:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:19:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:19:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:19:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:19:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:19:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:19:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:19:54 --> Final output sent to browser
DEBUG - 2024-02-23 13:19:54 --> Total execution time: 0.0334
ERROR - 2024-02-23 13:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:19:54 --> Config Class Initialized
INFO - 2024-02-23 13:19:54 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:19:54 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:19:54 --> Utf8 Class Initialized
INFO - 2024-02-23 13:19:54 --> URI Class Initialized
INFO - 2024-02-23 13:19:54 --> Router Class Initialized
INFO - 2024-02-23 13:19:54 --> Output Class Initialized
INFO - 2024-02-23 13:19:54 --> Security Class Initialized
DEBUG - 2024-02-23 13:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:19:54 --> Input Class Initialized
INFO - 2024-02-23 13:19:54 --> Language Class Initialized
INFO - 2024-02-23 13:19:54 --> Loader Class Initialized
INFO - 2024-02-23 13:19:54 --> Helper loaded: url_helper
INFO - 2024-02-23 13:19:54 --> Helper loaded: file_helper
INFO - 2024-02-23 13:19:54 --> Helper loaded: form_helper
INFO - 2024-02-23 13:19:54 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:19:54 --> Controller Class Initialized
INFO - 2024-02-23 13:19:54 --> Form Validation Class Initialized
INFO - 2024-02-23 13:19:54 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:19:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:19:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:19:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:19:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:20:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:20:19 --> Config Class Initialized
INFO - 2024-02-23 13:20:19 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:20:19 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:20:19 --> Utf8 Class Initialized
INFO - 2024-02-23 13:20:19 --> URI Class Initialized
INFO - 2024-02-23 13:20:19 --> Router Class Initialized
INFO - 2024-02-23 13:20:19 --> Output Class Initialized
INFO - 2024-02-23 13:20:19 --> Security Class Initialized
DEBUG - 2024-02-23 13:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:20:19 --> Input Class Initialized
INFO - 2024-02-23 13:20:19 --> Language Class Initialized
INFO - 2024-02-23 13:20:19 --> Loader Class Initialized
INFO - 2024-02-23 13:20:19 --> Helper loaded: url_helper
INFO - 2024-02-23 13:20:19 --> Helper loaded: file_helper
INFO - 2024-02-23 13:20:19 --> Helper loaded: form_helper
INFO - 2024-02-23 13:20:19 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:20:19 --> Controller Class Initialized
INFO - 2024-02-23 13:20:19 --> Form Validation Class Initialized
INFO - 2024-02-23 13:20:19 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:20:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:20:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:20:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:20:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:20:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:20:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:20:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:20:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:20:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:20:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:20:19 --> Final output sent to browser
DEBUG - 2024-02-23 13:20:19 --> Total execution time: 0.0341
ERROR - 2024-02-23 13:20:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:20:19 --> Config Class Initialized
INFO - 2024-02-23 13:20:19 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:20:19 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:20:19 --> Utf8 Class Initialized
INFO - 2024-02-23 13:20:19 --> URI Class Initialized
INFO - 2024-02-23 13:20:19 --> Router Class Initialized
INFO - 2024-02-23 13:20:19 --> Output Class Initialized
INFO - 2024-02-23 13:20:19 --> Security Class Initialized
DEBUG - 2024-02-23 13:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:20:19 --> Input Class Initialized
INFO - 2024-02-23 13:20:19 --> Language Class Initialized
INFO - 2024-02-23 13:20:19 --> Loader Class Initialized
INFO - 2024-02-23 13:20:19 --> Helper loaded: url_helper
INFO - 2024-02-23 13:20:19 --> Helper loaded: file_helper
INFO - 2024-02-23 13:20:19 --> Helper loaded: form_helper
INFO - 2024-02-23 13:20:19 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:20:19 --> Controller Class Initialized
INFO - 2024-02-23 13:20:19 --> Form Validation Class Initialized
INFO - 2024-02-23 13:20:19 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:20:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:20:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:20:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:20:19 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:20:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:20:32 --> Config Class Initialized
INFO - 2024-02-23 13:20:32 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:20:32 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:20:32 --> Utf8 Class Initialized
INFO - 2024-02-23 13:20:32 --> URI Class Initialized
INFO - 2024-02-23 13:20:32 --> Router Class Initialized
INFO - 2024-02-23 13:20:32 --> Output Class Initialized
INFO - 2024-02-23 13:20:32 --> Security Class Initialized
DEBUG - 2024-02-23 13:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:20:32 --> Input Class Initialized
INFO - 2024-02-23 13:20:32 --> Language Class Initialized
INFO - 2024-02-23 13:20:32 --> Loader Class Initialized
INFO - 2024-02-23 13:20:32 --> Helper loaded: url_helper
INFO - 2024-02-23 13:20:32 --> Helper loaded: file_helper
INFO - 2024-02-23 13:20:32 --> Helper loaded: form_helper
INFO - 2024-02-23 13:20:32 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:20:32 --> Controller Class Initialized
INFO - 2024-02-23 13:20:32 --> Form Validation Class Initialized
INFO - 2024-02-23 13:20:32 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:20:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:20:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:20:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:20:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:20:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:20:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:20:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:20:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:20:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:20:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:20:32 --> Final output sent to browser
DEBUG - 2024-02-23 13:20:32 --> Total execution time: 0.0304
ERROR - 2024-02-23 13:20:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:20:32 --> Config Class Initialized
INFO - 2024-02-23 13:20:32 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:20:32 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:20:32 --> Utf8 Class Initialized
INFO - 2024-02-23 13:20:32 --> URI Class Initialized
INFO - 2024-02-23 13:20:32 --> Router Class Initialized
INFO - 2024-02-23 13:20:32 --> Output Class Initialized
INFO - 2024-02-23 13:20:32 --> Security Class Initialized
DEBUG - 2024-02-23 13:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:20:32 --> Input Class Initialized
INFO - 2024-02-23 13:20:32 --> Language Class Initialized
INFO - 2024-02-23 13:20:32 --> Loader Class Initialized
INFO - 2024-02-23 13:20:32 --> Helper loaded: url_helper
INFO - 2024-02-23 13:20:32 --> Helper loaded: file_helper
INFO - 2024-02-23 13:20:32 --> Helper loaded: form_helper
INFO - 2024-02-23 13:20:32 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:20:32 --> Controller Class Initialized
INFO - 2024-02-23 13:20:32 --> Form Validation Class Initialized
INFO - 2024-02-23 13:20:32 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:20:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:20:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:20:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:20:32 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:21:12 --> Config Class Initialized
INFO - 2024-02-23 13:21:12 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:21:12 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:21:12 --> Utf8 Class Initialized
INFO - 2024-02-23 13:21:12 --> URI Class Initialized
INFO - 2024-02-23 13:21:12 --> Router Class Initialized
INFO - 2024-02-23 13:21:12 --> Output Class Initialized
INFO - 2024-02-23 13:21:12 --> Security Class Initialized
DEBUG - 2024-02-23 13:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:21:12 --> Input Class Initialized
INFO - 2024-02-23 13:21:12 --> Language Class Initialized
INFO - 2024-02-23 13:21:12 --> Loader Class Initialized
INFO - 2024-02-23 13:21:12 --> Helper loaded: url_helper
INFO - 2024-02-23 13:21:12 --> Helper loaded: file_helper
INFO - 2024-02-23 13:21:12 --> Helper loaded: form_helper
INFO - 2024-02-23 13:21:12 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:21:12 --> Controller Class Initialized
INFO - 2024-02-23 13:21:12 --> Form Validation Class Initialized
INFO - 2024-02-23 13:21:12 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:21:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:21:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:21:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:21:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:21:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:21:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:21:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:21:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:21:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:21:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:21:12 --> Final output sent to browser
DEBUG - 2024-02-23 13:21:12 --> Total execution time: 0.0356
ERROR - 2024-02-23 13:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:21:13 --> Config Class Initialized
INFO - 2024-02-23 13:21:13 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:21:13 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:21:13 --> Utf8 Class Initialized
INFO - 2024-02-23 13:21:13 --> URI Class Initialized
INFO - 2024-02-23 13:21:13 --> Router Class Initialized
INFO - 2024-02-23 13:21:13 --> Output Class Initialized
INFO - 2024-02-23 13:21:13 --> Security Class Initialized
DEBUG - 2024-02-23 13:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:21:13 --> Input Class Initialized
INFO - 2024-02-23 13:21:13 --> Language Class Initialized
INFO - 2024-02-23 13:21:13 --> Loader Class Initialized
INFO - 2024-02-23 13:21:13 --> Helper loaded: url_helper
INFO - 2024-02-23 13:21:13 --> Helper loaded: file_helper
INFO - 2024-02-23 13:21:13 --> Helper loaded: form_helper
INFO - 2024-02-23 13:21:13 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:21:13 --> Controller Class Initialized
INFO - 2024-02-23 13:21:13 --> Form Validation Class Initialized
INFO - 2024-02-23 13:21:13 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:21:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:21:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:21:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:21:13 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:21:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:21:28 --> Config Class Initialized
INFO - 2024-02-23 13:21:28 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:21:28 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:21:28 --> Utf8 Class Initialized
INFO - 2024-02-23 13:21:28 --> URI Class Initialized
INFO - 2024-02-23 13:21:28 --> Router Class Initialized
INFO - 2024-02-23 13:21:28 --> Output Class Initialized
INFO - 2024-02-23 13:21:28 --> Security Class Initialized
DEBUG - 2024-02-23 13:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:21:28 --> Input Class Initialized
INFO - 2024-02-23 13:21:28 --> Language Class Initialized
INFO - 2024-02-23 13:21:28 --> Loader Class Initialized
INFO - 2024-02-23 13:21:28 --> Helper loaded: url_helper
INFO - 2024-02-23 13:21:28 --> Helper loaded: file_helper
INFO - 2024-02-23 13:21:28 --> Helper loaded: form_helper
INFO - 2024-02-23 13:21:28 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:21:28 --> Controller Class Initialized
INFO - 2024-02-23 13:21:28 --> Form Validation Class Initialized
INFO - 2024-02-23 13:21:28 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:21:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:21:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:21:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:21:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:21:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:21:28 --> Final output sent to browser
DEBUG - 2024-02-23 13:21:28 --> Total execution time: 0.0425
ERROR - 2024-02-23 13:21:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:21:29 --> Config Class Initialized
INFO - 2024-02-23 13:21:29 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:21:29 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:21:29 --> Utf8 Class Initialized
INFO - 2024-02-23 13:21:29 --> URI Class Initialized
INFO - 2024-02-23 13:21:29 --> Router Class Initialized
INFO - 2024-02-23 13:21:29 --> Output Class Initialized
INFO - 2024-02-23 13:21:29 --> Security Class Initialized
DEBUG - 2024-02-23 13:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:21:29 --> Input Class Initialized
INFO - 2024-02-23 13:21:29 --> Language Class Initialized
INFO - 2024-02-23 13:21:29 --> Loader Class Initialized
INFO - 2024-02-23 13:21:29 --> Helper loaded: url_helper
INFO - 2024-02-23 13:21:29 --> Helper loaded: file_helper
INFO - 2024-02-23 13:21:29 --> Helper loaded: form_helper
INFO - 2024-02-23 13:21:29 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:21:29 --> Controller Class Initialized
INFO - 2024-02-23 13:21:29 --> Form Validation Class Initialized
INFO - 2024-02-23 13:21:29 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:21:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:21:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:21:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:21:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:23:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:23:54 --> Config Class Initialized
INFO - 2024-02-23 13:23:54 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:23:54 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:23:54 --> Utf8 Class Initialized
INFO - 2024-02-23 13:23:54 --> URI Class Initialized
INFO - 2024-02-23 13:23:54 --> Router Class Initialized
INFO - 2024-02-23 13:23:54 --> Output Class Initialized
INFO - 2024-02-23 13:23:54 --> Security Class Initialized
DEBUG - 2024-02-23 13:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:23:54 --> Input Class Initialized
INFO - 2024-02-23 13:23:54 --> Language Class Initialized
INFO - 2024-02-23 13:23:54 --> Loader Class Initialized
INFO - 2024-02-23 13:23:54 --> Helper loaded: url_helper
INFO - 2024-02-23 13:23:54 --> Helper loaded: file_helper
INFO - 2024-02-23 13:23:54 --> Helper loaded: form_helper
INFO - 2024-02-23 13:23:54 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:23:54 --> Controller Class Initialized
INFO - 2024-02-23 13:23:54 --> Form Validation Class Initialized
INFO - 2024-02-23 13:23:54 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:23:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:23:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:23:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:23:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:23:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:23:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:23:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:23:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:23:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:23:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:23:54 --> Final output sent to browser
DEBUG - 2024-02-23 13:23:54 --> Total execution time: 0.0382
ERROR - 2024-02-23 13:23:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:23:55 --> Config Class Initialized
INFO - 2024-02-23 13:23:55 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:23:55 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:23:55 --> Utf8 Class Initialized
INFO - 2024-02-23 13:23:55 --> URI Class Initialized
INFO - 2024-02-23 13:23:55 --> Router Class Initialized
INFO - 2024-02-23 13:23:55 --> Output Class Initialized
INFO - 2024-02-23 13:23:55 --> Security Class Initialized
DEBUG - 2024-02-23 13:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:23:55 --> Input Class Initialized
INFO - 2024-02-23 13:23:55 --> Language Class Initialized
INFO - 2024-02-23 13:23:55 --> Loader Class Initialized
INFO - 2024-02-23 13:23:55 --> Helper loaded: url_helper
INFO - 2024-02-23 13:23:55 --> Helper loaded: file_helper
INFO - 2024-02-23 13:23:55 --> Helper loaded: form_helper
INFO - 2024-02-23 13:23:55 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:23:55 --> Controller Class Initialized
INFO - 2024-02-23 13:23:55 --> Form Validation Class Initialized
INFO - 2024-02-23 13:23:55 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:23:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:23:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:23:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:23:55 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:25:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:25:30 --> Config Class Initialized
INFO - 2024-02-23 13:25:30 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:25:30 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:25:30 --> Utf8 Class Initialized
INFO - 2024-02-23 13:25:30 --> URI Class Initialized
INFO - 2024-02-23 13:25:30 --> Router Class Initialized
INFO - 2024-02-23 13:25:30 --> Output Class Initialized
INFO - 2024-02-23 13:25:30 --> Security Class Initialized
DEBUG - 2024-02-23 13:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:25:30 --> Input Class Initialized
INFO - 2024-02-23 13:25:30 --> Language Class Initialized
INFO - 2024-02-23 13:25:30 --> Loader Class Initialized
INFO - 2024-02-23 13:25:30 --> Helper loaded: url_helper
INFO - 2024-02-23 13:25:30 --> Helper loaded: file_helper
INFO - 2024-02-23 13:25:30 --> Helper loaded: form_helper
INFO - 2024-02-23 13:25:30 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:25:30 --> Controller Class Initialized
INFO - 2024-02-23 13:25:30 --> Form Validation Class Initialized
INFO - 2024-02-23 13:25:30 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:25:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:25:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:25:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:25:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:25:30 --> Final output sent to browser
DEBUG - 2024-02-23 13:25:30 --> Total execution time: 0.0354
ERROR - 2024-02-23 13:25:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:25:30 --> Config Class Initialized
INFO - 2024-02-23 13:25:30 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:25:30 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:25:30 --> Utf8 Class Initialized
INFO - 2024-02-23 13:25:30 --> URI Class Initialized
INFO - 2024-02-23 13:25:30 --> Router Class Initialized
INFO - 2024-02-23 13:25:30 --> Output Class Initialized
INFO - 2024-02-23 13:25:30 --> Security Class Initialized
DEBUG - 2024-02-23 13:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:25:30 --> Input Class Initialized
INFO - 2024-02-23 13:25:30 --> Language Class Initialized
INFO - 2024-02-23 13:25:30 --> Loader Class Initialized
INFO - 2024-02-23 13:25:30 --> Helper loaded: url_helper
INFO - 2024-02-23 13:25:30 --> Helper loaded: file_helper
INFO - 2024-02-23 13:25:30 --> Helper loaded: form_helper
INFO - 2024-02-23 13:25:30 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:25:30 --> Controller Class Initialized
INFO - 2024-02-23 13:25:30 --> Form Validation Class Initialized
INFO - 2024-02-23 13:25:30 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:25:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:25:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:25:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:25:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:25:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:25:42 --> Config Class Initialized
INFO - 2024-02-23 13:25:42 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:25:42 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:25:42 --> Utf8 Class Initialized
INFO - 2024-02-23 13:25:42 --> URI Class Initialized
INFO - 2024-02-23 13:25:42 --> Router Class Initialized
INFO - 2024-02-23 13:25:42 --> Output Class Initialized
INFO - 2024-02-23 13:25:42 --> Security Class Initialized
DEBUG - 2024-02-23 13:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:25:42 --> Input Class Initialized
INFO - 2024-02-23 13:25:42 --> Language Class Initialized
INFO - 2024-02-23 13:25:42 --> Loader Class Initialized
INFO - 2024-02-23 13:25:42 --> Helper loaded: url_helper
INFO - 2024-02-23 13:25:42 --> Helper loaded: file_helper
INFO - 2024-02-23 13:25:42 --> Helper loaded: form_helper
INFO - 2024-02-23 13:25:42 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:25:42 --> Controller Class Initialized
INFO - 2024-02-23 13:25:42 --> Form Validation Class Initialized
INFO - 2024-02-23 13:25:42 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:25:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:25:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:25:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:25:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:25:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:25:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:25:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:25:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:25:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:25:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:25:42 --> Final output sent to browser
DEBUG - 2024-02-23 13:25:42 --> Total execution time: 0.0310
ERROR - 2024-02-23 13:25:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:25:42 --> Config Class Initialized
INFO - 2024-02-23 13:25:42 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:25:42 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:25:42 --> Utf8 Class Initialized
INFO - 2024-02-23 13:25:42 --> URI Class Initialized
INFO - 2024-02-23 13:25:42 --> Router Class Initialized
INFO - 2024-02-23 13:25:42 --> Output Class Initialized
INFO - 2024-02-23 13:25:42 --> Security Class Initialized
DEBUG - 2024-02-23 13:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:25:42 --> Input Class Initialized
INFO - 2024-02-23 13:25:42 --> Language Class Initialized
INFO - 2024-02-23 13:25:42 --> Loader Class Initialized
INFO - 2024-02-23 13:25:42 --> Helper loaded: url_helper
INFO - 2024-02-23 13:25:42 --> Helper loaded: file_helper
INFO - 2024-02-23 13:25:42 --> Helper loaded: form_helper
INFO - 2024-02-23 13:25:42 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:25:43 --> Controller Class Initialized
INFO - 2024-02-23 13:25:43 --> Form Validation Class Initialized
INFO - 2024-02-23 13:25:43 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:25:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:25:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:25:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:25:43 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:27:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:27:01 --> Config Class Initialized
INFO - 2024-02-23 13:27:01 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:27:01 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:27:01 --> Utf8 Class Initialized
INFO - 2024-02-23 13:27:01 --> URI Class Initialized
INFO - 2024-02-23 13:27:01 --> Router Class Initialized
INFO - 2024-02-23 13:27:01 --> Output Class Initialized
INFO - 2024-02-23 13:27:01 --> Security Class Initialized
DEBUG - 2024-02-23 13:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:27:01 --> Input Class Initialized
INFO - 2024-02-23 13:27:01 --> Language Class Initialized
INFO - 2024-02-23 13:27:01 --> Loader Class Initialized
INFO - 2024-02-23 13:27:01 --> Helper loaded: url_helper
INFO - 2024-02-23 13:27:01 --> Helper loaded: file_helper
INFO - 2024-02-23 13:27:01 --> Helper loaded: form_helper
INFO - 2024-02-23 13:27:01 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:27:01 --> Controller Class Initialized
INFO - 2024-02-23 13:27:01 --> Form Validation Class Initialized
INFO - 2024-02-23 13:27:01 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:27:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:27:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:27:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:27:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:27:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:27:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:27:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:27:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:27:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:27:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:27:01 --> Final output sent to browser
DEBUG - 2024-02-23 13:27:01 --> Total execution time: 0.0366
ERROR - 2024-02-23 13:27:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:27:01 --> Config Class Initialized
INFO - 2024-02-23 13:27:01 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:27:01 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:27:01 --> Utf8 Class Initialized
INFO - 2024-02-23 13:27:01 --> URI Class Initialized
INFO - 2024-02-23 13:27:01 --> Router Class Initialized
INFO - 2024-02-23 13:27:01 --> Output Class Initialized
INFO - 2024-02-23 13:27:01 --> Security Class Initialized
DEBUG - 2024-02-23 13:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:27:01 --> Input Class Initialized
INFO - 2024-02-23 13:27:01 --> Language Class Initialized
INFO - 2024-02-23 13:27:01 --> Loader Class Initialized
INFO - 2024-02-23 13:27:01 --> Helper loaded: url_helper
INFO - 2024-02-23 13:27:01 --> Helper loaded: file_helper
INFO - 2024-02-23 13:27:01 --> Helper loaded: form_helper
INFO - 2024-02-23 13:27:01 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:27:01 --> Controller Class Initialized
INFO - 2024-02-23 13:27:01 --> Form Validation Class Initialized
INFO - 2024-02-23 13:27:01 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:27:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:27:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:27:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:27:01 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:27:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:27:08 --> Config Class Initialized
INFO - 2024-02-23 13:27:08 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:27:08 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:27:08 --> Utf8 Class Initialized
INFO - 2024-02-23 13:27:08 --> URI Class Initialized
INFO - 2024-02-23 13:27:08 --> Router Class Initialized
INFO - 2024-02-23 13:27:08 --> Output Class Initialized
INFO - 2024-02-23 13:27:08 --> Security Class Initialized
DEBUG - 2024-02-23 13:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:27:08 --> Input Class Initialized
INFO - 2024-02-23 13:27:08 --> Language Class Initialized
INFO - 2024-02-23 13:27:08 --> Loader Class Initialized
INFO - 2024-02-23 13:27:08 --> Helper loaded: url_helper
INFO - 2024-02-23 13:27:08 --> Helper loaded: file_helper
INFO - 2024-02-23 13:27:08 --> Helper loaded: form_helper
INFO - 2024-02-23 13:27:08 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:27:08 --> Controller Class Initialized
INFO - 2024-02-23 13:27:08 --> Form Validation Class Initialized
INFO - 2024-02-23 13:27:08 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:27:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:27:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:27:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:27:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:27:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:27:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:27:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:27:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:27:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:27:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:27:08 --> Final output sent to browser
DEBUG - 2024-02-23 13:27:08 --> Total execution time: 0.0315
ERROR - 2024-02-23 13:27:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:27:08 --> Config Class Initialized
INFO - 2024-02-23 13:27:08 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:27:08 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:27:08 --> Utf8 Class Initialized
INFO - 2024-02-23 13:27:08 --> URI Class Initialized
INFO - 2024-02-23 13:27:08 --> Router Class Initialized
INFO - 2024-02-23 13:27:08 --> Output Class Initialized
INFO - 2024-02-23 13:27:08 --> Security Class Initialized
DEBUG - 2024-02-23 13:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:27:08 --> Input Class Initialized
INFO - 2024-02-23 13:27:08 --> Language Class Initialized
INFO - 2024-02-23 13:27:08 --> Loader Class Initialized
INFO - 2024-02-23 13:27:08 --> Helper loaded: url_helper
INFO - 2024-02-23 13:27:08 --> Helper loaded: file_helper
INFO - 2024-02-23 13:27:08 --> Helper loaded: form_helper
INFO - 2024-02-23 13:27:08 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:27:08 --> Controller Class Initialized
INFO - 2024-02-23 13:27:08 --> Form Validation Class Initialized
INFO - 2024-02-23 13:27:08 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:27:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:27:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:27:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:27:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:28:38 --> Config Class Initialized
INFO - 2024-02-23 13:28:38 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:28:38 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:28:38 --> Utf8 Class Initialized
INFO - 2024-02-23 13:28:38 --> URI Class Initialized
INFO - 2024-02-23 13:28:38 --> Router Class Initialized
INFO - 2024-02-23 13:28:38 --> Output Class Initialized
INFO - 2024-02-23 13:28:38 --> Security Class Initialized
DEBUG - 2024-02-23 13:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:28:38 --> Input Class Initialized
INFO - 2024-02-23 13:28:38 --> Language Class Initialized
INFO - 2024-02-23 13:28:38 --> Loader Class Initialized
INFO - 2024-02-23 13:28:38 --> Helper loaded: url_helper
INFO - 2024-02-23 13:28:38 --> Helper loaded: file_helper
INFO - 2024-02-23 13:28:38 --> Helper loaded: form_helper
INFO - 2024-02-23 13:28:38 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:28:38 --> Controller Class Initialized
INFO - 2024-02-23 13:28:38 --> Form Validation Class Initialized
INFO - 2024-02-23 13:28:38 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:28:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:28:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:28:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:28:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:28:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:28:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:28:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:28:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:28:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:28:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:28:38 --> Final output sent to browser
DEBUG - 2024-02-23 13:28:38 --> Total execution time: 0.0279
ERROR - 2024-02-23 13:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:28:39 --> Config Class Initialized
INFO - 2024-02-23 13:28:39 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:28:39 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:28:39 --> Utf8 Class Initialized
INFO - 2024-02-23 13:28:39 --> URI Class Initialized
INFO - 2024-02-23 13:28:39 --> Router Class Initialized
INFO - 2024-02-23 13:28:39 --> Output Class Initialized
INFO - 2024-02-23 13:28:39 --> Security Class Initialized
DEBUG - 2024-02-23 13:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:28:39 --> Input Class Initialized
INFO - 2024-02-23 13:28:39 --> Language Class Initialized
INFO - 2024-02-23 13:28:39 --> Loader Class Initialized
INFO - 2024-02-23 13:28:39 --> Helper loaded: url_helper
INFO - 2024-02-23 13:28:39 --> Helper loaded: file_helper
INFO - 2024-02-23 13:28:39 --> Helper loaded: form_helper
INFO - 2024-02-23 13:28:39 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:28:39 --> Controller Class Initialized
INFO - 2024-02-23 13:28:39 --> Form Validation Class Initialized
INFO - 2024-02-23 13:28:39 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:28:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:28:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:28:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:28:39 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:30:52 --> Config Class Initialized
INFO - 2024-02-23 13:30:52 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:30:52 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:30:52 --> Utf8 Class Initialized
INFO - 2024-02-23 13:30:52 --> URI Class Initialized
INFO - 2024-02-23 13:30:52 --> Router Class Initialized
INFO - 2024-02-23 13:30:52 --> Output Class Initialized
INFO - 2024-02-23 13:30:52 --> Security Class Initialized
DEBUG - 2024-02-23 13:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:30:52 --> Input Class Initialized
INFO - 2024-02-23 13:30:52 --> Language Class Initialized
INFO - 2024-02-23 13:30:52 --> Loader Class Initialized
INFO - 2024-02-23 13:30:52 --> Helper loaded: url_helper
INFO - 2024-02-23 13:30:52 --> Helper loaded: file_helper
INFO - 2024-02-23 13:30:52 --> Helper loaded: form_helper
INFO - 2024-02-23 13:30:52 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:30:52 --> Controller Class Initialized
INFO - 2024-02-23 13:30:52 --> Form Validation Class Initialized
INFO - 2024-02-23 13:30:52 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:30:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:30:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:30:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:30:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:30:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:30:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:30:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:30:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:30:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:30:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:30:52 --> Final output sent to browser
DEBUG - 2024-02-23 13:30:52 --> Total execution time: 0.0377
ERROR - 2024-02-23 13:30:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:30:53 --> Config Class Initialized
INFO - 2024-02-23 13:30:53 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:30:53 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:30:53 --> Utf8 Class Initialized
INFO - 2024-02-23 13:30:53 --> URI Class Initialized
INFO - 2024-02-23 13:30:53 --> Router Class Initialized
INFO - 2024-02-23 13:30:53 --> Output Class Initialized
INFO - 2024-02-23 13:30:53 --> Security Class Initialized
DEBUG - 2024-02-23 13:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:30:53 --> Input Class Initialized
INFO - 2024-02-23 13:30:53 --> Language Class Initialized
INFO - 2024-02-23 13:30:53 --> Loader Class Initialized
INFO - 2024-02-23 13:30:53 --> Helper loaded: url_helper
INFO - 2024-02-23 13:30:53 --> Helper loaded: file_helper
INFO - 2024-02-23 13:30:53 --> Helper loaded: form_helper
INFO - 2024-02-23 13:30:53 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:30:53 --> Controller Class Initialized
INFO - 2024-02-23 13:30:53 --> Form Validation Class Initialized
INFO - 2024-02-23 13:30:53 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:30:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:30:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:30:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:30:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:31:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:31:09 --> Config Class Initialized
INFO - 2024-02-23 13:31:09 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:31:09 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:31:09 --> Utf8 Class Initialized
INFO - 2024-02-23 13:31:09 --> URI Class Initialized
INFO - 2024-02-23 13:31:09 --> Router Class Initialized
INFO - 2024-02-23 13:31:09 --> Output Class Initialized
INFO - 2024-02-23 13:31:09 --> Security Class Initialized
DEBUG - 2024-02-23 13:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:31:09 --> Input Class Initialized
INFO - 2024-02-23 13:31:09 --> Language Class Initialized
INFO - 2024-02-23 13:31:09 --> Loader Class Initialized
INFO - 2024-02-23 13:31:09 --> Helper loaded: url_helper
INFO - 2024-02-23 13:31:09 --> Helper loaded: file_helper
INFO - 2024-02-23 13:31:09 --> Helper loaded: form_helper
INFO - 2024-02-23 13:31:09 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:31:09 --> Controller Class Initialized
INFO - 2024-02-23 13:31:09 --> Form Validation Class Initialized
INFO - 2024-02-23 13:31:09 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:31:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:31:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:31:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:31:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:31:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:31:09 --> Final output sent to browser
DEBUG - 2024-02-23 13:31:09 --> Total execution time: 0.0311
ERROR - 2024-02-23 13:31:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:31:10 --> Config Class Initialized
INFO - 2024-02-23 13:31:10 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:31:10 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:31:10 --> Utf8 Class Initialized
INFO - 2024-02-23 13:31:10 --> URI Class Initialized
INFO - 2024-02-23 13:31:10 --> Router Class Initialized
INFO - 2024-02-23 13:31:10 --> Output Class Initialized
INFO - 2024-02-23 13:31:10 --> Security Class Initialized
DEBUG - 2024-02-23 13:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:31:10 --> Input Class Initialized
INFO - 2024-02-23 13:31:10 --> Language Class Initialized
INFO - 2024-02-23 13:31:10 --> Loader Class Initialized
INFO - 2024-02-23 13:31:10 --> Helper loaded: url_helper
INFO - 2024-02-23 13:31:10 --> Helper loaded: file_helper
INFO - 2024-02-23 13:31:10 --> Helper loaded: form_helper
INFO - 2024-02-23 13:31:10 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:31:10 --> Controller Class Initialized
INFO - 2024-02-23 13:31:10 --> Form Validation Class Initialized
INFO - 2024-02-23 13:31:10 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:31:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:31:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:31:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:31:10 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:31:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:31:37 --> Config Class Initialized
INFO - 2024-02-23 13:31:37 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:31:37 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:31:37 --> Utf8 Class Initialized
INFO - 2024-02-23 13:31:37 --> URI Class Initialized
INFO - 2024-02-23 13:31:37 --> Router Class Initialized
INFO - 2024-02-23 13:31:37 --> Output Class Initialized
INFO - 2024-02-23 13:31:37 --> Security Class Initialized
DEBUG - 2024-02-23 13:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:31:37 --> Input Class Initialized
INFO - 2024-02-23 13:31:37 --> Language Class Initialized
INFO - 2024-02-23 13:31:37 --> Loader Class Initialized
INFO - 2024-02-23 13:31:37 --> Helper loaded: url_helper
INFO - 2024-02-23 13:31:37 --> Helper loaded: file_helper
INFO - 2024-02-23 13:31:37 --> Helper loaded: form_helper
INFO - 2024-02-23 13:31:37 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:31:37 --> Controller Class Initialized
INFO - 2024-02-23 13:31:37 --> Form Validation Class Initialized
INFO - 2024-02-23 13:31:37 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:31:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:31:37 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:31:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:31:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:31:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:31:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:31:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:31:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:31:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:31:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:31:37 --> Final output sent to browser
DEBUG - 2024-02-23 13:31:37 --> Total execution time: 0.0325
ERROR - 2024-02-23 13:31:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:31:38 --> Config Class Initialized
INFO - 2024-02-23 13:31:38 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:31:38 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:31:38 --> Utf8 Class Initialized
INFO - 2024-02-23 13:31:38 --> URI Class Initialized
INFO - 2024-02-23 13:31:38 --> Router Class Initialized
INFO - 2024-02-23 13:31:38 --> Output Class Initialized
INFO - 2024-02-23 13:31:38 --> Security Class Initialized
DEBUG - 2024-02-23 13:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:31:38 --> Input Class Initialized
INFO - 2024-02-23 13:31:38 --> Language Class Initialized
INFO - 2024-02-23 13:31:38 --> Loader Class Initialized
INFO - 2024-02-23 13:31:38 --> Helper loaded: url_helper
INFO - 2024-02-23 13:31:38 --> Helper loaded: file_helper
INFO - 2024-02-23 13:31:38 --> Helper loaded: form_helper
INFO - 2024-02-23 13:31:38 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:31:38 --> Controller Class Initialized
INFO - 2024-02-23 13:31:38 --> Form Validation Class Initialized
INFO - 2024-02-23 13:31:38 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:31:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:31:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:31:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:31:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:31:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:31:44 --> Config Class Initialized
INFO - 2024-02-23 13:31:44 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:31:44 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:31:44 --> Utf8 Class Initialized
INFO - 2024-02-23 13:31:44 --> URI Class Initialized
INFO - 2024-02-23 13:31:44 --> Router Class Initialized
INFO - 2024-02-23 13:31:44 --> Output Class Initialized
INFO - 2024-02-23 13:31:44 --> Security Class Initialized
DEBUG - 2024-02-23 13:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:31:44 --> Input Class Initialized
INFO - 2024-02-23 13:31:44 --> Language Class Initialized
INFO - 2024-02-23 13:31:44 --> Loader Class Initialized
INFO - 2024-02-23 13:31:44 --> Helper loaded: url_helper
INFO - 2024-02-23 13:31:44 --> Helper loaded: file_helper
INFO - 2024-02-23 13:31:44 --> Helper loaded: form_helper
INFO - 2024-02-23 13:31:44 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:31:44 --> Controller Class Initialized
INFO - 2024-02-23 13:31:44 --> Form Validation Class Initialized
INFO - 2024-02-23 13:31:44 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:31:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:31:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:31:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:31:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:31:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:31:45 --> Config Class Initialized
INFO - 2024-02-23 13:31:45 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:31:45 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:31:45 --> Utf8 Class Initialized
INFO - 2024-02-23 13:31:45 --> URI Class Initialized
INFO - 2024-02-23 13:31:45 --> Router Class Initialized
INFO - 2024-02-23 13:31:45 --> Output Class Initialized
INFO - 2024-02-23 13:31:45 --> Security Class Initialized
DEBUG - 2024-02-23 13:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:31:45 --> Input Class Initialized
INFO - 2024-02-23 13:31:45 --> Language Class Initialized
INFO - 2024-02-23 13:31:45 --> Loader Class Initialized
INFO - 2024-02-23 13:31:45 --> Helper loaded: url_helper
INFO - 2024-02-23 13:31:45 --> Helper loaded: file_helper
INFO - 2024-02-23 13:31:45 --> Helper loaded: form_helper
INFO - 2024-02-23 13:31:45 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:31:45 --> Controller Class Initialized
INFO - 2024-02-23 13:31:45 --> Form Validation Class Initialized
INFO - 2024-02-23 13:31:45 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:31:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:31:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:31:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:31:45 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:32:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:32:26 --> Config Class Initialized
INFO - 2024-02-23 13:32:26 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:32:26 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:32:26 --> Utf8 Class Initialized
INFO - 2024-02-23 13:32:26 --> URI Class Initialized
INFO - 2024-02-23 13:32:26 --> Router Class Initialized
INFO - 2024-02-23 13:32:26 --> Output Class Initialized
INFO - 2024-02-23 13:32:26 --> Security Class Initialized
DEBUG - 2024-02-23 13:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:32:26 --> Input Class Initialized
INFO - 2024-02-23 13:32:26 --> Language Class Initialized
INFO - 2024-02-23 13:32:26 --> Loader Class Initialized
INFO - 2024-02-23 13:32:26 --> Helper loaded: url_helper
INFO - 2024-02-23 13:32:26 --> Helper loaded: file_helper
INFO - 2024-02-23 13:32:26 --> Helper loaded: form_helper
INFO - 2024-02-23 13:32:26 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:32:26 --> Controller Class Initialized
INFO - 2024-02-23 13:32:26 --> Form Validation Class Initialized
INFO - 2024-02-23 13:32:26 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:32:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:32:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:32:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:32:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:32:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:32:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:32:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:32:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:32:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:32:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:32:26 --> Final output sent to browser
DEBUG - 2024-02-23 13:32:26 --> Total execution time: 0.0367
ERROR - 2024-02-23 13:32:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:32:27 --> Config Class Initialized
INFO - 2024-02-23 13:32:27 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:32:27 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:32:27 --> Utf8 Class Initialized
INFO - 2024-02-23 13:32:27 --> URI Class Initialized
INFO - 2024-02-23 13:32:27 --> Router Class Initialized
INFO - 2024-02-23 13:32:27 --> Output Class Initialized
INFO - 2024-02-23 13:32:27 --> Security Class Initialized
DEBUG - 2024-02-23 13:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:32:27 --> Input Class Initialized
INFO - 2024-02-23 13:32:27 --> Language Class Initialized
INFO - 2024-02-23 13:32:27 --> Loader Class Initialized
INFO - 2024-02-23 13:32:27 --> Helper loaded: url_helper
INFO - 2024-02-23 13:32:27 --> Helper loaded: file_helper
INFO - 2024-02-23 13:32:27 --> Helper loaded: form_helper
INFO - 2024-02-23 13:32:27 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:32:27 --> Controller Class Initialized
INFO - 2024-02-23 13:32:27 --> Form Validation Class Initialized
INFO - 2024-02-23 13:32:27 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:32:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:32:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:32:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:32:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:32:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:32:52 --> Config Class Initialized
INFO - 2024-02-23 13:32:52 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:32:52 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:32:52 --> Utf8 Class Initialized
INFO - 2024-02-23 13:32:52 --> URI Class Initialized
INFO - 2024-02-23 13:32:52 --> Router Class Initialized
INFO - 2024-02-23 13:32:52 --> Output Class Initialized
INFO - 2024-02-23 13:32:52 --> Security Class Initialized
DEBUG - 2024-02-23 13:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:32:52 --> Input Class Initialized
INFO - 2024-02-23 13:32:52 --> Language Class Initialized
INFO - 2024-02-23 13:32:52 --> Loader Class Initialized
INFO - 2024-02-23 13:32:52 --> Helper loaded: url_helper
INFO - 2024-02-23 13:32:52 --> Helper loaded: file_helper
INFO - 2024-02-23 13:32:52 --> Helper loaded: form_helper
INFO - 2024-02-23 13:32:52 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:32:52 --> Controller Class Initialized
INFO - 2024-02-23 13:32:52 --> Form Validation Class Initialized
INFO - 2024-02-23 13:32:52 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:32:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:32:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:32:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:32:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:32:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:32:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:32:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:32:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:32:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:32:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:32:52 --> Final output sent to browser
DEBUG - 2024-02-23 13:32:52 --> Total execution time: 0.0285
ERROR - 2024-02-23 13:32:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:32:53 --> Config Class Initialized
INFO - 2024-02-23 13:32:53 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:32:53 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:32:53 --> Utf8 Class Initialized
INFO - 2024-02-23 13:32:53 --> URI Class Initialized
INFO - 2024-02-23 13:32:53 --> Router Class Initialized
INFO - 2024-02-23 13:32:53 --> Output Class Initialized
INFO - 2024-02-23 13:32:53 --> Security Class Initialized
DEBUG - 2024-02-23 13:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:32:53 --> Input Class Initialized
INFO - 2024-02-23 13:32:53 --> Language Class Initialized
INFO - 2024-02-23 13:32:53 --> Loader Class Initialized
INFO - 2024-02-23 13:32:53 --> Helper loaded: url_helper
INFO - 2024-02-23 13:32:53 --> Helper loaded: file_helper
INFO - 2024-02-23 13:32:53 --> Helper loaded: form_helper
INFO - 2024-02-23 13:32:53 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:32:53 --> Controller Class Initialized
INFO - 2024-02-23 13:32:53 --> Form Validation Class Initialized
INFO - 2024-02-23 13:32:53 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:32:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:32:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:32:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:32:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:36:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:36:46 --> Config Class Initialized
INFO - 2024-02-23 13:36:46 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:36:46 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:36:46 --> Utf8 Class Initialized
INFO - 2024-02-23 13:36:46 --> URI Class Initialized
INFO - 2024-02-23 13:36:46 --> Router Class Initialized
INFO - 2024-02-23 13:36:46 --> Output Class Initialized
INFO - 2024-02-23 13:36:46 --> Security Class Initialized
DEBUG - 2024-02-23 13:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:36:46 --> Input Class Initialized
INFO - 2024-02-23 13:36:46 --> Language Class Initialized
INFO - 2024-02-23 13:36:46 --> Loader Class Initialized
INFO - 2024-02-23 13:36:46 --> Helper loaded: url_helper
INFO - 2024-02-23 13:36:46 --> Helper loaded: file_helper
INFO - 2024-02-23 13:36:46 --> Helper loaded: form_helper
INFO - 2024-02-23 13:36:46 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:36:46 --> Controller Class Initialized
INFO - 2024-02-23 13:36:46 --> Form Validation Class Initialized
INFO - 2024-02-23 13:36:46 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:36:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:36:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:36:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:36:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:36:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:36:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:36:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:36:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:36:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:36:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:36:46 --> Final output sent to browser
DEBUG - 2024-02-23 13:36:46 --> Total execution time: 0.0385
ERROR - 2024-02-23 13:36:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:36:47 --> Config Class Initialized
INFO - 2024-02-23 13:36:47 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:36:47 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:36:47 --> Utf8 Class Initialized
INFO - 2024-02-23 13:36:47 --> URI Class Initialized
INFO - 2024-02-23 13:36:47 --> Router Class Initialized
INFO - 2024-02-23 13:36:47 --> Output Class Initialized
INFO - 2024-02-23 13:36:47 --> Security Class Initialized
DEBUG - 2024-02-23 13:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:36:47 --> Input Class Initialized
INFO - 2024-02-23 13:36:47 --> Language Class Initialized
INFO - 2024-02-23 13:36:47 --> Loader Class Initialized
INFO - 2024-02-23 13:36:47 --> Helper loaded: url_helper
INFO - 2024-02-23 13:36:47 --> Helper loaded: file_helper
INFO - 2024-02-23 13:36:47 --> Helper loaded: form_helper
INFO - 2024-02-23 13:36:47 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:36:47 --> Controller Class Initialized
INFO - 2024-02-23 13:36:47 --> Form Validation Class Initialized
INFO - 2024-02-23 13:36:47 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:36:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:36:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:36:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:36:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:36:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:36:50 --> Config Class Initialized
INFO - 2024-02-23 13:36:50 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:36:50 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:36:50 --> Utf8 Class Initialized
INFO - 2024-02-23 13:36:50 --> URI Class Initialized
INFO - 2024-02-23 13:36:50 --> Router Class Initialized
INFO - 2024-02-23 13:36:50 --> Output Class Initialized
INFO - 2024-02-23 13:36:50 --> Security Class Initialized
DEBUG - 2024-02-23 13:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:36:50 --> Input Class Initialized
INFO - 2024-02-23 13:36:50 --> Language Class Initialized
INFO - 2024-02-23 13:36:50 --> Loader Class Initialized
INFO - 2024-02-23 13:36:50 --> Helper loaded: url_helper
INFO - 2024-02-23 13:36:50 --> Helper loaded: file_helper
INFO - 2024-02-23 13:36:50 --> Helper loaded: form_helper
INFO - 2024-02-23 13:36:50 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:36:50 --> Controller Class Initialized
INFO - 2024-02-23 13:36:50 --> Form Validation Class Initialized
INFO - 2024-02-23 13:36:50 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:36:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:36:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:36:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:36:50 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:36:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:36:57 --> Config Class Initialized
INFO - 2024-02-23 13:36:57 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:36:57 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:36:57 --> Utf8 Class Initialized
INFO - 2024-02-23 13:36:57 --> URI Class Initialized
INFO - 2024-02-23 13:36:57 --> Router Class Initialized
INFO - 2024-02-23 13:36:57 --> Output Class Initialized
INFO - 2024-02-23 13:36:57 --> Security Class Initialized
DEBUG - 2024-02-23 13:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:36:57 --> Input Class Initialized
INFO - 2024-02-23 13:36:57 --> Language Class Initialized
INFO - 2024-02-23 13:36:57 --> Loader Class Initialized
INFO - 2024-02-23 13:36:57 --> Helper loaded: url_helper
INFO - 2024-02-23 13:36:57 --> Helper loaded: file_helper
INFO - 2024-02-23 13:36:57 --> Helper loaded: form_helper
INFO - 2024-02-23 13:36:57 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:36:57 --> Controller Class Initialized
INFO - 2024-02-23 13:36:57 --> Form Validation Class Initialized
INFO - 2024-02-23 13:36:57 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:36:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:36:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:36:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:36:57 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:37:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:37:08 --> Config Class Initialized
INFO - 2024-02-23 13:37:08 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:37:08 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:37:08 --> Utf8 Class Initialized
INFO - 2024-02-23 13:37:08 --> URI Class Initialized
INFO - 2024-02-23 13:37:08 --> Router Class Initialized
INFO - 2024-02-23 13:37:08 --> Output Class Initialized
INFO - 2024-02-23 13:37:08 --> Security Class Initialized
DEBUG - 2024-02-23 13:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:37:08 --> Input Class Initialized
INFO - 2024-02-23 13:37:08 --> Language Class Initialized
INFO - 2024-02-23 13:37:08 --> Loader Class Initialized
INFO - 2024-02-23 13:37:08 --> Helper loaded: url_helper
INFO - 2024-02-23 13:37:08 --> Helper loaded: file_helper
INFO - 2024-02-23 13:37:08 --> Helper loaded: form_helper
INFO - 2024-02-23 13:37:08 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:37:08 --> Controller Class Initialized
INFO - 2024-02-23 13:37:08 --> Form Validation Class Initialized
INFO - 2024-02-23 13:37:08 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:37:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:37:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:37:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:37:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:37:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:37:16 --> Config Class Initialized
INFO - 2024-02-23 13:37:16 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:37:16 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:37:16 --> Utf8 Class Initialized
INFO - 2024-02-23 13:37:16 --> URI Class Initialized
INFO - 2024-02-23 13:37:16 --> Router Class Initialized
INFO - 2024-02-23 13:37:16 --> Output Class Initialized
INFO - 2024-02-23 13:37:16 --> Security Class Initialized
DEBUG - 2024-02-23 13:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:37:16 --> Input Class Initialized
INFO - 2024-02-23 13:37:16 --> Language Class Initialized
INFO - 2024-02-23 13:37:16 --> Loader Class Initialized
INFO - 2024-02-23 13:37:16 --> Helper loaded: url_helper
INFO - 2024-02-23 13:37:16 --> Helper loaded: file_helper
INFO - 2024-02-23 13:37:16 --> Helper loaded: form_helper
INFO - 2024-02-23 13:37:16 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:37:16 --> Controller Class Initialized
INFO - 2024-02-23 13:37:16 --> Form Validation Class Initialized
INFO - 2024-02-23 13:37:16 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:37:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:37:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:37:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:37:16 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:40:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:40:47 --> Config Class Initialized
INFO - 2024-02-23 13:40:47 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:40:47 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:40:47 --> Utf8 Class Initialized
INFO - 2024-02-23 13:40:47 --> URI Class Initialized
INFO - 2024-02-23 13:40:47 --> Router Class Initialized
INFO - 2024-02-23 13:40:47 --> Output Class Initialized
INFO - 2024-02-23 13:40:47 --> Security Class Initialized
DEBUG - 2024-02-23 13:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:40:47 --> Input Class Initialized
INFO - 2024-02-23 13:40:47 --> Language Class Initialized
INFO - 2024-02-23 13:40:47 --> Loader Class Initialized
INFO - 2024-02-23 13:40:47 --> Helper loaded: url_helper
INFO - 2024-02-23 13:40:47 --> Helper loaded: file_helper
INFO - 2024-02-23 13:40:47 --> Helper loaded: form_helper
INFO - 2024-02-23 13:40:47 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:40:47 --> Controller Class Initialized
INFO - 2024-02-23 13:40:47 --> Form Validation Class Initialized
INFO - 2024-02-23 13:40:47 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:40:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:40:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:40:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:40:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:40:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:40:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:40:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:40:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:40:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:40:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:40:47 --> Final output sent to browser
DEBUG - 2024-02-23 13:40:47 --> Total execution time: 0.0341
ERROR - 2024-02-23 13:40:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:40:48 --> Config Class Initialized
INFO - 2024-02-23 13:40:48 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:40:48 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:40:48 --> Utf8 Class Initialized
INFO - 2024-02-23 13:40:48 --> URI Class Initialized
INFO - 2024-02-23 13:40:48 --> Router Class Initialized
INFO - 2024-02-23 13:40:48 --> Output Class Initialized
INFO - 2024-02-23 13:40:48 --> Security Class Initialized
DEBUG - 2024-02-23 13:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:40:48 --> Input Class Initialized
INFO - 2024-02-23 13:40:48 --> Language Class Initialized
INFO - 2024-02-23 13:40:48 --> Loader Class Initialized
INFO - 2024-02-23 13:40:48 --> Helper loaded: url_helper
INFO - 2024-02-23 13:40:48 --> Helper loaded: file_helper
INFO - 2024-02-23 13:40:48 --> Helper loaded: form_helper
INFO - 2024-02-23 13:40:48 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:40:48 --> Controller Class Initialized
INFO - 2024-02-23 13:40:48 --> Form Validation Class Initialized
INFO - 2024-02-23 13:40:48 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:40:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:40:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:40:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:40:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:42:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:42:00 --> Config Class Initialized
INFO - 2024-02-23 13:42:00 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:42:00 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:42:00 --> Utf8 Class Initialized
INFO - 2024-02-23 13:42:00 --> URI Class Initialized
INFO - 2024-02-23 13:42:00 --> Router Class Initialized
INFO - 2024-02-23 13:42:00 --> Output Class Initialized
INFO - 2024-02-23 13:42:00 --> Security Class Initialized
DEBUG - 2024-02-23 13:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:42:00 --> Input Class Initialized
INFO - 2024-02-23 13:42:00 --> Language Class Initialized
INFO - 2024-02-23 13:42:00 --> Loader Class Initialized
INFO - 2024-02-23 13:42:00 --> Helper loaded: url_helper
INFO - 2024-02-23 13:42:00 --> Helper loaded: file_helper
INFO - 2024-02-23 13:42:00 --> Helper loaded: form_helper
INFO - 2024-02-23 13:42:00 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:42:00 --> Controller Class Initialized
INFO - 2024-02-23 13:42:00 --> Form Validation Class Initialized
INFO - 2024-02-23 13:42:00 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:42:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:42:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:42:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:42:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:42:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:42:00 --> Final output sent to browser
DEBUG - 2024-02-23 13:42:00 --> Total execution time: 0.0383
ERROR - 2024-02-23 13:42:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:42:01 --> Config Class Initialized
INFO - 2024-02-23 13:42:01 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:42:01 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:42:01 --> Utf8 Class Initialized
INFO - 2024-02-23 13:42:01 --> URI Class Initialized
INFO - 2024-02-23 13:42:01 --> Router Class Initialized
INFO - 2024-02-23 13:42:01 --> Output Class Initialized
INFO - 2024-02-23 13:42:01 --> Security Class Initialized
DEBUG - 2024-02-23 13:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:42:01 --> Input Class Initialized
INFO - 2024-02-23 13:42:01 --> Language Class Initialized
INFO - 2024-02-23 13:42:01 --> Loader Class Initialized
INFO - 2024-02-23 13:42:01 --> Helper loaded: url_helper
INFO - 2024-02-23 13:42:01 --> Helper loaded: file_helper
INFO - 2024-02-23 13:42:01 --> Helper loaded: form_helper
INFO - 2024-02-23 13:42:01 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:42:01 --> Controller Class Initialized
INFO - 2024-02-23 13:42:01 --> Form Validation Class Initialized
INFO - 2024-02-23 13:42:01 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:42:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:42:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:42:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:42:01 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:42:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:42:20 --> Config Class Initialized
INFO - 2024-02-23 13:42:20 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:42:20 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:42:20 --> Utf8 Class Initialized
INFO - 2024-02-23 13:42:20 --> URI Class Initialized
INFO - 2024-02-23 13:42:20 --> Router Class Initialized
INFO - 2024-02-23 13:42:20 --> Output Class Initialized
INFO - 2024-02-23 13:42:20 --> Security Class Initialized
DEBUG - 2024-02-23 13:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:42:20 --> Input Class Initialized
INFO - 2024-02-23 13:42:20 --> Language Class Initialized
INFO - 2024-02-23 13:42:20 --> Loader Class Initialized
INFO - 2024-02-23 13:42:20 --> Helper loaded: url_helper
INFO - 2024-02-23 13:42:20 --> Helper loaded: file_helper
INFO - 2024-02-23 13:42:20 --> Helper loaded: form_helper
INFO - 2024-02-23 13:42:20 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:42:20 --> Controller Class Initialized
INFO - 2024-02-23 13:42:20 --> Form Validation Class Initialized
INFO - 2024-02-23 13:42:20 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:42:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:42:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:42:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:42:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:42:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:42:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:42:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:42:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:42:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:42:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:42:20 --> Final output sent to browser
DEBUG - 2024-02-23 13:42:20 --> Total execution time: 0.0362
ERROR - 2024-02-23 13:42:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:42:20 --> Config Class Initialized
INFO - 2024-02-23 13:42:20 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:42:20 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:42:20 --> Utf8 Class Initialized
INFO - 2024-02-23 13:42:20 --> URI Class Initialized
INFO - 2024-02-23 13:42:20 --> Router Class Initialized
INFO - 2024-02-23 13:42:20 --> Output Class Initialized
INFO - 2024-02-23 13:42:20 --> Security Class Initialized
DEBUG - 2024-02-23 13:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:42:20 --> Input Class Initialized
INFO - 2024-02-23 13:42:20 --> Language Class Initialized
INFO - 2024-02-23 13:42:20 --> Loader Class Initialized
INFO - 2024-02-23 13:42:20 --> Helper loaded: url_helper
INFO - 2024-02-23 13:42:20 --> Helper loaded: file_helper
INFO - 2024-02-23 13:42:20 --> Helper loaded: form_helper
INFO - 2024-02-23 13:42:20 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:42:20 --> Controller Class Initialized
INFO - 2024-02-23 13:42:20 --> Form Validation Class Initialized
INFO - 2024-02-23 13:42:20 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:42:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:42:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:42:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:42:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:42:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:42:36 --> Config Class Initialized
INFO - 2024-02-23 13:42:36 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:42:36 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:42:36 --> Utf8 Class Initialized
INFO - 2024-02-23 13:42:36 --> URI Class Initialized
INFO - 2024-02-23 13:42:36 --> Router Class Initialized
INFO - 2024-02-23 13:42:36 --> Output Class Initialized
INFO - 2024-02-23 13:42:36 --> Security Class Initialized
DEBUG - 2024-02-23 13:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:42:36 --> Input Class Initialized
INFO - 2024-02-23 13:42:36 --> Language Class Initialized
INFO - 2024-02-23 13:42:36 --> Loader Class Initialized
INFO - 2024-02-23 13:42:36 --> Helper loaded: url_helper
INFO - 2024-02-23 13:42:36 --> Helper loaded: file_helper
INFO - 2024-02-23 13:42:36 --> Helper loaded: form_helper
INFO - 2024-02-23 13:42:36 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:42:36 --> Controller Class Initialized
INFO - 2024-02-23 13:42:36 --> Form Validation Class Initialized
INFO - 2024-02-23 13:42:36 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:42:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:42:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:42:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:42:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:42:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:42:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:42:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:42:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:42:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:42:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:42:36 --> Final output sent to browser
DEBUG - 2024-02-23 13:42:36 --> Total execution time: 0.0451
ERROR - 2024-02-23 13:42:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:42:36 --> Config Class Initialized
INFO - 2024-02-23 13:42:36 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:42:36 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:42:36 --> Utf8 Class Initialized
INFO - 2024-02-23 13:42:36 --> URI Class Initialized
INFO - 2024-02-23 13:42:36 --> Router Class Initialized
INFO - 2024-02-23 13:42:36 --> Output Class Initialized
INFO - 2024-02-23 13:42:36 --> Security Class Initialized
DEBUG - 2024-02-23 13:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:42:36 --> Input Class Initialized
INFO - 2024-02-23 13:42:36 --> Language Class Initialized
INFO - 2024-02-23 13:42:36 --> Loader Class Initialized
INFO - 2024-02-23 13:42:36 --> Helper loaded: url_helper
INFO - 2024-02-23 13:42:36 --> Helper loaded: file_helper
INFO - 2024-02-23 13:42:36 --> Helper loaded: form_helper
INFO - 2024-02-23 13:42:36 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:42:36 --> Controller Class Initialized
INFO - 2024-02-23 13:42:36 --> Form Validation Class Initialized
INFO - 2024-02-23 13:42:36 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:42:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:42:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:42:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:42:36 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:42:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:42:46 --> Config Class Initialized
INFO - 2024-02-23 13:42:46 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:42:46 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:42:46 --> Utf8 Class Initialized
INFO - 2024-02-23 13:42:46 --> URI Class Initialized
INFO - 2024-02-23 13:42:46 --> Router Class Initialized
INFO - 2024-02-23 13:42:46 --> Output Class Initialized
INFO - 2024-02-23 13:42:46 --> Security Class Initialized
DEBUG - 2024-02-23 13:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:42:46 --> Input Class Initialized
INFO - 2024-02-23 13:42:46 --> Language Class Initialized
INFO - 2024-02-23 13:42:46 --> Loader Class Initialized
INFO - 2024-02-23 13:42:46 --> Helper loaded: url_helper
INFO - 2024-02-23 13:42:46 --> Helper loaded: file_helper
INFO - 2024-02-23 13:42:46 --> Helper loaded: form_helper
INFO - 2024-02-23 13:42:46 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:42:46 --> Controller Class Initialized
INFO - 2024-02-23 13:42:46 --> Form Validation Class Initialized
INFO - 2024-02-23 13:42:46 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:42:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:42:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:42:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:42:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:42:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:42:46 --> Final output sent to browser
DEBUG - 2024-02-23 13:42:46 --> Total execution time: 0.0407
ERROR - 2024-02-23 13:42:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:42:46 --> Config Class Initialized
INFO - 2024-02-23 13:42:46 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:42:46 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:42:46 --> Utf8 Class Initialized
INFO - 2024-02-23 13:42:46 --> URI Class Initialized
INFO - 2024-02-23 13:42:46 --> Router Class Initialized
INFO - 2024-02-23 13:42:46 --> Output Class Initialized
INFO - 2024-02-23 13:42:46 --> Security Class Initialized
DEBUG - 2024-02-23 13:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:42:46 --> Input Class Initialized
INFO - 2024-02-23 13:42:46 --> Language Class Initialized
INFO - 2024-02-23 13:42:46 --> Loader Class Initialized
INFO - 2024-02-23 13:42:46 --> Helper loaded: url_helper
INFO - 2024-02-23 13:42:46 --> Helper loaded: file_helper
INFO - 2024-02-23 13:42:46 --> Helper loaded: form_helper
INFO - 2024-02-23 13:42:46 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:42:46 --> Controller Class Initialized
INFO - 2024-02-23 13:42:46 --> Form Validation Class Initialized
INFO - 2024-02-23 13:42:46 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:42:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:42:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:42:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:42:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:42:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:42:52 --> Config Class Initialized
INFO - 2024-02-23 13:42:52 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:42:52 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:42:52 --> Utf8 Class Initialized
INFO - 2024-02-23 13:42:52 --> URI Class Initialized
INFO - 2024-02-23 13:42:52 --> Router Class Initialized
INFO - 2024-02-23 13:42:52 --> Output Class Initialized
INFO - 2024-02-23 13:42:52 --> Security Class Initialized
DEBUG - 2024-02-23 13:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:42:52 --> Input Class Initialized
INFO - 2024-02-23 13:42:52 --> Language Class Initialized
INFO - 2024-02-23 13:42:52 --> Loader Class Initialized
INFO - 2024-02-23 13:42:52 --> Helper loaded: url_helper
INFO - 2024-02-23 13:42:52 --> Helper loaded: file_helper
INFO - 2024-02-23 13:42:52 --> Helper loaded: form_helper
INFO - 2024-02-23 13:42:52 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:42:52 --> Controller Class Initialized
INFO - 2024-02-23 13:42:52 --> Form Validation Class Initialized
INFO - 2024-02-23 13:42:52 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:42:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:42:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:42:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:42:52 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:42:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:42:56 --> Config Class Initialized
INFO - 2024-02-23 13:42:56 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:42:56 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:42:56 --> Utf8 Class Initialized
INFO - 2024-02-23 13:42:56 --> URI Class Initialized
INFO - 2024-02-23 13:42:56 --> Router Class Initialized
INFO - 2024-02-23 13:42:56 --> Output Class Initialized
INFO - 2024-02-23 13:42:56 --> Security Class Initialized
DEBUG - 2024-02-23 13:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:42:56 --> Input Class Initialized
INFO - 2024-02-23 13:42:56 --> Language Class Initialized
INFO - 2024-02-23 13:42:56 --> Loader Class Initialized
INFO - 2024-02-23 13:42:56 --> Helper loaded: url_helper
INFO - 2024-02-23 13:42:56 --> Helper loaded: file_helper
INFO - 2024-02-23 13:42:56 --> Helper loaded: form_helper
INFO - 2024-02-23 13:42:56 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:42:56 --> Controller Class Initialized
INFO - 2024-02-23 13:42:56 --> Form Validation Class Initialized
INFO - 2024-02-23 13:42:56 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:42:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:42:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:42:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:42:56 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:43:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:43:22 --> Config Class Initialized
INFO - 2024-02-23 13:43:22 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:43:22 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:43:22 --> Utf8 Class Initialized
INFO - 2024-02-23 13:43:22 --> URI Class Initialized
INFO - 2024-02-23 13:43:22 --> Router Class Initialized
INFO - 2024-02-23 13:43:22 --> Output Class Initialized
INFO - 2024-02-23 13:43:22 --> Security Class Initialized
DEBUG - 2024-02-23 13:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:43:22 --> Input Class Initialized
INFO - 2024-02-23 13:43:22 --> Language Class Initialized
INFO - 2024-02-23 13:43:22 --> Loader Class Initialized
INFO - 2024-02-23 13:43:22 --> Helper loaded: url_helper
INFO - 2024-02-23 13:43:22 --> Helper loaded: file_helper
INFO - 2024-02-23 13:43:22 --> Helper loaded: form_helper
INFO - 2024-02-23 13:43:22 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:43:22 --> Controller Class Initialized
INFO - 2024-02-23 13:43:22 --> Form Validation Class Initialized
INFO - 2024-02-23 13:43:22 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:43:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:43:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:43:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:43:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:43:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:43:22 --> Final output sent to browser
DEBUG - 2024-02-23 13:43:22 --> Total execution time: 0.0339
ERROR - 2024-02-23 13:43:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:43:22 --> Config Class Initialized
INFO - 2024-02-23 13:43:22 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:43:22 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:43:22 --> Utf8 Class Initialized
INFO - 2024-02-23 13:43:22 --> URI Class Initialized
INFO - 2024-02-23 13:43:22 --> Router Class Initialized
INFO - 2024-02-23 13:43:22 --> Output Class Initialized
INFO - 2024-02-23 13:43:22 --> Security Class Initialized
DEBUG - 2024-02-23 13:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:43:22 --> Input Class Initialized
INFO - 2024-02-23 13:43:22 --> Language Class Initialized
INFO - 2024-02-23 13:43:22 --> Loader Class Initialized
INFO - 2024-02-23 13:43:22 --> Helper loaded: url_helper
INFO - 2024-02-23 13:43:22 --> Helper loaded: file_helper
INFO - 2024-02-23 13:43:22 --> Helper loaded: form_helper
INFO - 2024-02-23 13:43:22 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:43:22 --> Controller Class Initialized
INFO - 2024-02-23 13:43:22 --> Form Validation Class Initialized
INFO - 2024-02-23 13:43:22 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:43:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:43:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:43:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:43:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:43:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:43:36 --> Config Class Initialized
INFO - 2024-02-23 13:43:36 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:43:36 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:43:36 --> Utf8 Class Initialized
INFO - 2024-02-23 13:43:36 --> URI Class Initialized
INFO - 2024-02-23 13:43:36 --> Router Class Initialized
INFO - 2024-02-23 13:43:36 --> Output Class Initialized
INFO - 2024-02-23 13:43:36 --> Security Class Initialized
DEBUG - 2024-02-23 13:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:43:36 --> Input Class Initialized
INFO - 2024-02-23 13:43:36 --> Language Class Initialized
INFO - 2024-02-23 13:43:36 --> Loader Class Initialized
INFO - 2024-02-23 13:43:36 --> Helper loaded: url_helper
INFO - 2024-02-23 13:43:36 --> Helper loaded: file_helper
INFO - 2024-02-23 13:43:36 --> Helper loaded: form_helper
INFO - 2024-02-23 13:43:36 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:43:36 --> Controller Class Initialized
INFO - 2024-02-23 13:43:36 --> Form Validation Class Initialized
INFO - 2024-02-23 13:43:36 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:43:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:43:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:43:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:43:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:43:36 --> Final output sent to browser
DEBUG - 2024-02-23 13:43:36 --> Total execution time: 0.0331
ERROR - 2024-02-23 13:43:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:43:37 --> Config Class Initialized
INFO - 2024-02-23 13:43:37 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:43:37 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:43:37 --> Utf8 Class Initialized
INFO - 2024-02-23 13:43:37 --> URI Class Initialized
INFO - 2024-02-23 13:43:37 --> Router Class Initialized
INFO - 2024-02-23 13:43:37 --> Output Class Initialized
INFO - 2024-02-23 13:43:37 --> Security Class Initialized
DEBUG - 2024-02-23 13:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:43:37 --> Input Class Initialized
INFO - 2024-02-23 13:43:37 --> Language Class Initialized
INFO - 2024-02-23 13:43:37 --> Loader Class Initialized
INFO - 2024-02-23 13:43:37 --> Helper loaded: url_helper
INFO - 2024-02-23 13:43:37 --> Helper loaded: file_helper
INFO - 2024-02-23 13:43:37 --> Helper loaded: form_helper
INFO - 2024-02-23 13:43:37 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:43:37 --> Controller Class Initialized
INFO - 2024-02-23 13:43:37 --> Form Validation Class Initialized
INFO - 2024-02-23 13:43:37 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:43:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:43:37 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:43:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:43:37 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:43:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:43:41 --> Config Class Initialized
INFO - 2024-02-23 13:43:41 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:43:41 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:43:41 --> Utf8 Class Initialized
INFO - 2024-02-23 13:43:41 --> URI Class Initialized
INFO - 2024-02-23 13:43:41 --> Router Class Initialized
INFO - 2024-02-23 13:43:41 --> Output Class Initialized
INFO - 2024-02-23 13:43:41 --> Security Class Initialized
DEBUG - 2024-02-23 13:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:43:41 --> Input Class Initialized
INFO - 2024-02-23 13:43:41 --> Language Class Initialized
INFO - 2024-02-23 13:43:41 --> Loader Class Initialized
INFO - 2024-02-23 13:43:41 --> Helper loaded: url_helper
INFO - 2024-02-23 13:43:41 --> Helper loaded: file_helper
INFO - 2024-02-23 13:43:41 --> Helper loaded: form_helper
INFO - 2024-02-23 13:43:41 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:43:41 --> Controller Class Initialized
INFO - 2024-02-23 13:43:41 --> Form Validation Class Initialized
INFO - 2024-02-23 13:43:41 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:43:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:43:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:43:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:43:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:44:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:44:16 --> Config Class Initialized
INFO - 2024-02-23 13:44:16 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:44:16 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:44:16 --> Utf8 Class Initialized
INFO - 2024-02-23 13:44:16 --> URI Class Initialized
INFO - 2024-02-23 13:44:16 --> Router Class Initialized
INFO - 2024-02-23 13:44:16 --> Output Class Initialized
INFO - 2024-02-23 13:44:16 --> Security Class Initialized
DEBUG - 2024-02-23 13:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:44:16 --> Input Class Initialized
INFO - 2024-02-23 13:44:16 --> Language Class Initialized
INFO - 2024-02-23 13:44:16 --> Loader Class Initialized
INFO - 2024-02-23 13:44:16 --> Helper loaded: url_helper
INFO - 2024-02-23 13:44:16 --> Helper loaded: file_helper
INFO - 2024-02-23 13:44:16 --> Helper loaded: form_helper
INFO - 2024-02-23 13:44:16 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:44:16 --> Controller Class Initialized
INFO - 2024-02-23 13:44:16 --> Form Validation Class Initialized
INFO - 2024-02-23 13:44:16 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:44:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:44:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:44:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:44:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:44:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:44:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:44:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:44:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:44:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:44:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:44:16 --> Final output sent to browser
DEBUG - 2024-02-23 13:44:16 --> Total execution time: 0.0391
ERROR - 2024-02-23 13:44:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:44:17 --> Config Class Initialized
INFO - 2024-02-23 13:44:17 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:44:17 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:44:17 --> Utf8 Class Initialized
INFO - 2024-02-23 13:44:17 --> URI Class Initialized
INFO - 2024-02-23 13:44:17 --> Router Class Initialized
INFO - 2024-02-23 13:44:17 --> Output Class Initialized
INFO - 2024-02-23 13:44:17 --> Security Class Initialized
DEBUG - 2024-02-23 13:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:44:17 --> Input Class Initialized
INFO - 2024-02-23 13:44:17 --> Language Class Initialized
INFO - 2024-02-23 13:44:17 --> Loader Class Initialized
INFO - 2024-02-23 13:44:17 --> Helper loaded: url_helper
INFO - 2024-02-23 13:44:17 --> Helper loaded: file_helper
INFO - 2024-02-23 13:44:17 --> Helper loaded: form_helper
INFO - 2024-02-23 13:44:17 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:44:17 --> Controller Class Initialized
INFO - 2024-02-23 13:44:17 --> Form Validation Class Initialized
INFO - 2024-02-23 13:44:17 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:44:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:44:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:44:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:44:17 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:44:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:44:19 --> Config Class Initialized
INFO - 2024-02-23 13:44:19 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:44:19 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:44:19 --> Utf8 Class Initialized
INFO - 2024-02-23 13:44:19 --> URI Class Initialized
INFO - 2024-02-23 13:44:19 --> Router Class Initialized
INFO - 2024-02-23 13:44:19 --> Output Class Initialized
INFO - 2024-02-23 13:44:19 --> Security Class Initialized
DEBUG - 2024-02-23 13:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:44:19 --> Input Class Initialized
INFO - 2024-02-23 13:44:19 --> Language Class Initialized
INFO - 2024-02-23 13:44:19 --> Loader Class Initialized
INFO - 2024-02-23 13:44:19 --> Helper loaded: url_helper
INFO - 2024-02-23 13:44:19 --> Helper loaded: file_helper
INFO - 2024-02-23 13:44:19 --> Helper loaded: form_helper
INFO - 2024-02-23 13:44:19 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:44:19 --> Controller Class Initialized
INFO - 2024-02-23 13:44:19 --> Form Validation Class Initialized
INFO - 2024-02-23 13:44:19 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:44:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:44:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:44:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:44:19 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:44:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:44:59 --> Config Class Initialized
INFO - 2024-02-23 13:44:59 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:44:59 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:44:59 --> Utf8 Class Initialized
INFO - 2024-02-23 13:44:59 --> URI Class Initialized
INFO - 2024-02-23 13:44:59 --> Router Class Initialized
INFO - 2024-02-23 13:44:59 --> Output Class Initialized
INFO - 2024-02-23 13:44:59 --> Security Class Initialized
DEBUG - 2024-02-23 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:44:59 --> Input Class Initialized
INFO - 2024-02-23 13:44:59 --> Language Class Initialized
INFO - 2024-02-23 13:44:59 --> Loader Class Initialized
INFO - 2024-02-23 13:44:59 --> Helper loaded: url_helper
INFO - 2024-02-23 13:44:59 --> Helper loaded: file_helper
INFO - 2024-02-23 13:44:59 --> Helper loaded: form_helper
INFO - 2024-02-23 13:44:59 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:44:59 --> Controller Class Initialized
INFO - 2024-02-23 13:44:59 --> Form Validation Class Initialized
INFO - 2024-02-23 13:44:59 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:44:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:44:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:44:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:44:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:44:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:44:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:44:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:44:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:44:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:44:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:44:59 --> Final output sent to browser
DEBUG - 2024-02-23 13:44:59 --> Total execution time: 0.0299
ERROR - 2024-02-23 13:44:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:44:59 --> Config Class Initialized
INFO - 2024-02-23 13:44:59 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:44:59 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:44:59 --> Utf8 Class Initialized
INFO - 2024-02-23 13:44:59 --> URI Class Initialized
INFO - 2024-02-23 13:44:59 --> Router Class Initialized
INFO - 2024-02-23 13:44:59 --> Output Class Initialized
INFO - 2024-02-23 13:44:59 --> Security Class Initialized
DEBUG - 2024-02-23 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:44:59 --> Input Class Initialized
INFO - 2024-02-23 13:44:59 --> Language Class Initialized
INFO - 2024-02-23 13:44:59 --> Loader Class Initialized
INFO - 2024-02-23 13:44:59 --> Helper loaded: url_helper
INFO - 2024-02-23 13:44:59 --> Helper loaded: file_helper
INFO - 2024-02-23 13:44:59 --> Helper loaded: form_helper
INFO - 2024-02-23 13:44:59 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:44:59 --> Controller Class Initialized
INFO - 2024-02-23 13:44:59 --> Form Validation Class Initialized
INFO - 2024-02-23 13:44:59 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:44:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:44:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:44:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:44:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:45:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:45:05 --> Config Class Initialized
INFO - 2024-02-23 13:45:05 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:45:05 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:45:05 --> Utf8 Class Initialized
INFO - 2024-02-23 13:45:05 --> URI Class Initialized
INFO - 2024-02-23 13:45:05 --> Router Class Initialized
INFO - 2024-02-23 13:45:05 --> Output Class Initialized
INFO - 2024-02-23 13:45:05 --> Security Class Initialized
DEBUG - 2024-02-23 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:45:05 --> Input Class Initialized
INFO - 2024-02-23 13:45:05 --> Language Class Initialized
INFO - 2024-02-23 13:45:05 --> Loader Class Initialized
INFO - 2024-02-23 13:45:05 --> Helper loaded: url_helper
INFO - 2024-02-23 13:45:05 --> Helper loaded: file_helper
INFO - 2024-02-23 13:45:05 --> Helper loaded: form_helper
INFO - 2024-02-23 13:45:05 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:45:05 --> Controller Class Initialized
INFO - 2024-02-23 13:45:05 --> Form Validation Class Initialized
INFO - 2024-02-23 13:45:05 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:45:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:45:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:45:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:45:05 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:45:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:45:10 --> Config Class Initialized
INFO - 2024-02-23 13:45:10 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:45:10 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:45:10 --> Utf8 Class Initialized
INFO - 2024-02-23 13:45:10 --> URI Class Initialized
INFO - 2024-02-23 13:45:10 --> Router Class Initialized
INFO - 2024-02-23 13:45:10 --> Output Class Initialized
INFO - 2024-02-23 13:45:10 --> Security Class Initialized
DEBUG - 2024-02-23 13:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:45:10 --> Input Class Initialized
INFO - 2024-02-23 13:45:10 --> Language Class Initialized
INFO - 2024-02-23 13:45:10 --> Loader Class Initialized
INFO - 2024-02-23 13:45:10 --> Helper loaded: url_helper
INFO - 2024-02-23 13:45:10 --> Helper loaded: file_helper
INFO - 2024-02-23 13:45:10 --> Helper loaded: form_helper
INFO - 2024-02-23 13:45:10 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:45:10 --> Controller Class Initialized
INFO - 2024-02-23 13:45:10 --> Form Validation Class Initialized
INFO - 2024-02-23 13:45:10 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:45:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:45:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:45:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:45:10 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:45:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:45:13 --> Config Class Initialized
INFO - 2024-02-23 13:45:13 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:45:13 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:45:13 --> Utf8 Class Initialized
INFO - 2024-02-23 13:45:13 --> URI Class Initialized
INFO - 2024-02-23 13:45:13 --> Router Class Initialized
INFO - 2024-02-23 13:45:13 --> Output Class Initialized
INFO - 2024-02-23 13:45:13 --> Security Class Initialized
DEBUG - 2024-02-23 13:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:45:13 --> Input Class Initialized
INFO - 2024-02-23 13:45:13 --> Language Class Initialized
INFO - 2024-02-23 13:45:13 --> Loader Class Initialized
INFO - 2024-02-23 13:45:13 --> Helper loaded: url_helper
INFO - 2024-02-23 13:45:13 --> Helper loaded: file_helper
INFO - 2024-02-23 13:45:13 --> Helper loaded: form_helper
INFO - 2024-02-23 13:45:13 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:45:13 --> Controller Class Initialized
INFO - 2024-02-23 13:45:13 --> Form Validation Class Initialized
INFO - 2024-02-23 13:45:13 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:45:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:45:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:45:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:45:13 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:45:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:45:22 --> Config Class Initialized
INFO - 2024-02-23 13:45:22 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:45:22 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:45:22 --> Utf8 Class Initialized
INFO - 2024-02-23 13:45:22 --> URI Class Initialized
INFO - 2024-02-23 13:45:22 --> Router Class Initialized
INFO - 2024-02-23 13:45:22 --> Output Class Initialized
INFO - 2024-02-23 13:45:22 --> Security Class Initialized
DEBUG - 2024-02-23 13:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:45:22 --> Input Class Initialized
INFO - 2024-02-23 13:45:22 --> Language Class Initialized
INFO - 2024-02-23 13:45:22 --> Loader Class Initialized
INFO - 2024-02-23 13:45:22 --> Helper loaded: url_helper
INFO - 2024-02-23 13:45:22 --> Helper loaded: file_helper
INFO - 2024-02-23 13:45:22 --> Helper loaded: form_helper
INFO - 2024-02-23 13:45:22 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:45:22 --> Controller Class Initialized
INFO - 2024-02-23 13:45:22 --> Form Validation Class Initialized
INFO - 2024-02-23 13:45:22 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:45:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:45:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:45:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:45:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:45:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:45:27 --> Config Class Initialized
INFO - 2024-02-23 13:45:27 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:45:27 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:45:27 --> Utf8 Class Initialized
INFO - 2024-02-23 13:45:27 --> URI Class Initialized
INFO - 2024-02-23 13:45:27 --> Router Class Initialized
INFO - 2024-02-23 13:45:27 --> Output Class Initialized
INFO - 2024-02-23 13:45:27 --> Security Class Initialized
DEBUG - 2024-02-23 13:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:45:27 --> Input Class Initialized
INFO - 2024-02-23 13:45:27 --> Language Class Initialized
INFO - 2024-02-23 13:45:27 --> Loader Class Initialized
INFO - 2024-02-23 13:45:27 --> Helper loaded: url_helper
INFO - 2024-02-23 13:45:27 --> Helper loaded: file_helper
INFO - 2024-02-23 13:45:27 --> Helper loaded: form_helper
INFO - 2024-02-23 13:45:27 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:45:27 --> Controller Class Initialized
INFO - 2024-02-23 13:45:27 --> Form Validation Class Initialized
INFO - 2024-02-23 13:45:27 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:45:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:45:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:45:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:45:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:46:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:46:22 --> Config Class Initialized
INFO - 2024-02-23 13:46:22 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:46:22 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:46:22 --> Utf8 Class Initialized
INFO - 2024-02-23 13:46:22 --> URI Class Initialized
INFO - 2024-02-23 13:46:22 --> Router Class Initialized
INFO - 2024-02-23 13:46:22 --> Output Class Initialized
INFO - 2024-02-23 13:46:22 --> Security Class Initialized
DEBUG - 2024-02-23 13:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:46:22 --> Input Class Initialized
INFO - 2024-02-23 13:46:22 --> Language Class Initialized
INFO - 2024-02-23 13:46:22 --> Loader Class Initialized
INFO - 2024-02-23 13:46:22 --> Helper loaded: url_helper
INFO - 2024-02-23 13:46:22 --> Helper loaded: file_helper
INFO - 2024-02-23 13:46:22 --> Helper loaded: form_helper
INFO - 2024-02-23 13:46:22 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:46:22 --> Controller Class Initialized
INFO - 2024-02-23 13:46:22 --> Form Validation Class Initialized
INFO - 2024-02-23 13:46:22 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:46:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:46:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:46:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:46:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 13:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 13:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 13:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 13:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 13:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 13:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 13:46:22 --> Final output sent to browser
DEBUG - 2024-02-23 13:46:22 --> Total execution time: 0.0245
ERROR - 2024-02-23 13:46:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:46:22 --> Config Class Initialized
INFO - 2024-02-23 13:46:22 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:46:22 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:46:22 --> Utf8 Class Initialized
INFO - 2024-02-23 13:46:22 --> URI Class Initialized
INFO - 2024-02-23 13:46:22 --> Router Class Initialized
INFO - 2024-02-23 13:46:22 --> Output Class Initialized
INFO - 2024-02-23 13:46:22 --> Security Class Initialized
DEBUG - 2024-02-23 13:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:46:22 --> Input Class Initialized
INFO - 2024-02-23 13:46:22 --> Language Class Initialized
INFO - 2024-02-23 13:46:22 --> Loader Class Initialized
INFO - 2024-02-23 13:46:22 --> Helper loaded: url_helper
INFO - 2024-02-23 13:46:22 --> Helper loaded: file_helper
INFO - 2024-02-23 13:46:22 --> Helper loaded: form_helper
INFO - 2024-02-23 13:46:22 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:46:22 --> Controller Class Initialized
INFO - 2024-02-23 13:46:22 --> Form Validation Class Initialized
INFO - 2024-02-23 13:46:22 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:46:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:46:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:46:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:46:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:46:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:46:28 --> Config Class Initialized
INFO - 2024-02-23 13:46:28 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:46:28 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:46:28 --> Utf8 Class Initialized
INFO - 2024-02-23 13:46:28 --> URI Class Initialized
INFO - 2024-02-23 13:46:28 --> Router Class Initialized
INFO - 2024-02-23 13:46:28 --> Output Class Initialized
INFO - 2024-02-23 13:46:28 --> Security Class Initialized
DEBUG - 2024-02-23 13:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:46:28 --> Input Class Initialized
INFO - 2024-02-23 13:46:28 --> Language Class Initialized
INFO - 2024-02-23 13:46:28 --> Loader Class Initialized
INFO - 2024-02-23 13:46:28 --> Helper loaded: url_helper
INFO - 2024-02-23 13:46:28 --> Helper loaded: file_helper
INFO - 2024-02-23 13:46:28 --> Helper loaded: form_helper
INFO - 2024-02-23 13:46:28 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:46:28 --> Controller Class Initialized
INFO - 2024-02-23 13:46:28 --> Form Validation Class Initialized
INFO - 2024-02-23 13:46:28 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:46:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:46:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:46:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:46:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:46:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:46:32 --> Config Class Initialized
INFO - 2024-02-23 13:46:32 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:46:32 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:46:32 --> Utf8 Class Initialized
INFO - 2024-02-23 13:46:32 --> URI Class Initialized
INFO - 2024-02-23 13:46:32 --> Router Class Initialized
INFO - 2024-02-23 13:46:32 --> Output Class Initialized
INFO - 2024-02-23 13:46:32 --> Security Class Initialized
DEBUG - 2024-02-23 13:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:46:32 --> Input Class Initialized
INFO - 2024-02-23 13:46:32 --> Language Class Initialized
INFO - 2024-02-23 13:46:32 --> Loader Class Initialized
INFO - 2024-02-23 13:46:32 --> Helper loaded: url_helper
INFO - 2024-02-23 13:46:32 --> Helper loaded: file_helper
INFO - 2024-02-23 13:46:32 --> Helper loaded: form_helper
INFO - 2024-02-23 13:46:32 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:46:32 --> Controller Class Initialized
INFO - 2024-02-23 13:46:32 --> Form Validation Class Initialized
INFO - 2024-02-23 13:46:32 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:46:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:46:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:46:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:46:32 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 13:46:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 13:46:35 --> Config Class Initialized
INFO - 2024-02-23 13:46:35 --> Hooks Class Initialized
DEBUG - 2024-02-23 13:46:35 --> UTF-8 Support Enabled
INFO - 2024-02-23 13:46:35 --> Utf8 Class Initialized
INFO - 2024-02-23 13:46:35 --> URI Class Initialized
INFO - 2024-02-23 13:46:35 --> Router Class Initialized
INFO - 2024-02-23 13:46:35 --> Output Class Initialized
INFO - 2024-02-23 13:46:35 --> Security Class Initialized
DEBUG - 2024-02-23 13:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 13:46:35 --> Input Class Initialized
INFO - 2024-02-23 13:46:35 --> Language Class Initialized
INFO - 2024-02-23 13:46:35 --> Loader Class Initialized
INFO - 2024-02-23 13:46:35 --> Helper loaded: url_helper
INFO - 2024-02-23 13:46:35 --> Helper loaded: file_helper
INFO - 2024-02-23 13:46:35 --> Helper loaded: form_helper
INFO - 2024-02-23 13:46:35 --> Database Driver Class Initialized
DEBUG - 2024-02-23 13:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 13:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 13:46:35 --> Controller Class Initialized
INFO - 2024-02-23 13:46:35 --> Form Validation Class Initialized
INFO - 2024-02-23 13:46:35 --> Model "MasterModel" initialized
INFO - 2024-02-23 13:46:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 13:46:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 13:46:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 13:46:35 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 16:05:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:05:30 --> Config Class Initialized
INFO - 2024-02-23 16:05:30 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:05:30 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:05:30 --> Utf8 Class Initialized
INFO - 2024-02-23 16:05:30 --> URI Class Initialized
INFO - 2024-02-23 16:05:30 --> Router Class Initialized
INFO - 2024-02-23 16:05:30 --> Output Class Initialized
INFO - 2024-02-23 16:05:30 --> Security Class Initialized
DEBUG - 2024-02-23 16:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:05:30 --> Input Class Initialized
INFO - 2024-02-23 16:05:30 --> Language Class Initialized
INFO - 2024-02-23 16:05:30 --> Loader Class Initialized
INFO - 2024-02-23 16:05:30 --> Helper loaded: url_helper
INFO - 2024-02-23 16:05:30 --> Helper loaded: file_helper
INFO - 2024-02-23 16:05:30 --> Helper loaded: form_helper
INFO - 2024-02-23 16:05:30 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:05:30 --> Controller Class Initialized
INFO - 2024-02-23 16:05:30 --> Form Validation Class Initialized
INFO - 2024-02-23 16:05:30 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:05:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:05:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:05:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:05:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 16:05:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 16:05:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 16:05:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 16:05:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 16:05:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 16:05:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 16:05:30 --> Final output sent to browser
DEBUG - 2024-02-23 16:05:30 --> Total execution time: 0.0287
ERROR - 2024-02-23 16:05:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:05:30 --> Config Class Initialized
INFO - 2024-02-23 16:05:30 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:05:30 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:05:30 --> Utf8 Class Initialized
INFO - 2024-02-23 16:05:30 --> URI Class Initialized
INFO - 2024-02-23 16:05:30 --> Router Class Initialized
INFO - 2024-02-23 16:05:30 --> Output Class Initialized
INFO - 2024-02-23 16:05:30 --> Security Class Initialized
DEBUG - 2024-02-23 16:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:05:30 --> Input Class Initialized
INFO - 2024-02-23 16:05:30 --> Language Class Initialized
INFO - 2024-02-23 16:05:30 --> Loader Class Initialized
INFO - 2024-02-23 16:05:30 --> Helper loaded: url_helper
INFO - 2024-02-23 16:05:30 --> Helper loaded: file_helper
INFO - 2024-02-23 16:05:30 --> Helper loaded: form_helper
INFO - 2024-02-23 16:05:30 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:05:30 --> Controller Class Initialized
INFO - 2024-02-23 16:05:30 --> Form Validation Class Initialized
INFO - 2024-02-23 16:05:30 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:05:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:05:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:05:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:05:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 16:05:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:05:33 --> Config Class Initialized
INFO - 2024-02-23 16:05:33 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:05:33 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:05:33 --> Utf8 Class Initialized
INFO - 2024-02-23 16:05:33 --> URI Class Initialized
INFO - 2024-02-23 16:05:33 --> Router Class Initialized
INFO - 2024-02-23 16:05:33 --> Output Class Initialized
INFO - 2024-02-23 16:05:33 --> Security Class Initialized
DEBUG - 2024-02-23 16:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:05:33 --> Input Class Initialized
INFO - 2024-02-23 16:05:33 --> Language Class Initialized
INFO - 2024-02-23 16:05:33 --> Loader Class Initialized
INFO - 2024-02-23 16:05:33 --> Helper loaded: url_helper
INFO - 2024-02-23 16:05:33 --> Helper loaded: file_helper
INFO - 2024-02-23 16:05:33 --> Helper loaded: form_helper
INFO - 2024-02-23 16:05:33 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:05:33 --> Controller Class Initialized
INFO - 2024-02-23 16:05:33 --> Form Validation Class Initialized
INFO - 2024-02-23 16:05:33 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:05:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:05:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:05:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:05:33 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 16:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:05:41 --> Config Class Initialized
INFO - 2024-02-23 16:05:41 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:05:41 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:05:41 --> Utf8 Class Initialized
INFO - 2024-02-23 16:05:41 --> URI Class Initialized
INFO - 2024-02-23 16:05:41 --> Router Class Initialized
INFO - 2024-02-23 16:05:41 --> Output Class Initialized
INFO - 2024-02-23 16:05:41 --> Security Class Initialized
DEBUG - 2024-02-23 16:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:05:41 --> Input Class Initialized
INFO - 2024-02-23 16:05:41 --> Language Class Initialized
INFO - 2024-02-23 16:05:41 --> Loader Class Initialized
INFO - 2024-02-23 16:05:41 --> Helper loaded: url_helper
INFO - 2024-02-23 16:05:41 --> Helper loaded: file_helper
INFO - 2024-02-23 16:05:41 --> Helper loaded: form_helper
INFO - 2024-02-23 16:05:41 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:05:41 --> Controller Class Initialized
INFO - 2024-02-23 16:05:41 --> Form Validation Class Initialized
INFO - 2024-02-23 16:05:41 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:05:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:05:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:05:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:05:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 16:05:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:05:44 --> Config Class Initialized
INFO - 2024-02-23 16:05:44 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:05:44 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:05:44 --> Utf8 Class Initialized
INFO - 2024-02-23 16:05:44 --> URI Class Initialized
INFO - 2024-02-23 16:05:44 --> Router Class Initialized
INFO - 2024-02-23 16:05:44 --> Output Class Initialized
INFO - 2024-02-23 16:05:44 --> Security Class Initialized
DEBUG - 2024-02-23 16:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:05:44 --> Input Class Initialized
INFO - 2024-02-23 16:05:44 --> Language Class Initialized
INFO - 2024-02-23 16:05:44 --> Loader Class Initialized
INFO - 2024-02-23 16:05:44 --> Helper loaded: url_helper
INFO - 2024-02-23 16:05:44 --> Helper loaded: file_helper
INFO - 2024-02-23 16:05:44 --> Helper loaded: form_helper
INFO - 2024-02-23 16:05:44 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:05:44 --> Controller Class Initialized
INFO - 2024-02-23 16:05:44 --> Form Validation Class Initialized
INFO - 2024-02-23 16:05:44 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:05:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:05:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:05:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:05:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 16:05:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:05:50 --> Config Class Initialized
INFO - 2024-02-23 16:05:50 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:05:50 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:05:50 --> Utf8 Class Initialized
INFO - 2024-02-23 16:05:50 --> URI Class Initialized
INFO - 2024-02-23 16:05:50 --> Router Class Initialized
INFO - 2024-02-23 16:05:50 --> Output Class Initialized
INFO - 2024-02-23 16:05:50 --> Security Class Initialized
DEBUG - 2024-02-23 16:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:05:50 --> Input Class Initialized
INFO - 2024-02-23 16:05:50 --> Language Class Initialized
INFO - 2024-02-23 16:05:50 --> Loader Class Initialized
INFO - 2024-02-23 16:05:50 --> Helper loaded: url_helper
INFO - 2024-02-23 16:05:50 --> Helper loaded: file_helper
INFO - 2024-02-23 16:05:50 --> Helper loaded: form_helper
INFO - 2024-02-23 16:05:50 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:05:50 --> Controller Class Initialized
INFO - 2024-02-23 16:05:50 --> Form Validation Class Initialized
INFO - 2024-02-23 16:05:50 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:05:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:05:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:05:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:05:50 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 16:12:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:12:13 --> Config Class Initialized
INFO - 2024-02-23 16:12:13 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:12:13 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:12:13 --> Utf8 Class Initialized
INFO - 2024-02-23 16:12:13 --> URI Class Initialized
INFO - 2024-02-23 16:12:13 --> Router Class Initialized
INFO - 2024-02-23 16:12:13 --> Output Class Initialized
INFO - 2024-02-23 16:12:13 --> Security Class Initialized
DEBUG - 2024-02-23 16:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:12:13 --> Input Class Initialized
INFO - 2024-02-23 16:12:13 --> Language Class Initialized
INFO - 2024-02-23 16:12:13 --> Loader Class Initialized
INFO - 2024-02-23 16:12:13 --> Helper loaded: url_helper
INFO - 2024-02-23 16:12:13 --> Helper loaded: file_helper
INFO - 2024-02-23 16:12:13 --> Helper loaded: form_helper
INFO - 2024-02-23 16:12:13 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:12:13 --> Controller Class Initialized
INFO - 2024-02-23 16:12:13 --> Form Validation Class Initialized
INFO - 2024-02-23 16:12:13 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:12:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:12:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:12:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:12:13 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 16:12:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:12:20 --> Config Class Initialized
INFO - 2024-02-23 16:12:20 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:12:20 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:12:20 --> Utf8 Class Initialized
INFO - 2024-02-23 16:12:20 --> URI Class Initialized
INFO - 2024-02-23 16:12:20 --> Router Class Initialized
INFO - 2024-02-23 16:12:20 --> Output Class Initialized
INFO - 2024-02-23 16:12:20 --> Security Class Initialized
DEBUG - 2024-02-23 16:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:12:20 --> Input Class Initialized
INFO - 2024-02-23 16:12:20 --> Language Class Initialized
INFO - 2024-02-23 16:12:20 --> Loader Class Initialized
INFO - 2024-02-23 16:12:20 --> Helper loaded: url_helper
INFO - 2024-02-23 16:12:20 --> Helper loaded: file_helper
INFO - 2024-02-23 16:12:20 --> Helper loaded: form_helper
INFO - 2024-02-23 16:12:20 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:12:20 --> Controller Class Initialized
INFO - 2024-02-23 16:12:20 --> Form Validation Class Initialized
INFO - 2024-02-23 16:12:20 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:12:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:12:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:12:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:12:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 16:12:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:12:26 --> Config Class Initialized
INFO - 2024-02-23 16:12:26 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:12:26 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:12:26 --> Utf8 Class Initialized
INFO - 2024-02-23 16:12:26 --> URI Class Initialized
INFO - 2024-02-23 16:12:26 --> Router Class Initialized
INFO - 2024-02-23 16:12:26 --> Output Class Initialized
INFO - 2024-02-23 16:12:26 --> Security Class Initialized
DEBUG - 2024-02-23 16:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:12:26 --> Input Class Initialized
INFO - 2024-02-23 16:12:26 --> Language Class Initialized
INFO - 2024-02-23 16:12:26 --> Loader Class Initialized
INFO - 2024-02-23 16:12:26 --> Helper loaded: url_helper
INFO - 2024-02-23 16:12:26 --> Helper loaded: file_helper
INFO - 2024-02-23 16:12:26 --> Helper loaded: form_helper
INFO - 2024-02-23 16:12:26 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:12:26 --> Controller Class Initialized
INFO - 2024-02-23 16:12:26 --> Form Validation Class Initialized
INFO - 2024-02-23 16:12:26 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:12:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:12:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:12:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:12:26 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 16:12:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:12:35 --> Config Class Initialized
INFO - 2024-02-23 16:12:35 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:12:35 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:12:35 --> Utf8 Class Initialized
INFO - 2024-02-23 16:12:35 --> URI Class Initialized
INFO - 2024-02-23 16:12:35 --> Router Class Initialized
INFO - 2024-02-23 16:12:35 --> Output Class Initialized
INFO - 2024-02-23 16:12:35 --> Security Class Initialized
DEBUG - 2024-02-23 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:12:35 --> Input Class Initialized
INFO - 2024-02-23 16:12:35 --> Language Class Initialized
INFO - 2024-02-23 16:12:35 --> Loader Class Initialized
INFO - 2024-02-23 16:12:35 --> Helper loaded: url_helper
INFO - 2024-02-23 16:12:35 --> Helper loaded: file_helper
INFO - 2024-02-23 16:12:35 --> Helper loaded: form_helper
INFO - 2024-02-23 16:12:35 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:12:35 --> Controller Class Initialized
INFO - 2024-02-23 16:12:35 --> Form Validation Class Initialized
INFO - 2024-02-23 16:12:35 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:12:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:12:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:12:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:12:35 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 16:12:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:12:53 --> Config Class Initialized
INFO - 2024-02-23 16:12:53 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:12:53 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:12:53 --> Utf8 Class Initialized
INFO - 2024-02-23 16:12:53 --> URI Class Initialized
INFO - 2024-02-23 16:12:53 --> Router Class Initialized
INFO - 2024-02-23 16:12:53 --> Output Class Initialized
INFO - 2024-02-23 16:12:53 --> Security Class Initialized
DEBUG - 2024-02-23 16:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:12:53 --> Input Class Initialized
INFO - 2024-02-23 16:12:53 --> Language Class Initialized
INFO - 2024-02-23 16:12:53 --> Loader Class Initialized
INFO - 2024-02-23 16:12:53 --> Helper loaded: url_helper
INFO - 2024-02-23 16:12:53 --> Helper loaded: file_helper
INFO - 2024-02-23 16:12:53 --> Helper loaded: form_helper
INFO - 2024-02-23 16:12:53 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:12:53 --> Controller Class Initialized
INFO - 2024-02-23 16:12:53 --> Form Validation Class Initialized
INFO - 2024-02-23 16:12:53 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:12:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:12:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:12:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:12:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 16:12:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:12:54 --> Config Class Initialized
INFO - 2024-02-23 16:12:54 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:12:54 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:12:54 --> Utf8 Class Initialized
INFO - 2024-02-23 16:12:54 --> URI Class Initialized
INFO - 2024-02-23 16:12:54 --> Router Class Initialized
INFO - 2024-02-23 16:12:54 --> Output Class Initialized
INFO - 2024-02-23 16:12:54 --> Security Class Initialized
DEBUG - 2024-02-23 16:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:12:54 --> Input Class Initialized
INFO - 2024-02-23 16:12:54 --> Language Class Initialized
INFO - 2024-02-23 16:12:54 --> Loader Class Initialized
INFO - 2024-02-23 16:12:54 --> Helper loaded: url_helper
INFO - 2024-02-23 16:12:54 --> Helper loaded: file_helper
INFO - 2024-02-23 16:12:54 --> Helper loaded: form_helper
INFO - 2024-02-23 16:12:54 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:12:54 --> Controller Class Initialized
INFO - 2024-02-23 16:12:54 --> Form Validation Class Initialized
INFO - 2024-02-23 16:12:54 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:12:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:12:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:12:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:12:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 16:16:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:16:58 --> Config Class Initialized
INFO - 2024-02-23 16:16:58 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:16:58 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:16:58 --> Utf8 Class Initialized
INFO - 2024-02-23 16:16:58 --> URI Class Initialized
INFO - 2024-02-23 16:16:58 --> Router Class Initialized
INFO - 2024-02-23 16:16:58 --> Output Class Initialized
INFO - 2024-02-23 16:16:58 --> Security Class Initialized
DEBUG - 2024-02-23 16:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:16:58 --> Input Class Initialized
INFO - 2024-02-23 16:16:58 --> Language Class Initialized
INFO - 2024-02-23 16:16:58 --> Loader Class Initialized
INFO - 2024-02-23 16:16:58 --> Helper loaded: url_helper
INFO - 2024-02-23 16:16:58 --> Helper loaded: file_helper
INFO - 2024-02-23 16:16:58 --> Helper loaded: form_helper
INFO - 2024-02-23 16:16:58 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:16:58 --> Controller Class Initialized
INFO - 2024-02-23 16:16:58 --> Form Validation Class Initialized
INFO - 2024-02-23 16:16:58 --> Model "MasterModel" initialized
INFO - 2024-02-23 16:16:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 16:16:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 16:16:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 16:16:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 16:16:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 16:16:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 16:16:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 16:16:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 16:16:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-23 16:16:58 --> Final output sent to browser
DEBUG - 2024-02-23 16:16:58 --> Total execution time: 0.0202
ERROR - 2024-02-23 16:16:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 16:16:59 --> Config Class Initialized
INFO - 2024-02-23 16:16:59 --> Hooks Class Initialized
DEBUG - 2024-02-23 16:16:59 --> UTF-8 Support Enabled
INFO - 2024-02-23 16:16:59 --> Utf8 Class Initialized
INFO - 2024-02-23 16:16:59 --> URI Class Initialized
INFO - 2024-02-23 16:16:59 --> Router Class Initialized
INFO - 2024-02-23 16:16:59 --> Output Class Initialized
INFO - 2024-02-23 16:16:59 --> Security Class Initialized
DEBUG - 2024-02-23 16:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 16:16:59 --> Input Class Initialized
INFO - 2024-02-23 16:16:59 --> Language Class Initialized
INFO - 2024-02-23 16:16:59 --> Loader Class Initialized
INFO - 2024-02-23 16:16:59 --> Helper loaded: url_helper
INFO - 2024-02-23 16:16:59 --> Helper loaded: file_helper
INFO - 2024-02-23 16:16:59 --> Helper loaded: form_helper
INFO - 2024-02-23 16:16:59 --> Database Driver Class Initialized
DEBUG - 2024-02-23 16:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 16:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 16:16:59 --> Controller Class Initialized
INFO - 2024-02-23 16:16:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-02-23 16:16:59 --> Final output sent to browser
DEBUG - 2024-02-23 16:16:59 --> Total execution time: 0.0224
ERROR - 2024-02-23 18:35:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 18:35:10 --> Config Class Initialized
INFO - 2024-02-23 18:35:10 --> Hooks Class Initialized
DEBUG - 2024-02-23 18:35:10 --> UTF-8 Support Enabled
INFO - 2024-02-23 18:35:10 --> Utf8 Class Initialized
INFO - 2024-02-23 18:35:10 --> URI Class Initialized
INFO - 2024-02-23 18:35:10 --> Router Class Initialized
INFO - 2024-02-23 18:35:10 --> Output Class Initialized
INFO - 2024-02-23 18:35:10 --> Security Class Initialized
DEBUG - 2024-02-23 18:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 18:35:10 --> Input Class Initialized
INFO - 2024-02-23 18:35:10 --> Language Class Initialized
INFO - 2024-02-23 18:35:10 --> Loader Class Initialized
INFO - 2024-02-23 18:35:10 --> Helper loaded: url_helper
INFO - 2024-02-23 18:35:10 --> Helper loaded: file_helper
INFO - 2024-02-23 18:35:10 --> Helper loaded: form_helper
INFO - 2024-02-23 18:35:10 --> Database Driver Class Initialized
DEBUG - 2024-02-23 18:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 18:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 18:35:10 --> Controller Class Initialized
INFO - 2024-02-23 18:35:10 --> Model "LoginModel" initialized
INFO - 2024-02-23 18:35:10 --> Form Validation Class Initialized
ERROR - 2024-02-23 18:35:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 18:35:10 --> Config Class Initialized
INFO - 2024-02-23 18:35:10 --> Hooks Class Initialized
DEBUG - 2024-02-23 18:35:10 --> UTF-8 Support Enabled
INFO - 2024-02-23 18:35:10 --> Utf8 Class Initialized
INFO - 2024-02-23 18:35:10 --> URI Class Initialized
INFO - 2024-02-23 18:35:10 --> Router Class Initialized
INFO - 2024-02-23 18:35:10 --> Output Class Initialized
INFO - 2024-02-23 18:35:10 --> Security Class Initialized
DEBUG - 2024-02-23 18:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 18:35:10 --> Input Class Initialized
INFO - 2024-02-23 18:35:10 --> Language Class Initialized
INFO - 2024-02-23 18:35:10 --> Loader Class Initialized
INFO - 2024-02-23 18:35:10 --> Helper loaded: url_helper
INFO - 2024-02-23 18:35:10 --> Helper loaded: file_helper
INFO - 2024-02-23 18:35:10 --> Helper loaded: form_helper
INFO - 2024-02-23 18:35:10 --> Database Driver Class Initialized
DEBUG - 2024-02-23 18:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 18:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 18:35:10 --> Controller Class Initialized
INFO - 2024-02-23 18:35:10 --> Form Validation Class Initialized
INFO - 2024-02-23 18:35:10 --> Model "MasterModel" initialized
INFO - 2024-02-23 18:35:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 18:35:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 18:35:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 18:35:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 18:35:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 18:35:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-23 18:35:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 18:35:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 18:35:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 18:35:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-23 18:35:10 --> Final output sent to browser
DEBUG - 2024-02-23 18:35:10 --> Total execution time: 0.0135
ERROR - 2024-02-23 18:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 18:35:13 --> Config Class Initialized
INFO - 2024-02-23 18:35:13 --> Hooks Class Initialized
DEBUG - 2024-02-23 18:35:13 --> UTF-8 Support Enabled
INFO - 2024-02-23 18:35:13 --> Utf8 Class Initialized
INFO - 2024-02-23 18:35:13 --> URI Class Initialized
INFO - 2024-02-23 18:35:13 --> Router Class Initialized
INFO - 2024-02-23 18:35:13 --> Output Class Initialized
INFO - 2024-02-23 18:35:13 --> Security Class Initialized
DEBUG - 2024-02-23 18:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 18:35:13 --> Input Class Initialized
INFO - 2024-02-23 18:35:13 --> Language Class Initialized
INFO - 2024-02-23 18:35:13 --> Loader Class Initialized
INFO - 2024-02-23 18:35:13 --> Helper loaded: url_helper
INFO - 2024-02-23 18:35:13 --> Helper loaded: file_helper
INFO - 2024-02-23 18:35:13 --> Helper loaded: form_helper
INFO - 2024-02-23 18:35:13 --> Database Driver Class Initialized
DEBUG - 2024-02-23 18:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 18:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 18:35:13 --> Controller Class Initialized
INFO - 2024-02-23 18:35:13 --> Form Validation Class Initialized
INFO - 2024-02-23 18:35:13 --> Model "MasterModel" initialized
INFO - 2024-02-23 18:35:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 18:35:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 18:35:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 18:35:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 18:35:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 18:35:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 18:35:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 18:35:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 18:35:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 18:35:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 18:35:13 --> Final output sent to browser
DEBUG - 2024-02-23 18:35:13 --> Total execution time: 0.0219
ERROR - 2024-02-23 18:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 18:35:13 --> Config Class Initialized
INFO - 2024-02-23 18:35:13 --> Hooks Class Initialized
DEBUG - 2024-02-23 18:35:13 --> UTF-8 Support Enabled
INFO - 2024-02-23 18:35:13 --> Utf8 Class Initialized
INFO - 2024-02-23 18:35:13 --> URI Class Initialized
INFO - 2024-02-23 18:35:13 --> Router Class Initialized
INFO - 2024-02-23 18:35:13 --> Output Class Initialized
INFO - 2024-02-23 18:35:13 --> Security Class Initialized
DEBUG - 2024-02-23 18:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 18:35:13 --> Input Class Initialized
INFO - 2024-02-23 18:35:13 --> Language Class Initialized
INFO - 2024-02-23 18:35:13 --> Loader Class Initialized
INFO - 2024-02-23 18:35:13 --> Helper loaded: url_helper
INFO - 2024-02-23 18:35:13 --> Helper loaded: file_helper
INFO - 2024-02-23 18:35:13 --> Helper loaded: form_helper
INFO - 2024-02-23 18:35:13 --> Database Driver Class Initialized
DEBUG - 2024-02-23 18:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 18:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 18:35:13 --> Controller Class Initialized
INFO - 2024-02-23 18:35:13 --> Form Validation Class Initialized
INFO - 2024-02-23 18:35:13 --> Model "MasterModel" initialized
INFO - 2024-02-23 18:35:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 18:35:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 18:35:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 18:35:13 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 18:35:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 18:35:23 --> Config Class Initialized
INFO - 2024-02-23 18:35:23 --> Hooks Class Initialized
DEBUG - 2024-02-23 18:35:23 --> UTF-8 Support Enabled
INFO - 2024-02-23 18:35:23 --> Utf8 Class Initialized
INFO - 2024-02-23 18:35:23 --> URI Class Initialized
INFO - 2024-02-23 18:35:23 --> Router Class Initialized
INFO - 2024-02-23 18:35:23 --> Output Class Initialized
INFO - 2024-02-23 18:35:23 --> Security Class Initialized
DEBUG - 2024-02-23 18:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 18:35:23 --> Input Class Initialized
INFO - 2024-02-23 18:35:23 --> Language Class Initialized
INFO - 2024-02-23 18:35:23 --> Loader Class Initialized
INFO - 2024-02-23 18:35:23 --> Helper loaded: url_helper
INFO - 2024-02-23 18:35:23 --> Helper loaded: file_helper
INFO - 2024-02-23 18:35:23 --> Helper loaded: form_helper
INFO - 2024-02-23 18:35:23 --> Database Driver Class Initialized
DEBUG - 2024-02-23 18:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 18:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 18:35:23 --> Controller Class Initialized
INFO - 2024-02-23 18:35:23 --> Form Validation Class Initialized
INFO - 2024-02-23 18:35:23 --> Model "MasterModel" initialized
INFO - 2024-02-23 18:35:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 18:35:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 18:35:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 18:35:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 18:35:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 18:35:26 --> Config Class Initialized
INFO - 2024-02-23 18:35:26 --> Hooks Class Initialized
DEBUG - 2024-02-23 18:35:26 --> UTF-8 Support Enabled
INFO - 2024-02-23 18:35:26 --> Utf8 Class Initialized
INFO - 2024-02-23 18:35:26 --> URI Class Initialized
INFO - 2024-02-23 18:35:26 --> Router Class Initialized
INFO - 2024-02-23 18:35:26 --> Output Class Initialized
INFO - 2024-02-23 18:35:26 --> Security Class Initialized
DEBUG - 2024-02-23 18:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 18:35:26 --> Input Class Initialized
INFO - 2024-02-23 18:35:26 --> Language Class Initialized
INFO - 2024-02-23 18:35:26 --> Loader Class Initialized
INFO - 2024-02-23 18:35:26 --> Helper loaded: url_helper
INFO - 2024-02-23 18:35:26 --> Helper loaded: file_helper
INFO - 2024-02-23 18:35:26 --> Helper loaded: form_helper
INFO - 2024-02-23 18:35:26 --> Database Driver Class Initialized
DEBUG - 2024-02-23 18:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 18:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 18:35:26 --> Controller Class Initialized
INFO - 2024-02-23 18:35:26 --> Form Validation Class Initialized
INFO - 2024-02-23 18:35:26 --> Model "MasterModel" initialized
INFO - 2024-02-23 18:35:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 18:35:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 18:35:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 18:35:26 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-23 18:45:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 18:45:46 --> Config Class Initialized
INFO - 2024-02-23 18:45:46 --> Hooks Class Initialized
DEBUG - 2024-02-23 18:45:46 --> UTF-8 Support Enabled
INFO - 2024-02-23 18:45:46 --> Utf8 Class Initialized
INFO - 2024-02-23 18:45:46 --> URI Class Initialized
INFO - 2024-02-23 18:45:46 --> Router Class Initialized
INFO - 2024-02-23 18:45:46 --> Output Class Initialized
INFO - 2024-02-23 18:45:46 --> Security Class Initialized
DEBUG - 2024-02-23 18:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 18:45:46 --> Input Class Initialized
INFO - 2024-02-23 18:45:46 --> Language Class Initialized
INFO - 2024-02-23 18:45:46 --> Loader Class Initialized
INFO - 2024-02-23 18:45:46 --> Helper loaded: url_helper
INFO - 2024-02-23 18:45:46 --> Helper loaded: file_helper
INFO - 2024-02-23 18:45:46 --> Helper loaded: form_helper
INFO - 2024-02-23 18:45:46 --> Database Driver Class Initialized
DEBUG - 2024-02-23 18:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 18:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 18:45:46 --> Controller Class Initialized
INFO - 2024-02-23 18:45:46 --> Form Validation Class Initialized
INFO - 2024-02-23 18:45:46 --> Model "MasterModel" initialized
INFO - 2024-02-23 18:45:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 18:45:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 18:45:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 18:45:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-23 18:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-23 18:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-23 18:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-23 18:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-23 18:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-23 18:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-23 18:45:46 --> Final output sent to browser
DEBUG - 2024-02-23 18:45:46 --> Total execution time: 0.0337
ERROR - 2024-02-23 18:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-23 18:45:47 --> Config Class Initialized
INFO - 2024-02-23 18:45:47 --> Hooks Class Initialized
DEBUG - 2024-02-23 18:45:47 --> UTF-8 Support Enabled
INFO - 2024-02-23 18:45:47 --> Utf8 Class Initialized
INFO - 2024-02-23 18:45:47 --> URI Class Initialized
INFO - 2024-02-23 18:45:47 --> Router Class Initialized
INFO - 2024-02-23 18:45:47 --> Output Class Initialized
INFO - 2024-02-23 18:45:47 --> Security Class Initialized
DEBUG - 2024-02-23 18:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-23 18:45:47 --> Input Class Initialized
INFO - 2024-02-23 18:45:47 --> Language Class Initialized
INFO - 2024-02-23 18:45:47 --> Loader Class Initialized
INFO - 2024-02-23 18:45:47 --> Helper loaded: url_helper
INFO - 2024-02-23 18:45:47 --> Helper loaded: file_helper
INFO - 2024-02-23 18:45:47 --> Helper loaded: form_helper
INFO - 2024-02-23 18:45:47 --> Database Driver Class Initialized
DEBUG - 2024-02-23 18:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-23 18:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-23 18:45:47 --> Controller Class Initialized
INFO - 2024-02-23 18:45:47 --> Form Validation Class Initialized
INFO - 2024-02-23 18:45:47 --> Model "MasterModel" initialized
INFO - 2024-02-23 18:45:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-23 18:45:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-23 18:45:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-23 18:45:47 --> Model "ItemMasterModel" initialized
