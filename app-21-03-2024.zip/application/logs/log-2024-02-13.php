<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-13 18:23:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-13 18:23:33 --> Config Class Initialized
INFO - 2024-02-13 18:23:33 --> Hooks Class Initialized
DEBUG - 2024-02-13 18:23:33 --> UTF-8 Support Enabled
INFO - 2024-02-13 18:23:33 --> Utf8 Class Initialized
INFO - 2024-02-13 18:23:33 --> URI Class Initialized
INFO - 2024-02-13 18:23:33 --> Router Class Initialized
INFO - 2024-02-13 18:23:33 --> Output Class Initialized
INFO - 2024-02-13 18:23:33 --> Security Class Initialized
DEBUG - 2024-02-13 18:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-13 18:23:33 --> Input Class Initialized
INFO - 2024-02-13 18:23:33 --> Language Class Initialized
INFO - 2024-02-13 18:23:33 --> Loader Class Initialized
INFO - 2024-02-13 18:23:33 --> Helper loaded: url_helper
INFO - 2024-02-13 18:23:33 --> Helper loaded: file_helper
INFO - 2024-02-13 18:23:33 --> Helper loaded: form_helper
INFO - 2024-02-13 18:23:33 --> Database Driver Class Initialized
DEBUG - 2024-02-13 18:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-13 18:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-13 18:23:33 --> Controller Class Initialized
INFO - 2024-02-13 18:23:33 --> Model "LoginModel" initialized
INFO - 2024-02-13 18:23:33 --> Form Validation Class Initialized
INFO - 2024-02-13 18:23:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-13 18:23:33 --> Final output sent to browser
DEBUG - 2024-02-13 18:23:33 --> Total execution time: 0.0609
