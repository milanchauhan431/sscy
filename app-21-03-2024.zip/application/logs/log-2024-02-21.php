<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-21 10:43:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 10:43:32 --> Config Class Initialized
INFO - 2024-02-21 10:43:32 --> Hooks Class Initialized
DEBUG - 2024-02-21 10:43:32 --> UTF-8 Support Enabled
INFO - 2024-02-21 10:43:32 --> Utf8 Class Initialized
INFO - 2024-02-21 10:43:32 --> URI Class Initialized
INFO - 2024-02-21 10:43:32 --> Router Class Initialized
INFO - 2024-02-21 10:43:32 --> Output Class Initialized
INFO - 2024-02-21 10:43:32 --> Security Class Initialized
DEBUG - 2024-02-21 10:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 10:43:32 --> Input Class Initialized
INFO - 2024-02-21 10:43:32 --> Language Class Initialized
INFO - 2024-02-21 10:43:32 --> Loader Class Initialized
INFO - 2024-02-21 10:43:32 --> Helper loaded: url_helper
INFO - 2024-02-21 10:43:32 --> Helper loaded: file_helper
INFO - 2024-02-21 10:43:32 --> Helper loaded: form_helper
INFO - 2024-02-21 10:43:32 --> Database Driver Class Initialized
DEBUG - 2024-02-21 10:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 10:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 10:43:32 --> Controller Class Initialized
INFO - 2024-02-21 10:43:32 --> Form Validation Class Initialized
INFO - 2024-02-21 10:43:32 --> Model "MasterModel" initialized
INFO - 2024-02-21 10:43:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 10:43:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 10:43:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 10:43:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 10:43:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 10:43:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 10:43:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 10:43:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 10:43:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 10:43:32 --> Final output sent to browser
DEBUG - 2024-02-21 10:43:32 --> Total execution time: 0.0529
ERROR - 2024-02-21 10:43:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 10:43:36 --> Config Class Initialized
INFO - 2024-02-21 10:43:36 --> Hooks Class Initialized
DEBUG - 2024-02-21 10:43:36 --> UTF-8 Support Enabled
INFO - 2024-02-21 10:43:36 --> Utf8 Class Initialized
INFO - 2024-02-21 10:43:36 --> URI Class Initialized
INFO - 2024-02-21 10:43:36 --> Router Class Initialized
INFO - 2024-02-21 10:43:36 --> Output Class Initialized
INFO - 2024-02-21 10:43:36 --> Security Class Initialized
DEBUG - 2024-02-21 10:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 10:43:36 --> Input Class Initialized
INFO - 2024-02-21 10:43:36 --> Language Class Initialized
INFO - 2024-02-21 10:43:36 --> Loader Class Initialized
INFO - 2024-02-21 10:43:36 --> Helper loaded: url_helper
INFO - 2024-02-21 10:43:36 --> Helper loaded: file_helper
INFO - 2024-02-21 10:43:36 --> Helper loaded: form_helper
INFO - 2024-02-21 10:43:36 --> Database Driver Class Initialized
DEBUG - 2024-02-21 10:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 10:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 10:43:36 --> Controller Class Initialized
INFO - 2024-02-21 10:43:36 --> Form Validation Class Initialized
INFO - 2024-02-21 10:43:36 --> Model "MasterModel" initialized
INFO - 2024-02-21 10:43:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 10:43:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 10:43:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 10:43:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 10:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 10:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 10:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 10:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 10:43:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 10:43:36 --> Final output sent to browser
DEBUG - 2024-02-21 10:43:36 --> Total execution time: 0.0430
ERROR - 2024-02-21 10:46:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 10:46:03 --> Config Class Initialized
INFO - 2024-02-21 10:46:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 10:46:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 10:46:03 --> Utf8 Class Initialized
INFO - 2024-02-21 10:46:03 --> URI Class Initialized
INFO - 2024-02-21 10:46:03 --> Router Class Initialized
INFO - 2024-02-21 10:46:03 --> Output Class Initialized
INFO - 2024-02-21 10:46:03 --> Security Class Initialized
DEBUG - 2024-02-21 10:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 10:46:03 --> Input Class Initialized
INFO - 2024-02-21 10:46:03 --> Language Class Initialized
INFO - 2024-02-21 10:46:03 --> Loader Class Initialized
INFO - 2024-02-21 10:46:03 --> Helper loaded: url_helper
INFO - 2024-02-21 10:46:03 --> Helper loaded: file_helper
INFO - 2024-02-21 10:46:03 --> Helper loaded: form_helper
INFO - 2024-02-21 10:46:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 10:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 10:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 10:46:03 --> Controller Class Initialized
INFO - 2024-02-21 10:46:03 --> Model "LoginModel" initialized
INFO - 2024-02-21 10:46:03 --> Form Validation Class Initialized
ERROR - 2024-02-21 10:46:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 10:46:03 --> Config Class Initialized
INFO - 2024-02-21 10:46:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 10:46:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 10:46:03 --> Utf8 Class Initialized
INFO - 2024-02-21 10:46:03 --> URI Class Initialized
INFO - 2024-02-21 10:46:03 --> Router Class Initialized
INFO - 2024-02-21 10:46:03 --> Output Class Initialized
INFO - 2024-02-21 10:46:03 --> Security Class Initialized
DEBUG - 2024-02-21 10:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 10:46:03 --> Input Class Initialized
INFO - 2024-02-21 10:46:03 --> Language Class Initialized
INFO - 2024-02-21 10:46:03 --> Loader Class Initialized
INFO - 2024-02-21 10:46:03 --> Helper loaded: url_helper
INFO - 2024-02-21 10:46:03 --> Helper loaded: file_helper
INFO - 2024-02-21 10:46:03 --> Helper loaded: form_helper
INFO - 2024-02-21 10:46:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 10:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 10:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 10:46:03 --> Controller Class Initialized
INFO - 2024-02-21 10:46:03 --> Form Validation Class Initialized
INFO - 2024-02-21 10:46:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 10:46:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 10:46:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 10:46:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 10:46:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 10:46:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 10:46:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-21 10:46:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 10:46:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 10:46:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 10:46:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-21 10:46:03 --> Final output sent to browser
DEBUG - 2024-02-21 10:46:03 --> Total execution time: 0.0150
ERROR - 2024-02-21 12:12:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 12:12:06 --> Config Class Initialized
INFO - 2024-02-21 12:12:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 12:12:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 12:12:06 --> Utf8 Class Initialized
INFO - 2024-02-21 12:12:06 --> URI Class Initialized
INFO - 2024-02-21 12:12:06 --> Router Class Initialized
INFO - 2024-02-21 12:12:06 --> Output Class Initialized
INFO - 2024-02-21 12:12:06 --> Security Class Initialized
DEBUG - 2024-02-21 12:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 12:12:06 --> Input Class Initialized
INFO - 2024-02-21 12:12:06 --> Language Class Initialized
INFO - 2024-02-21 12:12:06 --> Loader Class Initialized
INFO - 2024-02-21 12:12:06 --> Helper loaded: url_helper
INFO - 2024-02-21 12:12:06 --> Helper loaded: file_helper
INFO - 2024-02-21 12:12:06 --> Helper loaded: form_helper
INFO - 2024-02-21 12:12:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 12:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 12:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 12:12:06 --> Controller Class Initialized
INFO - 2024-02-21 12:12:06 --> Form Validation Class Initialized
INFO - 2024-02-21 12:12:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 12:12:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 12:12:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 12:12:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 12:12:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 12:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 12:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-21 12:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 12:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 12:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 12:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-21 12:12:06 --> Final output sent to browser
DEBUG - 2024-02-21 12:12:06 --> Total execution time: 0.0328
ERROR - 2024-02-21 12:12:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 12:12:14 --> Config Class Initialized
INFO - 2024-02-21 12:12:14 --> Hooks Class Initialized
DEBUG - 2024-02-21 12:12:14 --> UTF-8 Support Enabled
INFO - 2024-02-21 12:12:14 --> Utf8 Class Initialized
INFO - 2024-02-21 12:12:14 --> URI Class Initialized
INFO - 2024-02-21 12:12:14 --> Router Class Initialized
INFO - 2024-02-21 12:12:14 --> Output Class Initialized
INFO - 2024-02-21 12:12:14 --> Security Class Initialized
DEBUG - 2024-02-21 12:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 12:12:14 --> Input Class Initialized
INFO - 2024-02-21 12:12:14 --> Language Class Initialized
INFO - 2024-02-21 12:12:14 --> Loader Class Initialized
INFO - 2024-02-21 12:12:14 --> Helper loaded: url_helper
INFO - 2024-02-21 12:12:14 --> Helper loaded: file_helper
INFO - 2024-02-21 12:12:14 --> Helper loaded: form_helper
INFO - 2024-02-21 12:12:14 --> Database Driver Class Initialized
DEBUG - 2024-02-21 12:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 12:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 12:12:14 --> Controller Class Initialized
INFO - 2024-02-21 12:12:14 --> Form Validation Class Initialized
INFO - 2024-02-21 12:12:14 --> Model "MasterModel" initialized
INFO - 2024-02-21 12:12:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 12:12:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 12:12:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 12:12:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 12:12:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 12:12:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 12:12:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 12:12:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 12:12:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 12:12:14 --> Final output sent to browser
DEBUG - 2024-02-21 12:12:14 --> Total execution time: 0.0341
ERROR - 2024-02-21 13:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 13:10:16 --> Config Class Initialized
INFO - 2024-02-21 13:10:16 --> Hooks Class Initialized
DEBUG - 2024-02-21 13:10:16 --> UTF-8 Support Enabled
INFO - 2024-02-21 13:10:16 --> Utf8 Class Initialized
INFO - 2024-02-21 13:10:16 --> URI Class Initialized
INFO - 2024-02-21 13:10:16 --> Router Class Initialized
INFO - 2024-02-21 13:10:16 --> Output Class Initialized
INFO - 2024-02-21 13:10:16 --> Security Class Initialized
DEBUG - 2024-02-21 13:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 13:10:16 --> Input Class Initialized
INFO - 2024-02-21 13:10:16 --> Language Class Initialized
INFO - 2024-02-21 13:10:16 --> Loader Class Initialized
INFO - 2024-02-21 13:10:16 --> Helper loaded: url_helper
INFO - 2024-02-21 13:10:16 --> Helper loaded: file_helper
INFO - 2024-02-21 13:10:16 --> Helper loaded: form_helper
INFO - 2024-02-21 13:10:16 --> Database Driver Class Initialized
DEBUG - 2024-02-21 13:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 13:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 13:10:16 --> Controller Class Initialized
INFO - 2024-02-21 13:10:16 --> Form Validation Class Initialized
INFO - 2024-02-21 13:10:16 --> Model "MasterModel" initialized
INFO - 2024-02-21 13:10:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 13:10:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 13:10:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 13:10:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 13:10:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 13:10:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 13:10:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 13:10:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 13:10:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 13:10:16 --> Final output sent to browser
DEBUG - 2024-02-21 13:10:16 --> Total execution time: 0.0385
ERROR - 2024-02-21 13:10:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 13:10:38 --> Config Class Initialized
INFO - 2024-02-21 13:10:38 --> Hooks Class Initialized
DEBUG - 2024-02-21 13:10:38 --> UTF-8 Support Enabled
INFO - 2024-02-21 13:10:38 --> Utf8 Class Initialized
INFO - 2024-02-21 13:10:38 --> URI Class Initialized
INFO - 2024-02-21 13:10:38 --> Router Class Initialized
INFO - 2024-02-21 13:10:38 --> Output Class Initialized
INFO - 2024-02-21 13:10:38 --> Security Class Initialized
DEBUG - 2024-02-21 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 13:10:38 --> Input Class Initialized
INFO - 2024-02-21 13:10:38 --> Language Class Initialized
INFO - 2024-02-21 13:10:38 --> Loader Class Initialized
INFO - 2024-02-21 13:10:38 --> Helper loaded: url_helper
INFO - 2024-02-21 13:10:38 --> Helper loaded: file_helper
INFO - 2024-02-21 13:10:38 --> Helper loaded: form_helper
INFO - 2024-02-21 13:10:38 --> Database Driver Class Initialized
DEBUG - 2024-02-21 13:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 13:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 13:10:38 --> Controller Class Initialized
INFO - 2024-02-21 13:10:38 --> Form Validation Class Initialized
INFO - 2024-02-21 13:10:38 --> Model "MasterModel" initialized
INFO - 2024-02-21 13:10:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 13:10:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 13:10:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 13:10:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 13:10:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 13:10:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-21 13:10:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 13:10:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 13:10:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 13:10:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-21 13:10:38 --> Final output sent to browser
DEBUG - 2024-02-21 13:10:38 --> Total execution time: 0.0352
ERROR - 2024-02-21 13:10:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 13:10:42 --> Config Class Initialized
INFO - 2024-02-21 13:10:42 --> Hooks Class Initialized
DEBUG - 2024-02-21 13:10:42 --> UTF-8 Support Enabled
INFO - 2024-02-21 13:10:42 --> Utf8 Class Initialized
INFO - 2024-02-21 13:10:42 --> URI Class Initialized
INFO - 2024-02-21 13:10:42 --> Router Class Initialized
INFO - 2024-02-21 13:10:42 --> Output Class Initialized
INFO - 2024-02-21 13:10:42 --> Security Class Initialized
DEBUG - 2024-02-21 13:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 13:10:42 --> Input Class Initialized
INFO - 2024-02-21 13:10:42 --> Language Class Initialized
INFO - 2024-02-21 13:10:42 --> Loader Class Initialized
INFO - 2024-02-21 13:10:42 --> Helper loaded: url_helper
INFO - 2024-02-21 13:10:42 --> Helper loaded: file_helper
INFO - 2024-02-21 13:10:42 --> Helper loaded: form_helper
INFO - 2024-02-21 13:10:42 --> Database Driver Class Initialized
DEBUG - 2024-02-21 13:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 13:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 13:10:42 --> Controller Class Initialized
INFO - 2024-02-21 13:10:42 --> Form Validation Class Initialized
INFO - 2024-02-21 13:10:42 --> Model "MasterModel" initialized
INFO - 2024-02-21 13:10:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 13:10:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 13:10:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 13:10:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 13:10:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 13:10:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 13:10:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 13:10:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 13:10:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-21 13:10:42 --> Final output sent to browser
DEBUG - 2024-02-21 13:10:42 --> Total execution time: 0.0347
ERROR - 2024-02-21 13:10:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 13:10:42 --> Config Class Initialized
INFO - 2024-02-21 13:10:42 --> Hooks Class Initialized
DEBUG - 2024-02-21 13:10:42 --> UTF-8 Support Enabled
INFO - 2024-02-21 13:10:42 --> Utf8 Class Initialized
INFO - 2024-02-21 13:10:42 --> URI Class Initialized
INFO - 2024-02-21 13:10:42 --> Router Class Initialized
INFO - 2024-02-21 13:10:42 --> Output Class Initialized
INFO - 2024-02-21 13:10:42 --> Security Class Initialized
DEBUG - 2024-02-21 13:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 13:10:42 --> Input Class Initialized
INFO - 2024-02-21 13:10:42 --> Language Class Initialized
INFO - 2024-02-21 13:10:42 --> Loader Class Initialized
INFO - 2024-02-21 13:10:42 --> Helper loaded: url_helper
INFO - 2024-02-21 13:10:42 --> Helper loaded: file_helper
INFO - 2024-02-21 13:10:42 --> Helper loaded: form_helper
INFO - 2024-02-21 13:10:42 --> Database Driver Class Initialized
DEBUG - 2024-02-21 13:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 13:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 13:10:42 --> Controller Class Initialized
INFO - 2024-02-21 13:10:42 --> Form Validation Class Initialized
INFO - 2024-02-21 13:10:42 --> Model "MasterModel" initialized
INFO - 2024-02-21 13:10:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 13:10:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 13:10:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 13:10:42 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 13:10:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 13:10:47 --> Config Class Initialized
INFO - 2024-02-21 13:10:47 --> Hooks Class Initialized
DEBUG - 2024-02-21 13:10:47 --> UTF-8 Support Enabled
INFO - 2024-02-21 13:10:47 --> Utf8 Class Initialized
INFO - 2024-02-21 13:10:47 --> URI Class Initialized
INFO - 2024-02-21 13:10:47 --> Router Class Initialized
INFO - 2024-02-21 13:10:47 --> Output Class Initialized
INFO - 2024-02-21 13:10:47 --> Security Class Initialized
DEBUG - 2024-02-21 13:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 13:10:47 --> Input Class Initialized
INFO - 2024-02-21 13:10:47 --> Language Class Initialized
INFO - 2024-02-21 13:10:47 --> Loader Class Initialized
INFO - 2024-02-21 13:10:47 --> Helper loaded: url_helper
INFO - 2024-02-21 13:10:47 --> Helper loaded: file_helper
INFO - 2024-02-21 13:10:47 --> Helper loaded: form_helper
INFO - 2024-02-21 13:10:47 --> Database Driver Class Initialized
DEBUG - 2024-02-21 13:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 13:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 13:10:47 --> Controller Class Initialized
INFO - 2024-02-21 13:10:47 --> Form Validation Class Initialized
INFO - 2024-02-21 13:10:47 --> Model "MasterModel" initialized
INFO - 2024-02-21 13:10:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 13:10:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 13:10:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 13:10:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 13:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 13:10:51 --> Config Class Initialized
INFO - 2024-02-21 13:10:51 --> Hooks Class Initialized
DEBUG - 2024-02-21 13:10:51 --> UTF-8 Support Enabled
INFO - 2024-02-21 13:10:51 --> Utf8 Class Initialized
INFO - 2024-02-21 13:10:51 --> URI Class Initialized
INFO - 2024-02-21 13:10:51 --> Router Class Initialized
INFO - 2024-02-21 13:10:51 --> Output Class Initialized
INFO - 2024-02-21 13:10:51 --> Security Class Initialized
DEBUG - 2024-02-21 13:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 13:10:51 --> Input Class Initialized
INFO - 2024-02-21 13:10:51 --> Language Class Initialized
INFO - 2024-02-21 13:10:51 --> Loader Class Initialized
INFO - 2024-02-21 13:10:51 --> Helper loaded: url_helper
INFO - 2024-02-21 13:10:51 --> Helper loaded: file_helper
INFO - 2024-02-21 13:10:51 --> Helper loaded: form_helper
INFO - 2024-02-21 13:10:51 --> Database Driver Class Initialized
DEBUG - 2024-02-21 13:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 13:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 13:10:51 --> Controller Class Initialized
INFO - 2024-02-21 13:10:51 --> Form Validation Class Initialized
INFO - 2024-02-21 13:10:51 --> Model "MasterModel" initialized
INFO - 2024-02-21 13:10:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 13:10:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 13:10:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 13:10:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 13:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 13:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 13:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 13:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 13:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 13:10:51 --> Final output sent to browser
DEBUG - 2024-02-21 13:10:51 --> Total execution time: 0.0327
ERROR - 2024-02-21 15:31:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 15:31:40 --> Config Class Initialized
INFO - 2024-02-21 15:31:40 --> Hooks Class Initialized
DEBUG - 2024-02-21 15:31:40 --> UTF-8 Support Enabled
INFO - 2024-02-21 15:31:40 --> Utf8 Class Initialized
INFO - 2024-02-21 15:31:40 --> URI Class Initialized
INFO - 2024-02-21 15:31:40 --> Router Class Initialized
INFO - 2024-02-21 15:31:40 --> Output Class Initialized
INFO - 2024-02-21 15:31:40 --> Security Class Initialized
DEBUG - 2024-02-21 15:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 15:31:40 --> Input Class Initialized
INFO - 2024-02-21 15:31:40 --> Language Class Initialized
INFO - 2024-02-21 15:31:40 --> Loader Class Initialized
INFO - 2024-02-21 15:31:40 --> Helper loaded: url_helper
INFO - 2024-02-21 15:31:40 --> Helper loaded: file_helper
INFO - 2024-02-21 15:31:40 --> Helper loaded: form_helper
INFO - 2024-02-21 15:31:40 --> Database Driver Class Initialized
DEBUG - 2024-02-21 15:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 15:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 15:31:40 --> Controller Class Initialized
INFO - 2024-02-21 15:31:40 --> Model "LoginModel" initialized
INFO - 2024-02-21 15:31:40 --> Form Validation Class Initialized
INFO - 2024-02-21 15:31:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-21 15:31:40 --> Final output sent to browser
DEBUG - 2024-02-21 15:31:40 --> Total execution time: 0.0220
ERROR - 2024-02-21 19:35:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:35:15 --> Config Class Initialized
INFO - 2024-02-21 19:35:15 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:35:15 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:35:15 --> Utf8 Class Initialized
INFO - 2024-02-21 19:35:15 --> URI Class Initialized
INFO - 2024-02-21 19:35:15 --> Router Class Initialized
INFO - 2024-02-21 19:35:15 --> Output Class Initialized
INFO - 2024-02-21 19:35:15 --> Security Class Initialized
DEBUG - 2024-02-21 19:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:35:15 --> Input Class Initialized
INFO - 2024-02-21 19:35:15 --> Language Class Initialized
INFO - 2024-02-21 19:35:15 --> Loader Class Initialized
INFO - 2024-02-21 19:35:15 --> Helper loaded: url_helper
INFO - 2024-02-21 19:35:15 --> Helper loaded: file_helper
INFO - 2024-02-21 19:35:15 --> Helper loaded: form_helper
INFO - 2024-02-21 19:35:15 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:35:15 --> Controller Class Initialized
INFO - 2024-02-21 19:35:15 --> Model "LoginModel" initialized
INFO - 2024-02-21 19:35:15 --> Form Validation Class Initialized
ERROR - 2024-02-21 19:35:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:35:15 --> Config Class Initialized
INFO - 2024-02-21 19:35:15 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:35:15 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:35:15 --> Utf8 Class Initialized
INFO - 2024-02-21 19:35:15 --> URI Class Initialized
INFO - 2024-02-21 19:35:15 --> Router Class Initialized
INFO - 2024-02-21 19:35:15 --> Output Class Initialized
INFO - 2024-02-21 19:35:15 --> Security Class Initialized
DEBUG - 2024-02-21 19:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:35:15 --> Input Class Initialized
INFO - 2024-02-21 19:35:15 --> Language Class Initialized
INFO - 2024-02-21 19:35:15 --> Loader Class Initialized
INFO - 2024-02-21 19:35:15 --> Helper loaded: url_helper
INFO - 2024-02-21 19:35:15 --> Helper loaded: file_helper
INFO - 2024-02-21 19:35:15 --> Helper loaded: form_helper
INFO - 2024-02-21 19:35:15 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:35:15 --> Controller Class Initialized
INFO - 2024-02-21 19:35:15 --> Form Validation Class Initialized
INFO - 2024-02-21 19:35:15 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:35:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:35:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:35:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:35:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 19:35:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 19:35:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-21 19:35:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 19:35:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 19:35:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 19:35:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-21 19:35:15 --> Final output sent to browser
DEBUG - 2024-02-21 19:35:15 --> Total execution time: 0.0263
ERROR - 2024-02-21 19:35:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:35:17 --> Config Class Initialized
INFO - 2024-02-21 19:35:17 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:35:17 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:35:17 --> Utf8 Class Initialized
INFO - 2024-02-21 19:35:17 --> URI Class Initialized
INFO - 2024-02-21 19:35:17 --> Router Class Initialized
INFO - 2024-02-21 19:35:17 --> Output Class Initialized
INFO - 2024-02-21 19:35:17 --> Security Class Initialized
DEBUG - 2024-02-21 19:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:35:17 --> Input Class Initialized
INFO - 2024-02-21 19:35:17 --> Language Class Initialized
INFO - 2024-02-21 19:35:17 --> Loader Class Initialized
INFO - 2024-02-21 19:35:17 --> Helper loaded: url_helper
INFO - 2024-02-21 19:35:17 --> Helper loaded: file_helper
INFO - 2024-02-21 19:35:17 --> Helper loaded: form_helper
INFO - 2024-02-21 19:35:17 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:35:17 --> Controller Class Initialized
INFO - 2024-02-21 19:35:17 --> Form Validation Class Initialized
INFO - 2024-02-21 19:35:17 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:35:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:35:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:35:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:35:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 19:35:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 19:35:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 19:35:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 19:35:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 19:35:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 19:35:17 --> Final output sent to browser
DEBUG - 2024-02-21 19:35:17 --> Total execution time: 0.0377
ERROR - 2024-02-21 19:35:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:35:21 --> Config Class Initialized
INFO - 2024-02-21 19:35:21 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:35:21 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:35:21 --> Utf8 Class Initialized
INFO - 2024-02-21 19:35:21 --> URI Class Initialized
INFO - 2024-02-21 19:35:21 --> Router Class Initialized
INFO - 2024-02-21 19:35:21 --> Output Class Initialized
INFO - 2024-02-21 19:35:21 --> Security Class Initialized
DEBUG - 2024-02-21 19:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:35:21 --> Input Class Initialized
INFO - 2024-02-21 19:35:21 --> Language Class Initialized
INFO - 2024-02-21 19:35:21 --> Loader Class Initialized
INFO - 2024-02-21 19:35:21 --> Helper loaded: url_helper
INFO - 2024-02-21 19:35:21 --> Helper loaded: file_helper
INFO - 2024-02-21 19:35:21 --> Helper loaded: form_helper
INFO - 2024-02-21 19:35:21 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:35:21 --> Controller Class Initialized
INFO - 2024-02-21 19:35:21 --> Form Validation Class Initialized
INFO - 2024-02-21 19:35:21 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:35:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:35:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:35:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:35:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 19:35:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 19:35:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 19:35:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 19:35:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 19:35:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 19:35:21 --> Final output sent to browser
DEBUG - 2024-02-21 19:35:21 --> Total execution time: 0.0325
ERROR - 2024-02-21 19:35:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:35:34 --> Config Class Initialized
INFO - 2024-02-21 19:35:34 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:35:34 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:35:34 --> Utf8 Class Initialized
INFO - 2024-02-21 19:35:34 --> URI Class Initialized
INFO - 2024-02-21 19:35:34 --> Router Class Initialized
INFO - 2024-02-21 19:35:34 --> Output Class Initialized
INFO - 2024-02-21 19:35:34 --> Security Class Initialized
DEBUG - 2024-02-21 19:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:35:34 --> Input Class Initialized
INFO - 2024-02-21 19:35:34 --> Language Class Initialized
INFO - 2024-02-21 19:35:34 --> Loader Class Initialized
INFO - 2024-02-21 19:35:34 --> Helper loaded: url_helper
INFO - 2024-02-21 19:35:34 --> Helper loaded: file_helper
INFO - 2024-02-21 19:35:34 --> Helper loaded: form_helper
INFO - 2024-02-21 19:35:34 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:35:34 --> Controller Class Initialized
INFO - 2024-02-21 19:35:34 --> Form Validation Class Initialized
INFO - 2024-02-21 19:35:34 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:35:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:35:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:35:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:35:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 19:35:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 19:35:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 19:35:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 19:35:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 19:35:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 19:35:34 --> Final output sent to browser
DEBUG - 2024-02-21 19:35:34 --> Total execution time: 0.0530
ERROR - 2024-02-21 19:54:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:54:48 --> Config Class Initialized
INFO - 2024-02-21 19:54:48 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:54:48 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:54:48 --> Utf8 Class Initialized
INFO - 2024-02-21 19:54:48 --> URI Class Initialized
INFO - 2024-02-21 19:54:48 --> Router Class Initialized
INFO - 2024-02-21 19:54:48 --> Output Class Initialized
INFO - 2024-02-21 19:54:48 --> Security Class Initialized
DEBUG - 2024-02-21 19:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:54:48 --> Input Class Initialized
INFO - 2024-02-21 19:54:48 --> Language Class Initialized
INFO - 2024-02-21 19:54:48 --> Loader Class Initialized
INFO - 2024-02-21 19:54:48 --> Helper loaded: url_helper
INFO - 2024-02-21 19:54:48 --> Helper loaded: file_helper
INFO - 2024-02-21 19:54:48 --> Helper loaded: form_helper
INFO - 2024-02-21 19:54:48 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:54:48 --> Controller Class Initialized
INFO - 2024-02-21 19:54:48 --> Form Validation Class Initialized
INFO - 2024-02-21 19:54:48 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:54:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:54:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:54:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:54:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 19:54:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 19:54:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 19:54:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 19:54:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 19:54:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 19:54:48 --> Final output sent to browser
DEBUG - 2024-02-21 19:54:48 --> Total execution time: 0.0430
ERROR - 2024-02-21 19:54:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:54:49 --> Config Class Initialized
INFO - 2024-02-21 19:54:49 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:54:49 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:54:49 --> Utf8 Class Initialized
INFO - 2024-02-21 19:54:49 --> URI Class Initialized
INFO - 2024-02-21 19:54:49 --> Router Class Initialized
INFO - 2024-02-21 19:54:49 --> Output Class Initialized
INFO - 2024-02-21 19:54:49 --> Security Class Initialized
DEBUG - 2024-02-21 19:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:54:49 --> Input Class Initialized
INFO - 2024-02-21 19:54:49 --> Language Class Initialized
INFO - 2024-02-21 19:54:49 --> Loader Class Initialized
INFO - 2024-02-21 19:54:49 --> Helper loaded: url_helper
INFO - 2024-02-21 19:54:49 --> Helper loaded: file_helper
INFO - 2024-02-21 19:54:49 --> Helper loaded: form_helper
INFO - 2024-02-21 19:54:49 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:54:49 --> Controller Class Initialized
INFO - 2024-02-21 19:54:49 --> Form Validation Class Initialized
INFO - 2024-02-21 19:54:49 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:54:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:54:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:54:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:54:49 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 19:54:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:54:54 --> Config Class Initialized
INFO - 2024-02-21 19:54:54 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:54:54 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:54:54 --> Utf8 Class Initialized
INFO - 2024-02-21 19:54:54 --> URI Class Initialized
INFO - 2024-02-21 19:54:54 --> Router Class Initialized
INFO - 2024-02-21 19:54:54 --> Output Class Initialized
INFO - 2024-02-21 19:54:54 --> Security Class Initialized
DEBUG - 2024-02-21 19:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:54:54 --> Input Class Initialized
INFO - 2024-02-21 19:54:54 --> Language Class Initialized
INFO - 2024-02-21 19:54:54 --> Loader Class Initialized
INFO - 2024-02-21 19:54:54 --> Helper loaded: url_helper
INFO - 2024-02-21 19:54:54 --> Helper loaded: file_helper
INFO - 2024-02-21 19:54:54 --> Helper loaded: form_helper
INFO - 2024-02-21 19:54:54 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:54:54 --> Controller Class Initialized
INFO - 2024-02-21 19:54:54 --> Form Validation Class Initialized
INFO - 2024-02-21 19:54:54 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:54:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:54:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:54:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:54:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 19:55:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:55:22 --> Config Class Initialized
INFO - 2024-02-21 19:55:22 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:55:22 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:55:22 --> Utf8 Class Initialized
INFO - 2024-02-21 19:55:22 --> URI Class Initialized
INFO - 2024-02-21 19:55:22 --> Router Class Initialized
INFO - 2024-02-21 19:55:22 --> Output Class Initialized
INFO - 2024-02-21 19:55:22 --> Security Class Initialized
DEBUG - 2024-02-21 19:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:55:22 --> Input Class Initialized
INFO - 2024-02-21 19:55:22 --> Language Class Initialized
INFO - 2024-02-21 19:55:22 --> Loader Class Initialized
INFO - 2024-02-21 19:55:22 --> Helper loaded: url_helper
INFO - 2024-02-21 19:55:22 --> Helper loaded: file_helper
INFO - 2024-02-21 19:55:22 --> Helper loaded: form_helper
INFO - 2024-02-21 19:55:22 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:55:22 --> Controller Class Initialized
INFO - 2024-02-21 19:55:22 --> Form Validation Class Initialized
INFO - 2024-02-21 19:55:22 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:55:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:55:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:55:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:55:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 19:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:55:23 --> Config Class Initialized
INFO - 2024-02-21 19:55:23 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:55:23 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:55:23 --> Utf8 Class Initialized
INFO - 2024-02-21 19:55:23 --> URI Class Initialized
INFO - 2024-02-21 19:55:23 --> Router Class Initialized
INFO - 2024-02-21 19:55:23 --> Output Class Initialized
INFO - 2024-02-21 19:55:23 --> Security Class Initialized
DEBUG - 2024-02-21 19:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:55:23 --> Input Class Initialized
INFO - 2024-02-21 19:55:23 --> Language Class Initialized
INFO - 2024-02-21 19:55:23 --> Loader Class Initialized
INFO - 2024-02-21 19:55:23 --> Helper loaded: url_helper
INFO - 2024-02-21 19:55:23 --> Helper loaded: file_helper
INFO - 2024-02-21 19:55:23 --> Helper loaded: form_helper
INFO - 2024-02-21 19:55:23 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:55:23 --> Controller Class Initialized
INFO - 2024-02-21 19:55:23 --> Form Validation Class Initialized
INFO - 2024-02-21 19:55:23 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:55:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:55:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:55:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:55:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 19:55:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:55:25 --> Config Class Initialized
INFO - 2024-02-21 19:55:25 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:55:25 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:55:25 --> Utf8 Class Initialized
INFO - 2024-02-21 19:55:25 --> URI Class Initialized
INFO - 2024-02-21 19:55:25 --> Router Class Initialized
INFO - 2024-02-21 19:55:25 --> Output Class Initialized
INFO - 2024-02-21 19:55:25 --> Security Class Initialized
DEBUG - 2024-02-21 19:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:55:25 --> Input Class Initialized
INFO - 2024-02-21 19:55:25 --> Language Class Initialized
INFO - 2024-02-21 19:55:25 --> Loader Class Initialized
INFO - 2024-02-21 19:55:25 --> Helper loaded: url_helper
INFO - 2024-02-21 19:55:25 --> Helper loaded: file_helper
INFO - 2024-02-21 19:55:25 --> Helper loaded: form_helper
INFO - 2024-02-21 19:55:25 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:55:25 --> Controller Class Initialized
INFO - 2024-02-21 19:55:25 --> Form Validation Class Initialized
INFO - 2024-02-21 19:55:25 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:55:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:55:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:55:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:55:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 19:55:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:55:59 --> Config Class Initialized
INFO - 2024-02-21 19:55:59 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:55:59 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:55:59 --> Utf8 Class Initialized
INFO - 2024-02-21 19:55:59 --> URI Class Initialized
INFO - 2024-02-21 19:55:59 --> Router Class Initialized
INFO - 2024-02-21 19:55:59 --> Output Class Initialized
INFO - 2024-02-21 19:55:59 --> Security Class Initialized
DEBUG - 2024-02-21 19:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:55:59 --> Input Class Initialized
INFO - 2024-02-21 19:55:59 --> Language Class Initialized
INFO - 2024-02-21 19:55:59 --> Loader Class Initialized
INFO - 2024-02-21 19:55:59 --> Helper loaded: url_helper
INFO - 2024-02-21 19:55:59 --> Helper loaded: file_helper
INFO - 2024-02-21 19:55:59 --> Helper loaded: form_helper
INFO - 2024-02-21 19:55:59 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:55:59 --> Controller Class Initialized
INFO - 2024-02-21 19:55:59 --> Form Validation Class Initialized
INFO - 2024-02-21 19:55:59 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:55:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:55:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:55:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:55:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 19:56:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:56:31 --> Config Class Initialized
INFO - 2024-02-21 19:56:31 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:56:31 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:56:31 --> Utf8 Class Initialized
INFO - 2024-02-21 19:56:31 --> URI Class Initialized
INFO - 2024-02-21 19:56:31 --> Router Class Initialized
INFO - 2024-02-21 19:56:31 --> Output Class Initialized
INFO - 2024-02-21 19:56:31 --> Security Class Initialized
DEBUG - 2024-02-21 19:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:56:31 --> Input Class Initialized
INFO - 2024-02-21 19:56:31 --> Language Class Initialized
INFO - 2024-02-21 19:56:31 --> Loader Class Initialized
INFO - 2024-02-21 19:56:31 --> Helper loaded: url_helper
INFO - 2024-02-21 19:56:31 --> Helper loaded: file_helper
INFO - 2024-02-21 19:56:31 --> Helper loaded: form_helper
INFO - 2024-02-21 19:56:31 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:56:31 --> Controller Class Initialized
INFO - 2024-02-21 19:56:31 --> Form Validation Class Initialized
INFO - 2024-02-21 19:56:31 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:56:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:56:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:56:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:56:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 19:56:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 19:56:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 19:56:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 19:56:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 19:56:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 19:56:31 --> Final output sent to browser
DEBUG - 2024-02-21 19:56:31 --> Total execution time: 0.0315
ERROR - 2024-02-21 19:56:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:56:32 --> Config Class Initialized
INFO - 2024-02-21 19:56:32 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:56:32 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:56:32 --> Utf8 Class Initialized
INFO - 2024-02-21 19:56:32 --> URI Class Initialized
INFO - 2024-02-21 19:56:32 --> Router Class Initialized
INFO - 2024-02-21 19:56:32 --> Output Class Initialized
INFO - 2024-02-21 19:56:32 --> Security Class Initialized
DEBUG - 2024-02-21 19:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:56:32 --> Input Class Initialized
INFO - 2024-02-21 19:56:32 --> Language Class Initialized
INFO - 2024-02-21 19:56:32 --> Loader Class Initialized
INFO - 2024-02-21 19:56:32 --> Helper loaded: url_helper
INFO - 2024-02-21 19:56:32 --> Helper loaded: file_helper
INFO - 2024-02-21 19:56:32 --> Helper loaded: form_helper
INFO - 2024-02-21 19:56:32 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:56:32 --> Controller Class Initialized
INFO - 2024-02-21 19:56:32 --> Form Validation Class Initialized
INFO - 2024-02-21 19:56:32 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:56:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:56:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:56:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:56:32 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 19:56:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 19:56:59 --> Config Class Initialized
INFO - 2024-02-21 19:56:59 --> Hooks Class Initialized
DEBUG - 2024-02-21 19:56:59 --> UTF-8 Support Enabled
INFO - 2024-02-21 19:56:59 --> Utf8 Class Initialized
INFO - 2024-02-21 19:56:59 --> URI Class Initialized
INFO - 2024-02-21 19:56:59 --> Router Class Initialized
INFO - 2024-02-21 19:56:59 --> Output Class Initialized
INFO - 2024-02-21 19:56:59 --> Security Class Initialized
DEBUG - 2024-02-21 19:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 19:56:59 --> Input Class Initialized
INFO - 2024-02-21 19:56:59 --> Language Class Initialized
INFO - 2024-02-21 19:56:59 --> Loader Class Initialized
INFO - 2024-02-21 19:56:59 --> Helper loaded: url_helper
INFO - 2024-02-21 19:56:59 --> Helper loaded: file_helper
INFO - 2024-02-21 19:56:59 --> Helper loaded: form_helper
INFO - 2024-02-21 19:56:59 --> Database Driver Class Initialized
DEBUG - 2024-02-21 19:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 19:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 19:56:59 --> Controller Class Initialized
INFO - 2024-02-21 19:56:59 --> Form Validation Class Initialized
INFO - 2024-02-21 19:56:59 --> Model "MasterModel" initialized
INFO - 2024-02-21 19:56:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 19:56:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 19:56:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 19:56:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 19:56:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 19:56:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 19:56:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 19:56:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 19:56:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 19:56:59 --> Final output sent to browser
DEBUG - 2024-02-21 19:56:59 --> Total execution time: 0.0373
ERROR - 2024-02-21 20:00:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:00:38 --> Config Class Initialized
INFO - 2024-02-21 20:00:38 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:00:38 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:00:38 --> Utf8 Class Initialized
INFO - 2024-02-21 20:00:38 --> URI Class Initialized
INFO - 2024-02-21 20:00:38 --> Router Class Initialized
INFO - 2024-02-21 20:00:38 --> Output Class Initialized
INFO - 2024-02-21 20:00:38 --> Security Class Initialized
DEBUG - 2024-02-21 20:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:00:38 --> Input Class Initialized
INFO - 2024-02-21 20:00:38 --> Language Class Initialized
INFO - 2024-02-21 20:00:38 --> Loader Class Initialized
INFO - 2024-02-21 20:00:38 --> Helper loaded: url_helper
INFO - 2024-02-21 20:00:38 --> Helper loaded: file_helper
INFO - 2024-02-21 20:00:38 --> Helper loaded: form_helper
INFO - 2024-02-21 20:00:38 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:00:38 --> Controller Class Initialized
INFO - 2024-02-21 20:00:38 --> Form Validation Class Initialized
INFO - 2024-02-21 20:00:38 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:00:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:00:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:00:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:00:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:00:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:00:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:00:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:00:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:00:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:00:38 --> Final output sent to browser
DEBUG - 2024-02-21 20:00:38 --> Total execution time: 0.0365
ERROR - 2024-02-21 20:00:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:00:39 --> Config Class Initialized
INFO - 2024-02-21 20:00:39 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:00:39 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:00:39 --> Utf8 Class Initialized
INFO - 2024-02-21 20:00:39 --> URI Class Initialized
INFO - 2024-02-21 20:00:39 --> Router Class Initialized
INFO - 2024-02-21 20:00:39 --> Output Class Initialized
INFO - 2024-02-21 20:00:39 --> Security Class Initialized
DEBUG - 2024-02-21 20:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:00:39 --> Input Class Initialized
INFO - 2024-02-21 20:00:39 --> Language Class Initialized
INFO - 2024-02-21 20:00:39 --> Loader Class Initialized
INFO - 2024-02-21 20:00:39 --> Helper loaded: url_helper
INFO - 2024-02-21 20:00:39 --> Helper loaded: file_helper
INFO - 2024-02-21 20:00:39 --> Helper loaded: form_helper
INFO - 2024-02-21 20:00:39 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:00:39 --> Controller Class Initialized
INFO - 2024-02-21 20:00:39 --> Form Validation Class Initialized
INFO - 2024-02-21 20:00:39 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:00:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:00:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:00:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:00:39 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:00:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:00:44 --> Config Class Initialized
INFO - 2024-02-21 20:00:44 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:00:44 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:00:44 --> Utf8 Class Initialized
INFO - 2024-02-21 20:00:44 --> URI Class Initialized
INFO - 2024-02-21 20:00:44 --> Router Class Initialized
INFO - 2024-02-21 20:00:44 --> Output Class Initialized
INFO - 2024-02-21 20:00:44 --> Security Class Initialized
DEBUG - 2024-02-21 20:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:00:44 --> Input Class Initialized
INFO - 2024-02-21 20:00:44 --> Language Class Initialized
INFO - 2024-02-21 20:00:44 --> Loader Class Initialized
INFO - 2024-02-21 20:00:44 --> Helper loaded: url_helper
INFO - 2024-02-21 20:00:44 --> Helper loaded: file_helper
INFO - 2024-02-21 20:00:44 --> Helper loaded: form_helper
INFO - 2024-02-21 20:00:44 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:00:44 --> Controller Class Initialized
INFO - 2024-02-21 20:00:44 --> Form Validation Class Initialized
INFO - 2024-02-21 20:00:44 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:00:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:00:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:00:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:00:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:00:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:00:56 --> Config Class Initialized
INFO - 2024-02-21 20:00:56 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:00:56 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:00:56 --> Utf8 Class Initialized
INFO - 2024-02-21 20:00:56 --> URI Class Initialized
INFO - 2024-02-21 20:00:56 --> Router Class Initialized
INFO - 2024-02-21 20:00:56 --> Output Class Initialized
INFO - 2024-02-21 20:00:56 --> Security Class Initialized
DEBUG - 2024-02-21 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:00:56 --> Input Class Initialized
INFO - 2024-02-21 20:00:56 --> Language Class Initialized
INFO - 2024-02-21 20:00:56 --> Loader Class Initialized
INFO - 2024-02-21 20:00:56 --> Helper loaded: url_helper
INFO - 2024-02-21 20:00:56 --> Helper loaded: file_helper
INFO - 2024-02-21 20:00:56 --> Helper loaded: form_helper
INFO - 2024-02-21 20:00:56 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:00:56 --> Controller Class Initialized
INFO - 2024-02-21 20:00:56 --> Form Validation Class Initialized
INFO - 2024-02-21 20:00:56 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:00:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:00:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:00:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:00:56 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:01:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:01:18 --> Config Class Initialized
INFO - 2024-02-21 20:01:18 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:01:18 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:01:18 --> Utf8 Class Initialized
INFO - 2024-02-21 20:01:18 --> URI Class Initialized
INFO - 2024-02-21 20:01:18 --> Router Class Initialized
INFO - 2024-02-21 20:01:18 --> Output Class Initialized
INFO - 2024-02-21 20:01:18 --> Security Class Initialized
DEBUG - 2024-02-21 20:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:01:18 --> Input Class Initialized
INFO - 2024-02-21 20:01:18 --> Language Class Initialized
INFO - 2024-02-21 20:01:18 --> Loader Class Initialized
INFO - 2024-02-21 20:01:18 --> Helper loaded: url_helper
INFO - 2024-02-21 20:01:18 --> Helper loaded: file_helper
INFO - 2024-02-21 20:01:18 --> Helper loaded: form_helper
INFO - 2024-02-21 20:01:18 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:01:18 --> Controller Class Initialized
INFO - 2024-02-21 20:01:18 --> Form Validation Class Initialized
INFO - 2024-02-21 20:01:18 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:01:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:01:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:01:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:01:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:01:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:01:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:01:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:01:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:01:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:01:18 --> Final output sent to browser
DEBUG - 2024-02-21 20:01:18 --> Total execution time: 0.0317
ERROR - 2024-02-21 20:01:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:01:18 --> Config Class Initialized
INFO - 2024-02-21 20:01:18 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:01:18 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:01:18 --> Utf8 Class Initialized
INFO - 2024-02-21 20:01:18 --> URI Class Initialized
INFO - 2024-02-21 20:01:19 --> Router Class Initialized
INFO - 2024-02-21 20:01:19 --> Output Class Initialized
INFO - 2024-02-21 20:01:19 --> Security Class Initialized
DEBUG - 2024-02-21 20:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:01:19 --> Input Class Initialized
INFO - 2024-02-21 20:01:19 --> Language Class Initialized
INFO - 2024-02-21 20:01:19 --> Loader Class Initialized
INFO - 2024-02-21 20:01:19 --> Helper loaded: url_helper
INFO - 2024-02-21 20:01:19 --> Helper loaded: file_helper
INFO - 2024-02-21 20:01:19 --> Helper loaded: form_helper
INFO - 2024-02-21 20:01:19 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:01:19 --> Controller Class Initialized
INFO - 2024-02-21 20:01:19 --> Form Validation Class Initialized
INFO - 2024-02-21 20:01:19 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:01:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:01:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:01:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:01:19 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:01:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:01:21 --> Config Class Initialized
INFO - 2024-02-21 20:01:21 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:01:21 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:01:21 --> Utf8 Class Initialized
INFO - 2024-02-21 20:01:21 --> URI Class Initialized
INFO - 2024-02-21 20:01:21 --> Router Class Initialized
INFO - 2024-02-21 20:01:21 --> Output Class Initialized
INFO - 2024-02-21 20:01:21 --> Security Class Initialized
DEBUG - 2024-02-21 20:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:01:21 --> Input Class Initialized
INFO - 2024-02-21 20:01:21 --> Language Class Initialized
INFO - 2024-02-21 20:01:21 --> Loader Class Initialized
INFO - 2024-02-21 20:01:21 --> Helper loaded: url_helper
INFO - 2024-02-21 20:01:21 --> Helper loaded: file_helper
INFO - 2024-02-21 20:01:21 --> Helper loaded: form_helper
INFO - 2024-02-21 20:01:21 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:01:21 --> Controller Class Initialized
INFO - 2024-02-21 20:01:21 --> Form Validation Class Initialized
INFO - 2024-02-21 20:01:21 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:01:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:01:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:01:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:01:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:01:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:01:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:01:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:01:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:01:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:01:21 --> Final output sent to browser
DEBUG - 2024-02-21 20:01:21 --> Total execution time: 0.0352
ERROR - 2024-02-21 20:01:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:01:23 --> Config Class Initialized
INFO - 2024-02-21 20:01:23 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:01:23 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:01:23 --> Utf8 Class Initialized
INFO - 2024-02-21 20:01:23 --> URI Class Initialized
INFO - 2024-02-21 20:01:23 --> Router Class Initialized
INFO - 2024-02-21 20:01:23 --> Output Class Initialized
INFO - 2024-02-21 20:01:23 --> Security Class Initialized
DEBUG - 2024-02-21 20:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:01:23 --> Input Class Initialized
INFO - 2024-02-21 20:01:23 --> Language Class Initialized
INFO - 2024-02-21 20:01:23 --> Loader Class Initialized
INFO - 2024-02-21 20:01:23 --> Helper loaded: url_helper
INFO - 2024-02-21 20:01:23 --> Helper loaded: file_helper
INFO - 2024-02-21 20:01:23 --> Helper loaded: form_helper
INFO - 2024-02-21 20:01:23 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:01:23 --> Controller Class Initialized
INFO - 2024-02-21 20:01:23 --> Form Validation Class Initialized
INFO - 2024-02-21 20:01:23 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:01:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:01:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:01:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:01:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:01:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:01:34 --> Config Class Initialized
INFO - 2024-02-21 20:01:34 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:01:34 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:01:34 --> Utf8 Class Initialized
INFO - 2024-02-21 20:01:34 --> URI Class Initialized
INFO - 2024-02-21 20:01:34 --> Router Class Initialized
INFO - 2024-02-21 20:01:34 --> Output Class Initialized
INFO - 2024-02-21 20:01:34 --> Security Class Initialized
DEBUG - 2024-02-21 20:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:01:34 --> Input Class Initialized
INFO - 2024-02-21 20:01:34 --> Language Class Initialized
INFO - 2024-02-21 20:01:34 --> Loader Class Initialized
INFO - 2024-02-21 20:01:34 --> Helper loaded: url_helper
INFO - 2024-02-21 20:01:34 --> Helper loaded: file_helper
INFO - 2024-02-21 20:01:34 --> Helper loaded: form_helper
INFO - 2024-02-21 20:01:34 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:01:34 --> Controller Class Initialized
INFO - 2024-02-21 20:01:34 --> Form Validation Class Initialized
INFO - 2024-02-21 20:01:34 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:01:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:01:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:01:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:01:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:01:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:01:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:01:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:01:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:01:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:01:34 --> Final output sent to browser
DEBUG - 2024-02-21 20:01:34 --> Total execution time: 0.0391
ERROR - 2024-02-21 20:01:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:01:35 --> Config Class Initialized
INFO - 2024-02-21 20:01:35 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:01:35 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:01:35 --> Utf8 Class Initialized
INFO - 2024-02-21 20:01:35 --> URI Class Initialized
INFO - 2024-02-21 20:01:35 --> Router Class Initialized
INFO - 2024-02-21 20:01:35 --> Output Class Initialized
INFO - 2024-02-21 20:01:35 --> Security Class Initialized
DEBUG - 2024-02-21 20:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:01:35 --> Input Class Initialized
INFO - 2024-02-21 20:01:35 --> Language Class Initialized
INFO - 2024-02-21 20:01:35 --> Loader Class Initialized
INFO - 2024-02-21 20:01:35 --> Helper loaded: url_helper
INFO - 2024-02-21 20:01:35 --> Helper loaded: file_helper
INFO - 2024-02-21 20:01:35 --> Helper loaded: form_helper
INFO - 2024-02-21 20:01:35 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:01:35 --> Controller Class Initialized
INFO - 2024-02-21 20:01:35 --> Form Validation Class Initialized
INFO - 2024-02-21 20:01:35 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:01:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:01:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:01:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:01:35 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:01:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:01:47 --> Config Class Initialized
INFO - 2024-02-21 20:01:47 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:01:47 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:01:47 --> Utf8 Class Initialized
INFO - 2024-02-21 20:01:47 --> URI Class Initialized
INFO - 2024-02-21 20:01:47 --> Router Class Initialized
INFO - 2024-02-21 20:01:47 --> Output Class Initialized
INFO - 2024-02-21 20:01:47 --> Security Class Initialized
DEBUG - 2024-02-21 20:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:01:47 --> Input Class Initialized
INFO - 2024-02-21 20:01:47 --> Language Class Initialized
INFO - 2024-02-21 20:01:47 --> Loader Class Initialized
INFO - 2024-02-21 20:01:47 --> Helper loaded: url_helper
INFO - 2024-02-21 20:01:47 --> Helper loaded: file_helper
INFO - 2024-02-21 20:01:47 --> Helper loaded: form_helper
INFO - 2024-02-21 20:01:47 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:01:47 --> Controller Class Initialized
INFO - 2024-02-21 20:01:47 --> Form Validation Class Initialized
INFO - 2024-02-21 20:01:47 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:01:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:01:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:01:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:01:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:01:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:01:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:01:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:01:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:01:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:01:47 --> Final output sent to browser
DEBUG - 2024-02-21 20:01:47 --> Total execution time: 0.0283
ERROR - 2024-02-21 20:01:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:01:49 --> Config Class Initialized
INFO - 2024-02-21 20:01:49 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:01:49 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:01:49 --> Utf8 Class Initialized
INFO - 2024-02-21 20:01:49 --> URI Class Initialized
INFO - 2024-02-21 20:01:49 --> Router Class Initialized
INFO - 2024-02-21 20:01:49 --> Output Class Initialized
INFO - 2024-02-21 20:01:49 --> Security Class Initialized
DEBUG - 2024-02-21 20:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:01:49 --> Input Class Initialized
INFO - 2024-02-21 20:01:49 --> Language Class Initialized
INFO - 2024-02-21 20:01:49 --> Loader Class Initialized
INFO - 2024-02-21 20:01:49 --> Helper loaded: url_helper
INFO - 2024-02-21 20:01:49 --> Helper loaded: file_helper
INFO - 2024-02-21 20:01:49 --> Helper loaded: form_helper
INFO - 2024-02-21 20:01:49 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:01:49 --> Controller Class Initialized
INFO - 2024-02-21 20:01:49 --> Form Validation Class Initialized
INFO - 2024-02-21 20:01:49 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:01:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:01:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:01:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:01:49 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:02:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:02:00 --> Config Class Initialized
INFO - 2024-02-21 20:02:00 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:02:00 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:02:00 --> Utf8 Class Initialized
INFO - 2024-02-21 20:02:00 --> URI Class Initialized
INFO - 2024-02-21 20:02:00 --> Router Class Initialized
INFO - 2024-02-21 20:02:00 --> Output Class Initialized
INFO - 2024-02-21 20:02:00 --> Security Class Initialized
DEBUG - 2024-02-21 20:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:02:00 --> Input Class Initialized
INFO - 2024-02-21 20:02:00 --> Language Class Initialized
INFO - 2024-02-21 20:02:00 --> Loader Class Initialized
INFO - 2024-02-21 20:02:00 --> Helper loaded: url_helper
INFO - 2024-02-21 20:02:00 --> Helper loaded: file_helper
INFO - 2024-02-21 20:02:00 --> Helper loaded: form_helper
INFO - 2024-02-21 20:02:00 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:02:00 --> Controller Class Initialized
INFO - 2024-02-21 20:02:00 --> Form Validation Class Initialized
INFO - 2024-02-21 20:02:00 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:02:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:02:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:02:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:02:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:02:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:02:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:02:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:02:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:02:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:02:00 --> Final output sent to browser
DEBUG - 2024-02-21 20:02:00 --> Total execution time: 0.0272
ERROR - 2024-02-21 20:02:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:02:00 --> Config Class Initialized
INFO - 2024-02-21 20:02:00 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:02:00 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:02:00 --> Utf8 Class Initialized
INFO - 2024-02-21 20:02:00 --> URI Class Initialized
INFO - 2024-02-21 20:02:00 --> Router Class Initialized
INFO - 2024-02-21 20:02:00 --> Output Class Initialized
INFO - 2024-02-21 20:02:00 --> Security Class Initialized
DEBUG - 2024-02-21 20:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:02:00 --> Input Class Initialized
INFO - 2024-02-21 20:02:00 --> Language Class Initialized
INFO - 2024-02-21 20:02:00 --> Loader Class Initialized
INFO - 2024-02-21 20:02:00 --> Helper loaded: url_helper
INFO - 2024-02-21 20:02:00 --> Helper loaded: file_helper
INFO - 2024-02-21 20:02:00 --> Helper loaded: form_helper
INFO - 2024-02-21 20:02:00 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:02:00 --> Controller Class Initialized
INFO - 2024-02-21 20:02:00 --> Form Validation Class Initialized
INFO - 2024-02-21 20:02:00 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:02:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:02:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:02:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:02:00 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:03:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:03:05 --> Config Class Initialized
INFO - 2024-02-21 20:03:05 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:03:05 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:03:05 --> Utf8 Class Initialized
INFO - 2024-02-21 20:03:05 --> URI Class Initialized
INFO - 2024-02-21 20:03:05 --> Router Class Initialized
INFO - 2024-02-21 20:03:05 --> Output Class Initialized
INFO - 2024-02-21 20:03:05 --> Security Class Initialized
DEBUG - 2024-02-21 20:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:03:05 --> Input Class Initialized
INFO - 2024-02-21 20:03:05 --> Language Class Initialized
INFO - 2024-02-21 20:03:05 --> Loader Class Initialized
INFO - 2024-02-21 20:03:05 --> Helper loaded: url_helper
INFO - 2024-02-21 20:03:05 --> Helper loaded: file_helper
INFO - 2024-02-21 20:03:05 --> Helper loaded: form_helper
INFO - 2024-02-21 20:03:05 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:03:05 --> Controller Class Initialized
INFO - 2024-02-21 20:03:05 --> Form Validation Class Initialized
INFO - 2024-02-21 20:03:05 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:03:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:03:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:03:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:03:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:03:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:03:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:03:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:03:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:03:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:03:05 --> Final output sent to browser
DEBUG - 2024-02-21 20:03:05 --> Total execution time: 0.0338
ERROR - 2024-02-21 20:03:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:03:06 --> Config Class Initialized
INFO - 2024-02-21 20:03:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:03:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:03:06 --> Utf8 Class Initialized
INFO - 2024-02-21 20:03:06 --> URI Class Initialized
INFO - 2024-02-21 20:03:06 --> Router Class Initialized
INFO - 2024-02-21 20:03:06 --> Output Class Initialized
INFO - 2024-02-21 20:03:06 --> Security Class Initialized
DEBUG - 2024-02-21 20:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:03:06 --> Input Class Initialized
INFO - 2024-02-21 20:03:06 --> Language Class Initialized
INFO - 2024-02-21 20:03:06 --> Loader Class Initialized
INFO - 2024-02-21 20:03:06 --> Helper loaded: url_helper
INFO - 2024-02-21 20:03:06 --> Helper loaded: file_helper
INFO - 2024-02-21 20:03:06 --> Helper loaded: form_helper
INFO - 2024-02-21 20:03:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:03:06 --> Controller Class Initialized
INFO - 2024-02-21 20:03:06 --> Form Validation Class Initialized
INFO - 2024-02-21 20:03:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:03:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:03:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:03:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:03:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:04:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:04:24 --> Config Class Initialized
INFO - 2024-02-21 20:04:24 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:04:24 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:04:24 --> Utf8 Class Initialized
INFO - 2024-02-21 20:04:24 --> URI Class Initialized
INFO - 2024-02-21 20:04:24 --> Router Class Initialized
INFO - 2024-02-21 20:04:24 --> Output Class Initialized
INFO - 2024-02-21 20:04:24 --> Security Class Initialized
DEBUG - 2024-02-21 20:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:04:24 --> Input Class Initialized
INFO - 2024-02-21 20:04:24 --> Language Class Initialized
INFO - 2024-02-21 20:04:24 --> Loader Class Initialized
INFO - 2024-02-21 20:04:24 --> Helper loaded: url_helper
INFO - 2024-02-21 20:04:24 --> Helper loaded: file_helper
INFO - 2024-02-21 20:04:24 --> Helper loaded: form_helper
INFO - 2024-02-21 20:04:24 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:04:24 --> Controller Class Initialized
INFO - 2024-02-21 20:04:24 --> Form Validation Class Initialized
INFO - 2024-02-21 20:04:24 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:04:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:04:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:04:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:04:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:04:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:04:36 --> Config Class Initialized
INFO - 2024-02-21 20:04:36 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:04:36 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:04:36 --> Utf8 Class Initialized
INFO - 2024-02-21 20:04:36 --> URI Class Initialized
INFO - 2024-02-21 20:04:36 --> Router Class Initialized
INFO - 2024-02-21 20:04:36 --> Output Class Initialized
INFO - 2024-02-21 20:04:36 --> Security Class Initialized
DEBUG - 2024-02-21 20:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:04:36 --> Input Class Initialized
INFO - 2024-02-21 20:04:36 --> Language Class Initialized
INFO - 2024-02-21 20:04:36 --> Loader Class Initialized
INFO - 2024-02-21 20:04:36 --> Helper loaded: url_helper
INFO - 2024-02-21 20:04:36 --> Helper loaded: file_helper
INFO - 2024-02-21 20:04:36 --> Helper loaded: form_helper
INFO - 2024-02-21 20:04:36 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:04:36 --> Controller Class Initialized
INFO - 2024-02-21 20:04:36 --> Form Validation Class Initialized
INFO - 2024-02-21 20:04:36 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:04:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:04:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:04:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:04:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:04:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:04:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:04:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:04:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:04:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:04:36 --> Final output sent to browser
DEBUG - 2024-02-21 20:04:36 --> Total execution time: 0.0437
ERROR - 2024-02-21 20:04:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:04:38 --> Config Class Initialized
INFO - 2024-02-21 20:04:38 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:04:38 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:04:38 --> Utf8 Class Initialized
INFO - 2024-02-21 20:04:38 --> URI Class Initialized
INFO - 2024-02-21 20:04:38 --> Router Class Initialized
INFO - 2024-02-21 20:04:38 --> Output Class Initialized
INFO - 2024-02-21 20:04:38 --> Security Class Initialized
DEBUG - 2024-02-21 20:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:04:38 --> Input Class Initialized
INFO - 2024-02-21 20:04:38 --> Language Class Initialized
INFO - 2024-02-21 20:04:38 --> Loader Class Initialized
INFO - 2024-02-21 20:04:38 --> Helper loaded: url_helper
INFO - 2024-02-21 20:04:38 --> Helper loaded: file_helper
INFO - 2024-02-21 20:04:38 --> Helper loaded: form_helper
INFO - 2024-02-21 20:04:38 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:04:38 --> Controller Class Initialized
INFO - 2024-02-21 20:04:38 --> Form Validation Class Initialized
INFO - 2024-02-21 20:04:38 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:04:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:04:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:04:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:04:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:04:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:04:42 --> Config Class Initialized
INFO - 2024-02-21 20:04:42 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:04:42 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:04:42 --> Utf8 Class Initialized
INFO - 2024-02-21 20:04:42 --> URI Class Initialized
INFO - 2024-02-21 20:04:42 --> Router Class Initialized
INFO - 2024-02-21 20:04:42 --> Output Class Initialized
INFO - 2024-02-21 20:04:42 --> Security Class Initialized
DEBUG - 2024-02-21 20:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:04:42 --> Input Class Initialized
INFO - 2024-02-21 20:04:42 --> Language Class Initialized
INFO - 2024-02-21 20:04:42 --> Loader Class Initialized
INFO - 2024-02-21 20:04:42 --> Helper loaded: url_helper
INFO - 2024-02-21 20:04:42 --> Helper loaded: file_helper
INFO - 2024-02-21 20:04:42 --> Helper loaded: form_helper
INFO - 2024-02-21 20:04:42 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:04:42 --> Controller Class Initialized
INFO - 2024-02-21 20:04:42 --> Form Validation Class Initialized
INFO - 2024-02-21 20:04:42 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:04:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:04:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:04:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:04:42 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:04:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:04:43 --> Config Class Initialized
INFO - 2024-02-21 20:04:43 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:04:43 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:04:43 --> Utf8 Class Initialized
INFO - 2024-02-21 20:04:43 --> URI Class Initialized
INFO - 2024-02-21 20:04:43 --> Router Class Initialized
INFO - 2024-02-21 20:04:43 --> Output Class Initialized
INFO - 2024-02-21 20:04:43 --> Security Class Initialized
DEBUG - 2024-02-21 20:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:04:43 --> Input Class Initialized
INFO - 2024-02-21 20:04:43 --> Language Class Initialized
INFO - 2024-02-21 20:04:43 --> Loader Class Initialized
INFO - 2024-02-21 20:04:43 --> Helper loaded: url_helper
INFO - 2024-02-21 20:04:43 --> Helper loaded: file_helper
INFO - 2024-02-21 20:04:43 --> Helper loaded: form_helper
INFO - 2024-02-21 20:04:43 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:04:43 --> Controller Class Initialized
INFO - 2024-02-21 20:04:43 --> Form Validation Class Initialized
INFO - 2024-02-21 20:04:43 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:04:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:04:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:04:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:04:43 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:10:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:10:25 --> Config Class Initialized
INFO - 2024-02-21 20:10:25 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:10:25 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:10:25 --> Utf8 Class Initialized
INFO - 2024-02-21 20:10:25 --> URI Class Initialized
INFO - 2024-02-21 20:10:25 --> Router Class Initialized
INFO - 2024-02-21 20:10:25 --> Output Class Initialized
INFO - 2024-02-21 20:10:25 --> Security Class Initialized
DEBUG - 2024-02-21 20:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:10:25 --> Input Class Initialized
INFO - 2024-02-21 20:10:25 --> Language Class Initialized
INFO - 2024-02-21 20:10:25 --> Loader Class Initialized
INFO - 2024-02-21 20:10:25 --> Helper loaded: url_helper
INFO - 2024-02-21 20:10:25 --> Helper loaded: file_helper
INFO - 2024-02-21 20:10:25 --> Helper loaded: form_helper
INFO - 2024-02-21 20:10:25 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:10:25 --> Controller Class Initialized
INFO - 2024-02-21 20:10:25 --> Form Validation Class Initialized
INFO - 2024-02-21 20:10:25 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:10:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:10:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:10:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:10:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:10:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:10:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:10:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:10:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:10:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:10:25 --> Final output sent to browser
DEBUG - 2024-02-21 20:10:25 --> Total execution time: 0.0375
ERROR - 2024-02-21 20:10:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:10:25 --> Config Class Initialized
INFO - 2024-02-21 20:10:25 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:10:25 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:10:25 --> Utf8 Class Initialized
INFO - 2024-02-21 20:10:25 --> URI Class Initialized
INFO - 2024-02-21 20:10:25 --> Router Class Initialized
INFO - 2024-02-21 20:10:25 --> Output Class Initialized
INFO - 2024-02-21 20:10:25 --> Security Class Initialized
DEBUG - 2024-02-21 20:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:10:25 --> Input Class Initialized
INFO - 2024-02-21 20:10:25 --> Language Class Initialized
INFO - 2024-02-21 20:10:25 --> Loader Class Initialized
INFO - 2024-02-21 20:10:25 --> Helper loaded: url_helper
INFO - 2024-02-21 20:10:25 --> Helper loaded: file_helper
INFO - 2024-02-21 20:10:25 --> Helper loaded: form_helper
INFO - 2024-02-21 20:10:25 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:10:25 --> Controller Class Initialized
INFO - 2024-02-21 20:10:25 --> Form Validation Class Initialized
INFO - 2024-02-21 20:10:25 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:10:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:10:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:10:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:10:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:10:51 --> Config Class Initialized
INFO - 2024-02-21 20:10:51 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:10:51 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:10:51 --> Utf8 Class Initialized
INFO - 2024-02-21 20:10:51 --> URI Class Initialized
INFO - 2024-02-21 20:10:51 --> Router Class Initialized
INFO - 2024-02-21 20:10:51 --> Output Class Initialized
INFO - 2024-02-21 20:10:51 --> Security Class Initialized
DEBUG - 2024-02-21 20:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:10:51 --> Input Class Initialized
INFO - 2024-02-21 20:10:51 --> Language Class Initialized
INFO - 2024-02-21 20:10:51 --> Loader Class Initialized
INFO - 2024-02-21 20:10:51 --> Helper loaded: url_helper
INFO - 2024-02-21 20:10:51 --> Helper loaded: file_helper
INFO - 2024-02-21 20:10:51 --> Helper loaded: form_helper
INFO - 2024-02-21 20:10:51 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:10:51 --> Controller Class Initialized
INFO - 2024-02-21 20:10:51 --> Form Validation Class Initialized
INFO - 2024-02-21 20:10:51 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:10:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:10:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:10:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:10:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:10:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:10:51 --> Final output sent to browser
DEBUG - 2024-02-21 20:10:51 --> Total execution time: 0.0287
ERROR - 2024-02-21 20:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:10:51 --> Config Class Initialized
INFO - 2024-02-21 20:10:51 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:10:51 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:10:51 --> Utf8 Class Initialized
INFO - 2024-02-21 20:10:51 --> URI Class Initialized
INFO - 2024-02-21 20:10:51 --> Router Class Initialized
INFO - 2024-02-21 20:10:51 --> Output Class Initialized
INFO - 2024-02-21 20:10:51 --> Security Class Initialized
DEBUG - 2024-02-21 20:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:10:51 --> Input Class Initialized
INFO - 2024-02-21 20:10:51 --> Language Class Initialized
INFO - 2024-02-21 20:10:51 --> Loader Class Initialized
INFO - 2024-02-21 20:10:51 --> Helper loaded: url_helper
INFO - 2024-02-21 20:10:51 --> Helper loaded: file_helper
INFO - 2024-02-21 20:10:51 --> Helper loaded: form_helper
INFO - 2024-02-21 20:10:51 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:10:51 --> Controller Class Initialized
INFO - 2024-02-21 20:10:51 --> Form Validation Class Initialized
INFO - 2024-02-21 20:10:51 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:10:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:10:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:10:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:10:51 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:11:03 --> Config Class Initialized
INFO - 2024-02-21 20:11:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:11:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:11:03 --> Utf8 Class Initialized
INFO - 2024-02-21 20:11:03 --> URI Class Initialized
INFO - 2024-02-21 20:11:03 --> Router Class Initialized
INFO - 2024-02-21 20:11:03 --> Output Class Initialized
INFO - 2024-02-21 20:11:03 --> Security Class Initialized
DEBUG - 2024-02-21 20:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:11:03 --> Input Class Initialized
INFO - 2024-02-21 20:11:03 --> Language Class Initialized
INFO - 2024-02-21 20:11:03 --> Loader Class Initialized
INFO - 2024-02-21 20:11:03 --> Helper loaded: url_helper
INFO - 2024-02-21 20:11:03 --> Helper loaded: file_helper
INFO - 2024-02-21 20:11:03 --> Helper loaded: form_helper
INFO - 2024-02-21 20:11:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:11:03 --> Controller Class Initialized
INFO - 2024-02-21 20:11:03 --> Form Validation Class Initialized
INFO - 2024-02-21 20:11:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:11:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:11:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:11:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:11:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:11:03 --> Final output sent to browser
DEBUG - 2024-02-21 20:11:03 --> Total execution time: 0.0349
ERROR - 2024-02-21 20:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:11:03 --> Config Class Initialized
INFO - 2024-02-21 20:11:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:11:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:11:03 --> Utf8 Class Initialized
INFO - 2024-02-21 20:11:03 --> URI Class Initialized
INFO - 2024-02-21 20:11:03 --> Router Class Initialized
INFO - 2024-02-21 20:11:03 --> Output Class Initialized
INFO - 2024-02-21 20:11:03 --> Security Class Initialized
DEBUG - 2024-02-21 20:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:11:03 --> Input Class Initialized
INFO - 2024-02-21 20:11:03 --> Language Class Initialized
INFO - 2024-02-21 20:11:03 --> Loader Class Initialized
INFO - 2024-02-21 20:11:03 --> Helper loaded: url_helper
INFO - 2024-02-21 20:11:03 --> Helper loaded: file_helper
INFO - 2024-02-21 20:11:03 --> Helper loaded: form_helper
INFO - 2024-02-21 20:11:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:11:03 --> Controller Class Initialized
INFO - 2024-02-21 20:11:03 --> Form Validation Class Initialized
INFO - 2024-02-21 20:11:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:11:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:11:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:11:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:11:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:11:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:11:14 --> Config Class Initialized
INFO - 2024-02-21 20:11:14 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:11:14 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:11:14 --> Utf8 Class Initialized
INFO - 2024-02-21 20:11:14 --> URI Class Initialized
INFO - 2024-02-21 20:11:14 --> Router Class Initialized
INFO - 2024-02-21 20:11:14 --> Output Class Initialized
INFO - 2024-02-21 20:11:14 --> Security Class Initialized
DEBUG - 2024-02-21 20:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:11:14 --> Input Class Initialized
INFO - 2024-02-21 20:11:14 --> Language Class Initialized
INFO - 2024-02-21 20:11:14 --> Loader Class Initialized
INFO - 2024-02-21 20:11:14 --> Helper loaded: url_helper
INFO - 2024-02-21 20:11:14 --> Helper loaded: file_helper
INFO - 2024-02-21 20:11:14 --> Helper loaded: form_helper
INFO - 2024-02-21 20:11:14 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:11:14 --> Controller Class Initialized
INFO - 2024-02-21 20:11:14 --> Form Validation Class Initialized
INFO - 2024-02-21 20:11:14 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:11:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:11:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:11:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:11:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:11:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:11:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:11:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:11:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:11:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:11:14 --> Final output sent to browser
DEBUG - 2024-02-21 20:11:14 --> Total execution time: 0.0277
ERROR - 2024-02-21 20:11:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:11:14 --> Config Class Initialized
INFO - 2024-02-21 20:11:14 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:11:14 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:11:14 --> Utf8 Class Initialized
INFO - 2024-02-21 20:11:14 --> URI Class Initialized
INFO - 2024-02-21 20:11:14 --> Router Class Initialized
INFO - 2024-02-21 20:11:14 --> Output Class Initialized
INFO - 2024-02-21 20:11:14 --> Security Class Initialized
DEBUG - 2024-02-21 20:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:11:14 --> Input Class Initialized
INFO - 2024-02-21 20:11:14 --> Language Class Initialized
INFO - 2024-02-21 20:11:14 --> Loader Class Initialized
INFO - 2024-02-21 20:11:14 --> Helper loaded: url_helper
INFO - 2024-02-21 20:11:14 --> Helper loaded: file_helper
INFO - 2024-02-21 20:11:14 --> Helper loaded: form_helper
INFO - 2024-02-21 20:11:14 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:11:14 --> Controller Class Initialized
INFO - 2024-02-21 20:11:14 --> Form Validation Class Initialized
INFO - 2024-02-21 20:11:14 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:11:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:11:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:11:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:11:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:11:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:11:24 --> Config Class Initialized
INFO - 2024-02-21 20:11:24 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:11:24 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:11:24 --> Utf8 Class Initialized
INFO - 2024-02-21 20:11:24 --> URI Class Initialized
INFO - 2024-02-21 20:11:24 --> Router Class Initialized
INFO - 2024-02-21 20:11:24 --> Output Class Initialized
INFO - 2024-02-21 20:11:24 --> Security Class Initialized
DEBUG - 2024-02-21 20:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:11:24 --> Input Class Initialized
INFO - 2024-02-21 20:11:24 --> Language Class Initialized
INFO - 2024-02-21 20:11:24 --> Loader Class Initialized
INFO - 2024-02-21 20:11:24 --> Helper loaded: url_helper
INFO - 2024-02-21 20:11:24 --> Helper loaded: file_helper
INFO - 2024-02-21 20:11:24 --> Helper loaded: form_helper
INFO - 2024-02-21 20:11:24 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:11:24 --> Controller Class Initialized
INFO - 2024-02-21 20:11:24 --> Form Validation Class Initialized
INFO - 2024-02-21 20:11:24 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:11:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:11:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:11:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:11:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:11:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:11:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:11:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:11:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:11:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:11:24 --> Final output sent to browser
DEBUG - 2024-02-21 20:11:24 --> Total execution time: 0.0379
ERROR - 2024-02-21 20:11:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:11:24 --> Config Class Initialized
INFO - 2024-02-21 20:11:24 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:11:24 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:11:24 --> Utf8 Class Initialized
INFO - 2024-02-21 20:11:24 --> URI Class Initialized
INFO - 2024-02-21 20:11:24 --> Router Class Initialized
INFO - 2024-02-21 20:11:24 --> Output Class Initialized
INFO - 2024-02-21 20:11:24 --> Security Class Initialized
DEBUG - 2024-02-21 20:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:11:24 --> Input Class Initialized
INFO - 2024-02-21 20:11:24 --> Language Class Initialized
INFO - 2024-02-21 20:11:24 --> Loader Class Initialized
INFO - 2024-02-21 20:11:24 --> Helper loaded: url_helper
INFO - 2024-02-21 20:11:24 --> Helper loaded: file_helper
INFO - 2024-02-21 20:11:24 --> Helper loaded: form_helper
INFO - 2024-02-21 20:11:24 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:11:24 --> Controller Class Initialized
INFO - 2024-02-21 20:11:24 --> Form Validation Class Initialized
INFO - 2024-02-21 20:11:24 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:11:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:11:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:11:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:11:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:11:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:11:31 --> Config Class Initialized
INFO - 2024-02-21 20:11:31 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:11:31 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:11:31 --> Utf8 Class Initialized
INFO - 2024-02-21 20:11:31 --> URI Class Initialized
INFO - 2024-02-21 20:11:31 --> Router Class Initialized
INFO - 2024-02-21 20:11:31 --> Output Class Initialized
INFO - 2024-02-21 20:11:31 --> Security Class Initialized
DEBUG - 2024-02-21 20:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:11:31 --> Input Class Initialized
INFO - 2024-02-21 20:11:31 --> Language Class Initialized
INFO - 2024-02-21 20:11:31 --> Loader Class Initialized
INFO - 2024-02-21 20:11:31 --> Helper loaded: url_helper
INFO - 2024-02-21 20:11:31 --> Helper loaded: file_helper
INFO - 2024-02-21 20:11:31 --> Helper loaded: form_helper
INFO - 2024-02-21 20:11:31 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:11:31 --> Controller Class Initialized
INFO - 2024-02-21 20:11:31 --> Form Validation Class Initialized
INFO - 2024-02-21 20:11:31 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:11:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:11:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:11:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:11:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:11:37 --> Config Class Initialized
INFO - 2024-02-21 20:11:37 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:11:37 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:11:37 --> Utf8 Class Initialized
INFO - 2024-02-21 20:11:37 --> URI Class Initialized
INFO - 2024-02-21 20:11:37 --> Router Class Initialized
INFO - 2024-02-21 20:11:37 --> Output Class Initialized
INFO - 2024-02-21 20:11:37 --> Security Class Initialized
DEBUG - 2024-02-21 20:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:11:37 --> Input Class Initialized
INFO - 2024-02-21 20:11:37 --> Language Class Initialized
INFO - 2024-02-21 20:11:37 --> Loader Class Initialized
INFO - 2024-02-21 20:11:37 --> Helper loaded: url_helper
INFO - 2024-02-21 20:11:37 --> Helper loaded: file_helper
INFO - 2024-02-21 20:11:37 --> Helper loaded: form_helper
INFO - 2024-02-21 20:11:37 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:11:37 --> Controller Class Initialized
INFO - 2024-02-21 20:11:37 --> Form Validation Class Initialized
INFO - 2024-02-21 20:11:37 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:11:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:11:37 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:11:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:11:37 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:11:38 --> Config Class Initialized
INFO - 2024-02-21 20:11:38 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:11:38 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:11:38 --> Utf8 Class Initialized
INFO - 2024-02-21 20:11:38 --> URI Class Initialized
INFO - 2024-02-21 20:11:38 --> Router Class Initialized
INFO - 2024-02-21 20:11:38 --> Output Class Initialized
INFO - 2024-02-21 20:11:38 --> Security Class Initialized
DEBUG - 2024-02-21 20:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:11:38 --> Input Class Initialized
INFO - 2024-02-21 20:11:38 --> Language Class Initialized
INFO - 2024-02-21 20:11:38 --> Loader Class Initialized
INFO - 2024-02-21 20:11:38 --> Helper loaded: url_helper
INFO - 2024-02-21 20:11:38 --> Helper loaded: file_helper
INFO - 2024-02-21 20:11:38 --> Helper loaded: form_helper
INFO - 2024-02-21 20:11:38 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:11:38 --> Controller Class Initialized
INFO - 2024-02-21 20:11:38 --> Form Validation Class Initialized
INFO - 2024-02-21 20:11:38 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:11:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:11:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:11:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:11:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:11:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:11:44 --> Config Class Initialized
INFO - 2024-02-21 20:11:44 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:11:44 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:11:44 --> Utf8 Class Initialized
INFO - 2024-02-21 20:11:44 --> URI Class Initialized
INFO - 2024-02-21 20:11:44 --> Router Class Initialized
INFO - 2024-02-21 20:11:44 --> Output Class Initialized
INFO - 2024-02-21 20:11:44 --> Security Class Initialized
DEBUG - 2024-02-21 20:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:11:44 --> Input Class Initialized
INFO - 2024-02-21 20:11:44 --> Language Class Initialized
INFO - 2024-02-21 20:11:44 --> Loader Class Initialized
INFO - 2024-02-21 20:11:44 --> Helper loaded: url_helper
INFO - 2024-02-21 20:11:44 --> Helper loaded: file_helper
INFO - 2024-02-21 20:11:44 --> Helper loaded: form_helper
INFO - 2024-02-21 20:11:44 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:11:44 --> Controller Class Initialized
INFO - 2024-02-21 20:11:44 --> Form Validation Class Initialized
INFO - 2024-02-21 20:11:44 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:11:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:11:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:11:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:11:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:11:45 --> Config Class Initialized
INFO - 2024-02-21 20:11:45 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:11:45 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:11:45 --> Utf8 Class Initialized
INFO - 2024-02-21 20:11:45 --> URI Class Initialized
INFO - 2024-02-21 20:11:45 --> Router Class Initialized
INFO - 2024-02-21 20:11:45 --> Output Class Initialized
INFO - 2024-02-21 20:11:45 --> Security Class Initialized
DEBUG - 2024-02-21 20:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:11:45 --> Input Class Initialized
INFO - 2024-02-21 20:11:45 --> Language Class Initialized
INFO - 2024-02-21 20:11:45 --> Loader Class Initialized
INFO - 2024-02-21 20:11:45 --> Helper loaded: url_helper
INFO - 2024-02-21 20:11:45 --> Helper loaded: file_helper
INFO - 2024-02-21 20:11:45 --> Helper loaded: form_helper
INFO - 2024-02-21 20:11:45 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:11:45 --> Controller Class Initialized
INFO - 2024-02-21 20:11:45 --> Form Validation Class Initialized
INFO - 2024-02-21 20:11:45 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:11:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:11:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:11:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:11:45 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:12:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:12:08 --> Config Class Initialized
INFO - 2024-02-21 20:12:08 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:12:08 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:12:08 --> Utf8 Class Initialized
INFO - 2024-02-21 20:12:08 --> URI Class Initialized
INFO - 2024-02-21 20:12:08 --> Router Class Initialized
INFO - 2024-02-21 20:12:08 --> Output Class Initialized
INFO - 2024-02-21 20:12:08 --> Security Class Initialized
DEBUG - 2024-02-21 20:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:12:08 --> Input Class Initialized
INFO - 2024-02-21 20:12:08 --> Language Class Initialized
INFO - 2024-02-21 20:12:08 --> Loader Class Initialized
INFO - 2024-02-21 20:12:08 --> Helper loaded: url_helper
INFO - 2024-02-21 20:12:08 --> Helper loaded: file_helper
INFO - 2024-02-21 20:12:08 --> Helper loaded: form_helper
INFO - 2024-02-21 20:12:08 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:12:08 --> Controller Class Initialized
INFO - 2024-02-21 20:12:08 --> Form Validation Class Initialized
INFO - 2024-02-21 20:12:08 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:12:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:12:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:12:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:12:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:12:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:12:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:12:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:12:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:12:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:12:08 --> Final output sent to browser
DEBUG - 2024-02-21 20:12:08 --> Total execution time: 0.0285
ERROR - 2024-02-21 20:12:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:12:27 --> Config Class Initialized
INFO - 2024-02-21 20:12:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:12:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:12:27 --> Utf8 Class Initialized
INFO - 2024-02-21 20:12:27 --> URI Class Initialized
INFO - 2024-02-21 20:12:27 --> Router Class Initialized
INFO - 2024-02-21 20:12:27 --> Output Class Initialized
INFO - 2024-02-21 20:12:27 --> Security Class Initialized
DEBUG - 2024-02-21 20:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:12:27 --> Input Class Initialized
INFO - 2024-02-21 20:12:27 --> Language Class Initialized
INFO - 2024-02-21 20:12:27 --> Loader Class Initialized
INFO - 2024-02-21 20:12:27 --> Helper loaded: url_helper
INFO - 2024-02-21 20:12:27 --> Helper loaded: file_helper
INFO - 2024-02-21 20:12:27 --> Helper loaded: form_helper
INFO - 2024-02-21 20:12:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:12:27 --> Controller Class Initialized
INFO - 2024-02-21 20:12:27 --> Form Validation Class Initialized
INFO - 2024-02-21 20:12:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:12:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:12:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:12:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:12:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:12:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:12:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:12:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:12:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:12:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:12:27 --> Final output sent to browser
DEBUG - 2024-02-21 20:12:27 --> Total execution time: 0.0358
ERROR - 2024-02-21 20:12:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:12:27 --> Config Class Initialized
INFO - 2024-02-21 20:12:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:12:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:12:27 --> Utf8 Class Initialized
INFO - 2024-02-21 20:12:27 --> URI Class Initialized
INFO - 2024-02-21 20:12:27 --> Router Class Initialized
INFO - 2024-02-21 20:12:27 --> Output Class Initialized
INFO - 2024-02-21 20:12:27 --> Security Class Initialized
DEBUG - 2024-02-21 20:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:12:27 --> Input Class Initialized
INFO - 2024-02-21 20:12:27 --> Language Class Initialized
INFO - 2024-02-21 20:12:28 --> Loader Class Initialized
INFO - 2024-02-21 20:12:28 --> Helper loaded: url_helper
INFO - 2024-02-21 20:12:28 --> Helper loaded: file_helper
INFO - 2024-02-21 20:12:28 --> Helper loaded: form_helper
INFO - 2024-02-21 20:12:28 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:12:28 --> Controller Class Initialized
INFO - 2024-02-21 20:12:28 --> Form Validation Class Initialized
INFO - 2024-02-21 20:12:28 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:12:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:12:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:12:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:12:28 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:12:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:12:44 --> Config Class Initialized
INFO - 2024-02-21 20:12:44 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:12:44 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:12:44 --> Utf8 Class Initialized
INFO - 2024-02-21 20:12:44 --> URI Class Initialized
INFO - 2024-02-21 20:12:44 --> Router Class Initialized
INFO - 2024-02-21 20:12:44 --> Output Class Initialized
INFO - 2024-02-21 20:12:44 --> Security Class Initialized
DEBUG - 2024-02-21 20:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:12:44 --> Input Class Initialized
INFO - 2024-02-21 20:12:44 --> Language Class Initialized
INFO - 2024-02-21 20:12:44 --> Loader Class Initialized
INFO - 2024-02-21 20:12:44 --> Helper loaded: url_helper
INFO - 2024-02-21 20:12:44 --> Helper loaded: file_helper
INFO - 2024-02-21 20:12:44 --> Helper loaded: form_helper
INFO - 2024-02-21 20:12:44 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:12:44 --> Controller Class Initialized
INFO - 2024-02-21 20:12:44 --> Form Validation Class Initialized
INFO - 2024-02-21 20:12:44 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:12:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:12:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:12:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:12:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:13:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:13:02 --> Config Class Initialized
INFO - 2024-02-21 20:13:02 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:13:02 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:13:02 --> Utf8 Class Initialized
INFO - 2024-02-21 20:13:02 --> URI Class Initialized
INFO - 2024-02-21 20:13:02 --> Router Class Initialized
INFO - 2024-02-21 20:13:02 --> Output Class Initialized
INFO - 2024-02-21 20:13:02 --> Security Class Initialized
DEBUG - 2024-02-21 20:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:13:02 --> Input Class Initialized
INFO - 2024-02-21 20:13:02 --> Language Class Initialized
INFO - 2024-02-21 20:13:02 --> Loader Class Initialized
INFO - 2024-02-21 20:13:02 --> Helper loaded: url_helper
INFO - 2024-02-21 20:13:02 --> Helper loaded: file_helper
INFO - 2024-02-21 20:13:02 --> Helper loaded: form_helper
INFO - 2024-02-21 20:13:02 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:13:02 --> Controller Class Initialized
INFO - 2024-02-21 20:13:02 --> Form Validation Class Initialized
INFO - 2024-02-21 20:13:02 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:13:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:13:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:13:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:13:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:13:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:13:04 --> Config Class Initialized
INFO - 2024-02-21 20:13:04 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:13:04 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:13:04 --> Utf8 Class Initialized
INFO - 2024-02-21 20:13:04 --> URI Class Initialized
INFO - 2024-02-21 20:13:04 --> Router Class Initialized
INFO - 2024-02-21 20:13:04 --> Output Class Initialized
INFO - 2024-02-21 20:13:04 --> Security Class Initialized
DEBUG - 2024-02-21 20:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:13:04 --> Input Class Initialized
INFO - 2024-02-21 20:13:04 --> Language Class Initialized
INFO - 2024-02-21 20:13:04 --> Loader Class Initialized
INFO - 2024-02-21 20:13:04 --> Helper loaded: url_helper
INFO - 2024-02-21 20:13:04 --> Helper loaded: file_helper
INFO - 2024-02-21 20:13:04 --> Helper loaded: form_helper
INFO - 2024-02-21 20:13:04 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:13:04 --> Controller Class Initialized
INFO - 2024-02-21 20:13:04 --> Form Validation Class Initialized
INFO - 2024-02-21 20:13:04 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:13:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:13:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:13:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:13:04 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:13:08 --> Config Class Initialized
INFO - 2024-02-21 20:13:08 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:13:08 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:13:08 --> Utf8 Class Initialized
INFO - 2024-02-21 20:13:08 --> URI Class Initialized
INFO - 2024-02-21 20:13:08 --> Router Class Initialized
INFO - 2024-02-21 20:13:08 --> Output Class Initialized
INFO - 2024-02-21 20:13:08 --> Security Class Initialized
DEBUG - 2024-02-21 20:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:13:08 --> Input Class Initialized
INFO - 2024-02-21 20:13:08 --> Language Class Initialized
INFO - 2024-02-21 20:13:08 --> Loader Class Initialized
INFO - 2024-02-21 20:13:08 --> Helper loaded: url_helper
INFO - 2024-02-21 20:13:08 --> Helper loaded: file_helper
INFO - 2024-02-21 20:13:08 --> Helper loaded: form_helper
INFO - 2024-02-21 20:13:08 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:13:08 --> Controller Class Initialized
INFO - 2024-02-21 20:13:08 --> Form Validation Class Initialized
INFO - 2024-02-21 20:13:08 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:13:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:13:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:13:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:13:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:13:11 --> Config Class Initialized
INFO - 2024-02-21 20:13:11 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:13:11 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:13:11 --> Utf8 Class Initialized
INFO - 2024-02-21 20:13:11 --> URI Class Initialized
INFO - 2024-02-21 20:13:11 --> Router Class Initialized
INFO - 2024-02-21 20:13:11 --> Output Class Initialized
INFO - 2024-02-21 20:13:11 --> Security Class Initialized
DEBUG - 2024-02-21 20:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:13:11 --> Input Class Initialized
INFO - 2024-02-21 20:13:11 --> Language Class Initialized
INFO - 2024-02-21 20:13:11 --> Loader Class Initialized
INFO - 2024-02-21 20:13:11 --> Helper loaded: url_helper
INFO - 2024-02-21 20:13:11 --> Helper loaded: file_helper
INFO - 2024-02-21 20:13:11 --> Helper loaded: form_helper
INFO - 2024-02-21 20:13:11 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:13:11 --> Controller Class Initialized
INFO - 2024-02-21 20:13:11 --> Form Validation Class Initialized
INFO - 2024-02-21 20:13:11 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:13:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:13:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:13:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:13:11 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:13:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:13:14 --> Config Class Initialized
INFO - 2024-02-21 20:13:14 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:13:14 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:13:14 --> Utf8 Class Initialized
INFO - 2024-02-21 20:13:14 --> URI Class Initialized
INFO - 2024-02-21 20:13:14 --> Router Class Initialized
INFO - 2024-02-21 20:13:14 --> Output Class Initialized
INFO - 2024-02-21 20:13:14 --> Security Class Initialized
DEBUG - 2024-02-21 20:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:13:14 --> Input Class Initialized
INFO - 2024-02-21 20:13:14 --> Language Class Initialized
INFO - 2024-02-21 20:13:14 --> Loader Class Initialized
INFO - 2024-02-21 20:13:14 --> Helper loaded: url_helper
INFO - 2024-02-21 20:13:14 --> Helper loaded: file_helper
INFO - 2024-02-21 20:13:14 --> Helper loaded: form_helper
INFO - 2024-02-21 20:13:14 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:13:14 --> Controller Class Initialized
INFO - 2024-02-21 20:13:14 --> Form Validation Class Initialized
INFO - 2024-02-21 20:13:14 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:13:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:13:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:13:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:13:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:13:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:13:16 --> Config Class Initialized
INFO - 2024-02-21 20:13:16 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:13:16 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:13:16 --> Utf8 Class Initialized
INFO - 2024-02-21 20:13:16 --> URI Class Initialized
INFO - 2024-02-21 20:13:16 --> Router Class Initialized
INFO - 2024-02-21 20:13:16 --> Output Class Initialized
INFO - 2024-02-21 20:13:16 --> Security Class Initialized
DEBUG - 2024-02-21 20:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:13:16 --> Input Class Initialized
INFO - 2024-02-21 20:13:16 --> Language Class Initialized
INFO - 2024-02-21 20:13:16 --> Loader Class Initialized
INFO - 2024-02-21 20:13:16 --> Helper loaded: url_helper
INFO - 2024-02-21 20:13:16 --> Helper loaded: file_helper
INFO - 2024-02-21 20:13:16 --> Helper loaded: form_helper
INFO - 2024-02-21 20:13:16 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:13:16 --> Controller Class Initialized
INFO - 2024-02-21 20:13:16 --> Form Validation Class Initialized
INFO - 2024-02-21 20:13:16 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:13:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:13:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:13:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:13:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:13:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:13:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:13:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:13:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:13:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:13:16 --> Final output sent to browser
DEBUG - 2024-02-21 20:13:16 --> Total execution time: 0.0390
ERROR - 2024-02-21 20:13:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:13:30 --> Config Class Initialized
INFO - 2024-02-21 20:13:30 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:13:30 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:13:30 --> Utf8 Class Initialized
INFO - 2024-02-21 20:13:30 --> URI Class Initialized
INFO - 2024-02-21 20:13:30 --> Router Class Initialized
INFO - 2024-02-21 20:13:30 --> Output Class Initialized
INFO - 2024-02-21 20:13:30 --> Security Class Initialized
DEBUG - 2024-02-21 20:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:13:30 --> Input Class Initialized
INFO - 2024-02-21 20:13:30 --> Language Class Initialized
INFO - 2024-02-21 20:13:30 --> Loader Class Initialized
INFO - 2024-02-21 20:13:30 --> Helper loaded: url_helper
INFO - 2024-02-21 20:13:30 --> Helper loaded: file_helper
INFO - 2024-02-21 20:13:30 --> Helper loaded: form_helper
INFO - 2024-02-21 20:13:30 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:13:30 --> Controller Class Initialized
INFO - 2024-02-21 20:13:30 --> Form Validation Class Initialized
INFO - 2024-02-21 20:13:30 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:13:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:13:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:13:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:13:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:13:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:13:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:13:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:13:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:13:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:13:30 --> Final output sent to browser
DEBUG - 2024-02-21 20:13:30 --> Total execution time: 0.0402
ERROR - 2024-02-21 20:13:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:13:31 --> Config Class Initialized
INFO - 2024-02-21 20:13:31 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:13:31 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:13:31 --> Utf8 Class Initialized
INFO - 2024-02-21 20:13:31 --> URI Class Initialized
INFO - 2024-02-21 20:13:31 --> Router Class Initialized
INFO - 2024-02-21 20:13:31 --> Output Class Initialized
INFO - 2024-02-21 20:13:31 --> Security Class Initialized
DEBUG - 2024-02-21 20:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:13:31 --> Input Class Initialized
INFO - 2024-02-21 20:13:31 --> Language Class Initialized
INFO - 2024-02-21 20:13:31 --> Loader Class Initialized
INFO - 2024-02-21 20:13:31 --> Helper loaded: url_helper
INFO - 2024-02-21 20:13:31 --> Helper loaded: file_helper
INFO - 2024-02-21 20:13:31 --> Helper loaded: form_helper
INFO - 2024-02-21 20:13:31 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:13:31 --> Controller Class Initialized
INFO - 2024-02-21 20:13:31 --> Form Validation Class Initialized
INFO - 2024-02-21 20:13:31 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:13:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:13:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:13:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:13:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:13:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:13:49 --> Config Class Initialized
INFO - 2024-02-21 20:13:49 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:13:49 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:13:49 --> Utf8 Class Initialized
INFO - 2024-02-21 20:13:49 --> URI Class Initialized
INFO - 2024-02-21 20:13:49 --> Router Class Initialized
INFO - 2024-02-21 20:13:49 --> Output Class Initialized
INFO - 2024-02-21 20:13:49 --> Security Class Initialized
DEBUG - 2024-02-21 20:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:13:49 --> Input Class Initialized
INFO - 2024-02-21 20:13:49 --> Language Class Initialized
INFO - 2024-02-21 20:13:49 --> Loader Class Initialized
INFO - 2024-02-21 20:13:49 --> Helper loaded: url_helper
INFO - 2024-02-21 20:13:49 --> Helper loaded: file_helper
INFO - 2024-02-21 20:13:49 --> Helper loaded: form_helper
INFO - 2024-02-21 20:13:49 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:13:49 --> Controller Class Initialized
INFO - 2024-02-21 20:13:49 --> Form Validation Class Initialized
INFO - 2024-02-21 20:13:49 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:13:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:13:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:13:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:13:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:13:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:13:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:13:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:13:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:13:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:13:49 --> Final output sent to browser
DEBUG - 2024-02-21 20:13:49 --> Total execution time: 0.0286
ERROR - 2024-02-21 20:13:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:13:49 --> Config Class Initialized
INFO - 2024-02-21 20:13:49 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:13:49 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:13:49 --> Utf8 Class Initialized
INFO - 2024-02-21 20:13:49 --> URI Class Initialized
INFO - 2024-02-21 20:13:49 --> Router Class Initialized
INFO - 2024-02-21 20:13:49 --> Output Class Initialized
INFO - 2024-02-21 20:13:49 --> Security Class Initialized
DEBUG - 2024-02-21 20:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:13:49 --> Input Class Initialized
INFO - 2024-02-21 20:13:49 --> Language Class Initialized
INFO - 2024-02-21 20:13:49 --> Loader Class Initialized
INFO - 2024-02-21 20:13:49 --> Helper loaded: url_helper
INFO - 2024-02-21 20:13:49 --> Helper loaded: file_helper
INFO - 2024-02-21 20:13:49 --> Helper loaded: form_helper
INFO - 2024-02-21 20:13:49 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:13:49 --> Controller Class Initialized
INFO - 2024-02-21 20:13:49 --> Form Validation Class Initialized
INFO - 2024-02-21 20:13:49 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:13:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:13:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:13:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:13:49 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:13:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:13:54 --> Config Class Initialized
INFO - 2024-02-21 20:13:54 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:13:54 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:13:54 --> Utf8 Class Initialized
INFO - 2024-02-21 20:13:54 --> URI Class Initialized
INFO - 2024-02-21 20:13:54 --> Router Class Initialized
INFO - 2024-02-21 20:13:54 --> Output Class Initialized
INFO - 2024-02-21 20:13:54 --> Security Class Initialized
DEBUG - 2024-02-21 20:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:13:54 --> Input Class Initialized
INFO - 2024-02-21 20:13:54 --> Language Class Initialized
INFO - 2024-02-21 20:13:54 --> Loader Class Initialized
INFO - 2024-02-21 20:13:54 --> Helper loaded: url_helper
INFO - 2024-02-21 20:13:54 --> Helper loaded: file_helper
INFO - 2024-02-21 20:13:54 --> Helper loaded: form_helper
INFO - 2024-02-21 20:13:54 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:13:54 --> Controller Class Initialized
INFO - 2024-02-21 20:13:54 --> Form Validation Class Initialized
INFO - 2024-02-21 20:13:54 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:13:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:13:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:13:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:13:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:14:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:14:01 --> Config Class Initialized
INFO - 2024-02-21 20:14:01 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:14:01 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:14:01 --> Utf8 Class Initialized
INFO - 2024-02-21 20:14:01 --> URI Class Initialized
INFO - 2024-02-21 20:14:01 --> Router Class Initialized
INFO - 2024-02-21 20:14:01 --> Output Class Initialized
INFO - 2024-02-21 20:14:01 --> Security Class Initialized
DEBUG - 2024-02-21 20:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:14:01 --> Input Class Initialized
INFO - 2024-02-21 20:14:01 --> Language Class Initialized
INFO - 2024-02-21 20:14:01 --> Loader Class Initialized
INFO - 2024-02-21 20:14:01 --> Helper loaded: url_helper
INFO - 2024-02-21 20:14:01 --> Helper loaded: file_helper
INFO - 2024-02-21 20:14:01 --> Helper loaded: form_helper
INFO - 2024-02-21 20:14:01 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:14:01 --> Controller Class Initialized
INFO - 2024-02-21 20:14:01 --> Form Validation Class Initialized
INFO - 2024-02-21 20:14:01 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:14:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:14:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:14:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:14:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:14:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:14:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:14:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:14:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:14:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-21 20:14:01 --> Final output sent to browser
DEBUG - 2024-02-21 20:14:01 --> Total execution time: 0.0419
ERROR - 2024-02-21 20:14:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:14:01 --> Config Class Initialized
INFO - 2024-02-21 20:14:01 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:14:01 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:14:01 --> Utf8 Class Initialized
INFO - 2024-02-21 20:14:01 --> URI Class Initialized
INFO - 2024-02-21 20:14:01 --> Router Class Initialized
INFO - 2024-02-21 20:14:01 --> Output Class Initialized
INFO - 2024-02-21 20:14:01 --> Security Class Initialized
DEBUG - 2024-02-21 20:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:14:01 --> Input Class Initialized
INFO - 2024-02-21 20:14:01 --> Language Class Initialized
INFO - 2024-02-21 20:14:01 --> Loader Class Initialized
INFO - 2024-02-21 20:14:01 --> Helper loaded: url_helper
INFO - 2024-02-21 20:14:01 --> Helper loaded: file_helper
INFO - 2024-02-21 20:14:01 --> Helper loaded: form_helper
INFO - 2024-02-21 20:14:01 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:14:01 --> Controller Class Initialized
INFO - 2024-02-21 20:14:01 --> Form Validation Class Initialized
INFO - 2024-02-21 20:14:01 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:14:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:14:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:14:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:14:01 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:14:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:14:22 --> Config Class Initialized
INFO - 2024-02-21 20:14:22 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:14:22 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:14:22 --> Utf8 Class Initialized
INFO - 2024-02-21 20:14:22 --> URI Class Initialized
INFO - 2024-02-21 20:14:22 --> Router Class Initialized
INFO - 2024-02-21 20:14:22 --> Output Class Initialized
INFO - 2024-02-21 20:14:22 --> Security Class Initialized
DEBUG - 2024-02-21 20:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:14:22 --> Input Class Initialized
INFO - 2024-02-21 20:14:22 --> Language Class Initialized
INFO - 2024-02-21 20:14:22 --> Loader Class Initialized
INFO - 2024-02-21 20:14:22 --> Helper loaded: url_helper
INFO - 2024-02-21 20:14:22 --> Helper loaded: file_helper
INFO - 2024-02-21 20:14:22 --> Helper loaded: form_helper
INFO - 2024-02-21 20:14:22 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:14:22 --> Controller Class Initialized
INFO - 2024-02-21 20:14:22 --> Model "LoginModel" initialized
INFO - 2024-02-21 20:14:22 --> Form Validation Class Initialized
INFO - 2024-02-21 20:14:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-21 20:14:22 --> Final output sent to browser
DEBUG - 2024-02-21 20:14:22 --> Total execution time: 0.0273
ERROR - 2024-02-21 20:14:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:14:28 --> Config Class Initialized
INFO - 2024-02-21 20:14:28 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:14:28 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:14:28 --> Utf8 Class Initialized
INFO - 2024-02-21 20:14:28 --> URI Class Initialized
INFO - 2024-02-21 20:14:28 --> Router Class Initialized
INFO - 2024-02-21 20:14:28 --> Output Class Initialized
INFO - 2024-02-21 20:14:28 --> Security Class Initialized
DEBUG - 2024-02-21 20:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:14:28 --> Input Class Initialized
INFO - 2024-02-21 20:14:28 --> Language Class Initialized
INFO - 2024-02-21 20:14:28 --> Loader Class Initialized
INFO - 2024-02-21 20:14:28 --> Helper loaded: url_helper
INFO - 2024-02-21 20:14:28 --> Helper loaded: file_helper
INFO - 2024-02-21 20:14:28 --> Helper loaded: form_helper
INFO - 2024-02-21 20:14:28 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:14:28 --> Controller Class Initialized
INFO - 2024-02-21 20:14:28 --> Model "LoginModel" initialized
INFO - 2024-02-21 20:14:28 --> Form Validation Class Initialized
INFO - 2024-02-21 20:14:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-21 20:14:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:14:28 --> Config Class Initialized
INFO - 2024-02-21 20:14:28 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:14:28 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:14:28 --> Utf8 Class Initialized
INFO - 2024-02-21 20:14:28 --> URI Class Initialized
INFO - 2024-02-21 20:14:28 --> Router Class Initialized
INFO - 2024-02-21 20:14:28 --> Output Class Initialized
INFO - 2024-02-21 20:14:28 --> Security Class Initialized
DEBUG - 2024-02-21 20:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:14:28 --> Input Class Initialized
INFO - 2024-02-21 20:14:28 --> Language Class Initialized
INFO - 2024-02-21 20:14:28 --> Loader Class Initialized
INFO - 2024-02-21 20:14:28 --> Helper loaded: url_helper
INFO - 2024-02-21 20:14:28 --> Helper loaded: file_helper
INFO - 2024-02-21 20:14:28 --> Helper loaded: form_helper
INFO - 2024-02-21 20:14:28 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:14:28 --> Controller Class Initialized
INFO - 2024-02-21 20:14:28 --> Form Validation Class Initialized
INFO - 2024-02-21 20:14:28 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:14:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:14:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:14:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:14:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:14:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:14:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-21 20:14:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:14:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:14:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:14:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-21 20:14:28 --> Final output sent to browser
DEBUG - 2024-02-21 20:14:28 --> Total execution time: 0.0236
ERROR - 2024-02-21 20:14:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:14:31 --> Config Class Initialized
INFO - 2024-02-21 20:14:31 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:14:31 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:14:31 --> Utf8 Class Initialized
INFO - 2024-02-21 20:14:31 --> URI Class Initialized
INFO - 2024-02-21 20:14:31 --> Router Class Initialized
INFO - 2024-02-21 20:14:31 --> Output Class Initialized
INFO - 2024-02-21 20:14:31 --> Security Class Initialized
DEBUG - 2024-02-21 20:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:14:31 --> Input Class Initialized
INFO - 2024-02-21 20:14:31 --> Language Class Initialized
INFO - 2024-02-21 20:14:31 --> Loader Class Initialized
INFO - 2024-02-21 20:14:31 --> Helper loaded: url_helper
INFO - 2024-02-21 20:14:31 --> Helper loaded: file_helper
INFO - 2024-02-21 20:14:31 --> Helper loaded: form_helper
INFO - 2024-02-21 20:14:31 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:14:31 --> Controller Class Initialized
INFO - 2024-02-21 20:14:31 --> Form Validation Class Initialized
INFO - 2024-02-21 20:14:31 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:14:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:14:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:14:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:14:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:14:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:14:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:14:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:14:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:14:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-21 20:14:31 --> Final output sent to browser
DEBUG - 2024-02-21 20:14:31 --> Total execution time: 0.0410
ERROR - 2024-02-21 20:14:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:14:31 --> Config Class Initialized
INFO - 2024-02-21 20:14:31 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:14:31 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:14:31 --> Utf8 Class Initialized
INFO - 2024-02-21 20:14:31 --> URI Class Initialized
INFO - 2024-02-21 20:14:31 --> Router Class Initialized
INFO - 2024-02-21 20:14:31 --> Output Class Initialized
INFO - 2024-02-21 20:14:31 --> Security Class Initialized
DEBUG - 2024-02-21 20:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:14:31 --> Input Class Initialized
INFO - 2024-02-21 20:14:31 --> Language Class Initialized
INFO - 2024-02-21 20:14:31 --> Loader Class Initialized
INFO - 2024-02-21 20:14:31 --> Helper loaded: url_helper
INFO - 2024-02-21 20:14:31 --> Helper loaded: file_helper
INFO - 2024-02-21 20:14:31 --> Helper loaded: form_helper
INFO - 2024-02-21 20:14:31 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:14:31 --> Controller Class Initialized
INFO - 2024-02-21 20:14:31 --> Form Validation Class Initialized
INFO - 2024-02-21 20:14:31 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:14:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:14:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:14:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:14:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:14:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:14:34 --> Config Class Initialized
INFO - 2024-02-21 20:14:34 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:14:34 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:14:34 --> Utf8 Class Initialized
INFO - 2024-02-21 20:14:34 --> URI Class Initialized
INFO - 2024-02-21 20:14:34 --> Router Class Initialized
INFO - 2024-02-21 20:14:34 --> Output Class Initialized
INFO - 2024-02-21 20:14:34 --> Security Class Initialized
DEBUG - 2024-02-21 20:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:14:34 --> Input Class Initialized
INFO - 2024-02-21 20:14:34 --> Language Class Initialized
INFO - 2024-02-21 20:14:34 --> Loader Class Initialized
INFO - 2024-02-21 20:14:34 --> Helper loaded: url_helper
INFO - 2024-02-21 20:14:34 --> Helper loaded: file_helper
INFO - 2024-02-21 20:14:34 --> Helper loaded: form_helper
INFO - 2024-02-21 20:14:34 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:14:34 --> Controller Class Initialized
INFO - 2024-02-21 20:14:34 --> Form Validation Class Initialized
INFO - 2024-02-21 20:14:34 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:14:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:14:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:14:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:14:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:14:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-21 20:14:34 --> Final output sent to browser
DEBUG - 2024-02-21 20:14:34 --> Total execution time: 0.0432
ERROR - 2024-02-21 20:14:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:14:45 --> Config Class Initialized
INFO - 2024-02-21 20:14:45 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:14:45 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:14:45 --> Utf8 Class Initialized
INFO - 2024-02-21 20:14:45 --> URI Class Initialized
INFO - 2024-02-21 20:14:45 --> Router Class Initialized
INFO - 2024-02-21 20:14:45 --> Output Class Initialized
INFO - 2024-02-21 20:14:45 --> Security Class Initialized
DEBUG - 2024-02-21 20:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:14:45 --> Input Class Initialized
INFO - 2024-02-21 20:14:45 --> Language Class Initialized
INFO - 2024-02-21 20:14:45 --> Loader Class Initialized
INFO - 2024-02-21 20:14:45 --> Helper loaded: url_helper
INFO - 2024-02-21 20:14:45 --> Helper loaded: file_helper
INFO - 2024-02-21 20:14:45 --> Helper loaded: form_helper
INFO - 2024-02-21 20:14:45 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:14:45 --> Controller Class Initialized
INFO - 2024-02-21 20:14:45 --> Form Validation Class Initialized
INFO - 2024-02-21 20:14:45 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:14:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:14:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:14:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:14:45 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:24 --> Config Class Initialized
INFO - 2024-02-21 20:15:24 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:24 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:24 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:24 --> URI Class Initialized
INFO - 2024-02-21 20:15:24 --> Router Class Initialized
INFO - 2024-02-21 20:15:24 --> Output Class Initialized
INFO - 2024-02-21 20:15:24 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:24 --> Input Class Initialized
INFO - 2024-02-21 20:15:24 --> Language Class Initialized
INFO - 2024-02-21 20:15:24 --> Loader Class Initialized
INFO - 2024-02-21 20:15:24 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:24 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:24 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:24 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:25 --> Controller Class Initialized
INFO - 2024-02-21 20:15:25 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:25 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:25 --> Config Class Initialized
INFO - 2024-02-21 20:15:25 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:25 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:25 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:25 --> URI Class Initialized
INFO - 2024-02-21 20:15:25 --> Router Class Initialized
INFO - 2024-02-21 20:15:25 --> Output Class Initialized
INFO - 2024-02-21 20:15:25 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:25 --> Input Class Initialized
INFO - 2024-02-21 20:15:25 --> Language Class Initialized
INFO - 2024-02-21 20:15:25 --> Loader Class Initialized
INFO - 2024-02-21 20:15:25 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:25 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:25 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:25 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:25 --> Controller Class Initialized
INFO - 2024-02-21 20:15:25 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:25 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:26 --> Config Class Initialized
INFO - 2024-02-21 20:15:26 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:26 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:26 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:26 --> URI Class Initialized
INFO - 2024-02-21 20:15:26 --> Router Class Initialized
INFO - 2024-02-21 20:15:26 --> Output Class Initialized
INFO - 2024-02-21 20:15:26 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:26 --> Input Class Initialized
INFO - 2024-02-21 20:15:26 --> Language Class Initialized
INFO - 2024-02-21 20:15:26 --> Loader Class Initialized
INFO - 2024-02-21 20:15:26 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:26 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:26 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:26 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:26 --> Controller Class Initialized
INFO - 2024-02-21 20:15:26 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:26 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:15:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-21 20:15:26 --> Final output sent to browser
DEBUG - 2024-02-21 20:15:26 --> Total execution time: 0.0398
ERROR - 2024-02-21 20:15:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:33 --> Config Class Initialized
INFO - 2024-02-21 20:15:33 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:33 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:33 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:33 --> URI Class Initialized
INFO - 2024-02-21 20:15:33 --> Router Class Initialized
INFO - 2024-02-21 20:15:33 --> Output Class Initialized
INFO - 2024-02-21 20:15:33 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:33 --> Input Class Initialized
INFO - 2024-02-21 20:15:33 --> Language Class Initialized
INFO - 2024-02-21 20:15:33 --> Loader Class Initialized
INFO - 2024-02-21 20:15:33 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:33 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:33 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:33 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:33 --> Controller Class Initialized
INFO - 2024-02-21 20:15:33 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:33 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:33 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:33 --> Config Class Initialized
INFO - 2024-02-21 20:15:33 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:33 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:33 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:33 --> URI Class Initialized
INFO - 2024-02-21 20:15:33 --> Router Class Initialized
INFO - 2024-02-21 20:15:33 --> Output Class Initialized
INFO - 2024-02-21 20:15:33 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:33 --> Input Class Initialized
INFO - 2024-02-21 20:15:33 --> Language Class Initialized
INFO - 2024-02-21 20:15:33 --> Loader Class Initialized
INFO - 2024-02-21 20:15:33 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:33 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:33 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:33 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:33 --> Controller Class Initialized
INFO - 2024-02-21 20:15:33 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:33 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:33 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:34 --> Config Class Initialized
INFO - 2024-02-21 20:15:34 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:34 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:34 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:34 --> URI Class Initialized
INFO - 2024-02-21 20:15:34 --> Router Class Initialized
INFO - 2024-02-21 20:15:34 --> Output Class Initialized
INFO - 2024-02-21 20:15:34 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:34 --> Input Class Initialized
INFO - 2024-02-21 20:15:34 --> Language Class Initialized
INFO - 2024-02-21 20:15:34 --> Loader Class Initialized
INFO - 2024-02-21 20:15:34 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:34 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:34 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:34 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:34 --> Controller Class Initialized
INFO - 2024-02-21 20:15:34 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:34 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:15:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-21 20:15:34 --> Final output sent to browser
DEBUG - 2024-02-21 20:15:34 --> Total execution time: 0.0317
ERROR - 2024-02-21 20:15:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:38 --> Config Class Initialized
INFO - 2024-02-21 20:15:38 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:39 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:39 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:39 --> URI Class Initialized
INFO - 2024-02-21 20:15:39 --> Router Class Initialized
INFO - 2024-02-21 20:15:39 --> Output Class Initialized
INFO - 2024-02-21 20:15:39 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:39 --> Input Class Initialized
INFO - 2024-02-21 20:15:39 --> Language Class Initialized
INFO - 2024-02-21 20:15:39 --> Loader Class Initialized
INFO - 2024-02-21 20:15:39 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:39 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:39 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:39 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:39 --> Controller Class Initialized
INFO - 2024-02-21 20:15:39 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:39 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:39 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:39 --> Config Class Initialized
INFO - 2024-02-21 20:15:39 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:39 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:39 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:39 --> URI Class Initialized
INFO - 2024-02-21 20:15:39 --> Router Class Initialized
INFO - 2024-02-21 20:15:39 --> Output Class Initialized
INFO - 2024-02-21 20:15:39 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:39 --> Input Class Initialized
INFO - 2024-02-21 20:15:39 --> Language Class Initialized
INFO - 2024-02-21 20:15:39 --> Loader Class Initialized
INFO - 2024-02-21 20:15:39 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:39 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:39 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:39 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:39 --> Controller Class Initialized
INFO - 2024-02-21 20:15:39 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:39 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:39 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:39 --> Config Class Initialized
INFO - 2024-02-21 20:15:39 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:39 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:39 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:39 --> URI Class Initialized
INFO - 2024-02-21 20:15:39 --> Router Class Initialized
INFO - 2024-02-21 20:15:39 --> Output Class Initialized
INFO - 2024-02-21 20:15:39 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:39 --> Input Class Initialized
INFO - 2024-02-21 20:15:39 --> Language Class Initialized
INFO - 2024-02-21 20:15:39 --> Loader Class Initialized
INFO - 2024-02-21 20:15:39 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:39 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:39 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:39 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:39 --> Controller Class Initialized
INFO - 2024-02-21 20:15:39 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:40 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:15:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-21 20:15:40 --> Final output sent to browser
DEBUG - 2024-02-21 20:15:40 --> Total execution time: 0.0349
ERROR - 2024-02-21 20:15:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:44 --> Config Class Initialized
INFO - 2024-02-21 20:15:44 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:44 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:44 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:44 --> URI Class Initialized
INFO - 2024-02-21 20:15:44 --> Router Class Initialized
INFO - 2024-02-21 20:15:44 --> Output Class Initialized
INFO - 2024-02-21 20:15:44 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:44 --> Input Class Initialized
INFO - 2024-02-21 20:15:44 --> Language Class Initialized
INFO - 2024-02-21 20:15:44 --> Loader Class Initialized
INFO - 2024-02-21 20:15:44 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:44 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:44 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:44 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:44 --> Controller Class Initialized
INFO - 2024-02-21 20:15:44 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:44 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:44 --> Config Class Initialized
INFO - 2024-02-21 20:15:44 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:44 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:44 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:44 --> URI Class Initialized
INFO - 2024-02-21 20:15:44 --> Router Class Initialized
INFO - 2024-02-21 20:15:44 --> Output Class Initialized
INFO - 2024-02-21 20:15:44 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:44 --> Input Class Initialized
INFO - 2024-02-21 20:15:44 --> Language Class Initialized
INFO - 2024-02-21 20:15:44 --> Loader Class Initialized
INFO - 2024-02-21 20:15:44 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:44 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:44 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:44 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:44 --> Controller Class Initialized
INFO - 2024-02-21 20:15:44 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:44 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:44 --> Config Class Initialized
INFO - 2024-02-21 20:15:44 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:44 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:44 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:44 --> URI Class Initialized
INFO - 2024-02-21 20:15:44 --> Router Class Initialized
INFO - 2024-02-21 20:15:44 --> Output Class Initialized
INFO - 2024-02-21 20:15:44 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:44 --> Input Class Initialized
INFO - 2024-02-21 20:15:44 --> Language Class Initialized
INFO - 2024-02-21 20:15:44 --> Loader Class Initialized
INFO - 2024-02-21 20:15:44 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:44 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:44 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:44 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:44 --> Controller Class Initialized
INFO - 2024-02-21 20:15:44 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:44 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:15:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-21 20:15:44 --> Final output sent to browser
DEBUG - 2024-02-21 20:15:44 --> Total execution time: 0.0279
ERROR - 2024-02-21 20:15:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:48 --> Config Class Initialized
INFO - 2024-02-21 20:15:48 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:48 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:48 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:48 --> URI Class Initialized
INFO - 2024-02-21 20:15:48 --> Router Class Initialized
INFO - 2024-02-21 20:15:48 --> Output Class Initialized
INFO - 2024-02-21 20:15:48 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:48 --> Input Class Initialized
INFO - 2024-02-21 20:15:48 --> Language Class Initialized
INFO - 2024-02-21 20:15:48 --> Loader Class Initialized
INFO - 2024-02-21 20:15:48 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:48 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:48 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:48 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:48 --> Controller Class Initialized
INFO - 2024-02-21 20:15:48 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:48 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:48 --> Config Class Initialized
INFO - 2024-02-21 20:15:48 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:48 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:48 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:48 --> URI Class Initialized
INFO - 2024-02-21 20:15:48 --> Router Class Initialized
INFO - 2024-02-21 20:15:48 --> Output Class Initialized
INFO - 2024-02-21 20:15:48 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:48 --> Input Class Initialized
INFO - 2024-02-21 20:15:48 --> Language Class Initialized
INFO - 2024-02-21 20:15:48 --> Loader Class Initialized
INFO - 2024-02-21 20:15:48 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:48 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:48 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:48 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:48 --> Controller Class Initialized
INFO - 2024-02-21 20:15:48 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:48 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:49 --> Config Class Initialized
INFO - 2024-02-21 20:15:49 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:49 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:49 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:49 --> URI Class Initialized
INFO - 2024-02-21 20:15:49 --> Router Class Initialized
INFO - 2024-02-21 20:15:49 --> Output Class Initialized
INFO - 2024-02-21 20:15:49 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:49 --> Input Class Initialized
INFO - 2024-02-21 20:15:49 --> Language Class Initialized
INFO - 2024-02-21 20:15:49 --> Loader Class Initialized
INFO - 2024-02-21 20:15:49 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:49 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:49 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:49 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:49 --> Controller Class Initialized
INFO - 2024-02-21 20:15:49 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:49 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:15:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-21 20:15:49 --> Final output sent to browser
DEBUG - 2024-02-21 20:15:49 --> Total execution time: 0.0414
ERROR - 2024-02-21 20:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:53 --> Config Class Initialized
INFO - 2024-02-21 20:15:53 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:53 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:53 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:53 --> URI Class Initialized
INFO - 2024-02-21 20:15:53 --> Router Class Initialized
INFO - 2024-02-21 20:15:53 --> Output Class Initialized
INFO - 2024-02-21 20:15:53 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:53 --> Input Class Initialized
INFO - 2024-02-21 20:15:53 --> Language Class Initialized
INFO - 2024-02-21 20:15:53 --> Loader Class Initialized
INFO - 2024-02-21 20:15:53 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:53 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:53 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:53 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:53 --> Controller Class Initialized
INFO - 2024-02-21 20:15:53 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:53 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:53 --> Config Class Initialized
INFO - 2024-02-21 20:15:53 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:53 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:53 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:53 --> URI Class Initialized
INFO - 2024-02-21 20:15:53 --> Router Class Initialized
INFO - 2024-02-21 20:15:53 --> Output Class Initialized
INFO - 2024-02-21 20:15:53 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:53 --> Input Class Initialized
INFO - 2024-02-21 20:15:53 --> Language Class Initialized
INFO - 2024-02-21 20:15:53 --> Loader Class Initialized
INFO - 2024-02-21 20:15:53 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:53 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:53 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:53 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:53 --> Controller Class Initialized
INFO - 2024-02-21 20:15:53 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:53 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:55 --> Config Class Initialized
INFO - 2024-02-21 20:15:55 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:55 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:55 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:55 --> URI Class Initialized
INFO - 2024-02-21 20:15:55 --> Router Class Initialized
INFO - 2024-02-21 20:15:55 --> Output Class Initialized
INFO - 2024-02-21 20:15:55 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:55 --> Input Class Initialized
INFO - 2024-02-21 20:15:55 --> Language Class Initialized
INFO - 2024-02-21 20:15:55 --> Loader Class Initialized
INFO - 2024-02-21 20:15:55 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:55 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:55 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:55 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:55 --> Controller Class Initialized
INFO - 2024-02-21 20:15:55 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:55 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:15:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-21 20:15:55 --> Final output sent to browser
DEBUG - 2024-02-21 20:15:55 --> Total execution time: 0.0315
ERROR - 2024-02-21 20:15:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:59 --> Config Class Initialized
INFO - 2024-02-21 20:15:59 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:59 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:59 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:59 --> URI Class Initialized
INFO - 2024-02-21 20:15:59 --> Router Class Initialized
INFO - 2024-02-21 20:15:59 --> Output Class Initialized
INFO - 2024-02-21 20:15:59 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:59 --> Input Class Initialized
INFO - 2024-02-21 20:15:59 --> Language Class Initialized
INFO - 2024-02-21 20:15:59 --> Loader Class Initialized
INFO - 2024-02-21 20:15:59 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:59 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:59 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:59 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:59 --> Controller Class Initialized
INFO - 2024-02-21 20:15:59 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:59 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:15:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:15:59 --> Config Class Initialized
INFO - 2024-02-21 20:15:59 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:15:59 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:15:59 --> Utf8 Class Initialized
INFO - 2024-02-21 20:15:59 --> URI Class Initialized
INFO - 2024-02-21 20:15:59 --> Router Class Initialized
INFO - 2024-02-21 20:15:59 --> Output Class Initialized
INFO - 2024-02-21 20:15:59 --> Security Class Initialized
DEBUG - 2024-02-21 20:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:15:59 --> Input Class Initialized
INFO - 2024-02-21 20:15:59 --> Language Class Initialized
INFO - 2024-02-21 20:15:59 --> Loader Class Initialized
INFO - 2024-02-21 20:15:59 --> Helper loaded: url_helper
INFO - 2024-02-21 20:15:59 --> Helper loaded: file_helper
INFO - 2024-02-21 20:15:59 --> Helper loaded: form_helper
INFO - 2024-02-21 20:15:59 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:15:59 --> Controller Class Initialized
INFO - 2024-02-21 20:15:59 --> Form Validation Class Initialized
INFO - 2024-02-21 20:15:59 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:15:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:15:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:15:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:15:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:16:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:16:00 --> Config Class Initialized
INFO - 2024-02-21 20:16:00 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:16:00 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:16:00 --> Utf8 Class Initialized
INFO - 2024-02-21 20:16:00 --> URI Class Initialized
INFO - 2024-02-21 20:16:00 --> Router Class Initialized
INFO - 2024-02-21 20:16:00 --> Output Class Initialized
INFO - 2024-02-21 20:16:00 --> Security Class Initialized
DEBUG - 2024-02-21 20:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:16:00 --> Input Class Initialized
INFO - 2024-02-21 20:16:00 --> Language Class Initialized
INFO - 2024-02-21 20:16:00 --> Loader Class Initialized
INFO - 2024-02-21 20:16:00 --> Helper loaded: url_helper
INFO - 2024-02-21 20:16:00 --> Helper loaded: file_helper
INFO - 2024-02-21 20:16:00 --> Helper loaded: form_helper
INFO - 2024-02-21 20:16:00 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:16:00 --> Controller Class Initialized
INFO - 2024-02-21 20:16:00 --> Form Validation Class Initialized
INFO - 2024-02-21 20:16:00 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:16:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:16:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:16:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:16:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:16:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/form.php
INFO - 2024-02-21 20:16:00 --> Final output sent to browser
DEBUG - 2024-02-21 20:16:00 --> Total execution time: 0.0301
ERROR - 2024-02-21 20:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:16:03 --> Config Class Initialized
INFO - 2024-02-21 20:16:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:16:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:16:03 --> Utf8 Class Initialized
INFO - 2024-02-21 20:16:03 --> URI Class Initialized
INFO - 2024-02-21 20:16:03 --> Router Class Initialized
INFO - 2024-02-21 20:16:03 --> Output Class Initialized
INFO - 2024-02-21 20:16:03 --> Security Class Initialized
DEBUG - 2024-02-21 20:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:16:03 --> Input Class Initialized
INFO - 2024-02-21 20:16:03 --> Language Class Initialized
INFO - 2024-02-21 20:16:03 --> Loader Class Initialized
INFO - 2024-02-21 20:16:03 --> Helper loaded: url_helper
INFO - 2024-02-21 20:16:03 --> Helper loaded: file_helper
INFO - 2024-02-21 20:16:03 --> Helper loaded: form_helper
INFO - 2024-02-21 20:16:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:16:03 --> Controller Class Initialized
INFO - 2024-02-21 20:16:03 --> Form Validation Class Initialized
INFO - 2024-02-21 20:16:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:16:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:16:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:16:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:16:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:16:03 --> Config Class Initialized
INFO - 2024-02-21 20:16:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:16:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:16:03 --> Utf8 Class Initialized
INFO - 2024-02-21 20:16:03 --> URI Class Initialized
INFO - 2024-02-21 20:16:03 --> Router Class Initialized
INFO - 2024-02-21 20:16:03 --> Output Class Initialized
INFO - 2024-02-21 20:16:03 --> Security Class Initialized
DEBUG - 2024-02-21 20:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:16:03 --> Input Class Initialized
INFO - 2024-02-21 20:16:03 --> Language Class Initialized
INFO - 2024-02-21 20:16:03 --> Loader Class Initialized
INFO - 2024-02-21 20:16:03 --> Helper loaded: url_helper
INFO - 2024-02-21 20:16:03 --> Helper loaded: file_helper
INFO - 2024-02-21 20:16:03 --> Helper loaded: form_helper
INFO - 2024-02-21 20:16:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:16:03 --> Controller Class Initialized
INFO - 2024-02-21 20:16:03 --> Form Validation Class Initialized
INFO - 2024-02-21 20:16:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:16:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:16:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:16:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:16:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:16:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:16:06 --> Config Class Initialized
INFO - 2024-02-21 20:16:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:16:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:16:06 --> Utf8 Class Initialized
INFO - 2024-02-21 20:16:06 --> URI Class Initialized
INFO - 2024-02-21 20:16:06 --> Router Class Initialized
INFO - 2024-02-21 20:16:06 --> Output Class Initialized
INFO - 2024-02-21 20:16:06 --> Security Class Initialized
DEBUG - 2024-02-21 20:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:16:06 --> Input Class Initialized
INFO - 2024-02-21 20:16:06 --> Language Class Initialized
INFO - 2024-02-21 20:16:06 --> Loader Class Initialized
INFO - 2024-02-21 20:16:06 --> Helper loaded: url_helper
INFO - 2024-02-21 20:16:06 --> Helper loaded: file_helper
INFO - 2024-02-21 20:16:06 --> Helper loaded: form_helper
INFO - 2024-02-21 20:16:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:16:06 --> Controller Class Initialized
INFO - 2024-02-21 20:16:06 --> Form Validation Class Initialized
INFO - 2024-02-21 20:16:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:16:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:16:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:16:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:16:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:16:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:16:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:16:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:16:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:16:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-21 20:16:06 --> Final output sent to browser
DEBUG - 2024-02-21 20:16:06 --> Total execution time: 0.0418
ERROR - 2024-02-21 20:16:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:16:06 --> Config Class Initialized
INFO - 2024-02-21 20:16:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:16:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:16:06 --> Utf8 Class Initialized
INFO - 2024-02-21 20:16:06 --> URI Class Initialized
INFO - 2024-02-21 20:16:06 --> Router Class Initialized
INFO - 2024-02-21 20:16:06 --> Output Class Initialized
INFO - 2024-02-21 20:16:06 --> Security Class Initialized
DEBUG - 2024-02-21 20:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:16:06 --> Input Class Initialized
INFO - 2024-02-21 20:16:06 --> Language Class Initialized
INFO - 2024-02-21 20:16:06 --> Loader Class Initialized
INFO - 2024-02-21 20:16:06 --> Helper loaded: url_helper
INFO - 2024-02-21 20:16:06 --> Helper loaded: file_helper
INFO - 2024-02-21 20:16:06 --> Helper loaded: form_helper
INFO - 2024-02-21 20:16:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:16:06 --> Controller Class Initialized
INFO - 2024-02-21 20:16:06 --> Form Validation Class Initialized
INFO - 2024-02-21 20:16:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:16:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:16:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:16:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:16:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:16:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:16:08 --> Config Class Initialized
INFO - 2024-02-21 20:16:08 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:16:08 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:16:08 --> Utf8 Class Initialized
INFO - 2024-02-21 20:16:08 --> URI Class Initialized
INFO - 2024-02-21 20:16:08 --> Router Class Initialized
INFO - 2024-02-21 20:16:08 --> Output Class Initialized
INFO - 2024-02-21 20:16:08 --> Security Class Initialized
DEBUG - 2024-02-21 20:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:16:08 --> Input Class Initialized
INFO - 2024-02-21 20:16:08 --> Language Class Initialized
INFO - 2024-02-21 20:16:08 --> Loader Class Initialized
INFO - 2024-02-21 20:16:08 --> Helper loaded: url_helper
INFO - 2024-02-21 20:16:08 --> Helper loaded: file_helper
INFO - 2024-02-21 20:16:08 --> Helper loaded: form_helper
INFO - 2024-02-21 20:16:08 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:16:08 --> Controller Class Initialized
INFO - 2024-02-21 20:16:08 --> Form Validation Class Initialized
INFO - 2024-02-21 20:16:08 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:16:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:16:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:16:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:16:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:16:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:16:08 --> Final output sent to browser
DEBUG - 2024-02-21 20:16:08 --> Total execution time: 0.0395
ERROR - 2024-02-21 20:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:19:58 --> Config Class Initialized
INFO - 2024-02-21 20:19:58 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:19:58 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:19:58 --> Utf8 Class Initialized
INFO - 2024-02-21 20:19:58 --> URI Class Initialized
INFO - 2024-02-21 20:19:58 --> Router Class Initialized
INFO - 2024-02-21 20:19:58 --> Output Class Initialized
INFO - 2024-02-21 20:19:58 --> Security Class Initialized
DEBUG - 2024-02-21 20:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:19:58 --> Input Class Initialized
INFO - 2024-02-21 20:19:58 --> Language Class Initialized
INFO - 2024-02-21 20:19:58 --> Loader Class Initialized
INFO - 2024-02-21 20:19:58 --> Helper loaded: url_helper
INFO - 2024-02-21 20:19:58 --> Helper loaded: file_helper
INFO - 2024-02-21 20:19:58 --> Helper loaded: form_helper
INFO - 2024-02-21 20:19:58 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:19:58 --> Controller Class Initialized
INFO - 2024-02-21 20:19:58 --> Form Validation Class Initialized
INFO - 2024-02-21 20:19:58 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:19:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:19:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:19:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:19:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:19:58 --> Config Class Initialized
INFO - 2024-02-21 20:19:58 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:19:58 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:19:58 --> Utf8 Class Initialized
INFO - 2024-02-21 20:19:58 --> URI Class Initialized
INFO - 2024-02-21 20:19:58 --> Router Class Initialized
INFO - 2024-02-21 20:19:58 --> Output Class Initialized
INFO - 2024-02-21 20:19:58 --> Security Class Initialized
DEBUG - 2024-02-21 20:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:19:58 --> Input Class Initialized
INFO - 2024-02-21 20:19:58 --> Language Class Initialized
INFO - 2024-02-21 20:19:58 --> Loader Class Initialized
INFO - 2024-02-21 20:19:58 --> Helper loaded: url_helper
INFO - 2024-02-21 20:19:58 --> Helper loaded: file_helper
INFO - 2024-02-21 20:19:58 --> Helper loaded: form_helper
INFO - 2024-02-21 20:19:58 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:19:58 --> Controller Class Initialized
INFO - 2024-02-21 20:19:58 --> Form Validation Class Initialized
INFO - 2024-02-21 20:19:58 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:19:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:19:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:19:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:19:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:20:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:20:05 --> Config Class Initialized
INFO - 2024-02-21 20:20:05 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:20:05 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:20:05 --> Utf8 Class Initialized
INFO - 2024-02-21 20:20:05 --> URI Class Initialized
INFO - 2024-02-21 20:20:05 --> Router Class Initialized
INFO - 2024-02-21 20:20:05 --> Output Class Initialized
INFO - 2024-02-21 20:20:05 --> Security Class Initialized
DEBUG - 2024-02-21 20:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:20:05 --> Input Class Initialized
INFO - 2024-02-21 20:20:05 --> Language Class Initialized
INFO - 2024-02-21 20:20:05 --> Loader Class Initialized
INFO - 2024-02-21 20:20:05 --> Helper loaded: url_helper
INFO - 2024-02-21 20:20:05 --> Helper loaded: file_helper
INFO - 2024-02-21 20:20:05 --> Helper loaded: form_helper
INFO - 2024-02-21 20:20:05 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:20:05 --> Controller Class Initialized
INFO - 2024-02-21 20:20:05 --> Form Validation Class Initialized
INFO - 2024-02-21 20:20:05 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:20:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:20:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:20:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:20:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:20:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:20:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:20:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:20:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:20:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-21 20:20:05 --> Final output sent to browser
DEBUG - 2024-02-21 20:20:05 --> Total execution time: 0.0385
ERROR - 2024-02-21 20:20:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:20:09 --> Config Class Initialized
INFO - 2024-02-21 20:20:09 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:20:09 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:20:09 --> Utf8 Class Initialized
INFO - 2024-02-21 20:20:09 --> URI Class Initialized
INFO - 2024-02-21 20:20:09 --> Router Class Initialized
INFO - 2024-02-21 20:20:09 --> Output Class Initialized
INFO - 2024-02-21 20:20:09 --> Security Class Initialized
DEBUG - 2024-02-21 20:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:20:09 --> Input Class Initialized
INFO - 2024-02-21 20:20:09 --> Language Class Initialized
INFO - 2024-02-21 20:20:09 --> Loader Class Initialized
INFO - 2024-02-21 20:20:09 --> Helper loaded: url_helper
INFO - 2024-02-21 20:20:09 --> Helper loaded: file_helper
INFO - 2024-02-21 20:20:09 --> Helper loaded: form_helper
INFO - 2024-02-21 20:20:09 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:20:09 --> Controller Class Initialized
INFO - 2024-02-21 20:20:09 --> Form Validation Class Initialized
INFO - 2024-02-21 20:20:09 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:20:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:20:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:20:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:20:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:20:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:20:09 --> Final output sent to browser
DEBUG - 2024-02-21 20:20:09 --> Total execution time: 0.0401
ERROR - 2024-02-21 20:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:20:14 --> Config Class Initialized
INFO - 2024-02-21 20:20:14 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:20:14 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:20:14 --> Utf8 Class Initialized
INFO - 2024-02-21 20:20:14 --> URI Class Initialized
INFO - 2024-02-21 20:20:14 --> Router Class Initialized
INFO - 2024-02-21 20:20:14 --> Output Class Initialized
INFO - 2024-02-21 20:20:14 --> Security Class Initialized
DEBUG - 2024-02-21 20:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:20:14 --> Input Class Initialized
INFO - 2024-02-21 20:20:14 --> Language Class Initialized
INFO - 2024-02-21 20:20:14 --> Loader Class Initialized
INFO - 2024-02-21 20:20:14 --> Helper loaded: url_helper
INFO - 2024-02-21 20:20:14 --> Helper loaded: file_helper
INFO - 2024-02-21 20:20:14 --> Helper loaded: form_helper
INFO - 2024-02-21 20:20:14 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:20:14 --> Controller Class Initialized
INFO - 2024-02-21 20:20:14 --> Form Validation Class Initialized
INFO - 2024-02-21 20:20:14 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:20:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:20:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:20:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:20:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:20:14 --> Config Class Initialized
INFO - 2024-02-21 20:20:14 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:20:14 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:20:14 --> Utf8 Class Initialized
INFO - 2024-02-21 20:20:14 --> URI Class Initialized
INFO - 2024-02-21 20:20:14 --> Router Class Initialized
INFO - 2024-02-21 20:20:14 --> Output Class Initialized
INFO - 2024-02-21 20:20:14 --> Security Class Initialized
DEBUG - 2024-02-21 20:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:20:14 --> Input Class Initialized
INFO - 2024-02-21 20:20:14 --> Language Class Initialized
INFO - 2024-02-21 20:20:14 --> Loader Class Initialized
INFO - 2024-02-21 20:20:14 --> Helper loaded: url_helper
INFO - 2024-02-21 20:20:14 --> Helper loaded: file_helper
INFO - 2024-02-21 20:20:14 --> Helper loaded: form_helper
INFO - 2024-02-21 20:20:14 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:20:14 --> Controller Class Initialized
INFO - 2024-02-21 20:20:14 --> Form Validation Class Initialized
INFO - 2024-02-21 20:20:14 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:20:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:20:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:20:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:20:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:20:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:20:32 --> Config Class Initialized
INFO - 2024-02-21 20:20:32 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:20:32 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:20:32 --> Utf8 Class Initialized
INFO - 2024-02-21 20:20:32 --> URI Class Initialized
INFO - 2024-02-21 20:20:32 --> Router Class Initialized
INFO - 2024-02-21 20:20:32 --> Output Class Initialized
INFO - 2024-02-21 20:20:32 --> Security Class Initialized
DEBUG - 2024-02-21 20:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:20:32 --> Input Class Initialized
INFO - 2024-02-21 20:20:32 --> Language Class Initialized
INFO - 2024-02-21 20:20:32 --> Loader Class Initialized
INFO - 2024-02-21 20:20:32 --> Helper loaded: url_helper
INFO - 2024-02-21 20:20:32 --> Helper loaded: file_helper
INFO - 2024-02-21 20:20:32 --> Helper loaded: form_helper
INFO - 2024-02-21 20:20:32 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:20:32 --> Controller Class Initialized
INFO - 2024-02-21 20:20:32 --> Form Validation Class Initialized
INFO - 2024-02-21 20:20:32 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:20:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:20:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:20:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:20:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:20:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:20:32 --> Final output sent to browser
DEBUG - 2024-02-21 20:20:32 --> Total execution time: 0.0317
ERROR - 2024-02-21 20:21:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:21:20 --> Config Class Initialized
INFO - 2024-02-21 20:21:20 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:21:20 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:21:20 --> Utf8 Class Initialized
INFO - 2024-02-21 20:21:20 --> URI Class Initialized
INFO - 2024-02-21 20:21:20 --> Router Class Initialized
INFO - 2024-02-21 20:21:20 --> Output Class Initialized
INFO - 2024-02-21 20:21:20 --> Security Class Initialized
DEBUG - 2024-02-21 20:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:21:20 --> Input Class Initialized
INFO - 2024-02-21 20:21:20 --> Language Class Initialized
INFO - 2024-02-21 20:21:20 --> Loader Class Initialized
INFO - 2024-02-21 20:21:20 --> Helper loaded: url_helper
INFO - 2024-02-21 20:21:20 --> Helper loaded: file_helper
INFO - 2024-02-21 20:21:20 --> Helper loaded: form_helper
INFO - 2024-02-21 20:21:20 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:21:20 --> Controller Class Initialized
INFO - 2024-02-21 20:21:20 --> Form Validation Class Initialized
INFO - 2024-02-21 20:21:20 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:21:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:21:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:21:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:21:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:21:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:21:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:21:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:21:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:21:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-21 20:21:20 --> Final output sent to browser
DEBUG - 2024-02-21 20:21:20 --> Total execution time: 0.0360
ERROR - 2024-02-21 20:21:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:21:21 --> Config Class Initialized
INFO - 2024-02-21 20:21:21 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:21:21 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:21:21 --> Utf8 Class Initialized
INFO - 2024-02-21 20:21:21 --> URI Class Initialized
INFO - 2024-02-21 20:21:21 --> Router Class Initialized
INFO - 2024-02-21 20:21:21 --> Output Class Initialized
INFO - 2024-02-21 20:21:21 --> Security Class Initialized
DEBUG - 2024-02-21 20:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:21:21 --> Input Class Initialized
INFO - 2024-02-21 20:21:21 --> Language Class Initialized
INFO - 2024-02-21 20:21:21 --> Loader Class Initialized
INFO - 2024-02-21 20:21:21 --> Helper loaded: url_helper
INFO - 2024-02-21 20:21:21 --> Helper loaded: file_helper
INFO - 2024-02-21 20:21:21 --> Helper loaded: form_helper
INFO - 2024-02-21 20:21:21 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:21:21 --> Controller Class Initialized
INFO - 2024-02-21 20:21:21 --> Form Validation Class Initialized
INFO - 2024-02-21 20:21:21 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:21:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:21:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:21:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:21:21 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:21:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:21:24 --> Config Class Initialized
INFO - 2024-02-21 20:21:24 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:21:24 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:21:24 --> Utf8 Class Initialized
INFO - 2024-02-21 20:21:24 --> URI Class Initialized
INFO - 2024-02-21 20:21:24 --> Router Class Initialized
INFO - 2024-02-21 20:21:24 --> Output Class Initialized
INFO - 2024-02-21 20:21:24 --> Security Class Initialized
DEBUG - 2024-02-21 20:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:21:24 --> Input Class Initialized
INFO - 2024-02-21 20:21:24 --> Language Class Initialized
INFO - 2024-02-21 20:21:24 --> Loader Class Initialized
INFO - 2024-02-21 20:21:24 --> Helper loaded: url_helper
INFO - 2024-02-21 20:21:24 --> Helper loaded: file_helper
INFO - 2024-02-21 20:21:24 --> Helper loaded: form_helper
INFO - 2024-02-21 20:21:24 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:21:24 --> Controller Class Initialized
INFO - 2024-02-21 20:21:24 --> Form Validation Class Initialized
INFO - 2024-02-21 20:21:24 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:21:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:21:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:21:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:21:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:21:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:21:24 --> Final output sent to browser
DEBUG - 2024-02-21 20:21:24 --> Total execution time: 0.0394
ERROR - 2024-02-21 20:21:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:21:29 --> Config Class Initialized
INFO - 2024-02-21 20:21:29 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:21:29 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:21:29 --> Utf8 Class Initialized
INFO - 2024-02-21 20:21:29 --> URI Class Initialized
INFO - 2024-02-21 20:21:29 --> Router Class Initialized
INFO - 2024-02-21 20:21:29 --> Output Class Initialized
INFO - 2024-02-21 20:21:29 --> Security Class Initialized
DEBUG - 2024-02-21 20:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:21:29 --> Input Class Initialized
INFO - 2024-02-21 20:21:29 --> Language Class Initialized
INFO - 2024-02-21 20:21:29 --> Loader Class Initialized
INFO - 2024-02-21 20:21:29 --> Helper loaded: url_helper
INFO - 2024-02-21 20:21:29 --> Helper loaded: file_helper
INFO - 2024-02-21 20:21:29 --> Helper loaded: form_helper
INFO - 2024-02-21 20:21:29 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:21:29 --> Controller Class Initialized
INFO - 2024-02-21 20:21:29 --> Form Validation Class Initialized
INFO - 2024-02-21 20:21:29 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:21:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:21:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:21:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:21:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:21:29 --> Upload Class Initialized
INFO - 2024-02-21 20:21:29 --> Image Lib Class Initialized
ERROR - 2024-02-21 20:21:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:21:29 --> Config Class Initialized
INFO - 2024-02-21 20:21:29 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:21:29 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:21:29 --> Utf8 Class Initialized
INFO - 2024-02-21 20:21:29 --> URI Class Initialized
INFO - 2024-02-21 20:21:29 --> Router Class Initialized
INFO - 2024-02-21 20:21:29 --> Output Class Initialized
INFO - 2024-02-21 20:21:29 --> Security Class Initialized
DEBUG - 2024-02-21 20:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:21:29 --> Input Class Initialized
INFO - 2024-02-21 20:21:29 --> Language Class Initialized
INFO - 2024-02-21 20:21:29 --> Loader Class Initialized
INFO - 2024-02-21 20:21:29 --> Helper loaded: url_helper
INFO - 2024-02-21 20:21:29 --> Helper loaded: file_helper
INFO - 2024-02-21 20:21:29 --> Helper loaded: form_helper
INFO - 2024-02-21 20:21:29 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:21:29 --> Controller Class Initialized
INFO - 2024-02-21 20:21:29 --> Form Validation Class Initialized
INFO - 2024-02-21 20:21:29 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:21:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:21:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:21:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:21:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:21:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:21:32 --> Config Class Initialized
INFO - 2024-02-21 20:21:32 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:21:32 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:21:32 --> Utf8 Class Initialized
INFO - 2024-02-21 20:21:32 --> URI Class Initialized
INFO - 2024-02-21 20:21:32 --> Router Class Initialized
INFO - 2024-02-21 20:21:32 --> Output Class Initialized
INFO - 2024-02-21 20:21:32 --> Security Class Initialized
DEBUG - 2024-02-21 20:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:21:32 --> Input Class Initialized
INFO - 2024-02-21 20:21:32 --> Language Class Initialized
INFO - 2024-02-21 20:21:32 --> Loader Class Initialized
INFO - 2024-02-21 20:21:32 --> Helper loaded: url_helper
INFO - 2024-02-21 20:21:32 --> Helper loaded: file_helper
INFO - 2024-02-21 20:21:32 --> Helper loaded: form_helper
INFO - 2024-02-21 20:21:32 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:21:32 --> Controller Class Initialized
INFO - 2024-02-21 20:21:32 --> Form Validation Class Initialized
INFO - 2024-02-21 20:21:32 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:21:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:21:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:21:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:21:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:21:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:21:32 --> Final output sent to browser
DEBUG - 2024-02-21 20:21:32 --> Total execution time: 0.0332
ERROR - 2024-02-21 20:21:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:21:55 --> Config Class Initialized
INFO - 2024-02-21 20:21:55 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:21:55 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:21:55 --> Utf8 Class Initialized
INFO - 2024-02-21 20:21:55 --> URI Class Initialized
INFO - 2024-02-21 20:21:55 --> Router Class Initialized
INFO - 2024-02-21 20:21:55 --> Output Class Initialized
INFO - 2024-02-21 20:21:55 --> Security Class Initialized
DEBUG - 2024-02-21 20:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:21:55 --> Input Class Initialized
INFO - 2024-02-21 20:21:55 --> Language Class Initialized
INFO - 2024-02-21 20:21:55 --> Loader Class Initialized
INFO - 2024-02-21 20:21:55 --> Helper loaded: url_helper
INFO - 2024-02-21 20:21:55 --> Helper loaded: file_helper
INFO - 2024-02-21 20:21:55 --> Helper loaded: form_helper
INFO - 2024-02-21 20:21:55 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:21:55 --> Controller Class Initialized
INFO - 2024-02-21 20:21:55 --> Form Validation Class Initialized
INFO - 2024-02-21 20:21:55 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:21:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:21:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:21:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:21:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:21:55 --> Upload Class Initialized
INFO - 2024-02-21 20:21:55 --> Image Lib Class Initialized
ERROR - 2024-02-21 20:21:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:21:55 --> Config Class Initialized
INFO - 2024-02-21 20:21:55 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:21:55 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:21:55 --> Utf8 Class Initialized
INFO - 2024-02-21 20:21:55 --> URI Class Initialized
INFO - 2024-02-21 20:21:55 --> Router Class Initialized
INFO - 2024-02-21 20:21:55 --> Output Class Initialized
INFO - 2024-02-21 20:21:55 --> Security Class Initialized
DEBUG - 2024-02-21 20:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:21:55 --> Input Class Initialized
INFO - 2024-02-21 20:21:55 --> Language Class Initialized
INFO - 2024-02-21 20:21:55 --> Loader Class Initialized
INFO - 2024-02-21 20:21:55 --> Helper loaded: url_helper
INFO - 2024-02-21 20:21:55 --> Helper loaded: file_helper
INFO - 2024-02-21 20:21:55 --> Helper loaded: form_helper
INFO - 2024-02-21 20:21:55 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:21:55 --> Controller Class Initialized
INFO - 2024-02-21 20:21:55 --> Form Validation Class Initialized
INFO - 2024-02-21 20:21:55 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:21:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:21:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:21:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:21:55 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:01 --> Config Class Initialized
INFO - 2024-02-21 20:22:01 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:01 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:01 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:01 --> URI Class Initialized
INFO - 2024-02-21 20:22:01 --> Router Class Initialized
INFO - 2024-02-21 20:22:01 --> Output Class Initialized
INFO - 2024-02-21 20:22:01 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:01 --> Input Class Initialized
INFO - 2024-02-21 20:22:01 --> Language Class Initialized
INFO - 2024-02-21 20:22:01 --> Loader Class Initialized
INFO - 2024-02-21 20:22:01 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:01 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:01 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:01 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:01 --> Controller Class Initialized
INFO - 2024-02-21 20:22:01 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:01 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:22:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:22:01 --> Final output sent to browser
DEBUG - 2024-02-21 20:22:01 --> Total execution time: 0.0470
ERROR - 2024-02-21 20:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:17 --> Config Class Initialized
INFO - 2024-02-21 20:22:17 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:17 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:17 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:17 --> URI Class Initialized
INFO - 2024-02-21 20:22:17 --> Router Class Initialized
INFO - 2024-02-21 20:22:17 --> Output Class Initialized
INFO - 2024-02-21 20:22:17 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:17 --> Input Class Initialized
INFO - 2024-02-21 20:22:17 --> Language Class Initialized
INFO - 2024-02-21 20:22:17 --> Loader Class Initialized
INFO - 2024-02-21 20:22:17 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:17 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:17 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:17 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:17 --> Controller Class Initialized
INFO - 2024-02-21 20:22:17 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:17 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:22:17 --> Upload Class Initialized
INFO - 2024-02-21 20:22:17 --> Image Lib Class Initialized
ERROR - 2024-02-21 20:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:17 --> Config Class Initialized
INFO - 2024-02-21 20:22:17 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:17 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:17 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:17 --> URI Class Initialized
INFO - 2024-02-21 20:22:17 --> Router Class Initialized
INFO - 2024-02-21 20:22:17 --> Output Class Initialized
INFO - 2024-02-21 20:22:17 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:17 --> Input Class Initialized
INFO - 2024-02-21 20:22:17 --> Language Class Initialized
INFO - 2024-02-21 20:22:17 --> Loader Class Initialized
INFO - 2024-02-21 20:22:17 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:17 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:17 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:17 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:17 --> Controller Class Initialized
INFO - 2024-02-21 20:22:17 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:17 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:17 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:22:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:22 --> Config Class Initialized
INFO - 2024-02-21 20:22:22 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:22 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:22 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:22 --> URI Class Initialized
INFO - 2024-02-21 20:22:22 --> Router Class Initialized
INFO - 2024-02-21 20:22:22 --> Output Class Initialized
INFO - 2024-02-21 20:22:22 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:22 --> Input Class Initialized
INFO - 2024-02-21 20:22:22 --> Language Class Initialized
INFO - 2024-02-21 20:22:22 --> Loader Class Initialized
INFO - 2024-02-21 20:22:22 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:22 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:22 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:22 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:22 --> Controller Class Initialized
INFO - 2024-02-21 20:22:22 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:22 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:22:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:22:22 --> Final output sent to browser
DEBUG - 2024-02-21 20:22:22 --> Total execution time: 0.0482
ERROR - 2024-02-21 20:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:38 --> Config Class Initialized
INFO - 2024-02-21 20:22:38 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:38 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:38 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:38 --> URI Class Initialized
INFO - 2024-02-21 20:22:38 --> Router Class Initialized
INFO - 2024-02-21 20:22:38 --> Output Class Initialized
INFO - 2024-02-21 20:22:38 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:38 --> Input Class Initialized
INFO - 2024-02-21 20:22:38 --> Language Class Initialized
INFO - 2024-02-21 20:22:38 --> Loader Class Initialized
INFO - 2024-02-21 20:22:38 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:38 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:38 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:38 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:38 --> Controller Class Initialized
INFO - 2024-02-21 20:22:38 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:38 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:22:38 --> Upload Class Initialized
INFO - 2024-02-21 20:22:38 --> Image Lib Class Initialized
ERROR - 2024-02-21 20:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:38 --> Config Class Initialized
INFO - 2024-02-21 20:22:38 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:38 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:38 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:38 --> URI Class Initialized
INFO - 2024-02-21 20:22:38 --> Router Class Initialized
INFO - 2024-02-21 20:22:38 --> Output Class Initialized
INFO - 2024-02-21 20:22:38 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:38 --> Input Class Initialized
INFO - 2024-02-21 20:22:38 --> Language Class Initialized
INFO - 2024-02-21 20:22:38 --> Loader Class Initialized
INFO - 2024-02-21 20:22:38 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:38 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:38 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:38 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:38 --> Controller Class Initialized
INFO - 2024-02-21 20:22:38 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:38 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:22:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:40 --> Config Class Initialized
INFO - 2024-02-21 20:22:40 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:40 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:40 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:40 --> URI Class Initialized
INFO - 2024-02-21 20:22:40 --> Router Class Initialized
INFO - 2024-02-21 20:22:40 --> Output Class Initialized
INFO - 2024-02-21 20:22:40 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:40 --> Input Class Initialized
INFO - 2024-02-21 20:22:40 --> Language Class Initialized
INFO - 2024-02-21 20:22:40 --> Loader Class Initialized
INFO - 2024-02-21 20:22:40 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:40 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:40 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:40 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:40 --> Controller Class Initialized
INFO - 2024-02-21 20:22:40 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:40 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:40 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:22:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:45 --> Config Class Initialized
INFO - 2024-02-21 20:22:45 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:45 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:45 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:45 --> URI Class Initialized
INFO - 2024-02-21 20:22:45 --> Router Class Initialized
INFO - 2024-02-21 20:22:45 --> Output Class Initialized
INFO - 2024-02-21 20:22:45 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:45 --> Input Class Initialized
INFO - 2024-02-21 20:22:45 --> Language Class Initialized
INFO - 2024-02-21 20:22:45 --> Loader Class Initialized
INFO - 2024-02-21 20:22:45 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:45 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:45 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:45 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:45 --> Controller Class Initialized
INFO - 2024-02-21 20:22:45 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:45 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:22:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:22:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:22:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:22:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:22:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-21 20:22:45 --> Final output sent to browser
DEBUG - 2024-02-21 20:22:45 --> Total execution time: 0.0320
ERROR - 2024-02-21 20:22:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:45 --> Config Class Initialized
INFO - 2024-02-21 20:22:45 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:45 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:45 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:45 --> URI Class Initialized
INFO - 2024-02-21 20:22:45 --> Router Class Initialized
INFO - 2024-02-21 20:22:45 --> Output Class Initialized
INFO - 2024-02-21 20:22:45 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:45 --> Input Class Initialized
INFO - 2024-02-21 20:22:45 --> Language Class Initialized
INFO - 2024-02-21 20:22:45 --> Loader Class Initialized
INFO - 2024-02-21 20:22:45 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:45 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:45 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:45 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:45 --> Controller Class Initialized
INFO - 2024-02-21 20:22:45 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:45 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:45 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:22:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:47 --> Config Class Initialized
INFO - 2024-02-21 20:22:47 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:47 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:47 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:47 --> URI Class Initialized
INFO - 2024-02-21 20:22:47 --> Router Class Initialized
INFO - 2024-02-21 20:22:47 --> Output Class Initialized
INFO - 2024-02-21 20:22:47 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:47 --> Input Class Initialized
INFO - 2024-02-21 20:22:47 --> Language Class Initialized
INFO - 2024-02-21 20:22:47 --> Loader Class Initialized
INFO - 2024-02-21 20:22:47 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:47 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:47 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:47 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:47 --> Controller Class Initialized
INFO - 2024-02-21 20:22:47 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:47 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:22:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:22:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:22:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:22:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:22:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:22:47 --> Final output sent to browser
DEBUG - 2024-02-21 20:22:47 --> Total execution time: 0.0279
ERROR - 2024-02-21 20:22:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:47 --> Config Class Initialized
INFO - 2024-02-21 20:22:47 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:47 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:47 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:47 --> URI Class Initialized
INFO - 2024-02-21 20:22:47 --> Router Class Initialized
INFO - 2024-02-21 20:22:47 --> Output Class Initialized
INFO - 2024-02-21 20:22:47 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:47 --> Input Class Initialized
INFO - 2024-02-21 20:22:47 --> Language Class Initialized
INFO - 2024-02-21 20:22:47 --> Loader Class Initialized
INFO - 2024-02-21 20:22:47 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:47 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:47 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:47 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:47 --> Controller Class Initialized
INFO - 2024-02-21 20:22:47 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:47 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:49 --> Config Class Initialized
INFO - 2024-02-21 20:22:49 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:49 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:49 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:49 --> URI Class Initialized
INFO - 2024-02-21 20:22:49 --> Router Class Initialized
INFO - 2024-02-21 20:22:49 --> Output Class Initialized
INFO - 2024-02-21 20:22:49 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:49 --> Input Class Initialized
INFO - 2024-02-21 20:22:49 --> Language Class Initialized
INFO - 2024-02-21 20:22:49 --> Loader Class Initialized
INFO - 2024-02-21 20:22:49 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:49 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:49 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:49 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:49 --> Controller Class Initialized
INFO - 2024-02-21 20:22:49 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:49 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:22:49 --> Final output sent to browser
DEBUG - 2024-02-21 20:22:49 --> Total execution time: 0.0407
ERROR - 2024-02-21 20:22:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:22:54 --> Config Class Initialized
INFO - 2024-02-21 20:22:54 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:22:54 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:22:54 --> Utf8 Class Initialized
INFO - 2024-02-21 20:22:54 --> URI Class Initialized
INFO - 2024-02-21 20:22:54 --> Router Class Initialized
INFO - 2024-02-21 20:22:54 --> Output Class Initialized
INFO - 2024-02-21 20:22:54 --> Security Class Initialized
DEBUG - 2024-02-21 20:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:22:54 --> Input Class Initialized
INFO - 2024-02-21 20:22:54 --> Language Class Initialized
INFO - 2024-02-21 20:22:54 --> Loader Class Initialized
INFO - 2024-02-21 20:22:54 --> Helper loaded: url_helper
INFO - 2024-02-21 20:22:54 --> Helper loaded: file_helper
INFO - 2024-02-21 20:22:54 --> Helper loaded: form_helper
INFO - 2024-02-21 20:22:54 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:22:54 --> Controller Class Initialized
INFO - 2024-02-21 20:22:54 --> Form Validation Class Initialized
INFO - 2024-02-21 20:22:54 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:22:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:22:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:22:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:22:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:23:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:23:25 --> Config Class Initialized
INFO - 2024-02-21 20:23:25 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:23:25 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:23:25 --> Utf8 Class Initialized
INFO - 2024-02-21 20:23:25 --> URI Class Initialized
INFO - 2024-02-21 20:23:25 --> Router Class Initialized
INFO - 2024-02-21 20:23:25 --> Output Class Initialized
INFO - 2024-02-21 20:23:25 --> Security Class Initialized
DEBUG - 2024-02-21 20:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:23:25 --> Input Class Initialized
INFO - 2024-02-21 20:23:25 --> Language Class Initialized
INFO - 2024-02-21 20:23:25 --> Loader Class Initialized
INFO - 2024-02-21 20:23:25 --> Helper loaded: url_helper
INFO - 2024-02-21 20:23:25 --> Helper loaded: file_helper
INFO - 2024-02-21 20:23:25 --> Helper loaded: form_helper
INFO - 2024-02-21 20:23:25 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:23:25 --> Controller Class Initialized
INFO - 2024-02-21 20:23:25 --> Form Validation Class Initialized
INFO - 2024-02-21 20:23:25 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:23:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:23:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:23:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:23:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:23:27 --> Config Class Initialized
INFO - 2024-02-21 20:23:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:23:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:23:27 --> Utf8 Class Initialized
INFO - 2024-02-21 20:23:27 --> URI Class Initialized
INFO - 2024-02-21 20:23:27 --> Router Class Initialized
INFO - 2024-02-21 20:23:27 --> Output Class Initialized
INFO - 2024-02-21 20:23:27 --> Security Class Initialized
DEBUG - 2024-02-21 20:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:23:27 --> Input Class Initialized
INFO - 2024-02-21 20:23:27 --> Language Class Initialized
INFO - 2024-02-21 20:23:27 --> Loader Class Initialized
INFO - 2024-02-21 20:23:27 --> Helper loaded: url_helper
INFO - 2024-02-21 20:23:27 --> Helper loaded: file_helper
INFO - 2024-02-21 20:23:27 --> Helper loaded: form_helper
INFO - 2024-02-21 20:23:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:23:27 --> Controller Class Initialized
INFO - 2024-02-21 20:23:27 --> Form Validation Class Initialized
INFO - 2024-02-21 20:23:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:23:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:23:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:23:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:23:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:23:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:23:31 --> Config Class Initialized
INFO - 2024-02-21 20:23:31 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:23:31 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:23:31 --> Utf8 Class Initialized
INFO - 2024-02-21 20:23:31 --> URI Class Initialized
INFO - 2024-02-21 20:23:31 --> Router Class Initialized
INFO - 2024-02-21 20:23:31 --> Output Class Initialized
INFO - 2024-02-21 20:23:31 --> Security Class Initialized
DEBUG - 2024-02-21 20:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:23:31 --> Input Class Initialized
INFO - 2024-02-21 20:23:31 --> Language Class Initialized
INFO - 2024-02-21 20:23:31 --> Loader Class Initialized
INFO - 2024-02-21 20:23:31 --> Helper loaded: url_helper
INFO - 2024-02-21 20:23:31 --> Helper loaded: file_helper
INFO - 2024-02-21 20:23:31 --> Helper loaded: form_helper
INFO - 2024-02-21 20:23:31 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:23:31 --> Controller Class Initialized
INFO - 2024-02-21 20:23:31 --> Form Validation Class Initialized
INFO - 2024-02-21 20:23:31 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:23:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:23:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:23:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:23:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:23:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:23:32 --> Config Class Initialized
INFO - 2024-02-21 20:23:32 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:23:32 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:23:32 --> Utf8 Class Initialized
INFO - 2024-02-21 20:23:32 --> URI Class Initialized
INFO - 2024-02-21 20:23:32 --> Router Class Initialized
INFO - 2024-02-21 20:23:32 --> Output Class Initialized
INFO - 2024-02-21 20:23:32 --> Security Class Initialized
DEBUG - 2024-02-21 20:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:23:32 --> Input Class Initialized
INFO - 2024-02-21 20:23:32 --> Language Class Initialized
INFO - 2024-02-21 20:23:32 --> Loader Class Initialized
INFO - 2024-02-21 20:23:32 --> Helper loaded: url_helper
INFO - 2024-02-21 20:23:32 --> Helper loaded: file_helper
INFO - 2024-02-21 20:23:32 --> Helper loaded: form_helper
INFO - 2024-02-21 20:23:32 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:23:32 --> Controller Class Initialized
INFO - 2024-02-21 20:23:32 --> Form Validation Class Initialized
INFO - 2024-02-21 20:23:32 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:23:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:23:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:23:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:23:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:23:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:23:32 --> Final output sent to browser
DEBUG - 2024-02-21 20:23:32 --> Total execution time: 0.0396
ERROR - 2024-02-21 20:23:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:23:47 --> Config Class Initialized
INFO - 2024-02-21 20:23:47 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:23:47 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:23:47 --> Utf8 Class Initialized
INFO - 2024-02-21 20:23:47 --> URI Class Initialized
INFO - 2024-02-21 20:23:47 --> Router Class Initialized
INFO - 2024-02-21 20:23:47 --> Output Class Initialized
INFO - 2024-02-21 20:23:47 --> Security Class Initialized
DEBUG - 2024-02-21 20:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:23:47 --> Input Class Initialized
INFO - 2024-02-21 20:23:47 --> Language Class Initialized
INFO - 2024-02-21 20:23:47 --> Loader Class Initialized
INFO - 2024-02-21 20:23:47 --> Helper loaded: url_helper
INFO - 2024-02-21 20:23:47 --> Helper loaded: file_helper
INFO - 2024-02-21 20:23:47 --> Helper loaded: form_helper
INFO - 2024-02-21 20:23:47 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:23:47 --> Controller Class Initialized
INFO - 2024-02-21 20:23:47 --> Form Validation Class Initialized
INFO - 2024-02-21 20:23:47 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:23:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:23:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:23:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:23:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:23:47 --> Upload Class Initialized
INFO - 2024-02-21 20:23:47 --> Image Lib Class Initialized
ERROR - 2024-02-21 20:23:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:23:47 --> Config Class Initialized
INFO - 2024-02-21 20:23:47 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:23:47 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:23:47 --> Utf8 Class Initialized
INFO - 2024-02-21 20:23:47 --> URI Class Initialized
INFO - 2024-02-21 20:23:47 --> Router Class Initialized
INFO - 2024-02-21 20:23:47 --> Output Class Initialized
INFO - 2024-02-21 20:23:47 --> Security Class Initialized
DEBUG - 2024-02-21 20:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:23:47 --> Input Class Initialized
INFO - 2024-02-21 20:23:47 --> Language Class Initialized
INFO - 2024-02-21 20:23:47 --> Loader Class Initialized
INFO - 2024-02-21 20:23:47 --> Helper loaded: url_helper
INFO - 2024-02-21 20:23:47 --> Helper loaded: file_helper
INFO - 2024-02-21 20:23:47 --> Helper loaded: form_helper
INFO - 2024-02-21 20:23:47 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:23:47 --> Controller Class Initialized
INFO - 2024-02-21 20:23:47 --> Form Validation Class Initialized
INFO - 2024-02-21 20:23:47 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:23:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:23:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:23:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:23:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:23:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:23:55 --> Config Class Initialized
INFO - 2024-02-21 20:23:55 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:23:55 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:23:55 --> Utf8 Class Initialized
INFO - 2024-02-21 20:23:55 --> URI Class Initialized
INFO - 2024-02-21 20:23:55 --> Router Class Initialized
INFO - 2024-02-21 20:23:55 --> Output Class Initialized
INFO - 2024-02-21 20:23:55 --> Security Class Initialized
DEBUG - 2024-02-21 20:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:23:55 --> Input Class Initialized
INFO - 2024-02-21 20:23:55 --> Language Class Initialized
INFO - 2024-02-21 20:23:55 --> Loader Class Initialized
INFO - 2024-02-21 20:23:55 --> Helper loaded: url_helper
INFO - 2024-02-21 20:23:55 --> Helper loaded: file_helper
INFO - 2024-02-21 20:23:55 --> Helper loaded: form_helper
INFO - 2024-02-21 20:23:55 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:23:55 --> Controller Class Initialized
INFO - 2024-02-21 20:23:55 --> Form Validation Class Initialized
INFO - 2024-02-21 20:23:55 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:23:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:23:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:23:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:23:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:23:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:23:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:23:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:23:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:23:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:23:55 --> Final output sent to browser
DEBUG - 2024-02-21 20:23:55 --> Total execution time: 0.0334
ERROR - 2024-02-21 20:23:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:23:57 --> Config Class Initialized
INFO - 2024-02-21 20:23:57 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:23:57 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:23:57 --> Utf8 Class Initialized
INFO - 2024-02-21 20:23:57 --> URI Class Initialized
INFO - 2024-02-21 20:23:57 --> Router Class Initialized
INFO - 2024-02-21 20:23:57 --> Output Class Initialized
INFO - 2024-02-21 20:23:57 --> Security Class Initialized
DEBUG - 2024-02-21 20:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:23:57 --> Input Class Initialized
INFO - 2024-02-21 20:23:57 --> Language Class Initialized
INFO - 2024-02-21 20:23:57 --> Loader Class Initialized
INFO - 2024-02-21 20:23:57 --> Helper loaded: url_helper
INFO - 2024-02-21 20:23:57 --> Helper loaded: file_helper
INFO - 2024-02-21 20:23:57 --> Helper loaded: form_helper
INFO - 2024-02-21 20:23:57 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:23:57 --> Controller Class Initialized
INFO - 2024-02-21 20:23:57 --> Form Validation Class Initialized
INFO - 2024-02-21 20:23:57 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:23:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:23:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:23:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:23:57 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:24:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:24:28 --> Config Class Initialized
INFO - 2024-02-21 20:24:28 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:24:28 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:24:28 --> Utf8 Class Initialized
INFO - 2024-02-21 20:24:28 --> URI Class Initialized
INFO - 2024-02-21 20:24:28 --> Router Class Initialized
INFO - 2024-02-21 20:24:28 --> Output Class Initialized
INFO - 2024-02-21 20:24:28 --> Security Class Initialized
DEBUG - 2024-02-21 20:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:24:28 --> Input Class Initialized
INFO - 2024-02-21 20:24:28 --> Language Class Initialized
INFO - 2024-02-21 20:24:28 --> Loader Class Initialized
INFO - 2024-02-21 20:24:28 --> Helper loaded: url_helper
INFO - 2024-02-21 20:24:28 --> Helper loaded: file_helper
INFO - 2024-02-21 20:24:28 --> Helper loaded: form_helper
INFO - 2024-02-21 20:24:28 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:24:28 --> Controller Class Initialized
INFO - 2024-02-21 20:24:28 --> Form Validation Class Initialized
INFO - 2024-02-21 20:24:28 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:24:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:24:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:24:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:24:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:24:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:24:28 --> Final output sent to browser
DEBUG - 2024-02-21 20:24:28 --> Total execution time: 0.0355
ERROR - 2024-02-21 20:24:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:24:49 --> Config Class Initialized
INFO - 2024-02-21 20:24:49 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:24:49 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:24:49 --> Utf8 Class Initialized
INFO - 2024-02-21 20:24:49 --> URI Class Initialized
INFO - 2024-02-21 20:24:49 --> Router Class Initialized
INFO - 2024-02-21 20:24:49 --> Output Class Initialized
INFO - 2024-02-21 20:24:49 --> Security Class Initialized
DEBUG - 2024-02-21 20:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:24:49 --> Input Class Initialized
INFO - 2024-02-21 20:24:49 --> Language Class Initialized
INFO - 2024-02-21 20:24:49 --> Loader Class Initialized
INFO - 2024-02-21 20:24:49 --> Helper loaded: url_helper
INFO - 2024-02-21 20:24:49 --> Helper loaded: file_helper
INFO - 2024-02-21 20:24:49 --> Helper loaded: form_helper
INFO - 2024-02-21 20:24:49 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:24:49 --> Controller Class Initialized
INFO - 2024-02-21 20:24:49 --> Form Validation Class Initialized
INFO - 2024-02-21 20:24:49 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:24:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:24:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:24:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:24:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:24:49 --> Upload Class Initialized
INFO - 2024-02-21 20:24:49 --> Image Lib Class Initialized
ERROR - 2024-02-21 20:24:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:24:49 --> Config Class Initialized
INFO - 2024-02-21 20:24:49 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:24:49 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:24:49 --> Utf8 Class Initialized
INFO - 2024-02-21 20:24:49 --> URI Class Initialized
INFO - 2024-02-21 20:24:49 --> Router Class Initialized
INFO - 2024-02-21 20:24:49 --> Output Class Initialized
INFO - 2024-02-21 20:24:49 --> Security Class Initialized
DEBUG - 2024-02-21 20:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:24:49 --> Input Class Initialized
INFO - 2024-02-21 20:24:49 --> Language Class Initialized
INFO - 2024-02-21 20:24:49 --> Loader Class Initialized
INFO - 2024-02-21 20:24:49 --> Helper loaded: url_helper
INFO - 2024-02-21 20:24:49 --> Helper loaded: file_helper
INFO - 2024-02-21 20:24:49 --> Helper loaded: form_helper
INFO - 2024-02-21 20:24:49 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:24:49 --> Controller Class Initialized
INFO - 2024-02-21 20:24:49 --> Form Validation Class Initialized
INFO - 2024-02-21 20:24:49 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:24:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:24:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:24:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:24:49 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:24:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:24:55 --> Config Class Initialized
INFO - 2024-02-21 20:24:55 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:24:55 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:24:55 --> Utf8 Class Initialized
INFO - 2024-02-21 20:24:55 --> URI Class Initialized
INFO - 2024-02-21 20:24:55 --> Router Class Initialized
INFO - 2024-02-21 20:24:55 --> Output Class Initialized
INFO - 2024-02-21 20:24:55 --> Security Class Initialized
DEBUG - 2024-02-21 20:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:24:55 --> Input Class Initialized
INFO - 2024-02-21 20:24:55 --> Language Class Initialized
INFO - 2024-02-21 20:24:55 --> Loader Class Initialized
INFO - 2024-02-21 20:24:55 --> Helper loaded: url_helper
INFO - 2024-02-21 20:24:55 --> Helper loaded: file_helper
INFO - 2024-02-21 20:24:55 --> Helper loaded: form_helper
INFO - 2024-02-21 20:24:55 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:24:55 --> Controller Class Initialized
INFO - 2024-02-21 20:24:55 --> Form Validation Class Initialized
INFO - 2024-02-21 20:24:55 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:24:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:24:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:24:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:24:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:24:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:24:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:24:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:24:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:24:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:24:55 --> Final output sent to browser
DEBUG - 2024-02-21 20:24:55 --> Total execution time: 0.0364
ERROR - 2024-02-21 20:24:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:24:57 --> Config Class Initialized
INFO - 2024-02-21 20:24:57 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:24:57 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:24:57 --> Utf8 Class Initialized
INFO - 2024-02-21 20:24:57 --> URI Class Initialized
INFO - 2024-02-21 20:24:57 --> Router Class Initialized
INFO - 2024-02-21 20:24:57 --> Output Class Initialized
INFO - 2024-02-21 20:24:57 --> Security Class Initialized
DEBUG - 2024-02-21 20:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:24:57 --> Input Class Initialized
INFO - 2024-02-21 20:24:57 --> Language Class Initialized
INFO - 2024-02-21 20:24:57 --> Loader Class Initialized
INFO - 2024-02-21 20:24:57 --> Helper loaded: url_helper
INFO - 2024-02-21 20:24:57 --> Helper loaded: file_helper
INFO - 2024-02-21 20:24:57 --> Helper loaded: form_helper
INFO - 2024-02-21 20:24:57 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:24:57 --> Controller Class Initialized
INFO - 2024-02-21 20:24:57 --> Form Validation Class Initialized
INFO - 2024-02-21 20:24:57 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:24:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:24:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:24:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:24:57 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:25:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:25:00 --> Config Class Initialized
INFO - 2024-02-21 20:25:00 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:25:00 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:25:00 --> Utf8 Class Initialized
INFO - 2024-02-21 20:25:00 --> URI Class Initialized
INFO - 2024-02-21 20:25:00 --> Router Class Initialized
INFO - 2024-02-21 20:25:00 --> Output Class Initialized
INFO - 2024-02-21 20:25:00 --> Security Class Initialized
DEBUG - 2024-02-21 20:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:25:00 --> Input Class Initialized
INFO - 2024-02-21 20:25:00 --> Language Class Initialized
INFO - 2024-02-21 20:25:00 --> Loader Class Initialized
INFO - 2024-02-21 20:25:00 --> Helper loaded: url_helper
INFO - 2024-02-21 20:25:00 --> Helper loaded: file_helper
INFO - 2024-02-21 20:25:00 --> Helper loaded: form_helper
INFO - 2024-02-21 20:25:00 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:25:00 --> Controller Class Initialized
INFO - 2024-02-21 20:25:00 --> Form Validation Class Initialized
INFO - 2024-02-21 20:25:00 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:25:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:25:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:25:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:25:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:25:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:25:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:25:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:25:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:25:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:25:00 --> Final output sent to browser
DEBUG - 2024-02-21 20:25:00 --> Total execution time: 0.0351
ERROR - 2024-02-21 20:25:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:25:01 --> Config Class Initialized
INFO - 2024-02-21 20:25:01 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:25:01 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:25:01 --> Utf8 Class Initialized
INFO - 2024-02-21 20:25:01 --> URI Class Initialized
INFO - 2024-02-21 20:25:01 --> Router Class Initialized
INFO - 2024-02-21 20:25:01 --> Output Class Initialized
INFO - 2024-02-21 20:25:01 --> Security Class Initialized
DEBUG - 2024-02-21 20:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:25:01 --> Input Class Initialized
INFO - 2024-02-21 20:25:01 --> Language Class Initialized
INFO - 2024-02-21 20:25:01 --> Loader Class Initialized
INFO - 2024-02-21 20:25:01 --> Helper loaded: url_helper
INFO - 2024-02-21 20:25:01 --> Helper loaded: file_helper
INFO - 2024-02-21 20:25:01 --> Helper loaded: form_helper
INFO - 2024-02-21 20:25:01 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:25:01 --> Controller Class Initialized
INFO - 2024-02-21 20:25:01 --> Form Validation Class Initialized
INFO - 2024-02-21 20:25:01 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:25:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:25:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:25:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:25:01 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:25:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:25:05 --> Config Class Initialized
INFO - 2024-02-21 20:25:05 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:25:05 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:25:05 --> Utf8 Class Initialized
INFO - 2024-02-21 20:25:05 --> URI Class Initialized
INFO - 2024-02-21 20:25:05 --> Router Class Initialized
INFO - 2024-02-21 20:25:05 --> Output Class Initialized
INFO - 2024-02-21 20:25:05 --> Security Class Initialized
DEBUG - 2024-02-21 20:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:25:05 --> Input Class Initialized
INFO - 2024-02-21 20:25:05 --> Language Class Initialized
INFO - 2024-02-21 20:25:05 --> Loader Class Initialized
INFO - 2024-02-21 20:25:05 --> Helper loaded: url_helper
INFO - 2024-02-21 20:25:05 --> Helper loaded: file_helper
INFO - 2024-02-21 20:25:05 --> Helper loaded: form_helper
INFO - 2024-02-21 20:25:05 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:25:05 --> Controller Class Initialized
INFO - 2024-02-21 20:25:05 --> Form Validation Class Initialized
INFO - 2024-02-21 20:25:05 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:25:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:25:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:25:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:25:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:25:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:25:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-21 20:25:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:25:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:25:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:25:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-21 20:25:05 --> Final output sent to browser
DEBUG - 2024-02-21 20:25:05 --> Total execution time: 0.0326
ERROR - 2024-02-21 20:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:25:10 --> Config Class Initialized
INFO - 2024-02-21 20:25:10 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:25:10 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:25:10 --> Utf8 Class Initialized
INFO - 2024-02-21 20:25:10 --> URI Class Initialized
INFO - 2024-02-21 20:25:10 --> Router Class Initialized
INFO - 2024-02-21 20:25:10 --> Output Class Initialized
INFO - 2024-02-21 20:25:10 --> Security Class Initialized
DEBUG - 2024-02-21 20:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:25:10 --> Input Class Initialized
INFO - 2024-02-21 20:25:10 --> Language Class Initialized
INFO - 2024-02-21 20:25:10 --> Loader Class Initialized
INFO - 2024-02-21 20:25:10 --> Helper loaded: url_helper
INFO - 2024-02-21 20:25:10 --> Helper loaded: file_helper
INFO - 2024-02-21 20:25:10 --> Helper loaded: form_helper
INFO - 2024-02-21 20:25:10 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:25:10 --> Controller Class Initialized
INFO - 2024-02-21 20:25:10 --> Model "LoginModel" initialized
INFO - 2024-02-21 20:25:10 --> Form Validation Class Initialized
ERROR - 2024-02-21 20:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:25:10 --> Config Class Initialized
INFO - 2024-02-21 20:25:10 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:25:10 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:25:10 --> Utf8 Class Initialized
INFO - 2024-02-21 20:25:10 --> URI Class Initialized
INFO - 2024-02-21 20:25:10 --> Router Class Initialized
INFO - 2024-02-21 20:25:10 --> Output Class Initialized
INFO - 2024-02-21 20:25:10 --> Security Class Initialized
DEBUG - 2024-02-21 20:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:25:10 --> Input Class Initialized
INFO - 2024-02-21 20:25:10 --> Language Class Initialized
INFO - 2024-02-21 20:25:10 --> Loader Class Initialized
INFO - 2024-02-21 20:25:10 --> Helper loaded: url_helper
INFO - 2024-02-21 20:25:10 --> Helper loaded: file_helper
INFO - 2024-02-21 20:25:10 --> Helper loaded: form_helper
INFO - 2024-02-21 20:25:10 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:25:10 --> Controller Class Initialized
INFO - 2024-02-21 20:25:10 --> Model "LoginModel" initialized
INFO - 2024-02-21 20:25:10 --> Form Validation Class Initialized
INFO - 2024-02-21 20:25:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-21 20:25:10 --> Final output sent to browser
DEBUG - 2024-02-21 20:25:10 --> Total execution time: 0.0219
ERROR - 2024-02-21 20:25:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:25:22 --> Config Class Initialized
INFO - 2024-02-21 20:25:22 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:25:22 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:25:22 --> Utf8 Class Initialized
INFO - 2024-02-21 20:25:22 --> URI Class Initialized
INFO - 2024-02-21 20:25:22 --> Router Class Initialized
INFO - 2024-02-21 20:25:22 --> Output Class Initialized
INFO - 2024-02-21 20:25:22 --> Security Class Initialized
DEBUG - 2024-02-21 20:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:25:22 --> Input Class Initialized
INFO - 2024-02-21 20:25:22 --> Language Class Initialized
INFO - 2024-02-21 20:25:22 --> Loader Class Initialized
INFO - 2024-02-21 20:25:22 --> Helper loaded: url_helper
INFO - 2024-02-21 20:25:22 --> Helper loaded: file_helper
INFO - 2024-02-21 20:25:22 --> Helper loaded: form_helper
INFO - 2024-02-21 20:25:22 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:25:22 --> Controller Class Initialized
INFO - 2024-02-21 20:25:22 --> Model "LoginModel" initialized
INFO - 2024-02-21 20:25:22 --> Form Validation Class Initialized
INFO - 2024-02-21 20:25:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-21 20:25:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:25:22 --> Config Class Initialized
INFO - 2024-02-21 20:25:22 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:25:22 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:25:22 --> Utf8 Class Initialized
INFO - 2024-02-21 20:25:22 --> URI Class Initialized
INFO - 2024-02-21 20:25:22 --> Router Class Initialized
INFO - 2024-02-21 20:25:22 --> Output Class Initialized
INFO - 2024-02-21 20:25:22 --> Security Class Initialized
DEBUG - 2024-02-21 20:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:25:22 --> Input Class Initialized
INFO - 2024-02-21 20:25:22 --> Language Class Initialized
INFO - 2024-02-21 20:25:22 --> Loader Class Initialized
INFO - 2024-02-21 20:25:22 --> Helper loaded: url_helper
INFO - 2024-02-21 20:25:22 --> Helper loaded: file_helper
INFO - 2024-02-21 20:25:22 --> Helper loaded: form_helper
INFO - 2024-02-21 20:25:22 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:25:22 --> Controller Class Initialized
INFO - 2024-02-21 20:25:22 --> Form Validation Class Initialized
INFO - 2024-02-21 20:25:22 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:25:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:25:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:25:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:25:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:25:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:25:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-21 20:25:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:25:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:25:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:25:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-21 20:25:22 --> Final output sent to browser
DEBUG - 2024-02-21 20:25:22 --> Total execution time: 0.0245
ERROR - 2024-02-21 20:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:25:27 --> Config Class Initialized
INFO - 2024-02-21 20:25:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:25:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:25:27 --> Utf8 Class Initialized
INFO - 2024-02-21 20:25:27 --> URI Class Initialized
INFO - 2024-02-21 20:25:27 --> Router Class Initialized
INFO - 2024-02-21 20:25:27 --> Output Class Initialized
INFO - 2024-02-21 20:25:27 --> Security Class Initialized
DEBUG - 2024-02-21 20:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:25:27 --> Input Class Initialized
INFO - 2024-02-21 20:25:27 --> Language Class Initialized
INFO - 2024-02-21 20:25:27 --> Loader Class Initialized
INFO - 2024-02-21 20:25:27 --> Helper loaded: url_helper
INFO - 2024-02-21 20:25:27 --> Helper loaded: file_helper
INFO - 2024-02-21 20:25:27 --> Helper loaded: form_helper
INFO - 2024-02-21 20:25:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:25:27 --> Controller Class Initialized
INFO - 2024-02-21 20:25:27 --> Form Validation Class Initialized
INFO - 2024-02-21 20:25:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:25:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:25:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:25:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:25:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:25:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:25:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:25:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:25:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:25:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-21 20:25:27 --> Final output sent to browser
DEBUG - 2024-02-21 20:25:27 --> Total execution time: 0.0362
ERROR - 2024-02-21 20:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:25:27 --> Config Class Initialized
INFO - 2024-02-21 20:25:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:25:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:25:27 --> Utf8 Class Initialized
INFO - 2024-02-21 20:25:27 --> URI Class Initialized
INFO - 2024-02-21 20:25:27 --> Router Class Initialized
INFO - 2024-02-21 20:25:27 --> Output Class Initialized
INFO - 2024-02-21 20:25:27 --> Security Class Initialized
DEBUG - 2024-02-21 20:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:25:27 --> Input Class Initialized
INFO - 2024-02-21 20:25:27 --> Language Class Initialized
INFO - 2024-02-21 20:25:27 --> Loader Class Initialized
INFO - 2024-02-21 20:25:27 --> Helper loaded: url_helper
INFO - 2024-02-21 20:25:27 --> Helper loaded: file_helper
INFO - 2024-02-21 20:25:27 --> Helper loaded: form_helper
INFO - 2024-02-21 20:25:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:25:27 --> Controller Class Initialized
INFO - 2024-02-21 20:25:27 --> Form Validation Class Initialized
INFO - 2024-02-21 20:25:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:25:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:25:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:25:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:25:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:25:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:25:29 --> Config Class Initialized
INFO - 2024-02-21 20:25:29 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:25:29 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:25:29 --> Utf8 Class Initialized
INFO - 2024-02-21 20:25:29 --> URI Class Initialized
INFO - 2024-02-21 20:25:29 --> Router Class Initialized
INFO - 2024-02-21 20:25:29 --> Output Class Initialized
INFO - 2024-02-21 20:25:29 --> Security Class Initialized
DEBUG - 2024-02-21 20:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:25:29 --> Input Class Initialized
INFO - 2024-02-21 20:25:29 --> Language Class Initialized
INFO - 2024-02-21 20:25:30 --> Loader Class Initialized
INFO - 2024-02-21 20:25:30 --> Helper loaded: url_helper
INFO - 2024-02-21 20:25:30 --> Helper loaded: file_helper
INFO - 2024-02-21 20:25:30 --> Helper loaded: form_helper
INFO - 2024-02-21 20:25:30 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:25:30 --> Controller Class Initialized
INFO - 2024-02-21 20:25:30 --> Form Validation Class Initialized
INFO - 2024-02-21 20:25:30 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:25:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:25:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:25:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:25:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:25:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:25:30 --> Final output sent to browser
DEBUG - 2024-02-21 20:25:30 --> Total execution time: 0.0378
ERROR - 2024-02-21 20:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:26:06 --> Config Class Initialized
INFO - 2024-02-21 20:26:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:26:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:26:06 --> Utf8 Class Initialized
INFO - 2024-02-21 20:26:06 --> URI Class Initialized
INFO - 2024-02-21 20:26:06 --> Router Class Initialized
INFO - 2024-02-21 20:26:06 --> Output Class Initialized
INFO - 2024-02-21 20:26:06 --> Security Class Initialized
DEBUG - 2024-02-21 20:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:26:06 --> Input Class Initialized
INFO - 2024-02-21 20:26:06 --> Language Class Initialized
INFO - 2024-02-21 20:26:06 --> Loader Class Initialized
INFO - 2024-02-21 20:26:06 --> Helper loaded: url_helper
INFO - 2024-02-21 20:26:06 --> Helper loaded: file_helper
INFO - 2024-02-21 20:26:06 --> Helper loaded: form_helper
INFO - 2024-02-21 20:26:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:26:06 --> Controller Class Initialized
INFO - 2024-02-21 20:26:06 --> Form Validation Class Initialized
INFO - 2024-02-21 20:26:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:26:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:26:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:26:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:26:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:26:06 --> Upload Class Initialized
INFO - 2024-02-21 20:26:06 --> Image Lib Class Initialized
ERROR - 2024-02-21 20:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:26:07 --> Config Class Initialized
INFO - 2024-02-21 20:26:07 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:26:07 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:26:07 --> Utf8 Class Initialized
INFO - 2024-02-21 20:26:07 --> URI Class Initialized
INFO - 2024-02-21 20:26:07 --> Router Class Initialized
INFO - 2024-02-21 20:26:07 --> Output Class Initialized
INFO - 2024-02-21 20:26:07 --> Security Class Initialized
DEBUG - 2024-02-21 20:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:26:07 --> Input Class Initialized
INFO - 2024-02-21 20:26:07 --> Language Class Initialized
INFO - 2024-02-21 20:26:07 --> Loader Class Initialized
INFO - 2024-02-21 20:26:07 --> Helper loaded: url_helper
INFO - 2024-02-21 20:26:07 --> Helper loaded: file_helper
INFO - 2024-02-21 20:26:07 --> Helper loaded: form_helper
INFO - 2024-02-21 20:26:07 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:26:07 --> Controller Class Initialized
INFO - 2024-02-21 20:26:07 --> Form Validation Class Initialized
INFO - 2024-02-21 20:26:07 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:26:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:26:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:26:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:26:07 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:26:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:26:23 --> Config Class Initialized
INFO - 2024-02-21 20:26:23 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:26:23 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:26:23 --> Utf8 Class Initialized
INFO - 2024-02-21 20:26:23 --> URI Class Initialized
INFO - 2024-02-21 20:26:23 --> Router Class Initialized
INFO - 2024-02-21 20:26:23 --> Output Class Initialized
INFO - 2024-02-21 20:26:23 --> Security Class Initialized
DEBUG - 2024-02-21 20:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:26:23 --> Input Class Initialized
INFO - 2024-02-21 20:26:23 --> Language Class Initialized
INFO - 2024-02-21 20:26:23 --> Loader Class Initialized
INFO - 2024-02-21 20:26:23 --> Helper loaded: url_helper
INFO - 2024-02-21 20:26:23 --> Helper loaded: file_helper
INFO - 2024-02-21 20:26:23 --> Helper loaded: form_helper
INFO - 2024-02-21 20:26:23 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:26:23 --> Controller Class Initialized
INFO - 2024-02-21 20:26:23 --> Form Validation Class Initialized
INFO - 2024-02-21 20:26:23 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:26:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:26:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:26:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:26:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:26:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:26:23 --> Final output sent to browser
DEBUG - 2024-02-21 20:26:23 --> Total execution time: 0.0393
ERROR - 2024-02-21 20:27:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:27:21 --> Config Class Initialized
INFO - 2024-02-21 20:27:21 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:27:21 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:27:21 --> Utf8 Class Initialized
INFO - 2024-02-21 20:27:21 --> URI Class Initialized
INFO - 2024-02-21 20:27:21 --> Router Class Initialized
INFO - 2024-02-21 20:27:21 --> Output Class Initialized
INFO - 2024-02-21 20:27:21 --> Security Class Initialized
DEBUG - 2024-02-21 20:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:27:21 --> Input Class Initialized
INFO - 2024-02-21 20:27:21 --> Language Class Initialized
INFO - 2024-02-21 20:27:21 --> Loader Class Initialized
INFO - 2024-02-21 20:27:21 --> Helper loaded: url_helper
INFO - 2024-02-21 20:27:21 --> Helper loaded: file_helper
INFO - 2024-02-21 20:27:21 --> Helper loaded: form_helper
INFO - 2024-02-21 20:27:21 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:27:21 --> Controller Class Initialized
INFO - 2024-02-21 20:27:21 --> Form Validation Class Initialized
INFO - 2024-02-21 20:27:21 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:27:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:27:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:27:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:27:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:27:21 --> Upload Class Initialized
INFO - 2024-02-21 20:27:21 --> Image Lib Class Initialized
ERROR - 2024-02-21 20:27:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:27:22 --> Config Class Initialized
INFO - 2024-02-21 20:27:22 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:27:22 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:27:22 --> Utf8 Class Initialized
INFO - 2024-02-21 20:27:22 --> URI Class Initialized
INFO - 2024-02-21 20:27:22 --> Router Class Initialized
INFO - 2024-02-21 20:27:22 --> Output Class Initialized
INFO - 2024-02-21 20:27:22 --> Security Class Initialized
DEBUG - 2024-02-21 20:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:27:22 --> Input Class Initialized
INFO - 2024-02-21 20:27:22 --> Language Class Initialized
INFO - 2024-02-21 20:27:22 --> Loader Class Initialized
INFO - 2024-02-21 20:27:22 --> Helper loaded: url_helper
INFO - 2024-02-21 20:27:22 --> Helper loaded: file_helper
INFO - 2024-02-21 20:27:22 --> Helper loaded: form_helper
INFO - 2024-02-21 20:27:22 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:27:22 --> Controller Class Initialized
INFO - 2024-02-21 20:27:22 --> Form Validation Class Initialized
INFO - 2024-02-21 20:27:22 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:27:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:27:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:27:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:27:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:27:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:27:25 --> Config Class Initialized
INFO - 2024-02-21 20:27:25 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:27:25 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:27:25 --> Utf8 Class Initialized
INFO - 2024-02-21 20:27:25 --> URI Class Initialized
INFO - 2024-02-21 20:27:25 --> Router Class Initialized
INFO - 2024-02-21 20:27:25 --> Output Class Initialized
INFO - 2024-02-21 20:27:25 --> Security Class Initialized
DEBUG - 2024-02-21 20:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:27:25 --> Input Class Initialized
INFO - 2024-02-21 20:27:25 --> Language Class Initialized
INFO - 2024-02-21 20:27:25 --> Loader Class Initialized
INFO - 2024-02-21 20:27:25 --> Helper loaded: url_helper
INFO - 2024-02-21 20:27:25 --> Helper loaded: file_helper
INFO - 2024-02-21 20:27:25 --> Helper loaded: form_helper
INFO - 2024-02-21 20:27:25 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:27:25 --> Controller Class Initialized
INFO - 2024-02-21 20:27:25 --> Form Validation Class Initialized
INFO - 2024-02-21 20:27:25 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:27:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:27:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:27:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:27:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:27:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:27:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:27:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:27:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:27:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-21 20:27:25 --> Final output sent to browser
DEBUG - 2024-02-21 20:27:25 --> Total execution time: 0.0356
ERROR - 2024-02-21 20:27:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:27:25 --> Config Class Initialized
INFO - 2024-02-21 20:27:25 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:27:25 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:27:25 --> Utf8 Class Initialized
INFO - 2024-02-21 20:27:25 --> URI Class Initialized
INFO - 2024-02-21 20:27:25 --> Router Class Initialized
INFO - 2024-02-21 20:27:25 --> Output Class Initialized
INFO - 2024-02-21 20:27:25 --> Security Class Initialized
DEBUG - 2024-02-21 20:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:27:25 --> Input Class Initialized
INFO - 2024-02-21 20:27:25 --> Language Class Initialized
INFO - 2024-02-21 20:27:25 --> Loader Class Initialized
INFO - 2024-02-21 20:27:25 --> Helper loaded: url_helper
INFO - 2024-02-21 20:27:25 --> Helper loaded: file_helper
INFO - 2024-02-21 20:27:25 --> Helper loaded: form_helper
INFO - 2024-02-21 20:27:25 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:27:25 --> Controller Class Initialized
INFO - 2024-02-21 20:27:25 --> Form Validation Class Initialized
INFO - 2024-02-21 20:27:25 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:27:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:27:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:27:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:27:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:27:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:27:34 --> Config Class Initialized
INFO - 2024-02-21 20:27:34 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:27:34 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:27:34 --> Utf8 Class Initialized
INFO - 2024-02-21 20:27:34 --> URI Class Initialized
INFO - 2024-02-21 20:27:34 --> Router Class Initialized
INFO - 2024-02-21 20:27:34 --> Output Class Initialized
INFO - 2024-02-21 20:27:34 --> Security Class Initialized
DEBUG - 2024-02-21 20:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:27:34 --> Input Class Initialized
INFO - 2024-02-21 20:27:34 --> Language Class Initialized
INFO - 2024-02-21 20:27:34 --> Loader Class Initialized
INFO - 2024-02-21 20:27:34 --> Helper loaded: url_helper
INFO - 2024-02-21 20:27:34 --> Helper loaded: file_helper
INFO - 2024-02-21 20:27:34 --> Helper loaded: form_helper
INFO - 2024-02-21 20:27:34 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:27:34 --> Controller Class Initialized
INFO - 2024-02-21 20:27:34 --> Form Validation Class Initialized
INFO - 2024-02-21 20:27:34 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:27:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:27:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:27:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:27:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:27:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:27:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:27:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:27:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:27:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:27:34 --> Final output sent to browser
DEBUG - 2024-02-21 20:27:34 --> Total execution time: 0.0334
ERROR - 2024-02-21 20:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:27:35 --> Config Class Initialized
INFO - 2024-02-21 20:27:35 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:27:35 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:27:35 --> Utf8 Class Initialized
INFO - 2024-02-21 20:27:35 --> URI Class Initialized
INFO - 2024-02-21 20:27:35 --> Router Class Initialized
INFO - 2024-02-21 20:27:35 --> Output Class Initialized
INFO - 2024-02-21 20:27:35 --> Security Class Initialized
DEBUG - 2024-02-21 20:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:27:35 --> Input Class Initialized
INFO - 2024-02-21 20:27:35 --> Language Class Initialized
INFO - 2024-02-21 20:27:35 --> Loader Class Initialized
INFO - 2024-02-21 20:27:35 --> Helper loaded: url_helper
INFO - 2024-02-21 20:27:35 --> Helper loaded: file_helper
INFO - 2024-02-21 20:27:35 --> Helper loaded: form_helper
INFO - 2024-02-21 20:27:35 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:27:35 --> Controller Class Initialized
INFO - 2024-02-21 20:27:35 --> Form Validation Class Initialized
INFO - 2024-02-21 20:27:35 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:27:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:27:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:27:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:27:35 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:27:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:27:44 --> Config Class Initialized
INFO - 2024-02-21 20:27:44 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:27:44 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:27:44 --> Utf8 Class Initialized
INFO - 2024-02-21 20:27:44 --> URI Class Initialized
INFO - 2024-02-21 20:27:44 --> Router Class Initialized
INFO - 2024-02-21 20:27:44 --> Output Class Initialized
INFO - 2024-02-21 20:27:44 --> Security Class Initialized
DEBUG - 2024-02-21 20:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:27:45 --> Input Class Initialized
INFO - 2024-02-21 20:27:45 --> Language Class Initialized
INFO - 2024-02-21 20:27:45 --> Loader Class Initialized
INFO - 2024-02-21 20:27:45 --> Helper loaded: url_helper
INFO - 2024-02-21 20:27:45 --> Helper loaded: file_helper
INFO - 2024-02-21 20:27:45 --> Helper loaded: form_helper
INFO - 2024-02-21 20:27:45 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:27:45 --> Controller Class Initialized
INFO - 2024-02-21 20:27:45 --> Form Validation Class Initialized
INFO - 2024-02-21 20:27:45 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:27:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:27:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:27:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:27:45 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:27:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:27:46 --> Config Class Initialized
INFO - 2024-02-21 20:27:46 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:27:46 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:27:46 --> Utf8 Class Initialized
INFO - 2024-02-21 20:27:46 --> URI Class Initialized
INFO - 2024-02-21 20:27:46 --> Router Class Initialized
INFO - 2024-02-21 20:27:46 --> Output Class Initialized
INFO - 2024-02-21 20:27:46 --> Security Class Initialized
DEBUG - 2024-02-21 20:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:27:46 --> Input Class Initialized
INFO - 2024-02-21 20:27:46 --> Language Class Initialized
INFO - 2024-02-21 20:27:46 --> Loader Class Initialized
INFO - 2024-02-21 20:27:46 --> Helper loaded: url_helper
INFO - 2024-02-21 20:27:46 --> Helper loaded: file_helper
INFO - 2024-02-21 20:27:46 --> Helper loaded: form_helper
INFO - 2024-02-21 20:27:46 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:27:46 --> Controller Class Initialized
INFO - 2024-02-21 20:27:46 --> Form Validation Class Initialized
INFO - 2024-02-21 20:27:46 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:27:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:27:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:27:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:27:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:27:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:27:55 --> Config Class Initialized
INFO - 2024-02-21 20:27:55 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:27:55 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:27:55 --> Utf8 Class Initialized
INFO - 2024-02-21 20:27:55 --> URI Class Initialized
INFO - 2024-02-21 20:27:55 --> Router Class Initialized
INFO - 2024-02-21 20:27:55 --> Output Class Initialized
INFO - 2024-02-21 20:27:55 --> Security Class Initialized
DEBUG - 2024-02-21 20:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:27:55 --> Input Class Initialized
INFO - 2024-02-21 20:27:55 --> Language Class Initialized
INFO - 2024-02-21 20:27:55 --> Loader Class Initialized
INFO - 2024-02-21 20:27:55 --> Helper loaded: url_helper
INFO - 2024-02-21 20:27:55 --> Helper loaded: file_helper
INFO - 2024-02-21 20:27:55 --> Helper loaded: form_helper
INFO - 2024-02-21 20:27:55 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:27:55 --> Controller Class Initialized
INFO - 2024-02-21 20:27:55 --> Form Validation Class Initialized
INFO - 2024-02-21 20:27:55 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:27:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:27:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:27:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:27:55 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:27:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:27:57 --> Config Class Initialized
INFO - 2024-02-21 20:27:57 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:27:57 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:27:57 --> Utf8 Class Initialized
INFO - 2024-02-21 20:27:57 --> URI Class Initialized
INFO - 2024-02-21 20:27:57 --> Router Class Initialized
INFO - 2024-02-21 20:27:57 --> Output Class Initialized
INFO - 2024-02-21 20:27:57 --> Security Class Initialized
DEBUG - 2024-02-21 20:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:27:57 --> Input Class Initialized
INFO - 2024-02-21 20:27:57 --> Language Class Initialized
INFO - 2024-02-21 20:27:57 --> Loader Class Initialized
INFO - 2024-02-21 20:27:57 --> Helper loaded: url_helper
INFO - 2024-02-21 20:27:57 --> Helper loaded: file_helper
INFO - 2024-02-21 20:27:57 --> Helper loaded: form_helper
INFO - 2024-02-21 20:27:57 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:27:57 --> Controller Class Initialized
INFO - 2024-02-21 20:27:57 --> Form Validation Class Initialized
INFO - 2024-02-21 20:27:57 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:27:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:27:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:27:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:27:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:27:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:27:57 --> Final output sent to browser
DEBUG - 2024-02-21 20:27:57 --> Total execution time: 0.0389
ERROR - 2024-02-21 20:28:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:03 --> Config Class Initialized
INFO - 2024-02-21 20:28:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:03 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:03 --> URI Class Initialized
INFO - 2024-02-21 20:28:03 --> Router Class Initialized
INFO - 2024-02-21 20:28:03 --> Output Class Initialized
INFO - 2024-02-21 20:28:03 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:03 --> Input Class Initialized
INFO - 2024-02-21 20:28:03 --> Language Class Initialized
INFO - 2024-02-21 20:28:03 --> Loader Class Initialized
INFO - 2024-02-21 20:28:03 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:03 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:03 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:03 --> Controller Class Initialized
INFO - 2024-02-21 20:28:03 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:28:03 --> Upload Class Initialized
INFO - 2024-02-21 20:28:03 --> Image Lib Class Initialized
ERROR - 2024-02-21 20:28:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:03 --> Config Class Initialized
INFO - 2024-02-21 20:28:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:03 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:03 --> URI Class Initialized
INFO - 2024-02-21 20:28:03 --> Router Class Initialized
INFO - 2024-02-21 20:28:03 --> Output Class Initialized
INFO - 2024-02-21 20:28:03 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:03 --> Input Class Initialized
INFO - 2024-02-21 20:28:03 --> Language Class Initialized
INFO - 2024-02-21 20:28:03 --> Loader Class Initialized
INFO - 2024-02-21 20:28:03 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:03 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:03 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:03 --> Controller Class Initialized
INFO - 2024-02-21 20:28:03 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:28:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:05 --> Config Class Initialized
INFO - 2024-02-21 20:28:05 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:05 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:05 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:05 --> URI Class Initialized
INFO - 2024-02-21 20:28:05 --> Router Class Initialized
INFO - 2024-02-21 20:28:05 --> Output Class Initialized
INFO - 2024-02-21 20:28:05 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:05 --> Input Class Initialized
INFO - 2024-02-21 20:28:05 --> Language Class Initialized
INFO - 2024-02-21 20:28:05 --> Loader Class Initialized
INFO - 2024-02-21 20:28:05 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:05 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:05 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:05 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:05 --> Controller Class Initialized
INFO - 2024-02-21 20:28:05 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:05 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:05 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:28:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:15 --> Config Class Initialized
INFO - 2024-02-21 20:28:15 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:15 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:15 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:15 --> URI Class Initialized
INFO - 2024-02-21 20:28:15 --> Router Class Initialized
INFO - 2024-02-21 20:28:15 --> Output Class Initialized
INFO - 2024-02-21 20:28:15 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:15 --> Input Class Initialized
INFO - 2024-02-21 20:28:15 --> Language Class Initialized
INFO - 2024-02-21 20:28:15 --> Loader Class Initialized
INFO - 2024-02-21 20:28:15 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:15 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:15 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:15 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:15 --> Controller Class Initialized
INFO - 2024-02-21 20:28:15 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:15 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:28:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:28:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:28:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:28:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:28:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:28:15 --> Final output sent to browser
DEBUG - 2024-02-21 20:28:15 --> Total execution time: 0.0348
ERROR - 2024-02-21 20:28:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:15 --> Config Class Initialized
INFO - 2024-02-21 20:28:15 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:15 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:15 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:15 --> URI Class Initialized
INFO - 2024-02-21 20:28:15 --> Router Class Initialized
INFO - 2024-02-21 20:28:15 --> Output Class Initialized
INFO - 2024-02-21 20:28:15 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:15 --> Input Class Initialized
INFO - 2024-02-21 20:28:15 --> Language Class Initialized
INFO - 2024-02-21 20:28:15 --> Loader Class Initialized
INFO - 2024-02-21 20:28:15 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:15 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:15 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:15 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:15 --> Controller Class Initialized
INFO - 2024-02-21 20:28:15 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:15 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:15 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:21 --> Config Class Initialized
INFO - 2024-02-21 20:28:21 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:21 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:21 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:21 --> URI Class Initialized
INFO - 2024-02-21 20:28:21 --> Router Class Initialized
INFO - 2024-02-21 20:28:21 --> Output Class Initialized
INFO - 2024-02-21 20:28:21 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:21 --> Input Class Initialized
INFO - 2024-02-21 20:28:21 --> Language Class Initialized
INFO - 2024-02-21 20:28:21 --> Loader Class Initialized
INFO - 2024-02-21 20:28:21 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:21 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:21 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:21 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:21 --> Controller Class Initialized
INFO - 2024-02-21 20:28:21 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:21 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:21 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:28:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:22 --> Config Class Initialized
INFO - 2024-02-21 20:28:22 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:22 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:22 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:22 --> URI Class Initialized
INFO - 2024-02-21 20:28:22 --> Router Class Initialized
INFO - 2024-02-21 20:28:22 --> Output Class Initialized
INFO - 2024-02-21 20:28:22 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:22 --> Input Class Initialized
INFO - 2024-02-21 20:28:22 --> Language Class Initialized
INFO - 2024-02-21 20:28:22 --> Loader Class Initialized
INFO - 2024-02-21 20:28:22 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:22 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:22 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:22 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:22 --> Controller Class Initialized
INFO - 2024-02-21 20:28:22 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:22 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:28:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:28:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:28:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:28:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:28:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-21 20:28:22 --> Final output sent to browser
DEBUG - 2024-02-21 20:28:22 --> Total execution time: 0.0354
ERROR - 2024-02-21 20:28:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:23 --> Config Class Initialized
INFO - 2024-02-21 20:28:23 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:23 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:23 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:23 --> URI Class Initialized
INFO - 2024-02-21 20:28:23 --> Router Class Initialized
INFO - 2024-02-21 20:28:23 --> Output Class Initialized
INFO - 2024-02-21 20:28:23 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:23 --> Input Class Initialized
INFO - 2024-02-21 20:28:23 --> Language Class Initialized
INFO - 2024-02-21 20:28:23 --> Loader Class Initialized
INFO - 2024-02-21 20:28:23 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:23 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:23 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:23 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:23 --> Controller Class Initialized
INFO - 2024-02-21 20:28:23 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:23 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:28:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:26 --> Config Class Initialized
INFO - 2024-02-21 20:28:26 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:26 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:26 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:26 --> URI Class Initialized
INFO - 2024-02-21 20:28:26 --> Router Class Initialized
INFO - 2024-02-21 20:28:26 --> Output Class Initialized
INFO - 2024-02-21 20:28:26 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:26 --> Input Class Initialized
INFO - 2024-02-21 20:28:26 --> Language Class Initialized
INFO - 2024-02-21 20:28:26 --> Loader Class Initialized
INFO - 2024-02-21 20:28:26 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:26 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:26 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:26 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:26 --> Controller Class Initialized
INFO - 2024-02-21 20:28:26 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:26 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:26 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:28:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:30 --> Config Class Initialized
INFO - 2024-02-21 20:28:30 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:30 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:30 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:30 --> URI Class Initialized
INFO - 2024-02-21 20:28:30 --> Router Class Initialized
INFO - 2024-02-21 20:28:30 --> Output Class Initialized
INFO - 2024-02-21 20:28:30 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:30 --> Input Class Initialized
INFO - 2024-02-21 20:28:30 --> Language Class Initialized
INFO - 2024-02-21 20:28:30 --> Loader Class Initialized
INFO - 2024-02-21 20:28:30 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:30 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:30 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:30 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:30 --> Controller Class Initialized
INFO - 2024-02-21 20:28:30 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:30 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-21 20:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:28:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-21 20:28:30 --> Final output sent to browser
DEBUG - 2024-02-21 20:28:30 --> Total execution time: 0.0363
ERROR - 2024-02-21 20:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:34 --> Config Class Initialized
INFO - 2024-02-21 20:28:34 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:34 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:34 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:34 --> URI Class Initialized
INFO - 2024-02-21 20:28:34 --> Router Class Initialized
INFO - 2024-02-21 20:28:34 --> Output Class Initialized
INFO - 2024-02-21 20:28:34 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:34 --> Input Class Initialized
INFO - 2024-02-21 20:28:34 --> Language Class Initialized
INFO - 2024-02-21 20:28:34 --> Loader Class Initialized
INFO - 2024-02-21 20:28:34 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:34 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:34 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:34 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:34 --> Controller Class Initialized
INFO - 2024-02-21 20:28:34 --> Model "LoginModel" initialized
INFO - 2024-02-21 20:28:34 --> Form Validation Class Initialized
ERROR - 2024-02-21 20:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:34 --> Config Class Initialized
INFO - 2024-02-21 20:28:34 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:34 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:34 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:34 --> URI Class Initialized
INFO - 2024-02-21 20:28:34 --> Router Class Initialized
INFO - 2024-02-21 20:28:34 --> Output Class Initialized
INFO - 2024-02-21 20:28:34 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:34 --> Input Class Initialized
INFO - 2024-02-21 20:28:34 --> Language Class Initialized
INFO - 2024-02-21 20:28:34 --> Loader Class Initialized
INFO - 2024-02-21 20:28:34 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:34 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:34 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:34 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:34 --> Controller Class Initialized
INFO - 2024-02-21 20:28:34 --> Model "LoginModel" initialized
INFO - 2024-02-21 20:28:34 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-21 20:28:34 --> Final output sent to browser
DEBUG - 2024-02-21 20:28:34 --> Total execution time: 0.0223
ERROR - 2024-02-21 20:28:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:50 --> Config Class Initialized
INFO - 2024-02-21 20:28:50 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:50 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:50 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:50 --> URI Class Initialized
INFO - 2024-02-21 20:28:50 --> Router Class Initialized
INFO - 2024-02-21 20:28:50 --> Output Class Initialized
INFO - 2024-02-21 20:28:50 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:50 --> Input Class Initialized
INFO - 2024-02-21 20:28:50 --> Language Class Initialized
INFO - 2024-02-21 20:28:50 --> Loader Class Initialized
INFO - 2024-02-21 20:28:50 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:50 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:50 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:50 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:50 --> Controller Class Initialized
INFO - 2024-02-21 20:28:50 --> Model "LoginModel" initialized
INFO - 2024-02-21 20:28:50 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-21 20:28:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:51 --> Config Class Initialized
INFO - 2024-02-21 20:28:51 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:51 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:51 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:51 --> URI Class Initialized
INFO - 2024-02-21 20:28:51 --> Router Class Initialized
INFO - 2024-02-21 20:28:51 --> Output Class Initialized
INFO - 2024-02-21 20:28:51 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:51 --> Input Class Initialized
INFO - 2024-02-21 20:28:51 --> Language Class Initialized
INFO - 2024-02-21 20:28:51 --> Loader Class Initialized
INFO - 2024-02-21 20:28:51 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:51 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:51 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:51 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:51 --> Controller Class Initialized
INFO - 2024-02-21 20:28:51 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:51 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:28:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:28:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-21 20:28:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:28:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:28:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:28:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-21 20:28:51 --> Final output sent to browser
DEBUG - 2024-02-21 20:28:51 --> Total execution time: 0.0305
ERROR - 2024-02-21 20:28:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:54 --> Config Class Initialized
INFO - 2024-02-21 20:28:54 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:54 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:54 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:54 --> URI Class Initialized
INFO - 2024-02-21 20:28:54 --> Router Class Initialized
INFO - 2024-02-21 20:28:54 --> Output Class Initialized
INFO - 2024-02-21 20:28:54 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:54 --> Input Class Initialized
INFO - 2024-02-21 20:28:54 --> Language Class Initialized
INFO - 2024-02-21 20:28:54 --> Loader Class Initialized
INFO - 2024-02-21 20:28:54 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:54 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:54 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:54 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:54 --> Controller Class Initialized
INFO - 2024-02-21 20:28:54 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:54 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:28:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:28:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:28:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:28:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:28:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:28:54 --> Final output sent to browser
DEBUG - 2024-02-21 20:28:54 --> Total execution time: 0.0281
ERROR - 2024-02-21 20:28:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:28:55 --> Config Class Initialized
INFO - 2024-02-21 20:28:55 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:28:55 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:28:55 --> Utf8 Class Initialized
INFO - 2024-02-21 20:28:55 --> URI Class Initialized
INFO - 2024-02-21 20:28:55 --> Router Class Initialized
INFO - 2024-02-21 20:28:55 --> Output Class Initialized
INFO - 2024-02-21 20:28:55 --> Security Class Initialized
DEBUG - 2024-02-21 20:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:28:55 --> Input Class Initialized
INFO - 2024-02-21 20:28:55 --> Language Class Initialized
INFO - 2024-02-21 20:28:55 --> Loader Class Initialized
INFO - 2024-02-21 20:28:55 --> Helper loaded: url_helper
INFO - 2024-02-21 20:28:55 --> Helper loaded: file_helper
INFO - 2024-02-21 20:28:55 --> Helper loaded: form_helper
INFO - 2024-02-21 20:28:55 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:28:55 --> Controller Class Initialized
INFO - 2024-02-21 20:28:55 --> Form Validation Class Initialized
INFO - 2024-02-21 20:28:55 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:28:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:28:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:28:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:28:55 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:29:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:29:27 --> Config Class Initialized
INFO - 2024-02-21 20:29:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:29:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:29:27 --> Utf8 Class Initialized
INFO - 2024-02-21 20:29:27 --> URI Class Initialized
INFO - 2024-02-21 20:29:27 --> Router Class Initialized
INFO - 2024-02-21 20:29:27 --> Output Class Initialized
INFO - 2024-02-21 20:29:27 --> Security Class Initialized
DEBUG - 2024-02-21 20:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:29:27 --> Input Class Initialized
INFO - 2024-02-21 20:29:27 --> Language Class Initialized
INFO - 2024-02-21 20:29:27 --> Loader Class Initialized
INFO - 2024-02-21 20:29:27 --> Helper loaded: url_helper
INFO - 2024-02-21 20:29:27 --> Helper loaded: file_helper
INFO - 2024-02-21 20:29:27 --> Helper loaded: form_helper
INFO - 2024-02-21 20:29:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:29:27 --> Controller Class Initialized
INFO - 2024-02-21 20:29:27 --> Form Validation Class Initialized
INFO - 2024-02-21 20:29:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:29:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:29:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:29:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:29:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:29:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:29:31 --> Config Class Initialized
INFO - 2024-02-21 20:29:31 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:29:31 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:29:31 --> Utf8 Class Initialized
INFO - 2024-02-21 20:29:31 --> URI Class Initialized
INFO - 2024-02-21 20:29:31 --> Router Class Initialized
INFO - 2024-02-21 20:29:31 --> Output Class Initialized
INFO - 2024-02-21 20:29:31 --> Security Class Initialized
DEBUG - 2024-02-21 20:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:29:31 --> Input Class Initialized
INFO - 2024-02-21 20:29:31 --> Language Class Initialized
INFO - 2024-02-21 20:29:31 --> Loader Class Initialized
INFO - 2024-02-21 20:29:31 --> Helper loaded: url_helper
INFO - 2024-02-21 20:29:31 --> Helper loaded: file_helper
INFO - 2024-02-21 20:29:31 --> Helper loaded: form_helper
INFO - 2024-02-21 20:29:31 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:29:31 --> Controller Class Initialized
INFO - 2024-02-21 20:29:31 --> Form Validation Class Initialized
INFO - 2024-02-21 20:29:31 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:29:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:29:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:29:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:29:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:29:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:29:31 --> Final output sent to browser
DEBUG - 2024-02-21 20:29:31 --> Total execution time: 0.0417
ERROR - 2024-02-21 20:29:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:29:55 --> Config Class Initialized
INFO - 2024-02-21 20:29:55 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:29:55 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:29:55 --> Utf8 Class Initialized
INFO - 2024-02-21 20:29:55 --> URI Class Initialized
INFO - 2024-02-21 20:29:55 --> Router Class Initialized
INFO - 2024-02-21 20:29:55 --> Output Class Initialized
INFO - 2024-02-21 20:29:55 --> Security Class Initialized
DEBUG - 2024-02-21 20:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:29:56 --> Input Class Initialized
INFO - 2024-02-21 20:29:56 --> Language Class Initialized
INFO - 2024-02-21 20:29:56 --> Loader Class Initialized
INFO - 2024-02-21 20:29:56 --> Helper loaded: url_helper
INFO - 2024-02-21 20:29:56 --> Helper loaded: file_helper
INFO - 2024-02-21 20:29:56 --> Helper loaded: form_helper
INFO - 2024-02-21 20:29:56 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:29:56 --> Controller Class Initialized
INFO - 2024-02-21 20:29:56 --> Form Validation Class Initialized
INFO - 2024-02-21 20:29:56 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:29:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:29:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:29:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:29:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:29:56 --> Upload Class Initialized
INFO - 2024-02-21 20:29:56 --> Image Lib Class Initialized
ERROR - 2024-02-21 20:29:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:29:56 --> Config Class Initialized
INFO - 2024-02-21 20:29:56 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:29:56 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:29:56 --> Utf8 Class Initialized
INFO - 2024-02-21 20:29:56 --> URI Class Initialized
INFO - 2024-02-21 20:29:56 --> Router Class Initialized
INFO - 2024-02-21 20:29:56 --> Output Class Initialized
INFO - 2024-02-21 20:29:56 --> Security Class Initialized
DEBUG - 2024-02-21 20:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:29:56 --> Input Class Initialized
INFO - 2024-02-21 20:29:56 --> Language Class Initialized
INFO - 2024-02-21 20:29:56 --> Loader Class Initialized
INFO - 2024-02-21 20:29:56 --> Helper loaded: url_helper
INFO - 2024-02-21 20:29:56 --> Helper loaded: file_helper
INFO - 2024-02-21 20:29:56 --> Helper loaded: form_helper
INFO - 2024-02-21 20:29:56 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:29:56 --> Controller Class Initialized
INFO - 2024-02-21 20:29:56 --> Form Validation Class Initialized
INFO - 2024-02-21 20:29:56 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:29:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:29:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:29:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:29:56 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:30:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:30:00 --> Config Class Initialized
INFO - 2024-02-21 20:30:00 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:30:00 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:30:00 --> Utf8 Class Initialized
INFO - 2024-02-21 20:30:00 --> URI Class Initialized
INFO - 2024-02-21 20:30:00 --> Router Class Initialized
INFO - 2024-02-21 20:30:00 --> Output Class Initialized
INFO - 2024-02-21 20:30:00 --> Security Class Initialized
DEBUG - 2024-02-21 20:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:30:00 --> Input Class Initialized
INFO - 2024-02-21 20:30:00 --> Language Class Initialized
INFO - 2024-02-21 20:30:00 --> Loader Class Initialized
INFO - 2024-02-21 20:30:00 --> Helper loaded: url_helper
INFO - 2024-02-21 20:30:00 --> Helper loaded: file_helper
INFO - 2024-02-21 20:30:00 --> Helper loaded: form_helper
INFO - 2024-02-21 20:30:00 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:30:00 --> Controller Class Initialized
INFO - 2024-02-21 20:30:00 --> Form Validation Class Initialized
INFO - 2024-02-21 20:30:00 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:30:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:30:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:30:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:30:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:30:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:30:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:30:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:30:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:30:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:30:00 --> Final output sent to browser
DEBUG - 2024-02-21 20:30:00 --> Total execution time: 0.0332
ERROR - 2024-02-21 20:30:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:30:02 --> Config Class Initialized
INFO - 2024-02-21 20:30:02 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:30:02 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:30:02 --> Utf8 Class Initialized
INFO - 2024-02-21 20:30:02 --> URI Class Initialized
INFO - 2024-02-21 20:30:02 --> Router Class Initialized
INFO - 2024-02-21 20:30:02 --> Output Class Initialized
INFO - 2024-02-21 20:30:02 --> Security Class Initialized
DEBUG - 2024-02-21 20:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:30:02 --> Input Class Initialized
INFO - 2024-02-21 20:30:02 --> Language Class Initialized
INFO - 2024-02-21 20:30:02 --> Loader Class Initialized
INFO - 2024-02-21 20:30:02 --> Helper loaded: url_helper
INFO - 2024-02-21 20:30:02 --> Helper loaded: file_helper
INFO - 2024-02-21 20:30:02 --> Helper loaded: form_helper
INFO - 2024-02-21 20:30:02 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:30:02 --> Controller Class Initialized
INFO - 2024-02-21 20:30:02 --> Form Validation Class Initialized
INFO - 2024-02-21 20:30:02 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:30:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:30:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:30:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:30:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:30:19 --> Config Class Initialized
INFO - 2024-02-21 20:30:19 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:30:19 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:30:19 --> Utf8 Class Initialized
INFO - 2024-02-21 20:30:19 --> URI Class Initialized
INFO - 2024-02-21 20:30:19 --> Router Class Initialized
INFO - 2024-02-21 20:30:19 --> Output Class Initialized
INFO - 2024-02-21 20:30:19 --> Security Class Initialized
DEBUG - 2024-02-21 20:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:30:19 --> Input Class Initialized
INFO - 2024-02-21 20:30:19 --> Language Class Initialized
INFO - 2024-02-21 20:30:19 --> Loader Class Initialized
INFO - 2024-02-21 20:30:19 --> Helper loaded: url_helper
INFO - 2024-02-21 20:30:19 --> Helper loaded: file_helper
INFO - 2024-02-21 20:30:19 --> Helper loaded: form_helper
INFO - 2024-02-21 20:30:19 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:30:19 --> Controller Class Initialized
INFO - 2024-02-21 20:30:19 --> Form Validation Class Initialized
INFO - 2024-02-21 20:30:19 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:30:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:30:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:30:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:30:19 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:30:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:30:21 --> Config Class Initialized
INFO - 2024-02-21 20:30:21 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:30:21 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:30:21 --> Utf8 Class Initialized
INFO - 2024-02-21 20:30:21 --> URI Class Initialized
INFO - 2024-02-21 20:30:21 --> Router Class Initialized
INFO - 2024-02-21 20:30:21 --> Output Class Initialized
INFO - 2024-02-21 20:30:21 --> Security Class Initialized
DEBUG - 2024-02-21 20:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:30:21 --> Input Class Initialized
INFO - 2024-02-21 20:30:21 --> Language Class Initialized
INFO - 2024-02-21 20:30:21 --> Loader Class Initialized
INFO - 2024-02-21 20:30:21 --> Helper loaded: url_helper
INFO - 2024-02-21 20:30:21 --> Helper loaded: file_helper
INFO - 2024-02-21 20:30:21 --> Helper loaded: form_helper
INFO - 2024-02-21 20:30:21 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:30:21 --> Controller Class Initialized
INFO - 2024-02-21 20:30:21 --> Form Validation Class Initialized
INFO - 2024-02-21 20:30:21 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:30:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:30:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:30:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:30:21 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:30:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:30:28 --> Config Class Initialized
INFO - 2024-02-21 20:30:28 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:30:28 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:30:28 --> Utf8 Class Initialized
INFO - 2024-02-21 20:30:28 --> URI Class Initialized
INFO - 2024-02-21 20:30:28 --> Router Class Initialized
INFO - 2024-02-21 20:30:28 --> Output Class Initialized
INFO - 2024-02-21 20:30:28 --> Security Class Initialized
DEBUG - 2024-02-21 20:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:30:28 --> Input Class Initialized
INFO - 2024-02-21 20:30:28 --> Language Class Initialized
INFO - 2024-02-21 20:30:28 --> Loader Class Initialized
INFO - 2024-02-21 20:30:28 --> Helper loaded: url_helper
INFO - 2024-02-21 20:30:28 --> Helper loaded: file_helper
INFO - 2024-02-21 20:30:28 --> Helper loaded: form_helper
INFO - 2024-02-21 20:30:28 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:30:28 --> Controller Class Initialized
INFO - 2024-02-21 20:30:28 --> Form Validation Class Initialized
INFO - 2024-02-21 20:30:28 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:30:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:30:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:30:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:30:28 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:30:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:30:30 --> Config Class Initialized
INFO - 2024-02-21 20:30:30 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:30:30 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:30:30 --> Utf8 Class Initialized
INFO - 2024-02-21 20:30:30 --> URI Class Initialized
INFO - 2024-02-21 20:30:30 --> Router Class Initialized
INFO - 2024-02-21 20:30:30 --> Output Class Initialized
INFO - 2024-02-21 20:30:30 --> Security Class Initialized
DEBUG - 2024-02-21 20:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:30:30 --> Input Class Initialized
INFO - 2024-02-21 20:30:30 --> Language Class Initialized
INFO - 2024-02-21 20:30:30 --> Loader Class Initialized
INFO - 2024-02-21 20:30:30 --> Helper loaded: url_helper
INFO - 2024-02-21 20:30:30 --> Helper loaded: file_helper
INFO - 2024-02-21 20:30:30 --> Helper loaded: form_helper
INFO - 2024-02-21 20:30:30 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:30:30 --> Controller Class Initialized
INFO - 2024-02-21 20:30:30 --> Form Validation Class Initialized
INFO - 2024-02-21 20:30:30 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:30:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:30:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:30:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:30:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:30:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:30:34 --> Config Class Initialized
INFO - 2024-02-21 20:30:34 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:30:34 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:30:34 --> Utf8 Class Initialized
INFO - 2024-02-21 20:30:34 --> URI Class Initialized
INFO - 2024-02-21 20:30:34 --> Router Class Initialized
INFO - 2024-02-21 20:30:34 --> Output Class Initialized
INFO - 2024-02-21 20:30:34 --> Security Class Initialized
DEBUG - 2024-02-21 20:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:30:34 --> Input Class Initialized
INFO - 2024-02-21 20:30:34 --> Language Class Initialized
INFO - 2024-02-21 20:30:34 --> Loader Class Initialized
INFO - 2024-02-21 20:30:34 --> Helper loaded: url_helper
INFO - 2024-02-21 20:30:34 --> Helper loaded: file_helper
INFO - 2024-02-21 20:30:34 --> Helper loaded: form_helper
INFO - 2024-02-21 20:30:34 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:30:34 --> Controller Class Initialized
INFO - 2024-02-21 20:30:34 --> Form Validation Class Initialized
INFO - 2024-02-21 20:30:34 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:30:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:30:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:30:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:30:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:30:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:30:34 --> Final output sent to browser
DEBUG - 2024-02-21 20:30:34 --> Total execution time: 0.0378
ERROR - 2024-02-21 20:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:30:52 --> Config Class Initialized
INFO - 2024-02-21 20:30:52 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:30:52 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:30:52 --> Utf8 Class Initialized
INFO - 2024-02-21 20:30:52 --> URI Class Initialized
INFO - 2024-02-21 20:30:52 --> Router Class Initialized
INFO - 2024-02-21 20:30:52 --> Output Class Initialized
INFO - 2024-02-21 20:30:52 --> Security Class Initialized
DEBUG - 2024-02-21 20:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:30:52 --> Input Class Initialized
INFO - 2024-02-21 20:30:52 --> Language Class Initialized
INFO - 2024-02-21 20:30:52 --> Loader Class Initialized
INFO - 2024-02-21 20:30:52 --> Helper loaded: url_helper
INFO - 2024-02-21 20:30:52 --> Helper loaded: file_helper
INFO - 2024-02-21 20:30:52 --> Helper loaded: form_helper
INFO - 2024-02-21 20:30:52 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:30:52 --> Controller Class Initialized
INFO - 2024-02-21 20:30:52 --> Form Validation Class Initialized
INFO - 2024-02-21 20:30:52 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:30:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:30:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:30:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:30:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:30:52 --> Upload Class Initialized
INFO - 2024-02-21 20:30:52 --> Image Lib Class Initialized
ERROR - 2024-02-21 20:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:30:52 --> Config Class Initialized
INFO - 2024-02-21 20:30:52 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:30:52 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:30:52 --> Utf8 Class Initialized
INFO - 2024-02-21 20:30:52 --> URI Class Initialized
INFO - 2024-02-21 20:30:52 --> Router Class Initialized
INFO - 2024-02-21 20:30:52 --> Output Class Initialized
INFO - 2024-02-21 20:30:52 --> Security Class Initialized
DEBUG - 2024-02-21 20:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:30:52 --> Input Class Initialized
INFO - 2024-02-21 20:30:52 --> Language Class Initialized
INFO - 2024-02-21 20:30:52 --> Loader Class Initialized
INFO - 2024-02-21 20:30:52 --> Helper loaded: url_helper
INFO - 2024-02-21 20:30:52 --> Helper loaded: file_helper
INFO - 2024-02-21 20:30:52 --> Helper loaded: form_helper
INFO - 2024-02-21 20:30:52 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:30:52 --> Controller Class Initialized
INFO - 2024-02-21 20:30:52 --> Form Validation Class Initialized
INFO - 2024-02-21 20:30:52 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:30:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:30:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:30:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:30:52 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:30:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:30:58 --> Config Class Initialized
INFO - 2024-02-21 20:30:58 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:30:58 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:30:58 --> Utf8 Class Initialized
INFO - 2024-02-21 20:30:58 --> URI Class Initialized
INFO - 2024-02-21 20:30:58 --> Router Class Initialized
INFO - 2024-02-21 20:30:58 --> Output Class Initialized
INFO - 2024-02-21 20:30:58 --> Security Class Initialized
DEBUG - 2024-02-21 20:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:30:58 --> Input Class Initialized
INFO - 2024-02-21 20:30:58 --> Language Class Initialized
INFO - 2024-02-21 20:30:58 --> Loader Class Initialized
INFO - 2024-02-21 20:30:58 --> Helper loaded: url_helper
INFO - 2024-02-21 20:30:58 --> Helper loaded: file_helper
INFO - 2024-02-21 20:30:58 --> Helper loaded: form_helper
INFO - 2024-02-21 20:30:58 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:30:58 --> Controller Class Initialized
INFO - 2024-02-21 20:30:58 --> Form Validation Class Initialized
INFO - 2024-02-21 20:30:58 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:30:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:30:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:30:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:30:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:30:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:30:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:30:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:30:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:30:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:30:58 --> Final output sent to browser
DEBUG - 2024-02-21 20:30:58 --> Total execution time: 0.0354
ERROR - 2024-02-21 20:30:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:30:58 --> Config Class Initialized
INFO - 2024-02-21 20:30:58 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:30:58 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:30:58 --> Utf8 Class Initialized
INFO - 2024-02-21 20:30:58 --> URI Class Initialized
INFO - 2024-02-21 20:30:58 --> Router Class Initialized
INFO - 2024-02-21 20:30:58 --> Output Class Initialized
INFO - 2024-02-21 20:30:58 --> Security Class Initialized
DEBUG - 2024-02-21 20:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:30:58 --> Input Class Initialized
INFO - 2024-02-21 20:30:58 --> Language Class Initialized
INFO - 2024-02-21 20:30:58 --> Loader Class Initialized
INFO - 2024-02-21 20:30:58 --> Helper loaded: url_helper
INFO - 2024-02-21 20:30:58 --> Helper loaded: file_helper
INFO - 2024-02-21 20:30:58 --> Helper loaded: form_helper
INFO - 2024-02-21 20:30:58 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:30:58 --> Controller Class Initialized
INFO - 2024-02-21 20:30:58 --> Form Validation Class Initialized
INFO - 2024-02-21 20:30:58 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:30:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:30:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:30:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:30:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:31:03 --> Config Class Initialized
INFO - 2024-02-21 20:31:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:31:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:31:03 --> Utf8 Class Initialized
INFO - 2024-02-21 20:31:03 --> URI Class Initialized
INFO - 2024-02-21 20:31:03 --> Router Class Initialized
INFO - 2024-02-21 20:31:03 --> Output Class Initialized
INFO - 2024-02-21 20:31:03 --> Security Class Initialized
DEBUG - 2024-02-21 20:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:31:03 --> Input Class Initialized
INFO - 2024-02-21 20:31:03 --> Language Class Initialized
INFO - 2024-02-21 20:31:03 --> Loader Class Initialized
INFO - 2024-02-21 20:31:03 --> Helper loaded: url_helper
INFO - 2024-02-21 20:31:03 --> Helper loaded: file_helper
INFO - 2024-02-21 20:31:03 --> Helper loaded: form_helper
INFO - 2024-02-21 20:31:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:31:03 --> Controller Class Initialized
INFO - 2024-02-21 20:31:03 --> Form Validation Class Initialized
INFO - 2024-02-21 20:31:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:31:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:31:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:31:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:31:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:31:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:31:06 --> Config Class Initialized
INFO - 2024-02-21 20:31:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:31:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:31:06 --> Utf8 Class Initialized
INFO - 2024-02-21 20:31:06 --> URI Class Initialized
INFO - 2024-02-21 20:31:06 --> Router Class Initialized
INFO - 2024-02-21 20:31:06 --> Output Class Initialized
INFO - 2024-02-21 20:31:06 --> Security Class Initialized
DEBUG - 2024-02-21 20:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:31:06 --> Input Class Initialized
INFO - 2024-02-21 20:31:06 --> Language Class Initialized
INFO - 2024-02-21 20:31:06 --> Loader Class Initialized
INFO - 2024-02-21 20:31:06 --> Helper loaded: url_helper
INFO - 2024-02-21 20:31:06 --> Helper loaded: file_helper
INFO - 2024-02-21 20:31:06 --> Helper loaded: form_helper
INFO - 2024-02-21 20:31:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:31:06 --> Controller Class Initialized
INFO - 2024-02-21 20:31:06 --> Form Validation Class Initialized
INFO - 2024-02-21 20:31:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:31:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:31:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:31:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:31:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:31:26 --> Config Class Initialized
INFO - 2024-02-21 20:31:26 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:31:26 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:31:26 --> Utf8 Class Initialized
INFO - 2024-02-21 20:31:26 --> URI Class Initialized
INFO - 2024-02-21 20:31:26 --> Router Class Initialized
INFO - 2024-02-21 20:31:26 --> Output Class Initialized
INFO - 2024-02-21 20:31:26 --> Security Class Initialized
DEBUG - 2024-02-21 20:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:31:26 --> Input Class Initialized
INFO - 2024-02-21 20:31:26 --> Language Class Initialized
INFO - 2024-02-21 20:31:26 --> Loader Class Initialized
INFO - 2024-02-21 20:31:26 --> Helper loaded: url_helper
INFO - 2024-02-21 20:31:26 --> Helper loaded: file_helper
INFO - 2024-02-21 20:31:26 --> Helper loaded: form_helper
INFO - 2024-02-21 20:31:26 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:31:26 --> Controller Class Initialized
INFO - 2024-02-21 20:31:26 --> Form Validation Class Initialized
INFO - 2024-02-21 20:31:26 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:31:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:31:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:31:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:31:26 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:31:27 --> Config Class Initialized
INFO - 2024-02-21 20:31:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:31:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:31:27 --> Utf8 Class Initialized
INFO - 2024-02-21 20:31:27 --> URI Class Initialized
INFO - 2024-02-21 20:31:27 --> Router Class Initialized
INFO - 2024-02-21 20:31:27 --> Output Class Initialized
INFO - 2024-02-21 20:31:27 --> Security Class Initialized
DEBUG - 2024-02-21 20:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:31:27 --> Input Class Initialized
INFO - 2024-02-21 20:31:27 --> Language Class Initialized
INFO - 2024-02-21 20:31:27 --> Loader Class Initialized
INFO - 2024-02-21 20:31:27 --> Helper loaded: url_helper
INFO - 2024-02-21 20:31:27 --> Helper loaded: file_helper
INFO - 2024-02-21 20:31:27 --> Helper loaded: form_helper
INFO - 2024-02-21 20:31:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:31:27 --> Controller Class Initialized
INFO - 2024-02-21 20:31:27 --> Form Validation Class Initialized
INFO - 2024-02-21 20:31:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:31:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:31:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:31:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:31:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:31:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:31:31 --> Config Class Initialized
INFO - 2024-02-21 20:31:31 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:31:31 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:31:31 --> Utf8 Class Initialized
INFO - 2024-02-21 20:31:31 --> URI Class Initialized
INFO - 2024-02-21 20:31:31 --> Router Class Initialized
INFO - 2024-02-21 20:31:31 --> Output Class Initialized
INFO - 2024-02-21 20:31:31 --> Security Class Initialized
DEBUG - 2024-02-21 20:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:31:31 --> Input Class Initialized
INFO - 2024-02-21 20:31:31 --> Language Class Initialized
INFO - 2024-02-21 20:31:31 --> Loader Class Initialized
INFO - 2024-02-21 20:31:31 --> Helper loaded: url_helper
INFO - 2024-02-21 20:31:31 --> Helper loaded: file_helper
INFO - 2024-02-21 20:31:31 --> Helper loaded: form_helper
INFO - 2024-02-21 20:31:31 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:31:31 --> Controller Class Initialized
INFO - 2024-02-21 20:31:31 --> Form Validation Class Initialized
INFO - 2024-02-21 20:31:31 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:31:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:31:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:31:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:31:31 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:32:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:32:21 --> Config Class Initialized
INFO - 2024-02-21 20:32:21 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:32:21 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:32:21 --> Utf8 Class Initialized
INFO - 2024-02-21 20:32:21 --> URI Class Initialized
INFO - 2024-02-21 20:32:21 --> Router Class Initialized
INFO - 2024-02-21 20:32:21 --> Output Class Initialized
INFO - 2024-02-21 20:32:21 --> Security Class Initialized
DEBUG - 2024-02-21 20:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:32:21 --> Input Class Initialized
INFO - 2024-02-21 20:32:21 --> Language Class Initialized
INFO - 2024-02-21 20:32:21 --> Loader Class Initialized
INFO - 2024-02-21 20:32:21 --> Helper loaded: url_helper
INFO - 2024-02-21 20:32:21 --> Helper loaded: file_helper
INFO - 2024-02-21 20:32:21 --> Helper loaded: form_helper
INFO - 2024-02-21 20:32:21 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:32:21 --> Controller Class Initialized
INFO - 2024-02-21 20:32:21 --> Form Validation Class Initialized
INFO - 2024-02-21 20:32:21 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:32:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:32:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:32:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:32:21 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:32:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:32:23 --> Config Class Initialized
INFO - 2024-02-21 20:32:23 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:32:23 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:32:23 --> Utf8 Class Initialized
INFO - 2024-02-21 20:32:23 --> URI Class Initialized
INFO - 2024-02-21 20:32:23 --> Router Class Initialized
INFO - 2024-02-21 20:32:23 --> Output Class Initialized
INFO - 2024-02-21 20:32:23 --> Security Class Initialized
DEBUG - 2024-02-21 20:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:32:23 --> Input Class Initialized
INFO - 2024-02-21 20:32:23 --> Language Class Initialized
INFO - 2024-02-21 20:32:23 --> Loader Class Initialized
INFO - 2024-02-21 20:32:23 --> Helper loaded: url_helper
INFO - 2024-02-21 20:32:23 --> Helper loaded: file_helper
INFO - 2024-02-21 20:32:23 --> Helper loaded: form_helper
INFO - 2024-02-21 20:32:23 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:32:23 --> Controller Class Initialized
INFO - 2024-02-21 20:32:23 --> Form Validation Class Initialized
INFO - 2024-02-21 20:32:23 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:32:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:32:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:32:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:32:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:32:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:32:29 --> Config Class Initialized
INFO - 2024-02-21 20:32:29 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:32:29 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:32:29 --> Utf8 Class Initialized
INFO - 2024-02-21 20:32:29 --> URI Class Initialized
INFO - 2024-02-21 20:32:29 --> Router Class Initialized
INFO - 2024-02-21 20:32:29 --> Output Class Initialized
INFO - 2024-02-21 20:32:29 --> Security Class Initialized
DEBUG - 2024-02-21 20:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:32:29 --> Input Class Initialized
INFO - 2024-02-21 20:32:29 --> Language Class Initialized
INFO - 2024-02-21 20:32:29 --> Loader Class Initialized
INFO - 2024-02-21 20:32:29 --> Helper loaded: url_helper
INFO - 2024-02-21 20:32:29 --> Helper loaded: file_helper
INFO - 2024-02-21 20:32:29 --> Helper loaded: form_helper
INFO - 2024-02-21 20:32:29 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:32:29 --> Controller Class Initialized
INFO - 2024-02-21 20:32:29 --> Form Validation Class Initialized
INFO - 2024-02-21 20:32:29 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:32:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:32:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:32:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:32:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:32:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 20:32:29 --> Final output sent to browser
DEBUG - 2024-02-21 20:32:29 --> Total execution time: 0.0398
ERROR - 2024-02-21 20:32:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:32:58 --> Config Class Initialized
INFO - 2024-02-21 20:32:58 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:32:58 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:32:58 --> Utf8 Class Initialized
INFO - 2024-02-21 20:32:58 --> URI Class Initialized
INFO - 2024-02-21 20:32:58 --> Router Class Initialized
INFO - 2024-02-21 20:32:58 --> Output Class Initialized
INFO - 2024-02-21 20:32:58 --> Security Class Initialized
DEBUG - 2024-02-21 20:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:32:58 --> Input Class Initialized
INFO - 2024-02-21 20:32:58 --> Language Class Initialized
INFO - 2024-02-21 20:32:58 --> Loader Class Initialized
INFO - 2024-02-21 20:32:58 --> Helper loaded: url_helper
INFO - 2024-02-21 20:32:58 --> Helper loaded: file_helper
INFO - 2024-02-21 20:32:58 --> Helper loaded: form_helper
INFO - 2024-02-21 20:32:58 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:32:58 --> Controller Class Initialized
INFO - 2024-02-21 20:32:58 --> Form Validation Class Initialized
INFO - 2024-02-21 20:32:58 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:32:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:32:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:32:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:32:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:32:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:32:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:32:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:32:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:32:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:32:58 --> Final output sent to browser
DEBUG - 2024-02-21 20:32:58 --> Total execution time: 0.0371
ERROR - 2024-02-21 20:32:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:32:58 --> Config Class Initialized
INFO - 2024-02-21 20:32:58 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:32:58 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:32:58 --> Utf8 Class Initialized
INFO - 2024-02-21 20:32:58 --> URI Class Initialized
INFO - 2024-02-21 20:32:58 --> Router Class Initialized
INFO - 2024-02-21 20:32:58 --> Output Class Initialized
INFO - 2024-02-21 20:32:58 --> Security Class Initialized
DEBUG - 2024-02-21 20:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:32:58 --> Input Class Initialized
INFO - 2024-02-21 20:32:58 --> Language Class Initialized
INFO - 2024-02-21 20:32:58 --> Loader Class Initialized
INFO - 2024-02-21 20:32:58 --> Helper loaded: url_helper
INFO - 2024-02-21 20:32:58 --> Helper loaded: file_helper
INFO - 2024-02-21 20:32:58 --> Helper loaded: form_helper
INFO - 2024-02-21 20:32:58 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:32:58 --> Controller Class Initialized
INFO - 2024-02-21 20:32:58 --> Form Validation Class Initialized
INFO - 2024-02-21 20:32:58 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:32:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:32:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:32:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:32:58 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:33:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:33:28 --> Config Class Initialized
INFO - 2024-02-21 20:33:28 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:33:28 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:33:28 --> Utf8 Class Initialized
INFO - 2024-02-21 20:33:28 --> URI Class Initialized
INFO - 2024-02-21 20:33:28 --> Router Class Initialized
INFO - 2024-02-21 20:33:28 --> Output Class Initialized
INFO - 2024-02-21 20:33:28 --> Security Class Initialized
DEBUG - 2024-02-21 20:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:33:28 --> Input Class Initialized
INFO - 2024-02-21 20:33:28 --> Language Class Initialized
INFO - 2024-02-21 20:33:28 --> Loader Class Initialized
INFO - 2024-02-21 20:33:28 --> Helper loaded: url_helper
INFO - 2024-02-21 20:33:28 --> Helper loaded: file_helper
INFO - 2024-02-21 20:33:28 --> Helper loaded: form_helper
INFO - 2024-02-21 20:33:28 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:33:28 --> Controller Class Initialized
INFO - 2024-02-21 20:33:28 --> Form Validation Class Initialized
INFO - 2024-02-21 20:33:28 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:33:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:33:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:33:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:33:28 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:33:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:33:29 --> Config Class Initialized
INFO - 2024-02-21 20:33:29 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:33:29 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:33:29 --> Utf8 Class Initialized
INFO - 2024-02-21 20:33:29 --> URI Class Initialized
INFO - 2024-02-21 20:33:29 --> Router Class Initialized
INFO - 2024-02-21 20:33:29 --> Output Class Initialized
INFO - 2024-02-21 20:33:29 --> Security Class Initialized
DEBUG - 2024-02-21 20:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:33:29 --> Input Class Initialized
INFO - 2024-02-21 20:33:29 --> Language Class Initialized
INFO - 2024-02-21 20:33:29 --> Loader Class Initialized
INFO - 2024-02-21 20:33:29 --> Helper loaded: url_helper
INFO - 2024-02-21 20:33:29 --> Helper loaded: file_helper
INFO - 2024-02-21 20:33:29 --> Helper loaded: form_helper
INFO - 2024-02-21 20:33:29 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:33:29 --> Controller Class Initialized
INFO - 2024-02-21 20:33:29 --> Form Validation Class Initialized
INFO - 2024-02-21 20:33:29 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:33:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:33:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:33:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:33:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:33:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:33:40 --> Config Class Initialized
INFO - 2024-02-21 20:33:40 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:33:40 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:33:40 --> Utf8 Class Initialized
INFO - 2024-02-21 20:33:40 --> URI Class Initialized
INFO - 2024-02-21 20:33:40 --> Router Class Initialized
INFO - 2024-02-21 20:33:40 --> Output Class Initialized
INFO - 2024-02-21 20:33:40 --> Security Class Initialized
DEBUG - 2024-02-21 20:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:33:40 --> Input Class Initialized
INFO - 2024-02-21 20:33:40 --> Language Class Initialized
INFO - 2024-02-21 20:33:40 --> Loader Class Initialized
INFO - 2024-02-21 20:33:40 --> Helper loaded: url_helper
INFO - 2024-02-21 20:33:40 --> Helper loaded: file_helper
INFO - 2024-02-21 20:33:40 --> Helper loaded: form_helper
INFO - 2024-02-21 20:33:40 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:33:40 --> Controller Class Initialized
INFO - 2024-02-21 20:33:40 --> Form Validation Class Initialized
INFO - 2024-02-21 20:33:40 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:33:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:33:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:33:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:33:40 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:33:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:33:42 --> Config Class Initialized
INFO - 2024-02-21 20:33:42 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:33:42 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:33:42 --> Utf8 Class Initialized
INFO - 2024-02-21 20:33:42 --> URI Class Initialized
INFO - 2024-02-21 20:33:42 --> Router Class Initialized
INFO - 2024-02-21 20:33:42 --> Output Class Initialized
INFO - 2024-02-21 20:33:42 --> Security Class Initialized
DEBUG - 2024-02-21 20:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:33:42 --> Input Class Initialized
INFO - 2024-02-21 20:33:42 --> Language Class Initialized
INFO - 2024-02-21 20:33:42 --> Loader Class Initialized
INFO - 2024-02-21 20:33:42 --> Helper loaded: url_helper
INFO - 2024-02-21 20:33:42 --> Helper loaded: file_helper
INFO - 2024-02-21 20:33:42 --> Helper loaded: form_helper
INFO - 2024-02-21 20:33:42 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:33:42 --> Controller Class Initialized
INFO - 2024-02-21 20:33:42 --> Form Validation Class Initialized
INFO - 2024-02-21 20:33:42 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:33:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:33:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:33:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:33:42 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:35:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:35:55 --> Config Class Initialized
INFO - 2024-02-21 20:35:55 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:35:55 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:35:55 --> Utf8 Class Initialized
INFO - 2024-02-21 20:35:55 --> URI Class Initialized
INFO - 2024-02-21 20:35:55 --> Router Class Initialized
INFO - 2024-02-21 20:35:55 --> Output Class Initialized
INFO - 2024-02-21 20:35:55 --> Security Class Initialized
DEBUG - 2024-02-21 20:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:35:55 --> Input Class Initialized
INFO - 2024-02-21 20:35:55 --> Language Class Initialized
INFO - 2024-02-21 20:35:55 --> Loader Class Initialized
INFO - 2024-02-21 20:35:55 --> Helper loaded: url_helper
INFO - 2024-02-21 20:35:55 --> Helper loaded: file_helper
INFO - 2024-02-21 20:35:55 --> Helper loaded: form_helper
INFO - 2024-02-21 20:35:55 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:35:55 --> Controller Class Initialized
INFO - 2024-02-21 20:35:55 --> Form Validation Class Initialized
INFO - 2024-02-21 20:35:55 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:35:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:35:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:35:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:35:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:35:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:35:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-21 20:35:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:35:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:35:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:35:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-21 20:35:55 --> Final output sent to browser
DEBUG - 2024-02-21 20:35:55 --> Total execution time: 0.0350
ERROR - 2024-02-21 20:37:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:37:01 --> Config Class Initialized
INFO - 2024-02-21 20:37:01 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:37:01 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:37:01 --> Utf8 Class Initialized
INFO - 2024-02-21 20:37:01 --> URI Class Initialized
INFO - 2024-02-21 20:37:01 --> Router Class Initialized
INFO - 2024-02-21 20:37:01 --> Output Class Initialized
INFO - 2024-02-21 20:37:01 --> Security Class Initialized
DEBUG - 2024-02-21 20:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:37:01 --> Input Class Initialized
INFO - 2024-02-21 20:37:01 --> Language Class Initialized
INFO - 2024-02-21 20:37:01 --> Loader Class Initialized
INFO - 2024-02-21 20:37:01 --> Helper loaded: url_helper
INFO - 2024-02-21 20:37:01 --> Helper loaded: file_helper
INFO - 2024-02-21 20:37:01 --> Helper loaded: form_helper
INFO - 2024-02-21 20:37:01 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:37:01 --> Controller Class Initialized
INFO - 2024-02-21 20:37:01 --> Form Validation Class Initialized
INFO - 2024-02-21 20:37:01 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:37:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:37:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:37:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:37:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:37:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:37:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-21 20:37:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:37:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:37:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:37:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-21 20:37:01 --> Final output sent to browser
DEBUG - 2024-02-21 20:37:01 --> Total execution time: 0.0303
ERROR - 2024-02-21 20:37:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:37:03 --> Config Class Initialized
INFO - 2024-02-21 20:37:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:37:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:37:03 --> Utf8 Class Initialized
INFO - 2024-02-21 20:37:03 --> URI Class Initialized
INFO - 2024-02-21 20:37:03 --> Router Class Initialized
INFO - 2024-02-21 20:37:03 --> Output Class Initialized
INFO - 2024-02-21 20:37:03 --> Security Class Initialized
DEBUG - 2024-02-21 20:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:37:03 --> Input Class Initialized
INFO - 2024-02-21 20:37:03 --> Language Class Initialized
INFO - 2024-02-21 20:37:03 --> Loader Class Initialized
INFO - 2024-02-21 20:37:03 --> Helper loaded: url_helper
INFO - 2024-02-21 20:37:03 --> Helper loaded: file_helper
INFO - 2024-02-21 20:37:03 --> Helper loaded: form_helper
INFO - 2024-02-21 20:37:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:37:03 --> Controller Class Initialized
INFO - 2024-02-21 20:37:03 --> Form Validation Class Initialized
INFO - 2024-02-21 20:37:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:37:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:37:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:37:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:37:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:37:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:37:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:37:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:37:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:37:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:37:03 --> Final output sent to browser
DEBUG - 2024-02-21 20:37:03 --> Total execution time: 0.0319
ERROR - 2024-02-21 20:37:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:37:03 --> Config Class Initialized
INFO - 2024-02-21 20:37:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:37:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:37:03 --> Utf8 Class Initialized
INFO - 2024-02-21 20:37:03 --> URI Class Initialized
INFO - 2024-02-21 20:37:03 --> Router Class Initialized
INFO - 2024-02-21 20:37:03 --> Output Class Initialized
INFO - 2024-02-21 20:37:03 --> Security Class Initialized
DEBUG - 2024-02-21 20:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:37:03 --> Input Class Initialized
INFO - 2024-02-21 20:37:03 --> Language Class Initialized
INFO - 2024-02-21 20:37:03 --> Loader Class Initialized
INFO - 2024-02-21 20:37:03 --> Helper loaded: url_helper
INFO - 2024-02-21 20:37:03 --> Helper loaded: file_helper
INFO - 2024-02-21 20:37:03 --> Helper loaded: form_helper
INFO - 2024-02-21 20:37:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:37:03 --> Controller Class Initialized
INFO - 2024-02-21 20:37:03 --> Form Validation Class Initialized
INFO - 2024-02-21 20:37:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:37:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:37:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:37:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:37:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:37:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:37:18 --> Config Class Initialized
INFO - 2024-02-21 20:37:18 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:37:18 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:37:18 --> Utf8 Class Initialized
INFO - 2024-02-21 20:37:18 --> URI Class Initialized
INFO - 2024-02-21 20:37:18 --> Router Class Initialized
INFO - 2024-02-21 20:37:18 --> Output Class Initialized
INFO - 2024-02-21 20:37:18 --> Security Class Initialized
DEBUG - 2024-02-21 20:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:37:18 --> Input Class Initialized
INFO - 2024-02-21 20:37:18 --> Language Class Initialized
INFO - 2024-02-21 20:37:18 --> Loader Class Initialized
INFO - 2024-02-21 20:37:18 --> Helper loaded: url_helper
INFO - 2024-02-21 20:37:18 --> Helper loaded: file_helper
INFO - 2024-02-21 20:37:18 --> Helper loaded: form_helper
INFO - 2024-02-21 20:37:18 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:37:18 --> Controller Class Initialized
INFO - 2024-02-21 20:37:18 --> Form Validation Class Initialized
INFO - 2024-02-21 20:37:18 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:37:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:37:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:37:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:37:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:37:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:37:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:37:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:37:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:37:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:37:18 --> Final output sent to browser
DEBUG - 2024-02-21 20:37:18 --> Total execution time: 0.0277
ERROR - 2024-02-21 20:37:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:37:19 --> Config Class Initialized
INFO - 2024-02-21 20:37:19 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:37:19 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:37:19 --> Utf8 Class Initialized
INFO - 2024-02-21 20:37:19 --> URI Class Initialized
INFO - 2024-02-21 20:37:19 --> Router Class Initialized
INFO - 2024-02-21 20:37:19 --> Output Class Initialized
INFO - 2024-02-21 20:37:19 --> Security Class Initialized
DEBUG - 2024-02-21 20:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:37:19 --> Input Class Initialized
INFO - 2024-02-21 20:37:19 --> Language Class Initialized
INFO - 2024-02-21 20:37:19 --> Loader Class Initialized
INFO - 2024-02-21 20:37:19 --> Helper loaded: url_helper
INFO - 2024-02-21 20:37:19 --> Helper loaded: file_helper
INFO - 2024-02-21 20:37:19 --> Helper loaded: form_helper
INFO - 2024-02-21 20:37:19 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:37:19 --> Controller Class Initialized
INFO - 2024-02-21 20:37:19 --> Form Validation Class Initialized
INFO - 2024-02-21 20:37:19 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:37:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:37:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:37:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:37:19 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:37:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:37:26 --> Config Class Initialized
INFO - 2024-02-21 20:37:26 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:37:26 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:37:26 --> Utf8 Class Initialized
INFO - 2024-02-21 20:37:26 --> URI Class Initialized
INFO - 2024-02-21 20:37:26 --> Router Class Initialized
INFO - 2024-02-21 20:37:26 --> Output Class Initialized
INFO - 2024-02-21 20:37:26 --> Security Class Initialized
DEBUG - 2024-02-21 20:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:37:26 --> Input Class Initialized
INFO - 2024-02-21 20:37:26 --> Language Class Initialized
INFO - 2024-02-21 20:37:26 --> Loader Class Initialized
INFO - 2024-02-21 20:37:26 --> Helper loaded: url_helper
INFO - 2024-02-21 20:37:26 --> Helper loaded: file_helper
INFO - 2024-02-21 20:37:26 --> Helper loaded: form_helper
INFO - 2024-02-21 20:37:26 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:37:26 --> Controller Class Initialized
INFO - 2024-02-21 20:37:26 --> Form Validation Class Initialized
INFO - 2024-02-21 20:37:26 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:37:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:37:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:37:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:37:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:37:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:37:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:37:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:37:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:37:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:37:26 --> Final output sent to browser
DEBUG - 2024-02-21 20:37:26 --> Total execution time: 0.0334
ERROR - 2024-02-21 20:37:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:37:26 --> Config Class Initialized
INFO - 2024-02-21 20:37:26 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:37:26 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:37:26 --> Utf8 Class Initialized
INFO - 2024-02-21 20:37:26 --> URI Class Initialized
INFO - 2024-02-21 20:37:26 --> Router Class Initialized
INFO - 2024-02-21 20:37:26 --> Output Class Initialized
INFO - 2024-02-21 20:37:26 --> Security Class Initialized
DEBUG - 2024-02-21 20:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:37:26 --> Input Class Initialized
INFO - 2024-02-21 20:37:26 --> Language Class Initialized
INFO - 2024-02-21 20:37:26 --> Loader Class Initialized
INFO - 2024-02-21 20:37:26 --> Helper loaded: url_helper
INFO - 2024-02-21 20:37:26 --> Helper loaded: file_helper
INFO - 2024-02-21 20:37:26 --> Helper loaded: form_helper
INFO - 2024-02-21 20:37:26 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:37:26 --> Controller Class Initialized
INFO - 2024-02-21 20:37:26 --> Form Validation Class Initialized
INFO - 2024-02-21 20:37:26 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:37:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:37:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:37:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:37:26 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:38:27 --> Config Class Initialized
INFO - 2024-02-21 20:38:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:38:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:38:27 --> Utf8 Class Initialized
INFO - 2024-02-21 20:38:27 --> URI Class Initialized
INFO - 2024-02-21 20:38:27 --> Router Class Initialized
INFO - 2024-02-21 20:38:27 --> Output Class Initialized
INFO - 2024-02-21 20:38:27 --> Security Class Initialized
DEBUG - 2024-02-21 20:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:38:27 --> Input Class Initialized
INFO - 2024-02-21 20:38:27 --> Language Class Initialized
INFO - 2024-02-21 20:38:27 --> Loader Class Initialized
INFO - 2024-02-21 20:38:27 --> Helper loaded: url_helper
INFO - 2024-02-21 20:38:27 --> Helper loaded: file_helper
INFO - 2024-02-21 20:38:27 --> Helper loaded: form_helper
INFO - 2024-02-21 20:38:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:38:27 --> Controller Class Initialized
INFO - 2024-02-21 20:38:27 --> Form Validation Class Initialized
INFO - 2024-02-21 20:38:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:38:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:38:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:38:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:38:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:38:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:38:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:38:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:38:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:38:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:38:27 --> Final output sent to browser
DEBUG - 2024-02-21 20:38:27 --> Total execution time: 0.0341
ERROR - 2024-02-21 20:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:38:27 --> Config Class Initialized
INFO - 2024-02-21 20:38:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:38:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:38:27 --> Utf8 Class Initialized
INFO - 2024-02-21 20:38:27 --> URI Class Initialized
INFO - 2024-02-21 20:38:27 --> Router Class Initialized
INFO - 2024-02-21 20:38:27 --> Output Class Initialized
INFO - 2024-02-21 20:38:27 --> Security Class Initialized
DEBUG - 2024-02-21 20:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:38:27 --> Input Class Initialized
INFO - 2024-02-21 20:38:27 --> Language Class Initialized
INFO - 2024-02-21 20:38:27 --> Loader Class Initialized
INFO - 2024-02-21 20:38:27 --> Helper loaded: url_helper
INFO - 2024-02-21 20:38:27 --> Helper loaded: file_helper
INFO - 2024-02-21 20:38:27 --> Helper loaded: form_helper
INFO - 2024-02-21 20:38:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:38:27 --> Controller Class Initialized
INFO - 2024-02-21 20:38:27 --> Form Validation Class Initialized
INFO - 2024-02-21 20:38:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:38:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:38:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:38:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:38:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:38:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:38:54 --> Config Class Initialized
INFO - 2024-02-21 20:38:54 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:38:54 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:38:54 --> Utf8 Class Initialized
INFO - 2024-02-21 20:38:54 --> URI Class Initialized
INFO - 2024-02-21 20:38:54 --> Router Class Initialized
INFO - 2024-02-21 20:38:54 --> Output Class Initialized
INFO - 2024-02-21 20:38:54 --> Security Class Initialized
DEBUG - 2024-02-21 20:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:38:54 --> Input Class Initialized
INFO - 2024-02-21 20:38:54 --> Language Class Initialized
INFO - 2024-02-21 20:38:54 --> Loader Class Initialized
INFO - 2024-02-21 20:38:54 --> Helper loaded: url_helper
INFO - 2024-02-21 20:38:54 --> Helper loaded: file_helper
INFO - 2024-02-21 20:38:54 --> Helper loaded: form_helper
INFO - 2024-02-21 20:38:54 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:38:54 --> Controller Class Initialized
INFO - 2024-02-21 20:38:54 --> Form Validation Class Initialized
INFO - 2024-02-21 20:38:54 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:38:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:38:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:38:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:38:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:38:54 --> Final output sent to browser
DEBUG - 2024-02-21 20:38:54 --> Total execution time: 0.0594
ERROR - 2024-02-21 20:38:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:38:54 --> Config Class Initialized
INFO - 2024-02-21 20:38:54 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:38:54 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:38:54 --> Utf8 Class Initialized
INFO - 2024-02-21 20:38:54 --> URI Class Initialized
INFO - 2024-02-21 20:38:54 --> Router Class Initialized
INFO - 2024-02-21 20:38:54 --> Output Class Initialized
INFO - 2024-02-21 20:38:54 --> Security Class Initialized
DEBUG - 2024-02-21 20:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:38:54 --> Input Class Initialized
INFO - 2024-02-21 20:38:54 --> Language Class Initialized
INFO - 2024-02-21 20:38:54 --> Loader Class Initialized
INFO - 2024-02-21 20:38:54 --> Helper loaded: url_helper
INFO - 2024-02-21 20:38:54 --> Helper loaded: file_helper
INFO - 2024-02-21 20:38:54 --> Helper loaded: form_helper
INFO - 2024-02-21 20:38:54 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:38:54 --> Controller Class Initialized
INFO - 2024-02-21 20:38:54 --> Form Validation Class Initialized
INFO - 2024-02-21 20:38:54 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:38:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:38:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:38:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:38:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:39:06 --> Config Class Initialized
INFO - 2024-02-21 20:39:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:39:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:39:06 --> Utf8 Class Initialized
INFO - 2024-02-21 20:39:06 --> URI Class Initialized
INFO - 2024-02-21 20:39:06 --> Router Class Initialized
INFO - 2024-02-21 20:39:06 --> Output Class Initialized
INFO - 2024-02-21 20:39:06 --> Security Class Initialized
DEBUG - 2024-02-21 20:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:39:06 --> Input Class Initialized
INFO - 2024-02-21 20:39:06 --> Language Class Initialized
INFO - 2024-02-21 20:39:06 --> Loader Class Initialized
INFO - 2024-02-21 20:39:06 --> Helper loaded: url_helper
INFO - 2024-02-21 20:39:06 --> Helper loaded: file_helper
INFO - 2024-02-21 20:39:06 --> Helper loaded: form_helper
INFO - 2024-02-21 20:39:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:39:06 --> Controller Class Initialized
INFO - 2024-02-21 20:39:06 --> Form Validation Class Initialized
INFO - 2024-02-21 20:39:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:39:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:39:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:39:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:39:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:39:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:39:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:39:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:39:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:39:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:39:06 --> Final output sent to browser
DEBUG - 2024-02-21 20:39:06 --> Total execution time: 0.0443
ERROR - 2024-02-21 20:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:39:06 --> Config Class Initialized
INFO - 2024-02-21 20:39:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:39:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:39:06 --> Utf8 Class Initialized
INFO - 2024-02-21 20:39:06 --> URI Class Initialized
INFO - 2024-02-21 20:39:06 --> Router Class Initialized
INFO - 2024-02-21 20:39:06 --> Output Class Initialized
INFO - 2024-02-21 20:39:06 --> Security Class Initialized
DEBUG - 2024-02-21 20:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:39:06 --> Input Class Initialized
INFO - 2024-02-21 20:39:06 --> Language Class Initialized
INFO - 2024-02-21 20:39:06 --> Loader Class Initialized
INFO - 2024-02-21 20:39:06 --> Helper loaded: url_helper
INFO - 2024-02-21 20:39:06 --> Helper loaded: file_helper
INFO - 2024-02-21 20:39:06 --> Helper loaded: form_helper
INFO - 2024-02-21 20:39:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:39:06 --> Controller Class Initialized
INFO - 2024-02-21 20:39:06 --> Form Validation Class Initialized
INFO - 2024-02-21 20:39:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:39:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:39:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:39:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:39:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:39:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:39:09 --> Config Class Initialized
INFO - 2024-02-21 20:39:09 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:39:09 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:39:09 --> Utf8 Class Initialized
INFO - 2024-02-21 20:39:09 --> URI Class Initialized
INFO - 2024-02-21 20:39:09 --> Router Class Initialized
INFO - 2024-02-21 20:39:09 --> Output Class Initialized
INFO - 2024-02-21 20:39:09 --> Security Class Initialized
DEBUG - 2024-02-21 20:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:39:09 --> Input Class Initialized
INFO - 2024-02-21 20:39:09 --> Language Class Initialized
INFO - 2024-02-21 20:39:09 --> Loader Class Initialized
INFO - 2024-02-21 20:39:09 --> Helper loaded: url_helper
INFO - 2024-02-21 20:39:09 --> Helper loaded: file_helper
INFO - 2024-02-21 20:39:09 --> Helper loaded: form_helper
INFO - 2024-02-21 20:39:09 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:39:09 --> Controller Class Initialized
INFO - 2024-02-21 20:39:09 --> Form Validation Class Initialized
INFO - 2024-02-21 20:39:09 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:39:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:39:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:39:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:39:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:39:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:39:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:39:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:39:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:39:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:39:09 --> Final output sent to browser
DEBUG - 2024-02-21 20:39:09 --> Total execution time: 0.0351
ERROR - 2024-02-21 20:39:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:39:10 --> Config Class Initialized
INFO - 2024-02-21 20:39:10 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:39:10 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:39:10 --> Utf8 Class Initialized
INFO - 2024-02-21 20:39:10 --> URI Class Initialized
INFO - 2024-02-21 20:39:10 --> Router Class Initialized
INFO - 2024-02-21 20:39:10 --> Output Class Initialized
INFO - 2024-02-21 20:39:10 --> Security Class Initialized
DEBUG - 2024-02-21 20:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:39:10 --> Input Class Initialized
INFO - 2024-02-21 20:39:10 --> Language Class Initialized
INFO - 2024-02-21 20:39:10 --> Loader Class Initialized
INFO - 2024-02-21 20:39:10 --> Helper loaded: url_helper
INFO - 2024-02-21 20:39:10 --> Helper loaded: file_helper
INFO - 2024-02-21 20:39:10 --> Helper loaded: form_helper
INFO - 2024-02-21 20:39:10 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:39:10 --> Controller Class Initialized
INFO - 2024-02-21 20:39:10 --> Form Validation Class Initialized
INFO - 2024-02-21 20:39:10 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:39:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:39:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:39:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:39:10 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:39:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:39:41 --> Config Class Initialized
INFO - 2024-02-21 20:39:41 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:39:41 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:39:41 --> Utf8 Class Initialized
INFO - 2024-02-21 20:39:41 --> URI Class Initialized
INFO - 2024-02-21 20:39:41 --> Router Class Initialized
INFO - 2024-02-21 20:39:41 --> Output Class Initialized
INFO - 2024-02-21 20:39:41 --> Security Class Initialized
DEBUG - 2024-02-21 20:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:39:41 --> Input Class Initialized
INFO - 2024-02-21 20:39:41 --> Language Class Initialized
INFO - 2024-02-21 20:39:41 --> Loader Class Initialized
INFO - 2024-02-21 20:39:41 --> Helper loaded: url_helper
INFO - 2024-02-21 20:39:41 --> Helper loaded: file_helper
INFO - 2024-02-21 20:39:41 --> Helper loaded: form_helper
INFO - 2024-02-21 20:39:41 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:39:41 --> Controller Class Initialized
INFO - 2024-02-21 20:39:41 --> Form Validation Class Initialized
INFO - 2024-02-21 20:39:41 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:39:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:39:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:39:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:39:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:39:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:39:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:39:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:39:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:39:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:39:41 --> Final output sent to browser
DEBUG - 2024-02-21 20:39:41 --> Total execution time: 0.0339
ERROR - 2024-02-21 20:39:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:39:41 --> Config Class Initialized
INFO - 2024-02-21 20:39:41 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:39:41 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:39:41 --> Utf8 Class Initialized
INFO - 2024-02-21 20:39:41 --> URI Class Initialized
INFO - 2024-02-21 20:39:41 --> Router Class Initialized
INFO - 2024-02-21 20:39:41 --> Output Class Initialized
INFO - 2024-02-21 20:39:41 --> Security Class Initialized
DEBUG - 2024-02-21 20:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:39:41 --> Input Class Initialized
INFO - 2024-02-21 20:39:41 --> Language Class Initialized
INFO - 2024-02-21 20:39:41 --> Loader Class Initialized
INFO - 2024-02-21 20:39:41 --> Helper loaded: url_helper
INFO - 2024-02-21 20:39:41 --> Helper loaded: file_helper
INFO - 2024-02-21 20:39:41 --> Helper loaded: form_helper
INFO - 2024-02-21 20:39:41 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:39:41 --> Controller Class Initialized
INFO - 2024-02-21 20:39:41 --> Form Validation Class Initialized
INFO - 2024-02-21 20:39:41 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:39:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:39:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:39:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:39:41 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:39:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:39:46 --> Config Class Initialized
INFO - 2024-02-21 20:39:46 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:39:46 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:39:46 --> Utf8 Class Initialized
INFO - 2024-02-21 20:39:46 --> URI Class Initialized
INFO - 2024-02-21 20:39:46 --> Router Class Initialized
INFO - 2024-02-21 20:39:46 --> Output Class Initialized
INFO - 2024-02-21 20:39:46 --> Security Class Initialized
DEBUG - 2024-02-21 20:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:39:46 --> Input Class Initialized
INFO - 2024-02-21 20:39:46 --> Language Class Initialized
INFO - 2024-02-21 20:39:46 --> Loader Class Initialized
INFO - 2024-02-21 20:39:46 --> Helper loaded: url_helper
INFO - 2024-02-21 20:39:46 --> Helper loaded: file_helper
INFO - 2024-02-21 20:39:46 --> Helper loaded: form_helper
INFO - 2024-02-21 20:39:46 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:39:46 --> Controller Class Initialized
INFO - 2024-02-21 20:39:46 --> Form Validation Class Initialized
INFO - 2024-02-21 20:39:46 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:39:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:39:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:39:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:39:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:39:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:39:49 --> Config Class Initialized
INFO - 2024-02-21 20:39:49 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:39:49 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:39:49 --> Utf8 Class Initialized
INFO - 2024-02-21 20:39:49 --> URI Class Initialized
INFO - 2024-02-21 20:39:49 --> Router Class Initialized
INFO - 2024-02-21 20:39:49 --> Output Class Initialized
INFO - 2024-02-21 20:39:49 --> Security Class Initialized
DEBUG - 2024-02-21 20:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:39:49 --> Input Class Initialized
INFO - 2024-02-21 20:39:49 --> Language Class Initialized
INFO - 2024-02-21 20:39:49 --> Loader Class Initialized
INFO - 2024-02-21 20:39:49 --> Helper loaded: url_helper
INFO - 2024-02-21 20:39:49 --> Helper loaded: file_helper
INFO - 2024-02-21 20:39:49 --> Helper loaded: form_helper
INFO - 2024-02-21 20:39:49 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:39:49 --> Controller Class Initialized
INFO - 2024-02-21 20:39:49 --> Form Validation Class Initialized
INFO - 2024-02-21 20:39:49 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:39:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:39:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:39:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:39:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:39:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:39:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:39:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:39:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:39:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:39:49 --> Final output sent to browser
DEBUG - 2024-02-21 20:39:49 --> Total execution time: 0.0353
ERROR - 2024-02-21 20:39:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:39:50 --> Config Class Initialized
INFO - 2024-02-21 20:39:50 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:39:50 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:39:50 --> Utf8 Class Initialized
INFO - 2024-02-21 20:39:50 --> URI Class Initialized
INFO - 2024-02-21 20:39:50 --> Router Class Initialized
INFO - 2024-02-21 20:39:50 --> Output Class Initialized
INFO - 2024-02-21 20:39:50 --> Security Class Initialized
DEBUG - 2024-02-21 20:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:39:50 --> Input Class Initialized
INFO - 2024-02-21 20:39:50 --> Language Class Initialized
INFO - 2024-02-21 20:39:50 --> Loader Class Initialized
INFO - 2024-02-21 20:39:50 --> Helper loaded: url_helper
INFO - 2024-02-21 20:39:50 --> Helper loaded: file_helper
INFO - 2024-02-21 20:39:50 --> Helper loaded: form_helper
INFO - 2024-02-21 20:39:50 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:39:50 --> Controller Class Initialized
INFO - 2024-02-21 20:39:50 --> Form Validation Class Initialized
INFO - 2024-02-21 20:39:50 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:39:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:39:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:39:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:39:50 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:39:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:39:53 --> Config Class Initialized
INFO - 2024-02-21 20:39:53 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:39:53 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:39:53 --> Utf8 Class Initialized
INFO - 2024-02-21 20:39:53 --> URI Class Initialized
INFO - 2024-02-21 20:39:53 --> Router Class Initialized
INFO - 2024-02-21 20:39:53 --> Output Class Initialized
INFO - 2024-02-21 20:39:53 --> Security Class Initialized
DEBUG - 2024-02-21 20:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:39:53 --> Input Class Initialized
INFO - 2024-02-21 20:39:53 --> Language Class Initialized
INFO - 2024-02-21 20:39:53 --> Loader Class Initialized
INFO - 2024-02-21 20:39:53 --> Helper loaded: url_helper
INFO - 2024-02-21 20:39:53 --> Helper loaded: file_helper
INFO - 2024-02-21 20:39:53 --> Helper loaded: form_helper
INFO - 2024-02-21 20:39:53 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:39:53 --> Controller Class Initialized
INFO - 2024-02-21 20:39:53 --> Form Validation Class Initialized
INFO - 2024-02-21 20:39:53 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:39:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:39:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:39:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:39:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:39:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:39:56 --> Config Class Initialized
INFO - 2024-02-21 20:39:56 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:39:56 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:39:56 --> Utf8 Class Initialized
INFO - 2024-02-21 20:39:56 --> URI Class Initialized
INFO - 2024-02-21 20:39:56 --> Router Class Initialized
INFO - 2024-02-21 20:39:56 --> Output Class Initialized
INFO - 2024-02-21 20:39:56 --> Security Class Initialized
DEBUG - 2024-02-21 20:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:39:56 --> Input Class Initialized
INFO - 2024-02-21 20:39:56 --> Language Class Initialized
INFO - 2024-02-21 20:39:56 --> Loader Class Initialized
INFO - 2024-02-21 20:39:56 --> Helper loaded: url_helper
INFO - 2024-02-21 20:39:56 --> Helper loaded: file_helper
INFO - 2024-02-21 20:39:56 --> Helper loaded: form_helper
INFO - 2024-02-21 20:39:56 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:39:56 --> Controller Class Initialized
INFO - 2024-02-21 20:39:56 --> Form Validation Class Initialized
INFO - 2024-02-21 20:39:56 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:39:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:39:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:39:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:39:56 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:40:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:40:07 --> Config Class Initialized
INFO - 2024-02-21 20:40:07 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:40:07 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:40:07 --> Utf8 Class Initialized
INFO - 2024-02-21 20:40:07 --> URI Class Initialized
INFO - 2024-02-21 20:40:07 --> Router Class Initialized
INFO - 2024-02-21 20:40:07 --> Output Class Initialized
INFO - 2024-02-21 20:40:07 --> Security Class Initialized
DEBUG - 2024-02-21 20:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:40:07 --> Input Class Initialized
INFO - 2024-02-21 20:40:07 --> Language Class Initialized
INFO - 2024-02-21 20:40:07 --> Loader Class Initialized
INFO - 2024-02-21 20:40:07 --> Helper loaded: url_helper
INFO - 2024-02-21 20:40:07 --> Helper loaded: file_helper
INFO - 2024-02-21 20:40:07 --> Helper loaded: form_helper
INFO - 2024-02-21 20:40:07 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:40:07 --> Controller Class Initialized
INFO - 2024-02-21 20:40:07 --> Form Validation Class Initialized
INFO - 2024-02-21 20:40:07 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:40:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:40:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:40:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:40:07 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:41:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:41:05 --> Config Class Initialized
INFO - 2024-02-21 20:41:05 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:41:05 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:41:05 --> Utf8 Class Initialized
INFO - 2024-02-21 20:41:05 --> URI Class Initialized
INFO - 2024-02-21 20:41:05 --> Router Class Initialized
INFO - 2024-02-21 20:41:05 --> Output Class Initialized
INFO - 2024-02-21 20:41:05 --> Security Class Initialized
DEBUG - 2024-02-21 20:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:41:05 --> Input Class Initialized
INFO - 2024-02-21 20:41:05 --> Language Class Initialized
INFO - 2024-02-21 20:41:05 --> Loader Class Initialized
INFO - 2024-02-21 20:41:05 --> Helper loaded: url_helper
INFO - 2024-02-21 20:41:05 --> Helper loaded: file_helper
INFO - 2024-02-21 20:41:05 --> Helper loaded: form_helper
INFO - 2024-02-21 20:41:05 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:41:05 --> Controller Class Initialized
INFO - 2024-02-21 20:41:05 --> Form Validation Class Initialized
INFO - 2024-02-21 20:41:05 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:41:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:41:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:41:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:41:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:41:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:41:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:41:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:41:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:41:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:41:05 --> Final output sent to browser
DEBUG - 2024-02-21 20:41:05 --> Total execution time: 0.0377
ERROR - 2024-02-21 20:41:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:41:06 --> Config Class Initialized
INFO - 2024-02-21 20:41:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:41:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:41:06 --> Utf8 Class Initialized
INFO - 2024-02-21 20:41:06 --> URI Class Initialized
INFO - 2024-02-21 20:41:06 --> Router Class Initialized
INFO - 2024-02-21 20:41:06 --> Output Class Initialized
INFO - 2024-02-21 20:41:06 --> Security Class Initialized
DEBUG - 2024-02-21 20:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:41:06 --> Input Class Initialized
INFO - 2024-02-21 20:41:06 --> Language Class Initialized
INFO - 2024-02-21 20:41:06 --> Loader Class Initialized
INFO - 2024-02-21 20:41:06 --> Helper loaded: url_helper
INFO - 2024-02-21 20:41:06 --> Helper loaded: file_helper
INFO - 2024-02-21 20:41:06 --> Helper loaded: form_helper
INFO - 2024-02-21 20:41:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:41:06 --> Controller Class Initialized
INFO - 2024-02-21 20:41:06 --> Form Validation Class Initialized
INFO - 2024-02-21 20:41:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:41:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:41:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:41:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:41:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:41:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:41:11 --> Config Class Initialized
INFO - 2024-02-21 20:41:11 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:41:11 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:41:11 --> Utf8 Class Initialized
INFO - 2024-02-21 20:41:11 --> URI Class Initialized
INFO - 2024-02-21 20:41:11 --> Router Class Initialized
INFO - 2024-02-21 20:41:11 --> Output Class Initialized
INFO - 2024-02-21 20:41:11 --> Security Class Initialized
DEBUG - 2024-02-21 20:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:41:11 --> Input Class Initialized
INFO - 2024-02-21 20:41:11 --> Language Class Initialized
INFO - 2024-02-21 20:41:11 --> Loader Class Initialized
INFO - 2024-02-21 20:41:11 --> Helper loaded: url_helper
INFO - 2024-02-21 20:41:11 --> Helper loaded: file_helper
INFO - 2024-02-21 20:41:11 --> Helper loaded: form_helper
INFO - 2024-02-21 20:41:11 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:41:11 --> Controller Class Initialized
INFO - 2024-02-21 20:41:11 --> Form Validation Class Initialized
INFO - 2024-02-21 20:41:11 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:41:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:41:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:41:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:41:11 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:41:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:41:18 --> Config Class Initialized
INFO - 2024-02-21 20:41:18 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:41:18 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:41:18 --> Utf8 Class Initialized
INFO - 2024-02-21 20:41:18 --> URI Class Initialized
INFO - 2024-02-21 20:41:18 --> Router Class Initialized
INFO - 2024-02-21 20:41:18 --> Output Class Initialized
INFO - 2024-02-21 20:41:18 --> Security Class Initialized
DEBUG - 2024-02-21 20:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:41:18 --> Input Class Initialized
INFO - 2024-02-21 20:41:18 --> Language Class Initialized
INFO - 2024-02-21 20:41:18 --> Loader Class Initialized
INFO - 2024-02-21 20:41:18 --> Helper loaded: url_helper
INFO - 2024-02-21 20:41:18 --> Helper loaded: file_helper
INFO - 2024-02-21 20:41:18 --> Helper loaded: form_helper
INFO - 2024-02-21 20:41:18 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:41:18 --> Controller Class Initialized
INFO - 2024-02-21 20:41:18 --> Form Validation Class Initialized
INFO - 2024-02-21 20:41:18 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:41:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:41:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:41:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:41:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:41:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:41:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:41:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:41:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:41:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:41:18 --> Final output sent to browser
DEBUG - 2024-02-21 20:41:18 --> Total execution time: 0.0345
ERROR - 2024-02-21 20:41:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:41:19 --> Config Class Initialized
INFO - 2024-02-21 20:41:19 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:41:19 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:41:19 --> Utf8 Class Initialized
INFO - 2024-02-21 20:41:19 --> URI Class Initialized
INFO - 2024-02-21 20:41:19 --> Router Class Initialized
INFO - 2024-02-21 20:41:19 --> Output Class Initialized
INFO - 2024-02-21 20:41:19 --> Security Class Initialized
DEBUG - 2024-02-21 20:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:41:19 --> Input Class Initialized
INFO - 2024-02-21 20:41:19 --> Language Class Initialized
INFO - 2024-02-21 20:41:19 --> Loader Class Initialized
INFO - 2024-02-21 20:41:19 --> Helper loaded: url_helper
INFO - 2024-02-21 20:41:19 --> Helper loaded: file_helper
INFO - 2024-02-21 20:41:19 --> Helper loaded: form_helper
INFO - 2024-02-21 20:41:19 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:41:19 --> Controller Class Initialized
INFO - 2024-02-21 20:41:19 --> Form Validation Class Initialized
INFO - 2024-02-21 20:41:19 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:41:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:41:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:41:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:41:19 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:41:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:41:23 --> Config Class Initialized
INFO - 2024-02-21 20:41:23 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:41:23 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:41:23 --> Utf8 Class Initialized
INFO - 2024-02-21 20:41:23 --> URI Class Initialized
INFO - 2024-02-21 20:41:23 --> Router Class Initialized
INFO - 2024-02-21 20:41:23 --> Output Class Initialized
INFO - 2024-02-21 20:41:23 --> Security Class Initialized
DEBUG - 2024-02-21 20:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:41:23 --> Input Class Initialized
INFO - 2024-02-21 20:41:23 --> Language Class Initialized
INFO - 2024-02-21 20:41:23 --> Loader Class Initialized
INFO - 2024-02-21 20:41:23 --> Helper loaded: url_helper
INFO - 2024-02-21 20:41:23 --> Helper loaded: file_helper
INFO - 2024-02-21 20:41:23 --> Helper loaded: form_helper
INFO - 2024-02-21 20:41:23 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:41:23 --> Controller Class Initialized
INFO - 2024-02-21 20:41:23 --> Form Validation Class Initialized
INFO - 2024-02-21 20:41:23 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:41:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:41:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:41:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:41:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:42:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:42:41 --> Config Class Initialized
INFO - 2024-02-21 20:42:41 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:42:41 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:42:41 --> Utf8 Class Initialized
INFO - 2024-02-21 20:42:41 --> URI Class Initialized
INFO - 2024-02-21 20:42:41 --> Router Class Initialized
INFO - 2024-02-21 20:42:41 --> Output Class Initialized
INFO - 2024-02-21 20:42:41 --> Security Class Initialized
DEBUG - 2024-02-21 20:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:42:41 --> Input Class Initialized
INFO - 2024-02-21 20:42:41 --> Language Class Initialized
INFO - 2024-02-21 20:42:41 --> Loader Class Initialized
INFO - 2024-02-21 20:42:41 --> Helper loaded: url_helper
INFO - 2024-02-21 20:42:41 --> Helper loaded: file_helper
INFO - 2024-02-21 20:42:41 --> Helper loaded: form_helper
INFO - 2024-02-21 20:42:41 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:42:41 --> Controller Class Initialized
INFO - 2024-02-21 20:42:41 --> Form Validation Class Initialized
INFO - 2024-02-21 20:42:41 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:42:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:42:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:42:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:42:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:42:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:42:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:42:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:42:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:42:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:42:41 --> Final output sent to browser
DEBUG - 2024-02-21 20:42:41 --> Total execution time: 0.0369
ERROR - 2024-02-21 20:42:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:42:42 --> Config Class Initialized
INFO - 2024-02-21 20:42:42 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:42:42 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:42:42 --> Utf8 Class Initialized
INFO - 2024-02-21 20:42:42 --> URI Class Initialized
INFO - 2024-02-21 20:42:42 --> Router Class Initialized
INFO - 2024-02-21 20:42:42 --> Output Class Initialized
INFO - 2024-02-21 20:42:42 --> Security Class Initialized
DEBUG - 2024-02-21 20:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:42:42 --> Input Class Initialized
INFO - 2024-02-21 20:42:42 --> Language Class Initialized
INFO - 2024-02-21 20:42:42 --> Loader Class Initialized
INFO - 2024-02-21 20:42:42 --> Helper loaded: url_helper
INFO - 2024-02-21 20:42:42 --> Helper loaded: file_helper
INFO - 2024-02-21 20:42:42 --> Helper loaded: form_helper
INFO - 2024-02-21 20:42:42 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:42:42 --> Controller Class Initialized
INFO - 2024-02-21 20:42:42 --> Form Validation Class Initialized
INFO - 2024-02-21 20:42:42 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:42:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:42:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:42:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:42:42 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:42:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:42:51 --> Config Class Initialized
INFO - 2024-02-21 20:42:51 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:42:51 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:42:51 --> Utf8 Class Initialized
INFO - 2024-02-21 20:42:51 --> URI Class Initialized
INFO - 2024-02-21 20:42:51 --> Router Class Initialized
INFO - 2024-02-21 20:42:51 --> Output Class Initialized
INFO - 2024-02-21 20:42:51 --> Security Class Initialized
DEBUG - 2024-02-21 20:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:42:51 --> Input Class Initialized
INFO - 2024-02-21 20:42:51 --> Language Class Initialized
INFO - 2024-02-21 20:42:51 --> Loader Class Initialized
INFO - 2024-02-21 20:42:51 --> Helper loaded: url_helper
INFO - 2024-02-21 20:42:51 --> Helper loaded: file_helper
INFO - 2024-02-21 20:42:51 --> Helper loaded: form_helper
INFO - 2024-02-21 20:42:51 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:42:51 --> Controller Class Initialized
INFO - 2024-02-21 20:42:51 --> Form Validation Class Initialized
INFO - 2024-02-21 20:42:51 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:42:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:42:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:42:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:42:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:42:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:42:51 --> Final output sent to browser
DEBUG - 2024-02-21 20:42:51 --> Total execution time: 0.0363
ERROR - 2024-02-21 20:42:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:42:51 --> Config Class Initialized
INFO - 2024-02-21 20:42:51 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:42:51 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:42:51 --> Utf8 Class Initialized
INFO - 2024-02-21 20:42:51 --> URI Class Initialized
INFO - 2024-02-21 20:42:51 --> Router Class Initialized
INFO - 2024-02-21 20:42:51 --> Output Class Initialized
INFO - 2024-02-21 20:42:51 --> Security Class Initialized
DEBUG - 2024-02-21 20:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:42:51 --> Input Class Initialized
INFO - 2024-02-21 20:42:51 --> Language Class Initialized
INFO - 2024-02-21 20:42:51 --> Loader Class Initialized
INFO - 2024-02-21 20:42:51 --> Helper loaded: url_helper
INFO - 2024-02-21 20:42:51 --> Helper loaded: file_helper
INFO - 2024-02-21 20:42:51 --> Helper loaded: form_helper
INFO - 2024-02-21 20:42:51 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:42:51 --> Controller Class Initialized
INFO - 2024-02-21 20:42:51 --> Form Validation Class Initialized
INFO - 2024-02-21 20:42:51 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:42:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:42:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:42:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:42:51 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:43:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:43:24 --> Config Class Initialized
INFO - 2024-02-21 20:43:24 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:43:24 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:43:24 --> Utf8 Class Initialized
INFO - 2024-02-21 20:43:24 --> URI Class Initialized
INFO - 2024-02-21 20:43:24 --> Router Class Initialized
INFO - 2024-02-21 20:43:24 --> Output Class Initialized
INFO - 2024-02-21 20:43:24 --> Security Class Initialized
DEBUG - 2024-02-21 20:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:43:24 --> Input Class Initialized
INFO - 2024-02-21 20:43:24 --> Language Class Initialized
INFO - 2024-02-21 20:43:24 --> Loader Class Initialized
INFO - 2024-02-21 20:43:24 --> Helper loaded: url_helper
INFO - 2024-02-21 20:43:24 --> Helper loaded: file_helper
INFO - 2024-02-21 20:43:24 --> Helper loaded: form_helper
INFO - 2024-02-21 20:43:24 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:43:24 --> Controller Class Initialized
INFO - 2024-02-21 20:43:24 --> Form Validation Class Initialized
INFO - 2024-02-21 20:43:24 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:43:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:43:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:43:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:43:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:43:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:43:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:43:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:43:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:43:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:43:24 --> Final output sent to browser
DEBUG - 2024-02-21 20:43:24 --> Total execution time: 0.0282
ERROR - 2024-02-21 20:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:43:25 --> Config Class Initialized
INFO - 2024-02-21 20:43:25 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:43:25 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:43:25 --> Utf8 Class Initialized
INFO - 2024-02-21 20:43:25 --> URI Class Initialized
INFO - 2024-02-21 20:43:25 --> Router Class Initialized
INFO - 2024-02-21 20:43:25 --> Output Class Initialized
INFO - 2024-02-21 20:43:25 --> Security Class Initialized
DEBUG - 2024-02-21 20:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:43:25 --> Input Class Initialized
INFO - 2024-02-21 20:43:25 --> Language Class Initialized
INFO - 2024-02-21 20:43:25 --> Loader Class Initialized
INFO - 2024-02-21 20:43:25 --> Helper loaded: url_helper
INFO - 2024-02-21 20:43:25 --> Helper loaded: file_helper
INFO - 2024-02-21 20:43:25 --> Helper loaded: form_helper
INFO - 2024-02-21 20:43:25 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:43:25 --> Controller Class Initialized
INFO - 2024-02-21 20:43:25 --> Form Validation Class Initialized
INFO - 2024-02-21 20:43:25 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:43:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:43:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:43:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:43:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:45:21 --> Config Class Initialized
INFO - 2024-02-21 20:45:21 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:45:21 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:45:21 --> Utf8 Class Initialized
INFO - 2024-02-21 20:45:21 --> URI Class Initialized
INFO - 2024-02-21 20:45:21 --> Router Class Initialized
INFO - 2024-02-21 20:45:21 --> Output Class Initialized
INFO - 2024-02-21 20:45:21 --> Security Class Initialized
DEBUG - 2024-02-21 20:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:45:21 --> Input Class Initialized
INFO - 2024-02-21 20:45:21 --> Language Class Initialized
INFO - 2024-02-21 20:45:21 --> Loader Class Initialized
INFO - 2024-02-21 20:45:21 --> Helper loaded: url_helper
INFO - 2024-02-21 20:45:21 --> Helper loaded: file_helper
INFO - 2024-02-21 20:45:21 --> Helper loaded: form_helper
INFO - 2024-02-21 20:45:21 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:45:21 --> Controller Class Initialized
INFO - 2024-02-21 20:45:21 --> Form Validation Class Initialized
INFO - 2024-02-21 20:45:21 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:45:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:45:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:45:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:45:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:45:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:45:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:45:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:45:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:45:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:45:21 --> Final output sent to browser
DEBUG - 2024-02-21 20:45:21 --> Total execution time: 0.0326
ERROR - 2024-02-21 20:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:45:21 --> Config Class Initialized
INFO - 2024-02-21 20:45:21 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:45:21 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:45:21 --> Utf8 Class Initialized
INFO - 2024-02-21 20:45:21 --> URI Class Initialized
INFO - 2024-02-21 20:45:21 --> Router Class Initialized
INFO - 2024-02-21 20:45:21 --> Output Class Initialized
INFO - 2024-02-21 20:45:21 --> Security Class Initialized
DEBUG - 2024-02-21 20:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:45:21 --> Input Class Initialized
INFO - 2024-02-21 20:45:21 --> Language Class Initialized
INFO - 2024-02-21 20:45:21 --> Loader Class Initialized
INFO - 2024-02-21 20:45:21 --> Helper loaded: url_helper
INFO - 2024-02-21 20:45:21 --> Helper loaded: file_helper
INFO - 2024-02-21 20:45:21 --> Helper loaded: form_helper
INFO - 2024-02-21 20:45:21 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:45:21 --> Controller Class Initialized
INFO - 2024-02-21 20:45:21 --> Form Validation Class Initialized
INFO - 2024-02-21 20:45:21 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:45:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:45:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:45:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:45:21 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:46:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:46:23 --> Config Class Initialized
INFO - 2024-02-21 20:46:23 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:46:23 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:46:23 --> Utf8 Class Initialized
INFO - 2024-02-21 20:46:23 --> URI Class Initialized
INFO - 2024-02-21 20:46:23 --> Router Class Initialized
INFO - 2024-02-21 20:46:23 --> Output Class Initialized
INFO - 2024-02-21 20:46:23 --> Security Class Initialized
DEBUG - 2024-02-21 20:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:46:23 --> Input Class Initialized
INFO - 2024-02-21 20:46:23 --> Language Class Initialized
INFO - 2024-02-21 20:46:23 --> Loader Class Initialized
INFO - 2024-02-21 20:46:23 --> Helper loaded: url_helper
INFO - 2024-02-21 20:46:23 --> Helper loaded: file_helper
INFO - 2024-02-21 20:46:23 --> Helper loaded: form_helper
INFO - 2024-02-21 20:46:23 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:46:23 --> Controller Class Initialized
INFO - 2024-02-21 20:46:23 --> Form Validation Class Initialized
INFO - 2024-02-21 20:46:23 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:46:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:46:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:46:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:46:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:46:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:46:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:46:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:46:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:46:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:46:23 --> Final output sent to browser
DEBUG - 2024-02-21 20:46:23 --> Total execution time: 0.0344
ERROR - 2024-02-21 20:46:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:46:24 --> Config Class Initialized
INFO - 2024-02-21 20:46:24 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:46:24 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:46:24 --> Utf8 Class Initialized
INFO - 2024-02-21 20:46:24 --> URI Class Initialized
INFO - 2024-02-21 20:46:24 --> Router Class Initialized
INFO - 2024-02-21 20:46:24 --> Output Class Initialized
INFO - 2024-02-21 20:46:24 --> Security Class Initialized
DEBUG - 2024-02-21 20:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:46:24 --> Input Class Initialized
INFO - 2024-02-21 20:46:24 --> Language Class Initialized
INFO - 2024-02-21 20:46:24 --> Loader Class Initialized
INFO - 2024-02-21 20:46:24 --> Helper loaded: url_helper
INFO - 2024-02-21 20:46:24 --> Helper loaded: file_helper
INFO - 2024-02-21 20:46:24 --> Helper loaded: form_helper
INFO - 2024-02-21 20:46:24 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:46:24 --> Controller Class Initialized
INFO - 2024-02-21 20:46:24 --> Form Validation Class Initialized
INFO - 2024-02-21 20:46:24 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:46:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:46:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:46:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:46:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:46:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:46:27 --> Config Class Initialized
INFO - 2024-02-21 20:46:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:46:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:46:27 --> Utf8 Class Initialized
INFO - 2024-02-21 20:46:27 --> URI Class Initialized
INFO - 2024-02-21 20:46:27 --> Router Class Initialized
INFO - 2024-02-21 20:46:27 --> Output Class Initialized
INFO - 2024-02-21 20:46:27 --> Security Class Initialized
DEBUG - 2024-02-21 20:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:46:27 --> Input Class Initialized
INFO - 2024-02-21 20:46:27 --> Language Class Initialized
INFO - 2024-02-21 20:46:27 --> Loader Class Initialized
INFO - 2024-02-21 20:46:27 --> Helper loaded: url_helper
INFO - 2024-02-21 20:46:27 --> Helper loaded: file_helper
INFO - 2024-02-21 20:46:27 --> Helper loaded: form_helper
INFO - 2024-02-21 20:46:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:46:27 --> Controller Class Initialized
INFO - 2024-02-21 20:46:27 --> Form Validation Class Initialized
INFO - 2024-02-21 20:46:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:46:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:46:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:46:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:46:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:46:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:46:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:46:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:46:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:46:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:46:27 --> Final output sent to browser
DEBUG - 2024-02-21 20:46:27 --> Total execution time: 0.0365
ERROR - 2024-02-21 20:46:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:46:28 --> Config Class Initialized
INFO - 2024-02-21 20:46:28 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:46:28 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:46:28 --> Utf8 Class Initialized
INFO - 2024-02-21 20:46:28 --> URI Class Initialized
INFO - 2024-02-21 20:46:28 --> Router Class Initialized
INFO - 2024-02-21 20:46:28 --> Output Class Initialized
INFO - 2024-02-21 20:46:28 --> Security Class Initialized
DEBUG - 2024-02-21 20:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:46:28 --> Input Class Initialized
INFO - 2024-02-21 20:46:28 --> Language Class Initialized
INFO - 2024-02-21 20:46:28 --> Loader Class Initialized
INFO - 2024-02-21 20:46:28 --> Helper loaded: url_helper
INFO - 2024-02-21 20:46:28 --> Helper loaded: file_helper
INFO - 2024-02-21 20:46:28 --> Helper loaded: form_helper
INFO - 2024-02-21 20:46:28 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:46:28 --> Controller Class Initialized
INFO - 2024-02-21 20:46:28 --> Form Validation Class Initialized
INFO - 2024-02-21 20:46:28 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:46:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:46:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:46:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:46:28 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:47:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:47:29 --> Config Class Initialized
INFO - 2024-02-21 20:47:29 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:47:29 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:47:29 --> Utf8 Class Initialized
INFO - 2024-02-21 20:47:29 --> URI Class Initialized
INFO - 2024-02-21 20:47:29 --> Router Class Initialized
INFO - 2024-02-21 20:47:29 --> Output Class Initialized
INFO - 2024-02-21 20:47:29 --> Security Class Initialized
DEBUG - 2024-02-21 20:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:47:29 --> Input Class Initialized
INFO - 2024-02-21 20:47:29 --> Language Class Initialized
INFO - 2024-02-21 20:47:29 --> Loader Class Initialized
INFO - 2024-02-21 20:47:29 --> Helper loaded: url_helper
INFO - 2024-02-21 20:47:29 --> Helper loaded: file_helper
INFO - 2024-02-21 20:47:29 --> Helper loaded: form_helper
INFO - 2024-02-21 20:47:29 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:47:29 --> Controller Class Initialized
INFO - 2024-02-21 20:47:29 --> Form Validation Class Initialized
INFO - 2024-02-21 20:47:29 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:47:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:47:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:47:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:47:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:47:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:47:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:47:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:47:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:47:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:47:29 --> Final output sent to browser
DEBUG - 2024-02-21 20:47:29 --> Total execution time: 0.0322
ERROR - 2024-02-21 20:47:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:47:29 --> Config Class Initialized
INFO - 2024-02-21 20:47:29 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:47:29 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:47:29 --> Utf8 Class Initialized
INFO - 2024-02-21 20:47:29 --> URI Class Initialized
INFO - 2024-02-21 20:47:29 --> Router Class Initialized
INFO - 2024-02-21 20:47:29 --> Output Class Initialized
INFO - 2024-02-21 20:47:29 --> Security Class Initialized
DEBUG - 2024-02-21 20:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:47:29 --> Input Class Initialized
INFO - 2024-02-21 20:47:29 --> Language Class Initialized
INFO - 2024-02-21 20:47:29 --> Loader Class Initialized
INFO - 2024-02-21 20:47:29 --> Helper loaded: url_helper
INFO - 2024-02-21 20:47:29 --> Helper loaded: file_helper
INFO - 2024-02-21 20:47:29 --> Helper loaded: form_helper
INFO - 2024-02-21 20:47:29 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:47:29 --> Controller Class Initialized
INFO - 2024-02-21 20:47:29 --> Form Validation Class Initialized
INFO - 2024-02-21 20:47:29 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:47:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:47:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:47:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:47:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:48:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:48:26 --> Config Class Initialized
INFO - 2024-02-21 20:48:26 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:48:26 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:48:26 --> Utf8 Class Initialized
INFO - 2024-02-21 20:48:26 --> URI Class Initialized
INFO - 2024-02-21 20:48:26 --> Router Class Initialized
INFO - 2024-02-21 20:48:26 --> Output Class Initialized
INFO - 2024-02-21 20:48:26 --> Security Class Initialized
DEBUG - 2024-02-21 20:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:48:26 --> Input Class Initialized
INFO - 2024-02-21 20:48:26 --> Language Class Initialized
INFO - 2024-02-21 20:48:26 --> Loader Class Initialized
INFO - 2024-02-21 20:48:26 --> Helper loaded: url_helper
INFO - 2024-02-21 20:48:26 --> Helper loaded: file_helper
INFO - 2024-02-21 20:48:26 --> Helper loaded: form_helper
INFO - 2024-02-21 20:48:26 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:48:26 --> Controller Class Initialized
INFO - 2024-02-21 20:48:26 --> Form Validation Class Initialized
INFO - 2024-02-21 20:48:26 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:48:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:48:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:48:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:48:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:48:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:48:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:48:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:48:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:48:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:48:26 --> Final output sent to browser
DEBUG - 2024-02-21 20:48:26 --> Total execution time: 0.0348
ERROR - 2024-02-21 20:48:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:48:26 --> Config Class Initialized
INFO - 2024-02-21 20:48:26 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:48:26 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:48:26 --> Utf8 Class Initialized
INFO - 2024-02-21 20:48:26 --> URI Class Initialized
INFO - 2024-02-21 20:48:26 --> Router Class Initialized
INFO - 2024-02-21 20:48:26 --> Output Class Initialized
INFO - 2024-02-21 20:48:26 --> Security Class Initialized
DEBUG - 2024-02-21 20:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:48:26 --> Input Class Initialized
INFO - 2024-02-21 20:48:26 --> Language Class Initialized
INFO - 2024-02-21 20:48:26 --> Loader Class Initialized
INFO - 2024-02-21 20:48:26 --> Helper loaded: url_helper
INFO - 2024-02-21 20:48:26 --> Helper loaded: file_helper
INFO - 2024-02-21 20:48:26 --> Helper loaded: form_helper
INFO - 2024-02-21 20:48:26 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:48:26 --> Controller Class Initialized
INFO - 2024-02-21 20:48:26 --> Form Validation Class Initialized
INFO - 2024-02-21 20:48:26 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:48:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:48:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:48:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:48:26 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:48:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:48:33 --> Config Class Initialized
INFO - 2024-02-21 20:48:33 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:48:33 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:48:33 --> Utf8 Class Initialized
INFO - 2024-02-21 20:48:33 --> URI Class Initialized
INFO - 2024-02-21 20:48:33 --> Router Class Initialized
INFO - 2024-02-21 20:48:33 --> Output Class Initialized
INFO - 2024-02-21 20:48:33 --> Security Class Initialized
DEBUG - 2024-02-21 20:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:48:33 --> Input Class Initialized
INFO - 2024-02-21 20:48:33 --> Language Class Initialized
INFO - 2024-02-21 20:48:33 --> Loader Class Initialized
INFO - 2024-02-21 20:48:33 --> Helper loaded: url_helper
INFO - 2024-02-21 20:48:33 --> Helper loaded: file_helper
INFO - 2024-02-21 20:48:33 --> Helper loaded: form_helper
INFO - 2024-02-21 20:48:33 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:48:33 --> Controller Class Initialized
INFO - 2024-02-21 20:48:33 --> Form Validation Class Initialized
INFO - 2024-02-21 20:48:33 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:48:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:48:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:48:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:48:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:48:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:48:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:48:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:48:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:48:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:48:33 --> Final output sent to browser
DEBUG - 2024-02-21 20:48:33 --> Total execution time: 0.0369
ERROR - 2024-02-21 20:48:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:48:33 --> Config Class Initialized
INFO - 2024-02-21 20:48:33 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:48:33 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:48:33 --> Utf8 Class Initialized
INFO - 2024-02-21 20:48:33 --> URI Class Initialized
INFO - 2024-02-21 20:48:33 --> Router Class Initialized
INFO - 2024-02-21 20:48:33 --> Output Class Initialized
INFO - 2024-02-21 20:48:33 --> Security Class Initialized
DEBUG - 2024-02-21 20:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:48:33 --> Input Class Initialized
INFO - 2024-02-21 20:48:33 --> Language Class Initialized
INFO - 2024-02-21 20:48:33 --> Loader Class Initialized
INFO - 2024-02-21 20:48:33 --> Helper loaded: url_helper
INFO - 2024-02-21 20:48:33 --> Helper loaded: file_helper
INFO - 2024-02-21 20:48:33 --> Helper loaded: form_helper
INFO - 2024-02-21 20:48:33 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:48:33 --> Controller Class Initialized
INFO - 2024-02-21 20:48:33 --> Form Validation Class Initialized
INFO - 2024-02-21 20:48:33 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:48:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:48:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:48:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:48:33 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:48:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:48:43 --> Config Class Initialized
INFO - 2024-02-21 20:48:43 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:48:43 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:48:43 --> Utf8 Class Initialized
INFO - 2024-02-21 20:48:43 --> URI Class Initialized
INFO - 2024-02-21 20:48:43 --> Router Class Initialized
INFO - 2024-02-21 20:48:43 --> Output Class Initialized
INFO - 2024-02-21 20:48:43 --> Security Class Initialized
DEBUG - 2024-02-21 20:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:48:43 --> Input Class Initialized
INFO - 2024-02-21 20:48:43 --> Language Class Initialized
INFO - 2024-02-21 20:48:43 --> Loader Class Initialized
INFO - 2024-02-21 20:48:43 --> Helper loaded: url_helper
INFO - 2024-02-21 20:48:43 --> Helper loaded: file_helper
INFO - 2024-02-21 20:48:43 --> Helper loaded: form_helper
INFO - 2024-02-21 20:48:43 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:48:43 --> Controller Class Initialized
INFO - 2024-02-21 20:48:43 --> Form Validation Class Initialized
INFO - 2024-02-21 20:48:43 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:48:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:48:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:48:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:48:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:48:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:48:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:48:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:48:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:48:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:48:43 --> Final output sent to browser
DEBUG - 2024-02-21 20:48:43 --> Total execution time: 0.0310
ERROR - 2024-02-21 20:48:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:48:43 --> Config Class Initialized
INFO - 2024-02-21 20:48:43 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:48:43 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:48:43 --> Utf8 Class Initialized
INFO - 2024-02-21 20:48:43 --> URI Class Initialized
INFO - 2024-02-21 20:48:43 --> Router Class Initialized
INFO - 2024-02-21 20:48:43 --> Output Class Initialized
INFO - 2024-02-21 20:48:43 --> Security Class Initialized
DEBUG - 2024-02-21 20:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:48:43 --> Input Class Initialized
INFO - 2024-02-21 20:48:43 --> Language Class Initialized
INFO - 2024-02-21 20:48:43 --> Loader Class Initialized
INFO - 2024-02-21 20:48:43 --> Helper loaded: url_helper
INFO - 2024-02-21 20:48:43 --> Helper loaded: file_helper
INFO - 2024-02-21 20:48:43 --> Helper loaded: form_helper
INFO - 2024-02-21 20:48:43 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:48:43 --> Controller Class Initialized
INFO - 2024-02-21 20:48:43 --> Form Validation Class Initialized
INFO - 2024-02-21 20:48:43 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:48:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:48:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:48:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:48:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:52:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:52:19 --> Config Class Initialized
INFO - 2024-02-21 20:52:19 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:52:19 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:52:19 --> Utf8 Class Initialized
INFO - 2024-02-21 20:52:19 --> URI Class Initialized
INFO - 2024-02-21 20:52:19 --> Router Class Initialized
INFO - 2024-02-21 20:52:19 --> Output Class Initialized
INFO - 2024-02-21 20:52:19 --> Security Class Initialized
DEBUG - 2024-02-21 20:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:52:19 --> Input Class Initialized
INFO - 2024-02-21 20:52:19 --> Language Class Initialized
INFO - 2024-02-21 20:52:19 --> Loader Class Initialized
INFO - 2024-02-21 20:52:19 --> Helper loaded: url_helper
INFO - 2024-02-21 20:52:19 --> Helper loaded: file_helper
INFO - 2024-02-21 20:52:19 --> Helper loaded: form_helper
INFO - 2024-02-21 20:52:19 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:52:19 --> Controller Class Initialized
INFO - 2024-02-21 20:52:19 --> Form Validation Class Initialized
INFO - 2024-02-21 20:52:19 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:52:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:52:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:52:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:52:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:52:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:52:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:52:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:52:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:52:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:52:19 --> Final output sent to browser
DEBUG - 2024-02-21 20:52:19 --> Total execution time: 0.0420
ERROR - 2024-02-21 20:52:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:52:20 --> Config Class Initialized
INFO - 2024-02-21 20:52:20 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:52:20 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:52:20 --> Utf8 Class Initialized
INFO - 2024-02-21 20:52:20 --> URI Class Initialized
INFO - 2024-02-21 20:52:20 --> Router Class Initialized
INFO - 2024-02-21 20:52:20 --> Output Class Initialized
INFO - 2024-02-21 20:52:20 --> Security Class Initialized
DEBUG - 2024-02-21 20:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:52:20 --> Input Class Initialized
INFO - 2024-02-21 20:52:20 --> Language Class Initialized
INFO - 2024-02-21 20:52:20 --> Loader Class Initialized
INFO - 2024-02-21 20:52:20 --> Helper loaded: url_helper
INFO - 2024-02-21 20:52:20 --> Helper loaded: file_helper
INFO - 2024-02-21 20:52:20 --> Helper loaded: form_helper
INFO - 2024-02-21 20:52:20 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:52:20 --> Controller Class Initialized
INFO - 2024-02-21 20:52:20 --> Form Validation Class Initialized
INFO - 2024-02-21 20:52:20 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:52:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:52:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:52:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:52:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:53:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:53:05 --> Config Class Initialized
INFO - 2024-02-21 20:53:05 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:53:05 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:53:05 --> Utf8 Class Initialized
INFO - 2024-02-21 20:53:05 --> URI Class Initialized
INFO - 2024-02-21 20:53:05 --> Router Class Initialized
INFO - 2024-02-21 20:53:05 --> Output Class Initialized
INFO - 2024-02-21 20:53:05 --> Security Class Initialized
DEBUG - 2024-02-21 20:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:53:05 --> Input Class Initialized
INFO - 2024-02-21 20:53:05 --> Language Class Initialized
INFO - 2024-02-21 20:53:05 --> Loader Class Initialized
INFO - 2024-02-21 20:53:05 --> Helper loaded: url_helper
INFO - 2024-02-21 20:53:05 --> Helper loaded: file_helper
INFO - 2024-02-21 20:53:05 --> Helper loaded: form_helper
INFO - 2024-02-21 20:53:05 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:53:05 --> Controller Class Initialized
INFO - 2024-02-21 20:53:05 --> Form Validation Class Initialized
INFO - 2024-02-21 20:53:05 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:53:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:53:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:53:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:53:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:53:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:53:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:53:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:53:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:53:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:53:05 --> Final output sent to browser
DEBUG - 2024-02-21 20:53:05 --> Total execution time: 0.0308
ERROR - 2024-02-21 20:53:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:53:06 --> Config Class Initialized
INFO - 2024-02-21 20:53:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:53:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:53:06 --> Utf8 Class Initialized
INFO - 2024-02-21 20:53:06 --> URI Class Initialized
INFO - 2024-02-21 20:53:06 --> Router Class Initialized
INFO - 2024-02-21 20:53:06 --> Output Class Initialized
INFO - 2024-02-21 20:53:06 --> Security Class Initialized
DEBUG - 2024-02-21 20:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:53:06 --> Input Class Initialized
INFO - 2024-02-21 20:53:06 --> Language Class Initialized
INFO - 2024-02-21 20:53:06 --> Loader Class Initialized
INFO - 2024-02-21 20:53:06 --> Helper loaded: url_helper
INFO - 2024-02-21 20:53:06 --> Helper loaded: file_helper
INFO - 2024-02-21 20:53:06 --> Helper loaded: form_helper
INFO - 2024-02-21 20:53:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:53:06 --> Controller Class Initialized
INFO - 2024-02-21 20:53:06 --> Form Validation Class Initialized
INFO - 2024-02-21 20:53:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:53:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:53:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:53:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:53:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:53:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:53:18 --> Config Class Initialized
INFO - 2024-02-21 20:53:18 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:53:18 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:53:18 --> Utf8 Class Initialized
INFO - 2024-02-21 20:53:18 --> URI Class Initialized
INFO - 2024-02-21 20:53:18 --> Router Class Initialized
INFO - 2024-02-21 20:53:18 --> Output Class Initialized
INFO - 2024-02-21 20:53:18 --> Security Class Initialized
DEBUG - 2024-02-21 20:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:53:18 --> Input Class Initialized
INFO - 2024-02-21 20:53:18 --> Language Class Initialized
INFO - 2024-02-21 20:53:18 --> Loader Class Initialized
INFO - 2024-02-21 20:53:18 --> Helper loaded: url_helper
INFO - 2024-02-21 20:53:18 --> Helper loaded: file_helper
INFO - 2024-02-21 20:53:18 --> Helper loaded: form_helper
INFO - 2024-02-21 20:53:18 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:53:18 --> Controller Class Initialized
INFO - 2024-02-21 20:53:18 --> Form Validation Class Initialized
INFO - 2024-02-21 20:53:18 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:53:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:53:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:53:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:53:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:53:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:53:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:53:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:53:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:53:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:53:18 --> Final output sent to browser
DEBUG - 2024-02-21 20:53:18 --> Total execution time: 0.0306
ERROR - 2024-02-21 20:54:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:54:13 --> Config Class Initialized
INFO - 2024-02-21 20:54:13 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:54:13 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:54:13 --> Utf8 Class Initialized
INFO - 2024-02-21 20:54:13 --> URI Class Initialized
INFO - 2024-02-21 20:54:13 --> Router Class Initialized
INFO - 2024-02-21 20:54:13 --> Output Class Initialized
INFO - 2024-02-21 20:54:13 --> Security Class Initialized
DEBUG - 2024-02-21 20:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:54:13 --> Input Class Initialized
INFO - 2024-02-21 20:54:13 --> Language Class Initialized
INFO - 2024-02-21 20:54:13 --> Loader Class Initialized
INFO - 2024-02-21 20:54:13 --> Helper loaded: url_helper
INFO - 2024-02-21 20:54:13 --> Helper loaded: file_helper
INFO - 2024-02-21 20:54:13 --> Helper loaded: form_helper
INFO - 2024-02-21 20:54:13 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:54:13 --> Controller Class Initialized
INFO - 2024-02-21 20:54:13 --> Form Validation Class Initialized
INFO - 2024-02-21 20:54:13 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:54:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:54:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:54:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:54:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:54:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:54:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:54:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:54:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:54:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:54:13 --> Final output sent to browser
DEBUG - 2024-02-21 20:54:13 --> Total execution time: 0.0446
ERROR - 2024-02-21 20:54:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:54:14 --> Config Class Initialized
INFO - 2024-02-21 20:54:14 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:54:14 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:54:14 --> Utf8 Class Initialized
INFO - 2024-02-21 20:54:14 --> URI Class Initialized
INFO - 2024-02-21 20:54:14 --> Router Class Initialized
INFO - 2024-02-21 20:54:14 --> Output Class Initialized
INFO - 2024-02-21 20:54:14 --> Security Class Initialized
DEBUG - 2024-02-21 20:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:54:14 --> Input Class Initialized
INFO - 2024-02-21 20:54:14 --> Language Class Initialized
INFO - 2024-02-21 20:54:14 --> Loader Class Initialized
INFO - 2024-02-21 20:54:14 --> Helper loaded: url_helper
INFO - 2024-02-21 20:54:14 --> Helper loaded: file_helper
INFO - 2024-02-21 20:54:14 --> Helper loaded: form_helper
INFO - 2024-02-21 20:54:14 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:54:14 --> Controller Class Initialized
INFO - 2024-02-21 20:54:14 --> Form Validation Class Initialized
INFO - 2024-02-21 20:54:14 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:54:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:54:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:54:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:54:14 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:56:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:56:01 --> Config Class Initialized
INFO - 2024-02-21 20:56:01 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:56:01 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:56:01 --> Utf8 Class Initialized
INFO - 2024-02-21 20:56:01 --> URI Class Initialized
INFO - 2024-02-21 20:56:01 --> Router Class Initialized
INFO - 2024-02-21 20:56:01 --> Output Class Initialized
INFO - 2024-02-21 20:56:01 --> Security Class Initialized
DEBUG - 2024-02-21 20:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:56:01 --> Input Class Initialized
INFO - 2024-02-21 20:56:01 --> Language Class Initialized
INFO - 2024-02-21 20:56:01 --> Loader Class Initialized
INFO - 2024-02-21 20:56:01 --> Helper loaded: url_helper
INFO - 2024-02-21 20:56:01 --> Helper loaded: file_helper
INFO - 2024-02-21 20:56:01 --> Helper loaded: form_helper
INFO - 2024-02-21 20:56:01 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:56:01 --> Controller Class Initialized
INFO - 2024-02-21 20:56:01 --> Form Validation Class Initialized
INFO - 2024-02-21 20:56:01 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:56:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:56:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:56:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:56:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:56:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:56:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:56:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:56:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:56:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:56:01 --> Final output sent to browser
DEBUG - 2024-02-21 20:56:01 --> Total execution time: 0.0332
ERROR - 2024-02-21 20:56:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:56:02 --> Config Class Initialized
INFO - 2024-02-21 20:56:02 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:56:02 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:56:02 --> Utf8 Class Initialized
INFO - 2024-02-21 20:56:02 --> URI Class Initialized
INFO - 2024-02-21 20:56:02 --> Router Class Initialized
INFO - 2024-02-21 20:56:02 --> Output Class Initialized
INFO - 2024-02-21 20:56:02 --> Security Class Initialized
DEBUG - 2024-02-21 20:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:56:02 --> Input Class Initialized
INFO - 2024-02-21 20:56:02 --> Language Class Initialized
INFO - 2024-02-21 20:56:02 --> Loader Class Initialized
INFO - 2024-02-21 20:56:02 --> Helper loaded: url_helper
INFO - 2024-02-21 20:56:02 --> Helper loaded: file_helper
INFO - 2024-02-21 20:56:02 --> Helper loaded: form_helper
INFO - 2024-02-21 20:56:02 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:56:02 --> Controller Class Initialized
INFO - 2024-02-21 20:56:02 --> Form Validation Class Initialized
INFO - 2024-02-21 20:56:02 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:56:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:56:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:56:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:56:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:56:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:56:18 --> Config Class Initialized
INFO - 2024-02-21 20:56:18 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:56:18 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:56:18 --> Utf8 Class Initialized
INFO - 2024-02-21 20:56:18 --> URI Class Initialized
INFO - 2024-02-21 20:56:18 --> Router Class Initialized
INFO - 2024-02-21 20:56:18 --> Output Class Initialized
INFO - 2024-02-21 20:56:18 --> Security Class Initialized
DEBUG - 2024-02-21 20:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:56:18 --> Input Class Initialized
INFO - 2024-02-21 20:56:18 --> Language Class Initialized
INFO - 2024-02-21 20:56:18 --> Loader Class Initialized
INFO - 2024-02-21 20:56:18 --> Helper loaded: url_helper
INFO - 2024-02-21 20:56:18 --> Helper loaded: file_helper
INFO - 2024-02-21 20:56:18 --> Helper loaded: form_helper
INFO - 2024-02-21 20:56:18 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:56:18 --> Controller Class Initialized
INFO - 2024-02-21 20:56:18 --> Form Validation Class Initialized
INFO - 2024-02-21 20:56:18 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:56:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:56:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:56:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:56:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:56:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:56:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:56:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:56:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:56:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:56:18 --> Final output sent to browser
DEBUG - 2024-02-21 20:56:18 --> Total execution time: 0.0362
ERROR - 2024-02-21 20:56:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:56:19 --> Config Class Initialized
INFO - 2024-02-21 20:56:19 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:56:19 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:56:19 --> Utf8 Class Initialized
INFO - 2024-02-21 20:56:19 --> URI Class Initialized
INFO - 2024-02-21 20:56:19 --> Router Class Initialized
INFO - 2024-02-21 20:56:19 --> Output Class Initialized
INFO - 2024-02-21 20:56:19 --> Security Class Initialized
DEBUG - 2024-02-21 20:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:56:19 --> Input Class Initialized
INFO - 2024-02-21 20:56:19 --> Language Class Initialized
INFO - 2024-02-21 20:56:19 --> Loader Class Initialized
INFO - 2024-02-21 20:56:19 --> Helper loaded: url_helper
INFO - 2024-02-21 20:56:19 --> Helper loaded: file_helper
INFO - 2024-02-21 20:56:19 --> Helper loaded: form_helper
INFO - 2024-02-21 20:56:19 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:56:19 --> Controller Class Initialized
INFO - 2024-02-21 20:56:19 --> Form Validation Class Initialized
INFO - 2024-02-21 20:56:19 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:56:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:56:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:56:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:56:19 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:56:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:56:45 --> Config Class Initialized
INFO - 2024-02-21 20:56:45 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:56:45 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:56:45 --> Utf8 Class Initialized
INFO - 2024-02-21 20:56:45 --> URI Class Initialized
INFO - 2024-02-21 20:56:45 --> Router Class Initialized
INFO - 2024-02-21 20:56:45 --> Output Class Initialized
INFO - 2024-02-21 20:56:45 --> Security Class Initialized
DEBUG - 2024-02-21 20:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:56:45 --> Input Class Initialized
INFO - 2024-02-21 20:56:45 --> Language Class Initialized
INFO - 2024-02-21 20:56:45 --> Loader Class Initialized
INFO - 2024-02-21 20:56:45 --> Helper loaded: url_helper
INFO - 2024-02-21 20:56:45 --> Helper loaded: file_helper
INFO - 2024-02-21 20:56:45 --> Helper loaded: form_helper
INFO - 2024-02-21 20:56:45 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:56:45 --> Controller Class Initialized
INFO - 2024-02-21 20:56:45 --> Form Validation Class Initialized
INFO - 2024-02-21 20:56:45 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:56:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:56:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:56:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:56:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:56:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:56:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:56:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:56:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:56:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:56:45 --> Final output sent to browser
DEBUG - 2024-02-21 20:56:45 --> Total execution time: 0.0309
ERROR - 2024-02-21 20:56:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:56:47 --> Config Class Initialized
INFO - 2024-02-21 20:56:47 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:56:47 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:56:47 --> Utf8 Class Initialized
INFO - 2024-02-21 20:56:47 --> URI Class Initialized
INFO - 2024-02-21 20:56:47 --> Router Class Initialized
INFO - 2024-02-21 20:56:47 --> Output Class Initialized
INFO - 2024-02-21 20:56:47 --> Security Class Initialized
DEBUG - 2024-02-21 20:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:56:47 --> Input Class Initialized
INFO - 2024-02-21 20:56:47 --> Language Class Initialized
INFO - 2024-02-21 20:56:47 --> Loader Class Initialized
INFO - 2024-02-21 20:56:47 --> Helper loaded: url_helper
INFO - 2024-02-21 20:56:47 --> Helper loaded: file_helper
INFO - 2024-02-21 20:56:47 --> Helper loaded: form_helper
INFO - 2024-02-21 20:56:47 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:56:47 --> Controller Class Initialized
INFO - 2024-02-21 20:56:47 --> Form Validation Class Initialized
INFO - 2024-02-21 20:56:47 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:56:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:56:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:56:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:56:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:57:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:57:03 --> Config Class Initialized
INFO - 2024-02-21 20:57:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:57:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:57:03 --> Utf8 Class Initialized
INFO - 2024-02-21 20:57:03 --> URI Class Initialized
INFO - 2024-02-21 20:57:03 --> Router Class Initialized
INFO - 2024-02-21 20:57:03 --> Output Class Initialized
INFO - 2024-02-21 20:57:03 --> Security Class Initialized
DEBUG - 2024-02-21 20:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:57:03 --> Input Class Initialized
INFO - 2024-02-21 20:57:03 --> Language Class Initialized
INFO - 2024-02-21 20:57:03 --> Loader Class Initialized
INFO - 2024-02-21 20:57:03 --> Helper loaded: url_helper
INFO - 2024-02-21 20:57:03 --> Helper loaded: file_helper
INFO - 2024-02-21 20:57:03 --> Helper loaded: form_helper
INFO - 2024-02-21 20:57:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:57:03 --> Controller Class Initialized
INFO - 2024-02-21 20:57:03 --> Form Validation Class Initialized
INFO - 2024-02-21 20:57:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:57:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:57:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:57:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:57:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:57:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:57:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:57:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:57:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:57:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:57:03 --> Final output sent to browser
DEBUG - 2024-02-21 20:57:03 --> Total execution time: 0.0347
ERROR - 2024-02-21 20:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:57:04 --> Config Class Initialized
INFO - 2024-02-21 20:57:04 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:57:04 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:57:04 --> Utf8 Class Initialized
INFO - 2024-02-21 20:57:04 --> URI Class Initialized
INFO - 2024-02-21 20:57:04 --> Router Class Initialized
INFO - 2024-02-21 20:57:04 --> Output Class Initialized
INFO - 2024-02-21 20:57:04 --> Security Class Initialized
DEBUG - 2024-02-21 20:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:57:04 --> Input Class Initialized
INFO - 2024-02-21 20:57:04 --> Language Class Initialized
INFO - 2024-02-21 20:57:04 --> Loader Class Initialized
INFO - 2024-02-21 20:57:04 --> Helper loaded: url_helper
INFO - 2024-02-21 20:57:04 --> Helper loaded: file_helper
INFO - 2024-02-21 20:57:04 --> Helper loaded: form_helper
INFO - 2024-02-21 20:57:04 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:57:04 --> Controller Class Initialized
INFO - 2024-02-21 20:57:04 --> Form Validation Class Initialized
INFO - 2024-02-21 20:57:04 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:57:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:57:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:57:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:57:04 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:57:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:57:29 --> Config Class Initialized
INFO - 2024-02-21 20:57:29 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:57:29 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:57:29 --> Utf8 Class Initialized
INFO - 2024-02-21 20:57:29 --> URI Class Initialized
INFO - 2024-02-21 20:57:29 --> Router Class Initialized
INFO - 2024-02-21 20:57:29 --> Output Class Initialized
INFO - 2024-02-21 20:57:29 --> Security Class Initialized
DEBUG - 2024-02-21 20:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:57:29 --> Input Class Initialized
INFO - 2024-02-21 20:57:29 --> Language Class Initialized
INFO - 2024-02-21 20:57:29 --> Loader Class Initialized
INFO - 2024-02-21 20:57:29 --> Helper loaded: url_helper
INFO - 2024-02-21 20:57:29 --> Helper loaded: file_helper
INFO - 2024-02-21 20:57:29 --> Helper loaded: form_helper
INFO - 2024-02-21 20:57:29 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:57:29 --> Controller Class Initialized
INFO - 2024-02-21 20:57:29 --> Form Validation Class Initialized
INFO - 2024-02-21 20:57:29 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:57:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:57:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:57:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:57:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:57:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:57:29 --> Final output sent to browser
DEBUG - 2024-02-21 20:57:29 --> Total execution time: 0.0349
ERROR - 2024-02-21 20:57:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:57:29 --> Config Class Initialized
INFO - 2024-02-21 20:57:29 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:57:29 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:57:29 --> Utf8 Class Initialized
INFO - 2024-02-21 20:57:29 --> URI Class Initialized
INFO - 2024-02-21 20:57:29 --> Router Class Initialized
INFO - 2024-02-21 20:57:29 --> Output Class Initialized
INFO - 2024-02-21 20:57:29 --> Security Class Initialized
DEBUG - 2024-02-21 20:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:57:29 --> Input Class Initialized
INFO - 2024-02-21 20:57:29 --> Language Class Initialized
INFO - 2024-02-21 20:57:29 --> Loader Class Initialized
INFO - 2024-02-21 20:57:29 --> Helper loaded: url_helper
INFO - 2024-02-21 20:57:29 --> Helper loaded: file_helper
INFO - 2024-02-21 20:57:29 --> Helper loaded: form_helper
INFO - 2024-02-21 20:57:29 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:57:29 --> Controller Class Initialized
INFO - 2024-02-21 20:57:29 --> Form Validation Class Initialized
INFO - 2024-02-21 20:57:29 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:57:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:57:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:57:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:57:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:58:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:58:15 --> Config Class Initialized
INFO - 2024-02-21 20:58:15 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:58:15 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:58:15 --> Utf8 Class Initialized
INFO - 2024-02-21 20:58:15 --> URI Class Initialized
INFO - 2024-02-21 20:58:15 --> Router Class Initialized
INFO - 2024-02-21 20:58:15 --> Output Class Initialized
INFO - 2024-02-21 20:58:15 --> Security Class Initialized
DEBUG - 2024-02-21 20:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:58:15 --> Input Class Initialized
INFO - 2024-02-21 20:58:15 --> Language Class Initialized
INFO - 2024-02-21 20:58:15 --> Loader Class Initialized
INFO - 2024-02-21 20:58:15 --> Helper loaded: url_helper
INFO - 2024-02-21 20:58:15 --> Helper loaded: file_helper
INFO - 2024-02-21 20:58:15 --> Helper loaded: form_helper
INFO - 2024-02-21 20:58:15 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:58:15 --> Controller Class Initialized
INFO - 2024-02-21 20:58:15 --> Form Validation Class Initialized
INFO - 2024-02-21 20:58:15 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:58:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:58:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:58:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:58:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:58:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:58:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:58:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:58:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:58:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:58:15 --> Final output sent to browser
DEBUG - 2024-02-21 20:58:15 --> Total execution time: 0.0288
ERROR - 2024-02-21 20:58:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:58:16 --> Config Class Initialized
INFO - 2024-02-21 20:58:16 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:58:16 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:58:16 --> Utf8 Class Initialized
INFO - 2024-02-21 20:58:16 --> URI Class Initialized
INFO - 2024-02-21 20:58:16 --> Router Class Initialized
INFO - 2024-02-21 20:58:16 --> Output Class Initialized
INFO - 2024-02-21 20:58:16 --> Security Class Initialized
DEBUG - 2024-02-21 20:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:58:16 --> Input Class Initialized
INFO - 2024-02-21 20:58:16 --> Language Class Initialized
INFO - 2024-02-21 20:58:16 --> Loader Class Initialized
INFO - 2024-02-21 20:58:16 --> Helper loaded: url_helper
INFO - 2024-02-21 20:58:16 --> Helper loaded: file_helper
INFO - 2024-02-21 20:58:16 --> Helper loaded: form_helper
INFO - 2024-02-21 20:58:16 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:58:16 --> Controller Class Initialized
INFO - 2024-02-21 20:58:16 --> Form Validation Class Initialized
INFO - 2024-02-21 20:58:16 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:58:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:58:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:58:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:58:16 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:58:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:58:52 --> Config Class Initialized
INFO - 2024-02-21 20:58:52 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:58:52 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:58:52 --> Utf8 Class Initialized
INFO - 2024-02-21 20:58:52 --> URI Class Initialized
INFO - 2024-02-21 20:58:52 --> Router Class Initialized
INFO - 2024-02-21 20:58:52 --> Output Class Initialized
INFO - 2024-02-21 20:58:52 --> Security Class Initialized
DEBUG - 2024-02-21 20:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:58:52 --> Input Class Initialized
INFO - 2024-02-21 20:58:52 --> Language Class Initialized
INFO - 2024-02-21 20:58:52 --> Loader Class Initialized
INFO - 2024-02-21 20:58:52 --> Helper loaded: url_helper
INFO - 2024-02-21 20:58:52 --> Helper loaded: file_helper
INFO - 2024-02-21 20:58:52 --> Helper loaded: form_helper
INFO - 2024-02-21 20:58:52 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:58:52 --> Controller Class Initialized
INFO - 2024-02-21 20:58:52 --> Form Validation Class Initialized
INFO - 2024-02-21 20:58:52 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:58:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:58:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:58:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:58:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:58:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:58:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:58:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:58:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:58:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:58:52 --> Final output sent to browser
DEBUG - 2024-02-21 20:58:52 --> Total execution time: 0.0308
ERROR - 2024-02-21 20:58:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:58:53 --> Config Class Initialized
INFO - 2024-02-21 20:58:53 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:58:53 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:58:53 --> Utf8 Class Initialized
INFO - 2024-02-21 20:58:53 --> URI Class Initialized
INFO - 2024-02-21 20:58:53 --> Router Class Initialized
INFO - 2024-02-21 20:58:53 --> Output Class Initialized
INFO - 2024-02-21 20:58:53 --> Security Class Initialized
DEBUG - 2024-02-21 20:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:58:53 --> Input Class Initialized
INFO - 2024-02-21 20:58:53 --> Language Class Initialized
INFO - 2024-02-21 20:58:53 --> Loader Class Initialized
INFO - 2024-02-21 20:58:53 --> Helper loaded: url_helper
INFO - 2024-02-21 20:58:53 --> Helper loaded: file_helper
INFO - 2024-02-21 20:58:53 --> Helper loaded: form_helper
INFO - 2024-02-21 20:58:53 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:58:53 --> Controller Class Initialized
INFO - 2024-02-21 20:58:53 --> Form Validation Class Initialized
INFO - 2024-02-21 20:58:53 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:58:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:58:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:58:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:58:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:59:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:59:14 --> Config Class Initialized
INFO - 2024-02-21 20:59:14 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:59:14 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:59:14 --> Utf8 Class Initialized
INFO - 2024-02-21 20:59:14 --> URI Class Initialized
INFO - 2024-02-21 20:59:14 --> Router Class Initialized
INFO - 2024-02-21 20:59:14 --> Output Class Initialized
INFO - 2024-02-21 20:59:14 --> Security Class Initialized
DEBUG - 2024-02-21 20:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:59:14 --> Input Class Initialized
INFO - 2024-02-21 20:59:14 --> Language Class Initialized
INFO - 2024-02-21 20:59:14 --> Loader Class Initialized
INFO - 2024-02-21 20:59:14 --> Helper loaded: url_helper
INFO - 2024-02-21 20:59:14 --> Helper loaded: file_helper
INFO - 2024-02-21 20:59:14 --> Helper loaded: form_helper
INFO - 2024-02-21 20:59:14 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:59:14 --> Controller Class Initialized
INFO - 2024-02-21 20:59:14 --> Form Validation Class Initialized
INFO - 2024-02-21 20:59:14 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:59:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:59:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:59:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:59:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:59:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:59:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:59:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:59:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:59:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:59:14 --> Final output sent to browser
DEBUG - 2024-02-21 20:59:14 --> Total execution time: 0.0256
ERROR - 2024-02-21 20:59:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:59:15 --> Config Class Initialized
INFO - 2024-02-21 20:59:15 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:59:15 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:59:15 --> Utf8 Class Initialized
INFO - 2024-02-21 20:59:15 --> URI Class Initialized
INFO - 2024-02-21 20:59:15 --> Router Class Initialized
INFO - 2024-02-21 20:59:15 --> Output Class Initialized
INFO - 2024-02-21 20:59:15 --> Security Class Initialized
DEBUG - 2024-02-21 20:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:59:15 --> Input Class Initialized
INFO - 2024-02-21 20:59:15 --> Language Class Initialized
INFO - 2024-02-21 20:59:15 --> Loader Class Initialized
INFO - 2024-02-21 20:59:15 --> Helper loaded: url_helper
INFO - 2024-02-21 20:59:15 --> Helper loaded: file_helper
INFO - 2024-02-21 20:59:15 --> Helper loaded: form_helper
INFO - 2024-02-21 20:59:15 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:59:15 --> Controller Class Initialized
INFO - 2024-02-21 20:59:15 --> Form Validation Class Initialized
INFO - 2024-02-21 20:59:15 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:59:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:59:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:59:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:59:15 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 20:59:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:59:28 --> Config Class Initialized
INFO - 2024-02-21 20:59:28 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:59:28 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:59:28 --> Utf8 Class Initialized
INFO - 2024-02-21 20:59:28 --> URI Class Initialized
INFO - 2024-02-21 20:59:28 --> Router Class Initialized
INFO - 2024-02-21 20:59:28 --> Output Class Initialized
INFO - 2024-02-21 20:59:28 --> Security Class Initialized
DEBUG - 2024-02-21 20:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:59:28 --> Input Class Initialized
INFO - 2024-02-21 20:59:28 --> Language Class Initialized
INFO - 2024-02-21 20:59:28 --> Loader Class Initialized
INFO - 2024-02-21 20:59:28 --> Helper loaded: url_helper
INFO - 2024-02-21 20:59:28 --> Helper loaded: file_helper
INFO - 2024-02-21 20:59:28 --> Helper loaded: form_helper
INFO - 2024-02-21 20:59:28 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:59:28 --> Controller Class Initialized
INFO - 2024-02-21 20:59:28 --> Form Validation Class Initialized
INFO - 2024-02-21 20:59:28 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:59:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:59:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:59:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:59:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 20:59:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 20:59:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 20:59:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 20:59:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 20:59:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 20:59:28 --> Final output sent to browser
DEBUG - 2024-02-21 20:59:28 --> Total execution time: 0.0327
ERROR - 2024-02-21 20:59:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 20:59:30 --> Config Class Initialized
INFO - 2024-02-21 20:59:30 --> Hooks Class Initialized
DEBUG - 2024-02-21 20:59:30 --> UTF-8 Support Enabled
INFO - 2024-02-21 20:59:30 --> Utf8 Class Initialized
INFO - 2024-02-21 20:59:30 --> URI Class Initialized
INFO - 2024-02-21 20:59:30 --> Router Class Initialized
INFO - 2024-02-21 20:59:30 --> Output Class Initialized
INFO - 2024-02-21 20:59:30 --> Security Class Initialized
DEBUG - 2024-02-21 20:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 20:59:30 --> Input Class Initialized
INFO - 2024-02-21 20:59:30 --> Language Class Initialized
INFO - 2024-02-21 20:59:30 --> Loader Class Initialized
INFO - 2024-02-21 20:59:30 --> Helper loaded: url_helper
INFO - 2024-02-21 20:59:30 --> Helper loaded: file_helper
INFO - 2024-02-21 20:59:30 --> Helper loaded: form_helper
INFO - 2024-02-21 20:59:30 --> Database Driver Class Initialized
DEBUG - 2024-02-21 20:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 20:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 20:59:30 --> Controller Class Initialized
INFO - 2024-02-21 20:59:30 --> Form Validation Class Initialized
INFO - 2024-02-21 20:59:30 --> Model "MasterModel" initialized
INFO - 2024-02-21 20:59:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 20:59:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 20:59:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 20:59:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:00:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:00:14 --> Config Class Initialized
INFO - 2024-02-21 21:00:14 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:00:14 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:00:14 --> Utf8 Class Initialized
INFO - 2024-02-21 21:00:14 --> URI Class Initialized
INFO - 2024-02-21 21:00:14 --> Router Class Initialized
INFO - 2024-02-21 21:00:14 --> Output Class Initialized
INFO - 2024-02-21 21:00:14 --> Security Class Initialized
DEBUG - 2024-02-21 21:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:00:14 --> Input Class Initialized
INFO - 2024-02-21 21:00:14 --> Language Class Initialized
INFO - 2024-02-21 21:00:14 --> Loader Class Initialized
INFO - 2024-02-21 21:00:14 --> Helper loaded: url_helper
INFO - 2024-02-21 21:00:14 --> Helper loaded: file_helper
INFO - 2024-02-21 21:00:14 --> Helper loaded: form_helper
INFO - 2024-02-21 21:00:14 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:00:14 --> Controller Class Initialized
INFO - 2024-02-21 21:00:14 --> Form Validation Class Initialized
INFO - 2024-02-21 21:00:14 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:00:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:00:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:00:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:00:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:00:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:00:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:00:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:00:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:00:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:00:14 --> Final output sent to browser
DEBUG - 2024-02-21 21:00:14 --> Total execution time: 0.0362
ERROR - 2024-02-21 21:00:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:00:15 --> Config Class Initialized
INFO - 2024-02-21 21:00:15 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:00:15 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:00:15 --> Utf8 Class Initialized
INFO - 2024-02-21 21:00:15 --> URI Class Initialized
INFO - 2024-02-21 21:00:15 --> Router Class Initialized
INFO - 2024-02-21 21:00:15 --> Output Class Initialized
INFO - 2024-02-21 21:00:15 --> Security Class Initialized
DEBUG - 2024-02-21 21:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:00:15 --> Input Class Initialized
INFO - 2024-02-21 21:00:15 --> Language Class Initialized
INFO - 2024-02-21 21:00:15 --> Loader Class Initialized
INFO - 2024-02-21 21:00:15 --> Helper loaded: url_helper
INFO - 2024-02-21 21:00:15 --> Helper loaded: file_helper
INFO - 2024-02-21 21:00:15 --> Helper loaded: form_helper
INFO - 2024-02-21 21:00:15 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:00:15 --> Controller Class Initialized
INFO - 2024-02-21 21:00:15 --> Form Validation Class Initialized
INFO - 2024-02-21 21:00:15 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:00:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:00:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:00:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:00:15 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:00:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:00:17 --> Config Class Initialized
INFO - 2024-02-21 21:00:17 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:00:17 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:00:17 --> Utf8 Class Initialized
INFO - 2024-02-21 21:00:17 --> URI Class Initialized
INFO - 2024-02-21 21:00:17 --> Router Class Initialized
INFO - 2024-02-21 21:00:17 --> Output Class Initialized
INFO - 2024-02-21 21:00:17 --> Security Class Initialized
DEBUG - 2024-02-21 21:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:00:17 --> Input Class Initialized
INFO - 2024-02-21 21:00:17 --> Language Class Initialized
INFO - 2024-02-21 21:00:17 --> Loader Class Initialized
INFO - 2024-02-21 21:00:17 --> Helper loaded: url_helper
INFO - 2024-02-21 21:00:18 --> Helper loaded: file_helper
INFO - 2024-02-21 21:00:18 --> Helper loaded: form_helper
INFO - 2024-02-21 21:00:18 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:00:18 --> Controller Class Initialized
INFO - 2024-02-21 21:00:18 --> Form Validation Class Initialized
INFO - 2024-02-21 21:00:18 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:00:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:00:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:00:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:00:18 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:00:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:00:28 --> Config Class Initialized
INFO - 2024-02-21 21:00:28 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:00:28 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:00:28 --> Utf8 Class Initialized
INFO - 2024-02-21 21:00:28 --> URI Class Initialized
INFO - 2024-02-21 21:00:28 --> Router Class Initialized
INFO - 2024-02-21 21:00:28 --> Output Class Initialized
INFO - 2024-02-21 21:00:28 --> Security Class Initialized
DEBUG - 2024-02-21 21:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:00:28 --> Input Class Initialized
INFO - 2024-02-21 21:00:28 --> Language Class Initialized
INFO - 2024-02-21 21:00:28 --> Loader Class Initialized
INFO - 2024-02-21 21:00:28 --> Helper loaded: url_helper
INFO - 2024-02-21 21:00:28 --> Helper loaded: file_helper
INFO - 2024-02-21 21:00:28 --> Helper loaded: form_helper
INFO - 2024-02-21 21:00:28 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:00:28 --> Controller Class Initialized
INFO - 2024-02-21 21:00:28 --> Form Validation Class Initialized
INFO - 2024-02-21 21:00:28 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:00:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:00:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:00:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:00:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:00:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:00:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:00:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:00:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:00:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:00:28 --> Final output sent to browser
DEBUG - 2024-02-21 21:00:28 --> Total execution time: 0.0324
ERROR - 2024-02-21 21:00:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:00:28 --> Config Class Initialized
INFO - 2024-02-21 21:00:28 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:00:28 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:00:28 --> Utf8 Class Initialized
INFO - 2024-02-21 21:00:28 --> URI Class Initialized
INFO - 2024-02-21 21:00:28 --> Router Class Initialized
INFO - 2024-02-21 21:00:28 --> Output Class Initialized
INFO - 2024-02-21 21:00:28 --> Security Class Initialized
DEBUG - 2024-02-21 21:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:00:28 --> Input Class Initialized
INFO - 2024-02-21 21:00:28 --> Language Class Initialized
INFO - 2024-02-21 21:00:28 --> Loader Class Initialized
INFO - 2024-02-21 21:00:28 --> Helper loaded: url_helper
INFO - 2024-02-21 21:00:28 --> Helper loaded: file_helper
INFO - 2024-02-21 21:00:28 --> Helper loaded: form_helper
INFO - 2024-02-21 21:00:28 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:00:28 --> Controller Class Initialized
INFO - 2024-02-21 21:00:28 --> Form Validation Class Initialized
INFO - 2024-02-21 21:00:28 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:00:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:00:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:00:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:00:28 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:02:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:02:51 --> Config Class Initialized
INFO - 2024-02-21 21:02:51 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:02:51 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:02:51 --> Utf8 Class Initialized
INFO - 2024-02-21 21:02:51 --> URI Class Initialized
INFO - 2024-02-21 21:02:51 --> Router Class Initialized
INFO - 2024-02-21 21:02:51 --> Output Class Initialized
INFO - 2024-02-21 21:02:51 --> Security Class Initialized
DEBUG - 2024-02-21 21:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:02:51 --> Input Class Initialized
INFO - 2024-02-21 21:02:51 --> Language Class Initialized
INFO - 2024-02-21 21:02:51 --> Loader Class Initialized
INFO - 2024-02-21 21:02:51 --> Helper loaded: url_helper
INFO - 2024-02-21 21:02:51 --> Helper loaded: file_helper
INFO - 2024-02-21 21:02:51 --> Helper loaded: form_helper
INFO - 2024-02-21 21:02:51 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:02:51 --> Controller Class Initialized
INFO - 2024-02-21 21:02:51 --> Form Validation Class Initialized
INFO - 2024-02-21 21:02:51 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:02:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:02:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:02:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:02:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:02:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:02:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:02:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:02:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:02:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:02:51 --> Final output sent to browser
DEBUG - 2024-02-21 21:02:51 --> Total execution time: 0.0359
ERROR - 2024-02-21 21:02:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:02:53 --> Config Class Initialized
INFO - 2024-02-21 21:02:53 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:02:53 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:02:53 --> Utf8 Class Initialized
INFO - 2024-02-21 21:02:53 --> URI Class Initialized
INFO - 2024-02-21 21:02:53 --> Router Class Initialized
INFO - 2024-02-21 21:02:53 --> Output Class Initialized
INFO - 2024-02-21 21:02:53 --> Security Class Initialized
DEBUG - 2024-02-21 21:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:02:53 --> Input Class Initialized
INFO - 2024-02-21 21:02:53 --> Language Class Initialized
INFO - 2024-02-21 21:02:53 --> Loader Class Initialized
INFO - 2024-02-21 21:02:53 --> Helper loaded: url_helper
INFO - 2024-02-21 21:02:53 --> Helper loaded: file_helper
INFO - 2024-02-21 21:02:53 --> Helper loaded: form_helper
INFO - 2024-02-21 21:02:53 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:02:53 --> Controller Class Initialized
INFO - 2024-02-21 21:02:53 --> Form Validation Class Initialized
INFO - 2024-02-21 21:02:53 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:02:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:02:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:02:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:02:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:03:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:03:21 --> Config Class Initialized
INFO - 2024-02-21 21:03:21 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:03:21 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:03:21 --> Utf8 Class Initialized
INFO - 2024-02-21 21:03:21 --> URI Class Initialized
INFO - 2024-02-21 21:03:21 --> Router Class Initialized
INFO - 2024-02-21 21:03:21 --> Output Class Initialized
INFO - 2024-02-21 21:03:21 --> Security Class Initialized
DEBUG - 2024-02-21 21:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:03:21 --> Input Class Initialized
INFO - 2024-02-21 21:03:21 --> Language Class Initialized
INFO - 2024-02-21 21:03:21 --> Loader Class Initialized
INFO - 2024-02-21 21:03:21 --> Helper loaded: url_helper
INFO - 2024-02-21 21:03:21 --> Helper loaded: file_helper
INFO - 2024-02-21 21:03:21 --> Helper loaded: form_helper
INFO - 2024-02-21 21:03:21 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:03:21 --> Controller Class Initialized
INFO - 2024-02-21 21:03:21 --> Form Validation Class Initialized
INFO - 2024-02-21 21:03:21 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:03:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:03:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:03:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:03:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:03:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:03:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:03:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:03:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:03:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:03:21 --> Final output sent to browser
DEBUG - 2024-02-21 21:03:21 --> Total execution time: 0.0439
ERROR - 2024-02-21 21:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:03:22 --> Config Class Initialized
INFO - 2024-02-21 21:03:22 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:03:22 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:03:22 --> Utf8 Class Initialized
INFO - 2024-02-21 21:03:22 --> URI Class Initialized
INFO - 2024-02-21 21:03:22 --> Router Class Initialized
INFO - 2024-02-21 21:03:22 --> Output Class Initialized
INFO - 2024-02-21 21:03:22 --> Security Class Initialized
DEBUG - 2024-02-21 21:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:03:22 --> Input Class Initialized
INFO - 2024-02-21 21:03:22 --> Language Class Initialized
INFO - 2024-02-21 21:03:22 --> Loader Class Initialized
INFO - 2024-02-21 21:03:22 --> Helper loaded: url_helper
INFO - 2024-02-21 21:03:22 --> Helper loaded: file_helper
INFO - 2024-02-21 21:03:22 --> Helper loaded: form_helper
INFO - 2024-02-21 21:03:22 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:03:22 --> Controller Class Initialized
INFO - 2024-02-21 21:03:22 --> Form Validation Class Initialized
INFO - 2024-02-21 21:03:22 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:03:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:03:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:03:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:03:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:04:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:04:25 --> Config Class Initialized
INFO - 2024-02-21 21:04:25 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:04:25 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:04:25 --> Utf8 Class Initialized
INFO - 2024-02-21 21:04:25 --> URI Class Initialized
INFO - 2024-02-21 21:04:25 --> Router Class Initialized
INFO - 2024-02-21 21:04:25 --> Output Class Initialized
INFO - 2024-02-21 21:04:25 --> Security Class Initialized
DEBUG - 2024-02-21 21:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:04:25 --> Input Class Initialized
INFO - 2024-02-21 21:04:25 --> Language Class Initialized
INFO - 2024-02-21 21:04:25 --> Loader Class Initialized
INFO - 2024-02-21 21:04:25 --> Helper loaded: url_helper
INFO - 2024-02-21 21:04:25 --> Helper loaded: file_helper
INFO - 2024-02-21 21:04:25 --> Helper loaded: form_helper
INFO - 2024-02-21 21:04:25 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:04:25 --> Controller Class Initialized
INFO - 2024-02-21 21:04:25 --> Form Validation Class Initialized
INFO - 2024-02-21 21:04:25 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:04:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:04:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:04:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:04:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:04:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:04:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:04:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:04:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:04:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:04:25 --> Final output sent to browser
DEBUG - 2024-02-21 21:04:25 --> Total execution time: 0.0309
ERROR - 2024-02-21 21:04:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:04:25 --> Config Class Initialized
INFO - 2024-02-21 21:04:25 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:04:25 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:04:25 --> Utf8 Class Initialized
INFO - 2024-02-21 21:04:25 --> URI Class Initialized
INFO - 2024-02-21 21:04:25 --> Router Class Initialized
INFO - 2024-02-21 21:04:25 --> Output Class Initialized
INFO - 2024-02-21 21:04:25 --> Security Class Initialized
DEBUG - 2024-02-21 21:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:04:25 --> Input Class Initialized
INFO - 2024-02-21 21:04:25 --> Language Class Initialized
INFO - 2024-02-21 21:04:25 --> Loader Class Initialized
INFO - 2024-02-21 21:04:25 --> Helper loaded: url_helper
INFO - 2024-02-21 21:04:25 --> Helper loaded: file_helper
INFO - 2024-02-21 21:04:25 --> Helper loaded: form_helper
INFO - 2024-02-21 21:04:25 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:04:25 --> Controller Class Initialized
INFO - 2024-02-21 21:04:25 --> Form Validation Class Initialized
INFO - 2024-02-21 21:04:25 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:04:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:04:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:04:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:04:25 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:04:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:04:41 --> Config Class Initialized
INFO - 2024-02-21 21:04:41 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:04:41 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:04:41 --> Utf8 Class Initialized
INFO - 2024-02-21 21:04:41 --> URI Class Initialized
INFO - 2024-02-21 21:04:41 --> Router Class Initialized
INFO - 2024-02-21 21:04:41 --> Output Class Initialized
INFO - 2024-02-21 21:04:41 --> Security Class Initialized
DEBUG - 2024-02-21 21:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:04:41 --> Input Class Initialized
INFO - 2024-02-21 21:04:41 --> Language Class Initialized
INFO - 2024-02-21 21:04:41 --> Loader Class Initialized
INFO - 2024-02-21 21:04:41 --> Helper loaded: url_helper
INFO - 2024-02-21 21:04:41 --> Helper loaded: file_helper
INFO - 2024-02-21 21:04:41 --> Helper loaded: form_helper
INFO - 2024-02-21 21:04:41 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:04:41 --> Controller Class Initialized
INFO - 2024-02-21 21:04:41 --> Form Validation Class Initialized
INFO - 2024-02-21 21:04:41 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:04:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:04:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:04:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:04:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:04:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-21 21:04:41 --> Final output sent to browser
DEBUG - 2024-02-21 21:04:41 --> Total execution time: 0.0421
ERROR - 2024-02-21 21:05:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:05:51 --> Config Class Initialized
INFO - 2024-02-21 21:05:51 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:05:51 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:05:51 --> Utf8 Class Initialized
INFO - 2024-02-21 21:05:51 --> URI Class Initialized
INFO - 2024-02-21 21:05:51 --> Router Class Initialized
INFO - 2024-02-21 21:05:51 --> Output Class Initialized
INFO - 2024-02-21 21:05:51 --> Security Class Initialized
DEBUG - 2024-02-21 21:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:05:51 --> Input Class Initialized
INFO - 2024-02-21 21:05:51 --> Language Class Initialized
INFO - 2024-02-21 21:05:51 --> Loader Class Initialized
INFO - 2024-02-21 21:05:51 --> Helper loaded: url_helper
INFO - 2024-02-21 21:05:51 --> Helper loaded: file_helper
INFO - 2024-02-21 21:05:51 --> Helper loaded: form_helper
INFO - 2024-02-21 21:05:51 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:05:51 --> Controller Class Initialized
INFO - 2024-02-21 21:05:51 --> Form Validation Class Initialized
INFO - 2024-02-21 21:05:51 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:05:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:05:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:05:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:05:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:05:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:05:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:05:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:05:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:05:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:05:51 --> Final output sent to browser
DEBUG - 2024-02-21 21:05:51 --> Total execution time: 0.0346
ERROR - 2024-02-21 21:05:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:05:52 --> Config Class Initialized
INFO - 2024-02-21 21:05:52 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:05:52 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:05:52 --> Utf8 Class Initialized
INFO - 2024-02-21 21:05:52 --> URI Class Initialized
INFO - 2024-02-21 21:05:52 --> Router Class Initialized
INFO - 2024-02-21 21:05:52 --> Output Class Initialized
INFO - 2024-02-21 21:05:52 --> Security Class Initialized
DEBUG - 2024-02-21 21:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:05:52 --> Input Class Initialized
INFO - 2024-02-21 21:05:52 --> Language Class Initialized
INFO - 2024-02-21 21:05:52 --> Loader Class Initialized
INFO - 2024-02-21 21:05:52 --> Helper loaded: url_helper
INFO - 2024-02-21 21:05:52 --> Helper loaded: file_helper
INFO - 2024-02-21 21:05:52 --> Helper loaded: form_helper
INFO - 2024-02-21 21:05:52 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:05:52 --> Controller Class Initialized
INFO - 2024-02-21 21:05:52 --> Form Validation Class Initialized
INFO - 2024-02-21 21:05:52 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:05:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:05:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:05:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:05:52 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:06:40 --> Config Class Initialized
INFO - 2024-02-21 21:06:40 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:06:40 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:06:40 --> Utf8 Class Initialized
INFO - 2024-02-21 21:06:40 --> URI Class Initialized
INFO - 2024-02-21 21:06:40 --> Router Class Initialized
INFO - 2024-02-21 21:06:40 --> Output Class Initialized
INFO - 2024-02-21 21:06:40 --> Security Class Initialized
DEBUG - 2024-02-21 21:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:06:40 --> Input Class Initialized
INFO - 2024-02-21 21:06:40 --> Language Class Initialized
INFO - 2024-02-21 21:06:40 --> Loader Class Initialized
INFO - 2024-02-21 21:06:40 --> Helper loaded: url_helper
INFO - 2024-02-21 21:06:40 --> Helper loaded: file_helper
INFO - 2024-02-21 21:06:40 --> Helper loaded: form_helper
INFO - 2024-02-21 21:06:40 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:06:40 --> Controller Class Initialized
INFO - 2024-02-21 21:06:40 --> Form Validation Class Initialized
INFO - 2024-02-21 21:06:40 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:06:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:06:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:06:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:06:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:06:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:06:40 --> Final output sent to browser
DEBUG - 2024-02-21 21:06:40 --> Total execution time: 0.0311
ERROR - 2024-02-21 21:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:06:40 --> Config Class Initialized
INFO - 2024-02-21 21:06:40 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:06:40 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:06:40 --> Utf8 Class Initialized
INFO - 2024-02-21 21:06:40 --> URI Class Initialized
INFO - 2024-02-21 21:06:40 --> Router Class Initialized
INFO - 2024-02-21 21:06:40 --> Output Class Initialized
INFO - 2024-02-21 21:06:40 --> Security Class Initialized
DEBUG - 2024-02-21 21:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:06:40 --> Input Class Initialized
INFO - 2024-02-21 21:06:40 --> Language Class Initialized
INFO - 2024-02-21 21:06:40 --> Loader Class Initialized
INFO - 2024-02-21 21:06:40 --> Helper loaded: url_helper
INFO - 2024-02-21 21:06:40 --> Helper loaded: file_helper
INFO - 2024-02-21 21:06:40 --> Helper loaded: form_helper
INFO - 2024-02-21 21:06:40 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:06:40 --> Controller Class Initialized
INFO - 2024-02-21 21:06:40 --> Form Validation Class Initialized
INFO - 2024-02-21 21:06:40 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:06:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:06:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:06:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:06:40 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:10:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:10:53 --> Config Class Initialized
INFO - 2024-02-21 21:10:53 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:10:53 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:10:53 --> Utf8 Class Initialized
INFO - 2024-02-21 21:10:53 --> URI Class Initialized
INFO - 2024-02-21 21:10:53 --> Router Class Initialized
INFO - 2024-02-21 21:10:53 --> Output Class Initialized
INFO - 2024-02-21 21:10:53 --> Security Class Initialized
DEBUG - 2024-02-21 21:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:10:53 --> Input Class Initialized
INFO - 2024-02-21 21:10:53 --> Language Class Initialized
INFO - 2024-02-21 21:10:53 --> Loader Class Initialized
INFO - 2024-02-21 21:10:53 --> Helper loaded: url_helper
INFO - 2024-02-21 21:10:53 --> Helper loaded: file_helper
INFO - 2024-02-21 21:10:53 --> Helper loaded: form_helper
INFO - 2024-02-21 21:10:53 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:10:53 --> Controller Class Initialized
INFO - 2024-02-21 21:10:53 --> Form Validation Class Initialized
INFO - 2024-02-21 21:10:53 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:10:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:10:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:10:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:10:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:10:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:10:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:10:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:10:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:10:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-21 21:10:53 --> Final output sent to browser
DEBUG - 2024-02-21 21:10:53 --> Total execution time: 0.0299
ERROR - 2024-02-21 21:10:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:10:53 --> Config Class Initialized
INFO - 2024-02-21 21:10:53 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:10:53 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:10:53 --> Utf8 Class Initialized
INFO - 2024-02-21 21:10:53 --> URI Class Initialized
INFO - 2024-02-21 21:10:53 --> Router Class Initialized
INFO - 2024-02-21 21:10:53 --> Output Class Initialized
INFO - 2024-02-21 21:10:53 --> Security Class Initialized
DEBUG - 2024-02-21 21:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:10:53 --> Input Class Initialized
INFO - 2024-02-21 21:10:53 --> Language Class Initialized
INFO - 2024-02-21 21:10:53 --> Loader Class Initialized
INFO - 2024-02-21 21:10:53 --> Helper loaded: url_helper
INFO - 2024-02-21 21:10:53 --> Helper loaded: file_helper
INFO - 2024-02-21 21:10:53 --> Helper loaded: form_helper
INFO - 2024-02-21 21:10:53 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:10:53 --> Controller Class Initialized
INFO - 2024-02-21 21:10:53 --> Form Validation Class Initialized
INFO - 2024-02-21 21:10:53 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:10:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:10:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:10:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:10:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:10:57 --> Config Class Initialized
INFO - 2024-02-21 21:10:57 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:10:57 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:10:57 --> Utf8 Class Initialized
INFO - 2024-02-21 21:10:57 --> URI Class Initialized
INFO - 2024-02-21 21:10:57 --> Router Class Initialized
INFO - 2024-02-21 21:10:57 --> Output Class Initialized
INFO - 2024-02-21 21:10:57 --> Security Class Initialized
DEBUG - 2024-02-21 21:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:10:57 --> Input Class Initialized
INFO - 2024-02-21 21:10:57 --> Language Class Initialized
INFO - 2024-02-21 21:10:57 --> Loader Class Initialized
INFO - 2024-02-21 21:10:57 --> Helper loaded: url_helper
INFO - 2024-02-21 21:10:57 --> Helper loaded: file_helper
INFO - 2024-02-21 21:10:57 --> Helper loaded: form_helper
INFO - 2024-02-21 21:10:57 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:10:57 --> Controller Class Initialized
INFO - 2024-02-21 21:10:57 --> Form Validation Class Initialized
INFO - 2024-02-21 21:10:57 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:10:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:10:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:10:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:10:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:10:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:10:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:10:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:10:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:10:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:10:57 --> Final output sent to browser
DEBUG - 2024-02-21 21:10:57 --> Total execution time: 0.0348
ERROR - 2024-02-21 21:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:10:57 --> Config Class Initialized
INFO - 2024-02-21 21:10:57 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:10:57 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:10:57 --> Utf8 Class Initialized
INFO - 2024-02-21 21:10:57 --> URI Class Initialized
INFO - 2024-02-21 21:10:57 --> Router Class Initialized
INFO - 2024-02-21 21:10:57 --> Output Class Initialized
INFO - 2024-02-21 21:10:57 --> Security Class Initialized
DEBUG - 2024-02-21 21:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:10:57 --> Input Class Initialized
INFO - 2024-02-21 21:10:57 --> Language Class Initialized
INFO - 2024-02-21 21:10:57 --> Loader Class Initialized
INFO - 2024-02-21 21:10:57 --> Helper loaded: url_helper
INFO - 2024-02-21 21:10:57 --> Helper loaded: file_helper
INFO - 2024-02-21 21:10:57 --> Helper loaded: form_helper
INFO - 2024-02-21 21:10:57 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:10:57 --> Controller Class Initialized
INFO - 2024-02-21 21:10:57 --> Form Validation Class Initialized
INFO - 2024-02-21 21:10:57 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:10:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:10:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:10:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:10:57 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:12:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:12:52 --> Config Class Initialized
INFO - 2024-02-21 21:12:52 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:12:52 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:12:52 --> Utf8 Class Initialized
INFO - 2024-02-21 21:12:52 --> URI Class Initialized
INFO - 2024-02-21 21:12:52 --> Router Class Initialized
INFO - 2024-02-21 21:12:52 --> Output Class Initialized
INFO - 2024-02-21 21:12:52 --> Security Class Initialized
DEBUG - 2024-02-21 21:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:12:52 --> Input Class Initialized
INFO - 2024-02-21 21:12:52 --> Language Class Initialized
INFO - 2024-02-21 21:12:52 --> Loader Class Initialized
INFO - 2024-02-21 21:12:52 --> Helper loaded: url_helper
INFO - 2024-02-21 21:12:52 --> Helper loaded: file_helper
INFO - 2024-02-21 21:12:52 --> Helper loaded: form_helper
INFO - 2024-02-21 21:12:52 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:12:52 --> Controller Class Initialized
INFO - 2024-02-21 21:12:52 --> Form Validation Class Initialized
INFO - 2024-02-21 21:12:52 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:12:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:12:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:12:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:12:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:12:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:12:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:12:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:12:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:12:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:12:52 --> Final output sent to browser
DEBUG - 2024-02-21 21:12:52 --> Total execution time: 0.0319
ERROR - 2024-02-21 21:12:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:12:52 --> Config Class Initialized
INFO - 2024-02-21 21:12:52 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:12:52 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:12:52 --> Utf8 Class Initialized
INFO - 2024-02-21 21:12:52 --> URI Class Initialized
INFO - 2024-02-21 21:12:52 --> Router Class Initialized
INFO - 2024-02-21 21:12:52 --> Output Class Initialized
INFO - 2024-02-21 21:12:52 --> Security Class Initialized
DEBUG - 2024-02-21 21:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:12:52 --> Input Class Initialized
INFO - 2024-02-21 21:12:52 --> Language Class Initialized
INFO - 2024-02-21 21:12:52 --> Loader Class Initialized
INFO - 2024-02-21 21:12:52 --> Helper loaded: url_helper
INFO - 2024-02-21 21:12:52 --> Helper loaded: file_helper
INFO - 2024-02-21 21:12:52 --> Helper loaded: form_helper
INFO - 2024-02-21 21:12:52 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:12:52 --> Controller Class Initialized
INFO - 2024-02-21 21:12:52 --> Form Validation Class Initialized
INFO - 2024-02-21 21:12:52 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:12:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:12:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:12:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:12:52 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:15:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:15:23 --> Config Class Initialized
INFO - 2024-02-21 21:15:23 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:15:23 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:15:23 --> Utf8 Class Initialized
INFO - 2024-02-21 21:15:23 --> URI Class Initialized
INFO - 2024-02-21 21:15:23 --> Router Class Initialized
INFO - 2024-02-21 21:15:23 --> Output Class Initialized
INFO - 2024-02-21 21:15:23 --> Security Class Initialized
DEBUG - 2024-02-21 21:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:15:23 --> Input Class Initialized
INFO - 2024-02-21 21:15:23 --> Language Class Initialized
INFO - 2024-02-21 21:15:23 --> Loader Class Initialized
INFO - 2024-02-21 21:15:23 --> Helper loaded: url_helper
INFO - 2024-02-21 21:15:23 --> Helper loaded: file_helper
INFO - 2024-02-21 21:15:23 --> Helper loaded: form_helper
INFO - 2024-02-21 21:15:23 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:15:23 --> Controller Class Initialized
INFO - 2024-02-21 21:15:23 --> Form Validation Class Initialized
INFO - 2024-02-21 21:15:23 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:15:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:15:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:15:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:15:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:15:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:15:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:15:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:15:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:15:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:15:23 --> Final output sent to browser
DEBUG - 2024-02-21 21:15:23 --> Total execution time: 0.0341
ERROR - 2024-02-21 21:15:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:15:23 --> Config Class Initialized
INFO - 2024-02-21 21:15:23 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:15:23 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:15:23 --> Utf8 Class Initialized
INFO - 2024-02-21 21:15:23 --> URI Class Initialized
INFO - 2024-02-21 21:15:23 --> Router Class Initialized
INFO - 2024-02-21 21:15:23 --> Output Class Initialized
INFO - 2024-02-21 21:15:23 --> Security Class Initialized
DEBUG - 2024-02-21 21:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:15:23 --> Input Class Initialized
INFO - 2024-02-21 21:15:23 --> Language Class Initialized
INFO - 2024-02-21 21:15:23 --> Loader Class Initialized
INFO - 2024-02-21 21:15:23 --> Helper loaded: url_helper
INFO - 2024-02-21 21:15:23 --> Helper loaded: file_helper
INFO - 2024-02-21 21:15:23 --> Helper loaded: form_helper
INFO - 2024-02-21 21:15:23 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:15:23 --> Controller Class Initialized
INFO - 2024-02-21 21:15:23 --> Form Validation Class Initialized
INFO - 2024-02-21 21:15:23 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:15:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:15:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:15:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:15:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:20:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:20:31 --> Config Class Initialized
INFO - 2024-02-21 21:20:31 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:20:31 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:20:31 --> Utf8 Class Initialized
INFO - 2024-02-21 21:20:31 --> URI Class Initialized
INFO - 2024-02-21 21:20:31 --> Router Class Initialized
INFO - 2024-02-21 21:20:31 --> Output Class Initialized
INFO - 2024-02-21 21:20:31 --> Security Class Initialized
DEBUG - 2024-02-21 21:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:20:31 --> Input Class Initialized
INFO - 2024-02-21 21:20:31 --> Language Class Initialized
INFO - 2024-02-21 21:20:31 --> Loader Class Initialized
INFO - 2024-02-21 21:20:31 --> Helper loaded: url_helper
INFO - 2024-02-21 21:20:31 --> Helper loaded: file_helper
INFO - 2024-02-21 21:20:31 --> Helper loaded: form_helper
INFO - 2024-02-21 21:20:31 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:20:31 --> Controller Class Initialized
INFO - 2024-02-21 21:20:31 --> Form Validation Class Initialized
INFO - 2024-02-21 21:20:31 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:20:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:20:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:20:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:20:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:20:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:20:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:20:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:20:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:20:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:20:31 --> Final output sent to browser
DEBUG - 2024-02-21 21:20:31 --> Total execution time: 0.0226
ERROR - 2024-02-21 21:20:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:20:31 --> Config Class Initialized
INFO - 2024-02-21 21:20:31 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:20:31 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:20:31 --> Utf8 Class Initialized
INFO - 2024-02-21 21:20:31 --> URI Class Initialized
INFO - 2024-02-21 21:20:31 --> Router Class Initialized
INFO - 2024-02-21 21:20:31 --> Output Class Initialized
INFO - 2024-02-21 21:20:32 --> Security Class Initialized
DEBUG - 2024-02-21 21:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:20:32 --> Input Class Initialized
INFO - 2024-02-21 21:20:32 --> Language Class Initialized
INFO - 2024-02-21 21:20:32 --> Loader Class Initialized
INFO - 2024-02-21 21:20:32 --> Helper loaded: url_helper
INFO - 2024-02-21 21:20:32 --> Helper loaded: file_helper
INFO - 2024-02-21 21:20:32 --> Helper loaded: form_helper
INFO - 2024-02-21 21:20:32 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:20:32 --> Controller Class Initialized
INFO - 2024-02-21 21:20:32 --> Form Validation Class Initialized
INFO - 2024-02-21 21:20:32 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:20:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:20:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:20:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:20:32 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:21:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:21:07 --> Config Class Initialized
INFO - 2024-02-21 21:21:07 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:21:07 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:21:07 --> Utf8 Class Initialized
INFO - 2024-02-21 21:21:07 --> URI Class Initialized
INFO - 2024-02-21 21:21:07 --> Router Class Initialized
INFO - 2024-02-21 21:21:07 --> Output Class Initialized
INFO - 2024-02-21 21:21:07 --> Security Class Initialized
DEBUG - 2024-02-21 21:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:21:07 --> Input Class Initialized
INFO - 2024-02-21 21:21:07 --> Language Class Initialized
INFO - 2024-02-21 21:21:07 --> Loader Class Initialized
INFO - 2024-02-21 21:21:07 --> Helper loaded: url_helper
INFO - 2024-02-21 21:21:07 --> Helper loaded: file_helper
INFO - 2024-02-21 21:21:07 --> Helper loaded: form_helper
INFO - 2024-02-21 21:21:07 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:21:07 --> Controller Class Initialized
INFO - 2024-02-21 21:21:07 --> Form Validation Class Initialized
INFO - 2024-02-21 21:21:07 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:21:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:21:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:21:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:21:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:21:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:21:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:21:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:21:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:21:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-21 21:21:07 --> Final output sent to browser
DEBUG - 2024-02-21 21:21:07 --> Total execution time: 0.0315
ERROR - 2024-02-21 21:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:21:08 --> Config Class Initialized
INFO - 2024-02-21 21:21:08 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:21:08 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:21:08 --> Utf8 Class Initialized
INFO - 2024-02-21 21:21:08 --> URI Class Initialized
INFO - 2024-02-21 21:21:08 --> Router Class Initialized
INFO - 2024-02-21 21:21:08 --> Output Class Initialized
INFO - 2024-02-21 21:21:08 --> Security Class Initialized
DEBUG - 2024-02-21 21:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:21:08 --> Input Class Initialized
INFO - 2024-02-21 21:21:08 --> Language Class Initialized
INFO - 2024-02-21 21:21:08 --> Loader Class Initialized
INFO - 2024-02-21 21:21:08 --> Helper loaded: url_helper
INFO - 2024-02-21 21:21:08 --> Helper loaded: file_helper
INFO - 2024-02-21 21:21:08 --> Helper loaded: form_helper
INFO - 2024-02-21 21:21:08 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:21:08 --> Controller Class Initialized
INFO - 2024-02-21 21:21:08 --> Form Validation Class Initialized
INFO - 2024-02-21 21:21:08 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:21:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:21:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:21:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:21:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:21:11 --> Config Class Initialized
INFO - 2024-02-21 21:21:11 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:21:11 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:21:11 --> Utf8 Class Initialized
INFO - 2024-02-21 21:21:11 --> URI Class Initialized
INFO - 2024-02-21 21:21:11 --> Router Class Initialized
INFO - 2024-02-21 21:21:11 --> Output Class Initialized
INFO - 2024-02-21 21:21:11 --> Security Class Initialized
DEBUG - 2024-02-21 21:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:21:11 --> Input Class Initialized
INFO - 2024-02-21 21:21:11 --> Language Class Initialized
INFO - 2024-02-21 21:21:11 --> Loader Class Initialized
INFO - 2024-02-21 21:21:11 --> Helper loaded: url_helper
INFO - 2024-02-21 21:21:11 --> Helper loaded: file_helper
INFO - 2024-02-21 21:21:11 --> Helper loaded: form_helper
INFO - 2024-02-21 21:21:11 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:21:11 --> Controller Class Initialized
INFO - 2024-02-21 21:21:11 --> Form Validation Class Initialized
INFO - 2024-02-21 21:21:11 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:21:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:21:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:21:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:21:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:21:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:21:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:21:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:21:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:21:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:21:11 --> Final output sent to browser
DEBUG - 2024-02-21 21:21:11 --> Total execution time: 0.0342
ERROR - 2024-02-21 21:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:21:11 --> Config Class Initialized
INFO - 2024-02-21 21:21:11 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:21:11 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:21:11 --> Utf8 Class Initialized
INFO - 2024-02-21 21:21:11 --> URI Class Initialized
INFO - 2024-02-21 21:21:11 --> Router Class Initialized
INFO - 2024-02-21 21:21:11 --> Output Class Initialized
INFO - 2024-02-21 21:21:11 --> Security Class Initialized
DEBUG - 2024-02-21 21:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:21:11 --> Input Class Initialized
INFO - 2024-02-21 21:21:11 --> Language Class Initialized
INFO - 2024-02-21 21:21:11 --> Loader Class Initialized
INFO - 2024-02-21 21:21:11 --> Helper loaded: url_helper
INFO - 2024-02-21 21:21:11 --> Helper loaded: file_helper
INFO - 2024-02-21 21:21:11 --> Helper loaded: form_helper
INFO - 2024-02-21 21:21:11 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:21:11 --> Controller Class Initialized
INFO - 2024-02-21 21:21:11 --> Form Validation Class Initialized
INFO - 2024-02-21 21:21:11 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:21:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:21:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:21:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:21:11 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:22:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:22:58 --> Config Class Initialized
INFO - 2024-02-21 21:22:58 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:22:58 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:22:58 --> Utf8 Class Initialized
INFO - 2024-02-21 21:22:58 --> URI Class Initialized
INFO - 2024-02-21 21:22:58 --> Router Class Initialized
INFO - 2024-02-21 21:22:58 --> Output Class Initialized
INFO - 2024-02-21 21:22:58 --> Security Class Initialized
DEBUG - 2024-02-21 21:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:22:58 --> Input Class Initialized
INFO - 2024-02-21 21:22:58 --> Language Class Initialized
INFO - 2024-02-21 21:22:58 --> Loader Class Initialized
INFO - 2024-02-21 21:22:58 --> Helper loaded: url_helper
INFO - 2024-02-21 21:22:58 --> Helper loaded: file_helper
INFO - 2024-02-21 21:22:58 --> Helper loaded: form_helper
INFO - 2024-02-21 21:22:58 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:22:58 --> Controller Class Initialized
INFO - 2024-02-21 21:22:58 --> Form Validation Class Initialized
INFO - 2024-02-21 21:22:58 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:22:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:22:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:22:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:22:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:22:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:22:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:22:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:22:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:22:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:22:58 --> Final output sent to browser
DEBUG - 2024-02-21 21:22:58 --> Total execution time: 0.0427
ERROR - 2024-02-21 21:22:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:22:59 --> Config Class Initialized
INFO - 2024-02-21 21:22:59 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:22:59 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:22:59 --> Utf8 Class Initialized
INFO - 2024-02-21 21:22:59 --> URI Class Initialized
INFO - 2024-02-21 21:22:59 --> Router Class Initialized
INFO - 2024-02-21 21:22:59 --> Output Class Initialized
INFO - 2024-02-21 21:22:59 --> Security Class Initialized
DEBUG - 2024-02-21 21:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:22:59 --> Input Class Initialized
INFO - 2024-02-21 21:22:59 --> Language Class Initialized
INFO - 2024-02-21 21:22:59 --> Loader Class Initialized
INFO - 2024-02-21 21:22:59 --> Helper loaded: url_helper
INFO - 2024-02-21 21:22:59 --> Helper loaded: file_helper
INFO - 2024-02-21 21:22:59 --> Helper loaded: form_helper
INFO - 2024-02-21 21:22:59 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:22:59 --> Controller Class Initialized
INFO - 2024-02-21 21:22:59 --> Form Validation Class Initialized
INFO - 2024-02-21 21:22:59 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:22:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:22:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:22:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:22:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:23:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:23:59 --> Config Class Initialized
INFO - 2024-02-21 21:23:59 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:23:59 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:23:59 --> Utf8 Class Initialized
INFO - 2024-02-21 21:23:59 --> URI Class Initialized
INFO - 2024-02-21 21:23:59 --> Router Class Initialized
INFO - 2024-02-21 21:23:59 --> Output Class Initialized
INFO - 2024-02-21 21:23:59 --> Security Class Initialized
DEBUG - 2024-02-21 21:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:23:59 --> Input Class Initialized
INFO - 2024-02-21 21:23:59 --> Language Class Initialized
INFO - 2024-02-21 21:23:59 --> Loader Class Initialized
INFO - 2024-02-21 21:23:59 --> Helper loaded: url_helper
INFO - 2024-02-21 21:23:59 --> Helper loaded: file_helper
INFO - 2024-02-21 21:23:59 --> Helper loaded: form_helper
INFO - 2024-02-21 21:23:59 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:23:59 --> Controller Class Initialized
INFO - 2024-02-21 21:23:59 --> Form Validation Class Initialized
INFO - 2024-02-21 21:23:59 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:23:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:23:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:23:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:23:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:23:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:23:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:23:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:23:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:23:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:23:59 --> Final output sent to browser
DEBUG - 2024-02-21 21:23:59 --> Total execution time: 0.0336
ERROR - 2024-02-21 21:24:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:24:00 --> Config Class Initialized
INFO - 2024-02-21 21:24:00 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:24:00 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:24:00 --> Utf8 Class Initialized
INFO - 2024-02-21 21:24:00 --> URI Class Initialized
INFO - 2024-02-21 21:24:00 --> Router Class Initialized
INFO - 2024-02-21 21:24:00 --> Output Class Initialized
INFO - 2024-02-21 21:24:00 --> Security Class Initialized
DEBUG - 2024-02-21 21:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:24:00 --> Input Class Initialized
INFO - 2024-02-21 21:24:00 --> Language Class Initialized
INFO - 2024-02-21 21:24:00 --> Loader Class Initialized
INFO - 2024-02-21 21:24:00 --> Helper loaded: url_helper
INFO - 2024-02-21 21:24:00 --> Helper loaded: file_helper
INFO - 2024-02-21 21:24:00 --> Helper loaded: form_helper
INFO - 2024-02-21 21:24:00 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:24:00 --> Controller Class Initialized
INFO - 2024-02-21 21:24:00 --> Form Validation Class Initialized
INFO - 2024-02-21 21:24:00 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:24:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:24:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:24:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:24:00 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:25:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:25:14 --> Config Class Initialized
INFO - 2024-02-21 21:25:14 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:25:14 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:25:14 --> Utf8 Class Initialized
INFO - 2024-02-21 21:25:14 --> URI Class Initialized
INFO - 2024-02-21 21:25:14 --> Router Class Initialized
INFO - 2024-02-21 21:25:14 --> Output Class Initialized
INFO - 2024-02-21 21:25:14 --> Security Class Initialized
DEBUG - 2024-02-21 21:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:25:14 --> Input Class Initialized
INFO - 2024-02-21 21:25:14 --> Language Class Initialized
INFO - 2024-02-21 21:25:14 --> Loader Class Initialized
INFO - 2024-02-21 21:25:14 --> Helper loaded: url_helper
INFO - 2024-02-21 21:25:14 --> Helper loaded: file_helper
INFO - 2024-02-21 21:25:14 --> Helper loaded: form_helper
INFO - 2024-02-21 21:25:14 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:25:14 --> Controller Class Initialized
INFO - 2024-02-21 21:25:14 --> Form Validation Class Initialized
INFO - 2024-02-21 21:25:14 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:25:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:25:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:25:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:25:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:25:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:25:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:25:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:25:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:25:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:25:14 --> Final output sent to browser
DEBUG - 2024-02-21 21:25:14 --> Total execution time: 0.0330
ERROR - 2024-02-21 21:25:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:25:15 --> Config Class Initialized
INFO - 2024-02-21 21:25:15 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:25:15 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:25:15 --> Utf8 Class Initialized
INFO - 2024-02-21 21:25:15 --> URI Class Initialized
INFO - 2024-02-21 21:25:15 --> Router Class Initialized
INFO - 2024-02-21 21:25:15 --> Output Class Initialized
INFO - 2024-02-21 21:25:15 --> Security Class Initialized
DEBUG - 2024-02-21 21:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:25:15 --> Input Class Initialized
INFO - 2024-02-21 21:25:15 --> Language Class Initialized
INFO - 2024-02-21 21:25:15 --> Loader Class Initialized
INFO - 2024-02-21 21:25:15 --> Helper loaded: url_helper
INFO - 2024-02-21 21:25:15 --> Helper loaded: file_helper
INFO - 2024-02-21 21:25:15 --> Helper loaded: form_helper
INFO - 2024-02-21 21:25:15 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:25:15 --> Controller Class Initialized
INFO - 2024-02-21 21:25:15 --> Form Validation Class Initialized
INFO - 2024-02-21 21:25:15 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:25:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:25:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:25:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:25:15 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:25:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:25:34 --> Config Class Initialized
INFO - 2024-02-21 21:25:34 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:25:34 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:25:34 --> Utf8 Class Initialized
INFO - 2024-02-21 21:25:34 --> URI Class Initialized
INFO - 2024-02-21 21:25:34 --> Router Class Initialized
INFO - 2024-02-21 21:25:34 --> Output Class Initialized
INFO - 2024-02-21 21:25:34 --> Security Class Initialized
DEBUG - 2024-02-21 21:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:25:34 --> Input Class Initialized
INFO - 2024-02-21 21:25:34 --> Language Class Initialized
INFO - 2024-02-21 21:25:34 --> Loader Class Initialized
INFO - 2024-02-21 21:25:34 --> Helper loaded: url_helper
INFO - 2024-02-21 21:25:34 --> Helper loaded: file_helper
INFO - 2024-02-21 21:25:34 --> Helper loaded: form_helper
INFO - 2024-02-21 21:25:34 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:25:34 --> Controller Class Initialized
INFO - 2024-02-21 21:25:34 --> Form Validation Class Initialized
INFO - 2024-02-21 21:25:34 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:25:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:25:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:25:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:25:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:25:34 --> Final output sent to browser
DEBUG - 2024-02-21 21:25:34 --> Total execution time: 0.0281
ERROR - 2024-02-21 21:25:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:25:35 --> Config Class Initialized
INFO - 2024-02-21 21:25:35 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:25:35 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:25:35 --> Utf8 Class Initialized
INFO - 2024-02-21 21:25:35 --> URI Class Initialized
INFO - 2024-02-21 21:25:35 --> Router Class Initialized
INFO - 2024-02-21 21:25:35 --> Output Class Initialized
INFO - 2024-02-21 21:25:35 --> Security Class Initialized
DEBUG - 2024-02-21 21:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:25:35 --> Input Class Initialized
INFO - 2024-02-21 21:25:35 --> Language Class Initialized
INFO - 2024-02-21 21:25:35 --> Loader Class Initialized
INFO - 2024-02-21 21:25:35 --> Helper loaded: url_helper
INFO - 2024-02-21 21:25:35 --> Helper loaded: file_helper
INFO - 2024-02-21 21:25:35 --> Helper loaded: form_helper
INFO - 2024-02-21 21:25:35 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:25:35 --> Controller Class Initialized
INFO - 2024-02-21 21:25:35 --> Form Validation Class Initialized
INFO - 2024-02-21 21:25:35 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:25:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:25:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:25:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:25:35 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 21:25:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:25:51 --> Config Class Initialized
INFO - 2024-02-21 21:25:51 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:25:51 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:25:51 --> Utf8 Class Initialized
INFO - 2024-02-21 21:25:51 --> URI Class Initialized
INFO - 2024-02-21 21:25:51 --> Router Class Initialized
INFO - 2024-02-21 21:25:51 --> Output Class Initialized
INFO - 2024-02-21 21:25:51 --> Security Class Initialized
DEBUG - 2024-02-21 21:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:25:51 --> Input Class Initialized
INFO - 2024-02-21 21:25:51 --> Language Class Initialized
INFO - 2024-02-21 21:25:51 --> Loader Class Initialized
INFO - 2024-02-21 21:25:51 --> Helper loaded: url_helper
INFO - 2024-02-21 21:25:51 --> Helper loaded: file_helper
INFO - 2024-02-21 21:25:51 --> Helper loaded: form_helper
INFO - 2024-02-21 21:25:51 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:25:51 --> Controller Class Initialized
INFO - 2024-02-21 21:25:51 --> Form Validation Class Initialized
INFO - 2024-02-21 21:25:51 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:25:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:25:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:25:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:25:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 21:25:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 21:25:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 21:25:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 21:25:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 21:25:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 21:25:51 --> Final output sent to browser
DEBUG - 2024-02-21 21:25:51 --> Total execution time: 0.0424
ERROR - 2024-02-21 21:25:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 21:25:52 --> Config Class Initialized
INFO - 2024-02-21 21:25:52 --> Hooks Class Initialized
DEBUG - 2024-02-21 21:25:52 --> UTF-8 Support Enabled
INFO - 2024-02-21 21:25:52 --> Utf8 Class Initialized
INFO - 2024-02-21 21:25:52 --> URI Class Initialized
INFO - 2024-02-21 21:25:52 --> Router Class Initialized
INFO - 2024-02-21 21:25:52 --> Output Class Initialized
INFO - 2024-02-21 21:25:52 --> Security Class Initialized
DEBUG - 2024-02-21 21:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 21:25:52 --> Input Class Initialized
INFO - 2024-02-21 21:25:52 --> Language Class Initialized
INFO - 2024-02-21 21:25:52 --> Loader Class Initialized
INFO - 2024-02-21 21:25:52 --> Helper loaded: url_helper
INFO - 2024-02-21 21:25:52 --> Helper loaded: file_helper
INFO - 2024-02-21 21:25:52 --> Helper loaded: form_helper
INFO - 2024-02-21 21:25:53 --> Database Driver Class Initialized
DEBUG - 2024-02-21 21:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 21:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 21:25:53 --> Controller Class Initialized
INFO - 2024-02-21 21:25:53 --> Form Validation Class Initialized
INFO - 2024-02-21 21:25:53 --> Model "MasterModel" initialized
INFO - 2024-02-21 21:25:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 21:25:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 21:25:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 21:25:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:04:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:04:56 --> Config Class Initialized
INFO - 2024-02-21 23:04:56 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:04:56 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:04:56 --> Utf8 Class Initialized
INFO - 2024-02-21 23:04:56 --> URI Class Initialized
INFO - 2024-02-21 23:04:56 --> Router Class Initialized
INFO - 2024-02-21 23:04:56 --> Output Class Initialized
INFO - 2024-02-21 23:04:56 --> Security Class Initialized
DEBUG - 2024-02-21 23:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:04:56 --> Input Class Initialized
INFO - 2024-02-21 23:04:56 --> Language Class Initialized
INFO - 2024-02-21 23:04:56 --> Loader Class Initialized
INFO - 2024-02-21 23:04:56 --> Helper loaded: url_helper
INFO - 2024-02-21 23:04:56 --> Helper loaded: file_helper
INFO - 2024-02-21 23:04:56 --> Helper loaded: form_helper
INFO - 2024-02-21 23:04:56 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:04:56 --> Controller Class Initialized
INFO - 2024-02-21 23:04:56 --> Form Validation Class Initialized
INFO - 2024-02-21 23:04:56 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:04:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:04:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:04:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:04:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:04:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:04:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:04:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:04:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:04:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:04:56 --> Final output sent to browser
DEBUG - 2024-02-21 23:04:56 --> Total execution time: 0.0348
ERROR - 2024-02-21 23:04:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:04:56 --> Config Class Initialized
INFO - 2024-02-21 23:04:56 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:04:56 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:04:56 --> Utf8 Class Initialized
INFO - 2024-02-21 23:04:56 --> URI Class Initialized
INFO - 2024-02-21 23:04:56 --> Router Class Initialized
INFO - 2024-02-21 23:04:56 --> Output Class Initialized
INFO - 2024-02-21 23:04:56 --> Security Class Initialized
DEBUG - 2024-02-21 23:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:04:56 --> Input Class Initialized
INFO - 2024-02-21 23:04:56 --> Language Class Initialized
INFO - 2024-02-21 23:04:56 --> Loader Class Initialized
INFO - 2024-02-21 23:04:56 --> Helper loaded: url_helper
INFO - 2024-02-21 23:04:56 --> Helper loaded: file_helper
INFO - 2024-02-21 23:04:56 --> Helper loaded: form_helper
INFO - 2024-02-21 23:04:56 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:04:56 --> Controller Class Initialized
INFO - 2024-02-21 23:04:56 --> Form Validation Class Initialized
INFO - 2024-02-21 23:04:56 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:04:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:04:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:04:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:04:56 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:05:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:05:10 --> Config Class Initialized
INFO - 2024-02-21 23:05:10 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:05:10 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:05:10 --> Utf8 Class Initialized
INFO - 2024-02-21 23:05:10 --> URI Class Initialized
INFO - 2024-02-21 23:05:10 --> Router Class Initialized
INFO - 2024-02-21 23:05:10 --> Output Class Initialized
INFO - 2024-02-21 23:05:10 --> Security Class Initialized
DEBUG - 2024-02-21 23:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:05:10 --> Input Class Initialized
INFO - 2024-02-21 23:05:10 --> Language Class Initialized
INFO - 2024-02-21 23:05:10 --> Loader Class Initialized
INFO - 2024-02-21 23:05:10 --> Helper loaded: url_helper
INFO - 2024-02-21 23:05:10 --> Helper loaded: file_helper
INFO - 2024-02-21 23:05:10 --> Helper loaded: form_helper
INFO - 2024-02-21 23:05:10 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:05:10 --> Controller Class Initialized
INFO - 2024-02-21 23:05:10 --> Form Validation Class Initialized
INFO - 2024-02-21 23:05:10 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:05:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:05:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:05:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:05:10 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:05:13 --> Config Class Initialized
INFO - 2024-02-21 23:05:13 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:05:13 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:05:13 --> Utf8 Class Initialized
INFO - 2024-02-21 23:05:13 --> URI Class Initialized
INFO - 2024-02-21 23:05:13 --> Router Class Initialized
INFO - 2024-02-21 23:05:13 --> Output Class Initialized
INFO - 2024-02-21 23:05:13 --> Security Class Initialized
DEBUG - 2024-02-21 23:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:05:13 --> Input Class Initialized
INFO - 2024-02-21 23:05:13 --> Language Class Initialized
INFO - 2024-02-21 23:05:13 --> Loader Class Initialized
INFO - 2024-02-21 23:05:13 --> Helper loaded: url_helper
INFO - 2024-02-21 23:05:13 --> Helper loaded: file_helper
INFO - 2024-02-21 23:05:13 --> Helper loaded: form_helper
INFO - 2024-02-21 23:05:13 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:05:13 --> Controller Class Initialized
INFO - 2024-02-21 23:05:13 --> Form Validation Class Initialized
INFO - 2024-02-21 23:05:13 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:05:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:05:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:05:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:05:13 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:05:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:05:20 --> Config Class Initialized
INFO - 2024-02-21 23:05:20 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:05:20 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:05:20 --> Utf8 Class Initialized
INFO - 2024-02-21 23:05:20 --> URI Class Initialized
INFO - 2024-02-21 23:05:20 --> Router Class Initialized
INFO - 2024-02-21 23:05:20 --> Output Class Initialized
INFO - 2024-02-21 23:05:20 --> Security Class Initialized
DEBUG - 2024-02-21 23:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:05:20 --> Input Class Initialized
INFO - 2024-02-21 23:05:20 --> Language Class Initialized
INFO - 2024-02-21 23:05:20 --> Loader Class Initialized
INFO - 2024-02-21 23:05:20 --> Helper loaded: url_helper
INFO - 2024-02-21 23:05:20 --> Helper loaded: file_helper
INFO - 2024-02-21 23:05:20 --> Helper loaded: form_helper
INFO - 2024-02-21 23:05:20 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:05:20 --> Controller Class Initialized
INFO - 2024-02-21 23:05:20 --> Form Validation Class Initialized
INFO - 2024-02-21 23:05:20 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:05:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:05:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:05:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:05:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:05:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:05:24 --> Config Class Initialized
INFO - 2024-02-21 23:05:24 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:05:24 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:05:24 --> Utf8 Class Initialized
INFO - 2024-02-21 23:05:24 --> URI Class Initialized
INFO - 2024-02-21 23:05:24 --> Router Class Initialized
INFO - 2024-02-21 23:05:24 --> Output Class Initialized
INFO - 2024-02-21 23:05:24 --> Security Class Initialized
DEBUG - 2024-02-21 23:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:05:24 --> Input Class Initialized
INFO - 2024-02-21 23:05:24 --> Language Class Initialized
INFO - 2024-02-21 23:05:24 --> Loader Class Initialized
INFO - 2024-02-21 23:05:24 --> Helper loaded: url_helper
INFO - 2024-02-21 23:05:24 --> Helper loaded: file_helper
INFO - 2024-02-21 23:05:24 --> Helper loaded: form_helper
INFO - 2024-02-21 23:05:24 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:05:24 --> Controller Class Initialized
INFO - 2024-02-21 23:05:24 --> Form Validation Class Initialized
INFO - 2024-02-21 23:05:24 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:05:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:05:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:05:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:05:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:05:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:05:32 --> Config Class Initialized
INFO - 2024-02-21 23:05:32 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:05:32 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:05:32 --> Utf8 Class Initialized
INFO - 2024-02-21 23:05:32 --> URI Class Initialized
INFO - 2024-02-21 23:05:32 --> Router Class Initialized
INFO - 2024-02-21 23:05:32 --> Output Class Initialized
INFO - 2024-02-21 23:05:32 --> Security Class Initialized
DEBUG - 2024-02-21 23:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:05:32 --> Input Class Initialized
INFO - 2024-02-21 23:05:32 --> Language Class Initialized
INFO - 2024-02-21 23:05:32 --> Loader Class Initialized
INFO - 2024-02-21 23:05:32 --> Helper loaded: url_helper
INFO - 2024-02-21 23:05:32 --> Helper loaded: file_helper
INFO - 2024-02-21 23:05:32 --> Helper loaded: form_helper
INFO - 2024-02-21 23:05:32 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:05:32 --> Controller Class Initialized
INFO - 2024-02-21 23:05:32 --> Form Validation Class Initialized
INFO - 2024-02-21 23:05:32 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:05:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:05:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:05:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:05:32 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:05:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:05:51 --> Config Class Initialized
INFO - 2024-02-21 23:05:51 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:05:51 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:05:51 --> Utf8 Class Initialized
INFO - 2024-02-21 23:05:51 --> URI Class Initialized
INFO - 2024-02-21 23:05:51 --> Router Class Initialized
INFO - 2024-02-21 23:05:51 --> Output Class Initialized
INFO - 2024-02-21 23:05:51 --> Security Class Initialized
DEBUG - 2024-02-21 23:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:05:51 --> Input Class Initialized
INFO - 2024-02-21 23:05:51 --> Language Class Initialized
INFO - 2024-02-21 23:05:51 --> Loader Class Initialized
INFO - 2024-02-21 23:05:51 --> Helper loaded: url_helper
INFO - 2024-02-21 23:05:51 --> Helper loaded: file_helper
INFO - 2024-02-21 23:05:51 --> Helper loaded: form_helper
INFO - 2024-02-21 23:05:51 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:05:51 --> Controller Class Initialized
INFO - 2024-02-21 23:05:51 --> Form Validation Class Initialized
INFO - 2024-02-21 23:05:51 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:05:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:05:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:05:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:05:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:05:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:05:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:05:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:05:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:05:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:05:51 --> Final output sent to browser
DEBUG - 2024-02-21 23:05:51 --> Total execution time: 0.0345
ERROR - 2024-02-21 23:05:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:05:52 --> Config Class Initialized
INFO - 2024-02-21 23:05:52 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:05:52 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:05:52 --> Utf8 Class Initialized
INFO - 2024-02-21 23:05:52 --> URI Class Initialized
INFO - 2024-02-21 23:05:52 --> Router Class Initialized
INFO - 2024-02-21 23:05:52 --> Output Class Initialized
INFO - 2024-02-21 23:05:52 --> Security Class Initialized
DEBUG - 2024-02-21 23:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:05:52 --> Input Class Initialized
INFO - 2024-02-21 23:05:52 --> Language Class Initialized
INFO - 2024-02-21 23:05:52 --> Loader Class Initialized
INFO - 2024-02-21 23:05:52 --> Helper loaded: url_helper
INFO - 2024-02-21 23:05:52 --> Helper loaded: file_helper
INFO - 2024-02-21 23:05:52 --> Helper loaded: form_helper
INFO - 2024-02-21 23:05:52 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:05:52 --> Controller Class Initialized
INFO - 2024-02-21 23:05:52 --> Form Validation Class Initialized
INFO - 2024-02-21 23:05:52 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:05:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:05:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:05:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:05:52 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:07:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:07:39 --> Config Class Initialized
INFO - 2024-02-21 23:07:39 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:07:39 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:07:39 --> Utf8 Class Initialized
INFO - 2024-02-21 23:07:39 --> URI Class Initialized
INFO - 2024-02-21 23:07:39 --> Router Class Initialized
INFO - 2024-02-21 23:07:39 --> Output Class Initialized
INFO - 2024-02-21 23:07:39 --> Security Class Initialized
DEBUG - 2024-02-21 23:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:07:39 --> Input Class Initialized
INFO - 2024-02-21 23:07:39 --> Language Class Initialized
INFO - 2024-02-21 23:07:39 --> Loader Class Initialized
INFO - 2024-02-21 23:07:39 --> Helper loaded: url_helper
INFO - 2024-02-21 23:07:39 --> Helper loaded: file_helper
INFO - 2024-02-21 23:07:39 --> Helper loaded: form_helper
INFO - 2024-02-21 23:07:39 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:07:39 --> Controller Class Initialized
INFO - 2024-02-21 23:07:39 --> Form Validation Class Initialized
INFO - 2024-02-21 23:07:39 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:07:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:07:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:07:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:07:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:07:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:07:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:07:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:07:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:07:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:07:39 --> Final output sent to browser
DEBUG - 2024-02-21 23:07:39 --> Total execution time: 0.0328
ERROR - 2024-02-21 23:07:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:07:39 --> Config Class Initialized
INFO - 2024-02-21 23:07:39 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:07:39 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:07:39 --> Utf8 Class Initialized
INFO - 2024-02-21 23:07:39 --> URI Class Initialized
INFO - 2024-02-21 23:07:39 --> Router Class Initialized
INFO - 2024-02-21 23:07:39 --> Output Class Initialized
INFO - 2024-02-21 23:07:39 --> Security Class Initialized
DEBUG - 2024-02-21 23:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:07:39 --> Input Class Initialized
INFO - 2024-02-21 23:07:39 --> Language Class Initialized
INFO - 2024-02-21 23:07:39 --> Loader Class Initialized
INFO - 2024-02-21 23:07:39 --> Helper loaded: url_helper
INFO - 2024-02-21 23:07:39 --> Helper loaded: file_helper
INFO - 2024-02-21 23:07:39 --> Helper loaded: form_helper
INFO - 2024-02-21 23:07:39 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:07:39 --> Controller Class Initialized
INFO - 2024-02-21 23:07:39 --> Form Validation Class Initialized
INFO - 2024-02-21 23:07:39 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:07:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:07:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:07:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:07:39 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:08:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:08:03 --> Config Class Initialized
INFO - 2024-02-21 23:08:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:08:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:08:03 --> Utf8 Class Initialized
INFO - 2024-02-21 23:08:03 --> URI Class Initialized
INFO - 2024-02-21 23:08:03 --> Router Class Initialized
INFO - 2024-02-21 23:08:03 --> Output Class Initialized
INFO - 2024-02-21 23:08:03 --> Security Class Initialized
DEBUG - 2024-02-21 23:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:08:03 --> Input Class Initialized
INFO - 2024-02-21 23:08:03 --> Language Class Initialized
INFO - 2024-02-21 23:08:03 --> Loader Class Initialized
INFO - 2024-02-21 23:08:03 --> Helper loaded: url_helper
INFO - 2024-02-21 23:08:03 --> Helper loaded: file_helper
INFO - 2024-02-21 23:08:03 --> Helper loaded: form_helper
INFO - 2024-02-21 23:08:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:08:03 --> Controller Class Initialized
INFO - 2024-02-21 23:08:03 --> Form Validation Class Initialized
INFO - 2024-02-21 23:08:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:08:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:08:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:08:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:08:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:08:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:08:04 --> Config Class Initialized
INFO - 2024-02-21 23:08:04 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:08:04 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:08:04 --> Utf8 Class Initialized
INFO - 2024-02-21 23:08:04 --> URI Class Initialized
INFO - 2024-02-21 23:08:04 --> Router Class Initialized
INFO - 2024-02-21 23:08:04 --> Output Class Initialized
INFO - 2024-02-21 23:08:04 --> Security Class Initialized
DEBUG - 2024-02-21 23:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:08:04 --> Input Class Initialized
INFO - 2024-02-21 23:08:04 --> Language Class Initialized
INFO - 2024-02-21 23:08:04 --> Loader Class Initialized
INFO - 2024-02-21 23:08:04 --> Helper loaded: url_helper
INFO - 2024-02-21 23:08:04 --> Helper loaded: file_helper
INFO - 2024-02-21 23:08:04 --> Helper loaded: form_helper
INFO - 2024-02-21 23:08:04 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:08:04 --> Controller Class Initialized
INFO - 2024-02-21 23:08:04 --> Form Validation Class Initialized
INFO - 2024-02-21 23:08:04 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:08:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:08:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:08:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:08:04 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:08:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:08:09 --> Config Class Initialized
INFO - 2024-02-21 23:08:09 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:08:09 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:08:09 --> Utf8 Class Initialized
INFO - 2024-02-21 23:08:09 --> URI Class Initialized
INFO - 2024-02-21 23:08:09 --> Router Class Initialized
INFO - 2024-02-21 23:08:09 --> Output Class Initialized
INFO - 2024-02-21 23:08:09 --> Security Class Initialized
DEBUG - 2024-02-21 23:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:08:09 --> Input Class Initialized
INFO - 2024-02-21 23:08:09 --> Language Class Initialized
INFO - 2024-02-21 23:08:09 --> Loader Class Initialized
INFO - 2024-02-21 23:08:09 --> Helper loaded: url_helper
INFO - 2024-02-21 23:08:09 --> Helper loaded: file_helper
INFO - 2024-02-21 23:08:09 --> Helper loaded: form_helper
INFO - 2024-02-21 23:08:09 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:08:09 --> Controller Class Initialized
INFO - 2024-02-21 23:08:09 --> Form Validation Class Initialized
INFO - 2024-02-21 23:08:09 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:08:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:08:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:08:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:08:09 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:08:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:08:20 --> Config Class Initialized
INFO - 2024-02-21 23:08:20 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:08:20 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:08:20 --> Utf8 Class Initialized
INFO - 2024-02-21 23:08:20 --> URI Class Initialized
INFO - 2024-02-21 23:08:20 --> Router Class Initialized
INFO - 2024-02-21 23:08:20 --> Output Class Initialized
INFO - 2024-02-21 23:08:20 --> Security Class Initialized
DEBUG - 2024-02-21 23:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:08:20 --> Input Class Initialized
INFO - 2024-02-21 23:08:20 --> Language Class Initialized
INFO - 2024-02-21 23:08:20 --> Loader Class Initialized
INFO - 2024-02-21 23:08:20 --> Helper loaded: url_helper
INFO - 2024-02-21 23:08:20 --> Helper loaded: file_helper
INFO - 2024-02-21 23:08:20 --> Helper loaded: form_helper
INFO - 2024-02-21 23:08:20 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:08:20 --> Controller Class Initialized
INFO - 2024-02-21 23:08:20 --> Form Validation Class Initialized
INFO - 2024-02-21 23:08:20 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:08:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:08:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:08:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:08:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:08:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:08:21 --> Config Class Initialized
INFO - 2024-02-21 23:08:21 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:08:21 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:08:21 --> Utf8 Class Initialized
INFO - 2024-02-21 23:08:21 --> URI Class Initialized
INFO - 2024-02-21 23:08:21 --> Router Class Initialized
INFO - 2024-02-21 23:08:21 --> Output Class Initialized
INFO - 2024-02-21 23:08:21 --> Security Class Initialized
DEBUG - 2024-02-21 23:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:08:21 --> Input Class Initialized
INFO - 2024-02-21 23:08:21 --> Language Class Initialized
INFO - 2024-02-21 23:08:21 --> Loader Class Initialized
INFO - 2024-02-21 23:08:21 --> Helper loaded: url_helper
INFO - 2024-02-21 23:08:21 --> Helper loaded: file_helper
INFO - 2024-02-21 23:08:21 --> Helper loaded: form_helper
INFO - 2024-02-21 23:08:21 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:08:21 --> Controller Class Initialized
INFO - 2024-02-21 23:08:21 --> Form Validation Class Initialized
INFO - 2024-02-21 23:08:21 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:08:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:08:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:08:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:08:21 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:08:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:08:24 --> Config Class Initialized
INFO - 2024-02-21 23:08:24 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:08:24 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:08:24 --> Utf8 Class Initialized
INFO - 2024-02-21 23:08:24 --> URI Class Initialized
INFO - 2024-02-21 23:08:24 --> Router Class Initialized
INFO - 2024-02-21 23:08:24 --> Output Class Initialized
INFO - 2024-02-21 23:08:24 --> Security Class Initialized
DEBUG - 2024-02-21 23:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:08:24 --> Input Class Initialized
INFO - 2024-02-21 23:08:24 --> Language Class Initialized
INFO - 2024-02-21 23:08:24 --> Loader Class Initialized
INFO - 2024-02-21 23:08:24 --> Helper loaded: url_helper
INFO - 2024-02-21 23:08:24 --> Helper loaded: file_helper
INFO - 2024-02-21 23:08:24 --> Helper loaded: form_helper
INFO - 2024-02-21 23:08:24 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:08:24 --> Controller Class Initialized
INFO - 2024-02-21 23:08:24 --> Form Validation Class Initialized
INFO - 2024-02-21 23:08:24 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:08:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:08:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:08:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:08:24 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:08:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:08:30 --> Config Class Initialized
INFO - 2024-02-21 23:08:30 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:08:30 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:08:30 --> Utf8 Class Initialized
INFO - 2024-02-21 23:08:30 --> URI Class Initialized
INFO - 2024-02-21 23:08:30 --> Router Class Initialized
INFO - 2024-02-21 23:08:30 --> Output Class Initialized
INFO - 2024-02-21 23:08:30 --> Security Class Initialized
DEBUG - 2024-02-21 23:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:08:30 --> Input Class Initialized
INFO - 2024-02-21 23:08:30 --> Language Class Initialized
INFO - 2024-02-21 23:08:30 --> Loader Class Initialized
INFO - 2024-02-21 23:08:30 --> Helper loaded: url_helper
INFO - 2024-02-21 23:08:30 --> Helper loaded: file_helper
INFO - 2024-02-21 23:08:30 --> Helper loaded: form_helper
INFO - 2024-02-21 23:08:30 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:08:30 --> Controller Class Initialized
INFO - 2024-02-21 23:08:30 --> Form Validation Class Initialized
INFO - 2024-02-21 23:08:30 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:08:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:08:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:08:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:08:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:08:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:08:35 --> Config Class Initialized
INFO - 2024-02-21 23:08:35 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:08:35 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:08:35 --> Utf8 Class Initialized
INFO - 2024-02-21 23:08:35 --> URI Class Initialized
INFO - 2024-02-21 23:08:35 --> Router Class Initialized
INFO - 2024-02-21 23:08:35 --> Output Class Initialized
INFO - 2024-02-21 23:08:35 --> Security Class Initialized
DEBUG - 2024-02-21 23:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:08:35 --> Input Class Initialized
INFO - 2024-02-21 23:08:35 --> Language Class Initialized
INFO - 2024-02-21 23:08:35 --> Loader Class Initialized
INFO - 2024-02-21 23:08:35 --> Helper loaded: url_helper
INFO - 2024-02-21 23:08:35 --> Helper loaded: file_helper
INFO - 2024-02-21 23:08:35 --> Helper loaded: form_helper
INFO - 2024-02-21 23:08:35 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:08:35 --> Controller Class Initialized
INFO - 2024-02-21 23:08:35 --> Form Validation Class Initialized
INFO - 2024-02-21 23:08:35 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:08:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:08:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:08:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:08:35 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:08:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:08:46 --> Config Class Initialized
INFO - 2024-02-21 23:08:46 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:08:46 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:08:46 --> Utf8 Class Initialized
INFO - 2024-02-21 23:08:46 --> URI Class Initialized
INFO - 2024-02-21 23:08:46 --> Router Class Initialized
INFO - 2024-02-21 23:08:46 --> Output Class Initialized
INFO - 2024-02-21 23:08:46 --> Security Class Initialized
DEBUG - 2024-02-21 23:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:08:46 --> Input Class Initialized
INFO - 2024-02-21 23:08:46 --> Language Class Initialized
INFO - 2024-02-21 23:08:46 --> Loader Class Initialized
INFO - 2024-02-21 23:08:46 --> Helper loaded: url_helper
INFO - 2024-02-21 23:08:46 --> Helper loaded: file_helper
INFO - 2024-02-21 23:08:46 --> Helper loaded: form_helper
INFO - 2024-02-21 23:08:46 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:08:46 --> Controller Class Initialized
INFO - 2024-02-21 23:08:46 --> Form Validation Class Initialized
INFO - 2024-02-21 23:08:46 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:08:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:08:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:08:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:08:46 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:08:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:08:50 --> Config Class Initialized
INFO - 2024-02-21 23:08:50 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:08:50 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:08:50 --> Utf8 Class Initialized
INFO - 2024-02-21 23:08:50 --> URI Class Initialized
INFO - 2024-02-21 23:08:50 --> Router Class Initialized
INFO - 2024-02-21 23:08:50 --> Output Class Initialized
INFO - 2024-02-21 23:08:50 --> Security Class Initialized
DEBUG - 2024-02-21 23:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:08:50 --> Input Class Initialized
INFO - 2024-02-21 23:08:50 --> Language Class Initialized
INFO - 2024-02-21 23:08:50 --> Loader Class Initialized
INFO - 2024-02-21 23:08:50 --> Helper loaded: url_helper
INFO - 2024-02-21 23:08:50 --> Helper loaded: file_helper
INFO - 2024-02-21 23:08:50 --> Helper loaded: form_helper
INFO - 2024-02-21 23:08:50 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:08:50 --> Controller Class Initialized
INFO - 2024-02-21 23:08:50 --> Form Validation Class Initialized
INFO - 2024-02-21 23:08:50 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:08:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:08:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:08:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:08:50 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:09:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:09:12 --> Config Class Initialized
INFO - 2024-02-21 23:09:12 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:09:12 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:09:12 --> Utf8 Class Initialized
INFO - 2024-02-21 23:09:12 --> URI Class Initialized
INFO - 2024-02-21 23:09:12 --> Router Class Initialized
INFO - 2024-02-21 23:09:12 --> Output Class Initialized
INFO - 2024-02-21 23:09:12 --> Security Class Initialized
DEBUG - 2024-02-21 23:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:09:12 --> Input Class Initialized
INFO - 2024-02-21 23:09:12 --> Language Class Initialized
INFO - 2024-02-21 23:09:12 --> Loader Class Initialized
INFO - 2024-02-21 23:09:12 --> Helper loaded: url_helper
INFO - 2024-02-21 23:09:12 --> Helper loaded: file_helper
INFO - 2024-02-21 23:09:12 --> Helper loaded: form_helper
INFO - 2024-02-21 23:09:12 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:09:12 --> Controller Class Initialized
INFO - 2024-02-21 23:09:12 --> Form Validation Class Initialized
INFO - 2024-02-21 23:09:12 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:09:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:09:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:09:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:09:12 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:09:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:09:29 --> Config Class Initialized
INFO - 2024-02-21 23:09:29 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:09:29 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:09:29 --> Utf8 Class Initialized
INFO - 2024-02-21 23:09:29 --> URI Class Initialized
INFO - 2024-02-21 23:09:29 --> Router Class Initialized
INFO - 2024-02-21 23:09:29 --> Output Class Initialized
INFO - 2024-02-21 23:09:29 --> Security Class Initialized
DEBUG - 2024-02-21 23:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:09:29 --> Input Class Initialized
INFO - 2024-02-21 23:09:29 --> Language Class Initialized
INFO - 2024-02-21 23:09:29 --> Loader Class Initialized
INFO - 2024-02-21 23:09:29 --> Helper loaded: url_helper
INFO - 2024-02-21 23:09:29 --> Helper loaded: file_helper
INFO - 2024-02-21 23:09:29 --> Helper loaded: form_helper
INFO - 2024-02-21 23:09:29 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:09:29 --> Controller Class Initialized
INFO - 2024-02-21 23:09:29 --> Form Validation Class Initialized
INFO - 2024-02-21 23:09:29 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:09:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:09:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:09:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:09:29 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:09:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:09:51 --> Config Class Initialized
INFO - 2024-02-21 23:09:51 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:09:51 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:09:51 --> Utf8 Class Initialized
INFO - 2024-02-21 23:09:51 --> URI Class Initialized
INFO - 2024-02-21 23:09:51 --> Router Class Initialized
INFO - 2024-02-21 23:09:51 --> Output Class Initialized
INFO - 2024-02-21 23:09:51 --> Security Class Initialized
DEBUG - 2024-02-21 23:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:09:51 --> Input Class Initialized
INFO - 2024-02-21 23:09:51 --> Language Class Initialized
INFO - 2024-02-21 23:09:51 --> Loader Class Initialized
INFO - 2024-02-21 23:09:51 --> Helper loaded: url_helper
INFO - 2024-02-21 23:09:51 --> Helper loaded: file_helper
INFO - 2024-02-21 23:09:51 --> Helper loaded: form_helper
INFO - 2024-02-21 23:09:51 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:09:51 --> Controller Class Initialized
INFO - 2024-02-21 23:09:51 --> Form Validation Class Initialized
INFO - 2024-02-21 23:09:51 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:09:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:09:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:09:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:09:51 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:10:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:10:10 --> Config Class Initialized
INFO - 2024-02-21 23:10:10 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:10:10 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:10:10 --> Utf8 Class Initialized
INFO - 2024-02-21 23:10:10 --> URI Class Initialized
INFO - 2024-02-21 23:10:10 --> Router Class Initialized
INFO - 2024-02-21 23:10:10 --> Output Class Initialized
INFO - 2024-02-21 23:10:10 --> Security Class Initialized
DEBUG - 2024-02-21 23:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:10:10 --> Input Class Initialized
INFO - 2024-02-21 23:10:10 --> Language Class Initialized
INFO - 2024-02-21 23:10:10 --> Loader Class Initialized
INFO - 2024-02-21 23:10:10 --> Helper loaded: url_helper
INFO - 2024-02-21 23:10:10 --> Helper loaded: file_helper
INFO - 2024-02-21 23:10:10 --> Helper loaded: form_helper
INFO - 2024-02-21 23:10:10 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:10:10 --> Controller Class Initialized
INFO - 2024-02-21 23:10:10 --> Form Validation Class Initialized
INFO - 2024-02-21 23:10:10 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:10:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:10:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:10:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:10:10 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:10:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:10:38 --> Config Class Initialized
INFO - 2024-02-21 23:10:38 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:10:38 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:10:38 --> Utf8 Class Initialized
INFO - 2024-02-21 23:10:38 --> URI Class Initialized
INFO - 2024-02-21 23:10:38 --> Router Class Initialized
INFO - 2024-02-21 23:10:38 --> Output Class Initialized
INFO - 2024-02-21 23:10:38 --> Security Class Initialized
DEBUG - 2024-02-21 23:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:10:38 --> Input Class Initialized
INFO - 2024-02-21 23:10:38 --> Language Class Initialized
INFO - 2024-02-21 23:10:38 --> Loader Class Initialized
INFO - 2024-02-21 23:10:38 --> Helper loaded: url_helper
INFO - 2024-02-21 23:10:38 --> Helper loaded: file_helper
INFO - 2024-02-21 23:10:38 --> Helper loaded: form_helper
INFO - 2024-02-21 23:10:38 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:10:38 --> Controller Class Initialized
INFO - 2024-02-21 23:10:38 --> Form Validation Class Initialized
INFO - 2024-02-21 23:10:38 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:10:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:10:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:10:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:10:38 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:10:52 --> Config Class Initialized
INFO - 2024-02-21 23:10:52 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:10:52 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:10:52 --> Utf8 Class Initialized
INFO - 2024-02-21 23:10:52 --> URI Class Initialized
INFO - 2024-02-21 23:10:52 --> Router Class Initialized
INFO - 2024-02-21 23:10:52 --> Output Class Initialized
INFO - 2024-02-21 23:10:52 --> Security Class Initialized
DEBUG - 2024-02-21 23:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:10:52 --> Input Class Initialized
INFO - 2024-02-21 23:10:52 --> Language Class Initialized
INFO - 2024-02-21 23:10:52 --> Loader Class Initialized
INFO - 2024-02-21 23:10:52 --> Helper loaded: url_helper
INFO - 2024-02-21 23:10:52 --> Helper loaded: file_helper
INFO - 2024-02-21 23:10:52 --> Helper loaded: form_helper
INFO - 2024-02-21 23:10:52 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:10:52 --> Controller Class Initialized
INFO - 2024-02-21 23:10:52 --> Form Validation Class Initialized
INFO - 2024-02-21 23:10:52 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:10:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:10:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:10:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:10:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:10:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:10:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:10:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:10:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:10:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:10:52 --> Final output sent to browser
DEBUG - 2024-02-21 23:10:52 --> Total execution time: 0.0324
ERROR - 2024-02-21 23:10:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:10:53 --> Config Class Initialized
INFO - 2024-02-21 23:10:53 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:10:53 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:10:53 --> Utf8 Class Initialized
INFO - 2024-02-21 23:10:53 --> URI Class Initialized
INFO - 2024-02-21 23:10:53 --> Router Class Initialized
INFO - 2024-02-21 23:10:53 --> Output Class Initialized
INFO - 2024-02-21 23:10:53 --> Security Class Initialized
DEBUG - 2024-02-21 23:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:10:53 --> Input Class Initialized
INFO - 2024-02-21 23:10:53 --> Language Class Initialized
INFO - 2024-02-21 23:10:53 --> Loader Class Initialized
INFO - 2024-02-21 23:10:53 --> Helper loaded: url_helper
INFO - 2024-02-21 23:10:53 --> Helper loaded: file_helper
INFO - 2024-02-21 23:10:53 --> Helper loaded: form_helper
INFO - 2024-02-21 23:10:53 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:10:53 --> Controller Class Initialized
INFO - 2024-02-21 23:10:53 --> Form Validation Class Initialized
INFO - 2024-02-21 23:10:53 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:10:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:10:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:10:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:10:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:11:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:11:07 --> Config Class Initialized
INFO - 2024-02-21 23:11:07 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:11:07 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:11:07 --> Utf8 Class Initialized
INFO - 2024-02-21 23:11:07 --> URI Class Initialized
INFO - 2024-02-21 23:11:07 --> Router Class Initialized
INFO - 2024-02-21 23:11:07 --> Output Class Initialized
INFO - 2024-02-21 23:11:07 --> Security Class Initialized
DEBUG - 2024-02-21 23:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:11:07 --> Input Class Initialized
INFO - 2024-02-21 23:11:07 --> Language Class Initialized
INFO - 2024-02-21 23:11:07 --> Loader Class Initialized
INFO - 2024-02-21 23:11:07 --> Helper loaded: url_helper
INFO - 2024-02-21 23:11:07 --> Helper loaded: file_helper
INFO - 2024-02-21 23:11:07 --> Helper loaded: form_helper
INFO - 2024-02-21 23:11:07 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:11:07 --> Controller Class Initialized
INFO - 2024-02-21 23:11:07 --> Form Validation Class Initialized
INFO - 2024-02-21 23:11:07 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:11:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:11:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:11:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:11:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:11:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:11:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:11:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:11:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:11:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:11:07 --> Final output sent to browser
DEBUG - 2024-02-21 23:11:07 --> Total execution time: 0.0340
ERROR - 2024-02-21 23:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:11:08 --> Config Class Initialized
INFO - 2024-02-21 23:11:08 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:11:08 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:11:08 --> Utf8 Class Initialized
INFO - 2024-02-21 23:11:08 --> URI Class Initialized
INFO - 2024-02-21 23:11:08 --> Router Class Initialized
INFO - 2024-02-21 23:11:08 --> Output Class Initialized
INFO - 2024-02-21 23:11:08 --> Security Class Initialized
DEBUG - 2024-02-21 23:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:11:08 --> Input Class Initialized
INFO - 2024-02-21 23:11:08 --> Language Class Initialized
INFO - 2024-02-21 23:11:08 --> Loader Class Initialized
INFO - 2024-02-21 23:11:08 --> Helper loaded: url_helper
INFO - 2024-02-21 23:11:08 --> Helper loaded: file_helper
INFO - 2024-02-21 23:11:08 --> Helper loaded: form_helper
INFO - 2024-02-21 23:11:08 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:11:08 --> Controller Class Initialized
INFO - 2024-02-21 23:11:08 --> Form Validation Class Initialized
INFO - 2024-02-21 23:11:08 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:11:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:11:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:11:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:11:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:12:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:12:15 --> Config Class Initialized
INFO - 2024-02-21 23:12:15 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:12:15 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:12:15 --> Utf8 Class Initialized
INFO - 2024-02-21 23:12:15 --> URI Class Initialized
INFO - 2024-02-21 23:12:15 --> Router Class Initialized
INFO - 2024-02-21 23:12:15 --> Output Class Initialized
INFO - 2024-02-21 23:12:15 --> Security Class Initialized
DEBUG - 2024-02-21 23:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:12:15 --> Input Class Initialized
INFO - 2024-02-21 23:12:15 --> Language Class Initialized
INFO - 2024-02-21 23:12:15 --> Loader Class Initialized
INFO - 2024-02-21 23:12:15 --> Helper loaded: url_helper
INFO - 2024-02-21 23:12:15 --> Helper loaded: file_helper
INFO - 2024-02-21 23:12:15 --> Helper loaded: form_helper
INFO - 2024-02-21 23:12:15 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:12:15 --> Controller Class Initialized
INFO - 2024-02-21 23:12:15 --> Form Validation Class Initialized
INFO - 2024-02-21 23:12:15 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:12:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:12:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:12:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:12:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:12:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:12:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:12:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:12:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:12:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:12:15 --> Final output sent to browser
DEBUG - 2024-02-21 23:12:15 --> Total execution time: 0.0296
ERROR - 2024-02-21 23:12:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:12:16 --> Config Class Initialized
INFO - 2024-02-21 23:12:16 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:12:16 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:12:16 --> Utf8 Class Initialized
INFO - 2024-02-21 23:12:16 --> URI Class Initialized
INFO - 2024-02-21 23:12:16 --> Router Class Initialized
INFO - 2024-02-21 23:12:16 --> Output Class Initialized
INFO - 2024-02-21 23:12:16 --> Security Class Initialized
DEBUG - 2024-02-21 23:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:12:16 --> Input Class Initialized
INFO - 2024-02-21 23:12:16 --> Language Class Initialized
INFO - 2024-02-21 23:12:16 --> Loader Class Initialized
INFO - 2024-02-21 23:12:16 --> Helper loaded: url_helper
INFO - 2024-02-21 23:12:16 --> Helper loaded: file_helper
INFO - 2024-02-21 23:12:16 --> Helper loaded: form_helper
INFO - 2024-02-21 23:12:16 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:12:16 --> Controller Class Initialized
INFO - 2024-02-21 23:12:16 --> Form Validation Class Initialized
INFO - 2024-02-21 23:12:16 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:12:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:12:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:12:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:12:16 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:12:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:12:27 --> Config Class Initialized
INFO - 2024-02-21 23:12:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:12:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:12:27 --> Utf8 Class Initialized
INFO - 2024-02-21 23:12:27 --> URI Class Initialized
INFO - 2024-02-21 23:12:27 --> Router Class Initialized
INFO - 2024-02-21 23:12:27 --> Output Class Initialized
INFO - 2024-02-21 23:12:27 --> Security Class Initialized
DEBUG - 2024-02-21 23:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:12:27 --> Input Class Initialized
INFO - 2024-02-21 23:12:27 --> Language Class Initialized
INFO - 2024-02-21 23:12:27 --> Loader Class Initialized
INFO - 2024-02-21 23:12:27 --> Helper loaded: url_helper
INFO - 2024-02-21 23:12:27 --> Helper loaded: file_helper
INFO - 2024-02-21 23:12:27 --> Helper loaded: form_helper
INFO - 2024-02-21 23:12:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:12:27 --> Controller Class Initialized
INFO - 2024-02-21 23:12:27 --> Form Validation Class Initialized
INFO - 2024-02-21 23:12:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:12:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:12:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:12:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:12:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:12:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:12:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:12:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:12:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:12:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:12:27 --> Final output sent to browser
DEBUG - 2024-02-21 23:12:27 --> Total execution time: 0.0351
ERROR - 2024-02-21 23:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:12:28 --> Config Class Initialized
INFO - 2024-02-21 23:12:28 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:12:28 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:12:28 --> Utf8 Class Initialized
INFO - 2024-02-21 23:12:28 --> URI Class Initialized
INFO - 2024-02-21 23:12:28 --> Router Class Initialized
INFO - 2024-02-21 23:12:28 --> Output Class Initialized
INFO - 2024-02-21 23:12:28 --> Security Class Initialized
DEBUG - 2024-02-21 23:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:12:28 --> Input Class Initialized
INFO - 2024-02-21 23:12:28 --> Language Class Initialized
INFO - 2024-02-21 23:12:28 --> Loader Class Initialized
INFO - 2024-02-21 23:12:28 --> Helper loaded: url_helper
INFO - 2024-02-21 23:12:28 --> Helper loaded: file_helper
INFO - 2024-02-21 23:12:28 --> Helper loaded: form_helper
INFO - 2024-02-21 23:12:28 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:12:28 --> Controller Class Initialized
INFO - 2024-02-21 23:12:28 --> Form Validation Class Initialized
INFO - 2024-02-21 23:12:28 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:12:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:12:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:12:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:12:28 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:12:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:12:46 --> Config Class Initialized
INFO - 2024-02-21 23:12:46 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:12:46 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:12:46 --> Utf8 Class Initialized
INFO - 2024-02-21 23:12:46 --> URI Class Initialized
INFO - 2024-02-21 23:12:46 --> Router Class Initialized
INFO - 2024-02-21 23:12:46 --> Output Class Initialized
INFO - 2024-02-21 23:12:46 --> Security Class Initialized
DEBUG - 2024-02-21 23:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:12:46 --> Input Class Initialized
INFO - 2024-02-21 23:12:46 --> Language Class Initialized
INFO - 2024-02-21 23:12:46 --> Loader Class Initialized
INFO - 2024-02-21 23:12:46 --> Helper loaded: url_helper
INFO - 2024-02-21 23:12:46 --> Helper loaded: file_helper
INFO - 2024-02-21 23:12:46 --> Helper loaded: form_helper
INFO - 2024-02-21 23:12:46 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:12:46 --> Controller Class Initialized
INFO - 2024-02-21 23:12:46 --> Form Validation Class Initialized
INFO - 2024-02-21 23:12:46 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:12:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:12:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:12:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:12:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:12:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:12:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:12:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:12:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:12:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:12:46 --> Final output sent to browser
DEBUG - 2024-02-21 23:12:46 --> Total execution time: 0.0300
ERROR - 2024-02-21 23:12:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:12:47 --> Config Class Initialized
INFO - 2024-02-21 23:12:47 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:12:47 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:12:47 --> Utf8 Class Initialized
INFO - 2024-02-21 23:12:47 --> URI Class Initialized
INFO - 2024-02-21 23:12:47 --> Router Class Initialized
INFO - 2024-02-21 23:12:47 --> Output Class Initialized
INFO - 2024-02-21 23:12:47 --> Security Class Initialized
DEBUG - 2024-02-21 23:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:12:47 --> Input Class Initialized
INFO - 2024-02-21 23:12:47 --> Language Class Initialized
INFO - 2024-02-21 23:12:47 --> Loader Class Initialized
INFO - 2024-02-21 23:12:47 --> Helper loaded: url_helper
INFO - 2024-02-21 23:12:47 --> Helper loaded: file_helper
INFO - 2024-02-21 23:12:47 --> Helper loaded: form_helper
INFO - 2024-02-21 23:12:47 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:12:47 --> Controller Class Initialized
INFO - 2024-02-21 23:12:47 --> Form Validation Class Initialized
INFO - 2024-02-21 23:12:47 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:12:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:12:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:12:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:12:47 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:12:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:12:52 --> Config Class Initialized
INFO - 2024-02-21 23:12:52 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:12:52 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:12:52 --> Utf8 Class Initialized
INFO - 2024-02-21 23:12:52 --> URI Class Initialized
INFO - 2024-02-21 23:12:52 --> Router Class Initialized
INFO - 2024-02-21 23:12:52 --> Output Class Initialized
INFO - 2024-02-21 23:12:52 --> Security Class Initialized
DEBUG - 2024-02-21 23:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:12:52 --> Input Class Initialized
INFO - 2024-02-21 23:12:52 --> Language Class Initialized
INFO - 2024-02-21 23:12:52 --> Loader Class Initialized
INFO - 2024-02-21 23:12:52 --> Helper loaded: url_helper
INFO - 2024-02-21 23:12:52 --> Helper loaded: file_helper
INFO - 2024-02-21 23:12:52 --> Helper loaded: form_helper
INFO - 2024-02-21 23:12:52 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:12:52 --> Controller Class Initialized
INFO - 2024-02-21 23:12:52 --> Form Validation Class Initialized
INFO - 2024-02-21 23:12:52 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:12:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:12:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:12:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:12:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:12:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:12:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:12:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:12:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:12:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:12:52 --> Final output sent to browser
DEBUG - 2024-02-21 23:12:52 --> Total execution time: 0.0314
ERROR - 2024-02-21 23:12:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:12:53 --> Config Class Initialized
INFO - 2024-02-21 23:12:53 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:12:53 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:12:53 --> Utf8 Class Initialized
INFO - 2024-02-21 23:12:53 --> URI Class Initialized
INFO - 2024-02-21 23:12:53 --> Router Class Initialized
INFO - 2024-02-21 23:12:53 --> Output Class Initialized
INFO - 2024-02-21 23:12:53 --> Security Class Initialized
DEBUG - 2024-02-21 23:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:12:53 --> Input Class Initialized
INFO - 2024-02-21 23:12:53 --> Language Class Initialized
INFO - 2024-02-21 23:12:53 --> Loader Class Initialized
INFO - 2024-02-21 23:12:53 --> Helper loaded: url_helper
INFO - 2024-02-21 23:12:53 --> Helper loaded: file_helper
INFO - 2024-02-21 23:12:53 --> Helper loaded: form_helper
INFO - 2024-02-21 23:12:53 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:12:53 --> Controller Class Initialized
INFO - 2024-02-21 23:12:53 --> Form Validation Class Initialized
INFO - 2024-02-21 23:12:53 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:12:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:12:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:12:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:12:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:18:27 --> Config Class Initialized
INFO - 2024-02-21 23:18:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:18:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:18:27 --> Utf8 Class Initialized
INFO - 2024-02-21 23:18:27 --> URI Class Initialized
INFO - 2024-02-21 23:18:27 --> Router Class Initialized
INFO - 2024-02-21 23:18:27 --> Output Class Initialized
INFO - 2024-02-21 23:18:27 --> Security Class Initialized
DEBUG - 2024-02-21 23:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:18:27 --> Input Class Initialized
INFO - 2024-02-21 23:18:27 --> Language Class Initialized
INFO - 2024-02-21 23:18:27 --> Loader Class Initialized
INFO - 2024-02-21 23:18:27 --> Helper loaded: url_helper
INFO - 2024-02-21 23:18:27 --> Helper loaded: file_helper
INFO - 2024-02-21 23:18:27 --> Helper loaded: form_helper
INFO - 2024-02-21 23:18:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:18:27 --> Controller Class Initialized
INFO - 2024-02-21 23:18:27 --> Form Validation Class Initialized
INFO - 2024-02-21 23:18:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:18:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:18:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:18:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:18:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:18:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:18:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:18:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:18:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:18:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:18:27 --> Final output sent to browser
DEBUG - 2024-02-21 23:18:27 --> Total execution time: 0.0337
ERROR - 2024-02-21 23:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:18:27 --> Config Class Initialized
INFO - 2024-02-21 23:18:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:18:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:18:27 --> Utf8 Class Initialized
INFO - 2024-02-21 23:18:27 --> URI Class Initialized
INFO - 2024-02-21 23:18:27 --> Router Class Initialized
INFO - 2024-02-21 23:18:27 --> Output Class Initialized
INFO - 2024-02-21 23:18:27 --> Security Class Initialized
DEBUG - 2024-02-21 23:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:18:27 --> Input Class Initialized
INFO - 2024-02-21 23:18:27 --> Language Class Initialized
INFO - 2024-02-21 23:18:27 --> Loader Class Initialized
INFO - 2024-02-21 23:18:27 --> Helper loaded: url_helper
INFO - 2024-02-21 23:18:27 --> Helper loaded: file_helper
INFO - 2024-02-21 23:18:27 --> Helper loaded: form_helper
INFO - 2024-02-21 23:18:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:18:27 --> Controller Class Initialized
INFO - 2024-02-21 23:18:27 --> Form Validation Class Initialized
INFO - 2024-02-21 23:18:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:18:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:18:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:18:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:18:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:21:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:21:37 --> Config Class Initialized
INFO - 2024-02-21 23:21:37 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:21:37 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:21:37 --> Utf8 Class Initialized
INFO - 2024-02-21 23:21:37 --> URI Class Initialized
INFO - 2024-02-21 23:21:37 --> Router Class Initialized
INFO - 2024-02-21 23:21:37 --> Output Class Initialized
INFO - 2024-02-21 23:21:37 --> Security Class Initialized
DEBUG - 2024-02-21 23:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:21:37 --> Input Class Initialized
INFO - 2024-02-21 23:21:37 --> Language Class Initialized
INFO - 2024-02-21 23:21:37 --> Loader Class Initialized
INFO - 2024-02-21 23:21:37 --> Helper loaded: url_helper
INFO - 2024-02-21 23:21:37 --> Helper loaded: file_helper
INFO - 2024-02-21 23:21:37 --> Helper loaded: form_helper
INFO - 2024-02-21 23:21:37 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:21:37 --> Controller Class Initialized
INFO - 2024-02-21 23:21:37 --> Form Validation Class Initialized
INFO - 2024-02-21 23:21:37 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:21:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:21:37 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:21:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:21:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:21:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:21:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:21:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:21:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:21:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:21:37 --> Final output sent to browser
DEBUG - 2024-02-21 23:21:37 --> Total execution time: 0.0330
ERROR - 2024-02-21 23:21:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:21:37 --> Config Class Initialized
INFO - 2024-02-21 23:21:37 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:21:37 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:21:37 --> Utf8 Class Initialized
INFO - 2024-02-21 23:21:37 --> URI Class Initialized
INFO - 2024-02-21 23:21:37 --> Router Class Initialized
INFO - 2024-02-21 23:21:37 --> Output Class Initialized
INFO - 2024-02-21 23:21:37 --> Security Class Initialized
DEBUG - 2024-02-21 23:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:21:37 --> Input Class Initialized
INFO - 2024-02-21 23:21:37 --> Language Class Initialized
INFO - 2024-02-21 23:21:37 --> Loader Class Initialized
INFO - 2024-02-21 23:21:37 --> Helper loaded: url_helper
INFO - 2024-02-21 23:21:37 --> Helper loaded: file_helper
INFO - 2024-02-21 23:21:37 --> Helper loaded: form_helper
INFO - 2024-02-21 23:21:37 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:21:37 --> Controller Class Initialized
INFO - 2024-02-21 23:21:37 --> Form Validation Class Initialized
INFO - 2024-02-21 23:21:37 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:21:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:21:37 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:21:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:21:37 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:22:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:22:23 --> Config Class Initialized
INFO - 2024-02-21 23:22:23 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:22:23 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:22:23 --> Utf8 Class Initialized
INFO - 2024-02-21 23:22:23 --> URI Class Initialized
INFO - 2024-02-21 23:22:23 --> Router Class Initialized
INFO - 2024-02-21 23:22:23 --> Output Class Initialized
INFO - 2024-02-21 23:22:23 --> Security Class Initialized
DEBUG - 2024-02-21 23:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:22:23 --> Input Class Initialized
INFO - 2024-02-21 23:22:23 --> Language Class Initialized
INFO - 2024-02-21 23:22:23 --> Loader Class Initialized
INFO - 2024-02-21 23:22:23 --> Helper loaded: url_helper
INFO - 2024-02-21 23:22:23 --> Helper loaded: file_helper
INFO - 2024-02-21 23:22:23 --> Helper loaded: form_helper
INFO - 2024-02-21 23:22:23 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:22:23 --> Controller Class Initialized
INFO - 2024-02-21 23:22:23 --> Form Validation Class Initialized
INFO - 2024-02-21 23:22:23 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:22:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:22:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:22:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:22:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:22:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:22:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:22:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:22:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:22:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:22:23 --> Final output sent to browser
DEBUG - 2024-02-21 23:22:23 --> Total execution time: 0.0324
ERROR - 2024-02-21 23:22:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:22:23 --> Config Class Initialized
INFO - 2024-02-21 23:22:23 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:22:23 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:22:23 --> Utf8 Class Initialized
INFO - 2024-02-21 23:22:23 --> URI Class Initialized
INFO - 2024-02-21 23:22:23 --> Router Class Initialized
INFO - 2024-02-21 23:22:23 --> Output Class Initialized
INFO - 2024-02-21 23:22:23 --> Security Class Initialized
DEBUG - 2024-02-21 23:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:22:23 --> Input Class Initialized
INFO - 2024-02-21 23:22:23 --> Language Class Initialized
INFO - 2024-02-21 23:22:23 --> Loader Class Initialized
INFO - 2024-02-21 23:22:23 --> Helper loaded: url_helper
INFO - 2024-02-21 23:22:23 --> Helper loaded: file_helper
INFO - 2024-02-21 23:22:23 --> Helper loaded: form_helper
INFO - 2024-02-21 23:22:23 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:22:23 --> Controller Class Initialized
INFO - 2024-02-21 23:22:23 --> Form Validation Class Initialized
INFO - 2024-02-21 23:22:23 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:22:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:22:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:22:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:22:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:22:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:22:28 --> Config Class Initialized
INFO - 2024-02-21 23:22:28 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:22:28 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:22:28 --> Utf8 Class Initialized
INFO - 2024-02-21 23:22:28 --> URI Class Initialized
INFO - 2024-02-21 23:22:28 --> Router Class Initialized
INFO - 2024-02-21 23:22:28 --> Output Class Initialized
INFO - 2024-02-21 23:22:28 --> Security Class Initialized
DEBUG - 2024-02-21 23:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:22:28 --> Input Class Initialized
INFO - 2024-02-21 23:22:28 --> Language Class Initialized
INFO - 2024-02-21 23:22:28 --> Loader Class Initialized
INFO - 2024-02-21 23:22:28 --> Helper loaded: url_helper
INFO - 2024-02-21 23:22:28 --> Helper loaded: file_helper
INFO - 2024-02-21 23:22:28 --> Helper loaded: form_helper
INFO - 2024-02-21 23:22:28 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:22:28 --> Controller Class Initialized
INFO - 2024-02-21 23:22:28 --> Form Validation Class Initialized
INFO - 2024-02-21 23:22:28 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:22:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:22:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:22:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:22:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:22:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:22:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:22:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:22:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:22:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:22:28 --> Final output sent to browser
DEBUG - 2024-02-21 23:22:28 --> Total execution time: 0.0307
ERROR - 2024-02-21 23:22:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:22:30 --> Config Class Initialized
INFO - 2024-02-21 23:22:30 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:22:30 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:22:30 --> Utf8 Class Initialized
INFO - 2024-02-21 23:22:30 --> URI Class Initialized
INFO - 2024-02-21 23:22:30 --> Router Class Initialized
INFO - 2024-02-21 23:22:30 --> Output Class Initialized
INFO - 2024-02-21 23:22:30 --> Security Class Initialized
DEBUG - 2024-02-21 23:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:22:30 --> Input Class Initialized
INFO - 2024-02-21 23:22:30 --> Language Class Initialized
INFO - 2024-02-21 23:22:30 --> Loader Class Initialized
INFO - 2024-02-21 23:22:30 --> Helper loaded: url_helper
INFO - 2024-02-21 23:22:30 --> Helper loaded: file_helper
INFO - 2024-02-21 23:22:30 --> Helper loaded: form_helper
INFO - 2024-02-21 23:22:30 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:22:30 --> Controller Class Initialized
INFO - 2024-02-21 23:22:30 --> Form Validation Class Initialized
INFO - 2024-02-21 23:22:30 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:22:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:22:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:22:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:22:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:22:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:22:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:22:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:22:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:22:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:22:30 --> Final output sent to browser
DEBUG - 2024-02-21 23:22:30 --> Total execution time: 0.0361
ERROR - 2024-02-21 23:22:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:22:30 --> Config Class Initialized
INFO - 2024-02-21 23:22:30 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:22:30 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:22:30 --> Utf8 Class Initialized
INFO - 2024-02-21 23:22:30 --> URI Class Initialized
INFO - 2024-02-21 23:22:30 --> Router Class Initialized
INFO - 2024-02-21 23:22:30 --> Output Class Initialized
INFO - 2024-02-21 23:22:30 --> Security Class Initialized
DEBUG - 2024-02-21 23:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:22:30 --> Input Class Initialized
INFO - 2024-02-21 23:22:30 --> Language Class Initialized
INFO - 2024-02-21 23:22:30 --> Loader Class Initialized
INFO - 2024-02-21 23:22:30 --> Helper loaded: url_helper
INFO - 2024-02-21 23:22:30 --> Helper loaded: file_helper
INFO - 2024-02-21 23:22:30 --> Helper loaded: form_helper
INFO - 2024-02-21 23:22:30 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:22:30 --> Controller Class Initialized
INFO - 2024-02-21 23:22:30 --> Form Validation Class Initialized
INFO - 2024-02-21 23:22:30 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:22:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:22:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:22:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:22:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:22:49 --> Config Class Initialized
INFO - 2024-02-21 23:22:49 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:22:49 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:22:49 --> Utf8 Class Initialized
INFO - 2024-02-21 23:22:49 --> URI Class Initialized
INFO - 2024-02-21 23:22:49 --> Router Class Initialized
INFO - 2024-02-21 23:22:49 --> Output Class Initialized
INFO - 2024-02-21 23:22:49 --> Security Class Initialized
DEBUG - 2024-02-21 23:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:22:49 --> Input Class Initialized
INFO - 2024-02-21 23:22:49 --> Language Class Initialized
INFO - 2024-02-21 23:22:49 --> Loader Class Initialized
INFO - 2024-02-21 23:22:49 --> Helper loaded: url_helper
INFO - 2024-02-21 23:22:49 --> Helper loaded: file_helper
INFO - 2024-02-21 23:22:49 --> Helper loaded: form_helper
INFO - 2024-02-21 23:22:49 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:22:49 --> Controller Class Initialized
INFO - 2024-02-21 23:22:49 --> Form Validation Class Initialized
INFO - 2024-02-21 23:22:49 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:22:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:22:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:22:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:22:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:22:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:22:49 --> Final output sent to browser
DEBUG - 2024-02-21 23:22:49 --> Total execution time: 0.0371
ERROR - 2024-02-21 23:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:22:49 --> Config Class Initialized
INFO - 2024-02-21 23:22:49 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:22:49 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:22:49 --> Utf8 Class Initialized
INFO - 2024-02-21 23:22:49 --> URI Class Initialized
INFO - 2024-02-21 23:22:49 --> Router Class Initialized
INFO - 2024-02-21 23:22:49 --> Output Class Initialized
INFO - 2024-02-21 23:22:49 --> Security Class Initialized
DEBUG - 2024-02-21 23:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:22:49 --> Input Class Initialized
INFO - 2024-02-21 23:22:49 --> Language Class Initialized
INFO - 2024-02-21 23:22:49 --> Loader Class Initialized
INFO - 2024-02-21 23:22:49 --> Helper loaded: url_helper
INFO - 2024-02-21 23:22:49 --> Helper loaded: file_helper
INFO - 2024-02-21 23:22:49 --> Helper loaded: form_helper
INFO - 2024-02-21 23:22:49 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:22:49 --> Controller Class Initialized
INFO - 2024-02-21 23:22:49 --> Form Validation Class Initialized
INFO - 2024-02-21 23:22:49 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:22:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:22:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:22:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:22:49 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:23:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:23:03 --> Config Class Initialized
INFO - 2024-02-21 23:23:03 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:23:03 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:23:03 --> Utf8 Class Initialized
INFO - 2024-02-21 23:23:03 --> URI Class Initialized
INFO - 2024-02-21 23:23:03 --> Router Class Initialized
INFO - 2024-02-21 23:23:03 --> Output Class Initialized
INFO - 2024-02-21 23:23:03 --> Security Class Initialized
DEBUG - 2024-02-21 23:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:23:03 --> Input Class Initialized
INFO - 2024-02-21 23:23:03 --> Language Class Initialized
INFO - 2024-02-21 23:23:03 --> Loader Class Initialized
INFO - 2024-02-21 23:23:03 --> Helper loaded: url_helper
INFO - 2024-02-21 23:23:03 --> Helper loaded: file_helper
INFO - 2024-02-21 23:23:03 --> Helper loaded: form_helper
INFO - 2024-02-21 23:23:03 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:23:03 --> Controller Class Initialized
INFO - 2024-02-21 23:23:03 --> Form Validation Class Initialized
INFO - 2024-02-21 23:23:03 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:23:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:23:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:23:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:23:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:23:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:23:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:23:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:23:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:23:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:23:03 --> Final output sent to browser
DEBUG - 2024-02-21 23:23:03 --> Total execution time: 0.0316
ERROR - 2024-02-21 23:23:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:23:05 --> Config Class Initialized
INFO - 2024-02-21 23:23:05 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:23:05 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:23:05 --> Utf8 Class Initialized
INFO - 2024-02-21 23:23:05 --> URI Class Initialized
INFO - 2024-02-21 23:23:05 --> Router Class Initialized
INFO - 2024-02-21 23:23:05 --> Output Class Initialized
INFO - 2024-02-21 23:23:05 --> Security Class Initialized
DEBUG - 2024-02-21 23:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:23:05 --> Input Class Initialized
INFO - 2024-02-21 23:23:05 --> Language Class Initialized
INFO - 2024-02-21 23:23:05 --> Loader Class Initialized
INFO - 2024-02-21 23:23:05 --> Helper loaded: url_helper
INFO - 2024-02-21 23:23:05 --> Helper loaded: file_helper
INFO - 2024-02-21 23:23:05 --> Helper loaded: form_helper
INFO - 2024-02-21 23:23:05 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:23:05 --> Controller Class Initialized
INFO - 2024-02-21 23:23:05 --> Form Validation Class Initialized
INFO - 2024-02-21 23:23:05 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:23:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:23:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:23:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:23:05 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:06 --> Config Class Initialized
INFO - 2024-02-21 23:24:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:06 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:06 --> URI Class Initialized
INFO - 2024-02-21 23:24:06 --> Router Class Initialized
INFO - 2024-02-21 23:24:06 --> Output Class Initialized
INFO - 2024-02-21 23:24:06 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:06 --> Input Class Initialized
INFO - 2024-02-21 23:24:06 --> Language Class Initialized
INFO - 2024-02-21 23:24:06 --> Loader Class Initialized
INFO - 2024-02-21 23:24:06 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:06 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:06 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:06 --> Controller Class Initialized
INFO - 2024-02-21 23:24:06 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:24:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:24:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:24:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:24:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:24:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:24:06 --> Final output sent to browser
DEBUG - 2024-02-21 23:24:06 --> Total execution time: 0.0404
ERROR - 2024-02-21 23:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:06 --> Config Class Initialized
INFO - 2024-02-21 23:24:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:06 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:06 --> URI Class Initialized
INFO - 2024-02-21 23:24:06 --> Router Class Initialized
INFO - 2024-02-21 23:24:06 --> Output Class Initialized
INFO - 2024-02-21 23:24:06 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:06 --> Input Class Initialized
INFO - 2024-02-21 23:24:06 --> Language Class Initialized
INFO - 2024-02-21 23:24:06 --> Loader Class Initialized
INFO - 2024-02-21 23:24:06 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:06 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:06 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:06 --> Controller Class Initialized
INFO - 2024-02-21 23:24:06 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:24:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:15 --> Config Class Initialized
INFO - 2024-02-21 23:24:15 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:15 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:15 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:15 --> URI Class Initialized
INFO - 2024-02-21 23:24:15 --> Router Class Initialized
INFO - 2024-02-21 23:24:15 --> Output Class Initialized
INFO - 2024-02-21 23:24:15 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:15 --> Input Class Initialized
INFO - 2024-02-21 23:24:15 --> Language Class Initialized
INFO - 2024-02-21 23:24:15 --> Loader Class Initialized
INFO - 2024-02-21 23:24:15 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:15 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:15 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:15 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:15 --> Controller Class Initialized
INFO - 2024-02-21 23:24:15 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:15 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:15 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:17 --> Config Class Initialized
INFO - 2024-02-21 23:24:17 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:17 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:17 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:17 --> URI Class Initialized
INFO - 2024-02-21 23:24:17 --> Router Class Initialized
INFO - 2024-02-21 23:24:17 --> Output Class Initialized
INFO - 2024-02-21 23:24:17 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:17 --> Input Class Initialized
INFO - 2024-02-21 23:24:17 --> Language Class Initialized
INFO - 2024-02-21 23:24:17 --> Loader Class Initialized
INFO - 2024-02-21 23:24:17 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:17 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:17 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:17 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:17 --> Controller Class Initialized
INFO - 2024-02-21 23:24:17 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:17 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:17 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:24:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:18 --> Config Class Initialized
INFO - 2024-02-21 23:24:18 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:18 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:18 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:18 --> URI Class Initialized
INFO - 2024-02-21 23:24:18 --> Router Class Initialized
INFO - 2024-02-21 23:24:18 --> Output Class Initialized
INFO - 2024-02-21 23:24:18 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:18 --> Input Class Initialized
INFO - 2024-02-21 23:24:18 --> Language Class Initialized
INFO - 2024-02-21 23:24:18 --> Loader Class Initialized
INFO - 2024-02-21 23:24:18 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:18 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:18 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:18 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:18 --> Controller Class Initialized
INFO - 2024-02-21 23:24:18 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:18 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:18 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:24:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:19 --> Config Class Initialized
INFO - 2024-02-21 23:24:19 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:19 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:19 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:19 --> URI Class Initialized
INFO - 2024-02-21 23:24:19 --> Router Class Initialized
INFO - 2024-02-21 23:24:19 --> Output Class Initialized
INFO - 2024-02-21 23:24:19 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:19 --> Input Class Initialized
INFO - 2024-02-21 23:24:19 --> Language Class Initialized
INFO - 2024-02-21 23:24:19 --> Loader Class Initialized
INFO - 2024-02-21 23:24:19 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:19 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:19 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:19 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:19 --> Controller Class Initialized
INFO - 2024-02-21 23:24:19 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:19 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:19 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:21 --> Config Class Initialized
INFO - 2024-02-21 23:24:21 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:21 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:21 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:21 --> URI Class Initialized
INFO - 2024-02-21 23:24:21 --> Router Class Initialized
INFO - 2024-02-21 23:24:21 --> Output Class Initialized
INFO - 2024-02-21 23:24:21 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:21 --> Input Class Initialized
INFO - 2024-02-21 23:24:21 --> Language Class Initialized
INFO - 2024-02-21 23:24:21 --> Loader Class Initialized
INFO - 2024-02-21 23:24:21 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:21 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:21 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:21 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:21 --> Controller Class Initialized
INFO - 2024-02-21 23:24:21 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:21 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:21 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:24:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:22 --> Config Class Initialized
INFO - 2024-02-21 23:24:22 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:22 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:22 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:22 --> URI Class Initialized
INFO - 2024-02-21 23:24:22 --> Router Class Initialized
INFO - 2024-02-21 23:24:22 --> Output Class Initialized
INFO - 2024-02-21 23:24:22 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:22 --> Input Class Initialized
INFO - 2024-02-21 23:24:22 --> Language Class Initialized
INFO - 2024-02-21 23:24:22 --> Loader Class Initialized
INFO - 2024-02-21 23:24:22 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:22 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:22 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:22 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:22 --> Controller Class Initialized
INFO - 2024-02-21 23:24:22 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:22 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:22 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:24:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:26 --> Config Class Initialized
INFO - 2024-02-21 23:24:26 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:26 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:26 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:26 --> URI Class Initialized
INFO - 2024-02-21 23:24:26 --> Router Class Initialized
INFO - 2024-02-21 23:24:26 --> Output Class Initialized
INFO - 2024-02-21 23:24:26 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:26 --> Input Class Initialized
INFO - 2024-02-21 23:24:26 --> Language Class Initialized
INFO - 2024-02-21 23:24:26 --> Loader Class Initialized
INFO - 2024-02-21 23:24:26 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:26 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:26 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:26 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:26 --> Controller Class Initialized
INFO - 2024-02-21 23:24:26 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:26 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:24:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:24:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:24:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:24:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:24:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-21 23:24:26 --> Final output sent to browser
DEBUG - 2024-02-21 23:24:26 --> Total execution time: 0.0373
ERROR - 2024-02-21 23:24:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:26 --> Config Class Initialized
INFO - 2024-02-21 23:24:26 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:26 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:26 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:26 --> URI Class Initialized
INFO - 2024-02-21 23:24:26 --> Router Class Initialized
INFO - 2024-02-21 23:24:26 --> Output Class Initialized
INFO - 2024-02-21 23:24:26 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:26 --> Input Class Initialized
INFO - 2024-02-21 23:24:26 --> Language Class Initialized
INFO - 2024-02-21 23:24:26 --> Loader Class Initialized
INFO - 2024-02-21 23:24:26 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:26 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:26 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:26 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:26 --> Controller Class Initialized
INFO - 2024-02-21 23:24:26 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:26 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:26 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:24:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:33 --> Config Class Initialized
INFO - 2024-02-21 23:24:33 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:33 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:33 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:33 --> URI Class Initialized
INFO - 2024-02-21 23:24:33 --> Router Class Initialized
INFO - 2024-02-21 23:24:33 --> Output Class Initialized
INFO - 2024-02-21 23:24:33 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:33 --> Input Class Initialized
INFO - 2024-02-21 23:24:33 --> Language Class Initialized
INFO - 2024-02-21 23:24:33 --> Loader Class Initialized
INFO - 2024-02-21 23:24:33 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:33 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:33 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:33 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:33 --> Controller Class Initialized
INFO - 2024-02-21 23:24:33 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:33 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:33 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:24:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:42 --> Config Class Initialized
INFO - 2024-02-21 23:24:42 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:42 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:42 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:42 --> URI Class Initialized
INFO - 2024-02-21 23:24:42 --> Router Class Initialized
INFO - 2024-02-21 23:24:42 --> Output Class Initialized
INFO - 2024-02-21 23:24:42 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:42 --> Input Class Initialized
INFO - 2024-02-21 23:24:42 --> Language Class Initialized
INFO - 2024-02-21 23:24:42 --> Loader Class Initialized
INFO - 2024-02-21 23:24:42 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:42 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:42 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:42 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:42 --> Controller Class Initialized
INFO - 2024-02-21 23:24:42 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:42 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:42 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:56 --> Config Class Initialized
INFO - 2024-02-21 23:24:56 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:56 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:56 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:56 --> URI Class Initialized
INFO - 2024-02-21 23:24:56 --> Router Class Initialized
INFO - 2024-02-21 23:24:56 --> Output Class Initialized
INFO - 2024-02-21 23:24:56 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:56 --> Input Class Initialized
INFO - 2024-02-21 23:24:56 --> Language Class Initialized
INFO - 2024-02-21 23:24:56 --> Loader Class Initialized
INFO - 2024-02-21 23:24:56 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:56 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:56 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:56 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:56 --> Controller Class Initialized
INFO - 2024-02-21 23:24:56 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:56 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:56 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:59 --> Config Class Initialized
INFO - 2024-02-21 23:24:59 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:59 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:59 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:59 --> URI Class Initialized
INFO - 2024-02-21 23:24:59 --> Router Class Initialized
INFO - 2024-02-21 23:24:59 --> Output Class Initialized
INFO - 2024-02-21 23:24:59 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:59 --> Input Class Initialized
INFO - 2024-02-21 23:24:59 --> Language Class Initialized
INFO - 2024-02-21 23:24:59 --> Loader Class Initialized
INFO - 2024-02-21 23:24:59 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:59 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:59 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:59 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:59 --> Controller Class Initialized
INFO - 2024-02-21 23:24:59 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:59 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:24:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:24:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:24:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:24:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:24:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-21 23:24:59 --> Final output sent to browser
DEBUG - 2024-02-21 23:24:59 --> Total execution time: 0.0467
ERROR - 2024-02-21 23:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:24:59 --> Config Class Initialized
INFO - 2024-02-21 23:24:59 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:24:59 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:24:59 --> Utf8 Class Initialized
INFO - 2024-02-21 23:24:59 --> URI Class Initialized
INFO - 2024-02-21 23:24:59 --> Router Class Initialized
INFO - 2024-02-21 23:24:59 --> Output Class Initialized
INFO - 2024-02-21 23:24:59 --> Security Class Initialized
DEBUG - 2024-02-21 23:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:24:59 --> Input Class Initialized
INFO - 2024-02-21 23:24:59 --> Language Class Initialized
INFO - 2024-02-21 23:24:59 --> Loader Class Initialized
INFO - 2024-02-21 23:24:59 --> Helper loaded: url_helper
INFO - 2024-02-21 23:24:59 --> Helper loaded: file_helper
INFO - 2024-02-21 23:24:59 --> Helper loaded: form_helper
INFO - 2024-02-21 23:24:59 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:24:59 --> Controller Class Initialized
INFO - 2024-02-21 23:24:59 --> Form Validation Class Initialized
INFO - 2024-02-21 23:24:59 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:24:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:24:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:24:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:24:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:25:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:25:23 --> Config Class Initialized
INFO - 2024-02-21 23:25:23 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:25:23 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:25:23 --> Utf8 Class Initialized
INFO - 2024-02-21 23:25:23 --> URI Class Initialized
INFO - 2024-02-21 23:25:23 --> Router Class Initialized
INFO - 2024-02-21 23:25:23 --> Output Class Initialized
INFO - 2024-02-21 23:25:23 --> Security Class Initialized
DEBUG - 2024-02-21 23:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:25:23 --> Input Class Initialized
INFO - 2024-02-21 23:25:23 --> Language Class Initialized
INFO - 2024-02-21 23:25:23 --> Loader Class Initialized
INFO - 2024-02-21 23:25:23 --> Helper loaded: url_helper
INFO - 2024-02-21 23:25:23 --> Helper loaded: file_helper
INFO - 2024-02-21 23:25:23 --> Helper loaded: form_helper
INFO - 2024-02-21 23:25:23 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:25:23 --> Controller Class Initialized
INFO - 2024-02-21 23:25:23 --> Form Validation Class Initialized
INFO - 2024-02-21 23:25:23 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:25:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:25:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:25:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:25:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:25:27 --> Config Class Initialized
INFO - 2024-02-21 23:25:27 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:25:27 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:25:27 --> Utf8 Class Initialized
INFO - 2024-02-21 23:25:27 --> URI Class Initialized
INFO - 2024-02-21 23:25:27 --> Router Class Initialized
INFO - 2024-02-21 23:25:27 --> Output Class Initialized
INFO - 2024-02-21 23:25:27 --> Security Class Initialized
DEBUG - 2024-02-21 23:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:25:27 --> Input Class Initialized
INFO - 2024-02-21 23:25:27 --> Language Class Initialized
INFO - 2024-02-21 23:25:27 --> Loader Class Initialized
INFO - 2024-02-21 23:25:27 --> Helper loaded: url_helper
INFO - 2024-02-21 23:25:27 --> Helper loaded: file_helper
INFO - 2024-02-21 23:25:27 --> Helper loaded: form_helper
INFO - 2024-02-21 23:25:27 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:25:27 --> Controller Class Initialized
INFO - 2024-02-21 23:25:27 --> Form Validation Class Initialized
INFO - 2024-02-21 23:25:27 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:25:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:25:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:25:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:25:27 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:25:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:25:41 --> Config Class Initialized
INFO - 2024-02-21 23:25:41 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:25:41 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:25:41 --> Utf8 Class Initialized
INFO - 2024-02-21 23:25:41 --> URI Class Initialized
INFO - 2024-02-21 23:25:41 --> Router Class Initialized
INFO - 2024-02-21 23:25:41 --> Output Class Initialized
INFO - 2024-02-21 23:25:41 --> Security Class Initialized
DEBUG - 2024-02-21 23:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:25:41 --> Input Class Initialized
INFO - 2024-02-21 23:25:41 --> Language Class Initialized
INFO - 2024-02-21 23:25:41 --> Loader Class Initialized
INFO - 2024-02-21 23:25:41 --> Helper loaded: url_helper
INFO - 2024-02-21 23:25:41 --> Helper loaded: file_helper
INFO - 2024-02-21 23:25:41 --> Helper loaded: form_helper
INFO - 2024-02-21 23:25:41 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:25:41 --> Controller Class Initialized
INFO - 2024-02-21 23:25:41 --> Form Validation Class Initialized
INFO - 2024-02-21 23:25:41 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:25:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:25:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:25:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:25:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:25:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:25:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:25:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:25:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:25:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-21 23:25:41 --> Final output sent to browser
DEBUG - 2024-02-21 23:25:41 --> Total execution time: 0.0355
ERROR - 2024-02-21 23:25:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:25:42 --> Config Class Initialized
INFO - 2024-02-21 23:25:42 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:25:42 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:25:42 --> Utf8 Class Initialized
INFO - 2024-02-21 23:25:42 --> URI Class Initialized
INFO - 2024-02-21 23:25:42 --> Router Class Initialized
INFO - 2024-02-21 23:25:42 --> Output Class Initialized
INFO - 2024-02-21 23:25:42 --> Security Class Initialized
DEBUG - 2024-02-21 23:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:25:42 --> Input Class Initialized
INFO - 2024-02-21 23:25:42 --> Language Class Initialized
INFO - 2024-02-21 23:25:42 --> Loader Class Initialized
INFO - 2024-02-21 23:25:42 --> Helper loaded: url_helper
INFO - 2024-02-21 23:25:42 --> Helper loaded: file_helper
INFO - 2024-02-21 23:25:42 --> Helper loaded: form_helper
INFO - 2024-02-21 23:25:42 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:25:42 --> Controller Class Initialized
INFO - 2024-02-21 23:25:42 --> Form Validation Class Initialized
INFO - 2024-02-21 23:25:42 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:25:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:25:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:25:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:25:42 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:25:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:25:52 --> Config Class Initialized
INFO - 2024-02-21 23:25:52 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:25:52 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:25:52 --> Utf8 Class Initialized
INFO - 2024-02-21 23:25:52 --> URI Class Initialized
INFO - 2024-02-21 23:25:52 --> Router Class Initialized
INFO - 2024-02-21 23:25:52 --> Output Class Initialized
INFO - 2024-02-21 23:25:52 --> Security Class Initialized
DEBUG - 2024-02-21 23:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:25:52 --> Input Class Initialized
INFO - 2024-02-21 23:25:52 --> Language Class Initialized
INFO - 2024-02-21 23:25:52 --> Loader Class Initialized
INFO - 2024-02-21 23:25:52 --> Helper loaded: url_helper
INFO - 2024-02-21 23:25:52 --> Helper loaded: file_helper
INFO - 2024-02-21 23:25:52 --> Helper loaded: form_helper
INFO - 2024-02-21 23:25:52 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:25:52 --> Controller Class Initialized
INFO - 2024-02-21 23:25:52 --> Form Validation Class Initialized
INFO - 2024-02-21 23:25:52 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:25:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:25:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:25:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:25:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:25:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:25:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:25:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:25:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:25:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-21 23:25:52 --> Final output sent to browser
DEBUG - 2024-02-21 23:25:52 --> Total execution time: 0.0374
ERROR - 2024-02-21 23:25:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:25:52 --> Config Class Initialized
INFO - 2024-02-21 23:25:52 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:25:52 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:25:52 --> Utf8 Class Initialized
INFO - 2024-02-21 23:25:52 --> URI Class Initialized
INFO - 2024-02-21 23:25:52 --> Router Class Initialized
INFO - 2024-02-21 23:25:52 --> Output Class Initialized
INFO - 2024-02-21 23:25:52 --> Security Class Initialized
DEBUG - 2024-02-21 23:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:25:52 --> Input Class Initialized
INFO - 2024-02-21 23:25:52 --> Language Class Initialized
INFO - 2024-02-21 23:25:52 --> Loader Class Initialized
INFO - 2024-02-21 23:25:52 --> Helper loaded: url_helper
INFO - 2024-02-21 23:25:52 --> Helper loaded: file_helper
INFO - 2024-02-21 23:25:52 --> Helper loaded: form_helper
INFO - 2024-02-21 23:25:52 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:25:52 --> Controller Class Initialized
INFO - 2024-02-21 23:25:52 --> Form Validation Class Initialized
INFO - 2024-02-21 23:25:52 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:25:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:25:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:25:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:25:53 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:25:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:25:55 --> Config Class Initialized
INFO - 2024-02-21 23:25:55 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:25:55 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:25:55 --> Utf8 Class Initialized
INFO - 2024-02-21 23:25:55 --> URI Class Initialized
INFO - 2024-02-21 23:25:55 --> Router Class Initialized
INFO - 2024-02-21 23:25:55 --> Output Class Initialized
INFO - 2024-02-21 23:25:55 --> Security Class Initialized
DEBUG - 2024-02-21 23:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:25:55 --> Input Class Initialized
INFO - 2024-02-21 23:25:55 --> Language Class Initialized
INFO - 2024-02-21 23:25:55 --> Loader Class Initialized
INFO - 2024-02-21 23:25:55 --> Helper loaded: url_helper
INFO - 2024-02-21 23:25:55 --> Helper loaded: file_helper
INFO - 2024-02-21 23:25:55 --> Helper loaded: form_helper
INFO - 2024-02-21 23:25:55 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:25:55 --> Controller Class Initialized
INFO - 2024-02-21 23:25:55 --> Form Validation Class Initialized
INFO - 2024-02-21 23:25:55 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:25:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:25:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:25:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:25:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:25:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:25:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:25:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:25:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:25:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-21 23:25:55 --> Final output sent to browser
DEBUG - 2024-02-21 23:25:55 --> Total execution time: 0.0316
ERROR - 2024-02-21 23:25:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:25:56 --> Config Class Initialized
INFO - 2024-02-21 23:25:56 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:25:56 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:25:56 --> Utf8 Class Initialized
INFO - 2024-02-21 23:25:56 --> URI Class Initialized
INFO - 2024-02-21 23:25:56 --> Router Class Initialized
INFO - 2024-02-21 23:25:56 --> Output Class Initialized
INFO - 2024-02-21 23:25:56 --> Security Class Initialized
DEBUG - 2024-02-21 23:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:25:56 --> Input Class Initialized
INFO - 2024-02-21 23:25:56 --> Language Class Initialized
INFO - 2024-02-21 23:25:56 --> Loader Class Initialized
INFO - 2024-02-21 23:25:56 --> Helper loaded: url_helper
INFO - 2024-02-21 23:25:56 --> Helper loaded: file_helper
INFO - 2024-02-21 23:25:56 --> Helper loaded: form_helper
INFO - 2024-02-21 23:25:56 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:25:56 --> Controller Class Initialized
INFO - 2024-02-21 23:25:56 --> Form Validation Class Initialized
INFO - 2024-02-21 23:25:56 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:25:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:25:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:25:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:25:56 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:26:10 --> Config Class Initialized
INFO - 2024-02-21 23:26:10 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:26:10 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:26:10 --> Utf8 Class Initialized
INFO - 2024-02-21 23:26:10 --> URI Class Initialized
INFO - 2024-02-21 23:26:10 --> Router Class Initialized
INFO - 2024-02-21 23:26:10 --> Output Class Initialized
INFO - 2024-02-21 23:26:10 --> Security Class Initialized
DEBUG - 2024-02-21 23:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:26:10 --> Input Class Initialized
INFO - 2024-02-21 23:26:10 --> Language Class Initialized
INFO - 2024-02-21 23:26:10 --> Loader Class Initialized
INFO - 2024-02-21 23:26:10 --> Helper loaded: url_helper
INFO - 2024-02-21 23:26:10 --> Helper loaded: file_helper
INFO - 2024-02-21 23:26:10 --> Helper loaded: form_helper
INFO - 2024-02-21 23:26:10 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:26:10 --> Controller Class Initialized
INFO - 2024-02-21 23:26:10 --> Form Validation Class Initialized
INFO - 2024-02-21 23:26:10 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:26:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:26:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:26:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:26:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:26:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:26:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:26:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:26:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:26:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-21 23:26:10 --> Final output sent to browser
DEBUG - 2024-02-21 23:26:10 --> Total execution time: 0.0298
ERROR - 2024-02-21 23:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:26:11 --> Config Class Initialized
INFO - 2024-02-21 23:26:11 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:26:11 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:26:11 --> Utf8 Class Initialized
INFO - 2024-02-21 23:26:11 --> URI Class Initialized
INFO - 2024-02-21 23:26:11 --> Router Class Initialized
INFO - 2024-02-21 23:26:11 --> Output Class Initialized
INFO - 2024-02-21 23:26:11 --> Security Class Initialized
DEBUG - 2024-02-21 23:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:26:11 --> Input Class Initialized
INFO - 2024-02-21 23:26:11 --> Language Class Initialized
INFO - 2024-02-21 23:26:11 --> Loader Class Initialized
INFO - 2024-02-21 23:26:11 --> Helper loaded: url_helper
INFO - 2024-02-21 23:26:11 --> Helper loaded: file_helper
INFO - 2024-02-21 23:26:11 --> Helper loaded: form_helper
INFO - 2024-02-21 23:26:11 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:26:11 --> Controller Class Initialized
INFO - 2024-02-21 23:26:11 --> Form Validation Class Initialized
INFO - 2024-02-21 23:26:11 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:26:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:26:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:26:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:26:11 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:26:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:26:20 --> Config Class Initialized
INFO - 2024-02-21 23:26:20 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:26:20 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:26:20 --> Utf8 Class Initialized
INFO - 2024-02-21 23:26:20 --> URI Class Initialized
INFO - 2024-02-21 23:26:20 --> Router Class Initialized
INFO - 2024-02-21 23:26:20 --> Output Class Initialized
INFO - 2024-02-21 23:26:20 --> Security Class Initialized
DEBUG - 2024-02-21 23:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:26:20 --> Input Class Initialized
INFO - 2024-02-21 23:26:20 --> Language Class Initialized
INFO - 2024-02-21 23:26:20 --> Loader Class Initialized
INFO - 2024-02-21 23:26:20 --> Helper loaded: url_helper
INFO - 2024-02-21 23:26:20 --> Helper loaded: file_helper
INFO - 2024-02-21 23:26:20 --> Helper loaded: form_helper
INFO - 2024-02-21 23:26:20 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:26:20 --> Controller Class Initialized
INFO - 2024-02-21 23:26:20 --> Form Validation Class Initialized
INFO - 2024-02-21 23:26:20 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:26:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:26:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:26:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:26:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:26:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:26:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:26:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:26:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:26:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-21 23:26:20 --> Final output sent to browser
DEBUG - 2024-02-21 23:26:20 --> Total execution time: 0.0365
ERROR - 2024-02-21 23:26:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:26:20 --> Config Class Initialized
INFO - 2024-02-21 23:26:20 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:26:20 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:26:20 --> Utf8 Class Initialized
INFO - 2024-02-21 23:26:20 --> URI Class Initialized
INFO - 2024-02-21 23:26:20 --> Router Class Initialized
INFO - 2024-02-21 23:26:20 --> Output Class Initialized
INFO - 2024-02-21 23:26:20 --> Security Class Initialized
DEBUG - 2024-02-21 23:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:26:20 --> Input Class Initialized
INFO - 2024-02-21 23:26:20 --> Language Class Initialized
INFO - 2024-02-21 23:26:20 --> Loader Class Initialized
INFO - 2024-02-21 23:26:20 --> Helper loaded: url_helper
INFO - 2024-02-21 23:26:20 --> Helper loaded: file_helper
INFO - 2024-02-21 23:26:20 --> Helper loaded: form_helper
INFO - 2024-02-21 23:26:20 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:26:20 --> Controller Class Initialized
INFO - 2024-02-21 23:26:20 --> Form Validation Class Initialized
INFO - 2024-02-21 23:26:20 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:26:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:26:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:26:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:26:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:26:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:26:44 --> Config Class Initialized
INFO - 2024-02-21 23:26:44 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:26:44 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:26:44 --> Utf8 Class Initialized
INFO - 2024-02-21 23:26:44 --> URI Class Initialized
INFO - 2024-02-21 23:26:44 --> Router Class Initialized
INFO - 2024-02-21 23:26:44 --> Output Class Initialized
INFO - 2024-02-21 23:26:44 --> Security Class Initialized
DEBUG - 2024-02-21 23:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:26:44 --> Input Class Initialized
INFO - 2024-02-21 23:26:44 --> Language Class Initialized
INFO - 2024-02-21 23:26:44 --> Loader Class Initialized
INFO - 2024-02-21 23:26:44 --> Helper loaded: url_helper
INFO - 2024-02-21 23:26:44 --> Helper loaded: file_helper
INFO - 2024-02-21 23:26:44 --> Helper loaded: form_helper
INFO - 2024-02-21 23:26:44 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:26:44 --> Controller Class Initialized
INFO - 2024-02-21 23:26:44 --> Form Validation Class Initialized
INFO - 2024-02-21 23:26:44 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:26:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:26:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:26:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:26:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:26:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:26:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:26:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:26:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:26:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-21 23:26:44 --> Final output sent to browser
DEBUG - 2024-02-21 23:26:44 --> Total execution time: 0.0307
ERROR - 2024-02-21 23:26:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:26:45 --> Config Class Initialized
INFO - 2024-02-21 23:26:45 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:26:45 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:26:45 --> Utf8 Class Initialized
INFO - 2024-02-21 23:26:45 --> URI Class Initialized
INFO - 2024-02-21 23:26:45 --> Router Class Initialized
INFO - 2024-02-21 23:26:45 --> Output Class Initialized
INFO - 2024-02-21 23:26:45 --> Security Class Initialized
DEBUG - 2024-02-21 23:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:26:45 --> Input Class Initialized
INFO - 2024-02-21 23:26:45 --> Language Class Initialized
INFO - 2024-02-21 23:26:45 --> Loader Class Initialized
INFO - 2024-02-21 23:26:45 --> Helper loaded: url_helper
INFO - 2024-02-21 23:26:45 --> Helper loaded: file_helper
INFO - 2024-02-21 23:26:45 --> Helper loaded: form_helper
INFO - 2024-02-21 23:26:45 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:26:45 --> Controller Class Initialized
INFO - 2024-02-21 23:26:45 --> Form Validation Class Initialized
INFO - 2024-02-21 23:26:45 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:26:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:26:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:26:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:26:45 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:26:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:26:54 --> Config Class Initialized
INFO - 2024-02-21 23:26:54 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:26:54 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:26:54 --> Utf8 Class Initialized
INFO - 2024-02-21 23:26:54 --> URI Class Initialized
INFO - 2024-02-21 23:26:54 --> Router Class Initialized
INFO - 2024-02-21 23:26:54 --> Output Class Initialized
INFO - 2024-02-21 23:26:54 --> Security Class Initialized
DEBUG - 2024-02-21 23:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:26:54 --> Input Class Initialized
INFO - 2024-02-21 23:26:54 --> Language Class Initialized
INFO - 2024-02-21 23:26:54 --> Loader Class Initialized
INFO - 2024-02-21 23:26:54 --> Helper loaded: url_helper
INFO - 2024-02-21 23:26:54 --> Helper loaded: file_helper
INFO - 2024-02-21 23:26:54 --> Helper loaded: form_helper
INFO - 2024-02-21 23:26:54 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:26:54 --> Controller Class Initialized
INFO - 2024-02-21 23:26:54 --> Form Validation Class Initialized
INFO - 2024-02-21 23:26:54 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:26:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:26:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:26:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:26:54 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:26:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:26:58 --> Config Class Initialized
INFO - 2024-02-21 23:26:58 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:26:58 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:26:58 --> Utf8 Class Initialized
INFO - 2024-02-21 23:26:58 --> URI Class Initialized
INFO - 2024-02-21 23:26:58 --> Router Class Initialized
INFO - 2024-02-21 23:26:58 --> Output Class Initialized
INFO - 2024-02-21 23:26:58 --> Security Class Initialized
DEBUG - 2024-02-21 23:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:26:58 --> Input Class Initialized
INFO - 2024-02-21 23:26:58 --> Language Class Initialized
INFO - 2024-02-21 23:26:58 --> Loader Class Initialized
INFO - 2024-02-21 23:26:58 --> Helper loaded: url_helper
INFO - 2024-02-21 23:26:58 --> Helper loaded: file_helper
INFO - 2024-02-21 23:26:58 --> Helper loaded: form_helper
INFO - 2024-02-21 23:26:58 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:26:58 --> Controller Class Initialized
INFO - 2024-02-21 23:26:58 --> Form Validation Class Initialized
INFO - 2024-02-21 23:26:58 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:26:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:26:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:26:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:26:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:26:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:26:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:26:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:26:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:26:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:26:58 --> Final output sent to browser
DEBUG - 2024-02-21 23:26:58 --> Total execution time: 0.0314
ERROR - 2024-02-21 23:26:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:26:59 --> Config Class Initialized
INFO - 2024-02-21 23:26:59 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:26:59 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:26:59 --> Utf8 Class Initialized
INFO - 2024-02-21 23:26:59 --> URI Class Initialized
INFO - 2024-02-21 23:26:59 --> Router Class Initialized
INFO - 2024-02-21 23:26:59 --> Output Class Initialized
INFO - 2024-02-21 23:26:59 --> Security Class Initialized
DEBUG - 2024-02-21 23:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:26:59 --> Input Class Initialized
INFO - 2024-02-21 23:26:59 --> Language Class Initialized
INFO - 2024-02-21 23:26:59 --> Loader Class Initialized
INFO - 2024-02-21 23:26:59 --> Helper loaded: url_helper
INFO - 2024-02-21 23:26:59 --> Helper loaded: file_helper
INFO - 2024-02-21 23:26:59 --> Helper loaded: form_helper
INFO - 2024-02-21 23:26:59 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:26:59 --> Controller Class Initialized
INFO - 2024-02-21 23:26:59 --> Form Validation Class Initialized
INFO - 2024-02-21 23:26:59 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:26:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:26:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:26:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:26:59 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:27:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:27:02 --> Config Class Initialized
INFO - 2024-02-21 23:27:02 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:27:02 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:27:02 --> Utf8 Class Initialized
INFO - 2024-02-21 23:27:02 --> URI Class Initialized
INFO - 2024-02-21 23:27:02 --> Router Class Initialized
INFO - 2024-02-21 23:27:02 --> Output Class Initialized
INFO - 2024-02-21 23:27:02 --> Security Class Initialized
DEBUG - 2024-02-21 23:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:27:02 --> Input Class Initialized
INFO - 2024-02-21 23:27:02 --> Language Class Initialized
INFO - 2024-02-21 23:27:02 --> Loader Class Initialized
INFO - 2024-02-21 23:27:02 --> Helper loaded: url_helper
INFO - 2024-02-21 23:27:02 --> Helper loaded: file_helper
INFO - 2024-02-21 23:27:02 --> Helper loaded: form_helper
INFO - 2024-02-21 23:27:02 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:27:02 --> Controller Class Initialized
INFO - 2024-02-21 23:27:02 --> Form Validation Class Initialized
INFO - 2024-02-21 23:27:02 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:27:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:27:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:27:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:27:02 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:27:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:27:06 --> Config Class Initialized
INFO - 2024-02-21 23:27:06 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:27:06 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:27:06 --> Utf8 Class Initialized
INFO - 2024-02-21 23:27:06 --> URI Class Initialized
INFO - 2024-02-21 23:27:06 --> Router Class Initialized
INFO - 2024-02-21 23:27:06 --> Output Class Initialized
INFO - 2024-02-21 23:27:06 --> Security Class Initialized
DEBUG - 2024-02-21 23:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:27:06 --> Input Class Initialized
INFO - 2024-02-21 23:27:06 --> Language Class Initialized
INFO - 2024-02-21 23:27:06 --> Loader Class Initialized
INFO - 2024-02-21 23:27:06 --> Helper loaded: url_helper
INFO - 2024-02-21 23:27:06 --> Helper loaded: file_helper
INFO - 2024-02-21 23:27:06 --> Helper loaded: form_helper
INFO - 2024-02-21 23:27:06 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:27:06 --> Controller Class Initialized
INFO - 2024-02-21 23:27:06 --> Form Validation Class Initialized
INFO - 2024-02-21 23:27:06 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:27:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:27:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:27:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:27:06 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:28:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:28:43 --> Config Class Initialized
INFO - 2024-02-21 23:28:43 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:28:43 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:28:43 --> Utf8 Class Initialized
INFO - 2024-02-21 23:28:43 --> URI Class Initialized
INFO - 2024-02-21 23:28:43 --> Router Class Initialized
INFO - 2024-02-21 23:28:43 --> Output Class Initialized
INFO - 2024-02-21 23:28:43 --> Security Class Initialized
DEBUG - 2024-02-21 23:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:28:43 --> Input Class Initialized
INFO - 2024-02-21 23:28:43 --> Language Class Initialized
INFO - 2024-02-21 23:28:43 --> Loader Class Initialized
INFO - 2024-02-21 23:28:43 --> Helper loaded: url_helper
INFO - 2024-02-21 23:28:43 --> Helper loaded: file_helper
INFO - 2024-02-21 23:28:43 --> Helper loaded: form_helper
INFO - 2024-02-21 23:28:43 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:28:43 --> Controller Class Initialized
INFO - 2024-02-21 23:28:43 --> Form Validation Class Initialized
INFO - 2024-02-21 23:28:43 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:28:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:28:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:28:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:28:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:28:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:28:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:28:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:28:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:28:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-21 23:28:43 --> Final output sent to browser
DEBUG - 2024-02-21 23:28:43 --> Total execution time: 0.0368
ERROR - 2024-02-21 23:28:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:28:43 --> Config Class Initialized
INFO - 2024-02-21 23:28:43 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:28:43 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:28:43 --> Utf8 Class Initialized
INFO - 2024-02-21 23:28:43 --> URI Class Initialized
INFO - 2024-02-21 23:28:43 --> Router Class Initialized
INFO - 2024-02-21 23:28:43 --> Output Class Initialized
INFO - 2024-02-21 23:28:43 --> Security Class Initialized
DEBUG - 2024-02-21 23:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:28:43 --> Input Class Initialized
INFO - 2024-02-21 23:28:43 --> Language Class Initialized
INFO - 2024-02-21 23:28:43 --> Loader Class Initialized
INFO - 2024-02-21 23:28:43 --> Helper loaded: url_helper
INFO - 2024-02-21 23:28:43 --> Helper loaded: file_helper
INFO - 2024-02-21 23:28:43 --> Helper loaded: form_helper
INFO - 2024-02-21 23:28:43 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:28:43 --> Controller Class Initialized
INFO - 2024-02-21 23:28:43 --> Form Validation Class Initialized
INFO - 2024-02-21 23:28:43 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:28:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:28:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:28:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:28:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:28:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:28:50 --> Config Class Initialized
INFO - 2024-02-21 23:28:50 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:28:50 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:28:50 --> Utf8 Class Initialized
INFO - 2024-02-21 23:28:50 --> URI Class Initialized
INFO - 2024-02-21 23:28:50 --> Router Class Initialized
INFO - 2024-02-21 23:28:50 --> Output Class Initialized
INFO - 2024-02-21 23:28:50 --> Security Class Initialized
DEBUG - 2024-02-21 23:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:28:50 --> Input Class Initialized
INFO - 2024-02-21 23:28:50 --> Language Class Initialized
INFO - 2024-02-21 23:28:50 --> Loader Class Initialized
INFO - 2024-02-21 23:28:50 --> Helper loaded: url_helper
INFO - 2024-02-21 23:28:50 --> Helper loaded: file_helper
INFO - 2024-02-21 23:28:50 --> Helper loaded: form_helper
INFO - 2024-02-21 23:28:50 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:28:50 --> Controller Class Initialized
INFO - 2024-02-21 23:28:50 --> Form Validation Class Initialized
INFO - 2024-02-21 23:28:50 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:28:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:28:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:28:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:28:50 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-21 23:50:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-21 23:50:35 --> Config Class Initialized
INFO - 2024-02-21 23:50:35 --> Hooks Class Initialized
DEBUG - 2024-02-21 23:50:35 --> UTF-8 Support Enabled
INFO - 2024-02-21 23:50:35 --> Utf8 Class Initialized
INFO - 2024-02-21 23:50:35 --> URI Class Initialized
INFO - 2024-02-21 23:50:35 --> Router Class Initialized
INFO - 2024-02-21 23:50:35 --> Output Class Initialized
INFO - 2024-02-21 23:50:35 --> Security Class Initialized
DEBUG - 2024-02-21 23:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 23:50:35 --> Input Class Initialized
INFO - 2024-02-21 23:50:35 --> Language Class Initialized
INFO - 2024-02-21 23:50:35 --> Loader Class Initialized
INFO - 2024-02-21 23:50:35 --> Helper loaded: url_helper
INFO - 2024-02-21 23:50:35 --> Helper loaded: file_helper
INFO - 2024-02-21 23:50:35 --> Helper loaded: form_helper
INFO - 2024-02-21 23:50:35 --> Database Driver Class Initialized
DEBUG - 2024-02-21 23:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-21 23:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 23:50:35 --> Controller Class Initialized
INFO - 2024-02-21 23:50:35 --> Form Validation Class Initialized
INFO - 2024-02-21 23:50:35 --> Model "MasterModel" initialized
INFO - 2024-02-21 23:50:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-21 23:50:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-21 23:50:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-21 23:50:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-21 23:50:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-21 23:50:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-21 23:50:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-21 23:50:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-21 23:50:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-21 23:50:35 --> Final output sent to browser
DEBUG - 2024-02-21 23:50:35 --> Total execution time: 0.0587
