<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-09 09:59:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 09:59:12 --> Config Class Initialized
INFO - 2024-02-09 09:59:12 --> Hooks Class Initialized
DEBUG - 2024-02-09 09:59:12 --> UTF-8 Support Enabled
INFO - 2024-02-09 09:59:12 --> Utf8 Class Initialized
INFO - 2024-02-09 09:59:12 --> URI Class Initialized
INFO - 2024-02-09 09:59:12 --> Router Class Initialized
INFO - 2024-02-09 09:59:12 --> Output Class Initialized
INFO - 2024-02-09 09:59:12 --> Security Class Initialized
DEBUG - 2024-02-09 09:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 09:59:12 --> Input Class Initialized
INFO - 2024-02-09 09:59:12 --> Language Class Initialized
INFO - 2024-02-09 09:59:12 --> Loader Class Initialized
INFO - 2024-02-09 09:59:12 --> Helper loaded: url_helper
INFO - 2024-02-09 09:59:12 --> Helper loaded: file_helper
INFO - 2024-02-09 09:59:12 --> Helper loaded: form_helper
INFO - 2024-02-09 09:59:12 --> Database Driver Class Initialized
DEBUG - 2024-02-09 09:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 09:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 09:59:12 --> Controller Class Initialized
INFO - 2024-02-09 09:59:12 --> Model "LoginModel" initialized
INFO - 2024-02-09 09:59:12 --> Form Validation Class Initialized
ERROR - 2024-02-09 09:59:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 09:59:12 --> Config Class Initialized
INFO - 2024-02-09 09:59:12 --> Hooks Class Initialized
DEBUG - 2024-02-09 09:59:12 --> UTF-8 Support Enabled
INFO - 2024-02-09 09:59:12 --> Utf8 Class Initialized
INFO - 2024-02-09 09:59:12 --> URI Class Initialized
INFO - 2024-02-09 09:59:12 --> Router Class Initialized
INFO - 2024-02-09 09:59:12 --> Output Class Initialized
INFO - 2024-02-09 09:59:12 --> Security Class Initialized
DEBUG - 2024-02-09 09:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 09:59:12 --> Input Class Initialized
INFO - 2024-02-09 09:59:12 --> Language Class Initialized
INFO - 2024-02-09 09:59:12 --> Loader Class Initialized
INFO - 2024-02-09 09:59:12 --> Helper loaded: url_helper
INFO - 2024-02-09 09:59:12 --> Helper loaded: file_helper
INFO - 2024-02-09 09:59:12 --> Helper loaded: form_helper
INFO - 2024-02-09 09:59:12 --> Database Driver Class Initialized
DEBUG - 2024-02-09 09:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 09:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 09:59:12 --> Controller Class Initialized
INFO - 2024-02-09 09:59:12 --> Form Validation Class Initialized
INFO - 2024-02-09 09:59:12 --> Model "MasterModel" initialized
INFO - 2024-02-09 09:59:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 09:59:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 09:59:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-09 09:59:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 09:59:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 09:59:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 09:59:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-09 09:59:12 --> Final output sent to browser
DEBUG - 2024-02-09 09:59:12 --> Total execution time: 0.0339
ERROR - 2024-02-09 09:59:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 09:59:17 --> Config Class Initialized
INFO - 2024-02-09 09:59:17 --> Hooks Class Initialized
DEBUG - 2024-02-09 09:59:17 --> UTF-8 Support Enabled
INFO - 2024-02-09 09:59:17 --> Utf8 Class Initialized
INFO - 2024-02-09 09:59:17 --> URI Class Initialized
INFO - 2024-02-09 09:59:17 --> Router Class Initialized
INFO - 2024-02-09 09:59:17 --> Output Class Initialized
INFO - 2024-02-09 09:59:17 --> Security Class Initialized
DEBUG - 2024-02-09 09:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 09:59:17 --> Input Class Initialized
INFO - 2024-02-09 09:59:17 --> Language Class Initialized
INFO - 2024-02-09 09:59:17 --> Loader Class Initialized
INFO - 2024-02-09 09:59:17 --> Helper loaded: url_helper
INFO - 2024-02-09 09:59:17 --> Helper loaded: file_helper
INFO - 2024-02-09 09:59:17 --> Helper loaded: form_helper
INFO - 2024-02-09 09:59:17 --> Database Driver Class Initialized
DEBUG - 2024-02-09 09:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 09:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 09:59:17 --> Controller Class Initialized
INFO - 2024-02-09 09:59:17 --> Form Validation Class Initialized
INFO - 2024-02-09 09:59:17 --> Model "MasterModel" initialized
INFO - 2024-02-09 09:59:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 09:59:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 09:59:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 09:59:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 09:59:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 09:59:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 09:59:17 --> Final output sent to browser
DEBUG - 2024-02-09 09:59:17 --> Total execution time: 0.0343
ERROR - 2024-02-09 09:59:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 09:59:17 --> Config Class Initialized
INFO - 2024-02-09 09:59:17 --> Hooks Class Initialized
DEBUG - 2024-02-09 09:59:17 --> UTF-8 Support Enabled
INFO - 2024-02-09 09:59:17 --> Utf8 Class Initialized
INFO - 2024-02-09 09:59:17 --> URI Class Initialized
INFO - 2024-02-09 09:59:17 --> Router Class Initialized
INFO - 2024-02-09 09:59:17 --> Output Class Initialized
INFO - 2024-02-09 09:59:17 --> Security Class Initialized
DEBUG - 2024-02-09 09:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 09:59:17 --> Input Class Initialized
INFO - 2024-02-09 09:59:17 --> Language Class Initialized
INFO - 2024-02-09 09:59:17 --> Loader Class Initialized
INFO - 2024-02-09 09:59:17 --> Helper loaded: url_helper
INFO - 2024-02-09 09:59:17 --> Helper loaded: file_helper
INFO - 2024-02-09 09:59:17 --> Helper loaded: form_helper
INFO - 2024-02-09 09:59:17 --> Database Driver Class Initialized
DEBUG - 2024-02-09 09:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 09:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 09:59:17 --> Controller Class Initialized
INFO - 2024-02-09 09:59:17 --> Form Validation Class Initialized
INFO - 2024-02-09 09:59:17 --> Model "MasterModel" initialized
INFO - 2024-02-09 09:59:17 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 09:59:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 09:59:26 --> Config Class Initialized
INFO - 2024-02-09 09:59:26 --> Hooks Class Initialized
DEBUG - 2024-02-09 09:59:26 --> UTF-8 Support Enabled
INFO - 2024-02-09 09:59:26 --> Utf8 Class Initialized
INFO - 2024-02-09 09:59:26 --> URI Class Initialized
INFO - 2024-02-09 09:59:26 --> Router Class Initialized
INFO - 2024-02-09 09:59:26 --> Output Class Initialized
INFO - 2024-02-09 09:59:26 --> Security Class Initialized
DEBUG - 2024-02-09 09:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 09:59:26 --> Input Class Initialized
INFO - 2024-02-09 09:59:26 --> Language Class Initialized
INFO - 2024-02-09 09:59:26 --> Loader Class Initialized
INFO - 2024-02-09 09:59:26 --> Helper loaded: url_helper
INFO - 2024-02-09 09:59:26 --> Helper loaded: file_helper
INFO - 2024-02-09 09:59:26 --> Helper loaded: form_helper
INFO - 2024-02-09 09:59:26 --> Database Driver Class Initialized
DEBUG - 2024-02-09 09:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 09:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 09:59:26 --> Controller Class Initialized
INFO - 2024-02-09 09:59:26 --> Form Validation Class Initialized
INFO - 2024-02-09 09:59:26 --> Model "MasterModel" initialized
INFO - 2024-02-09 09:59:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 09:59:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-09 09:59:26 --> Final output sent to browser
DEBUG - 2024-02-09 09:59:26 --> Total execution time: 0.0348
ERROR - 2024-02-09 10:05:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:05:59 --> Config Class Initialized
INFO - 2024-02-09 10:05:59 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:05:59 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:05:59 --> Utf8 Class Initialized
INFO - 2024-02-09 10:05:59 --> URI Class Initialized
INFO - 2024-02-09 10:05:59 --> Router Class Initialized
INFO - 2024-02-09 10:05:59 --> Output Class Initialized
INFO - 2024-02-09 10:05:59 --> Security Class Initialized
DEBUG - 2024-02-09 10:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:05:59 --> Input Class Initialized
INFO - 2024-02-09 10:05:59 --> Language Class Initialized
INFO - 2024-02-09 10:05:59 --> Loader Class Initialized
INFO - 2024-02-09 10:05:59 --> Helper loaded: url_helper
INFO - 2024-02-09 10:05:59 --> Helper loaded: file_helper
INFO - 2024-02-09 10:05:59 --> Helper loaded: form_helper
INFO - 2024-02-09 10:05:59 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:05:59 --> Controller Class Initialized
INFO - 2024-02-09 10:05:59 --> Form Validation Class Initialized
INFO - 2024-02-09 10:05:59 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:05:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:05:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:05:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:05:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:05:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:05:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:05:59 --> Final output sent to browser
DEBUG - 2024-02-09 10:05:59 --> Total execution time: 0.0327
ERROR - 2024-02-09 10:05:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:05:59 --> Config Class Initialized
INFO - 2024-02-09 10:05:59 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:05:59 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:05:59 --> Utf8 Class Initialized
INFO - 2024-02-09 10:05:59 --> URI Class Initialized
INFO - 2024-02-09 10:05:59 --> Router Class Initialized
INFO - 2024-02-09 10:05:59 --> Output Class Initialized
INFO - 2024-02-09 10:05:59 --> Security Class Initialized
DEBUG - 2024-02-09 10:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:05:59 --> Input Class Initialized
INFO - 2024-02-09 10:05:59 --> Language Class Initialized
INFO - 2024-02-09 10:05:59 --> Loader Class Initialized
INFO - 2024-02-09 10:05:59 --> Helper loaded: url_helper
INFO - 2024-02-09 10:05:59 --> Helper loaded: file_helper
INFO - 2024-02-09 10:05:59 --> Helper loaded: form_helper
INFO - 2024-02-09 10:05:59 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:05:59 --> Controller Class Initialized
INFO - 2024-02-09 10:05:59 --> Form Validation Class Initialized
INFO - 2024-02-09 10:05:59 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:05:59 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:06:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:06:11 --> Config Class Initialized
INFO - 2024-02-09 10:06:11 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:06:11 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:06:11 --> Utf8 Class Initialized
INFO - 2024-02-09 10:06:11 --> URI Class Initialized
INFO - 2024-02-09 10:06:11 --> Router Class Initialized
INFO - 2024-02-09 10:06:11 --> Output Class Initialized
INFO - 2024-02-09 10:06:11 --> Security Class Initialized
DEBUG - 2024-02-09 10:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:06:11 --> Input Class Initialized
INFO - 2024-02-09 10:06:11 --> Language Class Initialized
INFO - 2024-02-09 10:06:11 --> Loader Class Initialized
INFO - 2024-02-09 10:06:11 --> Helper loaded: url_helper
INFO - 2024-02-09 10:06:11 --> Helper loaded: file_helper
INFO - 2024-02-09 10:06:11 --> Helper loaded: form_helper
INFO - 2024-02-09 10:06:11 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:06:11 --> Controller Class Initialized
INFO - 2024-02-09 10:06:11 --> Form Validation Class Initialized
INFO - 2024-02-09 10:06:11 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:06:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:06:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:06:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:06:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:06:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:06:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:06:11 --> Final output sent to browser
DEBUG - 2024-02-09 10:06:11 --> Total execution time: 0.0562
ERROR - 2024-02-09 10:06:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:06:12 --> Config Class Initialized
INFO - 2024-02-09 10:06:12 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:06:12 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:06:12 --> Utf8 Class Initialized
INFO - 2024-02-09 10:06:12 --> URI Class Initialized
INFO - 2024-02-09 10:06:12 --> Router Class Initialized
INFO - 2024-02-09 10:06:12 --> Output Class Initialized
INFO - 2024-02-09 10:06:12 --> Security Class Initialized
DEBUG - 2024-02-09 10:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:06:12 --> Input Class Initialized
INFO - 2024-02-09 10:06:12 --> Language Class Initialized
INFO - 2024-02-09 10:06:12 --> Loader Class Initialized
INFO - 2024-02-09 10:06:12 --> Helper loaded: url_helper
INFO - 2024-02-09 10:06:12 --> Helper loaded: file_helper
INFO - 2024-02-09 10:06:12 --> Helper loaded: form_helper
INFO - 2024-02-09 10:06:12 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:06:12 --> Controller Class Initialized
INFO - 2024-02-09 10:06:12 --> Form Validation Class Initialized
INFO - 2024-02-09 10:06:12 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:06:12 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:06:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:06:37 --> Config Class Initialized
INFO - 2024-02-09 10:06:37 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:06:37 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:06:37 --> Utf8 Class Initialized
INFO - 2024-02-09 10:06:37 --> URI Class Initialized
INFO - 2024-02-09 10:06:37 --> Router Class Initialized
INFO - 2024-02-09 10:06:37 --> Output Class Initialized
INFO - 2024-02-09 10:06:37 --> Security Class Initialized
DEBUG - 2024-02-09 10:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:06:37 --> Input Class Initialized
INFO - 2024-02-09 10:06:37 --> Language Class Initialized
INFO - 2024-02-09 10:06:37 --> Loader Class Initialized
INFO - 2024-02-09 10:06:37 --> Helper loaded: url_helper
INFO - 2024-02-09 10:06:37 --> Helper loaded: file_helper
INFO - 2024-02-09 10:06:37 --> Helper loaded: form_helper
INFO - 2024-02-09 10:06:37 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:06:37 --> Controller Class Initialized
INFO - 2024-02-09 10:06:37 --> Form Validation Class Initialized
INFO - 2024-02-09 10:06:37 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:06:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:06:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:06:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:06:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:06:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:06:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:06:37 --> Final output sent to browser
DEBUG - 2024-02-09 10:06:37 --> Total execution time: 0.0364
ERROR - 2024-02-09 10:06:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:06:37 --> Config Class Initialized
INFO - 2024-02-09 10:06:37 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:06:37 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:06:37 --> Utf8 Class Initialized
INFO - 2024-02-09 10:06:37 --> URI Class Initialized
INFO - 2024-02-09 10:06:37 --> Router Class Initialized
INFO - 2024-02-09 10:06:37 --> Output Class Initialized
INFO - 2024-02-09 10:06:37 --> Security Class Initialized
DEBUG - 2024-02-09 10:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:06:37 --> Input Class Initialized
INFO - 2024-02-09 10:06:37 --> Language Class Initialized
INFO - 2024-02-09 10:06:37 --> Loader Class Initialized
INFO - 2024-02-09 10:06:37 --> Helper loaded: url_helper
INFO - 2024-02-09 10:06:37 --> Helper loaded: file_helper
INFO - 2024-02-09 10:06:37 --> Helper loaded: form_helper
INFO - 2024-02-09 10:06:37 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:06:37 --> Controller Class Initialized
INFO - 2024-02-09 10:06:37 --> Form Validation Class Initialized
INFO - 2024-02-09 10:06:37 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:06:37 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:06:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:06:39 --> Config Class Initialized
INFO - 2024-02-09 10:06:39 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:06:39 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:06:39 --> Utf8 Class Initialized
INFO - 2024-02-09 10:06:39 --> URI Class Initialized
INFO - 2024-02-09 10:06:39 --> Router Class Initialized
INFO - 2024-02-09 10:06:39 --> Output Class Initialized
INFO - 2024-02-09 10:06:39 --> Security Class Initialized
DEBUG - 2024-02-09 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:06:39 --> Input Class Initialized
INFO - 2024-02-09 10:06:39 --> Language Class Initialized
INFO - 2024-02-09 10:06:39 --> Loader Class Initialized
INFO - 2024-02-09 10:06:39 --> Helper loaded: url_helper
INFO - 2024-02-09 10:06:39 --> Helper loaded: file_helper
INFO - 2024-02-09 10:06:39 --> Helper loaded: form_helper
INFO - 2024-02-09 10:06:39 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:06:39 --> Controller Class Initialized
INFO - 2024-02-09 10:06:39 --> Form Validation Class Initialized
INFO - 2024-02-09 10:06:39 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:06:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:06:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:06:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:06:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:06:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:06:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:06:39 --> Final output sent to browser
DEBUG - 2024-02-09 10:06:39 --> Total execution time: 0.0349
ERROR - 2024-02-09 10:06:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:06:39 --> Config Class Initialized
INFO - 2024-02-09 10:06:39 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:06:39 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:06:39 --> Utf8 Class Initialized
INFO - 2024-02-09 10:06:39 --> URI Class Initialized
INFO - 2024-02-09 10:06:39 --> Router Class Initialized
INFO - 2024-02-09 10:06:39 --> Output Class Initialized
INFO - 2024-02-09 10:06:39 --> Security Class Initialized
DEBUG - 2024-02-09 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:06:39 --> Input Class Initialized
INFO - 2024-02-09 10:06:39 --> Language Class Initialized
INFO - 2024-02-09 10:06:39 --> Loader Class Initialized
INFO - 2024-02-09 10:06:39 --> Helper loaded: url_helper
INFO - 2024-02-09 10:06:39 --> Helper loaded: file_helper
INFO - 2024-02-09 10:06:39 --> Helper loaded: form_helper
INFO - 2024-02-09 10:06:39 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:06:39 --> Controller Class Initialized
INFO - 2024-02-09 10:06:39 --> Form Validation Class Initialized
INFO - 2024-02-09 10:06:39 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:06:39 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:07:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:07:45 --> Config Class Initialized
INFO - 2024-02-09 10:07:45 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:07:45 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:07:45 --> Utf8 Class Initialized
INFO - 2024-02-09 10:07:45 --> URI Class Initialized
INFO - 2024-02-09 10:07:45 --> Router Class Initialized
INFO - 2024-02-09 10:07:45 --> Output Class Initialized
INFO - 2024-02-09 10:07:45 --> Security Class Initialized
DEBUG - 2024-02-09 10:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:07:45 --> Input Class Initialized
INFO - 2024-02-09 10:07:45 --> Language Class Initialized
INFO - 2024-02-09 10:07:45 --> Loader Class Initialized
INFO - 2024-02-09 10:07:45 --> Helper loaded: url_helper
INFO - 2024-02-09 10:07:45 --> Helper loaded: file_helper
INFO - 2024-02-09 10:07:45 --> Helper loaded: form_helper
INFO - 2024-02-09 10:07:45 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:07:45 --> Controller Class Initialized
INFO - 2024-02-09 10:07:45 --> Form Validation Class Initialized
INFO - 2024-02-09 10:07:45 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:07:45 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:07:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:07:50 --> Config Class Initialized
INFO - 2024-02-09 10:07:50 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:07:50 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:07:50 --> Utf8 Class Initialized
INFO - 2024-02-09 10:07:50 --> URI Class Initialized
INFO - 2024-02-09 10:07:50 --> Router Class Initialized
INFO - 2024-02-09 10:07:50 --> Output Class Initialized
INFO - 2024-02-09 10:07:50 --> Security Class Initialized
DEBUG - 2024-02-09 10:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:07:50 --> Input Class Initialized
INFO - 2024-02-09 10:07:50 --> Language Class Initialized
INFO - 2024-02-09 10:07:50 --> Loader Class Initialized
INFO - 2024-02-09 10:07:50 --> Helper loaded: url_helper
INFO - 2024-02-09 10:07:50 --> Helper loaded: file_helper
INFO - 2024-02-09 10:07:50 --> Helper loaded: form_helper
INFO - 2024-02-09 10:07:50 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:07:50 --> Controller Class Initialized
INFO - 2024-02-09 10:07:50 --> Form Validation Class Initialized
INFO - 2024-02-09 10:07:50 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:07:50 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:07:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:07:53 --> Config Class Initialized
INFO - 2024-02-09 10:07:53 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:07:53 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:07:53 --> Utf8 Class Initialized
INFO - 2024-02-09 10:07:53 --> URI Class Initialized
INFO - 2024-02-09 10:07:53 --> Router Class Initialized
INFO - 2024-02-09 10:07:53 --> Output Class Initialized
INFO - 2024-02-09 10:07:53 --> Security Class Initialized
DEBUG - 2024-02-09 10:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:07:53 --> Input Class Initialized
INFO - 2024-02-09 10:07:53 --> Language Class Initialized
INFO - 2024-02-09 10:07:53 --> Loader Class Initialized
INFO - 2024-02-09 10:07:53 --> Helper loaded: url_helper
INFO - 2024-02-09 10:07:53 --> Helper loaded: file_helper
INFO - 2024-02-09 10:07:54 --> Helper loaded: form_helper
INFO - 2024-02-09 10:07:54 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:07:54 --> Controller Class Initialized
INFO - 2024-02-09 10:07:54 --> Form Validation Class Initialized
INFO - 2024-02-09 10:07:54 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:07:54 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:09:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:09:07 --> Config Class Initialized
INFO - 2024-02-09 10:09:07 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:09:07 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:09:07 --> Utf8 Class Initialized
INFO - 2024-02-09 10:09:07 --> URI Class Initialized
INFO - 2024-02-09 10:09:07 --> Router Class Initialized
INFO - 2024-02-09 10:09:07 --> Output Class Initialized
INFO - 2024-02-09 10:09:07 --> Security Class Initialized
DEBUG - 2024-02-09 10:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:09:07 --> Input Class Initialized
INFO - 2024-02-09 10:09:07 --> Language Class Initialized
INFO - 2024-02-09 10:09:07 --> Loader Class Initialized
INFO - 2024-02-09 10:09:07 --> Helper loaded: url_helper
INFO - 2024-02-09 10:09:07 --> Helper loaded: file_helper
INFO - 2024-02-09 10:09:07 --> Helper loaded: form_helper
INFO - 2024-02-09 10:09:07 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:09:07 --> Controller Class Initialized
INFO - 2024-02-09 10:09:07 --> Form Validation Class Initialized
INFO - 2024-02-09 10:09:07 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:09:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:09:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:09:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:09:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:09:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:09:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:09:07 --> Final output sent to browser
DEBUG - 2024-02-09 10:09:07 --> Total execution time: 0.0263
ERROR - 2024-02-09 10:09:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:09:07 --> Config Class Initialized
INFO - 2024-02-09 10:09:07 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:09:07 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:09:07 --> Utf8 Class Initialized
INFO - 2024-02-09 10:09:07 --> URI Class Initialized
INFO - 2024-02-09 10:09:07 --> Router Class Initialized
INFO - 2024-02-09 10:09:07 --> Output Class Initialized
INFO - 2024-02-09 10:09:07 --> Security Class Initialized
DEBUG - 2024-02-09 10:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:09:07 --> Input Class Initialized
INFO - 2024-02-09 10:09:07 --> Language Class Initialized
INFO - 2024-02-09 10:09:07 --> Loader Class Initialized
INFO - 2024-02-09 10:09:07 --> Helper loaded: url_helper
INFO - 2024-02-09 10:09:07 --> Helper loaded: file_helper
INFO - 2024-02-09 10:09:07 --> Helper loaded: form_helper
INFO - 2024-02-09 10:09:07 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:09:07 --> Controller Class Initialized
INFO - 2024-02-09 10:09:07 --> Form Validation Class Initialized
INFO - 2024-02-09 10:09:07 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:09:07 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:09:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:09:59 --> Config Class Initialized
INFO - 2024-02-09 10:09:59 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:09:59 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:09:59 --> Utf8 Class Initialized
INFO - 2024-02-09 10:09:59 --> URI Class Initialized
INFO - 2024-02-09 10:09:59 --> Router Class Initialized
INFO - 2024-02-09 10:09:59 --> Output Class Initialized
INFO - 2024-02-09 10:09:59 --> Security Class Initialized
DEBUG - 2024-02-09 10:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:09:59 --> Input Class Initialized
INFO - 2024-02-09 10:09:59 --> Language Class Initialized
INFO - 2024-02-09 10:09:59 --> Loader Class Initialized
INFO - 2024-02-09 10:09:59 --> Helper loaded: url_helper
INFO - 2024-02-09 10:09:59 --> Helper loaded: file_helper
INFO - 2024-02-09 10:09:59 --> Helper loaded: form_helper
INFO - 2024-02-09 10:09:59 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:09:59 --> Controller Class Initialized
INFO - 2024-02-09 10:09:59 --> Form Validation Class Initialized
INFO - 2024-02-09 10:09:59 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:09:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:09:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:09:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:09:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:09:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:09:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:09:59 --> Final output sent to browser
DEBUG - 2024-02-09 10:09:59 --> Total execution time: 0.0306
ERROR - 2024-02-09 10:10:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:10:00 --> Config Class Initialized
INFO - 2024-02-09 10:10:00 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:10:00 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:10:00 --> Utf8 Class Initialized
INFO - 2024-02-09 10:10:00 --> URI Class Initialized
INFO - 2024-02-09 10:10:00 --> Router Class Initialized
INFO - 2024-02-09 10:10:00 --> Output Class Initialized
INFO - 2024-02-09 10:10:00 --> Security Class Initialized
DEBUG - 2024-02-09 10:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:10:00 --> Input Class Initialized
INFO - 2024-02-09 10:10:00 --> Language Class Initialized
INFO - 2024-02-09 10:10:00 --> Loader Class Initialized
INFO - 2024-02-09 10:10:00 --> Helper loaded: url_helper
INFO - 2024-02-09 10:10:00 --> Helper loaded: file_helper
INFO - 2024-02-09 10:10:00 --> Helper loaded: form_helper
INFO - 2024-02-09 10:10:00 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:10:00 --> Controller Class Initialized
INFO - 2024-02-09 10:10:00 --> Form Validation Class Initialized
INFO - 2024-02-09 10:10:00 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:10:00 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:13:08 --> Config Class Initialized
INFO - 2024-02-09 10:13:08 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:13:08 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:13:08 --> Utf8 Class Initialized
INFO - 2024-02-09 10:13:08 --> URI Class Initialized
INFO - 2024-02-09 10:13:08 --> Router Class Initialized
INFO - 2024-02-09 10:13:08 --> Output Class Initialized
INFO - 2024-02-09 10:13:08 --> Security Class Initialized
DEBUG - 2024-02-09 10:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:13:08 --> Input Class Initialized
INFO - 2024-02-09 10:13:08 --> Language Class Initialized
INFO - 2024-02-09 10:13:08 --> Loader Class Initialized
INFO - 2024-02-09 10:13:08 --> Helper loaded: url_helper
INFO - 2024-02-09 10:13:08 --> Helper loaded: file_helper
INFO - 2024-02-09 10:13:08 --> Helper loaded: form_helper
INFO - 2024-02-09 10:13:08 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:13:08 --> Controller Class Initialized
INFO - 2024-02-09 10:13:08 --> Form Validation Class Initialized
INFO - 2024-02-09 10:13:08 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:13:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:13:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:13:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:13:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:13:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:13:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:13:08 --> Final output sent to browser
DEBUG - 2024-02-09 10:13:08 --> Total execution time: 0.0354
ERROR - 2024-02-09 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:13:08 --> Config Class Initialized
INFO - 2024-02-09 10:13:08 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:13:08 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:13:08 --> Utf8 Class Initialized
INFO - 2024-02-09 10:13:08 --> URI Class Initialized
INFO - 2024-02-09 10:13:08 --> Router Class Initialized
INFO - 2024-02-09 10:13:08 --> Output Class Initialized
INFO - 2024-02-09 10:13:08 --> Security Class Initialized
DEBUG - 2024-02-09 10:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:13:08 --> Input Class Initialized
INFO - 2024-02-09 10:13:08 --> Language Class Initialized
INFO - 2024-02-09 10:13:08 --> Loader Class Initialized
INFO - 2024-02-09 10:13:08 --> Helper loaded: url_helper
INFO - 2024-02-09 10:13:08 --> Helper loaded: file_helper
INFO - 2024-02-09 10:13:08 --> Helper loaded: form_helper
INFO - 2024-02-09 10:13:08 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:13:08 --> Controller Class Initialized
INFO - 2024-02-09 10:13:08 --> Form Validation Class Initialized
INFO - 2024-02-09 10:13:08 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:13:08 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:15:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:15:41 --> Config Class Initialized
INFO - 2024-02-09 10:15:41 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:15:41 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:15:41 --> Utf8 Class Initialized
INFO - 2024-02-09 10:15:41 --> URI Class Initialized
INFO - 2024-02-09 10:15:41 --> Router Class Initialized
INFO - 2024-02-09 10:15:41 --> Output Class Initialized
INFO - 2024-02-09 10:15:41 --> Security Class Initialized
DEBUG - 2024-02-09 10:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:15:41 --> Input Class Initialized
INFO - 2024-02-09 10:15:41 --> Language Class Initialized
INFO - 2024-02-09 10:15:41 --> Loader Class Initialized
INFO - 2024-02-09 10:15:41 --> Helper loaded: url_helper
INFO - 2024-02-09 10:15:41 --> Helper loaded: file_helper
INFO - 2024-02-09 10:15:41 --> Helper loaded: form_helper
INFO - 2024-02-09 10:15:41 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:15:41 --> Controller Class Initialized
INFO - 2024-02-09 10:15:41 --> Form Validation Class Initialized
INFO - 2024-02-09 10:15:41 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:15:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:15:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:15:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:15:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:15:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:15:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:15:41 --> Final output sent to browser
DEBUG - 2024-02-09 10:15:41 --> Total execution time: 0.0309
ERROR - 2024-02-09 10:15:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:15:42 --> Config Class Initialized
INFO - 2024-02-09 10:15:42 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:15:42 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:15:42 --> Utf8 Class Initialized
INFO - 2024-02-09 10:15:42 --> URI Class Initialized
INFO - 2024-02-09 10:15:42 --> Router Class Initialized
INFO - 2024-02-09 10:15:42 --> Output Class Initialized
INFO - 2024-02-09 10:15:42 --> Security Class Initialized
DEBUG - 2024-02-09 10:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:15:42 --> Input Class Initialized
INFO - 2024-02-09 10:15:42 --> Language Class Initialized
INFO - 2024-02-09 10:15:42 --> Loader Class Initialized
INFO - 2024-02-09 10:15:42 --> Helper loaded: url_helper
INFO - 2024-02-09 10:15:42 --> Helper loaded: file_helper
INFO - 2024-02-09 10:15:42 --> Helper loaded: form_helper
INFO - 2024-02-09 10:15:42 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:15:42 --> Controller Class Initialized
INFO - 2024-02-09 10:15:42 --> Form Validation Class Initialized
INFO - 2024-02-09 10:15:42 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:15:42 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:20:23 --> Config Class Initialized
INFO - 2024-02-09 10:20:23 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:20:23 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:20:23 --> Utf8 Class Initialized
INFO - 2024-02-09 10:20:23 --> URI Class Initialized
INFO - 2024-02-09 10:20:23 --> Router Class Initialized
INFO - 2024-02-09 10:20:23 --> Output Class Initialized
INFO - 2024-02-09 10:20:23 --> Security Class Initialized
DEBUG - 2024-02-09 10:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:20:23 --> Input Class Initialized
INFO - 2024-02-09 10:20:23 --> Language Class Initialized
INFO - 2024-02-09 10:20:23 --> Loader Class Initialized
INFO - 2024-02-09 10:20:23 --> Helper loaded: url_helper
INFO - 2024-02-09 10:20:23 --> Helper loaded: file_helper
INFO - 2024-02-09 10:20:23 --> Helper loaded: form_helper
INFO - 2024-02-09 10:20:23 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:20:23 --> Controller Class Initialized
INFO - 2024-02-09 10:20:23 --> Form Validation Class Initialized
INFO - 2024-02-09 10:20:23 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:20:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:20:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:20:23 --> Final output sent to browser
DEBUG - 2024-02-09 10:20:23 --> Total execution time: 0.0289
ERROR - 2024-02-09 10:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:20:23 --> Config Class Initialized
INFO - 2024-02-09 10:20:23 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:20:23 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:20:23 --> Utf8 Class Initialized
INFO - 2024-02-09 10:20:23 --> URI Class Initialized
INFO - 2024-02-09 10:20:23 --> Router Class Initialized
INFO - 2024-02-09 10:20:23 --> Output Class Initialized
INFO - 2024-02-09 10:20:23 --> Security Class Initialized
DEBUG - 2024-02-09 10:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:20:23 --> Input Class Initialized
INFO - 2024-02-09 10:20:23 --> Language Class Initialized
INFO - 2024-02-09 10:20:23 --> Loader Class Initialized
INFO - 2024-02-09 10:20:23 --> Helper loaded: url_helper
INFO - 2024-02-09 10:20:23 --> Helper loaded: file_helper
INFO - 2024-02-09 10:20:23 --> Helper loaded: form_helper
INFO - 2024-02-09 10:20:23 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:20:23 --> Controller Class Initialized
INFO - 2024-02-09 10:20:23 --> Form Validation Class Initialized
INFO - 2024-02-09 10:20:23 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:20:23 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:21:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:21:00 --> Config Class Initialized
INFO - 2024-02-09 10:21:00 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:21:00 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:21:00 --> Utf8 Class Initialized
INFO - 2024-02-09 10:21:00 --> URI Class Initialized
INFO - 2024-02-09 10:21:00 --> Router Class Initialized
INFO - 2024-02-09 10:21:00 --> Output Class Initialized
INFO - 2024-02-09 10:21:00 --> Security Class Initialized
DEBUG - 2024-02-09 10:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:21:00 --> Input Class Initialized
INFO - 2024-02-09 10:21:00 --> Language Class Initialized
INFO - 2024-02-09 10:21:00 --> Loader Class Initialized
INFO - 2024-02-09 10:21:00 --> Helper loaded: url_helper
INFO - 2024-02-09 10:21:00 --> Helper loaded: file_helper
INFO - 2024-02-09 10:21:00 --> Helper loaded: form_helper
INFO - 2024-02-09 10:21:00 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:21:00 --> Controller Class Initialized
INFO - 2024-02-09 10:21:00 --> Form Validation Class Initialized
INFO - 2024-02-09 10:21:00 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:21:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:21:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:21:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:21:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:21:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:21:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:21:00 --> Final output sent to browser
DEBUG - 2024-02-09 10:21:00 --> Total execution time: 0.0364
ERROR - 2024-02-09 10:21:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:21:01 --> Config Class Initialized
INFO - 2024-02-09 10:21:01 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:21:01 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:21:01 --> Utf8 Class Initialized
INFO - 2024-02-09 10:21:01 --> URI Class Initialized
INFO - 2024-02-09 10:21:01 --> Router Class Initialized
INFO - 2024-02-09 10:21:01 --> Output Class Initialized
INFO - 2024-02-09 10:21:01 --> Security Class Initialized
DEBUG - 2024-02-09 10:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:21:01 --> Input Class Initialized
INFO - 2024-02-09 10:21:01 --> Language Class Initialized
INFO - 2024-02-09 10:21:01 --> Loader Class Initialized
INFO - 2024-02-09 10:21:01 --> Helper loaded: url_helper
INFO - 2024-02-09 10:21:01 --> Helper loaded: file_helper
INFO - 2024-02-09 10:21:01 --> Helper loaded: form_helper
INFO - 2024-02-09 10:21:01 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:21:01 --> Controller Class Initialized
INFO - 2024-02-09 10:21:01 --> Form Validation Class Initialized
INFO - 2024-02-09 10:21:01 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:21:01 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:22:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:22:15 --> Config Class Initialized
INFO - 2024-02-09 10:22:15 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:22:15 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:22:15 --> Utf8 Class Initialized
INFO - 2024-02-09 10:22:15 --> URI Class Initialized
INFO - 2024-02-09 10:22:15 --> Router Class Initialized
INFO - 2024-02-09 10:22:15 --> Output Class Initialized
INFO - 2024-02-09 10:22:15 --> Security Class Initialized
DEBUG - 2024-02-09 10:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:22:15 --> Input Class Initialized
INFO - 2024-02-09 10:22:15 --> Language Class Initialized
INFO - 2024-02-09 10:22:15 --> Loader Class Initialized
INFO - 2024-02-09 10:22:15 --> Helper loaded: url_helper
INFO - 2024-02-09 10:22:15 --> Helper loaded: file_helper
INFO - 2024-02-09 10:22:15 --> Helper loaded: form_helper
INFO - 2024-02-09 10:22:15 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:22:15 --> Controller Class Initialized
INFO - 2024-02-09 10:22:15 --> Form Validation Class Initialized
INFO - 2024-02-09 10:22:15 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:22:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:22:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:22:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:22:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:22:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:22:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:22:15 --> Final output sent to browser
DEBUG - 2024-02-09 10:22:15 --> Total execution time: 0.0270
ERROR - 2024-02-09 10:22:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:22:15 --> Config Class Initialized
INFO - 2024-02-09 10:22:15 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:22:15 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:22:15 --> Utf8 Class Initialized
INFO - 2024-02-09 10:22:15 --> URI Class Initialized
INFO - 2024-02-09 10:22:15 --> Router Class Initialized
INFO - 2024-02-09 10:22:15 --> Output Class Initialized
INFO - 2024-02-09 10:22:15 --> Security Class Initialized
DEBUG - 2024-02-09 10:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:22:15 --> Input Class Initialized
INFO - 2024-02-09 10:22:15 --> Language Class Initialized
INFO - 2024-02-09 10:22:15 --> Loader Class Initialized
INFO - 2024-02-09 10:22:15 --> Helper loaded: url_helper
INFO - 2024-02-09 10:22:15 --> Helper loaded: file_helper
INFO - 2024-02-09 10:22:15 --> Helper loaded: form_helper
INFO - 2024-02-09 10:22:15 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:22:15 --> Controller Class Initialized
INFO - 2024-02-09 10:22:15 --> Form Validation Class Initialized
INFO - 2024-02-09 10:22:15 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:22:15 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:22:53 --> Config Class Initialized
INFO - 2024-02-09 10:22:53 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:22:53 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:22:53 --> Utf8 Class Initialized
INFO - 2024-02-09 10:22:53 --> URI Class Initialized
INFO - 2024-02-09 10:22:53 --> Router Class Initialized
INFO - 2024-02-09 10:22:53 --> Output Class Initialized
INFO - 2024-02-09 10:22:53 --> Security Class Initialized
DEBUG - 2024-02-09 10:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:22:53 --> Input Class Initialized
INFO - 2024-02-09 10:22:53 --> Language Class Initialized
INFO - 2024-02-09 10:22:53 --> Loader Class Initialized
INFO - 2024-02-09 10:22:53 --> Helper loaded: url_helper
INFO - 2024-02-09 10:22:53 --> Helper loaded: file_helper
INFO - 2024-02-09 10:22:53 --> Helper loaded: form_helper
INFO - 2024-02-09 10:22:53 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:22:53 --> Controller Class Initialized
INFO - 2024-02-09 10:22:53 --> Form Validation Class Initialized
INFO - 2024-02-09 10:22:53 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:22:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:22:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:22:53 --> Final output sent to browser
DEBUG - 2024-02-09 10:22:53 --> Total execution time: 0.0235
ERROR - 2024-02-09 10:22:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:22:54 --> Config Class Initialized
INFO - 2024-02-09 10:22:54 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:22:54 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:22:54 --> Utf8 Class Initialized
INFO - 2024-02-09 10:22:54 --> URI Class Initialized
INFO - 2024-02-09 10:22:54 --> Router Class Initialized
INFO - 2024-02-09 10:22:54 --> Output Class Initialized
INFO - 2024-02-09 10:22:54 --> Security Class Initialized
DEBUG - 2024-02-09 10:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:22:54 --> Input Class Initialized
INFO - 2024-02-09 10:22:54 --> Language Class Initialized
INFO - 2024-02-09 10:22:54 --> Loader Class Initialized
INFO - 2024-02-09 10:22:54 --> Helper loaded: url_helper
INFO - 2024-02-09 10:22:54 --> Helper loaded: file_helper
INFO - 2024-02-09 10:22:54 --> Helper loaded: form_helper
INFO - 2024-02-09 10:22:54 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:22:54 --> Controller Class Initialized
INFO - 2024-02-09 10:22:54 --> Form Validation Class Initialized
INFO - 2024-02-09 10:22:54 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:22:54 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:24:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:24:13 --> Config Class Initialized
INFO - 2024-02-09 10:24:13 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:24:13 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:24:13 --> Utf8 Class Initialized
INFO - 2024-02-09 10:24:13 --> URI Class Initialized
INFO - 2024-02-09 10:24:13 --> Router Class Initialized
INFO - 2024-02-09 10:24:13 --> Output Class Initialized
INFO - 2024-02-09 10:24:13 --> Security Class Initialized
DEBUG - 2024-02-09 10:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:24:13 --> Input Class Initialized
INFO - 2024-02-09 10:24:13 --> Language Class Initialized
INFO - 2024-02-09 10:24:13 --> Loader Class Initialized
INFO - 2024-02-09 10:24:13 --> Helper loaded: url_helper
INFO - 2024-02-09 10:24:13 --> Helper loaded: file_helper
INFO - 2024-02-09 10:24:13 --> Helper loaded: form_helper
INFO - 2024-02-09 10:24:13 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:24:13 --> Controller Class Initialized
INFO - 2024-02-09 10:24:13 --> Form Validation Class Initialized
INFO - 2024-02-09 10:24:13 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:24:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:24:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:24:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:24:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:24:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:24:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:24:13 --> Final output sent to browser
DEBUG - 2024-02-09 10:24:13 --> Total execution time: 0.0461
ERROR - 2024-02-09 10:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:24:14 --> Config Class Initialized
INFO - 2024-02-09 10:24:14 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:24:14 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:24:14 --> Utf8 Class Initialized
INFO - 2024-02-09 10:24:14 --> URI Class Initialized
INFO - 2024-02-09 10:24:14 --> Router Class Initialized
INFO - 2024-02-09 10:24:14 --> Output Class Initialized
INFO - 2024-02-09 10:24:14 --> Security Class Initialized
DEBUG - 2024-02-09 10:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:24:14 --> Input Class Initialized
INFO - 2024-02-09 10:24:14 --> Language Class Initialized
INFO - 2024-02-09 10:24:14 --> Loader Class Initialized
INFO - 2024-02-09 10:24:14 --> Helper loaded: url_helper
INFO - 2024-02-09 10:24:14 --> Helper loaded: file_helper
INFO - 2024-02-09 10:24:14 --> Helper loaded: form_helper
INFO - 2024-02-09 10:24:14 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:24:14 --> Controller Class Initialized
INFO - 2024-02-09 10:24:14 --> Form Validation Class Initialized
INFO - 2024-02-09 10:24:14 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:24:14 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:24:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:24:50 --> Config Class Initialized
INFO - 2024-02-09 10:24:50 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:24:50 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:24:50 --> Utf8 Class Initialized
INFO - 2024-02-09 10:24:50 --> URI Class Initialized
INFO - 2024-02-09 10:24:50 --> Router Class Initialized
INFO - 2024-02-09 10:24:50 --> Output Class Initialized
INFO - 2024-02-09 10:24:50 --> Security Class Initialized
DEBUG - 2024-02-09 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:24:50 --> Input Class Initialized
INFO - 2024-02-09 10:24:50 --> Language Class Initialized
INFO - 2024-02-09 10:24:50 --> Loader Class Initialized
INFO - 2024-02-09 10:24:50 --> Helper loaded: url_helper
INFO - 2024-02-09 10:24:50 --> Helper loaded: file_helper
INFO - 2024-02-09 10:24:50 --> Helper loaded: form_helper
INFO - 2024-02-09 10:24:50 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:24:50 --> Controller Class Initialized
INFO - 2024-02-09 10:24:50 --> Form Validation Class Initialized
INFO - 2024-02-09 10:24:50 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:24:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:24:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:24:50 --> Final output sent to browser
DEBUG - 2024-02-09 10:24:50 --> Total execution time: 0.0247
ERROR - 2024-02-09 10:24:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:24:50 --> Config Class Initialized
INFO - 2024-02-09 10:24:50 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:24:50 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:24:50 --> Utf8 Class Initialized
INFO - 2024-02-09 10:24:50 --> URI Class Initialized
INFO - 2024-02-09 10:24:50 --> Router Class Initialized
INFO - 2024-02-09 10:24:50 --> Output Class Initialized
INFO - 2024-02-09 10:24:50 --> Security Class Initialized
DEBUG - 2024-02-09 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:24:50 --> Input Class Initialized
INFO - 2024-02-09 10:24:50 --> Language Class Initialized
INFO - 2024-02-09 10:24:50 --> Loader Class Initialized
INFO - 2024-02-09 10:24:50 --> Helper loaded: url_helper
INFO - 2024-02-09 10:24:50 --> Helper loaded: file_helper
INFO - 2024-02-09 10:24:50 --> Helper loaded: form_helper
INFO - 2024-02-09 10:24:50 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:24:50 --> Controller Class Initialized
INFO - 2024-02-09 10:24:50 --> Form Validation Class Initialized
INFO - 2024-02-09 10:24:50 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:24:50 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:25:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:25:05 --> Config Class Initialized
INFO - 2024-02-09 10:25:05 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:25:05 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:25:05 --> Utf8 Class Initialized
INFO - 2024-02-09 10:25:05 --> URI Class Initialized
INFO - 2024-02-09 10:25:05 --> Router Class Initialized
INFO - 2024-02-09 10:25:05 --> Output Class Initialized
INFO - 2024-02-09 10:25:05 --> Security Class Initialized
DEBUG - 2024-02-09 10:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:25:05 --> Input Class Initialized
INFO - 2024-02-09 10:25:05 --> Language Class Initialized
INFO - 2024-02-09 10:25:05 --> Loader Class Initialized
INFO - 2024-02-09 10:25:05 --> Helper loaded: url_helper
INFO - 2024-02-09 10:25:05 --> Helper loaded: file_helper
INFO - 2024-02-09 10:25:05 --> Helper loaded: form_helper
INFO - 2024-02-09 10:25:05 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:25:05 --> Controller Class Initialized
INFO - 2024-02-09 10:25:05 --> Form Validation Class Initialized
INFO - 2024-02-09 10:25:05 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:25:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:25:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:25:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:25:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:25:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:25:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:25:05 --> Final output sent to browser
DEBUG - 2024-02-09 10:25:05 --> Total execution time: 0.0277
ERROR - 2024-02-09 10:25:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:25:08 --> Config Class Initialized
INFO - 2024-02-09 10:25:08 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:25:08 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:25:08 --> Utf8 Class Initialized
INFO - 2024-02-09 10:25:08 --> URI Class Initialized
INFO - 2024-02-09 10:25:08 --> Router Class Initialized
INFO - 2024-02-09 10:25:08 --> Output Class Initialized
INFO - 2024-02-09 10:25:08 --> Security Class Initialized
DEBUG - 2024-02-09 10:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:25:08 --> Input Class Initialized
INFO - 2024-02-09 10:25:08 --> Language Class Initialized
INFO - 2024-02-09 10:25:08 --> Loader Class Initialized
INFO - 2024-02-09 10:25:08 --> Helper loaded: url_helper
INFO - 2024-02-09 10:25:08 --> Helper loaded: file_helper
INFO - 2024-02-09 10:25:08 --> Helper loaded: form_helper
INFO - 2024-02-09 10:25:08 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:25:08 --> Controller Class Initialized
INFO - 2024-02-09 10:25:08 --> Form Validation Class Initialized
INFO - 2024-02-09 10:25:08 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:25:08 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:25:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:25:29 --> Config Class Initialized
INFO - 2024-02-09 10:25:29 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:25:29 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:25:29 --> Utf8 Class Initialized
INFO - 2024-02-09 10:25:29 --> URI Class Initialized
INFO - 2024-02-09 10:25:29 --> Router Class Initialized
INFO - 2024-02-09 10:25:29 --> Output Class Initialized
INFO - 2024-02-09 10:25:29 --> Security Class Initialized
DEBUG - 2024-02-09 10:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:25:29 --> Input Class Initialized
INFO - 2024-02-09 10:25:29 --> Language Class Initialized
INFO - 2024-02-09 10:25:29 --> Loader Class Initialized
INFO - 2024-02-09 10:25:29 --> Helper loaded: url_helper
INFO - 2024-02-09 10:25:29 --> Helper loaded: file_helper
INFO - 2024-02-09 10:25:29 --> Helper loaded: form_helper
INFO - 2024-02-09 10:25:29 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:25:29 --> Controller Class Initialized
INFO - 2024-02-09 10:25:29 --> Form Validation Class Initialized
INFO - 2024-02-09 10:25:29 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:25:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:25:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:25:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:25:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:25:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:25:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:25:29 --> Final output sent to browser
DEBUG - 2024-02-09 10:25:29 --> Total execution time: 0.0326
ERROR - 2024-02-09 10:25:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:25:30 --> Config Class Initialized
INFO - 2024-02-09 10:25:30 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:25:30 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:25:30 --> Utf8 Class Initialized
INFO - 2024-02-09 10:25:30 --> URI Class Initialized
INFO - 2024-02-09 10:25:30 --> Router Class Initialized
INFO - 2024-02-09 10:25:30 --> Output Class Initialized
INFO - 2024-02-09 10:25:30 --> Security Class Initialized
DEBUG - 2024-02-09 10:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:25:30 --> Input Class Initialized
INFO - 2024-02-09 10:25:30 --> Language Class Initialized
INFO - 2024-02-09 10:25:30 --> Loader Class Initialized
INFO - 2024-02-09 10:25:30 --> Helper loaded: url_helper
INFO - 2024-02-09 10:25:30 --> Helper loaded: file_helper
INFO - 2024-02-09 10:25:30 --> Helper loaded: form_helper
INFO - 2024-02-09 10:25:30 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:25:30 --> Controller Class Initialized
INFO - 2024-02-09 10:25:30 --> Form Validation Class Initialized
INFO - 2024-02-09 10:25:30 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:25:30 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:26:00 --> Config Class Initialized
INFO - 2024-02-09 10:26:00 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:26:00 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:26:00 --> Utf8 Class Initialized
INFO - 2024-02-09 10:26:00 --> URI Class Initialized
INFO - 2024-02-09 10:26:00 --> Router Class Initialized
INFO - 2024-02-09 10:26:00 --> Output Class Initialized
INFO - 2024-02-09 10:26:00 --> Security Class Initialized
DEBUG - 2024-02-09 10:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:26:00 --> Input Class Initialized
INFO - 2024-02-09 10:26:00 --> Language Class Initialized
INFO - 2024-02-09 10:26:00 --> Loader Class Initialized
INFO - 2024-02-09 10:26:00 --> Helper loaded: url_helper
INFO - 2024-02-09 10:26:00 --> Helper loaded: file_helper
INFO - 2024-02-09 10:26:00 --> Helper loaded: form_helper
INFO - 2024-02-09 10:26:00 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:26:00 --> Controller Class Initialized
INFO - 2024-02-09 10:26:00 --> Form Validation Class Initialized
INFO - 2024-02-09 10:26:00 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:26:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:26:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:26:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:26:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:26:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:26:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-09 10:26:00 --> Final output sent to browser
DEBUG - 2024-02-09 10:26:00 --> Total execution time: 0.0317
ERROR - 2024-02-09 10:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:26:01 --> Config Class Initialized
INFO - 2024-02-09 10:26:01 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:26:01 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:26:01 --> Utf8 Class Initialized
INFO - 2024-02-09 10:26:01 --> URI Class Initialized
INFO - 2024-02-09 10:26:01 --> Router Class Initialized
INFO - 2024-02-09 10:26:01 --> Output Class Initialized
INFO - 2024-02-09 10:26:01 --> Security Class Initialized
DEBUG - 2024-02-09 10:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:26:01 --> Input Class Initialized
INFO - 2024-02-09 10:26:01 --> Language Class Initialized
INFO - 2024-02-09 10:26:01 --> Loader Class Initialized
INFO - 2024-02-09 10:26:01 --> Helper loaded: url_helper
INFO - 2024-02-09 10:26:01 --> Helper loaded: file_helper
INFO - 2024-02-09 10:26:01 --> Helper loaded: form_helper
INFO - 2024-02-09 10:26:01 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:26:01 --> Controller Class Initialized
INFO - 2024-02-09 10:26:01 --> Form Validation Class Initialized
INFO - 2024-02-09 10:26:01 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:26:01 --> Model "UserMasterModel" initialized
ERROR - 2024-02-09 10:26:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:26:50 --> Config Class Initialized
INFO - 2024-02-09 10:26:50 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:26:50 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:26:50 --> Utf8 Class Initialized
INFO - 2024-02-09 10:26:50 --> URI Class Initialized
INFO - 2024-02-09 10:26:50 --> Router Class Initialized
INFO - 2024-02-09 10:26:50 --> Output Class Initialized
INFO - 2024-02-09 10:26:50 --> Security Class Initialized
DEBUG - 2024-02-09 10:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:26:50 --> Input Class Initialized
INFO - 2024-02-09 10:26:50 --> Language Class Initialized
INFO - 2024-02-09 10:26:50 --> Loader Class Initialized
INFO - 2024-02-09 10:26:50 --> Helper loaded: url_helper
INFO - 2024-02-09 10:26:50 --> Helper loaded: file_helper
INFO - 2024-02-09 10:26:50 --> Helper loaded: form_helper
INFO - 2024-02-09 10:26:50 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:26:50 --> Controller Class Initialized
INFO - 2024-02-09 10:26:50 --> Form Validation Class Initialized
INFO - 2024-02-09 10:26:50 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:26:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:26:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/form.php
INFO - 2024-02-09 10:26:50 --> Final output sent to browser
DEBUG - 2024-02-09 10:26:50 --> Total execution time: 0.0287
ERROR - 2024-02-09 10:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:29:01 --> Config Class Initialized
INFO - 2024-02-09 10:29:01 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:29:01 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:29:01 --> Utf8 Class Initialized
INFO - 2024-02-09 10:29:01 --> URI Class Initialized
INFO - 2024-02-09 10:29:01 --> Router Class Initialized
INFO - 2024-02-09 10:29:01 --> Output Class Initialized
INFO - 2024-02-09 10:29:01 --> Security Class Initialized
DEBUG - 2024-02-09 10:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:29:01 --> Input Class Initialized
INFO - 2024-02-09 10:29:01 --> Language Class Initialized
INFO - 2024-02-09 10:29:01 --> Loader Class Initialized
INFO - 2024-02-09 10:29:01 --> Helper loaded: url_helper
INFO - 2024-02-09 10:29:01 --> Helper loaded: file_helper
INFO - 2024-02-09 10:29:01 --> Helper loaded: form_helper
INFO - 2024-02-09 10:29:01 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:29:01 --> Controller Class Initialized
INFO - 2024-02-09 10:29:01 --> Model "LoginModel" initialized
INFO - 2024-02-09 10:29:01 --> Form Validation Class Initialized
ERROR - 2024-02-09 10:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-09 10:29:01 --> Config Class Initialized
INFO - 2024-02-09 10:29:01 --> Hooks Class Initialized
DEBUG - 2024-02-09 10:29:01 --> UTF-8 Support Enabled
INFO - 2024-02-09 10:29:01 --> Utf8 Class Initialized
INFO - 2024-02-09 10:29:01 --> URI Class Initialized
INFO - 2024-02-09 10:29:01 --> Router Class Initialized
INFO - 2024-02-09 10:29:01 --> Output Class Initialized
INFO - 2024-02-09 10:29:01 --> Security Class Initialized
DEBUG - 2024-02-09 10:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-09 10:29:01 --> Input Class Initialized
INFO - 2024-02-09 10:29:01 --> Language Class Initialized
INFO - 2024-02-09 10:29:01 --> Loader Class Initialized
INFO - 2024-02-09 10:29:01 --> Helper loaded: url_helper
INFO - 2024-02-09 10:29:01 --> Helper loaded: file_helper
INFO - 2024-02-09 10:29:01 --> Helper loaded: form_helper
INFO - 2024-02-09 10:29:01 --> Database Driver Class Initialized
DEBUG - 2024-02-09 10:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-09 10:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-09 10:29:01 --> Controller Class Initialized
INFO - 2024-02-09 10:29:01 --> Form Validation Class Initialized
INFO - 2024-02-09 10:29:01 --> Model "MasterModel" initialized
INFO - 2024-02-09 10:29:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-09 10:29:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-09 10:29:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-09 10:29:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-09 10:29:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-09 10:29:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-09 10:29:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-09 10:29:01 --> Final output sent to browser
DEBUG - 2024-02-09 10:29:01 --> Total execution time: 0.0262
