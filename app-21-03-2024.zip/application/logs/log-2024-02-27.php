<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-27 12:36:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:36:12 --> Config Class Initialized
INFO - 2024-02-27 12:36:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:36:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:36:12 --> Utf8 Class Initialized
INFO - 2024-02-27 12:36:12 --> URI Class Initialized
INFO - 2024-02-27 12:36:12 --> Router Class Initialized
INFO - 2024-02-27 12:36:12 --> Output Class Initialized
INFO - 2024-02-27 12:36:12 --> Security Class Initialized
DEBUG - 2024-02-27 12:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:36:12 --> Input Class Initialized
INFO - 2024-02-27 12:36:12 --> Language Class Initialized
INFO - 2024-02-27 12:36:12 --> Loader Class Initialized
INFO - 2024-02-27 12:36:12 --> Helper loaded: url_helper
INFO - 2024-02-27 12:36:12 --> Helper loaded: file_helper
INFO - 2024-02-27 12:36:12 --> Helper loaded: form_helper
INFO - 2024-02-27 12:36:12 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:36:12 --> Controller Class Initialized
INFO - 2024-02-27 12:36:12 --> Form Validation Class Initialized
INFO - 2024-02-27 12:36:12 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:36:12 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:36:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:36:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:36:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:36:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:36:12 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:36:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:36:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 12:36:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:36:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:36:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:36:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 12:36:12 --> Final output sent to browser
DEBUG - 2024-02-27 12:36:12 --> Total execution time: 0.0857
ERROR - 2024-02-27 12:36:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:36:12 --> Config Class Initialized
INFO - 2024-02-27 12:36:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:36:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:36:12 --> Utf8 Class Initialized
INFO - 2024-02-27 12:36:12 --> URI Class Initialized
INFO - 2024-02-27 12:36:12 --> Router Class Initialized
INFO - 2024-02-27 12:36:12 --> Output Class Initialized
INFO - 2024-02-27 12:36:12 --> Security Class Initialized
DEBUG - 2024-02-27 12:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:36:12 --> Input Class Initialized
INFO - 2024-02-27 12:36:12 --> Language Class Initialized
INFO - 2024-02-27 12:36:12 --> Loader Class Initialized
INFO - 2024-02-27 12:36:12 --> Helper loaded: url_helper
INFO - 2024-02-27 12:36:12 --> Helper loaded: file_helper
INFO - 2024-02-27 12:36:12 --> Helper loaded: form_helper
INFO - 2024-02-27 12:36:12 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:36:12 --> Controller Class Initialized
INFO - 2024-02-27 12:36:12 --> Form Validation Class Initialized
INFO - 2024-02-27 12:36:12 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:36:12 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:36:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:36:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:36:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:36:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:36:12 --> Model "OrderModel" initialized
ERROR - 2024-02-27 12:36:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:36:14 --> Config Class Initialized
INFO - 2024-02-27 12:36:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:36:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:36:14 --> Utf8 Class Initialized
INFO - 2024-02-27 12:36:14 --> URI Class Initialized
INFO - 2024-02-27 12:36:14 --> Router Class Initialized
INFO - 2024-02-27 12:36:14 --> Output Class Initialized
INFO - 2024-02-27 12:36:14 --> Security Class Initialized
DEBUG - 2024-02-27 12:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:36:14 --> Input Class Initialized
INFO - 2024-02-27 12:36:14 --> Language Class Initialized
INFO - 2024-02-27 12:36:14 --> Loader Class Initialized
INFO - 2024-02-27 12:36:14 --> Helper loaded: url_helper
INFO - 2024-02-27 12:36:14 --> Helper loaded: file_helper
INFO - 2024-02-27 12:36:14 --> Helper loaded: form_helper
INFO - 2024-02-27 12:36:14 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:36:14 --> Controller Class Initialized
INFO - 2024-02-27 12:36:14 --> Form Validation Class Initialized
INFO - 2024-02-27 12:36:14 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:36:14 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:36:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:36:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:36:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:36:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:36:14 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:36:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 12:36:14 --> Final output sent to browser
DEBUG - 2024-02-27 12:36:14 --> Total execution time: 0.0261
ERROR - 2024-02-27 12:37:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:37:03 --> Config Class Initialized
INFO - 2024-02-27 12:37:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:37:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:37:03 --> Utf8 Class Initialized
INFO - 2024-02-27 12:37:03 --> URI Class Initialized
INFO - 2024-02-27 12:37:03 --> Router Class Initialized
INFO - 2024-02-27 12:37:03 --> Output Class Initialized
INFO - 2024-02-27 12:37:03 --> Security Class Initialized
DEBUG - 2024-02-27 12:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:37:03 --> Input Class Initialized
INFO - 2024-02-27 12:37:03 --> Language Class Initialized
INFO - 2024-02-27 12:37:03 --> Loader Class Initialized
INFO - 2024-02-27 12:37:03 --> Helper loaded: url_helper
INFO - 2024-02-27 12:37:03 --> Helper loaded: file_helper
INFO - 2024-02-27 12:37:03 --> Helper loaded: form_helper
INFO - 2024-02-27 12:37:03 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:37:03 --> Controller Class Initialized
INFO - 2024-02-27 12:37:03 --> Form Validation Class Initialized
INFO - 2024-02-27 12:37:03 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:37:03 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:37:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:37:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:37:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:37:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:37:03 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:37:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:37:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:37:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:37:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:37:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-27 12:37:03 --> Final output sent to browser
DEBUG - 2024-02-27 12:37:03 --> Total execution time: 0.0373
ERROR - 2024-02-27 12:37:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:37:03 --> Config Class Initialized
INFO - 2024-02-27 12:37:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:37:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:37:03 --> Utf8 Class Initialized
INFO - 2024-02-27 12:37:03 --> URI Class Initialized
INFO - 2024-02-27 12:37:03 --> Router Class Initialized
INFO - 2024-02-27 12:37:03 --> Output Class Initialized
INFO - 2024-02-27 12:37:03 --> Security Class Initialized
DEBUG - 2024-02-27 12:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:37:03 --> Input Class Initialized
INFO - 2024-02-27 12:37:03 --> Language Class Initialized
INFO - 2024-02-27 12:37:03 --> Loader Class Initialized
INFO - 2024-02-27 12:37:03 --> Helper loaded: url_helper
INFO - 2024-02-27 12:37:03 --> Helper loaded: file_helper
INFO - 2024-02-27 12:37:03 --> Helper loaded: form_helper
INFO - 2024-02-27 12:37:03 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:37:03 --> Controller Class Initialized
INFO - 2024-02-27 12:37:03 --> Form Validation Class Initialized
INFO - 2024-02-27 12:37:03 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:37:03 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:37:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:37:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:37:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:37:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:37:03 --> Model "OrderModel" initialized
ERROR - 2024-02-27 12:37:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:37:05 --> Config Class Initialized
INFO - 2024-02-27 12:37:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:37:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:37:05 --> Utf8 Class Initialized
INFO - 2024-02-27 12:37:05 --> URI Class Initialized
INFO - 2024-02-27 12:37:05 --> Router Class Initialized
INFO - 2024-02-27 12:37:05 --> Output Class Initialized
INFO - 2024-02-27 12:37:05 --> Security Class Initialized
DEBUG - 2024-02-27 12:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:37:05 --> Input Class Initialized
INFO - 2024-02-27 12:37:05 --> Language Class Initialized
INFO - 2024-02-27 12:37:05 --> Loader Class Initialized
INFO - 2024-02-27 12:37:05 --> Helper loaded: url_helper
INFO - 2024-02-27 12:37:05 --> Helper loaded: file_helper
INFO - 2024-02-27 12:37:05 --> Helper loaded: form_helper
INFO - 2024-02-27 12:37:05 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:37:05 --> Controller Class Initialized
INFO - 2024-02-27 12:37:05 --> Form Validation Class Initialized
INFO - 2024-02-27 12:37:05 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:37:05 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:37:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:37:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:37:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:37:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:37:05 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:37:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:37:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:37:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:37:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:37:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-02-27 12:37:05 --> Final output sent to browser
DEBUG - 2024-02-27 12:37:05 --> Total execution time: 0.0441
ERROR - 2024-02-27 12:37:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:37:05 --> Config Class Initialized
INFO - 2024-02-27 12:37:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:37:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:37:05 --> Utf8 Class Initialized
INFO - 2024-02-27 12:37:05 --> URI Class Initialized
INFO - 2024-02-27 12:37:05 --> Router Class Initialized
INFO - 2024-02-27 12:37:05 --> Output Class Initialized
INFO - 2024-02-27 12:37:05 --> Security Class Initialized
DEBUG - 2024-02-27 12:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:37:05 --> Input Class Initialized
INFO - 2024-02-27 12:37:05 --> Language Class Initialized
INFO - 2024-02-27 12:37:05 --> Loader Class Initialized
INFO - 2024-02-27 12:37:05 --> Helper loaded: url_helper
INFO - 2024-02-27 12:37:05 --> Helper loaded: file_helper
INFO - 2024-02-27 12:37:05 --> Helper loaded: form_helper
INFO - 2024-02-27 12:37:05 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:37:05 --> Controller Class Initialized
INFO - 2024-02-27 12:37:05 --> Form Validation Class Initialized
INFO - 2024-02-27 12:37:05 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:37:05 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:37:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:37:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:37:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:37:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:37:05 --> Model "OrderModel" initialized
ERROR - 2024-02-27 12:47:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:47:16 --> Config Class Initialized
INFO - 2024-02-27 12:47:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:47:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:47:16 --> Utf8 Class Initialized
INFO - 2024-02-27 12:47:16 --> URI Class Initialized
INFO - 2024-02-27 12:47:16 --> Router Class Initialized
INFO - 2024-02-27 12:47:16 --> Output Class Initialized
INFO - 2024-02-27 12:47:16 --> Security Class Initialized
DEBUG - 2024-02-27 12:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:47:16 --> Input Class Initialized
INFO - 2024-02-27 12:47:16 --> Language Class Initialized
INFO - 2024-02-27 12:47:16 --> Loader Class Initialized
INFO - 2024-02-27 12:47:16 --> Helper loaded: url_helper
INFO - 2024-02-27 12:47:16 --> Helper loaded: file_helper
INFO - 2024-02-27 12:47:16 --> Helper loaded: form_helper
INFO - 2024-02-27 12:47:16 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:47:16 --> Controller Class Initialized
INFO - 2024-02-27 12:47:16 --> Form Validation Class Initialized
INFO - 2024-02-27 12:47:16 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:47:16 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:47:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:47:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:47:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:47:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:47:16 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:47:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:47:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:47:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:47:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:47:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 12:47:16 --> Final output sent to browser
DEBUG - 2024-02-27 12:47:16 --> Total execution time: 0.0269
ERROR - 2024-02-27 12:47:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:47:16 --> Config Class Initialized
INFO - 2024-02-27 12:47:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:47:17 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:47:17 --> Utf8 Class Initialized
INFO - 2024-02-27 12:47:17 --> URI Class Initialized
INFO - 2024-02-27 12:47:17 --> Router Class Initialized
INFO - 2024-02-27 12:47:17 --> Output Class Initialized
INFO - 2024-02-27 12:47:17 --> Security Class Initialized
DEBUG - 2024-02-27 12:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:47:17 --> Input Class Initialized
INFO - 2024-02-27 12:47:17 --> Language Class Initialized
INFO - 2024-02-27 12:47:17 --> Loader Class Initialized
INFO - 2024-02-27 12:47:17 --> Helper loaded: url_helper
INFO - 2024-02-27 12:47:17 --> Helper loaded: file_helper
INFO - 2024-02-27 12:47:17 --> Helper loaded: form_helper
INFO - 2024-02-27 12:47:17 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:47:17 --> Controller Class Initialized
INFO - 2024-02-27 12:47:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-27 12:47:17 --> Final output sent to browser
DEBUG - 2024-02-27 12:47:17 --> Total execution time: 0.0238
ERROR - 2024-02-27 12:47:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:47:31 --> Config Class Initialized
INFO - 2024-02-27 12:47:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:47:31 --> Utf8 Class Initialized
INFO - 2024-02-27 12:47:31 --> URI Class Initialized
INFO - 2024-02-27 12:47:31 --> Router Class Initialized
INFO - 2024-02-27 12:47:31 --> Output Class Initialized
INFO - 2024-02-27 12:47:31 --> Security Class Initialized
DEBUG - 2024-02-27 12:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:47:31 --> Input Class Initialized
INFO - 2024-02-27 12:47:31 --> Language Class Initialized
INFO - 2024-02-27 12:47:31 --> Loader Class Initialized
INFO - 2024-02-27 12:47:31 --> Helper loaded: url_helper
INFO - 2024-02-27 12:47:31 --> Helper loaded: file_helper
INFO - 2024-02-27 12:47:31 --> Helper loaded: form_helper
INFO - 2024-02-27 12:47:31 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:47:31 --> Controller Class Initialized
INFO - 2024-02-27 12:47:31 --> Form Validation Class Initialized
INFO - 2024-02-27 12:47:31 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:47:31 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:47:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:47:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:47:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:47:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:47:31 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:47:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:47:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:47:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:47:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:47:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 12:47:31 --> Final output sent to browser
DEBUG - 2024-02-27 12:47:31 --> Total execution time: 0.0360
ERROR - 2024-02-27 12:47:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:47:41 --> Config Class Initialized
INFO - 2024-02-27 12:47:41 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:47:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:47:41 --> Utf8 Class Initialized
INFO - 2024-02-27 12:47:41 --> URI Class Initialized
INFO - 2024-02-27 12:47:41 --> Router Class Initialized
INFO - 2024-02-27 12:47:41 --> Output Class Initialized
INFO - 2024-02-27 12:47:41 --> Security Class Initialized
DEBUG - 2024-02-27 12:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:47:41 --> Input Class Initialized
INFO - 2024-02-27 12:47:41 --> Language Class Initialized
INFO - 2024-02-27 12:47:41 --> Loader Class Initialized
INFO - 2024-02-27 12:47:41 --> Helper loaded: url_helper
INFO - 2024-02-27 12:47:41 --> Helper loaded: file_helper
INFO - 2024-02-27 12:47:41 --> Helper loaded: form_helper
INFO - 2024-02-27 12:47:41 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:47:41 --> Controller Class Initialized
INFO - 2024-02-27 12:47:41 --> Form Validation Class Initialized
INFO - 2024-02-27 12:47:41 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:47:41 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:47:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:47:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:47:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:47:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:47:41 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:47:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:47:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:47:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:47:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:47:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 12:47:41 --> Final output sent to browser
DEBUG - 2024-02-27 12:47:41 --> Total execution time: 0.0361
ERROR - 2024-02-27 12:52:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:52:52 --> Config Class Initialized
INFO - 2024-02-27 12:52:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:52:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:52:52 --> Utf8 Class Initialized
INFO - 2024-02-27 12:52:52 --> URI Class Initialized
INFO - 2024-02-27 12:52:52 --> Router Class Initialized
INFO - 2024-02-27 12:52:52 --> Output Class Initialized
INFO - 2024-02-27 12:52:52 --> Security Class Initialized
DEBUG - 2024-02-27 12:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:52:52 --> Input Class Initialized
INFO - 2024-02-27 12:52:52 --> Language Class Initialized
INFO - 2024-02-27 12:52:52 --> Loader Class Initialized
INFO - 2024-02-27 12:52:52 --> Helper loaded: url_helper
INFO - 2024-02-27 12:52:52 --> Helper loaded: file_helper
INFO - 2024-02-27 12:52:52 --> Helper loaded: form_helper
INFO - 2024-02-27 12:52:52 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:52:52 --> Controller Class Initialized
INFO - 2024-02-27 12:52:52 --> Form Validation Class Initialized
INFO - 2024-02-27 12:52:52 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:52:52 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:52:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:52:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:52:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:52:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:52:52 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:52:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:52:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:52:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:52:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:52:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 12:52:52 --> Final output sent to browser
DEBUG - 2024-02-27 12:52:52 --> Total execution time: 0.0376
ERROR - 2024-02-27 12:53:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:53:34 --> Config Class Initialized
INFO - 2024-02-27 12:53:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:53:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:53:34 --> Utf8 Class Initialized
INFO - 2024-02-27 12:53:34 --> URI Class Initialized
INFO - 2024-02-27 12:53:34 --> Router Class Initialized
INFO - 2024-02-27 12:53:34 --> Output Class Initialized
INFO - 2024-02-27 12:53:34 --> Security Class Initialized
DEBUG - 2024-02-27 12:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:53:34 --> Input Class Initialized
INFO - 2024-02-27 12:53:34 --> Language Class Initialized
INFO - 2024-02-27 12:53:34 --> Loader Class Initialized
INFO - 2024-02-27 12:53:34 --> Helper loaded: url_helper
INFO - 2024-02-27 12:53:34 --> Helper loaded: file_helper
INFO - 2024-02-27 12:53:34 --> Helper loaded: form_helper
INFO - 2024-02-27 12:53:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:53:34 --> Controller Class Initialized
INFO - 2024-02-27 12:53:34 --> Form Validation Class Initialized
INFO - 2024-02-27 12:53:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:53:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:53:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:53:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:53:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:53:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:53:34 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:53:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:53:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:53:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:53:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:53:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 12:53:34 --> Final output sent to browser
DEBUG - 2024-02-27 12:53:34 --> Total execution time: 0.0255
ERROR - 2024-02-27 12:53:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:53:55 --> Config Class Initialized
INFO - 2024-02-27 12:53:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:53:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:53:55 --> Utf8 Class Initialized
INFO - 2024-02-27 12:53:55 --> URI Class Initialized
INFO - 2024-02-27 12:53:55 --> Router Class Initialized
INFO - 2024-02-27 12:53:55 --> Output Class Initialized
INFO - 2024-02-27 12:53:55 --> Security Class Initialized
DEBUG - 2024-02-27 12:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:53:55 --> Input Class Initialized
INFO - 2024-02-27 12:53:55 --> Language Class Initialized
INFO - 2024-02-27 12:53:55 --> Loader Class Initialized
INFO - 2024-02-27 12:53:55 --> Helper loaded: url_helper
INFO - 2024-02-27 12:53:55 --> Helper loaded: file_helper
INFO - 2024-02-27 12:53:55 --> Helper loaded: form_helper
INFO - 2024-02-27 12:53:55 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:53:55 --> Controller Class Initialized
INFO - 2024-02-27 12:53:55 --> Model "LoginModel" initialized
INFO - 2024-02-27 12:53:55 --> Form Validation Class Initialized
ERROR - 2024-02-27 12:53:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:53:55 --> Config Class Initialized
INFO - 2024-02-27 12:53:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:53:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:53:55 --> Utf8 Class Initialized
INFO - 2024-02-27 12:53:55 --> URI Class Initialized
INFO - 2024-02-27 12:53:55 --> Router Class Initialized
INFO - 2024-02-27 12:53:55 --> Output Class Initialized
INFO - 2024-02-27 12:53:55 --> Security Class Initialized
DEBUG - 2024-02-27 12:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:53:55 --> Input Class Initialized
INFO - 2024-02-27 12:53:55 --> Language Class Initialized
INFO - 2024-02-27 12:53:55 --> Loader Class Initialized
INFO - 2024-02-27 12:53:55 --> Helper loaded: url_helper
INFO - 2024-02-27 12:53:55 --> Helper loaded: file_helper
INFO - 2024-02-27 12:53:55 --> Helper loaded: form_helper
INFO - 2024-02-27 12:53:55 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:53:55 --> Controller Class Initialized
INFO - 2024-02-27 12:53:55 --> Model "LoginModel" initialized
INFO - 2024-02-27 12:53:55 --> Form Validation Class Initialized
INFO - 2024-02-27 12:53:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-27 12:53:55 --> Final output sent to browser
DEBUG - 2024-02-27 12:53:55 --> Total execution time: 0.0224
ERROR - 2024-02-27 12:53:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:53:57 --> Config Class Initialized
INFO - 2024-02-27 12:53:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:53:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:53:57 --> Utf8 Class Initialized
INFO - 2024-02-27 12:53:57 --> URI Class Initialized
INFO - 2024-02-27 12:53:57 --> Router Class Initialized
INFO - 2024-02-27 12:53:57 --> Output Class Initialized
INFO - 2024-02-27 12:53:57 --> Security Class Initialized
DEBUG - 2024-02-27 12:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:53:57 --> Input Class Initialized
INFO - 2024-02-27 12:53:57 --> Language Class Initialized
INFO - 2024-02-27 12:53:57 --> Loader Class Initialized
INFO - 2024-02-27 12:53:57 --> Helper loaded: url_helper
INFO - 2024-02-27 12:53:57 --> Helper loaded: file_helper
INFO - 2024-02-27 12:53:57 --> Helper loaded: form_helper
INFO - 2024-02-27 12:53:57 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:53:57 --> Controller Class Initialized
INFO - 2024-02-27 12:53:57 --> Model "LoginModel" initialized
INFO - 2024-02-27 12:53:57 --> Form Validation Class Initialized
INFO - 2024-02-27 12:53:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-27 12:53:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:53:57 --> Config Class Initialized
INFO - 2024-02-27 12:53:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:53:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:53:57 --> Utf8 Class Initialized
INFO - 2024-02-27 12:53:57 --> URI Class Initialized
INFO - 2024-02-27 12:53:57 --> Router Class Initialized
INFO - 2024-02-27 12:53:57 --> Output Class Initialized
INFO - 2024-02-27 12:53:57 --> Security Class Initialized
DEBUG - 2024-02-27 12:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:53:57 --> Input Class Initialized
INFO - 2024-02-27 12:53:57 --> Language Class Initialized
INFO - 2024-02-27 12:53:57 --> Loader Class Initialized
INFO - 2024-02-27 12:53:57 --> Helper loaded: url_helper
INFO - 2024-02-27 12:53:57 --> Helper loaded: file_helper
INFO - 2024-02-27 12:53:57 --> Helper loaded: form_helper
INFO - 2024-02-27 12:53:57 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:53:57 --> Controller Class Initialized
INFO - 2024-02-27 12:53:57 --> Form Validation Class Initialized
INFO - 2024-02-27 12:53:57 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:53:57 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:53:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:53:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:53:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:53:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:53:57 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:53:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:53:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 12:53:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:53:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:53:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:53:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 12:53:57 --> Final output sent to browser
DEBUG - 2024-02-27 12:53:57 --> Total execution time: 0.0263
ERROR - 2024-02-27 12:53:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:53:57 --> Config Class Initialized
INFO - 2024-02-27 12:53:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:53:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:53:57 --> Utf8 Class Initialized
INFO - 2024-02-27 12:53:57 --> URI Class Initialized
INFO - 2024-02-27 12:53:57 --> Router Class Initialized
INFO - 2024-02-27 12:53:57 --> Output Class Initialized
INFO - 2024-02-27 12:53:57 --> Security Class Initialized
DEBUG - 2024-02-27 12:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:53:57 --> Input Class Initialized
INFO - 2024-02-27 12:53:57 --> Language Class Initialized
INFO - 2024-02-27 12:53:57 --> Loader Class Initialized
INFO - 2024-02-27 12:53:57 --> Helper loaded: url_helper
INFO - 2024-02-27 12:53:57 --> Helper loaded: file_helper
INFO - 2024-02-27 12:53:57 --> Helper loaded: form_helper
INFO - 2024-02-27 12:53:57 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:53:57 --> Controller Class Initialized
INFO - 2024-02-27 12:53:57 --> Form Validation Class Initialized
INFO - 2024-02-27 12:53:57 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:53:57 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:53:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:53:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:53:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:53:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:53:57 --> Model "OrderModel" initialized
ERROR - 2024-02-27 12:54:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:54:02 --> Config Class Initialized
INFO - 2024-02-27 12:54:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:54:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:54:03 --> Utf8 Class Initialized
INFO - 2024-02-27 12:54:03 --> URI Class Initialized
INFO - 2024-02-27 12:54:03 --> Router Class Initialized
INFO - 2024-02-27 12:54:03 --> Output Class Initialized
INFO - 2024-02-27 12:54:03 --> Security Class Initialized
DEBUG - 2024-02-27 12:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:54:03 --> Input Class Initialized
INFO - 2024-02-27 12:54:03 --> Language Class Initialized
INFO - 2024-02-27 12:54:03 --> Loader Class Initialized
INFO - 2024-02-27 12:54:03 --> Helper loaded: url_helper
INFO - 2024-02-27 12:54:03 --> Helper loaded: file_helper
INFO - 2024-02-27 12:54:03 --> Helper loaded: form_helper
INFO - 2024-02-27 12:54:03 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:54:03 --> Controller Class Initialized
INFO - 2024-02-27 12:54:03 --> Form Validation Class Initialized
INFO - 2024-02-27 12:54:03 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:54:03 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:54:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:54:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:54:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:54:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:54:03 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:54:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:54:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:54:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:54:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:54:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 12:54:03 --> Final output sent to browser
DEBUG - 2024-02-27 12:54:03 --> Total execution time: 0.0289
ERROR - 2024-02-27 12:54:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:54:47 --> Config Class Initialized
INFO - 2024-02-27 12:54:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:54:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:54:47 --> Utf8 Class Initialized
INFO - 2024-02-27 12:54:47 --> URI Class Initialized
INFO - 2024-02-27 12:54:47 --> Router Class Initialized
INFO - 2024-02-27 12:54:47 --> Output Class Initialized
INFO - 2024-02-27 12:54:47 --> Security Class Initialized
DEBUG - 2024-02-27 12:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:54:47 --> Input Class Initialized
INFO - 2024-02-27 12:54:47 --> Language Class Initialized
INFO - 2024-02-27 12:54:47 --> Loader Class Initialized
INFO - 2024-02-27 12:54:47 --> Helper loaded: url_helper
INFO - 2024-02-27 12:54:47 --> Helper loaded: file_helper
INFO - 2024-02-27 12:54:47 --> Helper loaded: form_helper
INFO - 2024-02-27 12:54:47 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:54:48 --> Controller Class Initialized
INFO - 2024-02-27 12:54:48 --> Form Validation Class Initialized
INFO - 2024-02-27 12:54:48 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:54:48 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:54:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:54:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:54:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:54:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:54:48 --> Model "OrderModel" initialized
ERROR - 2024-02-27 12:55:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:55:11 --> Config Class Initialized
INFO - 2024-02-27 12:55:11 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:55:11 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:55:11 --> Utf8 Class Initialized
INFO - 2024-02-27 12:55:11 --> URI Class Initialized
INFO - 2024-02-27 12:55:11 --> Router Class Initialized
INFO - 2024-02-27 12:55:11 --> Output Class Initialized
INFO - 2024-02-27 12:55:11 --> Security Class Initialized
DEBUG - 2024-02-27 12:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:55:11 --> Input Class Initialized
INFO - 2024-02-27 12:55:11 --> Language Class Initialized
INFO - 2024-02-27 12:55:11 --> Loader Class Initialized
INFO - 2024-02-27 12:55:11 --> Helper loaded: url_helper
INFO - 2024-02-27 12:55:11 --> Helper loaded: file_helper
INFO - 2024-02-27 12:55:11 --> Helper loaded: form_helper
INFO - 2024-02-27 12:55:11 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:55:11 --> Controller Class Initialized
INFO - 2024-02-27 12:55:11 --> Form Validation Class Initialized
INFO - 2024-02-27 12:55:11 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:55:11 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:55:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:55:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:55:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:55:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:55:11 --> Model "OrderModel" initialized
ERROR - 2024-02-27 12:55:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:55:26 --> Config Class Initialized
INFO - 2024-02-27 12:55:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:55:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:55:26 --> Utf8 Class Initialized
INFO - 2024-02-27 12:55:26 --> URI Class Initialized
INFO - 2024-02-27 12:55:26 --> Router Class Initialized
INFO - 2024-02-27 12:55:26 --> Output Class Initialized
INFO - 2024-02-27 12:55:26 --> Security Class Initialized
DEBUG - 2024-02-27 12:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:55:26 --> Input Class Initialized
INFO - 2024-02-27 12:55:26 --> Language Class Initialized
INFO - 2024-02-27 12:55:26 --> Loader Class Initialized
INFO - 2024-02-27 12:55:26 --> Helper loaded: url_helper
INFO - 2024-02-27 12:55:26 --> Helper loaded: file_helper
INFO - 2024-02-27 12:55:26 --> Helper loaded: form_helper
INFO - 2024-02-27 12:55:26 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:55:26 --> Controller Class Initialized
INFO - 2024-02-27 12:55:26 --> Form Validation Class Initialized
INFO - 2024-02-27 12:55:26 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:55:26 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:55:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:55:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:55:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:55:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:55:26 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:55:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:55:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:55:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:55:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:55:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 12:55:26 --> Final output sent to browser
DEBUG - 2024-02-27 12:55:26 --> Total execution time: 0.0321
ERROR - 2024-02-27 12:58:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:58:55 --> Config Class Initialized
INFO - 2024-02-27 12:58:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:58:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:58:55 --> Utf8 Class Initialized
INFO - 2024-02-27 12:58:55 --> URI Class Initialized
INFO - 2024-02-27 12:58:55 --> Router Class Initialized
INFO - 2024-02-27 12:58:55 --> Output Class Initialized
INFO - 2024-02-27 12:58:55 --> Security Class Initialized
DEBUG - 2024-02-27 12:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:58:55 --> Input Class Initialized
INFO - 2024-02-27 12:58:55 --> Language Class Initialized
INFO - 2024-02-27 12:58:55 --> Loader Class Initialized
INFO - 2024-02-27 12:58:55 --> Helper loaded: url_helper
INFO - 2024-02-27 12:58:55 --> Helper loaded: file_helper
INFO - 2024-02-27 12:58:55 --> Helper loaded: form_helper
INFO - 2024-02-27 12:58:55 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:58:55 --> Controller Class Initialized
INFO - 2024-02-27 12:58:55 --> Form Validation Class Initialized
INFO - 2024-02-27 12:58:55 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:58:55 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:58:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:58:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:58:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:58:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:58:55 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:58:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:58:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:58:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:58:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:58:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 12:58:55 --> Final output sent to browser
DEBUG - 2024-02-27 12:58:55 --> Total execution time: 0.0315
ERROR - 2024-02-27 12:58:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:58:56 --> Config Class Initialized
INFO - 2024-02-27 12:58:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:58:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:58:56 --> Utf8 Class Initialized
INFO - 2024-02-27 12:58:56 --> URI Class Initialized
INFO - 2024-02-27 12:58:56 --> Router Class Initialized
INFO - 2024-02-27 12:58:56 --> Output Class Initialized
INFO - 2024-02-27 12:58:56 --> Security Class Initialized
DEBUG - 2024-02-27 12:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:58:56 --> Input Class Initialized
INFO - 2024-02-27 12:58:56 --> Language Class Initialized
INFO - 2024-02-27 12:58:56 --> Loader Class Initialized
INFO - 2024-02-27 12:58:56 --> Helper loaded: url_helper
INFO - 2024-02-27 12:58:56 --> Helper loaded: file_helper
INFO - 2024-02-27 12:58:56 --> Helper loaded: form_helper
INFO - 2024-02-27 12:58:56 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:58:56 --> Controller Class Initialized
INFO - 2024-02-27 12:58:56 --> Form Validation Class Initialized
INFO - 2024-02-27 12:58:56 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:58:56 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:58:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:58:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:58:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:58:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:58:56 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:58:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:58:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:58:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:58:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:58:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 12:58:56 --> Final output sent to browser
DEBUG - 2024-02-27 12:58:56 --> Total execution time: 0.0336
ERROR - 2024-02-27 12:59:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:59:25 --> Config Class Initialized
INFO - 2024-02-27 12:59:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:59:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:59:25 --> Utf8 Class Initialized
INFO - 2024-02-27 12:59:25 --> URI Class Initialized
INFO - 2024-02-27 12:59:25 --> Router Class Initialized
INFO - 2024-02-27 12:59:25 --> Output Class Initialized
INFO - 2024-02-27 12:59:25 --> Security Class Initialized
DEBUG - 2024-02-27 12:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:59:25 --> Input Class Initialized
INFO - 2024-02-27 12:59:25 --> Language Class Initialized
INFO - 2024-02-27 12:59:25 --> Loader Class Initialized
INFO - 2024-02-27 12:59:25 --> Helper loaded: url_helper
INFO - 2024-02-27 12:59:25 --> Helper loaded: file_helper
INFO - 2024-02-27 12:59:25 --> Helper loaded: form_helper
INFO - 2024-02-27 12:59:25 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:59:25 --> Controller Class Initialized
INFO - 2024-02-27 12:59:25 --> Form Validation Class Initialized
INFO - 2024-02-27 12:59:25 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:59:25 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:59:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:59:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:59:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:59:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:59:25 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:59:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:59:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:59:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:59:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:59:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 12:59:25 --> Final output sent to browser
DEBUG - 2024-02-27 12:59:25 --> Total execution time: 0.0348
ERROR - 2024-02-27 12:59:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:59:27 --> Config Class Initialized
INFO - 2024-02-27 12:59:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:59:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:59:27 --> Utf8 Class Initialized
INFO - 2024-02-27 12:59:27 --> URI Class Initialized
INFO - 2024-02-27 12:59:27 --> Router Class Initialized
INFO - 2024-02-27 12:59:27 --> Output Class Initialized
INFO - 2024-02-27 12:59:27 --> Security Class Initialized
DEBUG - 2024-02-27 12:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:59:27 --> Input Class Initialized
INFO - 2024-02-27 12:59:27 --> Language Class Initialized
INFO - 2024-02-27 12:59:28 --> Loader Class Initialized
INFO - 2024-02-27 12:59:28 --> Helper loaded: url_helper
INFO - 2024-02-27 12:59:28 --> Helper loaded: file_helper
INFO - 2024-02-27 12:59:28 --> Helper loaded: form_helper
INFO - 2024-02-27 12:59:28 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:59:28 --> Controller Class Initialized
INFO - 2024-02-27 12:59:28 --> Form Validation Class Initialized
INFO - 2024-02-27 12:59:28 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:59:28 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:59:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:59:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:59:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:59:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:59:28 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:59:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:59:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:59:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:59:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:59:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 12:59:28 --> Final output sent to browser
DEBUG - 2024-02-27 12:59:28 --> Total execution time: 0.0423
ERROR - 2024-02-27 12:59:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:59:33 --> Config Class Initialized
INFO - 2024-02-27 12:59:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:59:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:59:33 --> Utf8 Class Initialized
INFO - 2024-02-27 12:59:33 --> URI Class Initialized
INFO - 2024-02-27 12:59:33 --> Router Class Initialized
INFO - 2024-02-27 12:59:33 --> Output Class Initialized
INFO - 2024-02-27 12:59:33 --> Security Class Initialized
DEBUG - 2024-02-27 12:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:59:33 --> Input Class Initialized
INFO - 2024-02-27 12:59:33 --> Language Class Initialized
INFO - 2024-02-27 12:59:33 --> Loader Class Initialized
INFO - 2024-02-27 12:59:33 --> Helper loaded: url_helper
INFO - 2024-02-27 12:59:33 --> Helper loaded: file_helper
INFO - 2024-02-27 12:59:33 --> Helper loaded: form_helper
INFO - 2024-02-27 12:59:33 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:59:33 --> Controller Class Initialized
INFO - 2024-02-27 12:59:33 --> Form Validation Class Initialized
INFO - 2024-02-27 12:59:33 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:59:33 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:59:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:59:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:59:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:59:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:59:33 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:59:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:59:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:59:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:59:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:59:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 12:59:33 --> Final output sent to browser
DEBUG - 2024-02-27 12:59:33 --> Total execution time: 0.0358
ERROR - 2024-02-27 12:59:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:59:40 --> Config Class Initialized
INFO - 2024-02-27 12:59:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:59:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:59:40 --> Utf8 Class Initialized
INFO - 2024-02-27 12:59:40 --> URI Class Initialized
INFO - 2024-02-27 12:59:40 --> Router Class Initialized
INFO - 2024-02-27 12:59:40 --> Output Class Initialized
INFO - 2024-02-27 12:59:40 --> Security Class Initialized
DEBUG - 2024-02-27 12:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:59:40 --> Input Class Initialized
INFO - 2024-02-27 12:59:40 --> Language Class Initialized
INFO - 2024-02-27 12:59:40 --> Loader Class Initialized
INFO - 2024-02-27 12:59:40 --> Helper loaded: url_helper
INFO - 2024-02-27 12:59:40 --> Helper loaded: file_helper
INFO - 2024-02-27 12:59:40 --> Helper loaded: form_helper
INFO - 2024-02-27 12:59:40 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:59:40 --> Controller Class Initialized
INFO - 2024-02-27 12:59:40 --> Form Validation Class Initialized
INFO - 2024-02-27 12:59:40 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:59:40 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:59:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:59:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:59:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:59:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:59:40 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:59:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:59:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 12:59:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:59:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:59:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:59:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 12:59:40 --> Final output sent to browser
DEBUG - 2024-02-27 12:59:40 --> Total execution time: 0.0259
ERROR - 2024-02-27 12:59:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:59:40 --> Config Class Initialized
INFO - 2024-02-27 12:59:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:59:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:59:40 --> Utf8 Class Initialized
INFO - 2024-02-27 12:59:40 --> URI Class Initialized
INFO - 2024-02-27 12:59:40 --> Router Class Initialized
INFO - 2024-02-27 12:59:40 --> Output Class Initialized
INFO - 2024-02-27 12:59:40 --> Security Class Initialized
DEBUG - 2024-02-27 12:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:59:40 --> Input Class Initialized
INFO - 2024-02-27 12:59:40 --> Language Class Initialized
INFO - 2024-02-27 12:59:40 --> Loader Class Initialized
INFO - 2024-02-27 12:59:40 --> Helper loaded: url_helper
INFO - 2024-02-27 12:59:40 --> Helper loaded: file_helper
INFO - 2024-02-27 12:59:40 --> Helper loaded: form_helper
INFO - 2024-02-27 12:59:40 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:59:40 --> Controller Class Initialized
INFO - 2024-02-27 12:59:40 --> Form Validation Class Initialized
INFO - 2024-02-27 12:59:40 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:59:40 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:59:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:59:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:59:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:59:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:59:40 --> Model "OrderModel" initialized
ERROR - 2024-02-27 12:59:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:59:47 --> Config Class Initialized
INFO - 2024-02-27 12:59:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:59:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:59:47 --> Utf8 Class Initialized
INFO - 2024-02-27 12:59:47 --> URI Class Initialized
INFO - 2024-02-27 12:59:47 --> Router Class Initialized
INFO - 2024-02-27 12:59:47 --> Output Class Initialized
INFO - 2024-02-27 12:59:47 --> Security Class Initialized
DEBUG - 2024-02-27 12:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:59:47 --> Input Class Initialized
INFO - 2024-02-27 12:59:47 --> Language Class Initialized
INFO - 2024-02-27 12:59:47 --> Loader Class Initialized
INFO - 2024-02-27 12:59:47 --> Helper loaded: url_helper
INFO - 2024-02-27 12:59:47 --> Helper loaded: file_helper
INFO - 2024-02-27 12:59:47 --> Helper loaded: form_helper
INFO - 2024-02-27 12:59:47 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:59:47 --> Controller Class Initialized
INFO - 2024-02-27 12:59:47 --> Form Validation Class Initialized
INFO - 2024-02-27 12:59:47 --> Model "MasterModel" initialized
INFO - 2024-02-27 12:59:47 --> Model "DashboardModel" initialized
INFO - 2024-02-27 12:59:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 12:59:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 12:59:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 12:59:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 12:59:47 --> Model "OrderModel" initialized
INFO - 2024-02-27 12:59:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 12:59:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 12:59:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 12:59:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 12:59:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 12:59:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 12:59:47 --> Final output sent to browser
DEBUG - 2024-02-27 12:59:47 --> Total execution time: 0.0370
ERROR - 2024-02-27 12:59:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:59:49 --> Config Class Initialized
INFO - 2024-02-27 12:59:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:59:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:59:49 --> Utf8 Class Initialized
INFO - 2024-02-27 12:59:49 --> URI Class Initialized
INFO - 2024-02-27 12:59:49 --> Router Class Initialized
INFO - 2024-02-27 12:59:49 --> Output Class Initialized
INFO - 2024-02-27 12:59:49 --> Security Class Initialized
DEBUG - 2024-02-27 12:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:59:49 --> Input Class Initialized
INFO - 2024-02-27 12:59:49 --> Language Class Initialized
INFO - 2024-02-27 12:59:49 --> Loader Class Initialized
INFO - 2024-02-27 12:59:49 --> Helper loaded: url_helper
INFO - 2024-02-27 12:59:49 --> Helper loaded: file_helper
INFO - 2024-02-27 12:59:49 --> Helper loaded: form_helper
INFO - 2024-02-27 12:59:49 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:59:49 --> Controller Class Initialized
INFO - 2024-02-27 12:59:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-27 12:59:49 --> Final output sent to browser
DEBUG - 2024-02-27 12:59:49 --> Total execution time: 0.0204
ERROR - 2024-02-27 12:59:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 12:59:54 --> Config Class Initialized
INFO - 2024-02-27 12:59:54 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:59:54 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:59:54 --> Utf8 Class Initialized
INFO - 2024-02-27 12:59:54 --> URI Class Initialized
INFO - 2024-02-27 12:59:54 --> Router Class Initialized
INFO - 2024-02-27 12:59:54 --> Output Class Initialized
INFO - 2024-02-27 12:59:54 --> Security Class Initialized
DEBUG - 2024-02-27 12:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:59:54 --> Input Class Initialized
INFO - 2024-02-27 12:59:54 --> Language Class Initialized
INFO - 2024-02-27 12:59:54 --> Loader Class Initialized
INFO - 2024-02-27 12:59:54 --> Helper loaded: url_helper
INFO - 2024-02-27 12:59:54 --> Helper loaded: file_helper
INFO - 2024-02-27 12:59:54 --> Helper loaded: form_helper
INFO - 2024-02-27 12:59:54 --> Database Driver Class Initialized
DEBUG - 2024-02-27 12:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 12:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:59:54 --> Controller Class Initialized
INFO - 2024-02-27 12:59:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-27 12:59:54 --> Final output sent to browser
DEBUG - 2024-02-27 12:59:54 --> Total execution time: 0.0207
ERROR - 2024-02-27 13:00:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:00:07 --> Config Class Initialized
INFO - 2024-02-27 13:00:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:00:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:00:07 --> Utf8 Class Initialized
INFO - 2024-02-27 13:00:07 --> URI Class Initialized
INFO - 2024-02-27 13:00:07 --> Router Class Initialized
INFO - 2024-02-27 13:00:07 --> Output Class Initialized
INFO - 2024-02-27 13:00:07 --> Security Class Initialized
DEBUG - 2024-02-27 13:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:00:07 --> Input Class Initialized
INFO - 2024-02-27 13:00:07 --> Language Class Initialized
INFO - 2024-02-27 13:00:07 --> Loader Class Initialized
INFO - 2024-02-27 13:00:07 --> Helper loaded: url_helper
INFO - 2024-02-27 13:00:07 --> Helper loaded: file_helper
INFO - 2024-02-27 13:00:07 --> Helper loaded: form_helper
INFO - 2024-02-27 13:00:07 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:00:07 --> Controller Class Initialized
INFO - 2024-02-27 13:00:07 --> Form Validation Class Initialized
INFO - 2024-02-27 13:00:07 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:00:07 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:00:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:00:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:00:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:00:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:00:07 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:00:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:00:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:00:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:00:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:00:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:00:07 --> Final output sent to browser
DEBUG - 2024-02-27 13:00:07 --> Total execution time: 0.0302
ERROR - 2024-02-27 13:00:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:00:34 --> Config Class Initialized
INFO - 2024-02-27 13:00:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:00:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:00:34 --> Utf8 Class Initialized
INFO - 2024-02-27 13:00:34 --> URI Class Initialized
INFO - 2024-02-27 13:00:34 --> Router Class Initialized
INFO - 2024-02-27 13:00:34 --> Output Class Initialized
INFO - 2024-02-27 13:00:34 --> Security Class Initialized
DEBUG - 2024-02-27 13:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:00:34 --> Input Class Initialized
INFO - 2024-02-27 13:00:34 --> Language Class Initialized
INFO - 2024-02-27 13:00:34 --> Loader Class Initialized
INFO - 2024-02-27 13:00:34 --> Helper loaded: url_helper
INFO - 2024-02-27 13:00:34 --> Helper loaded: file_helper
INFO - 2024-02-27 13:00:34 --> Helper loaded: form_helper
INFO - 2024-02-27 13:00:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:00:34 --> Controller Class Initialized
INFO - 2024-02-27 13:00:34 --> Form Validation Class Initialized
INFO - 2024-02-27 13:00:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:00:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:00:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:00:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:00:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:00:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:00:34 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:00:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:00:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:00:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:00:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:00:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:00:34 --> Final output sent to browser
DEBUG - 2024-02-27 13:00:34 --> Total execution time: 0.0363
ERROR - 2024-02-27 13:01:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:01:19 --> Config Class Initialized
INFO - 2024-02-27 13:01:19 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:01:19 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:01:19 --> Utf8 Class Initialized
INFO - 2024-02-27 13:01:19 --> URI Class Initialized
INFO - 2024-02-27 13:01:19 --> Router Class Initialized
INFO - 2024-02-27 13:01:19 --> Output Class Initialized
INFO - 2024-02-27 13:01:19 --> Security Class Initialized
DEBUG - 2024-02-27 13:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:01:19 --> Input Class Initialized
INFO - 2024-02-27 13:01:19 --> Language Class Initialized
INFO - 2024-02-27 13:01:19 --> Loader Class Initialized
INFO - 2024-02-27 13:01:19 --> Helper loaded: url_helper
INFO - 2024-02-27 13:01:19 --> Helper loaded: file_helper
INFO - 2024-02-27 13:01:19 --> Helper loaded: form_helper
INFO - 2024-02-27 13:01:19 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:01:19 --> Controller Class Initialized
INFO - 2024-02-27 13:01:19 --> Form Validation Class Initialized
INFO - 2024-02-27 13:01:19 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:01:19 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:01:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:01:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:01:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:01:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:01:19 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:01:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:01:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:01:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:01:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:01:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:01:19 --> Final output sent to browser
DEBUG - 2024-02-27 13:01:19 --> Total execution time: 0.0292
ERROR - 2024-02-27 13:01:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:01:21 --> Config Class Initialized
INFO - 2024-02-27 13:01:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:01:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:01:21 --> Utf8 Class Initialized
INFO - 2024-02-27 13:01:21 --> URI Class Initialized
INFO - 2024-02-27 13:01:21 --> Router Class Initialized
INFO - 2024-02-27 13:01:21 --> Output Class Initialized
INFO - 2024-02-27 13:01:21 --> Security Class Initialized
DEBUG - 2024-02-27 13:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:01:21 --> Input Class Initialized
INFO - 2024-02-27 13:01:21 --> Language Class Initialized
INFO - 2024-02-27 13:01:21 --> Loader Class Initialized
INFO - 2024-02-27 13:01:21 --> Helper loaded: url_helper
INFO - 2024-02-27 13:01:21 --> Helper loaded: file_helper
INFO - 2024-02-27 13:01:21 --> Helper loaded: form_helper
INFO - 2024-02-27 13:01:21 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:01:21 --> Controller Class Initialized
INFO - 2024-02-27 13:01:21 --> Form Validation Class Initialized
INFO - 2024-02-27 13:01:21 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:01:21 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:01:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:01:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:01:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:01:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:01:21 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:01:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:01:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:01:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:01:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:01:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:01:21 --> Final output sent to browser
DEBUG - 2024-02-27 13:01:21 --> Total execution time: 0.0277
ERROR - 2024-02-27 13:01:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:01:23 --> Config Class Initialized
INFO - 2024-02-27 13:01:23 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:01:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:01:23 --> Utf8 Class Initialized
INFO - 2024-02-27 13:01:23 --> URI Class Initialized
INFO - 2024-02-27 13:01:23 --> Router Class Initialized
INFO - 2024-02-27 13:01:23 --> Output Class Initialized
INFO - 2024-02-27 13:01:23 --> Security Class Initialized
DEBUG - 2024-02-27 13:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:01:23 --> Input Class Initialized
INFO - 2024-02-27 13:01:23 --> Language Class Initialized
INFO - 2024-02-27 13:01:23 --> Loader Class Initialized
INFO - 2024-02-27 13:01:23 --> Helper loaded: url_helper
INFO - 2024-02-27 13:01:23 --> Helper loaded: file_helper
INFO - 2024-02-27 13:01:23 --> Helper loaded: form_helper
INFO - 2024-02-27 13:01:23 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:01:23 --> Controller Class Initialized
INFO - 2024-02-27 13:01:23 --> Form Validation Class Initialized
INFO - 2024-02-27 13:01:23 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:01:23 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:01:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:01:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:01:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:01:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:01:23 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:01:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:01:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:01:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:01:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:01:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:01:23 --> Final output sent to browser
DEBUG - 2024-02-27 13:01:23 --> Total execution time: 0.0982
ERROR - 2024-02-27 13:01:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:01:57 --> Config Class Initialized
INFO - 2024-02-27 13:01:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:01:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:01:57 --> Utf8 Class Initialized
INFO - 2024-02-27 13:01:57 --> URI Class Initialized
INFO - 2024-02-27 13:01:57 --> Router Class Initialized
INFO - 2024-02-27 13:01:57 --> Output Class Initialized
INFO - 2024-02-27 13:01:57 --> Security Class Initialized
DEBUG - 2024-02-27 13:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:01:57 --> Input Class Initialized
INFO - 2024-02-27 13:01:57 --> Language Class Initialized
INFO - 2024-02-27 13:01:57 --> Loader Class Initialized
INFO - 2024-02-27 13:01:57 --> Helper loaded: url_helper
INFO - 2024-02-27 13:01:57 --> Helper loaded: file_helper
INFO - 2024-02-27 13:01:57 --> Helper loaded: form_helper
INFO - 2024-02-27 13:01:57 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:01:57 --> Controller Class Initialized
INFO - 2024-02-27 13:01:57 --> Form Validation Class Initialized
INFO - 2024-02-27 13:01:57 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:01:57 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:01:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:01:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:01:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:01:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:01:57 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:01:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:01:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:01:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:01:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:01:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:01:57 --> Final output sent to browser
DEBUG - 2024-02-27 13:01:57 --> Total execution time: 0.0318
ERROR - 2024-02-27 13:02:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:02:03 --> Config Class Initialized
INFO - 2024-02-27 13:02:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:02:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:02:03 --> Utf8 Class Initialized
INFO - 2024-02-27 13:02:03 --> URI Class Initialized
INFO - 2024-02-27 13:02:03 --> Router Class Initialized
INFO - 2024-02-27 13:02:03 --> Output Class Initialized
INFO - 2024-02-27 13:02:03 --> Security Class Initialized
DEBUG - 2024-02-27 13:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:02:03 --> Input Class Initialized
INFO - 2024-02-27 13:02:03 --> Language Class Initialized
INFO - 2024-02-27 13:02:03 --> Loader Class Initialized
INFO - 2024-02-27 13:02:03 --> Helper loaded: url_helper
INFO - 2024-02-27 13:02:03 --> Helper loaded: file_helper
INFO - 2024-02-27 13:02:03 --> Helper loaded: form_helper
INFO - 2024-02-27 13:02:03 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:02:03 --> Controller Class Initialized
INFO - 2024-02-27 13:02:03 --> Form Validation Class Initialized
INFO - 2024-02-27 13:02:03 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:02:03 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:02:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:02:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:02:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:02:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:02:03 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:02:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:02:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:02:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:02:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:02:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:02:03 --> Final output sent to browser
DEBUG - 2024-02-27 13:02:03 --> Total execution time: 0.0298
ERROR - 2024-02-27 13:05:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:05:43 --> Config Class Initialized
INFO - 2024-02-27 13:05:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:05:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:05:43 --> Utf8 Class Initialized
INFO - 2024-02-27 13:05:43 --> URI Class Initialized
INFO - 2024-02-27 13:05:43 --> Router Class Initialized
INFO - 2024-02-27 13:05:43 --> Output Class Initialized
INFO - 2024-02-27 13:05:43 --> Security Class Initialized
DEBUG - 2024-02-27 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:05:43 --> Input Class Initialized
INFO - 2024-02-27 13:05:43 --> Language Class Initialized
INFO - 2024-02-27 13:05:43 --> Loader Class Initialized
INFO - 2024-02-27 13:05:43 --> Helper loaded: url_helper
INFO - 2024-02-27 13:05:43 --> Helper loaded: file_helper
INFO - 2024-02-27 13:05:43 --> Helper loaded: form_helper
INFO - 2024-02-27 13:05:43 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:05:43 --> Controller Class Initialized
INFO - 2024-02-27 13:05:43 --> Form Validation Class Initialized
INFO - 2024-02-27 13:05:43 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:05:43 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:05:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:05:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:05:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:05:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:05:43 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:05:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:05:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:05:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:05:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:05:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:05:43 --> Final output sent to browser
DEBUG - 2024-02-27 13:05:43 --> Total execution time: 0.0315
ERROR - 2024-02-27 13:08:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:08:04 --> Config Class Initialized
INFO - 2024-02-27 13:08:04 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:08:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:08:04 --> Utf8 Class Initialized
INFO - 2024-02-27 13:08:04 --> URI Class Initialized
INFO - 2024-02-27 13:08:04 --> Router Class Initialized
INFO - 2024-02-27 13:08:04 --> Output Class Initialized
INFO - 2024-02-27 13:08:04 --> Security Class Initialized
DEBUG - 2024-02-27 13:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:08:04 --> Input Class Initialized
INFO - 2024-02-27 13:08:04 --> Language Class Initialized
INFO - 2024-02-27 13:08:04 --> Loader Class Initialized
INFO - 2024-02-27 13:08:04 --> Helper loaded: url_helper
INFO - 2024-02-27 13:08:04 --> Helper loaded: file_helper
INFO - 2024-02-27 13:08:04 --> Helper loaded: form_helper
INFO - 2024-02-27 13:08:04 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:08:04 --> Controller Class Initialized
INFO - 2024-02-27 13:08:04 --> Form Validation Class Initialized
INFO - 2024-02-27 13:08:04 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:08:04 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:08:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:08:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:08:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:08:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:08:04 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:08:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:08:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:08:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:08:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:08:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:08:04 --> Final output sent to browser
DEBUG - 2024-02-27 13:08:04 --> Total execution time: 0.0365
ERROR - 2024-02-27 13:08:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:08:05 --> Config Class Initialized
INFO - 2024-02-27 13:08:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:08:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:08:05 --> Utf8 Class Initialized
INFO - 2024-02-27 13:08:05 --> URI Class Initialized
INFO - 2024-02-27 13:08:05 --> Router Class Initialized
INFO - 2024-02-27 13:08:05 --> Output Class Initialized
INFO - 2024-02-27 13:08:05 --> Security Class Initialized
DEBUG - 2024-02-27 13:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:08:05 --> Input Class Initialized
INFO - 2024-02-27 13:08:05 --> Language Class Initialized
INFO - 2024-02-27 13:08:05 --> Loader Class Initialized
INFO - 2024-02-27 13:08:05 --> Helper loaded: url_helper
INFO - 2024-02-27 13:08:05 --> Helper loaded: file_helper
INFO - 2024-02-27 13:08:05 --> Helper loaded: form_helper
INFO - 2024-02-27 13:08:05 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:08:05 --> Controller Class Initialized
INFO - 2024-02-27 13:08:05 --> Form Validation Class Initialized
INFO - 2024-02-27 13:08:05 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:08:05 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:08:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:08:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:08:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:08:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:08:05 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:08:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:08:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:08:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:08:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:08:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:08:05 --> Final output sent to browser
DEBUG - 2024-02-27 13:08:05 --> Total execution time: 0.0343
ERROR - 2024-02-27 13:32:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:32:08 --> Config Class Initialized
INFO - 2024-02-27 13:32:08 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:32:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:32:08 --> Utf8 Class Initialized
INFO - 2024-02-27 13:32:08 --> URI Class Initialized
INFO - 2024-02-27 13:32:08 --> Router Class Initialized
INFO - 2024-02-27 13:32:08 --> Output Class Initialized
INFO - 2024-02-27 13:32:08 --> Security Class Initialized
DEBUG - 2024-02-27 13:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:32:08 --> Input Class Initialized
INFO - 2024-02-27 13:32:08 --> Language Class Initialized
INFO - 2024-02-27 13:32:08 --> Loader Class Initialized
INFO - 2024-02-27 13:32:08 --> Helper loaded: url_helper
INFO - 2024-02-27 13:32:08 --> Helper loaded: file_helper
INFO - 2024-02-27 13:32:08 --> Helper loaded: form_helper
INFO - 2024-02-27 13:32:08 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:32:08 --> Controller Class Initialized
INFO - 2024-02-27 13:32:08 --> Form Validation Class Initialized
INFO - 2024-02-27 13:32:08 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:32:08 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:32:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:32:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:32:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:32:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:32:08 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:32:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:32:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:32:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:32:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:32:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:32:08 --> Final output sent to browser
DEBUG - 2024-02-27 13:32:08 --> Total execution time: 0.0472
ERROR - 2024-02-27 13:32:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:32:28 --> Config Class Initialized
INFO - 2024-02-27 13:32:28 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:32:28 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:32:28 --> Utf8 Class Initialized
INFO - 2024-02-27 13:32:28 --> URI Class Initialized
INFO - 2024-02-27 13:32:28 --> Router Class Initialized
INFO - 2024-02-27 13:32:28 --> Output Class Initialized
INFO - 2024-02-27 13:32:28 --> Security Class Initialized
DEBUG - 2024-02-27 13:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:32:28 --> Input Class Initialized
INFO - 2024-02-27 13:32:28 --> Language Class Initialized
INFO - 2024-02-27 13:32:28 --> Loader Class Initialized
INFO - 2024-02-27 13:32:28 --> Helper loaded: url_helper
INFO - 2024-02-27 13:32:28 --> Helper loaded: file_helper
INFO - 2024-02-27 13:32:28 --> Helper loaded: form_helper
INFO - 2024-02-27 13:32:28 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:32:28 --> Controller Class Initialized
INFO - 2024-02-27 13:32:28 --> Form Validation Class Initialized
INFO - 2024-02-27 13:32:28 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:32:28 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:32:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:32:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:32:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:32:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:32:28 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:32:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:32:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:32:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:32:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:32:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:32:28 --> Final output sent to browser
DEBUG - 2024-02-27 13:32:28 --> Total execution time: 0.0537
ERROR - 2024-02-27 13:33:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:33:00 --> Config Class Initialized
INFO - 2024-02-27 13:33:00 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:33:00 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:33:00 --> Utf8 Class Initialized
INFO - 2024-02-27 13:33:00 --> URI Class Initialized
INFO - 2024-02-27 13:33:00 --> Router Class Initialized
INFO - 2024-02-27 13:33:00 --> Output Class Initialized
INFO - 2024-02-27 13:33:00 --> Security Class Initialized
DEBUG - 2024-02-27 13:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:33:00 --> Input Class Initialized
INFO - 2024-02-27 13:33:00 --> Language Class Initialized
INFO - 2024-02-27 13:33:00 --> Loader Class Initialized
INFO - 2024-02-27 13:33:00 --> Helper loaded: url_helper
INFO - 2024-02-27 13:33:00 --> Helper loaded: file_helper
INFO - 2024-02-27 13:33:00 --> Helper loaded: form_helper
INFO - 2024-02-27 13:33:00 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:33:00 --> Controller Class Initialized
INFO - 2024-02-27 13:33:00 --> Form Validation Class Initialized
INFO - 2024-02-27 13:33:00 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:33:00 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:33:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:33:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:33:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:33:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:33:00 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:33:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:33:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:33:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:33:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:33:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:33:00 --> Final output sent to browser
DEBUG - 2024-02-27 13:33:00 --> Total execution time: 0.0541
ERROR - 2024-02-27 13:33:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:33:41 --> Config Class Initialized
INFO - 2024-02-27 13:33:41 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:33:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:33:41 --> Utf8 Class Initialized
INFO - 2024-02-27 13:33:41 --> URI Class Initialized
INFO - 2024-02-27 13:33:41 --> Router Class Initialized
INFO - 2024-02-27 13:33:41 --> Output Class Initialized
INFO - 2024-02-27 13:33:41 --> Security Class Initialized
DEBUG - 2024-02-27 13:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:33:41 --> Input Class Initialized
INFO - 2024-02-27 13:33:41 --> Language Class Initialized
INFO - 2024-02-27 13:33:41 --> Loader Class Initialized
INFO - 2024-02-27 13:33:41 --> Helper loaded: url_helper
INFO - 2024-02-27 13:33:41 --> Helper loaded: file_helper
INFO - 2024-02-27 13:33:41 --> Helper loaded: form_helper
INFO - 2024-02-27 13:33:41 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:33:41 --> Controller Class Initialized
INFO - 2024-02-27 13:33:41 --> Form Validation Class Initialized
INFO - 2024-02-27 13:33:41 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:33:41 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:33:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:33:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:33:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:33:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:33:41 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:33:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:33:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:33:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:33:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:33:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:33:41 --> Final output sent to browser
DEBUG - 2024-02-27 13:33:41 --> Total execution time: 0.0474
ERROR - 2024-02-27 13:34:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:37 --> Config Class Initialized
INFO - 2024-02-27 13:34:37 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:37 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:37 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:37 --> URI Class Initialized
INFO - 2024-02-27 13:34:37 --> Router Class Initialized
INFO - 2024-02-27 13:34:37 --> Output Class Initialized
INFO - 2024-02-27 13:34:37 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:37 --> Input Class Initialized
INFO - 2024-02-27 13:34:37 --> Language Class Initialized
INFO - 2024-02-27 13:34:37 --> Loader Class Initialized
INFO - 2024-02-27 13:34:37 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:37 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:37 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:37 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:37 --> Controller Class Initialized
INFO - 2024-02-27 13:34:37 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:37 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:37 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:37 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:37 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:37 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:37 --> Total execution time: 0.0465
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0643
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.1013
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0907
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0901
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0961
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0798
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0697
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0653
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0643
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0578
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0580
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0614
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0411
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0490
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0561
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0490
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0500
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:38 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:38 --> Total execution time: 0.0714
ERROR - 2024-02-27 13:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:38 --> Config Class Initialized
INFO - 2024-02-27 13:34:38 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:38 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:38 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:38 --> URI Class Initialized
INFO - 2024-02-27 13:34:38 --> Router Class Initialized
INFO - 2024-02-27 13:34:38 --> Output Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:38 --> Security Class Initialized
INFO - 2024-02-27 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:38 --> Controller Class Initialized
DEBUG - 2024-02-27 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:38 --> Input Class Initialized
INFO - 2024-02-27 13:34:38 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:38 --> Language Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Loader Class Initialized
INFO - 2024-02-27 13:34:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:38 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.1186
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.1009
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0633
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0598
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0619
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0506
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0456
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0351
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0365
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0457
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0413
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0466
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0398
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0338
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0367
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0346
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0351
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0376
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0317
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0468
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0416
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0393
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0372
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0467
ERROR - 2024-02-27 13:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
INFO - 2024-02-27 13:34:39 --> Config Class Initialized
INFO - 2024-02-27 13:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:34:39 --> Utf8 Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> URI Class Initialized
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Router Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Output Class Initialized
INFO - 2024-02-27 13:34:39 --> Security Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
DEBUG - 2024-02-27 13:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:34:39 --> Input Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Language Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> Loader Class Initialized
INFO - 2024-02-27 13:34:39 --> Helper loaded: url_helper
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0438
INFO - 2024-02-27 13:34:39 --> Helper loaded: file_helper
INFO - 2024-02-27 13:34:39 --> Helper loaded: form_helper
INFO - 2024-02-27 13:34:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:34:39 --> Controller Class Initialized
INFO - 2024-02-27 13:34:39 --> Form Validation Class Initialized
INFO - 2024-02-27 13:34:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:34:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:34:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:34:39 --> Final output sent to browser
DEBUG - 2024-02-27 13:34:39 --> Total execution time: 0.0365
ERROR - 2024-02-27 13:40:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:40:18 --> Config Class Initialized
INFO - 2024-02-27 13:40:18 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:40:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:40:18 --> Utf8 Class Initialized
INFO - 2024-02-27 13:40:18 --> URI Class Initialized
INFO - 2024-02-27 13:40:18 --> Router Class Initialized
INFO - 2024-02-27 13:40:18 --> Output Class Initialized
INFO - 2024-02-27 13:40:18 --> Security Class Initialized
DEBUG - 2024-02-27 13:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:40:18 --> Input Class Initialized
INFO - 2024-02-27 13:40:18 --> Language Class Initialized
INFO - 2024-02-27 13:40:18 --> Loader Class Initialized
INFO - 2024-02-27 13:40:18 --> Helper loaded: url_helper
INFO - 2024-02-27 13:40:18 --> Helper loaded: file_helper
INFO - 2024-02-27 13:40:18 --> Helper loaded: form_helper
INFO - 2024-02-27 13:40:18 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:40:18 --> Controller Class Initialized
INFO - 2024-02-27 13:40:18 --> Form Validation Class Initialized
INFO - 2024-02-27 13:40:18 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:40:18 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:40:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:40:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:40:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:40:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:40:18 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:40:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:40:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:40:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:40:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:40:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:40:18 --> Final output sent to browser
DEBUG - 2024-02-27 13:40:18 --> Total execution time: 0.0461
ERROR - 2024-02-27 13:40:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:40:23 --> Config Class Initialized
INFO - 2024-02-27 13:40:23 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:40:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:40:23 --> Utf8 Class Initialized
INFO - 2024-02-27 13:40:23 --> URI Class Initialized
INFO - 2024-02-27 13:40:23 --> Router Class Initialized
INFO - 2024-02-27 13:40:23 --> Output Class Initialized
INFO - 2024-02-27 13:40:23 --> Security Class Initialized
DEBUG - 2024-02-27 13:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:40:23 --> Input Class Initialized
INFO - 2024-02-27 13:40:23 --> Language Class Initialized
INFO - 2024-02-27 13:40:23 --> Loader Class Initialized
INFO - 2024-02-27 13:40:23 --> Helper loaded: url_helper
INFO - 2024-02-27 13:40:23 --> Helper loaded: file_helper
INFO - 2024-02-27 13:40:23 --> Helper loaded: form_helper
INFO - 2024-02-27 13:40:23 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:40:23 --> Controller Class Initialized
INFO - 2024-02-27 13:40:23 --> Form Validation Class Initialized
INFO - 2024-02-27 13:40:23 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:40:23 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:40:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:40:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:40:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:40:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:40:23 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:40:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:40:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:40:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:40:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:40:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:40:23 --> Final output sent to browser
DEBUG - 2024-02-27 13:40:23 --> Total execution time: 0.0533
ERROR - 2024-02-27 13:41:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:41:00 --> Config Class Initialized
INFO - 2024-02-27 13:41:00 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:41:00 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:41:00 --> Utf8 Class Initialized
INFO - 2024-02-27 13:41:00 --> URI Class Initialized
INFO - 2024-02-27 13:41:00 --> Router Class Initialized
INFO - 2024-02-27 13:41:00 --> Output Class Initialized
INFO - 2024-02-27 13:41:00 --> Security Class Initialized
DEBUG - 2024-02-27 13:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:41:00 --> Input Class Initialized
INFO - 2024-02-27 13:41:00 --> Language Class Initialized
INFO - 2024-02-27 13:41:00 --> Loader Class Initialized
INFO - 2024-02-27 13:41:00 --> Helper loaded: url_helper
INFO - 2024-02-27 13:41:00 --> Helper loaded: file_helper
INFO - 2024-02-27 13:41:00 --> Helper loaded: form_helper
INFO - 2024-02-27 13:41:00 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:41:00 --> Controller Class Initialized
INFO - 2024-02-27 13:41:00 --> Form Validation Class Initialized
INFO - 2024-02-27 13:41:00 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:41:00 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:41:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:41:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:41:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:41:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:41:00 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:41:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:41:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:41:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:41:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:41:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:41:00 --> Final output sent to browser
DEBUG - 2024-02-27 13:41:00 --> Total execution time: 0.0588
ERROR - 2024-02-27 13:41:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:41:13 --> Config Class Initialized
INFO - 2024-02-27 13:41:13 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:41:13 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:41:13 --> Utf8 Class Initialized
INFO - 2024-02-27 13:41:13 --> URI Class Initialized
INFO - 2024-02-27 13:41:13 --> Router Class Initialized
INFO - 2024-02-27 13:41:13 --> Output Class Initialized
INFO - 2024-02-27 13:41:13 --> Security Class Initialized
DEBUG - 2024-02-27 13:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:41:13 --> Input Class Initialized
INFO - 2024-02-27 13:41:13 --> Language Class Initialized
INFO - 2024-02-27 13:41:13 --> Loader Class Initialized
INFO - 2024-02-27 13:41:13 --> Helper loaded: url_helper
INFO - 2024-02-27 13:41:13 --> Helper loaded: file_helper
INFO - 2024-02-27 13:41:13 --> Helper loaded: form_helper
INFO - 2024-02-27 13:41:13 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:41:13 --> Controller Class Initialized
INFO - 2024-02-27 13:41:13 --> Form Validation Class Initialized
INFO - 2024-02-27 13:41:13 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:41:13 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:41:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:41:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:41:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:41:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:41:13 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:41:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:41:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:41:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:41:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:41:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:41:13 --> Final output sent to browser
DEBUG - 2024-02-27 13:41:13 --> Total execution time: 0.0363
ERROR - 2024-02-27 13:42:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:42:10 --> Config Class Initialized
INFO - 2024-02-27 13:42:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:42:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:42:10 --> Utf8 Class Initialized
INFO - 2024-02-27 13:42:10 --> URI Class Initialized
INFO - 2024-02-27 13:42:10 --> Router Class Initialized
INFO - 2024-02-27 13:42:10 --> Output Class Initialized
INFO - 2024-02-27 13:42:10 --> Security Class Initialized
DEBUG - 2024-02-27 13:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:42:10 --> Input Class Initialized
INFO - 2024-02-27 13:42:10 --> Language Class Initialized
INFO - 2024-02-27 13:42:10 --> Loader Class Initialized
INFO - 2024-02-27 13:42:10 --> Helper loaded: url_helper
INFO - 2024-02-27 13:42:10 --> Helper loaded: file_helper
INFO - 2024-02-27 13:42:10 --> Helper loaded: form_helper
INFO - 2024-02-27 13:42:10 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:42:10 --> Controller Class Initialized
INFO - 2024-02-27 13:42:10 --> Form Validation Class Initialized
INFO - 2024-02-27 13:42:10 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:42:10 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:42:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:42:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:42:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:42:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:42:10 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:42:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:42:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:42:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:42:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:42:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:42:10 --> Final output sent to browser
DEBUG - 2024-02-27 13:42:10 --> Total execution time: 0.0483
ERROR - 2024-02-27 13:42:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:42:35 --> Config Class Initialized
INFO - 2024-02-27 13:42:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:42:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:42:35 --> Utf8 Class Initialized
INFO - 2024-02-27 13:42:35 --> URI Class Initialized
INFO - 2024-02-27 13:42:35 --> Router Class Initialized
INFO - 2024-02-27 13:42:35 --> Output Class Initialized
INFO - 2024-02-27 13:42:35 --> Security Class Initialized
DEBUG - 2024-02-27 13:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:42:35 --> Input Class Initialized
INFO - 2024-02-27 13:42:35 --> Language Class Initialized
INFO - 2024-02-27 13:42:35 --> Loader Class Initialized
INFO - 2024-02-27 13:42:35 --> Helper loaded: url_helper
INFO - 2024-02-27 13:42:35 --> Helper loaded: file_helper
INFO - 2024-02-27 13:42:35 --> Helper loaded: form_helper
INFO - 2024-02-27 13:42:35 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:42:35 --> Controller Class Initialized
INFO - 2024-02-27 13:42:35 --> Form Validation Class Initialized
INFO - 2024-02-27 13:42:35 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:42:35 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:42:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:42:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:42:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:42:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:42:35 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:42:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:42:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:42:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:42:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:42:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:42:35 --> Final output sent to browser
DEBUG - 2024-02-27 13:42:35 --> Total execution time: 0.0454
ERROR - 2024-02-27 13:43:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:43:28 --> Config Class Initialized
INFO - 2024-02-27 13:43:28 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:43:28 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:43:28 --> Utf8 Class Initialized
INFO - 2024-02-27 13:43:28 --> URI Class Initialized
INFO - 2024-02-27 13:43:28 --> Router Class Initialized
INFO - 2024-02-27 13:43:28 --> Output Class Initialized
INFO - 2024-02-27 13:43:28 --> Security Class Initialized
DEBUG - 2024-02-27 13:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:43:28 --> Input Class Initialized
INFO - 2024-02-27 13:43:28 --> Language Class Initialized
INFO - 2024-02-27 13:43:28 --> Loader Class Initialized
INFO - 2024-02-27 13:43:28 --> Helper loaded: url_helper
INFO - 2024-02-27 13:43:28 --> Helper loaded: file_helper
INFO - 2024-02-27 13:43:28 --> Helper loaded: form_helper
INFO - 2024-02-27 13:43:28 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:43:28 --> Controller Class Initialized
INFO - 2024-02-27 13:43:28 --> Form Validation Class Initialized
INFO - 2024-02-27 13:43:28 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:43:28 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:43:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:43:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:43:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:43:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:43:28 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:43:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:43:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:43:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:43:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:43:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:43:28 --> Final output sent to browser
DEBUG - 2024-02-27 13:43:28 --> Total execution time: 0.0517
ERROR - 2024-02-27 13:43:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:43:40 --> Config Class Initialized
INFO - 2024-02-27 13:43:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:43:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:43:40 --> Utf8 Class Initialized
INFO - 2024-02-27 13:43:40 --> URI Class Initialized
INFO - 2024-02-27 13:43:40 --> Router Class Initialized
INFO - 2024-02-27 13:43:40 --> Output Class Initialized
INFO - 2024-02-27 13:43:40 --> Security Class Initialized
DEBUG - 2024-02-27 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:43:40 --> Input Class Initialized
INFO - 2024-02-27 13:43:40 --> Language Class Initialized
INFO - 2024-02-27 13:43:40 --> Loader Class Initialized
INFO - 2024-02-27 13:43:40 --> Helper loaded: url_helper
INFO - 2024-02-27 13:43:40 --> Helper loaded: file_helper
INFO - 2024-02-27 13:43:40 --> Helper loaded: form_helper
INFO - 2024-02-27 13:43:40 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:43:40 --> Controller Class Initialized
INFO - 2024-02-27 13:43:40 --> Form Validation Class Initialized
INFO - 2024-02-27 13:43:40 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:43:40 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:43:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:43:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:43:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:43:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:43:40 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:43:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:43:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:43:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:43:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:43:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:43:40 --> Final output sent to browser
DEBUG - 2024-02-27 13:43:40 --> Total execution time: 0.0559
ERROR - 2024-02-27 13:44:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:44:21 --> Config Class Initialized
INFO - 2024-02-27 13:44:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:44:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:44:21 --> Utf8 Class Initialized
INFO - 2024-02-27 13:44:21 --> URI Class Initialized
INFO - 2024-02-27 13:44:21 --> Router Class Initialized
INFO - 2024-02-27 13:44:21 --> Output Class Initialized
INFO - 2024-02-27 13:44:21 --> Security Class Initialized
DEBUG - 2024-02-27 13:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:44:21 --> Input Class Initialized
INFO - 2024-02-27 13:44:21 --> Language Class Initialized
INFO - 2024-02-27 13:44:21 --> Loader Class Initialized
INFO - 2024-02-27 13:44:21 --> Helper loaded: url_helper
INFO - 2024-02-27 13:44:21 --> Helper loaded: file_helper
INFO - 2024-02-27 13:44:21 --> Helper loaded: form_helper
INFO - 2024-02-27 13:44:21 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:44:21 --> Controller Class Initialized
INFO - 2024-02-27 13:44:21 --> Form Validation Class Initialized
INFO - 2024-02-27 13:44:21 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:44:21 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:44:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:44:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:44:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:44:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:44:21 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:44:21 --> Final output sent to browser
DEBUG - 2024-02-27 13:44:21 --> Total execution time: 0.0444
ERROR - 2024-02-27 13:44:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:44:25 --> Config Class Initialized
INFO - 2024-02-27 13:44:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:44:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:44:25 --> Utf8 Class Initialized
INFO - 2024-02-27 13:44:25 --> URI Class Initialized
INFO - 2024-02-27 13:44:25 --> Router Class Initialized
INFO - 2024-02-27 13:44:25 --> Output Class Initialized
INFO - 2024-02-27 13:44:25 --> Security Class Initialized
DEBUG - 2024-02-27 13:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:44:25 --> Input Class Initialized
INFO - 2024-02-27 13:44:25 --> Language Class Initialized
INFO - 2024-02-27 13:44:25 --> Loader Class Initialized
INFO - 2024-02-27 13:44:25 --> Helper loaded: url_helper
INFO - 2024-02-27 13:44:25 --> Helper loaded: file_helper
INFO - 2024-02-27 13:44:25 --> Helper loaded: form_helper
INFO - 2024-02-27 13:44:25 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:44:25 --> Controller Class Initialized
INFO - 2024-02-27 13:44:25 --> Form Validation Class Initialized
INFO - 2024-02-27 13:44:25 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:44:25 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:44:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:44:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:44:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:44:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:44:25 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:44:25 --> Final output sent to browser
DEBUG - 2024-02-27 13:44:25 --> Total execution time: 0.0543
ERROR - 2024-02-27 13:45:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:26 --> Config Class Initialized
INFO - 2024-02-27 13:45:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:26 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:26 --> URI Class Initialized
INFO - 2024-02-27 13:45:26 --> Router Class Initialized
INFO - 2024-02-27 13:45:26 --> Output Class Initialized
INFO - 2024-02-27 13:45:26 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:26 --> Input Class Initialized
INFO - 2024-02-27 13:45:26 --> Language Class Initialized
INFO - 2024-02-27 13:45:26 --> Loader Class Initialized
INFO - 2024-02-27 13:45:26 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:26 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:26 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:26 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:26 --> Controller Class Initialized
INFO - 2024-02-27 13:45:26 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:26 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:26 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:26 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:45:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:45:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:45:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:45:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:45:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:45:26 --> Final output sent to browser
DEBUG - 2024-02-27 13:45:26 --> Total execution time: 0.0516
ERROR - 2024-02-27 13:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:29 --> Config Class Initialized
INFO - 2024-02-27 13:45:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:29 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:29 --> URI Class Initialized
INFO - 2024-02-27 13:45:29 --> Router Class Initialized
INFO - 2024-02-27 13:45:29 --> Output Class Initialized
INFO - 2024-02-27 13:45:29 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:29 --> Input Class Initialized
INFO - 2024-02-27 13:45:29 --> Language Class Initialized
INFO - 2024-02-27 13:45:29 --> Loader Class Initialized
INFO - 2024-02-27 13:45:29 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:29 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:29 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:29 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:29 --> Controller Class Initialized
INFO - 2024-02-27 13:45:29 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:29 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:29 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:29 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 13:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 13:45:29 --> Final output sent to browser
DEBUG - 2024-02-27 13:45:29 --> Total execution time: 0.0441
ERROR - 2024-02-27 13:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:29 --> Config Class Initialized
INFO - 2024-02-27 13:45:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:29 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:29 --> URI Class Initialized
INFO - 2024-02-27 13:45:29 --> Router Class Initialized
INFO - 2024-02-27 13:45:29 --> Output Class Initialized
INFO - 2024-02-27 13:45:29 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:29 --> Input Class Initialized
INFO - 2024-02-27 13:45:29 --> Language Class Initialized
INFO - 2024-02-27 13:45:29 --> Loader Class Initialized
INFO - 2024-02-27 13:45:29 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:29 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:29 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:29 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:29 --> Controller Class Initialized
INFO - 2024-02-27 13:45:29 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:29 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:29 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:29 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:31 --> Config Class Initialized
INFO - 2024-02-27 13:45:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:31 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:31 --> URI Class Initialized
INFO - 2024-02-27 13:45:31 --> Router Class Initialized
INFO - 2024-02-27 13:45:31 --> Output Class Initialized
INFO - 2024-02-27 13:45:31 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:31 --> Input Class Initialized
INFO - 2024-02-27 13:45:31 --> Language Class Initialized
INFO - 2024-02-27 13:45:31 --> Loader Class Initialized
INFO - 2024-02-27 13:45:31 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:31 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:31 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:31 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:31 --> Controller Class Initialized
INFO - 2024-02-27 13:45:31 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:31 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:31 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:31 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:45:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:45:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:45:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:45:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:45:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-27 13:45:31 --> Final output sent to browser
DEBUG - 2024-02-27 13:45:31 --> Total execution time: 0.0434
ERROR - 2024-02-27 13:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:31 --> Config Class Initialized
INFO - 2024-02-27 13:45:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:31 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:31 --> URI Class Initialized
INFO - 2024-02-27 13:45:31 --> Router Class Initialized
INFO - 2024-02-27 13:45:31 --> Output Class Initialized
INFO - 2024-02-27 13:45:31 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:31 --> Input Class Initialized
INFO - 2024-02-27 13:45:31 --> Language Class Initialized
INFO - 2024-02-27 13:45:31 --> Loader Class Initialized
INFO - 2024-02-27 13:45:31 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:31 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:31 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:31 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:31 --> Controller Class Initialized
INFO - 2024-02-27 13:45:31 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:31 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:31 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:31 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:45:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:34 --> Config Class Initialized
INFO - 2024-02-27 13:45:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:34 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:34 --> URI Class Initialized
INFO - 2024-02-27 13:45:34 --> Router Class Initialized
INFO - 2024-02-27 13:45:34 --> Output Class Initialized
INFO - 2024-02-27 13:45:34 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:34 --> Input Class Initialized
INFO - 2024-02-27 13:45:34 --> Language Class Initialized
INFO - 2024-02-27 13:45:34 --> Loader Class Initialized
INFO - 2024-02-27 13:45:34 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:34 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:34 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:34 --> Controller Class Initialized
INFO - 2024-02-27 13:45:34 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:34 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-27 13:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-27 13:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-27 13:45:34 --> Final output sent to browser
DEBUG - 2024-02-27 13:45:34 --> Total execution time: 0.0449
ERROR - 2024-02-27 13:45:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:34 --> Config Class Initialized
INFO - 2024-02-27 13:45:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:34 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:34 --> URI Class Initialized
INFO - 2024-02-27 13:45:34 --> Router Class Initialized
INFO - 2024-02-27 13:45:34 --> Output Class Initialized
INFO - 2024-02-27 13:45:34 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:34 --> Input Class Initialized
INFO - 2024-02-27 13:45:34 --> Language Class Initialized
INFO - 2024-02-27 13:45:34 --> Loader Class Initialized
INFO - 2024-02-27 13:45:34 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:34 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:34 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:34 --> Controller Class Initialized
INFO - 2024-02-27 13:45:34 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:34 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:45:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:41 --> Config Class Initialized
INFO - 2024-02-27 13:45:41 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:41 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:41 --> URI Class Initialized
INFO - 2024-02-27 13:45:41 --> Router Class Initialized
INFO - 2024-02-27 13:45:41 --> Output Class Initialized
INFO - 2024-02-27 13:45:41 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:41 --> Input Class Initialized
INFO - 2024-02-27 13:45:41 --> Language Class Initialized
INFO - 2024-02-27 13:45:41 --> Loader Class Initialized
INFO - 2024-02-27 13:45:41 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:41 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:41 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:41 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:41 --> Controller Class Initialized
INFO - 2024-02-27 13:45:41 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:41 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:41 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:41 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:45:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:43 --> Config Class Initialized
INFO - 2024-02-27 13:45:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:43 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:43 --> URI Class Initialized
INFO - 2024-02-27 13:45:43 --> Router Class Initialized
INFO - 2024-02-27 13:45:43 --> Output Class Initialized
INFO - 2024-02-27 13:45:43 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:43 --> Input Class Initialized
INFO - 2024-02-27 13:45:43 --> Language Class Initialized
INFO - 2024-02-27 13:45:43 --> Loader Class Initialized
INFO - 2024-02-27 13:45:43 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:43 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:43 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:43 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:43 --> Controller Class Initialized
INFO - 2024-02-27 13:45:43 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:43 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:43 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:43 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:45:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:46 --> Config Class Initialized
INFO - 2024-02-27 13:45:46 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:46 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:46 --> URI Class Initialized
INFO - 2024-02-27 13:45:46 --> Router Class Initialized
INFO - 2024-02-27 13:45:46 --> Output Class Initialized
INFO - 2024-02-27 13:45:46 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:46 --> Input Class Initialized
INFO - 2024-02-27 13:45:46 --> Language Class Initialized
INFO - 2024-02-27 13:45:46 --> Loader Class Initialized
INFO - 2024-02-27 13:45:46 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:46 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:46 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:46 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:46 --> Controller Class Initialized
INFO - 2024-02-27 13:45:46 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:46 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:46 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:46 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:45:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:48 --> Config Class Initialized
INFO - 2024-02-27 13:45:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:48 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:48 --> URI Class Initialized
INFO - 2024-02-27 13:45:48 --> Router Class Initialized
INFO - 2024-02-27 13:45:48 --> Output Class Initialized
INFO - 2024-02-27 13:45:48 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:48 --> Input Class Initialized
INFO - 2024-02-27 13:45:48 --> Language Class Initialized
INFO - 2024-02-27 13:45:48 --> Loader Class Initialized
INFO - 2024-02-27 13:45:48 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:48 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:48 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:48 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:48 --> Controller Class Initialized
INFO - 2024-02-27 13:45:48 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:48 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:48 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:48 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:45:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:45:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:45:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:45:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:45:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-02-27 13:45:48 --> Final output sent to browser
DEBUG - 2024-02-27 13:45:48 --> Total execution time: 0.0424
ERROR - 2024-02-27 13:45:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:48 --> Config Class Initialized
INFO - 2024-02-27 13:45:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:48 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:48 --> URI Class Initialized
INFO - 2024-02-27 13:45:48 --> Router Class Initialized
INFO - 2024-02-27 13:45:48 --> Output Class Initialized
INFO - 2024-02-27 13:45:48 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:48 --> Input Class Initialized
INFO - 2024-02-27 13:45:48 --> Language Class Initialized
INFO - 2024-02-27 13:45:48 --> Loader Class Initialized
INFO - 2024-02-27 13:45:48 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:48 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:48 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:48 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:48 --> Controller Class Initialized
INFO - 2024-02-27 13:45:48 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:48 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:48 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:48 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:45:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:45:52 --> Config Class Initialized
INFO - 2024-02-27 13:45:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:45:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:45:52 --> Utf8 Class Initialized
INFO - 2024-02-27 13:45:52 --> URI Class Initialized
INFO - 2024-02-27 13:45:52 --> Router Class Initialized
INFO - 2024-02-27 13:45:52 --> Output Class Initialized
INFO - 2024-02-27 13:45:52 --> Security Class Initialized
DEBUG - 2024-02-27 13:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:45:52 --> Input Class Initialized
INFO - 2024-02-27 13:45:52 --> Language Class Initialized
INFO - 2024-02-27 13:45:52 --> Loader Class Initialized
INFO - 2024-02-27 13:45:52 --> Helper loaded: url_helper
INFO - 2024-02-27 13:45:52 --> Helper loaded: file_helper
INFO - 2024-02-27 13:45:52 --> Helper loaded: form_helper
INFO - 2024-02-27 13:45:52 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:45:52 --> Controller Class Initialized
INFO - 2024-02-27 13:45:52 --> Form Validation Class Initialized
INFO - 2024-02-27 13:45:52 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:45:52 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:45:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:45:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:45:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:45:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:45:52 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:48:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:48:25 --> Config Class Initialized
INFO - 2024-02-27 13:48:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:48:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:48:25 --> Utf8 Class Initialized
INFO - 2024-02-27 13:48:25 --> URI Class Initialized
INFO - 2024-02-27 13:48:25 --> Router Class Initialized
INFO - 2024-02-27 13:48:25 --> Output Class Initialized
INFO - 2024-02-27 13:48:25 --> Security Class Initialized
DEBUG - 2024-02-27 13:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:48:25 --> Input Class Initialized
INFO - 2024-02-27 13:48:25 --> Language Class Initialized
INFO - 2024-02-27 13:48:25 --> Loader Class Initialized
INFO - 2024-02-27 13:48:25 --> Helper loaded: url_helper
INFO - 2024-02-27 13:48:25 --> Helper loaded: file_helper
INFO - 2024-02-27 13:48:25 --> Helper loaded: form_helper
INFO - 2024-02-27 13:48:25 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:48:25 --> Controller Class Initialized
INFO - 2024-02-27 13:48:25 --> Form Validation Class Initialized
INFO - 2024-02-27 13:48:25 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:48:25 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:48:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:48:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:48:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:48:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:48:25 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:48:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:48:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:48:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:48:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:48:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-02-27 13:48:25 --> Final output sent to browser
DEBUG - 2024-02-27 13:48:25 --> Total execution time: 0.0428
ERROR - 2024-02-27 13:48:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:48:26 --> Config Class Initialized
INFO - 2024-02-27 13:48:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:48:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:48:26 --> Utf8 Class Initialized
INFO - 2024-02-27 13:48:26 --> URI Class Initialized
INFO - 2024-02-27 13:48:26 --> Router Class Initialized
INFO - 2024-02-27 13:48:26 --> Output Class Initialized
INFO - 2024-02-27 13:48:26 --> Security Class Initialized
DEBUG - 2024-02-27 13:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:48:26 --> Input Class Initialized
INFO - 2024-02-27 13:48:26 --> Language Class Initialized
INFO - 2024-02-27 13:48:26 --> Loader Class Initialized
INFO - 2024-02-27 13:48:26 --> Helper loaded: url_helper
INFO - 2024-02-27 13:48:26 --> Helper loaded: file_helper
INFO - 2024-02-27 13:48:26 --> Helper loaded: form_helper
INFO - 2024-02-27 13:48:27 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:48:27 --> Controller Class Initialized
INFO - 2024-02-27 13:48:27 --> Form Validation Class Initialized
INFO - 2024-02-27 13:48:27 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:48:27 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:48:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:48:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:48:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:48:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:48:27 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:49:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:49:04 --> Config Class Initialized
INFO - 2024-02-27 13:49:04 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:49:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:49:04 --> Utf8 Class Initialized
INFO - 2024-02-27 13:49:04 --> URI Class Initialized
INFO - 2024-02-27 13:49:04 --> Router Class Initialized
INFO - 2024-02-27 13:49:04 --> Output Class Initialized
INFO - 2024-02-27 13:49:04 --> Security Class Initialized
DEBUG - 2024-02-27 13:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:49:04 --> Input Class Initialized
INFO - 2024-02-27 13:49:04 --> Language Class Initialized
INFO - 2024-02-27 13:49:04 --> Loader Class Initialized
INFO - 2024-02-27 13:49:04 --> Helper loaded: url_helper
INFO - 2024-02-27 13:49:04 --> Helper loaded: file_helper
INFO - 2024-02-27 13:49:04 --> Helper loaded: form_helper
INFO - 2024-02-27 13:49:04 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:49:04 --> Controller Class Initialized
INFO - 2024-02-27 13:49:04 --> Form Validation Class Initialized
INFO - 2024-02-27 13:49:04 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:49:04 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:49:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:49:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:49:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:49:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:49:04 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:49:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:49:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:49:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:49:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:49:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-02-27 13:49:04 --> Final output sent to browser
DEBUG - 2024-02-27 13:49:04 --> Total execution time: 0.0419
ERROR - 2024-02-27 13:49:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:49:05 --> Config Class Initialized
INFO - 2024-02-27 13:49:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:49:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:49:05 --> Utf8 Class Initialized
INFO - 2024-02-27 13:49:05 --> URI Class Initialized
INFO - 2024-02-27 13:49:05 --> Router Class Initialized
INFO - 2024-02-27 13:49:05 --> Output Class Initialized
INFO - 2024-02-27 13:49:05 --> Security Class Initialized
DEBUG - 2024-02-27 13:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:49:05 --> Input Class Initialized
INFO - 2024-02-27 13:49:05 --> Language Class Initialized
INFO - 2024-02-27 13:49:05 --> Loader Class Initialized
INFO - 2024-02-27 13:49:05 --> Helper loaded: url_helper
INFO - 2024-02-27 13:49:05 --> Helper loaded: file_helper
INFO - 2024-02-27 13:49:05 --> Helper loaded: form_helper
INFO - 2024-02-27 13:49:05 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:49:05 --> Controller Class Initialized
INFO - 2024-02-27 13:49:05 --> Form Validation Class Initialized
INFO - 2024-02-27 13:49:05 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:49:05 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:49:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:49:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:49:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:49:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:49:05 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:50:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:50:33 --> Config Class Initialized
INFO - 2024-02-27 13:50:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:50:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:50:33 --> Utf8 Class Initialized
INFO - 2024-02-27 13:50:33 --> URI Class Initialized
INFO - 2024-02-27 13:50:33 --> Router Class Initialized
INFO - 2024-02-27 13:50:33 --> Output Class Initialized
INFO - 2024-02-27 13:50:33 --> Security Class Initialized
DEBUG - 2024-02-27 13:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:50:33 --> Input Class Initialized
INFO - 2024-02-27 13:50:33 --> Language Class Initialized
INFO - 2024-02-27 13:50:33 --> Loader Class Initialized
INFO - 2024-02-27 13:50:33 --> Helper loaded: url_helper
INFO - 2024-02-27 13:50:33 --> Helper loaded: file_helper
INFO - 2024-02-27 13:50:33 --> Helper loaded: form_helper
INFO - 2024-02-27 13:50:33 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:50:33 --> Controller Class Initialized
INFO - 2024-02-27 13:50:33 --> Form Validation Class Initialized
INFO - 2024-02-27 13:50:33 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:50:33 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:50:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:50:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:50:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:50:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:50:33 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:50:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:50:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:50:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:50:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:50:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-02-27 13:50:33 --> Final output sent to browser
DEBUG - 2024-02-27 13:50:33 --> Total execution time: 0.0477
ERROR - 2024-02-27 13:50:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:50:35 --> Config Class Initialized
INFO - 2024-02-27 13:50:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:50:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:50:35 --> Utf8 Class Initialized
INFO - 2024-02-27 13:50:35 --> URI Class Initialized
INFO - 2024-02-27 13:50:35 --> Router Class Initialized
INFO - 2024-02-27 13:50:35 --> Output Class Initialized
INFO - 2024-02-27 13:50:35 --> Security Class Initialized
DEBUG - 2024-02-27 13:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:50:35 --> Input Class Initialized
INFO - 2024-02-27 13:50:35 --> Language Class Initialized
INFO - 2024-02-27 13:50:35 --> Loader Class Initialized
INFO - 2024-02-27 13:50:35 --> Helper loaded: url_helper
INFO - 2024-02-27 13:50:35 --> Helper loaded: file_helper
INFO - 2024-02-27 13:50:35 --> Helper loaded: form_helper
INFO - 2024-02-27 13:50:35 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:50:35 --> Controller Class Initialized
INFO - 2024-02-27 13:50:35 --> Form Validation Class Initialized
INFO - 2024-02-27 13:50:35 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:50:35 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:50:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:50:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:50:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:50:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:50:35 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:50:40 --> Config Class Initialized
INFO - 2024-02-27 13:50:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:50:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:50:40 --> Utf8 Class Initialized
INFO - 2024-02-27 13:50:40 --> URI Class Initialized
INFO - 2024-02-27 13:50:40 --> Router Class Initialized
INFO - 2024-02-27 13:50:40 --> Output Class Initialized
INFO - 2024-02-27 13:50:40 --> Security Class Initialized
DEBUG - 2024-02-27 13:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:50:40 --> Input Class Initialized
INFO - 2024-02-27 13:50:40 --> Language Class Initialized
INFO - 2024-02-27 13:50:40 --> Loader Class Initialized
INFO - 2024-02-27 13:50:40 --> Helper loaded: url_helper
INFO - 2024-02-27 13:50:40 --> Helper loaded: file_helper
INFO - 2024-02-27 13:50:40 --> Helper loaded: form_helper
INFO - 2024-02-27 13:50:40 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:50:40 --> Controller Class Initialized
INFO - 2024-02-27 13:50:40 --> Form Validation Class Initialized
INFO - 2024-02-27 13:50:40 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:50:40 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:50:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:50:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:50:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:50:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:50:40 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:50:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:50:51 --> Config Class Initialized
INFO - 2024-02-27 13:50:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:50:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:50:51 --> Utf8 Class Initialized
INFO - 2024-02-27 13:50:51 --> URI Class Initialized
INFO - 2024-02-27 13:50:51 --> Router Class Initialized
INFO - 2024-02-27 13:50:51 --> Output Class Initialized
INFO - 2024-02-27 13:50:51 --> Security Class Initialized
DEBUG - 2024-02-27 13:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:50:51 --> Input Class Initialized
INFO - 2024-02-27 13:50:51 --> Language Class Initialized
INFO - 2024-02-27 13:50:51 --> Loader Class Initialized
INFO - 2024-02-27 13:50:51 --> Helper loaded: url_helper
INFO - 2024-02-27 13:50:51 --> Helper loaded: file_helper
INFO - 2024-02-27 13:50:51 --> Helper loaded: form_helper
INFO - 2024-02-27 13:50:51 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:50:51 --> Controller Class Initialized
INFO - 2024-02-27 13:50:51 --> Form Validation Class Initialized
INFO - 2024-02-27 13:50:51 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:50:51 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:50:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:50:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:50:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:50:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:50:51 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:50:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:50:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:50:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:50:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:50:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 13:50:51 --> Final output sent to browser
DEBUG - 2024-02-27 13:50:51 --> Total execution time: 0.0447
ERROR - 2024-02-27 13:50:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:50:55 --> Config Class Initialized
INFO - 2024-02-27 13:50:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:50:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:50:55 --> Utf8 Class Initialized
INFO - 2024-02-27 13:50:55 --> URI Class Initialized
INFO - 2024-02-27 13:50:55 --> Router Class Initialized
INFO - 2024-02-27 13:50:55 --> Output Class Initialized
INFO - 2024-02-27 13:50:55 --> Security Class Initialized
DEBUG - 2024-02-27 13:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:50:55 --> Input Class Initialized
INFO - 2024-02-27 13:50:55 --> Language Class Initialized
INFO - 2024-02-27 13:50:55 --> Loader Class Initialized
INFO - 2024-02-27 13:50:55 --> Helper loaded: url_helper
INFO - 2024-02-27 13:50:55 --> Helper loaded: file_helper
INFO - 2024-02-27 13:50:55 --> Helper loaded: form_helper
INFO - 2024-02-27 13:50:55 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:50:55 --> Controller Class Initialized
INFO - 2024-02-27 13:50:55 --> Form Validation Class Initialized
INFO - 2024-02-27 13:50:55 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:50:55 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:50:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:50:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:50:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:50:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:50:55 --> Model "OrderModel" initialized
INFO - 2024-02-27 13:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 13:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 13:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 13:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 13:50:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-02-27 13:50:55 --> Final output sent to browser
DEBUG - 2024-02-27 13:50:55 --> Total execution time: 0.0429
ERROR - 2024-02-27 13:50:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:50:55 --> Config Class Initialized
INFO - 2024-02-27 13:50:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:50:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:50:55 --> Utf8 Class Initialized
INFO - 2024-02-27 13:50:55 --> URI Class Initialized
INFO - 2024-02-27 13:50:55 --> Router Class Initialized
INFO - 2024-02-27 13:50:55 --> Output Class Initialized
INFO - 2024-02-27 13:50:55 --> Security Class Initialized
DEBUG - 2024-02-27 13:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:50:55 --> Input Class Initialized
INFO - 2024-02-27 13:50:55 --> Language Class Initialized
INFO - 2024-02-27 13:50:55 --> Loader Class Initialized
INFO - 2024-02-27 13:50:55 --> Helper loaded: url_helper
INFO - 2024-02-27 13:50:55 --> Helper loaded: file_helper
INFO - 2024-02-27 13:50:55 --> Helper loaded: form_helper
INFO - 2024-02-27 13:50:55 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:50:55 --> Controller Class Initialized
INFO - 2024-02-27 13:50:55 --> Form Validation Class Initialized
INFO - 2024-02-27 13:50:55 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:50:55 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:50:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:50:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:50:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:50:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:50:55 --> Model "OrderModel" initialized
ERROR - 2024-02-27 13:51:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 13:51:00 --> Config Class Initialized
INFO - 2024-02-27 13:51:00 --> Hooks Class Initialized
DEBUG - 2024-02-27 13:51:00 --> UTF-8 Support Enabled
INFO - 2024-02-27 13:51:00 --> Utf8 Class Initialized
INFO - 2024-02-27 13:51:00 --> URI Class Initialized
INFO - 2024-02-27 13:51:00 --> Router Class Initialized
INFO - 2024-02-27 13:51:00 --> Output Class Initialized
INFO - 2024-02-27 13:51:00 --> Security Class Initialized
DEBUG - 2024-02-27 13:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 13:51:00 --> Input Class Initialized
INFO - 2024-02-27 13:51:00 --> Language Class Initialized
INFO - 2024-02-27 13:51:00 --> Loader Class Initialized
INFO - 2024-02-27 13:51:00 --> Helper loaded: url_helper
INFO - 2024-02-27 13:51:00 --> Helper loaded: file_helper
INFO - 2024-02-27 13:51:00 --> Helper loaded: form_helper
INFO - 2024-02-27 13:51:00 --> Database Driver Class Initialized
DEBUG - 2024-02-27 13:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 13:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 13:51:00 --> Controller Class Initialized
INFO - 2024-02-27 13:51:00 --> Form Validation Class Initialized
INFO - 2024-02-27 13:51:00 --> Model "MasterModel" initialized
INFO - 2024-02-27 13:51:00 --> Model "DashboardModel" initialized
INFO - 2024-02-27 13:51:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 13:51:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 13:51:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 13:51:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 13:51:00 --> Model "OrderModel" initialized
ERROR - 2024-02-27 17:03:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:03:44 --> Config Class Initialized
INFO - 2024-02-27 17:03:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:03:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:03:44 --> Utf8 Class Initialized
INFO - 2024-02-27 17:03:44 --> URI Class Initialized
INFO - 2024-02-27 17:03:44 --> Router Class Initialized
INFO - 2024-02-27 17:03:44 --> Output Class Initialized
INFO - 2024-02-27 17:03:44 --> Security Class Initialized
DEBUG - 2024-02-27 17:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:03:44 --> Input Class Initialized
INFO - 2024-02-27 17:03:44 --> Language Class Initialized
INFO - 2024-02-27 17:03:44 --> Loader Class Initialized
INFO - 2024-02-27 17:03:44 --> Helper loaded: url_helper
INFO - 2024-02-27 17:03:44 --> Helper loaded: file_helper
INFO - 2024-02-27 17:03:45 --> Helper loaded: form_helper
INFO - 2024-02-27 17:03:45 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:03:45 --> Controller Class Initialized
INFO - 2024-02-27 17:03:45 --> Form Validation Class Initialized
INFO - 2024-02-27 17:03:45 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:03:45 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:03:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:03:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:03:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:03:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:03:45 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:03:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:03:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:03:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:03:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:03:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:03:45 --> Final output sent to browser
DEBUG - 2024-02-27 17:03:45 --> Total execution time: 0.0351
ERROR - 2024-02-27 17:03:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:03:50 --> Config Class Initialized
INFO - 2024-02-27 17:03:50 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:03:50 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:03:50 --> Utf8 Class Initialized
INFO - 2024-02-27 17:03:50 --> URI Class Initialized
INFO - 2024-02-27 17:03:50 --> Router Class Initialized
INFO - 2024-02-27 17:03:50 --> Output Class Initialized
INFO - 2024-02-27 17:03:50 --> Security Class Initialized
DEBUG - 2024-02-27 17:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:03:50 --> Input Class Initialized
INFO - 2024-02-27 17:03:50 --> Language Class Initialized
INFO - 2024-02-27 17:03:50 --> Loader Class Initialized
INFO - 2024-02-27 17:03:50 --> Helper loaded: url_helper
INFO - 2024-02-27 17:03:50 --> Helper loaded: file_helper
INFO - 2024-02-27 17:03:50 --> Helper loaded: form_helper
INFO - 2024-02-27 17:03:50 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:03:50 --> Controller Class Initialized
INFO - 2024-02-27 17:03:50 --> Form Validation Class Initialized
INFO - 2024-02-27 17:03:50 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:03:50 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:03:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:03:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:03:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:03:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:03:50 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:03:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:03:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:03:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:03:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:03:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:03:50 --> Final output sent to browser
DEBUG - 2024-02-27 17:03:50 --> Total execution time: 0.0371
ERROR - 2024-02-27 17:06:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:06:45 --> Config Class Initialized
INFO - 2024-02-27 17:06:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:06:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:06:45 --> Utf8 Class Initialized
INFO - 2024-02-27 17:06:45 --> URI Class Initialized
INFO - 2024-02-27 17:06:45 --> Router Class Initialized
INFO - 2024-02-27 17:06:45 --> Output Class Initialized
INFO - 2024-02-27 17:06:45 --> Security Class Initialized
DEBUG - 2024-02-27 17:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:06:45 --> Input Class Initialized
INFO - 2024-02-27 17:06:45 --> Language Class Initialized
INFO - 2024-02-27 17:06:45 --> Loader Class Initialized
INFO - 2024-02-27 17:06:45 --> Helper loaded: url_helper
INFO - 2024-02-27 17:06:45 --> Helper loaded: file_helper
INFO - 2024-02-27 17:06:45 --> Helper loaded: form_helper
INFO - 2024-02-27 17:06:45 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:06:45 --> Controller Class Initialized
INFO - 2024-02-27 17:06:45 --> Form Validation Class Initialized
INFO - 2024-02-27 17:06:45 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:06:45 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:06:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:06:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:06:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:06:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:06:45 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:06:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:06:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:06:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:06:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:06:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:06:45 --> Final output sent to browser
DEBUG - 2024-02-27 17:06:45 --> Total execution time: 0.0306
ERROR - 2024-02-27 17:06:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:06:46 --> Config Class Initialized
INFO - 2024-02-27 17:06:46 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:06:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:06:46 --> Utf8 Class Initialized
INFO - 2024-02-27 17:06:46 --> URI Class Initialized
INFO - 2024-02-27 17:06:46 --> Router Class Initialized
INFO - 2024-02-27 17:06:46 --> Output Class Initialized
INFO - 2024-02-27 17:06:46 --> Security Class Initialized
DEBUG - 2024-02-27 17:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:06:46 --> Input Class Initialized
INFO - 2024-02-27 17:06:46 --> Language Class Initialized
INFO - 2024-02-27 17:06:46 --> Loader Class Initialized
INFO - 2024-02-27 17:06:46 --> Helper loaded: url_helper
INFO - 2024-02-27 17:06:46 --> Helper loaded: file_helper
INFO - 2024-02-27 17:06:46 --> Helper loaded: form_helper
INFO - 2024-02-27 17:06:46 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:06:46 --> Controller Class Initialized
INFO - 2024-02-27 17:06:46 --> Form Validation Class Initialized
INFO - 2024-02-27 17:06:46 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:06:46 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:06:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:06:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:06:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:06:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:06:46 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:06:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:06:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:06:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:06:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:06:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:06:46 --> Final output sent to browser
DEBUG - 2024-02-27 17:06:46 --> Total execution time: 0.0383
ERROR - 2024-02-27 17:10:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:10:31 --> Config Class Initialized
INFO - 2024-02-27 17:10:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:10:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:10:31 --> Utf8 Class Initialized
INFO - 2024-02-27 17:10:31 --> URI Class Initialized
INFO - 2024-02-27 17:10:31 --> Router Class Initialized
INFO - 2024-02-27 17:10:31 --> Output Class Initialized
INFO - 2024-02-27 17:10:31 --> Security Class Initialized
DEBUG - 2024-02-27 17:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:10:31 --> Input Class Initialized
INFO - 2024-02-27 17:10:31 --> Language Class Initialized
INFO - 2024-02-27 17:10:31 --> Loader Class Initialized
INFO - 2024-02-27 17:10:31 --> Helper loaded: url_helper
INFO - 2024-02-27 17:10:31 --> Helper loaded: file_helper
INFO - 2024-02-27 17:10:31 --> Helper loaded: form_helper
INFO - 2024-02-27 17:10:31 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:10:31 --> Controller Class Initialized
INFO - 2024-02-27 17:10:31 --> Form Validation Class Initialized
INFO - 2024-02-27 17:10:31 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:10:31 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:10:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:10:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:10:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:10:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:10:31 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:10:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:10:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:10:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:10:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:10:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:10:31 --> Final output sent to browser
DEBUG - 2024-02-27 17:10:31 --> Total execution time: 0.0446
ERROR - 2024-02-27 17:12:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:12:04 --> Config Class Initialized
INFO - 2024-02-27 17:12:04 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:12:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:12:04 --> Utf8 Class Initialized
INFO - 2024-02-27 17:12:04 --> URI Class Initialized
INFO - 2024-02-27 17:12:04 --> Router Class Initialized
INFO - 2024-02-27 17:12:04 --> Output Class Initialized
INFO - 2024-02-27 17:12:04 --> Security Class Initialized
DEBUG - 2024-02-27 17:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:12:04 --> Input Class Initialized
INFO - 2024-02-27 17:12:04 --> Language Class Initialized
INFO - 2024-02-27 17:12:04 --> Loader Class Initialized
INFO - 2024-02-27 17:12:04 --> Helper loaded: url_helper
INFO - 2024-02-27 17:12:04 --> Helper loaded: file_helper
INFO - 2024-02-27 17:12:04 --> Helper loaded: form_helper
INFO - 2024-02-27 17:12:04 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:12:04 --> Controller Class Initialized
INFO - 2024-02-27 17:12:04 --> Form Validation Class Initialized
INFO - 2024-02-27 17:12:04 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:12:04 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:12:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:12:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:12:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:12:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:12:04 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:12:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:12:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:12:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:12:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:12:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:12:04 --> Final output sent to browser
DEBUG - 2024-02-27 17:12:04 --> Total execution time: 0.0309
ERROR - 2024-02-27 17:12:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:12:40 --> Config Class Initialized
INFO - 2024-02-27 17:12:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:12:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:12:40 --> Utf8 Class Initialized
INFO - 2024-02-27 17:12:40 --> URI Class Initialized
INFO - 2024-02-27 17:12:40 --> Router Class Initialized
INFO - 2024-02-27 17:12:40 --> Output Class Initialized
INFO - 2024-02-27 17:12:40 --> Security Class Initialized
DEBUG - 2024-02-27 17:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:12:40 --> Input Class Initialized
INFO - 2024-02-27 17:12:40 --> Language Class Initialized
INFO - 2024-02-27 17:12:40 --> Loader Class Initialized
INFO - 2024-02-27 17:12:40 --> Helper loaded: url_helper
INFO - 2024-02-27 17:12:40 --> Helper loaded: file_helper
INFO - 2024-02-27 17:12:40 --> Helper loaded: form_helper
INFO - 2024-02-27 17:12:40 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:12:40 --> Controller Class Initialized
INFO - 2024-02-27 17:12:40 --> Form Validation Class Initialized
INFO - 2024-02-27 17:12:40 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:12:40 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:12:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:12:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:12:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:12:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:12:40 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:12:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:12:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:12:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:12:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:12:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:12:40 --> Final output sent to browser
DEBUG - 2024-02-27 17:12:40 --> Total execution time: 0.0370
ERROR - 2024-02-27 17:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:16:01 --> Config Class Initialized
INFO - 2024-02-27 17:16:01 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:16:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:16:01 --> Utf8 Class Initialized
INFO - 2024-02-27 17:16:01 --> URI Class Initialized
INFO - 2024-02-27 17:16:01 --> Router Class Initialized
INFO - 2024-02-27 17:16:01 --> Output Class Initialized
INFO - 2024-02-27 17:16:01 --> Security Class Initialized
DEBUG - 2024-02-27 17:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:16:01 --> Input Class Initialized
INFO - 2024-02-27 17:16:01 --> Language Class Initialized
INFO - 2024-02-27 17:16:01 --> Loader Class Initialized
INFO - 2024-02-27 17:16:01 --> Helper loaded: url_helper
INFO - 2024-02-27 17:16:01 --> Helper loaded: file_helper
INFO - 2024-02-27 17:16:01 --> Helper loaded: form_helper
INFO - 2024-02-27 17:16:01 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:16:01 --> Controller Class Initialized
INFO - 2024-02-27 17:16:01 --> Form Validation Class Initialized
INFO - 2024-02-27 17:16:01 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:16:01 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:16:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:16:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:16:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:16:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:16:01 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:16:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:16:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:16:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:16:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:16:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:16:01 --> Final output sent to browser
DEBUG - 2024-02-27 17:16:01 --> Total execution time: 0.0346
ERROR - 2024-02-27 17:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:16:29 --> Config Class Initialized
INFO - 2024-02-27 17:16:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:16:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:16:29 --> Utf8 Class Initialized
INFO - 2024-02-27 17:16:29 --> URI Class Initialized
INFO - 2024-02-27 17:16:29 --> Router Class Initialized
INFO - 2024-02-27 17:16:29 --> Output Class Initialized
INFO - 2024-02-27 17:16:29 --> Security Class Initialized
DEBUG - 2024-02-27 17:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:16:29 --> Input Class Initialized
INFO - 2024-02-27 17:16:29 --> Language Class Initialized
INFO - 2024-02-27 17:16:29 --> Loader Class Initialized
INFO - 2024-02-27 17:16:29 --> Helper loaded: url_helper
INFO - 2024-02-27 17:16:29 --> Helper loaded: file_helper
INFO - 2024-02-27 17:16:29 --> Helper loaded: form_helper
INFO - 2024-02-27 17:16:29 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:16:29 --> Controller Class Initialized
INFO - 2024-02-27 17:16:29 --> Form Validation Class Initialized
INFO - 2024-02-27 17:16:29 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:16:29 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:16:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:16:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:16:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:16:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:16:29 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:16:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:16:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:16:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:16:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:16:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:16:29 --> Final output sent to browser
DEBUG - 2024-02-27 17:16:29 --> Total execution time: 0.0390
ERROR - 2024-02-27 17:16:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:16:42 --> Config Class Initialized
INFO - 2024-02-27 17:16:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:16:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:16:42 --> Utf8 Class Initialized
INFO - 2024-02-27 17:16:42 --> URI Class Initialized
INFO - 2024-02-27 17:16:42 --> Router Class Initialized
INFO - 2024-02-27 17:16:42 --> Output Class Initialized
INFO - 2024-02-27 17:16:42 --> Security Class Initialized
DEBUG - 2024-02-27 17:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:16:42 --> Input Class Initialized
INFO - 2024-02-27 17:16:42 --> Language Class Initialized
INFO - 2024-02-27 17:16:42 --> Loader Class Initialized
INFO - 2024-02-27 17:16:42 --> Helper loaded: url_helper
INFO - 2024-02-27 17:16:42 --> Helper loaded: file_helper
INFO - 2024-02-27 17:16:42 --> Helper loaded: form_helper
INFO - 2024-02-27 17:16:42 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:16:42 --> Controller Class Initialized
INFO - 2024-02-27 17:16:42 --> Form Validation Class Initialized
INFO - 2024-02-27 17:16:42 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:16:42 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:16:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:16:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:16:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:16:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:16:42 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:16:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:16:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:16:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:16:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:16:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:16:42 --> Final output sent to browser
DEBUG - 2024-02-27 17:16:42 --> Total execution time: 0.0351
ERROR - 2024-02-27 17:18:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:18:53 --> Config Class Initialized
INFO - 2024-02-27 17:18:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:18:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:18:53 --> Utf8 Class Initialized
INFO - 2024-02-27 17:18:53 --> URI Class Initialized
INFO - 2024-02-27 17:18:53 --> Router Class Initialized
INFO - 2024-02-27 17:18:53 --> Output Class Initialized
INFO - 2024-02-27 17:18:53 --> Security Class Initialized
DEBUG - 2024-02-27 17:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:18:53 --> Input Class Initialized
INFO - 2024-02-27 17:18:53 --> Language Class Initialized
INFO - 2024-02-27 17:18:53 --> Loader Class Initialized
INFO - 2024-02-27 17:18:53 --> Helper loaded: url_helper
INFO - 2024-02-27 17:18:53 --> Helper loaded: file_helper
INFO - 2024-02-27 17:18:53 --> Helper loaded: form_helper
INFO - 2024-02-27 17:18:53 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:18:54 --> Controller Class Initialized
INFO - 2024-02-27 17:18:54 --> Form Validation Class Initialized
INFO - 2024-02-27 17:18:54 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:18:54 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:18:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:18:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:18:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:18:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:18:54 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:18:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:18:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:18:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:18:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:18:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:18:54 --> Final output sent to browser
DEBUG - 2024-02-27 17:18:54 --> Total execution time: 0.0324
ERROR - 2024-02-27 17:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:19:57 --> Config Class Initialized
INFO - 2024-02-27 17:19:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:19:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:19:57 --> Utf8 Class Initialized
INFO - 2024-02-27 17:19:57 --> URI Class Initialized
INFO - 2024-02-27 17:19:57 --> Router Class Initialized
INFO - 2024-02-27 17:19:57 --> Output Class Initialized
INFO - 2024-02-27 17:19:57 --> Security Class Initialized
DEBUG - 2024-02-27 17:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:19:57 --> Input Class Initialized
INFO - 2024-02-27 17:19:57 --> Language Class Initialized
INFO - 2024-02-27 17:19:57 --> Loader Class Initialized
INFO - 2024-02-27 17:19:57 --> Helper loaded: url_helper
INFO - 2024-02-27 17:19:57 --> Helper loaded: file_helper
INFO - 2024-02-27 17:19:57 --> Helper loaded: form_helper
INFO - 2024-02-27 17:19:57 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:19:57 --> Controller Class Initialized
INFO - 2024-02-27 17:19:57 --> Form Validation Class Initialized
INFO - 2024-02-27 17:19:57 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:19:57 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:19:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:19:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:19:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:19:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:19:57 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:19:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:19:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:19:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:19:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:19:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:19:57 --> Final output sent to browser
DEBUG - 2024-02-27 17:19:57 --> Total execution time: 0.0344
ERROR - 2024-02-27 17:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:23:07 --> Config Class Initialized
INFO - 2024-02-27 17:23:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:23:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:23:07 --> Utf8 Class Initialized
INFO - 2024-02-27 17:23:07 --> URI Class Initialized
INFO - 2024-02-27 17:23:07 --> Router Class Initialized
INFO - 2024-02-27 17:23:07 --> Output Class Initialized
INFO - 2024-02-27 17:23:07 --> Security Class Initialized
DEBUG - 2024-02-27 17:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:23:07 --> Input Class Initialized
INFO - 2024-02-27 17:23:07 --> Language Class Initialized
INFO - 2024-02-27 17:23:07 --> Loader Class Initialized
INFO - 2024-02-27 17:23:07 --> Helper loaded: url_helper
INFO - 2024-02-27 17:23:07 --> Helper loaded: file_helper
INFO - 2024-02-27 17:23:07 --> Helper loaded: form_helper
INFO - 2024-02-27 17:23:07 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:23:07 --> Controller Class Initialized
INFO - 2024-02-27 17:23:07 --> Form Validation Class Initialized
INFO - 2024-02-27 17:23:07 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:23:07 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:23:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:23:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:23:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:23:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:23:07 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:23:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:23:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:23:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:23:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:23:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:23:07 --> Final output sent to browser
DEBUG - 2024-02-27 17:23:07 --> Total execution time: 0.0353
ERROR - 2024-02-27 17:26:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:26:54 --> Config Class Initialized
INFO - 2024-02-27 17:26:54 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:26:54 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:26:54 --> Utf8 Class Initialized
INFO - 2024-02-27 17:26:54 --> URI Class Initialized
INFO - 2024-02-27 17:26:54 --> Router Class Initialized
INFO - 2024-02-27 17:26:54 --> Output Class Initialized
INFO - 2024-02-27 17:26:54 --> Security Class Initialized
DEBUG - 2024-02-27 17:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:26:54 --> Input Class Initialized
INFO - 2024-02-27 17:26:54 --> Language Class Initialized
INFO - 2024-02-27 17:26:54 --> Loader Class Initialized
INFO - 2024-02-27 17:26:54 --> Helper loaded: url_helper
INFO - 2024-02-27 17:26:54 --> Helper loaded: file_helper
INFO - 2024-02-27 17:26:54 --> Helper loaded: form_helper
INFO - 2024-02-27 17:26:54 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:26:54 --> Controller Class Initialized
INFO - 2024-02-27 17:26:54 --> Form Validation Class Initialized
INFO - 2024-02-27 17:26:54 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:26:54 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:26:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:26:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:26:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:26:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:26:54 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:26:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:26:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:26:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:26:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:26:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:26:54 --> Final output sent to browser
DEBUG - 2024-02-27 17:26:54 --> Total execution time: 0.0309
ERROR - 2024-02-27 17:27:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:27:03 --> Config Class Initialized
INFO - 2024-02-27 17:27:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:27:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:27:03 --> Utf8 Class Initialized
INFO - 2024-02-27 17:27:03 --> URI Class Initialized
INFO - 2024-02-27 17:27:03 --> Router Class Initialized
INFO - 2024-02-27 17:27:03 --> Output Class Initialized
INFO - 2024-02-27 17:27:03 --> Security Class Initialized
DEBUG - 2024-02-27 17:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:27:03 --> Input Class Initialized
INFO - 2024-02-27 17:27:03 --> Language Class Initialized
INFO - 2024-02-27 17:27:03 --> Loader Class Initialized
INFO - 2024-02-27 17:27:03 --> Helper loaded: url_helper
INFO - 2024-02-27 17:27:03 --> Helper loaded: file_helper
INFO - 2024-02-27 17:27:03 --> Helper loaded: form_helper
INFO - 2024-02-27 17:27:03 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:27:03 --> Controller Class Initialized
INFO - 2024-02-27 17:27:03 --> Form Validation Class Initialized
INFO - 2024-02-27 17:27:03 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:27:03 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:27:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:27:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:27:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:27:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:27:03 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:27:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:27:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:27:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:27:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:27:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:27:03 --> Final output sent to browser
DEBUG - 2024-02-27 17:27:03 --> Total execution time: 0.0345
ERROR - 2024-02-27 17:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:28:34 --> Config Class Initialized
INFO - 2024-02-27 17:28:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:28:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:28:34 --> Utf8 Class Initialized
INFO - 2024-02-27 17:28:34 --> URI Class Initialized
INFO - 2024-02-27 17:28:34 --> Router Class Initialized
INFO - 2024-02-27 17:28:34 --> Output Class Initialized
INFO - 2024-02-27 17:28:34 --> Security Class Initialized
DEBUG - 2024-02-27 17:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:28:34 --> Input Class Initialized
INFO - 2024-02-27 17:28:34 --> Language Class Initialized
INFO - 2024-02-27 17:28:34 --> Loader Class Initialized
INFO - 2024-02-27 17:28:34 --> Helper loaded: url_helper
INFO - 2024-02-27 17:28:34 --> Helper loaded: file_helper
INFO - 2024-02-27 17:28:34 --> Helper loaded: form_helper
INFO - 2024-02-27 17:28:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:28:34 --> Controller Class Initialized
INFO - 2024-02-27 17:28:34 --> Form Validation Class Initialized
INFO - 2024-02-27 17:28:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:28:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:28:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:28:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:28:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:28:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:28:34 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:28:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:28:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:28:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:28:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:28:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:28:34 --> Final output sent to browser
DEBUG - 2024-02-27 17:28:34 --> Total execution time: 0.0319
ERROR - 2024-02-27 17:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:28:39 --> Config Class Initialized
INFO - 2024-02-27 17:28:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:28:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:28:39 --> Utf8 Class Initialized
INFO - 2024-02-27 17:28:39 --> URI Class Initialized
INFO - 2024-02-27 17:28:39 --> Router Class Initialized
INFO - 2024-02-27 17:28:39 --> Output Class Initialized
INFO - 2024-02-27 17:28:39 --> Security Class Initialized
DEBUG - 2024-02-27 17:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:28:39 --> Input Class Initialized
INFO - 2024-02-27 17:28:39 --> Language Class Initialized
INFO - 2024-02-27 17:28:39 --> Loader Class Initialized
INFO - 2024-02-27 17:28:39 --> Helper loaded: url_helper
INFO - 2024-02-27 17:28:39 --> Helper loaded: file_helper
INFO - 2024-02-27 17:28:39 --> Helper loaded: form_helper
INFO - 2024-02-27 17:28:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:28:39 --> Controller Class Initialized
INFO - 2024-02-27 17:28:39 --> Form Validation Class Initialized
INFO - 2024-02-27 17:28:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:28:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:28:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:28:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:28:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:28:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:28:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:28:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:28:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:28:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:28:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:28:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:28:39 --> Final output sent to browser
DEBUG - 2024-02-27 17:28:39 --> Total execution time: 0.0277
ERROR - 2024-02-27 17:29:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:29:24 --> Config Class Initialized
INFO - 2024-02-27 17:29:24 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:29:24 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:29:24 --> Utf8 Class Initialized
INFO - 2024-02-27 17:29:24 --> URI Class Initialized
INFO - 2024-02-27 17:29:24 --> Router Class Initialized
INFO - 2024-02-27 17:29:24 --> Output Class Initialized
INFO - 2024-02-27 17:29:24 --> Security Class Initialized
DEBUG - 2024-02-27 17:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:29:24 --> Input Class Initialized
INFO - 2024-02-27 17:29:24 --> Language Class Initialized
INFO - 2024-02-27 17:29:24 --> Loader Class Initialized
INFO - 2024-02-27 17:29:24 --> Helper loaded: url_helper
INFO - 2024-02-27 17:29:24 --> Helper loaded: file_helper
INFO - 2024-02-27 17:29:24 --> Helper loaded: form_helper
INFO - 2024-02-27 17:29:24 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:29:24 --> Controller Class Initialized
INFO - 2024-02-27 17:29:24 --> Form Validation Class Initialized
INFO - 2024-02-27 17:29:24 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:29:24 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:29:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:29:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:29:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:29:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:29:24 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:29:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:29:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:29:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:29:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:29:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:29:24 --> Final output sent to browser
DEBUG - 2024-02-27 17:29:24 --> Total execution time: 0.0316
ERROR - 2024-02-27 17:29:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:29:34 --> Config Class Initialized
INFO - 2024-02-27 17:29:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:29:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:29:34 --> Utf8 Class Initialized
INFO - 2024-02-27 17:29:34 --> URI Class Initialized
INFO - 2024-02-27 17:29:34 --> Router Class Initialized
INFO - 2024-02-27 17:29:34 --> Output Class Initialized
INFO - 2024-02-27 17:29:34 --> Security Class Initialized
DEBUG - 2024-02-27 17:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:29:34 --> Input Class Initialized
INFO - 2024-02-27 17:29:34 --> Language Class Initialized
INFO - 2024-02-27 17:29:34 --> Loader Class Initialized
INFO - 2024-02-27 17:29:34 --> Helper loaded: url_helper
INFO - 2024-02-27 17:29:34 --> Helper loaded: file_helper
INFO - 2024-02-27 17:29:34 --> Helper loaded: form_helper
INFO - 2024-02-27 17:29:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:29:34 --> Controller Class Initialized
INFO - 2024-02-27 17:29:34 --> Form Validation Class Initialized
INFO - 2024-02-27 17:29:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:29:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:29:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:29:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:29:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:29:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:29:34 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:29:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:29:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:29:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:29:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:29:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:29:35 --> Final output sent to browser
DEBUG - 2024-02-27 17:29:35 --> Total execution time: 0.0447
ERROR - 2024-02-27 17:30:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:30:21 --> Config Class Initialized
INFO - 2024-02-27 17:30:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:30:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:30:21 --> Utf8 Class Initialized
INFO - 2024-02-27 17:30:21 --> URI Class Initialized
INFO - 2024-02-27 17:30:21 --> Router Class Initialized
INFO - 2024-02-27 17:30:21 --> Output Class Initialized
INFO - 2024-02-27 17:30:21 --> Security Class Initialized
DEBUG - 2024-02-27 17:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:30:21 --> Input Class Initialized
INFO - 2024-02-27 17:30:21 --> Language Class Initialized
INFO - 2024-02-27 17:30:21 --> Loader Class Initialized
INFO - 2024-02-27 17:30:21 --> Helper loaded: url_helper
INFO - 2024-02-27 17:30:21 --> Helper loaded: file_helper
INFO - 2024-02-27 17:30:21 --> Helper loaded: form_helper
INFO - 2024-02-27 17:30:21 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:30:21 --> Controller Class Initialized
INFO - 2024-02-27 17:30:21 --> Form Validation Class Initialized
INFO - 2024-02-27 17:30:21 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:30:21 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:30:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:30:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:30:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:30:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:30:21 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:30:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:30:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:30:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:30:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:30:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:30:21 --> Final output sent to browser
DEBUG - 2024-02-27 17:30:21 --> Total execution time: 0.0322
ERROR - 2024-02-27 17:35:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:35:01 --> Config Class Initialized
INFO - 2024-02-27 17:35:01 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:35:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:35:01 --> Utf8 Class Initialized
INFO - 2024-02-27 17:35:01 --> URI Class Initialized
INFO - 2024-02-27 17:35:01 --> Router Class Initialized
INFO - 2024-02-27 17:35:01 --> Output Class Initialized
INFO - 2024-02-27 17:35:01 --> Security Class Initialized
DEBUG - 2024-02-27 17:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:35:01 --> Input Class Initialized
INFO - 2024-02-27 17:35:01 --> Language Class Initialized
INFO - 2024-02-27 17:35:01 --> Loader Class Initialized
INFO - 2024-02-27 17:35:01 --> Helper loaded: url_helper
INFO - 2024-02-27 17:35:01 --> Helper loaded: file_helper
INFO - 2024-02-27 17:35:01 --> Helper loaded: form_helper
INFO - 2024-02-27 17:35:01 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:35:01 --> Controller Class Initialized
INFO - 2024-02-27 17:35:01 --> Form Validation Class Initialized
INFO - 2024-02-27 17:35:01 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:35:01 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:35:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:35:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:35:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:35:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:35:01 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:35:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:35:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:35:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:35:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:35:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:35:01 --> Final output sent to browser
DEBUG - 2024-02-27 17:35:01 --> Total execution time: 0.0288
ERROR - 2024-02-27 17:35:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:35:02 --> Config Class Initialized
INFO - 2024-02-27 17:35:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:35:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:35:02 --> Utf8 Class Initialized
INFO - 2024-02-27 17:35:02 --> URI Class Initialized
INFO - 2024-02-27 17:35:02 --> Router Class Initialized
INFO - 2024-02-27 17:35:02 --> Output Class Initialized
INFO - 2024-02-27 17:35:02 --> Security Class Initialized
DEBUG - 2024-02-27 17:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:35:02 --> Input Class Initialized
INFO - 2024-02-27 17:35:02 --> Language Class Initialized
INFO - 2024-02-27 17:35:02 --> Loader Class Initialized
INFO - 2024-02-27 17:35:02 --> Helper loaded: url_helper
INFO - 2024-02-27 17:35:02 --> Helper loaded: file_helper
INFO - 2024-02-27 17:35:02 --> Helper loaded: form_helper
INFO - 2024-02-27 17:35:02 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:35:02 --> Controller Class Initialized
INFO - 2024-02-27 17:35:02 --> Form Validation Class Initialized
INFO - 2024-02-27 17:35:02 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:35:02 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:35:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:35:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:35:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:35:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:35:02 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:35:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:35:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:35:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:35:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:35:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:35:02 --> Final output sent to browser
DEBUG - 2024-02-27 17:35:02 --> Total execution time: 0.0339
ERROR - 2024-02-27 17:35:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:35:30 --> Config Class Initialized
INFO - 2024-02-27 17:35:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:35:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:35:30 --> Utf8 Class Initialized
INFO - 2024-02-27 17:35:30 --> URI Class Initialized
INFO - 2024-02-27 17:35:30 --> Router Class Initialized
INFO - 2024-02-27 17:35:30 --> Output Class Initialized
INFO - 2024-02-27 17:35:30 --> Security Class Initialized
DEBUG - 2024-02-27 17:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:35:30 --> Input Class Initialized
INFO - 2024-02-27 17:35:30 --> Language Class Initialized
INFO - 2024-02-27 17:35:30 --> Loader Class Initialized
INFO - 2024-02-27 17:35:30 --> Helper loaded: url_helper
INFO - 2024-02-27 17:35:30 --> Helper loaded: file_helper
INFO - 2024-02-27 17:35:30 --> Helper loaded: form_helper
INFO - 2024-02-27 17:35:30 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:35:30 --> Controller Class Initialized
INFO - 2024-02-27 17:35:30 --> Form Validation Class Initialized
INFO - 2024-02-27 17:35:30 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:35:30 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:35:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:35:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:35:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:35:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:35:30 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:35:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:35:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:35:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:35:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:35:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:35:30 --> Final output sent to browser
DEBUG - 2024-02-27 17:35:30 --> Total execution time: 0.0304
ERROR - 2024-02-27 17:36:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:36:32 --> Config Class Initialized
INFO - 2024-02-27 17:36:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:36:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:36:32 --> Utf8 Class Initialized
INFO - 2024-02-27 17:36:32 --> URI Class Initialized
INFO - 2024-02-27 17:36:32 --> Router Class Initialized
INFO - 2024-02-27 17:36:32 --> Output Class Initialized
INFO - 2024-02-27 17:36:32 --> Security Class Initialized
DEBUG - 2024-02-27 17:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:36:32 --> Input Class Initialized
INFO - 2024-02-27 17:36:32 --> Language Class Initialized
INFO - 2024-02-27 17:36:32 --> Loader Class Initialized
INFO - 2024-02-27 17:36:32 --> Helper loaded: url_helper
INFO - 2024-02-27 17:36:32 --> Helper loaded: file_helper
INFO - 2024-02-27 17:36:32 --> Helper loaded: form_helper
INFO - 2024-02-27 17:36:32 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:36:32 --> Controller Class Initialized
INFO - 2024-02-27 17:36:32 --> Form Validation Class Initialized
INFO - 2024-02-27 17:36:32 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:36:32 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:36:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:36:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:36:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:36:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:36:32 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:36:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:36:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:36:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:36:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:36:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:36:32 --> Final output sent to browser
DEBUG - 2024-02-27 17:36:32 --> Total execution time: 0.0387
ERROR - 2024-02-27 17:36:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:36:45 --> Config Class Initialized
INFO - 2024-02-27 17:36:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:36:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:36:45 --> Utf8 Class Initialized
INFO - 2024-02-27 17:36:45 --> URI Class Initialized
INFO - 2024-02-27 17:36:45 --> Router Class Initialized
INFO - 2024-02-27 17:36:45 --> Output Class Initialized
INFO - 2024-02-27 17:36:45 --> Security Class Initialized
DEBUG - 2024-02-27 17:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:36:45 --> Input Class Initialized
INFO - 2024-02-27 17:36:45 --> Language Class Initialized
INFO - 2024-02-27 17:36:45 --> Loader Class Initialized
INFO - 2024-02-27 17:36:45 --> Helper loaded: url_helper
INFO - 2024-02-27 17:36:45 --> Helper loaded: file_helper
INFO - 2024-02-27 17:36:45 --> Helper loaded: form_helper
INFO - 2024-02-27 17:36:45 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:36:45 --> Controller Class Initialized
INFO - 2024-02-27 17:36:45 --> Form Validation Class Initialized
INFO - 2024-02-27 17:36:45 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:36:45 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:36:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:36:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:36:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:36:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:36:45 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:36:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:36:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:36:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:36:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:36:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:36:45 --> Final output sent to browser
DEBUG - 2024-02-27 17:36:45 --> Total execution time: 0.0212
ERROR - 2024-02-27 17:36:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:36:55 --> Config Class Initialized
INFO - 2024-02-27 17:36:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:36:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:36:55 --> Utf8 Class Initialized
INFO - 2024-02-27 17:36:55 --> URI Class Initialized
INFO - 2024-02-27 17:36:55 --> Router Class Initialized
INFO - 2024-02-27 17:36:55 --> Output Class Initialized
INFO - 2024-02-27 17:36:55 --> Security Class Initialized
DEBUG - 2024-02-27 17:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:36:55 --> Input Class Initialized
INFO - 2024-02-27 17:36:55 --> Language Class Initialized
INFO - 2024-02-27 17:36:55 --> Loader Class Initialized
INFO - 2024-02-27 17:36:55 --> Helper loaded: url_helper
INFO - 2024-02-27 17:36:55 --> Helper loaded: file_helper
INFO - 2024-02-27 17:36:55 --> Helper loaded: form_helper
INFO - 2024-02-27 17:36:55 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:36:55 --> Controller Class Initialized
INFO - 2024-02-27 17:36:55 --> Form Validation Class Initialized
INFO - 2024-02-27 17:36:55 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:36:55 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:36:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:36:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:36:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:36:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:36:55 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:36:55 --> Final output sent to browser
DEBUG - 2024-02-27 17:36:55 --> Total execution time: 0.0374
ERROR - 2024-02-27 17:37:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:37:13 --> Config Class Initialized
INFO - 2024-02-27 17:37:13 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:37:13 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:37:13 --> Utf8 Class Initialized
INFO - 2024-02-27 17:37:13 --> URI Class Initialized
INFO - 2024-02-27 17:37:13 --> Router Class Initialized
INFO - 2024-02-27 17:37:13 --> Output Class Initialized
INFO - 2024-02-27 17:37:13 --> Security Class Initialized
DEBUG - 2024-02-27 17:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:37:13 --> Input Class Initialized
INFO - 2024-02-27 17:37:13 --> Language Class Initialized
INFO - 2024-02-27 17:37:13 --> Loader Class Initialized
INFO - 2024-02-27 17:37:13 --> Helper loaded: url_helper
INFO - 2024-02-27 17:37:13 --> Helper loaded: file_helper
INFO - 2024-02-27 17:37:13 --> Helper loaded: form_helper
INFO - 2024-02-27 17:37:13 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:37:13 --> Controller Class Initialized
INFO - 2024-02-27 17:37:13 --> Form Validation Class Initialized
INFO - 2024-02-27 17:37:13 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:37:13 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:37:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:37:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:37:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:37:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:37:13 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:37:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:37:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:37:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:37:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:37:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:37:13 --> Final output sent to browser
DEBUG - 2024-02-27 17:37:13 --> Total execution time: 0.0412
ERROR - 2024-02-27 17:37:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:37:20 --> Config Class Initialized
INFO - 2024-02-27 17:37:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:37:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:37:20 --> Utf8 Class Initialized
INFO - 2024-02-27 17:37:20 --> URI Class Initialized
INFO - 2024-02-27 17:37:20 --> Router Class Initialized
INFO - 2024-02-27 17:37:20 --> Output Class Initialized
INFO - 2024-02-27 17:37:20 --> Security Class Initialized
DEBUG - 2024-02-27 17:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:37:20 --> Input Class Initialized
INFO - 2024-02-27 17:37:20 --> Language Class Initialized
INFO - 2024-02-27 17:37:20 --> Loader Class Initialized
INFO - 2024-02-27 17:37:20 --> Helper loaded: url_helper
INFO - 2024-02-27 17:37:20 --> Helper loaded: file_helper
INFO - 2024-02-27 17:37:20 --> Helper loaded: form_helper
INFO - 2024-02-27 17:37:20 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:37:20 --> Controller Class Initialized
INFO - 2024-02-27 17:37:20 --> Form Validation Class Initialized
INFO - 2024-02-27 17:37:20 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:37:20 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:37:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:37:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:37:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:37:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:37:20 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:37:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:37:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:37:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:37:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:37:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:37:20 --> Final output sent to browser
DEBUG - 2024-02-27 17:37:20 --> Total execution time: 0.0448
ERROR - 2024-02-27 17:38:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:38:41 --> Config Class Initialized
INFO - 2024-02-27 17:38:41 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:38:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:38:41 --> Utf8 Class Initialized
INFO - 2024-02-27 17:38:41 --> URI Class Initialized
INFO - 2024-02-27 17:38:41 --> Router Class Initialized
INFO - 2024-02-27 17:38:41 --> Output Class Initialized
INFO - 2024-02-27 17:38:41 --> Security Class Initialized
DEBUG - 2024-02-27 17:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:38:41 --> Input Class Initialized
INFO - 2024-02-27 17:38:41 --> Language Class Initialized
INFO - 2024-02-27 17:38:41 --> Loader Class Initialized
INFO - 2024-02-27 17:38:41 --> Helper loaded: url_helper
INFO - 2024-02-27 17:38:41 --> Helper loaded: file_helper
INFO - 2024-02-27 17:38:41 --> Helper loaded: form_helper
INFO - 2024-02-27 17:38:41 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:38:41 --> Controller Class Initialized
INFO - 2024-02-27 17:38:41 --> Form Validation Class Initialized
INFO - 2024-02-27 17:38:41 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:38:41 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:38:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:38:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:38:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:38:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:38:41 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:38:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:38:41 --> Final output sent to browser
DEBUG - 2024-02-27 17:38:41 --> Total execution time: 0.0313
ERROR - 2024-02-27 17:38:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:38:43 --> Config Class Initialized
INFO - 2024-02-27 17:38:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:38:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:38:43 --> Utf8 Class Initialized
INFO - 2024-02-27 17:38:43 --> URI Class Initialized
INFO - 2024-02-27 17:38:43 --> Router Class Initialized
INFO - 2024-02-27 17:38:43 --> Output Class Initialized
INFO - 2024-02-27 17:38:43 --> Security Class Initialized
DEBUG - 2024-02-27 17:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:38:43 --> Input Class Initialized
INFO - 2024-02-27 17:38:43 --> Language Class Initialized
INFO - 2024-02-27 17:38:43 --> Loader Class Initialized
INFO - 2024-02-27 17:38:43 --> Helper loaded: url_helper
INFO - 2024-02-27 17:38:43 --> Helper loaded: file_helper
INFO - 2024-02-27 17:38:43 --> Helper loaded: form_helper
INFO - 2024-02-27 17:38:43 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:38:43 --> Controller Class Initialized
INFO - 2024-02-27 17:38:43 --> Form Validation Class Initialized
INFO - 2024-02-27 17:38:43 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:38:43 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:38:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:38:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:38:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:38:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:38:43 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:38:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:38:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:38:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:38:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:38:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:38:43 --> Final output sent to browser
DEBUG - 2024-02-27 17:38:43 --> Total execution time: 0.0326
ERROR - 2024-02-27 17:38:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:38:53 --> Config Class Initialized
INFO - 2024-02-27 17:38:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:38:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:38:53 --> Utf8 Class Initialized
INFO - 2024-02-27 17:38:53 --> URI Class Initialized
INFO - 2024-02-27 17:38:53 --> Router Class Initialized
INFO - 2024-02-27 17:38:53 --> Output Class Initialized
INFO - 2024-02-27 17:38:53 --> Security Class Initialized
DEBUG - 2024-02-27 17:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:38:53 --> Input Class Initialized
INFO - 2024-02-27 17:38:53 --> Language Class Initialized
INFO - 2024-02-27 17:38:53 --> Loader Class Initialized
INFO - 2024-02-27 17:38:53 --> Helper loaded: url_helper
INFO - 2024-02-27 17:38:53 --> Helper loaded: file_helper
INFO - 2024-02-27 17:38:53 --> Helper loaded: form_helper
INFO - 2024-02-27 17:38:53 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:38:53 --> Controller Class Initialized
INFO - 2024-02-27 17:38:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-27 17:38:53 --> Final output sent to browser
DEBUG - 2024-02-27 17:38:53 --> Total execution time: 0.0250
ERROR - 2024-02-27 17:39:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:39:26 --> Config Class Initialized
INFO - 2024-02-27 17:39:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:39:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:39:26 --> Utf8 Class Initialized
INFO - 2024-02-27 17:39:26 --> URI Class Initialized
INFO - 2024-02-27 17:39:26 --> Router Class Initialized
INFO - 2024-02-27 17:39:26 --> Output Class Initialized
INFO - 2024-02-27 17:39:26 --> Security Class Initialized
DEBUG - 2024-02-27 17:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:39:26 --> Input Class Initialized
INFO - 2024-02-27 17:39:26 --> Language Class Initialized
INFO - 2024-02-27 17:39:26 --> Loader Class Initialized
INFO - 2024-02-27 17:39:26 --> Helper loaded: url_helper
INFO - 2024-02-27 17:39:26 --> Helper loaded: file_helper
INFO - 2024-02-27 17:39:26 --> Helper loaded: form_helper
INFO - 2024-02-27 17:39:26 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:39:26 --> Controller Class Initialized
INFO - 2024-02-27 17:39:26 --> Form Validation Class Initialized
INFO - 2024-02-27 17:39:26 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:39:26 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:39:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:39:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:39:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:39:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:39:26 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:39:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:39:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:39:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:39:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:39:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:39:26 --> Final output sent to browser
DEBUG - 2024-02-27 17:39:26 --> Total execution time: 0.0359
ERROR - 2024-02-27 17:39:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:39:34 --> Config Class Initialized
INFO - 2024-02-27 17:39:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:39:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:39:34 --> Utf8 Class Initialized
INFO - 2024-02-27 17:39:34 --> URI Class Initialized
INFO - 2024-02-27 17:39:34 --> Router Class Initialized
INFO - 2024-02-27 17:39:34 --> Output Class Initialized
INFO - 2024-02-27 17:39:34 --> Security Class Initialized
DEBUG - 2024-02-27 17:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:39:34 --> Input Class Initialized
INFO - 2024-02-27 17:39:34 --> Language Class Initialized
INFO - 2024-02-27 17:39:34 --> Loader Class Initialized
INFO - 2024-02-27 17:39:34 --> Helper loaded: url_helper
INFO - 2024-02-27 17:39:34 --> Helper loaded: file_helper
INFO - 2024-02-27 17:39:34 --> Helper loaded: form_helper
INFO - 2024-02-27 17:39:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:39:34 --> Controller Class Initialized
INFO - 2024-02-27 17:39:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-27 17:39:34 --> Final output sent to browser
DEBUG - 2024-02-27 17:39:34 --> Total execution time: 0.0577
ERROR - 2024-02-27 17:40:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:40:09 --> Config Class Initialized
INFO - 2024-02-27 17:40:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:40:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:40:09 --> Utf8 Class Initialized
INFO - 2024-02-27 17:40:09 --> URI Class Initialized
INFO - 2024-02-27 17:40:09 --> Router Class Initialized
INFO - 2024-02-27 17:40:09 --> Output Class Initialized
INFO - 2024-02-27 17:40:09 --> Security Class Initialized
DEBUG - 2024-02-27 17:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:40:09 --> Input Class Initialized
INFO - 2024-02-27 17:40:09 --> Language Class Initialized
INFO - 2024-02-27 17:40:09 --> Loader Class Initialized
INFO - 2024-02-27 17:40:09 --> Helper loaded: url_helper
INFO - 2024-02-27 17:40:09 --> Helper loaded: file_helper
INFO - 2024-02-27 17:40:09 --> Helper loaded: form_helper
INFO - 2024-02-27 17:40:09 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:40:09 --> Controller Class Initialized
INFO - 2024-02-27 17:40:09 --> Form Validation Class Initialized
INFO - 2024-02-27 17:40:09 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:40:09 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:40:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:40:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:40:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:40:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:40:09 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:40:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:40:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:40:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:40:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:40:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:40:09 --> Final output sent to browser
DEBUG - 2024-02-27 17:40:09 --> Total execution time: 0.0421
ERROR - 2024-02-27 17:40:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:40:14 --> Config Class Initialized
INFO - 2024-02-27 17:40:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:40:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:40:14 --> Utf8 Class Initialized
INFO - 2024-02-27 17:40:14 --> URI Class Initialized
INFO - 2024-02-27 17:40:14 --> Router Class Initialized
INFO - 2024-02-27 17:40:14 --> Output Class Initialized
INFO - 2024-02-27 17:40:14 --> Security Class Initialized
DEBUG - 2024-02-27 17:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:40:14 --> Input Class Initialized
INFO - 2024-02-27 17:40:14 --> Language Class Initialized
INFO - 2024-02-27 17:40:14 --> Loader Class Initialized
INFO - 2024-02-27 17:40:14 --> Helper loaded: url_helper
INFO - 2024-02-27 17:40:14 --> Helper loaded: file_helper
INFO - 2024-02-27 17:40:14 --> Helper loaded: form_helper
INFO - 2024-02-27 17:40:14 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:40:14 --> Controller Class Initialized
INFO - 2024-02-27 17:40:14 --> Form Validation Class Initialized
INFO - 2024-02-27 17:40:14 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:40:14 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:40:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:40:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:40:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:40:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:40:14 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:40:14 --> Upload Class Initialized
ERROR - 2024-02-27 17:40:14 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\sscy\application\controllers\app\UserMaster.php 104
ERROR - 2024-02-27 17:40:14 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\sscy\application\controllers\app\UserMaster.php 104
ERROR - 2024-02-27 17:40:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:40:52 --> Config Class Initialized
INFO - 2024-02-27 17:40:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:40:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:40:52 --> Utf8 Class Initialized
INFO - 2024-02-27 17:40:52 --> URI Class Initialized
INFO - 2024-02-27 17:40:52 --> Router Class Initialized
INFO - 2024-02-27 17:40:52 --> Output Class Initialized
INFO - 2024-02-27 17:40:52 --> Security Class Initialized
DEBUG - 2024-02-27 17:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:40:52 --> Input Class Initialized
INFO - 2024-02-27 17:40:52 --> Language Class Initialized
INFO - 2024-02-27 17:40:52 --> Loader Class Initialized
INFO - 2024-02-27 17:40:52 --> Helper loaded: url_helper
INFO - 2024-02-27 17:40:52 --> Helper loaded: file_helper
INFO - 2024-02-27 17:40:52 --> Helper loaded: form_helper
INFO - 2024-02-27 17:40:52 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:40:52 --> Controller Class Initialized
INFO - 2024-02-27 17:40:52 --> Form Validation Class Initialized
INFO - 2024-02-27 17:40:52 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:40:52 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:40:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:40:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:40:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:40:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:40:52 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:40:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:40:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:40:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:40:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:40:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:40:52 --> Final output sent to browser
DEBUG - 2024-02-27 17:40:52 --> Total execution time: 0.0249
ERROR - 2024-02-27 17:40:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:40:57 --> Config Class Initialized
INFO - 2024-02-27 17:40:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:40:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:40:57 --> Utf8 Class Initialized
INFO - 2024-02-27 17:40:57 --> URI Class Initialized
INFO - 2024-02-27 17:40:57 --> Router Class Initialized
INFO - 2024-02-27 17:40:57 --> Output Class Initialized
INFO - 2024-02-27 17:40:57 --> Security Class Initialized
DEBUG - 2024-02-27 17:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:40:57 --> Input Class Initialized
INFO - 2024-02-27 17:40:57 --> Language Class Initialized
INFO - 2024-02-27 17:40:57 --> Loader Class Initialized
INFO - 2024-02-27 17:40:57 --> Helper loaded: url_helper
INFO - 2024-02-27 17:40:57 --> Helper loaded: file_helper
INFO - 2024-02-27 17:40:57 --> Helper loaded: form_helper
INFO - 2024-02-27 17:40:57 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:40:57 --> Controller Class Initialized
INFO - 2024-02-27 17:40:57 --> Form Validation Class Initialized
INFO - 2024-02-27 17:40:57 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:40:57 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:40:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:40:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:40:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:40:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:40:57 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:40:57 --> Upload Class Initialized
ERROR - 2024-02-27 17:41:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:41:49 --> Config Class Initialized
INFO - 2024-02-27 17:41:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:41:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:41:49 --> Utf8 Class Initialized
INFO - 2024-02-27 17:41:49 --> URI Class Initialized
INFO - 2024-02-27 17:41:49 --> Router Class Initialized
INFO - 2024-02-27 17:41:49 --> Output Class Initialized
INFO - 2024-02-27 17:41:49 --> Security Class Initialized
DEBUG - 2024-02-27 17:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:41:49 --> Input Class Initialized
INFO - 2024-02-27 17:41:49 --> Language Class Initialized
INFO - 2024-02-27 17:41:49 --> Loader Class Initialized
INFO - 2024-02-27 17:41:49 --> Helper loaded: url_helper
INFO - 2024-02-27 17:41:49 --> Helper loaded: file_helper
INFO - 2024-02-27 17:41:49 --> Helper loaded: form_helper
INFO - 2024-02-27 17:41:49 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:41:49 --> Controller Class Initialized
INFO - 2024-02-27 17:41:49 --> Form Validation Class Initialized
INFO - 2024-02-27 17:41:49 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:41:49 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:41:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:41:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:41:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:41:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:41:49 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:41:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:41:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:41:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:41:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:41:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:41:49 --> Final output sent to browser
DEBUG - 2024-02-27 17:41:49 --> Total execution time: 0.0350
ERROR - 2024-02-27 17:41:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:41:56 --> Config Class Initialized
INFO - 2024-02-27 17:41:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:41:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:41:56 --> Utf8 Class Initialized
INFO - 2024-02-27 17:41:56 --> URI Class Initialized
INFO - 2024-02-27 17:41:56 --> Router Class Initialized
INFO - 2024-02-27 17:41:56 --> Output Class Initialized
INFO - 2024-02-27 17:41:56 --> Security Class Initialized
DEBUG - 2024-02-27 17:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:41:56 --> Input Class Initialized
INFO - 2024-02-27 17:41:56 --> Language Class Initialized
INFO - 2024-02-27 17:41:56 --> Loader Class Initialized
INFO - 2024-02-27 17:41:56 --> Helper loaded: url_helper
INFO - 2024-02-27 17:41:56 --> Helper loaded: file_helper
INFO - 2024-02-27 17:41:56 --> Helper loaded: form_helper
INFO - 2024-02-27 17:41:56 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:41:56 --> Controller Class Initialized
INFO - 2024-02-27 17:41:56 --> Form Validation Class Initialized
INFO - 2024-02-27 17:41:56 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:41:56 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:41:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:41:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:41:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:41:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:41:56 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:41:56 --> Upload Class Initialized
ERROR - 2024-02-27 17:43:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:43:56 --> Config Class Initialized
INFO - 2024-02-27 17:43:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:43:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:43:56 --> Utf8 Class Initialized
INFO - 2024-02-27 17:43:56 --> URI Class Initialized
INFO - 2024-02-27 17:43:56 --> Router Class Initialized
INFO - 2024-02-27 17:43:56 --> Output Class Initialized
INFO - 2024-02-27 17:43:56 --> Security Class Initialized
DEBUG - 2024-02-27 17:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:43:56 --> Input Class Initialized
INFO - 2024-02-27 17:43:56 --> Language Class Initialized
INFO - 2024-02-27 17:43:56 --> Loader Class Initialized
INFO - 2024-02-27 17:43:56 --> Helper loaded: url_helper
INFO - 2024-02-27 17:43:56 --> Helper loaded: file_helper
INFO - 2024-02-27 17:43:56 --> Helper loaded: form_helper
INFO - 2024-02-27 17:43:56 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:43:56 --> Controller Class Initialized
INFO - 2024-02-27 17:43:56 --> Form Validation Class Initialized
INFO - 2024-02-27 17:43:56 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:43:56 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:43:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:43:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:43:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:43:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:43:56 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:43:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:43:56 --> Final output sent to browser
DEBUG - 2024-02-27 17:43:56 --> Total execution time: 0.0418
ERROR - 2024-02-27 17:43:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:43:58 --> Config Class Initialized
INFO - 2024-02-27 17:43:58 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:43:58 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:43:58 --> Utf8 Class Initialized
INFO - 2024-02-27 17:43:58 --> URI Class Initialized
INFO - 2024-02-27 17:43:58 --> Router Class Initialized
INFO - 2024-02-27 17:43:58 --> Output Class Initialized
INFO - 2024-02-27 17:43:58 --> Security Class Initialized
DEBUG - 2024-02-27 17:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:43:58 --> Input Class Initialized
INFO - 2024-02-27 17:43:58 --> Language Class Initialized
INFO - 2024-02-27 17:43:58 --> Loader Class Initialized
INFO - 2024-02-27 17:43:58 --> Helper loaded: url_helper
INFO - 2024-02-27 17:43:58 --> Helper loaded: file_helper
INFO - 2024-02-27 17:43:58 --> Helper loaded: form_helper
INFO - 2024-02-27 17:43:58 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:43:58 --> Controller Class Initialized
INFO - 2024-02-27 17:43:58 --> Form Validation Class Initialized
INFO - 2024-02-27 17:43:58 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:43:58 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:43:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:43:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:43:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:43:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:43:58 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:43:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:43:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:43:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:43:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:43:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:43:58 --> Final output sent to browser
DEBUG - 2024-02-27 17:43:58 --> Total execution time: 0.0424
ERROR - 2024-02-27 17:44:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:44:02 --> Config Class Initialized
INFO - 2024-02-27 17:44:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:44:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:44:02 --> Utf8 Class Initialized
INFO - 2024-02-27 17:44:02 --> URI Class Initialized
INFO - 2024-02-27 17:44:02 --> Router Class Initialized
INFO - 2024-02-27 17:44:02 --> Output Class Initialized
INFO - 2024-02-27 17:44:02 --> Security Class Initialized
DEBUG - 2024-02-27 17:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:44:02 --> Input Class Initialized
INFO - 2024-02-27 17:44:02 --> Language Class Initialized
INFO - 2024-02-27 17:44:02 --> Loader Class Initialized
INFO - 2024-02-27 17:44:02 --> Helper loaded: url_helper
INFO - 2024-02-27 17:44:02 --> Helper loaded: file_helper
INFO - 2024-02-27 17:44:02 --> Helper loaded: form_helper
INFO - 2024-02-27 17:44:02 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:44:02 --> Controller Class Initialized
INFO - 2024-02-27 17:44:02 --> Form Validation Class Initialized
INFO - 2024-02-27 17:44:02 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:44:02 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:44:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:44:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:44:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:44:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:44:02 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:44:02 --> Upload Class Initialized
ERROR - 2024-02-27 17:44:02 --> Severity: Notice --> Undefined index: user_code D:\xampp\htdocs\sscy\application\models\UserMasterModel.php 27
ERROR - 2024-02-27 17:44:02 --> Severity: Notice --> Undefined index: mobile_no D:\xampp\htdocs\sscy\application\models\UserMasterModel.php 30
ERROR - 2024-02-27 17:44:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:44:07 --> Config Class Initialized
INFO - 2024-02-27 17:44:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:44:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:44:07 --> Utf8 Class Initialized
INFO - 2024-02-27 17:44:07 --> URI Class Initialized
INFO - 2024-02-27 17:44:07 --> Router Class Initialized
INFO - 2024-02-27 17:44:07 --> Output Class Initialized
INFO - 2024-02-27 17:44:07 --> Security Class Initialized
DEBUG - 2024-02-27 17:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:44:07 --> Input Class Initialized
INFO - 2024-02-27 17:44:07 --> Language Class Initialized
INFO - 2024-02-27 17:44:07 --> Loader Class Initialized
INFO - 2024-02-27 17:44:07 --> Helper loaded: url_helper
INFO - 2024-02-27 17:44:07 --> Helper loaded: file_helper
INFO - 2024-02-27 17:44:07 --> Helper loaded: form_helper
INFO - 2024-02-27 17:44:07 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:44:07 --> Controller Class Initialized
INFO - 2024-02-27 17:44:07 --> Form Validation Class Initialized
INFO - 2024-02-27 17:44:07 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:44:07 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:44:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:44:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:44:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:44:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:44:07 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:44:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:44:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:44:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:44:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:44:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:44:07 --> Final output sent to browser
DEBUG - 2024-02-27 17:44:07 --> Total execution time: 0.0342
ERROR - 2024-02-27 17:44:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:44:12 --> Config Class Initialized
INFO - 2024-02-27 17:44:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:44:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:44:12 --> Utf8 Class Initialized
INFO - 2024-02-27 17:44:12 --> URI Class Initialized
INFO - 2024-02-27 17:44:12 --> Router Class Initialized
INFO - 2024-02-27 17:44:12 --> Output Class Initialized
INFO - 2024-02-27 17:44:12 --> Security Class Initialized
DEBUG - 2024-02-27 17:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:44:12 --> Input Class Initialized
INFO - 2024-02-27 17:44:12 --> Language Class Initialized
INFO - 2024-02-27 17:44:12 --> Loader Class Initialized
INFO - 2024-02-27 17:44:12 --> Helper loaded: url_helper
INFO - 2024-02-27 17:44:12 --> Helper loaded: file_helper
INFO - 2024-02-27 17:44:12 --> Helper loaded: form_helper
INFO - 2024-02-27 17:44:12 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:44:12 --> Controller Class Initialized
INFO - 2024-02-27 17:44:12 --> Form Validation Class Initialized
INFO - 2024-02-27 17:44:12 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:44:12 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:44:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:44:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:44:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:44:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:44:12 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:44:12 --> Upload Class Initialized
ERROR - 2024-02-27 17:44:12 --> Severity: Notice --> Undefined index: user_code D:\xampp\htdocs\sscy\application\models\UserMasterModel.php 27
ERROR - 2024-02-27 17:44:12 --> Severity: Notice --> Undefined index: mobile_no D:\xampp\htdocs\sscy\application\models\UserMasterModel.php 30
ERROR - 2024-02-27 17:44:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:44:28 --> Config Class Initialized
INFO - 2024-02-27 17:44:28 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:44:28 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:44:28 --> Utf8 Class Initialized
INFO - 2024-02-27 17:44:28 --> URI Class Initialized
INFO - 2024-02-27 17:44:28 --> Router Class Initialized
INFO - 2024-02-27 17:44:28 --> Output Class Initialized
INFO - 2024-02-27 17:44:28 --> Security Class Initialized
DEBUG - 2024-02-27 17:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:44:28 --> Input Class Initialized
INFO - 2024-02-27 17:44:28 --> Language Class Initialized
INFO - 2024-02-27 17:44:28 --> Loader Class Initialized
INFO - 2024-02-27 17:44:28 --> Helper loaded: url_helper
INFO - 2024-02-27 17:44:28 --> Helper loaded: file_helper
INFO - 2024-02-27 17:44:28 --> Helper loaded: form_helper
INFO - 2024-02-27 17:44:28 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:44:28 --> Controller Class Initialized
INFO - 2024-02-27 17:44:28 --> Form Validation Class Initialized
INFO - 2024-02-27 17:44:28 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:44:28 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:44:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:44:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:44:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:44:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:44:28 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:44:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:44:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:44:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:44:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:44:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:44:28 --> Final output sent to browser
DEBUG - 2024-02-27 17:44:28 --> Total execution time: 0.0351
ERROR - 2024-02-27 17:44:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:44:32 --> Config Class Initialized
INFO - 2024-02-27 17:44:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:44:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:44:32 --> Utf8 Class Initialized
INFO - 2024-02-27 17:44:32 --> URI Class Initialized
INFO - 2024-02-27 17:44:32 --> Router Class Initialized
INFO - 2024-02-27 17:44:32 --> Output Class Initialized
INFO - 2024-02-27 17:44:32 --> Security Class Initialized
DEBUG - 2024-02-27 17:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:44:32 --> Input Class Initialized
INFO - 2024-02-27 17:44:32 --> Language Class Initialized
INFO - 2024-02-27 17:44:32 --> Loader Class Initialized
INFO - 2024-02-27 17:44:32 --> Helper loaded: url_helper
INFO - 2024-02-27 17:44:32 --> Helper loaded: file_helper
INFO - 2024-02-27 17:44:32 --> Helper loaded: form_helper
INFO - 2024-02-27 17:44:32 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:44:32 --> Controller Class Initialized
INFO - 2024-02-27 17:44:32 --> Form Validation Class Initialized
INFO - 2024-02-27 17:44:32 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:44:32 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:44:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:44:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:44:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:44:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:44:32 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:44:32 --> Upload Class Initialized
ERROR - 2024-02-27 17:45:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:45:46 --> Config Class Initialized
INFO - 2024-02-27 17:45:46 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:45:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:45:46 --> Utf8 Class Initialized
INFO - 2024-02-27 17:45:46 --> URI Class Initialized
INFO - 2024-02-27 17:45:46 --> Router Class Initialized
INFO - 2024-02-27 17:45:46 --> Output Class Initialized
INFO - 2024-02-27 17:45:46 --> Security Class Initialized
DEBUG - 2024-02-27 17:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:45:46 --> Input Class Initialized
INFO - 2024-02-27 17:45:46 --> Language Class Initialized
INFO - 2024-02-27 17:45:46 --> Loader Class Initialized
INFO - 2024-02-27 17:45:46 --> Helper loaded: url_helper
INFO - 2024-02-27 17:45:46 --> Helper loaded: file_helper
INFO - 2024-02-27 17:45:46 --> Helper loaded: form_helper
INFO - 2024-02-27 17:45:46 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:45:46 --> Controller Class Initialized
INFO - 2024-02-27 17:45:46 --> Form Validation Class Initialized
INFO - 2024-02-27 17:45:46 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:45:46 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:45:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:45:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:45:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:45:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:45:46 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:45:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:45:46 --> Final output sent to browser
DEBUG - 2024-02-27 17:45:46 --> Total execution time: 0.0381
ERROR - 2024-02-27 17:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:45:47 --> Config Class Initialized
INFO - 2024-02-27 17:45:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:45:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:45:47 --> Utf8 Class Initialized
INFO - 2024-02-27 17:45:47 --> URI Class Initialized
INFO - 2024-02-27 17:45:47 --> Router Class Initialized
INFO - 2024-02-27 17:45:47 --> Output Class Initialized
INFO - 2024-02-27 17:45:47 --> Security Class Initialized
DEBUG - 2024-02-27 17:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:45:47 --> Input Class Initialized
INFO - 2024-02-27 17:45:47 --> Language Class Initialized
INFO - 2024-02-27 17:45:47 --> Loader Class Initialized
INFO - 2024-02-27 17:45:47 --> Helper loaded: url_helper
INFO - 2024-02-27 17:45:47 --> Helper loaded: file_helper
INFO - 2024-02-27 17:45:47 --> Helper loaded: form_helper
INFO - 2024-02-27 17:45:47 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:45:47 --> Controller Class Initialized
INFO - 2024-02-27 17:45:47 --> Form Validation Class Initialized
INFO - 2024-02-27 17:45:47 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:45:47 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:45:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:45:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:45:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:45:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:45:47 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:45:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:45:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:45:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:45:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:45:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:45:47 --> Final output sent to browser
DEBUG - 2024-02-27 17:45:47 --> Total execution time: 0.0453
ERROR - 2024-02-27 17:45:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:45:50 --> Config Class Initialized
INFO - 2024-02-27 17:45:50 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:45:50 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:45:50 --> Utf8 Class Initialized
INFO - 2024-02-27 17:45:50 --> URI Class Initialized
INFO - 2024-02-27 17:45:50 --> Router Class Initialized
INFO - 2024-02-27 17:45:50 --> Output Class Initialized
INFO - 2024-02-27 17:45:50 --> Security Class Initialized
DEBUG - 2024-02-27 17:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:45:50 --> Input Class Initialized
INFO - 2024-02-27 17:45:50 --> Language Class Initialized
INFO - 2024-02-27 17:45:50 --> Loader Class Initialized
INFO - 2024-02-27 17:45:50 --> Helper loaded: url_helper
INFO - 2024-02-27 17:45:50 --> Helper loaded: file_helper
INFO - 2024-02-27 17:45:50 --> Helper loaded: form_helper
INFO - 2024-02-27 17:45:50 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:45:50 --> Controller Class Initialized
INFO - 2024-02-27 17:45:50 --> Form Validation Class Initialized
INFO - 2024-02-27 17:45:50 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:45:50 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:45:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:45:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:45:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:45:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:45:50 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:45:50 --> Upload Class Initialized
ERROR - 2024-02-27 17:46:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:46:14 --> Config Class Initialized
INFO - 2024-02-27 17:46:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:46:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:46:14 --> Utf8 Class Initialized
INFO - 2024-02-27 17:46:14 --> URI Class Initialized
INFO - 2024-02-27 17:46:14 --> Router Class Initialized
INFO - 2024-02-27 17:46:14 --> Output Class Initialized
INFO - 2024-02-27 17:46:14 --> Security Class Initialized
DEBUG - 2024-02-27 17:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:46:14 --> Input Class Initialized
INFO - 2024-02-27 17:46:14 --> Language Class Initialized
INFO - 2024-02-27 17:46:14 --> Loader Class Initialized
INFO - 2024-02-27 17:46:14 --> Helper loaded: url_helper
INFO - 2024-02-27 17:46:14 --> Helper loaded: file_helper
INFO - 2024-02-27 17:46:14 --> Helper loaded: form_helper
INFO - 2024-02-27 17:46:14 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:46:14 --> Controller Class Initialized
INFO - 2024-02-27 17:46:14 --> Form Validation Class Initialized
INFO - 2024-02-27 17:46:14 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:46:14 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:46:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:46:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:46:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:46:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:46:14 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:46:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:46:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:46:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:46:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:46:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:46:14 --> Final output sent to browser
DEBUG - 2024-02-27 17:46:14 --> Total execution time: 0.0477
ERROR - 2024-02-27 17:46:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:46:15 --> Config Class Initialized
INFO - 2024-02-27 17:46:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:46:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:46:15 --> Utf8 Class Initialized
INFO - 2024-02-27 17:46:15 --> URI Class Initialized
INFO - 2024-02-27 17:46:15 --> Router Class Initialized
INFO - 2024-02-27 17:46:15 --> Output Class Initialized
INFO - 2024-02-27 17:46:15 --> Security Class Initialized
DEBUG - 2024-02-27 17:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:46:15 --> Input Class Initialized
INFO - 2024-02-27 17:46:15 --> Language Class Initialized
INFO - 2024-02-27 17:46:15 --> Loader Class Initialized
INFO - 2024-02-27 17:46:15 --> Helper loaded: url_helper
INFO - 2024-02-27 17:46:15 --> Helper loaded: file_helper
INFO - 2024-02-27 17:46:15 --> Helper loaded: form_helper
INFO - 2024-02-27 17:46:15 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:46:15 --> Controller Class Initialized
INFO - 2024-02-27 17:46:15 --> Form Validation Class Initialized
INFO - 2024-02-27 17:46:15 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:46:15 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:46:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:46:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:46:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:46:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:46:15 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:46:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:46:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:46:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:46:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:46:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 17:46:15 --> Final output sent to browser
DEBUG - 2024-02-27 17:46:15 --> Total execution time: 0.0411
ERROR - 2024-02-27 17:46:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:46:20 --> Config Class Initialized
INFO - 2024-02-27 17:46:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:46:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:46:20 --> Utf8 Class Initialized
INFO - 2024-02-27 17:46:20 --> URI Class Initialized
INFO - 2024-02-27 17:46:20 --> Router Class Initialized
INFO - 2024-02-27 17:46:20 --> Output Class Initialized
INFO - 2024-02-27 17:46:20 --> Security Class Initialized
DEBUG - 2024-02-27 17:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:46:20 --> Input Class Initialized
INFO - 2024-02-27 17:46:20 --> Language Class Initialized
INFO - 2024-02-27 17:46:20 --> Loader Class Initialized
INFO - 2024-02-27 17:46:20 --> Helper loaded: url_helper
INFO - 2024-02-27 17:46:20 --> Helper loaded: file_helper
INFO - 2024-02-27 17:46:20 --> Helper loaded: form_helper
INFO - 2024-02-27 17:46:20 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:46:20 --> Controller Class Initialized
INFO - 2024-02-27 17:46:20 --> Form Validation Class Initialized
INFO - 2024-02-27 17:46:20 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:46:20 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:46:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:46:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:46:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:46:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:46:20 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:46:20 --> Upload Class Initialized
ERROR - 2024-02-27 17:46:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:46:30 --> Config Class Initialized
INFO - 2024-02-27 17:46:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:46:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:46:30 --> Utf8 Class Initialized
INFO - 2024-02-27 17:46:30 --> URI Class Initialized
INFO - 2024-02-27 17:46:30 --> Router Class Initialized
INFO - 2024-02-27 17:46:30 --> Output Class Initialized
INFO - 2024-02-27 17:46:30 --> Security Class Initialized
DEBUG - 2024-02-27 17:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:46:30 --> Input Class Initialized
INFO - 2024-02-27 17:46:30 --> Language Class Initialized
INFO - 2024-02-27 17:46:30 --> Loader Class Initialized
INFO - 2024-02-27 17:46:30 --> Helper loaded: url_helper
INFO - 2024-02-27 17:46:30 --> Helper loaded: file_helper
INFO - 2024-02-27 17:46:30 --> Helper loaded: form_helper
INFO - 2024-02-27 17:46:30 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:46:30 --> Controller Class Initialized
INFO - 2024-02-27 17:46:30 --> Form Validation Class Initialized
INFO - 2024-02-27 17:46:30 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:46:30 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:46:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:46:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:46:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:46:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:46:30 --> Model "OrderModel" initialized
INFO - 2024-02-27 17:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 17:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 17:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 17:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 17:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 17:46:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 17:46:30 --> Final output sent to browser
DEBUG - 2024-02-27 17:46:30 --> Total execution time: 0.0322
ERROR - 2024-02-27 17:46:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 17:46:30 --> Config Class Initialized
INFO - 2024-02-27 17:46:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 17:46:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 17:46:30 --> Utf8 Class Initialized
INFO - 2024-02-27 17:46:30 --> URI Class Initialized
INFO - 2024-02-27 17:46:30 --> Router Class Initialized
INFO - 2024-02-27 17:46:30 --> Output Class Initialized
INFO - 2024-02-27 17:46:30 --> Security Class Initialized
DEBUG - 2024-02-27 17:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 17:46:30 --> Input Class Initialized
INFO - 2024-02-27 17:46:30 --> Language Class Initialized
INFO - 2024-02-27 17:46:30 --> Loader Class Initialized
INFO - 2024-02-27 17:46:30 --> Helper loaded: url_helper
INFO - 2024-02-27 17:46:30 --> Helper loaded: file_helper
INFO - 2024-02-27 17:46:30 --> Helper loaded: form_helper
INFO - 2024-02-27 17:46:30 --> Database Driver Class Initialized
DEBUG - 2024-02-27 17:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 17:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 17:46:30 --> Controller Class Initialized
INFO - 2024-02-27 17:46:30 --> Form Validation Class Initialized
INFO - 2024-02-27 17:46:30 --> Model "MasterModel" initialized
INFO - 2024-02-27 17:46:30 --> Model "DashboardModel" initialized
INFO - 2024-02-27 17:46:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 17:46:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 17:46:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 17:46:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 17:46:30 --> Model "OrderModel" initialized
ERROR - 2024-02-27 18:49:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 18:49:26 --> Config Class Initialized
INFO - 2024-02-27 18:49:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 18:49:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 18:49:26 --> Utf8 Class Initialized
INFO - 2024-02-27 18:49:26 --> URI Class Initialized
INFO - 2024-02-27 18:49:26 --> Router Class Initialized
INFO - 2024-02-27 18:49:26 --> Output Class Initialized
INFO - 2024-02-27 18:49:26 --> Security Class Initialized
DEBUG - 2024-02-27 18:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 18:49:26 --> Input Class Initialized
INFO - 2024-02-27 18:49:26 --> Language Class Initialized
INFO - 2024-02-27 18:49:26 --> Loader Class Initialized
INFO - 2024-02-27 18:49:26 --> Helper loaded: url_helper
INFO - 2024-02-27 18:49:26 --> Helper loaded: file_helper
INFO - 2024-02-27 18:49:26 --> Helper loaded: form_helper
INFO - 2024-02-27 18:49:26 --> Database Driver Class Initialized
DEBUG - 2024-02-27 18:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 18:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 18:49:26 --> Controller Class Initialized
INFO - 2024-02-27 18:49:26 --> Form Validation Class Initialized
INFO - 2024-02-27 18:49:26 --> Model "MasterModel" initialized
INFO - 2024-02-27 18:49:26 --> Model "DashboardModel" initialized
INFO - 2024-02-27 18:49:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 18:49:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 18:49:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 18:49:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 18:49:26 --> Model "OrderModel" initialized
INFO - 2024-02-27 18:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 18:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 18:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 18:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 18:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 18:49:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 18:49:26 --> Final output sent to browser
DEBUG - 2024-02-27 18:49:26 --> Total execution time: 0.0384
ERROR - 2024-02-27 18:49:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 18:49:27 --> Config Class Initialized
INFO - 2024-02-27 18:49:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 18:49:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 18:49:27 --> Utf8 Class Initialized
INFO - 2024-02-27 18:49:27 --> URI Class Initialized
INFO - 2024-02-27 18:49:27 --> Router Class Initialized
INFO - 2024-02-27 18:49:27 --> Output Class Initialized
INFO - 2024-02-27 18:49:27 --> Security Class Initialized
DEBUG - 2024-02-27 18:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 18:49:27 --> Input Class Initialized
INFO - 2024-02-27 18:49:27 --> Language Class Initialized
INFO - 2024-02-27 18:49:27 --> Loader Class Initialized
INFO - 2024-02-27 18:49:27 --> Helper loaded: url_helper
INFO - 2024-02-27 18:49:27 --> Helper loaded: file_helper
INFO - 2024-02-27 18:49:27 --> Helper loaded: form_helper
INFO - 2024-02-27 18:49:27 --> Database Driver Class Initialized
DEBUG - 2024-02-27 18:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 18:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 18:49:28 --> Controller Class Initialized
INFO - 2024-02-27 18:49:28 --> Form Validation Class Initialized
INFO - 2024-02-27 18:49:28 --> Model "MasterModel" initialized
INFO - 2024-02-27 18:49:28 --> Model "DashboardModel" initialized
INFO - 2024-02-27 18:49:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 18:49:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 18:49:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 18:49:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 18:49:28 --> Model "OrderModel" initialized
INFO - 2024-02-27 18:49:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 18:49:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 18:49:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 18:49:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 18:49:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 18:49:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 18:49:28 --> Final output sent to browser
DEBUG - 2024-02-27 18:49:28 --> Total execution time: 0.0304
ERROR - 2024-02-27 18:52:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 18:52:35 --> Config Class Initialized
INFO - 2024-02-27 18:52:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 18:52:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 18:52:35 --> Utf8 Class Initialized
INFO - 2024-02-27 18:52:35 --> URI Class Initialized
INFO - 2024-02-27 18:52:35 --> Router Class Initialized
INFO - 2024-02-27 18:52:35 --> Output Class Initialized
INFO - 2024-02-27 18:52:35 --> Security Class Initialized
DEBUG - 2024-02-27 18:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 18:52:35 --> Input Class Initialized
INFO - 2024-02-27 18:52:35 --> Language Class Initialized
INFO - 2024-02-27 18:52:35 --> Loader Class Initialized
INFO - 2024-02-27 18:52:35 --> Helper loaded: url_helper
INFO - 2024-02-27 18:52:35 --> Helper loaded: file_helper
INFO - 2024-02-27 18:52:35 --> Helper loaded: form_helper
INFO - 2024-02-27 18:52:35 --> Database Driver Class Initialized
DEBUG - 2024-02-27 18:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 18:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 18:52:35 --> Controller Class Initialized
INFO - 2024-02-27 18:52:35 --> Form Validation Class Initialized
INFO - 2024-02-27 18:52:35 --> Model "MasterModel" initialized
INFO - 2024-02-27 18:52:35 --> Model "DashboardModel" initialized
INFO - 2024-02-27 18:52:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 18:52:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 18:52:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 18:52:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 18:52:35 --> Model "OrderModel" initialized
INFO - 2024-02-27 18:52:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 18:52:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 18:52:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 18:52:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 18:52:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 18:52:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 18:52:35 --> Final output sent to browser
DEBUG - 2024-02-27 18:52:35 --> Total execution time: 0.0320
ERROR - 2024-02-27 18:52:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 18:52:36 --> Config Class Initialized
INFO - 2024-02-27 18:52:36 --> Hooks Class Initialized
DEBUG - 2024-02-27 18:52:36 --> UTF-8 Support Enabled
INFO - 2024-02-27 18:52:36 --> Utf8 Class Initialized
INFO - 2024-02-27 18:52:36 --> URI Class Initialized
INFO - 2024-02-27 18:52:36 --> Router Class Initialized
INFO - 2024-02-27 18:52:36 --> Output Class Initialized
INFO - 2024-02-27 18:52:36 --> Security Class Initialized
DEBUG - 2024-02-27 18:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 18:52:36 --> Input Class Initialized
INFO - 2024-02-27 18:52:36 --> Language Class Initialized
INFO - 2024-02-27 18:52:36 --> Loader Class Initialized
INFO - 2024-02-27 18:52:36 --> Helper loaded: url_helper
INFO - 2024-02-27 18:52:36 --> Helper loaded: file_helper
INFO - 2024-02-27 18:52:36 --> Helper loaded: form_helper
INFO - 2024-02-27 18:52:36 --> Database Driver Class Initialized
DEBUG - 2024-02-27 18:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 18:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 18:52:36 --> Controller Class Initialized
INFO - 2024-02-27 18:52:36 --> Form Validation Class Initialized
INFO - 2024-02-27 18:52:36 --> Model "MasterModel" initialized
INFO - 2024-02-27 18:52:36 --> Model "DashboardModel" initialized
INFO - 2024-02-27 18:52:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 18:52:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 18:52:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 18:52:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 18:52:36 --> Model "OrderModel" initialized
ERROR - 2024-02-27 18:52:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 18:52:39 --> Config Class Initialized
INFO - 2024-02-27 18:52:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 18:52:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 18:52:39 --> Utf8 Class Initialized
INFO - 2024-02-27 18:52:39 --> URI Class Initialized
INFO - 2024-02-27 18:52:39 --> Router Class Initialized
INFO - 2024-02-27 18:52:39 --> Output Class Initialized
INFO - 2024-02-27 18:52:39 --> Security Class Initialized
DEBUG - 2024-02-27 18:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 18:52:39 --> Input Class Initialized
INFO - 2024-02-27 18:52:39 --> Language Class Initialized
INFO - 2024-02-27 18:52:39 --> Loader Class Initialized
INFO - 2024-02-27 18:52:39 --> Helper loaded: url_helper
INFO - 2024-02-27 18:52:39 --> Helper loaded: file_helper
INFO - 2024-02-27 18:52:39 --> Helper loaded: form_helper
INFO - 2024-02-27 18:52:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 18:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 18:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 18:52:39 --> Controller Class Initialized
INFO - 2024-02-27 18:52:39 --> Model "LoginModel" initialized
INFO - 2024-02-27 18:52:39 --> Form Validation Class Initialized
ERROR - 2024-02-27 18:52:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 18:52:39 --> Config Class Initialized
INFO - 2024-02-27 18:52:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 18:52:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 18:52:39 --> Utf8 Class Initialized
INFO - 2024-02-27 18:52:39 --> URI Class Initialized
INFO - 2024-02-27 18:52:39 --> Router Class Initialized
INFO - 2024-02-27 18:52:39 --> Output Class Initialized
INFO - 2024-02-27 18:52:39 --> Security Class Initialized
DEBUG - 2024-02-27 18:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 18:52:39 --> Input Class Initialized
INFO - 2024-02-27 18:52:39 --> Language Class Initialized
INFO - 2024-02-27 18:52:39 --> Loader Class Initialized
INFO - 2024-02-27 18:52:39 --> Helper loaded: url_helper
INFO - 2024-02-27 18:52:39 --> Helper loaded: file_helper
INFO - 2024-02-27 18:52:39 --> Helper loaded: form_helper
INFO - 2024-02-27 18:52:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 18:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 18:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 18:52:39 --> Controller Class Initialized
INFO - 2024-02-27 18:52:39 --> Model "LoginModel" initialized
INFO - 2024-02-27 18:52:39 --> Form Validation Class Initialized
INFO - 2024-02-27 18:52:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-27 18:52:39 --> Final output sent to browser
DEBUG - 2024-02-27 18:52:39 --> Total execution time: 0.0334
ERROR - 2024-02-27 18:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 18:52:41 --> Config Class Initialized
INFO - 2024-02-27 18:52:41 --> Hooks Class Initialized
DEBUG - 2024-02-27 18:52:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 18:52:41 --> Utf8 Class Initialized
INFO - 2024-02-27 18:52:41 --> URI Class Initialized
INFO - 2024-02-27 18:52:41 --> Router Class Initialized
INFO - 2024-02-27 18:52:41 --> Output Class Initialized
INFO - 2024-02-27 18:52:41 --> Security Class Initialized
DEBUG - 2024-02-27 18:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 18:52:41 --> Input Class Initialized
INFO - 2024-02-27 18:52:41 --> Language Class Initialized
INFO - 2024-02-27 18:52:41 --> Loader Class Initialized
INFO - 2024-02-27 18:52:41 --> Helper loaded: url_helper
INFO - 2024-02-27 18:52:41 --> Helper loaded: file_helper
INFO - 2024-02-27 18:52:41 --> Helper loaded: form_helper
INFO - 2024-02-27 18:52:41 --> Database Driver Class Initialized
DEBUG - 2024-02-27 18:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 18:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 18:52:41 --> Controller Class Initialized
INFO - 2024-02-27 18:52:41 --> Model "LoginModel" initialized
INFO - 2024-02-27 18:52:41 --> Form Validation Class Initialized
INFO - 2024-02-27 18:52:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-27 18:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 18:52:41 --> Config Class Initialized
INFO - 2024-02-27 18:52:41 --> Hooks Class Initialized
DEBUG - 2024-02-27 18:52:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 18:52:41 --> Utf8 Class Initialized
INFO - 2024-02-27 18:52:41 --> URI Class Initialized
INFO - 2024-02-27 18:52:41 --> Router Class Initialized
INFO - 2024-02-27 18:52:41 --> Output Class Initialized
INFO - 2024-02-27 18:52:41 --> Security Class Initialized
DEBUG - 2024-02-27 18:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 18:52:41 --> Input Class Initialized
INFO - 2024-02-27 18:52:41 --> Language Class Initialized
INFO - 2024-02-27 18:52:41 --> Loader Class Initialized
INFO - 2024-02-27 18:52:41 --> Helper loaded: url_helper
INFO - 2024-02-27 18:52:41 --> Helper loaded: file_helper
INFO - 2024-02-27 18:52:41 --> Helper loaded: form_helper
INFO - 2024-02-27 18:52:41 --> Database Driver Class Initialized
DEBUG - 2024-02-27 18:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 18:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 18:52:41 --> Controller Class Initialized
INFO - 2024-02-27 18:52:41 --> Form Validation Class Initialized
INFO - 2024-02-27 18:52:41 --> Model "MasterModel" initialized
INFO - 2024-02-27 18:52:41 --> Model "DashboardModel" initialized
INFO - 2024-02-27 18:52:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 18:52:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 18:52:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 18:52:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 18:52:41 --> Model "OrderModel" initialized
INFO - 2024-02-27 18:52:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 18:52:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 18:52:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 18:52:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 18:52:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 18:52:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 18:52:41 --> Final output sent to browser
DEBUG - 2024-02-27 18:52:41 --> Total execution time: 0.0298
ERROR - 2024-02-27 18:52:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 18:52:42 --> Config Class Initialized
INFO - 2024-02-27 18:52:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 18:52:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 18:52:42 --> Utf8 Class Initialized
INFO - 2024-02-27 18:52:42 --> URI Class Initialized
INFO - 2024-02-27 18:52:42 --> Router Class Initialized
INFO - 2024-02-27 18:52:42 --> Output Class Initialized
INFO - 2024-02-27 18:52:42 --> Security Class Initialized
DEBUG - 2024-02-27 18:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 18:52:42 --> Input Class Initialized
INFO - 2024-02-27 18:52:42 --> Language Class Initialized
INFO - 2024-02-27 18:52:42 --> Loader Class Initialized
INFO - 2024-02-27 18:52:42 --> Helper loaded: url_helper
INFO - 2024-02-27 18:52:42 --> Helper loaded: file_helper
INFO - 2024-02-27 18:52:42 --> Helper loaded: form_helper
INFO - 2024-02-27 18:52:42 --> Database Driver Class Initialized
DEBUG - 2024-02-27 18:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 18:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 18:52:42 --> Controller Class Initialized
INFO - 2024-02-27 18:52:42 --> Form Validation Class Initialized
INFO - 2024-02-27 18:52:42 --> Model "MasterModel" initialized
INFO - 2024-02-27 18:52:42 --> Model "DashboardModel" initialized
INFO - 2024-02-27 18:52:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 18:52:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 18:52:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 18:52:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 18:52:42 --> Model "OrderModel" initialized
ERROR - 2024-02-27 18:52:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 18:52:45 --> Config Class Initialized
INFO - 2024-02-27 18:52:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 18:52:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 18:52:45 --> Utf8 Class Initialized
INFO - 2024-02-27 18:52:45 --> URI Class Initialized
INFO - 2024-02-27 18:52:45 --> Router Class Initialized
INFO - 2024-02-27 18:52:45 --> Output Class Initialized
INFO - 2024-02-27 18:52:45 --> Security Class Initialized
DEBUG - 2024-02-27 18:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 18:52:45 --> Input Class Initialized
INFO - 2024-02-27 18:52:45 --> Language Class Initialized
INFO - 2024-02-27 18:52:45 --> Loader Class Initialized
INFO - 2024-02-27 18:52:45 --> Helper loaded: url_helper
INFO - 2024-02-27 18:52:45 --> Helper loaded: file_helper
INFO - 2024-02-27 18:52:45 --> Helper loaded: form_helper
INFO - 2024-02-27 18:52:45 --> Database Driver Class Initialized
DEBUG - 2024-02-27 18:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 18:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 18:52:45 --> Controller Class Initialized
INFO - 2024-02-27 18:52:45 --> Form Validation Class Initialized
INFO - 2024-02-27 18:52:45 --> Model "MasterModel" initialized
INFO - 2024-02-27 18:52:45 --> Model "DashboardModel" initialized
INFO - 2024-02-27 18:52:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 18:52:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 18:52:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 18:52:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 18:52:45 --> Model "OrderModel" initialized
INFO - 2024-02-27 18:52:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 18:52:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 18:52:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 18:52:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 18:52:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 18:52:45 --> Final output sent to browser
DEBUG - 2024-02-27 18:52:45 --> Total execution time: 0.0380
ERROR - 2024-02-27 18:52:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 18:52:47 --> Config Class Initialized
INFO - 2024-02-27 18:52:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 18:52:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 18:52:47 --> Utf8 Class Initialized
INFO - 2024-02-27 18:52:47 --> URI Class Initialized
INFO - 2024-02-27 18:52:47 --> Router Class Initialized
INFO - 2024-02-27 18:52:47 --> Output Class Initialized
INFO - 2024-02-27 18:52:47 --> Security Class Initialized
DEBUG - 2024-02-27 18:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 18:52:47 --> Input Class Initialized
INFO - 2024-02-27 18:52:47 --> Language Class Initialized
INFO - 2024-02-27 18:52:47 --> Loader Class Initialized
INFO - 2024-02-27 18:52:47 --> Helper loaded: url_helper
INFO - 2024-02-27 18:52:47 --> Helper loaded: file_helper
INFO - 2024-02-27 18:52:47 --> Helper loaded: form_helper
INFO - 2024-02-27 18:52:47 --> Database Driver Class Initialized
DEBUG - 2024-02-27 18:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 18:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 18:52:47 --> Controller Class Initialized
INFO - 2024-02-27 18:52:47 --> Form Validation Class Initialized
INFO - 2024-02-27 18:52:47 --> Model "MasterModel" initialized
INFO - 2024-02-27 18:52:47 --> Model "DashboardModel" initialized
INFO - 2024-02-27 18:52:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 18:52:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 18:52:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 18:52:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 18:52:47 --> Model "OrderModel" initialized
INFO - 2024-02-27 18:52:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 18:52:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 18:52:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 18:52:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 18:52:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 18:52:47 --> Final output sent to browser
DEBUG - 2024-02-27 18:52:47 --> Total execution time: 0.0438
ERROR - 2024-02-27 19:07:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:07:45 --> Config Class Initialized
INFO - 2024-02-27 19:07:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:07:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:07:45 --> Utf8 Class Initialized
INFO - 2024-02-27 19:07:45 --> URI Class Initialized
INFO - 2024-02-27 19:07:45 --> Router Class Initialized
INFO - 2024-02-27 19:07:45 --> Output Class Initialized
INFO - 2024-02-27 19:07:45 --> Security Class Initialized
DEBUG - 2024-02-27 19:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:07:45 --> Input Class Initialized
INFO - 2024-02-27 19:07:45 --> Language Class Initialized
INFO - 2024-02-27 19:07:45 --> Loader Class Initialized
INFO - 2024-02-27 19:07:45 --> Helper loaded: url_helper
INFO - 2024-02-27 19:07:45 --> Helper loaded: file_helper
INFO - 2024-02-27 19:07:45 --> Helper loaded: form_helper
INFO - 2024-02-27 19:07:45 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:07:45 --> Controller Class Initialized
INFO - 2024-02-27 19:07:45 --> Form Validation Class Initialized
INFO - 2024-02-27 19:07:45 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:07:45 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:07:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:07:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:07:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:07:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:07:45 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:07:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:07:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:07:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:07:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:07:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:07:45 --> Final output sent to browser
DEBUG - 2024-02-27 19:07:45 --> Total execution time: 0.0416
ERROR - 2024-02-27 19:07:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:07:48 --> Config Class Initialized
INFO - 2024-02-27 19:07:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:07:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:07:48 --> Utf8 Class Initialized
INFO - 2024-02-27 19:07:48 --> URI Class Initialized
INFO - 2024-02-27 19:07:48 --> Router Class Initialized
INFO - 2024-02-27 19:07:48 --> Output Class Initialized
INFO - 2024-02-27 19:07:48 --> Security Class Initialized
DEBUG - 2024-02-27 19:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:07:48 --> Input Class Initialized
INFO - 2024-02-27 19:07:48 --> Language Class Initialized
INFO - 2024-02-27 19:07:48 --> Loader Class Initialized
INFO - 2024-02-27 19:07:48 --> Helper loaded: url_helper
INFO - 2024-02-27 19:07:48 --> Helper loaded: file_helper
INFO - 2024-02-27 19:07:48 --> Helper loaded: form_helper
INFO - 2024-02-27 19:07:48 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:07:48 --> Controller Class Initialized
INFO - 2024-02-27 19:07:48 --> Form Validation Class Initialized
INFO - 2024-02-27 19:07:48 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:07:48 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:07:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:07:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:07:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:07:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:07:48 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:07:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/change_password.php
INFO - 2024-02-27 19:07:48 --> Final output sent to browser
DEBUG - 2024-02-27 19:07:48 --> Total execution time: 0.0469
ERROR - 2024-02-27 19:08:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:10 --> Config Class Initialized
INFO - 2024-02-27 19:08:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:10 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:10 --> URI Class Initialized
INFO - 2024-02-27 19:08:10 --> Router Class Initialized
INFO - 2024-02-27 19:08:10 --> Output Class Initialized
INFO - 2024-02-27 19:08:10 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:10 --> Input Class Initialized
INFO - 2024-02-27 19:08:10 --> Language Class Initialized
INFO - 2024-02-27 19:08:10 --> Loader Class Initialized
INFO - 2024-02-27 19:08:10 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:10 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:10 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:10 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:10 --> Controller Class Initialized
INFO - 2024-02-27 19:08:10 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:10 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:10 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:10 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:08:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:13 --> Config Class Initialized
INFO - 2024-02-27 19:08:13 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:13 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:13 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:13 --> URI Class Initialized
INFO - 2024-02-27 19:08:13 --> Router Class Initialized
INFO - 2024-02-27 19:08:13 --> Output Class Initialized
INFO - 2024-02-27 19:08:13 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:13 --> Input Class Initialized
INFO - 2024-02-27 19:08:13 --> Language Class Initialized
INFO - 2024-02-27 19:08:13 --> Loader Class Initialized
INFO - 2024-02-27 19:08:13 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:13 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:13 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:13 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:13 --> Controller Class Initialized
INFO - 2024-02-27 19:08:13 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:13 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:13 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:13 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:08:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:08:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:08:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:08:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:08:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:08:13 --> Final output sent to browser
DEBUG - 2024-02-27 19:08:13 --> Total execution time: 0.0407
ERROR - 2024-02-27 19:08:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:16 --> Config Class Initialized
INFO - 2024-02-27 19:08:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:16 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:16 --> URI Class Initialized
INFO - 2024-02-27 19:08:16 --> Router Class Initialized
INFO - 2024-02-27 19:08:16 --> Output Class Initialized
INFO - 2024-02-27 19:08:16 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:16 --> Input Class Initialized
INFO - 2024-02-27 19:08:16 --> Language Class Initialized
INFO - 2024-02-27 19:08:16 --> Loader Class Initialized
INFO - 2024-02-27 19:08:16 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:16 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:16 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:16 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:16 --> Controller Class Initialized
INFO - 2024-02-27 19:08:16 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:16 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:16 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:16 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:08:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:08:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:08:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:08:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:08:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:08:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:08:16 --> Final output sent to browser
DEBUG - 2024-02-27 19:08:16 --> Total execution time: 0.0362
ERROR - 2024-02-27 19:08:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:16 --> Config Class Initialized
INFO - 2024-02-27 19:08:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:16 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:16 --> URI Class Initialized
INFO - 2024-02-27 19:08:16 --> Router Class Initialized
INFO - 2024-02-27 19:08:16 --> Output Class Initialized
INFO - 2024-02-27 19:08:16 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:16 --> Input Class Initialized
INFO - 2024-02-27 19:08:16 --> Language Class Initialized
INFO - 2024-02-27 19:08:16 --> Loader Class Initialized
INFO - 2024-02-27 19:08:16 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:16 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:16 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:16 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:16 --> Controller Class Initialized
INFO - 2024-02-27 19:08:16 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:16 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:16 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:16 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:08:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:19 --> Config Class Initialized
INFO - 2024-02-27 19:08:19 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:19 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:19 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:19 --> URI Class Initialized
INFO - 2024-02-27 19:08:19 --> Router Class Initialized
INFO - 2024-02-27 19:08:19 --> Output Class Initialized
INFO - 2024-02-27 19:08:19 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:19 --> Input Class Initialized
INFO - 2024-02-27 19:08:19 --> Language Class Initialized
INFO - 2024-02-27 19:08:19 --> Loader Class Initialized
INFO - 2024-02-27 19:08:19 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:19 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:19 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:19 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:19 --> Controller Class Initialized
INFO - 2024-02-27 19:08:19 --> Model "LoginModel" initialized
INFO - 2024-02-27 19:08:19 --> Form Validation Class Initialized
ERROR - 2024-02-27 19:08:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:19 --> Config Class Initialized
INFO - 2024-02-27 19:08:19 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:19 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:19 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:19 --> URI Class Initialized
INFO - 2024-02-27 19:08:19 --> Router Class Initialized
INFO - 2024-02-27 19:08:19 --> Output Class Initialized
INFO - 2024-02-27 19:08:19 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:19 --> Input Class Initialized
INFO - 2024-02-27 19:08:19 --> Language Class Initialized
INFO - 2024-02-27 19:08:19 --> Loader Class Initialized
INFO - 2024-02-27 19:08:19 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:19 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:19 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:19 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:19 --> Controller Class Initialized
INFO - 2024-02-27 19:08:19 --> Model "LoginModel" initialized
INFO - 2024-02-27 19:08:19 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-27 19:08:19 --> Final output sent to browser
DEBUG - 2024-02-27 19:08:19 --> Total execution time: 0.0236
ERROR - 2024-02-27 19:08:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:25 --> Config Class Initialized
INFO - 2024-02-27 19:08:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:25 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:25 --> URI Class Initialized
INFO - 2024-02-27 19:08:25 --> Router Class Initialized
INFO - 2024-02-27 19:08:25 --> Output Class Initialized
INFO - 2024-02-27 19:08:25 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:25 --> Input Class Initialized
INFO - 2024-02-27 19:08:25 --> Language Class Initialized
INFO - 2024-02-27 19:08:25 --> Loader Class Initialized
INFO - 2024-02-27 19:08:25 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:25 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:25 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:25 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:25 --> Controller Class Initialized
INFO - 2024-02-27 19:08:25 --> Model "LoginModel" initialized
INFO - 2024-02-27 19:08:25 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-27 19:08:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:25 --> Config Class Initialized
INFO - 2024-02-27 19:08:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:25 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:25 --> URI Class Initialized
INFO - 2024-02-27 19:08:25 --> Router Class Initialized
INFO - 2024-02-27 19:08:25 --> Output Class Initialized
INFO - 2024-02-27 19:08:25 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:25 --> Input Class Initialized
INFO - 2024-02-27 19:08:25 --> Language Class Initialized
INFO - 2024-02-27 19:08:25 --> Loader Class Initialized
INFO - 2024-02-27 19:08:25 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:25 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:25 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:25 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:25 --> Controller Class Initialized
INFO - 2024-02-27 19:08:25 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:25 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:25 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:25 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:08:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:08:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:08:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:08:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:08:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:08:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:08:25 --> Final output sent to browser
DEBUG - 2024-02-27 19:08:25 --> Total execution time: 0.0302
ERROR - 2024-02-27 19:08:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:25 --> Config Class Initialized
INFO - 2024-02-27 19:08:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:25 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:25 --> URI Class Initialized
INFO - 2024-02-27 19:08:25 --> Router Class Initialized
INFO - 2024-02-27 19:08:25 --> Output Class Initialized
INFO - 2024-02-27 19:08:25 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:25 --> Input Class Initialized
INFO - 2024-02-27 19:08:25 --> Language Class Initialized
INFO - 2024-02-27 19:08:25 --> Loader Class Initialized
INFO - 2024-02-27 19:08:25 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:25 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:25 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:25 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:26 --> Controller Class Initialized
INFO - 2024-02-27 19:08:26 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:26 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:26 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:26 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:08:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:28 --> Config Class Initialized
INFO - 2024-02-27 19:08:28 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:28 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:28 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:28 --> URI Class Initialized
INFO - 2024-02-27 19:08:28 --> Router Class Initialized
INFO - 2024-02-27 19:08:28 --> Output Class Initialized
INFO - 2024-02-27 19:08:28 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:28 --> Input Class Initialized
INFO - 2024-02-27 19:08:28 --> Language Class Initialized
INFO - 2024-02-27 19:08:28 --> Loader Class Initialized
INFO - 2024-02-27 19:08:28 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:28 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:28 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:28 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:28 --> Controller Class Initialized
INFO - 2024-02-27 19:08:28 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:28 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:28 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:28 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:08:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:08:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:08:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:08:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:08:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:08:28 --> Final output sent to browser
DEBUG - 2024-02-27 19:08:28 --> Total execution time: 0.0451
ERROR - 2024-02-27 19:08:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:30 --> Config Class Initialized
INFO - 2024-02-27 19:08:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:30 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:30 --> URI Class Initialized
INFO - 2024-02-27 19:08:30 --> Router Class Initialized
INFO - 2024-02-27 19:08:30 --> Output Class Initialized
INFO - 2024-02-27 19:08:30 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:30 --> Input Class Initialized
INFO - 2024-02-27 19:08:30 --> Language Class Initialized
INFO - 2024-02-27 19:08:30 --> Loader Class Initialized
INFO - 2024-02-27 19:08:30 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:30 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:30 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:30 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:30 --> Controller Class Initialized
INFO - 2024-02-27 19:08:30 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:30 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:30 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:30 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:08:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:08:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:08:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:08:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:08:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:08:30 --> Final output sent to browser
DEBUG - 2024-02-27 19:08:30 --> Total execution time: 0.0461
ERROR - 2024-02-27 19:08:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:31 --> Config Class Initialized
INFO - 2024-02-27 19:08:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:31 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:31 --> URI Class Initialized
INFO - 2024-02-27 19:08:31 --> Router Class Initialized
INFO - 2024-02-27 19:08:31 --> Output Class Initialized
INFO - 2024-02-27 19:08:31 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:31 --> Input Class Initialized
INFO - 2024-02-27 19:08:31 --> Language Class Initialized
INFO - 2024-02-27 19:08:31 --> Loader Class Initialized
INFO - 2024-02-27 19:08:31 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:31 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:31 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:31 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:31 --> Controller Class Initialized
INFO - 2024-02-27 19:08:31 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:31 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:31 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:31 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:08:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/change_password.php
INFO - 2024-02-27 19:08:31 --> Final output sent to browser
DEBUG - 2024-02-27 19:08:31 --> Total execution time: 0.0290
ERROR - 2024-02-27 19:08:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:48 --> Config Class Initialized
INFO - 2024-02-27 19:08:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:48 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:48 --> URI Class Initialized
INFO - 2024-02-27 19:08:48 --> Router Class Initialized
INFO - 2024-02-27 19:08:48 --> Output Class Initialized
INFO - 2024-02-27 19:08:48 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:48 --> Input Class Initialized
INFO - 2024-02-27 19:08:48 --> Language Class Initialized
INFO - 2024-02-27 19:08:48 --> Loader Class Initialized
INFO - 2024-02-27 19:08:48 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:48 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:48 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:48 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:48 --> Controller Class Initialized
INFO - 2024-02-27 19:08:48 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:48 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:48 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:48 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:08:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:56 --> Config Class Initialized
INFO - 2024-02-27 19:08:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:56 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:56 --> URI Class Initialized
INFO - 2024-02-27 19:08:56 --> Router Class Initialized
INFO - 2024-02-27 19:08:56 --> Output Class Initialized
INFO - 2024-02-27 19:08:56 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:56 --> Input Class Initialized
INFO - 2024-02-27 19:08:56 --> Language Class Initialized
INFO - 2024-02-27 19:08:56 --> Loader Class Initialized
INFO - 2024-02-27 19:08:56 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:56 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:56 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:56 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:56 --> Controller Class Initialized
INFO - 2024-02-27 19:08:56 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:56 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:56 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:56 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:08:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:08:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:08:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:08:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:08:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:08:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:08:56 --> Final output sent to browser
DEBUG - 2024-02-27 19:08:56 --> Total execution time: 0.0588
ERROR - 2024-02-27 19:08:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:57 --> Config Class Initialized
INFO - 2024-02-27 19:08:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:57 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:57 --> URI Class Initialized
INFO - 2024-02-27 19:08:57 --> Router Class Initialized
INFO - 2024-02-27 19:08:57 --> Output Class Initialized
INFO - 2024-02-27 19:08:57 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:57 --> Input Class Initialized
INFO - 2024-02-27 19:08:57 --> Language Class Initialized
INFO - 2024-02-27 19:08:57 --> Loader Class Initialized
INFO - 2024-02-27 19:08:57 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:57 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:57 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:57 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:57 --> Controller Class Initialized
INFO - 2024-02-27 19:08:57 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:57 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:57 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:57 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:08:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:59 --> Config Class Initialized
INFO - 2024-02-27 19:08:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:59 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:59 --> URI Class Initialized
INFO - 2024-02-27 19:08:59 --> Router Class Initialized
INFO - 2024-02-27 19:08:59 --> Output Class Initialized
INFO - 2024-02-27 19:08:59 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:59 --> Input Class Initialized
INFO - 2024-02-27 19:08:59 --> Language Class Initialized
INFO - 2024-02-27 19:08:59 --> Loader Class Initialized
INFO - 2024-02-27 19:08:59 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:59 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:59 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:59 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:59 --> Controller Class Initialized
INFO - 2024-02-27 19:08:59 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:59 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:59 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:59 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-27 19:08:59 --> Final output sent to browser
DEBUG - 2024-02-27 19:08:59 --> Total execution time: 0.0307
ERROR - 2024-02-27 19:08:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:08:59 --> Config Class Initialized
INFO - 2024-02-27 19:08:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:08:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:08:59 --> Utf8 Class Initialized
INFO - 2024-02-27 19:08:59 --> URI Class Initialized
INFO - 2024-02-27 19:08:59 --> Router Class Initialized
INFO - 2024-02-27 19:08:59 --> Output Class Initialized
INFO - 2024-02-27 19:08:59 --> Security Class Initialized
DEBUG - 2024-02-27 19:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:08:59 --> Input Class Initialized
INFO - 2024-02-27 19:08:59 --> Language Class Initialized
INFO - 2024-02-27 19:08:59 --> Loader Class Initialized
INFO - 2024-02-27 19:08:59 --> Helper loaded: url_helper
INFO - 2024-02-27 19:08:59 --> Helper loaded: file_helper
INFO - 2024-02-27 19:08:59 --> Helper loaded: form_helper
INFO - 2024-02-27 19:08:59 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:08:59 --> Controller Class Initialized
INFO - 2024-02-27 19:08:59 --> Form Validation Class Initialized
INFO - 2024-02-27 19:08:59 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:08:59 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:08:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:08:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:08:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:08:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:08:59 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:09:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:09:31 --> Config Class Initialized
INFO - 2024-02-27 19:09:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:09:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:09:31 --> Utf8 Class Initialized
INFO - 2024-02-27 19:09:31 --> URI Class Initialized
INFO - 2024-02-27 19:09:31 --> Router Class Initialized
INFO - 2024-02-27 19:09:31 --> Output Class Initialized
INFO - 2024-02-27 19:09:31 --> Security Class Initialized
DEBUG - 2024-02-27 19:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:09:31 --> Input Class Initialized
INFO - 2024-02-27 19:09:31 --> Language Class Initialized
INFO - 2024-02-27 19:09:31 --> Loader Class Initialized
INFO - 2024-02-27 19:09:31 --> Helper loaded: url_helper
INFO - 2024-02-27 19:09:31 --> Helper loaded: file_helper
INFO - 2024-02-27 19:09:31 --> Helper loaded: form_helper
INFO - 2024-02-27 19:09:31 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:09:31 --> Controller Class Initialized
INFO - 2024-02-27 19:09:31 --> Form Validation Class Initialized
INFO - 2024-02-27 19:09:31 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:09:31 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:09:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:09:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:09:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:09:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:09:31 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:09:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:09:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:09:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:09:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:09:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-27 19:09:31 --> Final output sent to browser
DEBUG - 2024-02-27 19:09:31 --> Total execution time: 0.0281
ERROR - 2024-02-27 19:09:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:09:31 --> Config Class Initialized
INFO - 2024-02-27 19:09:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:09:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:09:31 --> Utf8 Class Initialized
INFO - 2024-02-27 19:09:31 --> URI Class Initialized
INFO - 2024-02-27 19:09:31 --> Router Class Initialized
INFO - 2024-02-27 19:09:31 --> Output Class Initialized
INFO - 2024-02-27 19:09:31 --> Security Class Initialized
DEBUG - 2024-02-27 19:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:09:31 --> Input Class Initialized
INFO - 2024-02-27 19:09:31 --> Language Class Initialized
INFO - 2024-02-27 19:09:31 --> Loader Class Initialized
INFO - 2024-02-27 19:09:31 --> Helper loaded: url_helper
INFO - 2024-02-27 19:09:31 --> Helper loaded: file_helper
INFO - 2024-02-27 19:09:31 --> Helper loaded: form_helper
INFO - 2024-02-27 19:09:31 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:09:31 --> Controller Class Initialized
INFO - 2024-02-27 19:09:31 --> Form Validation Class Initialized
INFO - 2024-02-27 19:09:31 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:09:31 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:09:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:09:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:09:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:09:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:09:31 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:09:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:09:34 --> Config Class Initialized
INFO - 2024-02-27 19:09:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:09:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:09:34 --> Utf8 Class Initialized
INFO - 2024-02-27 19:09:34 --> URI Class Initialized
INFO - 2024-02-27 19:09:34 --> Router Class Initialized
INFO - 2024-02-27 19:09:34 --> Output Class Initialized
INFO - 2024-02-27 19:09:34 --> Security Class Initialized
DEBUG - 2024-02-27 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:09:34 --> Input Class Initialized
INFO - 2024-02-27 19:09:34 --> Language Class Initialized
INFO - 2024-02-27 19:09:34 --> Loader Class Initialized
INFO - 2024-02-27 19:09:34 --> Helper loaded: url_helper
INFO - 2024-02-27 19:09:34 --> Helper loaded: file_helper
INFO - 2024-02-27 19:09:34 --> Helper loaded: form_helper
INFO - 2024-02-27 19:09:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:09:34 --> Controller Class Initialized
INFO - 2024-02-27 19:09:34 --> Form Validation Class Initialized
INFO - 2024-02-27 19:09:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:09:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:09:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:09:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:09:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:09:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:09:34 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:09:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:09:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:09:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:09:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:09:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:09:34 --> Final output sent to browser
DEBUG - 2024-02-27 19:09:34 --> Total execution time: 0.0319
ERROR - 2024-02-27 19:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:09:36 --> Config Class Initialized
INFO - 2024-02-27 19:09:36 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:09:36 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:09:36 --> Utf8 Class Initialized
INFO - 2024-02-27 19:09:36 --> URI Class Initialized
INFO - 2024-02-27 19:09:36 --> Router Class Initialized
INFO - 2024-02-27 19:09:36 --> Output Class Initialized
INFO - 2024-02-27 19:09:36 --> Security Class Initialized
DEBUG - 2024-02-27 19:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:09:36 --> Input Class Initialized
INFO - 2024-02-27 19:09:36 --> Language Class Initialized
INFO - 2024-02-27 19:09:36 --> Loader Class Initialized
INFO - 2024-02-27 19:09:36 --> Helper loaded: url_helper
INFO - 2024-02-27 19:09:36 --> Helper loaded: file_helper
INFO - 2024-02-27 19:09:36 --> Helper loaded: form_helper
INFO - 2024-02-27 19:09:36 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:09:36 --> Controller Class Initialized
INFO - 2024-02-27 19:09:36 --> Form Validation Class Initialized
INFO - 2024-02-27 19:09:36 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:09:36 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:09:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:09:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:09:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:09:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:09:36 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:09:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:09:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:09:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:09:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:09:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:09:36 --> Final output sent to browser
DEBUG - 2024-02-27 19:09:36 --> Total execution time: 0.0339
ERROR - 2024-02-27 19:10:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:02 --> Config Class Initialized
INFO - 2024-02-27 19:10:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:02 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:02 --> URI Class Initialized
INFO - 2024-02-27 19:10:02 --> Router Class Initialized
INFO - 2024-02-27 19:10:02 --> Output Class Initialized
INFO - 2024-02-27 19:10:02 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:02 --> Input Class Initialized
INFO - 2024-02-27 19:10:02 --> Language Class Initialized
INFO - 2024-02-27 19:10:02 --> Loader Class Initialized
INFO - 2024-02-27 19:10:02 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:02 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:02 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:02 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:02 --> Controller Class Initialized
INFO - 2024-02-27 19:10:02 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:02 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:02 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:02 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:10:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:10:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:10:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:10:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:10:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:10:02 --> Final output sent to browser
DEBUG - 2024-02-27 19:10:02 --> Total execution time: 0.0402
ERROR - 2024-02-27 19:10:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:07 --> Config Class Initialized
INFO - 2024-02-27 19:10:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:07 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:07 --> URI Class Initialized
INFO - 2024-02-27 19:10:07 --> Router Class Initialized
INFO - 2024-02-27 19:10:07 --> Output Class Initialized
INFO - 2024-02-27 19:10:07 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:07 --> Input Class Initialized
INFO - 2024-02-27 19:10:07 --> Language Class Initialized
INFO - 2024-02-27 19:10:07 --> Loader Class Initialized
INFO - 2024-02-27 19:10:07 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:07 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:07 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:07 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:07 --> Controller Class Initialized
INFO - 2024-02-27 19:10:07 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:07 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:07 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:07 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:10:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:10:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:10:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:10:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:10:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:10:07 --> Final output sent to browser
DEBUG - 2024-02-27 19:10:07 --> Total execution time: 0.0287
ERROR - 2024-02-27 19:10:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:12 --> Config Class Initialized
INFO - 2024-02-27 19:10:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:12 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:12 --> URI Class Initialized
INFO - 2024-02-27 19:10:12 --> Router Class Initialized
INFO - 2024-02-27 19:10:12 --> Output Class Initialized
INFO - 2024-02-27 19:10:12 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:12 --> Input Class Initialized
INFO - 2024-02-27 19:10:12 --> Language Class Initialized
INFO - 2024-02-27 19:10:12 --> Loader Class Initialized
INFO - 2024-02-27 19:10:12 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:12 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:12 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:12 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:12 --> Controller Class Initialized
INFO - 2024-02-27 19:10:12 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:12 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:12 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:12 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:10:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:10:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:10:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:10:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:10:12 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-27 19:10:12 --> Final output sent to browser
DEBUG - 2024-02-27 19:10:12 --> Total execution time: 0.0274
ERROR - 2024-02-27 19:10:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:12 --> Config Class Initialized
INFO - 2024-02-27 19:10:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:12 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:12 --> URI Class Initialized
INFO - 2024-02-27 19:10:12 --> Router Class Initialized
INFO - 2024-02-27 19:10:12 --> Output Class Initialized
INFO - 2024-02-27 19:10:12 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:12 --> Input Class Initialized
INFO - 2024-02-27 19:10:12 --> Language Class Initialized
INFO - 2024-02-27 19:10:12 --> Loader Class Initialized
INFO - 2024-02-27 19:10:12 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:12 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:12 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:12 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:12 --> Controller Class Initialized
INFO - 2024-02-27 19:10:12 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:12 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:12 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:12 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:10:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:15 --> Config Class Initialized
INFO - 2024-02-27 19:10:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:15 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:15 --> URI Class Initialized
INFO - 2024-02-27 19:10:15 --> Router Class Initialized
INFO - 2024-02-27 19:10:15 --> Output Class Initialized
INFO - 2024-02-27 19:10:15 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:15 --> Input Class Initialized
INFO - 2024-02-27 19:10:15 --> Language Class Initialized
INFO - 2024-02-27 19:10:15 --> Loader Class Initialized
INFO - 2024-02-27 19:10:15 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:15 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:15 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:15 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:15 --> Controller Class Initialized
INFO - 2024-02-27 19:10:15 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:15 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:15 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:15 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:10:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:10:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:10:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:10:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:10:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:10:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:10:15 --> Final output sent to browser
DEBUG - 2024-02-27 19:10:15 --> Total execution time: 0.0343
ERROR - 2024-02-27 19:10:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:15 --> Config Class Initialized
INFO - 2024-02-27 19:10:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:15 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:15 --> URI Class Initialized
INFO - 2024-02-27 19:10:15 --> Router Class Initialized
INFO - 2024-02-27 19:10:15 --> Output Class Initialized
INFO - 2024-02-27 19:10:15 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:15 --> Input Class Initialized
INFO - 2024-02-27 19:10:15 --> Language Class Initialized
INFO - 2024-02-27 19:10:15 --> Loader Class Initialized
INFO - 2024-02-27 19:10:15 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:15 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:15 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:15 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:15 --> Controller Class Initialized
INFO - 2024-02-27 19:10:15 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:15 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:15 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:15 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:10:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:19 --> Config Class Initialized
INFO - 2024-02-27 19:10:19 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:19 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:19 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:19 --> URI Class Initialized
INFO - 2024-02-27 19:10:19 --> Router Class Initialized
INFO - 2024-02-27 19:10:19 --> Output Class Initialized
INFO - 2024-02-27 19:10:19 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:19 --> Input Class Initialized
INFO - 2024-02-27 19:10:19 --> Language Class Initialized
INFO - 2024-02-27 19:10:19 --> Loader Class Initialized
INFO - 2024-02-27 19:10:19 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:19 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:19 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:19 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:19 --> Controller Class Initialized
INFO - 2024-02-27 19:10:19 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:19 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:19 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:19 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:10:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:10:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:10:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:10:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:10:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-27 19:10:19 --> Final output sent to browser
DEBUG - 2024-02-27 19:10:19 --> Total execution time: 0.0283
ERROR - 2024-02-27 19:10:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:19 --> Config Class Initialized
INFO - 2024-02-27 19:10:19 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:19 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:19 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:19 --> URI Class Initialized
INFO - 2024-02-27 19:10:19 --> Router Class Initialized
INFO - 2024-02-27 19:10:19 --> Output Class Initialized
INFO - 2024-02-27 19:10:19 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:19 --> Input Class Initialized
INFO - 2024-02-27 19:10:19 --> Language Class Initialized
INFO - 2024-02-27 19:10:19 --> Loader Class Initialized
INFO - 2024-02-27 19:10:19 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:19 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:19 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:19 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:19 --> Controller Class Initialized
INFO - 2024-02-27 19:10:19 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:19 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:19 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:19 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:10:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:21 --> Config Class Initialized
INFO - 2024-02-27 19:10:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:21 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:21 --> URI Class Initialized
INFO - 2024-02-27 19:10:21 --> Router Class Initialized
INFO - 2024-02-27 19:10:21 --> Output Class Initialized
INFO - 2024-02-27 19:10:21 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:21 --> Input Class Initialized
INFO - 2024-02-27 19:10:21 --> Language Class Initialized
INFO - 2024-02-27 19:10:21 --> Loader Class Initialized
INFO - 2024-02-27 19:10:21 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:21 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:21 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:21 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:21 --> Controller Class Initialized
INFO - 2024-02-27 19:10:21 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:21 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:21 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:21 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:10:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:10:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:10:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:10:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:10:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:10:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:10:21 --> Final output sent to browser
DEBUG - 2024-02-27 19:10:21 --> Total execution time: 0.0350
ERROR - 2024-02-27 19:10:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:21 --> Config Class Initialized
INFO - 2024-02-27 19:10:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:21 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:21 --> URI Class Initialized
INFO - 2024-02-27 19:10:21 --> Router Class Initialized
INFO - 2024-02-27 19:10:21 --> Output Class Initialized
INFO - 2024-02-27 19:10:21 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:21 --> Input Class Initialized
INFO - 2024-02-27 19:10:21 --> Language Class Initialized
INFO - 2024-02-27 19:10:21 --> Loader Class Initialized
INFO - 2024-02-27 19:10:21 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:21 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:21 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:21 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:21 --> Controller Class Initialized
INFO - 2024-02-27 19:10:21 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:21 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:21 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:21 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:10:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:24 --> Config Class Initialized
INFO - 2024-02-27 19:10:24 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:24 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:24 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:24 --> URI Class Initialized
INFO - 2024-02-27 19:10:24 --> Router Class Initialized
INFO - 2024-02-27 19:10:24 --> Output Class Initialized
INFO - 2024-02-27 19:10:24 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:24 --> Input Class Initialized
INFO - 2024-02-27 19:10:24 --> Language Class Initialized
INFO - 2024-02-27 19:10:24 --> Loader Class Initialized
INFO - 2024-02-27 19:10:24 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:24 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:24 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:24 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:24 --> Controller Class Initialized
INFO - 2024-02-27 19:10:24 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:24 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:24 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:24 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:10:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:10:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:10:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:10:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:10:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-27 19:10:24 --> Final output sent to browser
DEBUG - 2024-02-27 19:10:24 --> Total execution time: 0.0256
ERROR - 2024-02-27 19:10:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:24 --> Config Class Initialized
INFO - 2024-02-27 19:10:24 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:24 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:24 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:24 --> URI Class Initialized
INFO - 2024-02-27 19:10:24 --> Router Class Initialized
INFO - 2024-02-27 19:10:24 --> Output Class Initialized
INFO - 2024-02-27 19:10:24 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:24 --> Input Class Initialized
INFO - 2024-02-27 19:10:24 --> Language Class Initialized
INFO - 2024-02-27 19:10:24 --> Loader Class Initialized
INFO - 2024-02-27 19:10:24 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:24 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:24 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:24 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:24 --> Controller Class Initialized
INFO - 2024-02-27 19:10:24 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:24 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:24 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:24 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:10:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:26 --> Config Class Initialized
INFO - 2024-02-27 19:10:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:26 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:26 --> URI Class Initialized
INFO - 2024-02-27 19:10:26 --> Router Class Initialized
INFO - 2024-02-27 19:10:26 --> Output Class Initialized
INFO - 2024-02-27 19:10:26 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:26 --> Input Class Initialized
INFO - 2024-02-27 19:10:26 --> Language Class Initialized
INFO - 2024-02-27 19:10:26 --> Loader Class Initialized
INFO - 2024-02-27 19:10:26 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:26 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:26 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:26 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:26 --> Controller Class Initialized
INFO - 2024-02-27 19:10:26 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:26 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:26 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:26 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:10:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:10:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:10:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:10:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:10:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-27 19:10:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-27 19:10:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-27 19:10:26 --> Final output sent to browser
DEBUG - 2024-02-27 19:10:26 --> Total execution time: 0.0339
ERROR - 2024-02-27 19:10:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:26 --> Config Class Initialized
INFO - 2024-02-27 19:10:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:26 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:26 --> URI Class Initialized
INFO - 2024-02-27 19:10:26 --> Router Class Initialized
INFO - 2024-02-27 19:10:26 --> Output Class Initialized
INFO - 2024-02-27 19:10:26 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:26 --> Input Class Initialized
INFO - 2024-02-27 19:10:26 --> Language Class Initialized
INFO - 2024-02-27 19:10:26 --> Loader Class Initialized
INFO - 2024-02-27 19:10:26 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:26 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:26 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:26 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:26 --> Controller Class Initialized
INFO - 2024-02-27 19:10:26 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:26 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:26 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:26 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:10:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:28 --> Config Class Initialized
INFO - 2024-02-27 19:10:28 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:28 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:28 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:28 --> URI Class Initialized
INFO - 2024-02-27 19:10:28 --> Router Class Initialized
INFO - 2024-02-27 19:10:28 --> Output Class Initialized
INFO - 2024-02-27 19:10:28 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:28 --> Input Class Initialized
INFO - 2024-02-27 19:10:28 --> Language Class Initialized
INFO - 2024-02-27 19:10:28 --> Loader Class Initialized
INFO - 2024-02-27 19:10:28 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:28 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:28 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:28 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:28 --> Controller Class Initialized
INFO - 2024-02-27 19:10:28 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:28 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:28 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:28 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:10:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:10:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:10:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:10:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:10:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:10:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:10:28 --> Final output sent to browser
DEBUG - 2024-02-27 19:10:28 --> Total execution time: 0.0395
ERROR - 2024-02-27 19:10:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:28 --> Config Class Initialized
INFO - 2024-02-27 19:10:28 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:28 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:28 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:28 --> URI Class Initialized
INFO - 2024-02-27 19:10:28 --> Router Class Initialized
INFO - 2024-02-27 19:10:28 --> Output Class Initialized
INFO - 2024-02-27 19:10:28 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:28 --> Input Class Initialized
INFO - 2024-02-27 19:10:28 --> Language Class Initialized
INFO - 2024-02-27 19:10:28 --> Loader Class Initialized
INFO - 2024-02-27 19:10:28 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:28 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:28 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:28 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:28 --> Controller Class Initialized
INFO - 2024-02-27 19:10:28 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:28 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:28 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:28 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:10:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:34 --> Config Class Initialized
INFO - 2024-02-27 19:10:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:34 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:34 --> URI Class Initialized
INFO - 2024-02-27 19:10:34 --> Router Class Initialized
INFO - 2024-02-27 19:10:34 --> Output Class Initialized
INFO - 2024-02-27 19:10:34 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:34 --> Input Class Initialized
INFO - 2024-02-27 19:10:34 --> Language Class Initialized
INFO - 2024-02-27 19:10:34 --> Loader Class Initialized
INFO - 2024-02-27 19:10:34 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:34 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:34 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:34 --> Controller Class Initialized
INFO - 2024-02-27 19:10:34 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:34 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:10:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:10:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:10:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:10:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:10:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-27 19:10:34 --> Final output sent to browser
DEBUG - 2024-02-27 19:10:34 --> Total execution time: 0.0337
ERROR - 2024-02-27 19:10:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:10:34 --> Config Class Initialized
INFO - 2024-02-27 19:10:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:10:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:10:34 --> Utf8 Class Initialized
INFO - 2024-02-27 19:10:34 --> URI Class Initialized
INFO - 2024-02-27 19:10:34 --> Router Class Initialized
INFO - 2024-02-27 19:10:34 --> Output Class Initialized
INFO - 2024-02-27 19:10:34 --> Security Class Initialized
DEBUG - 2024-02-27 19:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:10:34 --> Input Class Initialized
INFO - 2024-02-27 19:10:34 --> Language Class Initialized
INFO - 2024-02-27 19:10:34 --> Loader Class Initialized
INFO - 2024-02-27 19:10:34 --> Helper loaded: url_helper
INFO - 2024-02-27 19:10:34 --> Helper loaded: file_helper
INFO - 2024-02-27 19:10:34 --> Helper loaded: form_helper
INFO - 2024-02-27 19:10:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:10:34 --> Controller Class Initialized
INFO - 2024-02-27 19:10:34 --> Form Validation Class Initialized
INFO - 2024-02-27 19:10:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:10:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:10:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:10:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:10:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:10:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:10:34 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:03 --> Config Class Initialized
INFO - 2024-02-27 19:11:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:03 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:03 --> URI Class Initialized
INFO - 2024-02-27 19:11:03 --> Router Class Initialized
INFO - 2024-02-27 19:11:03 --> Output Class Initialized
INFO - 2024-02-27 19:11:03 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:03 --> Input Class Initialized
INFO - 2024-02-27 19:11:03 --> Language Class Initialized
INFO - 2024-02-27 19:11:03 --> Loader Class Initialized
INFO - 2024-02-27 19:11:03 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:03 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:03 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:03 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:03 --> Controller Class Initialized
INFO - 2024-02-27 19:11:03 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:03 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:11:03 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:11:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:11:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:11:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:11:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:11:03 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:11:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-27 19:11:03 --> Final output sent to browser
DEBUG - 2024-02-27 19:11:03 --> Total execution time: 0.0243
ERROR - 2024-02-27 19:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:03 --> Config Class Initialized
INFO - 2024-02-27 19:11:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:03 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:03 --> URI Class Initialized
INFO - 2024-02-27 19:11:03 --> Router Class Initialized
INFO - 2024-02-27 19:11:03 --> Output Class Initialized
INFO - 2024-02-27 19:11:03 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:03 --> Input Class Initialized
INFO - 2024-02-27 19:11:03 --> Language Class Initialized
INFO - 2024-02-27 19:11:03 --> Loader Class Initialized
INFO - 2024-02-27 19:11:03 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:03 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:03 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:03 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:03 --> Controller Class Initialized
INFO - 2024-02-27 19:11:03 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:03 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:11:03 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:11:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:11:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:11:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:11:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:11:03 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:11:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:05 --> Config Class Initialized
INFO - 2024-02-27 19:11:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:05 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:05 --> URI Class Initialized
INFO - 2024-02-27 19:11:05 --> Router Class Initialized
INFO - 2024-02-27 19:11:05 --> Output Class Initialized
INFO - 2024-02-27 19:11:05 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:05 --> Input Class Initialized
INFO - 2024-02-27 19:11:05 --> Language Class Initialized
INFO - 2024-02-27 19:11:05 --> Loader Class Initialized
INFO - 2024-02-27 19:11:05 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:05 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:05 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:05 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:05 --> Controller Class Initialized
INFO - 2024-02-27 19:11:05 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:05 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:11:05 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:11:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:11:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:11:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:11:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:11:05 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:11:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:11:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:11:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:11:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:11:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:11:05 --> Final output sent to browser
DEBUG - 2024-02-27 19:11:05 --> Total execution time: 0.0229
ERROR - 2024-02-27 19:11:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:06 --> Config Class Initialized
INFO - 2024-02-27 19:11:06 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:06 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:06 --> URI Class Initialized
INFO - 2024-02-27 19:11:06 --> Router Class Initialized
INFO - 2024-02-27 19:11:06 --> Output Class Initialized
INFO - 2024-02-27 19:11:06 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:06 --> Input Class Initialized
INFO - 2024-02-27 19:11:06 --> Language Class Initialized
INFO - 2024-02-27 19:11:06 --> Loader Class Initialized
INFO - 2024-02-27 19:11:06 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:06 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:06 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:06 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:06 --> Controller Class Initialized
INFO - 2024-02-27 19:11:06 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:06 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:11:06 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:11:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:11:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:11:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:11:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:11:06 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:11:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:11:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:11:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:11:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:11:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:11:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:11:06 --> Final output sent to browser
DEBUG - 2024-02-27 19:11:06 --> Total execution time: 0.0367
ERROR - 2024-02-27 19:11:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:07 --> Config Class Initialized
INFO - 2024-02-27 19:11:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:07 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:07 --> URI Class Initialized
INFO - 2024-02-27 19:11:07 --> Router Class Initialized
INFO - 2024-02-27 19:11:07 --> Output Class Initialized
INFO - 2024-02-27 19:11:07 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:07 --> Input Class Initialized
INFO - 2024-02-27 19:11:07 --> Language Class Initialized
INFO - 2024-02-27 19:11:07 --> Loader Class Initialized
INFO - 2024-02-27 19:11:07 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:07 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:07 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:07 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:07 --> Controller Class Initialized
INFO - 2024-02-27 19:11:07 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:07 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:11:07 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:11:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:11:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:11:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:11:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:11:07 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:11:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:15 --> Config Class Initialized
INFO - 2024-02-27 19:11:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:15 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:15 --> URI Class Initialized
INFO - 2024-02-27 19:11:15 --> Router Class Initialized
INFO - 2024-02-27 19:11:15 --> Output Class Initialized
INFO - 2024-02-27 19:11:15 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:15 --> Input Class Initialized
INFO - 2024-02-27 19:11:15 --> Language Class Initialized
INFO - 2024-02-27 19:11:15 --> Loader Class Initialized
INFO - 2024-02-27 19:11:15 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:15 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:15 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:15 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:15 --> Controller Class Initialized
INFO - 2024-02-27 19:11:15 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:15 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:11:15 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:11:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:11:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:11:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:11:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:11:15 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:11:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:11:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:11:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:11:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:11:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:11:15 --> Final output sent to browser
DEBUG - 2024-02-27 19:11:15 --> Total execution time: 0.0313
ERROR - 2024-02-27 19:11:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:19 --> Config Class Initialized
INFO - 2024-02-27 19:11:19 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:19 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:19 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:19 --> URI Class Initialized
INFO - 2024-02-27 19:11:19 --> Router Class Initialized
INFO - 2024-02-27 19:11:19 --> Output Class Initialized
INFO - 2024-02-27 19:11:19 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:19 --> Input Class Initialized
INFO - 2024-02-27 19:11:19 --> Language Class Initialized
INFO - 2024-02-27 19:11:19 --> Loader Class Initialized
INFO - 2024-02-27 19:11:19 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:19 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:19 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:19 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:20 --> Controller Class Initialized
INFO - 2024-02-27 19:11:20 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:20 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:11:20 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:11:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:11:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:11:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:11:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:11:20 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:11:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:11:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:11:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:11:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:11:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:11:20 --> Final output sent to browser
DEBUG - 2024-02-27 19:11:20 --> Total execution time: 0.0427
ERROR - 2024-02-27 19:11:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:33 --> Config Class Initialized
INFO - 2024-02-27 19:11:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:33 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:33 --> URI Class Initialized
INFO - 2024-02-27 19:11:33 --> Router Class Initialized
INFO - 2024-02-27 19:11:33 --> Output Class Initialized
INFO - 2024-02-27 19:11:33 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:33 --> Input Class Initialized
INFO - 2024-02-27 19:11:33 --> Language Class Initialized
INFO - 2024-02-27 19:11:33 --> Loader Class Initialized
INFO - 2024-02-27 19:11:33 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:33 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:33 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:33 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:33 --> Controller Class Initialized
INFO - 2024-02-27 19:11:33 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:33 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:11:33 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:11:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:11:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:11:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:11:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:11:33 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:11:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:11:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:11:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:11:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:11:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:11:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:11:33 --> Final output sent to browser
DEBUG - 2024-02-27 19:11:33 --> Total execution time: 0.0260
ERROR - 2024-02-27 19:11:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:33 --> Config Class Initialized
INFO - 2024-02-27 19:11:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:33 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:33 --> URI Class Initialized
INFO - 2024-02-27 19:11:33 --> Router Class Initialized
INFO - 2024-02-27 19:11:33 --> Output Class Initialized
INFO - 2024-02-27 19:11:33 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:33 --> Input Class Initialized
INFO - 2024-02-27 19:11:33 --> Language Class Initialized
INFO - 2024-02-27 19:11:33 --> Loader Class Initialized
INFO - 2024-02-27 19:11:33 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:33 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:33 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:33 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:33 --> Controller Class Initialized
INFO - 2024-02-27 19:11:33 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:33 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:11:33 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:11:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:11:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:11:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:11:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:11:33 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:45 --> Config Class Initialized
INFO - 2024-02-27 19:11:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:45 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:45 --> URI Class Initialized
INFO - 2024-02-27 19:11:45 --> Router Class Initialized
INFO - 2024-02-27 19:11:45 --> Output Class Initialized
INFO - 2024-02-27 19:11:45 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:45 --> Input Class Initialized
INFO - 2024-02-27 19:11:45 --> Language Class Initialized
INFO - 2024-02-27 19:11:45 --> Loader Class Initialized
INFO - 2024-02-27 19:11:45 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:45 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:45 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:45 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:45 --> Controller Class Initialized
INFO - 2024-02-27 19:11:45 --> Model "LoginModel" initialized
INFO - 2024-02-27 19:11:45 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-27 19:11:45 --> Final output sent to browser
DEBUG - 2024-02-27 19:11:45 --> Total execution time: 0.0346
ERROR - 2024-02-27 19:11:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:48 --> Config Class Initialized
INFO - 2024-02-27 19:11:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:48 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:48 --> URI Class Initialized
DEBUG - 2024-02-27 19:11:48 --> No URI present. Default controller set.
INFO - 2024-02-27 19:11:48 --> Router Class Initialized
INFO - 2024-02-27 19:11:48 --> Output Class Initialized
INFO - 2024-02-27 19:11:48 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:48 --> Input Class Initialized
INFO - 2024-02-27 19:11:48 --> Language Class Initialized
INFO - 2024-02-27 19:11:48 --> Loader Class Initialized
INFO - 2024-02-27 19:11:48 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:48 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:48 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:48 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:48 --> Controller Class Initialized
INFO - 2024-02-27 19:11:48 --> Model "LoginModel" initialized
INFO - 2024-02-27 19:11:48 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-27 19:11:48 --> Final output sent to browser
DEBUG - 2024-02-27 19:11:48 --> Total execution time: 0.0403
ERROR - 2024-02-27 19:11:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:56 --> Config Class Initialized
INFO - 2024-02-27 19:11:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:56 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:56 --> URI Class Initialized
INFO - 2024-02-27 19:11:56 --> Router Class Initialized
INFO - 2024-02-27 19:11:56 --> Output Class Initialized
INFO - 2024-02-27 19:11:56 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:56 --> Input Class Initialized
INFO - 2024-02-27 19:11:56 --> Language Class Initialized
INFO - 2024-02-27 19:11:56 --> Loader Class Initialized
INFO - 2024-02-27 19:11:56 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:56 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:56 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:56 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:56 --> Controller Class Initialized
INFO - 2024-02-27 19:11:56 --> Model "LoginModel" initialized
INFO - 2024-02-27 19:11:56 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-27 19:11:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:56 --> Config Class Initialized
INFO - 2024-02-27 19:11:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:56 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:56 --> URI Class Initialized
INFO - 2024-02-27 19:11:56 --> Router Class Initialized
INFO - 2024-02-27 19:11:56 --> Output Class Initialized
INFO - 2024-02-27 19:11:56 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:56 --> Input Class Initialized
INFO - 2024-02-27 19:11:56 --> Language Class Initialized
INFO - 2024-02-27 19:11:56 --> Loader Class Initialized
INFO - 2024-02-27 19:11:56 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:56 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:56 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:56 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:56 --> Controller Class Initialized
INFO - 2024-02-27 19:11:56 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:56 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:11:56 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:11:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:11:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:11:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:11:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:11:56 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:11:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:11:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:11:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:11:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:11:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:11:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:11:56 --> Final output sent to browser
DEBUG - 2024-02-27 19:11:56 --> Total execution time: 0.0344
ERROR - 2024-02-27 19:11:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:11:57 --> Config Class Initialized
INFO - 2024-02-27 19:11:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:11:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:11:57 --> Utf8 Class Initialized
INFO - 2024-02-27 19:11:57 --> URI Class Initialized
INFO - 2024-02-27 19:11:57 --> Router Class Initialized
INFO - 2024-02-27 19:11:57 --> Output Class Initialized
INFO - 2024-02-27 19:11:57 --> Security Class Initialized
DEBUG - 2024-02-27 19:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:11:57 --> Input Class Initialized
INFO - 2024-02-27 19:11:57 --> Language Class Initialized
INFO - 2024-02-27 19:11:57 --> Loader Class Initialized
INFO - 2024-02-27 19:11:57 --> Helper loaded: url_helper
INFO - 2024-02-27 19:11:57 --> Helper loaded: file_helper
INFO - 2024-02-27 19:11:57 --> Helper loaded: form_helper
INFO - 2024-02-27 19:11:57 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:11:57 --> Controller Class Initialized
INFO - 2024-02-27 19:11:57 --> Form Validation Class Initialized
INFO - 2024-02-27 19:11:57 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:11:57 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:11:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:11:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:11:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:11:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:11:57 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:12:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:00 --> Config Class Initialized
INFO - 2024-02-27 19:12:00 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:00 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:00 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:00 --> URI Class Initialized
INFO - 2024-02-27 19:12:00 --> Router Class Initialized
INFO - 2024-02-27 19:12:00 --> Output Class Initialized
INFO - 2024-02-27 19:12:00 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:00 --> Input Class Initialized
INFO - 2024-02-27 19:12:00 --> Language Class Initialized
INFO - 2024-02-27 19:12:00 --> Loader Class Initialized
INFO - 2024-02-27 19:12:00 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:00 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:00 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:00 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:00 --> Controller Class Initialized
INFO - 2024-02-27 19:12:00 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:00 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:00 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:00 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:00 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:00 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:00 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:12:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:12:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:12:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:12:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:12:00 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:12:00 --> Final output sent to browser
DEBUG - 2024-02-27 19:12:00 --> Total execution time: 0.0357
ERROR - 2024-02-27 19:12:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:06 --> Config Class Initialized
INFO - 2024-02-27 19:12:06 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:06 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:06 --> URI Class Initialized
INFO - 2024-02-27 19:12:06 --> Router Class Initialized
INFO - 2024-02-27 19:12:06 --> Output Class Initialized
INFO - 2024-02-27 19:12:06 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:06 --> Input Class Initialized
INFO - 2024-02-27 19:12:06 --> Language Class Initialized
INFO - 2024-02-27 19:12:06 --> Loader Class Initialized
INFO - 2024-02-27 19:12:06 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:06 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:06 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:06 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:06 --> Controller Class Initialized
INFO - 2024-02-27 19:12:06 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:06 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:06 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:06 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:06 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:06 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:06 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:12:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:12:06 --> Final output sent to browser
DEBUG - 2024-02-27 19:12:06 --> Total execution time: 0.0403
ERROR - 2024-02-27 19:12:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:08 --> Config Class Initialized
INFO - 2024-02-27 19:12:08 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:08 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:08 --> URI Class Initialized
INFO - 2024-02-27 19:12:08 --> Router Class Initialized
INFO - 2024-02-27 19:12:08 --> Output Class Initialized
INFO - 2024-02-27 19:12:08 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:08 --> Input Class Initialized
INFO - 2024-02-27 19:12:08 --> Language Class Initialized
INFO - 2024-02-27 19:12:08 --> Loader Class Initialized
INFO - 2024-02-27 19:12:08 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:08 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:08 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:08 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:08 --> Controller Class Initialized
INFO - 2024-02-27 19:12:08 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:08 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:08 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:08 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:12:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/change_password.php
INFO - 2024-02-27 19:12:08 --> Final output sent to browser
DEBUG - 2024-02-27 19:12:08 --> Total execution time: 0.0276
ERROR - 2024-02-27 19:12:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:34 --> Config Class Initialized
INFO - 2024-02-27 19:12:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:34 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:34 --> URI Class Initialized
INFO - 2024-02-27 19:12:34 --> Router Class Initialized
INFO - 2024-02-27 19:12:34 --> Output Class Initialized
INFO - 2024-02-27 19:12:34 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:34 --> Input Class Initialized
INFO - 2024-02-27 19:12:34 --> Language Class Initialized
INFO - 2024-02-27 19:12:34 --> Loader Class Initialized
INFO - 2024-02-27 19:12:34 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:34 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:34 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:34 --> Controller Class Initialized
INFO - 2024-02-27 19:12:34 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:34 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:12:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:12:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:12:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:12:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:12:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:12:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:12:34 --> Final output sent to browser
DEBUG - 2024-02-27 19:12:34 --> Total execution time: 0.0345
ERROR - 2024-02-27 19:12:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:34 --> Config Class Initialized
INFO - 2024-02-27 19:12:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:34 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:34 --> URI Class Initialized
INFO - 2024-02-27 19:12:34 --> Router Class Initialized
INFO - 2024-02-27 19:12:34 --> Output Class Initialized
INFO - 2024-02-27 19:12:34 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:34 --> Input Class Initialized
INFO - 2024-02-27 19:12:34 --> Language Class Initialized
INFO - 2024-02-27 19:12:34 --> Loader Class Initialized
INFO - 2024-02-27 19:12:34 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:34 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:34 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:34 --> Controller Class Initialized
INFO - 2024-02-27 19:12:34 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:34 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:12:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:38 --> Config Class Initialized
INFO - 2024-02-27 19:12:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:38 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:38 --> URI Class Initialized
INFO - 2024-02-27 19:12:38 --> Router Class Initialized
INFO - 2024-02-27 19:12:38 --> Output Class Initialized
INFO - 2024-02-27 19:12:38 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:38 --> Input Class Initialized
INFO - 2024-02-27 19:12:38 --> Language Class Initialized
INFO - 2024-02-27 19:12:38 --> Loader Class Initialized
INFO - 2024-02-27 19:12:38 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:39 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:39 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:39 --> Controller Class Initialized
INFO - 2024-02-27 19:12:39 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:12:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:12:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:12:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:12:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:12:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-27 19:12:39 --> Final output sent to browser
DEBUG - 2024-02-27 19:12:39 --> Total execution time: 0.0389
ERROR - 2024-02-27 19:12:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:39 --> Config Class Initialized
INFO - 2024-02-27 19:12:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:39 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:39 --> URI Class Initialized
INFO - 2024-02-27 19:12:39 --> Router Class Initialized
INFO - 2024-02-27 19:12:39 --> Output Class Initialized
INFO - 2024-02-27 19:12:39 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:39 --> Input Class Initialized
INFO - 2024-02-27 19:12:39 --> Language Class Initialized
INFO - 2024-02-27 19:12:39 --> Loader Class Initialized
INFO - 2024-02-27 19:12:39 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:39 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:39 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:39 --> Controller Class Initialized
INFO - 2024-02-27 19:12:39 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:39 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:12:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:44 --> Config Class Initialized
INFO - 2024-02-27 19:12:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:44 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:44 --> URI Class Initialized
INFO - 2024-02-27 19:12:44 --> Router Class Initialized
INFO - 2024-02-27 19:12:44 --> Output Class Initialized
INFO - 2024-02-27 19:12:44 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:44 --> Input Class Initialized
INFO - 2024-02-27 19:12:44 --> Language Class Initialized
INFO - 2024-02-27 19:12:44 --> Loader Class Initialized
INFO - 2024-02-27 19:12:44 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:44 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:44 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:44 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:44 --> Controller Class Initialized
INFO - 2024-02-27 19:12:44 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:44 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:44 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:44 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:12:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:12:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:12:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:12:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:12:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-27 19:12:44 --> Final output sent to browser
DEBUG - 2024-02-27 19:12:44 --> Total execution time: 0.0470
ERROR - 2024-02-27 19:12:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:44 --> Config Class Initialized
INFO - 2024-02-27 19:12:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:44 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:44 --> URI Class Initialized
INFO - 2024-02-27 19:12:44 --> Router Class Initialized
INFO - 2024-02-27 19:12:44 --> Output Class Initialized
INFO - 2024-02-27 19:12:44 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:44 --> Input Class Initialized
INFO - 2024-02-27 19:12:44 --> Language Class Initialized
INFO - 2024-02-27 19:12:44 --> Loader Class Initialized
INFO - 2024-02-27 19:12:44 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:44 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:44 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:44 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:44 --> Controller Class Initialized
INFO - 2024-02-27 19:12:44 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:44 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:44 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:44 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:12:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:47 --> Config Class Initialized
INFO - 2024-02-27 19:12:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:47 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:47 --> URI Class Initialized
INFO - 2024-02-27 19:12:47 --> Router Class Initialized
INFO - 2024-02-27 19:12:47 --> Output Class Initialized
INFO - 2024-02-27 19:12:47 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:47 --> Input Class Initialized
INFO - 2024-02-27 19:12:47 --> Language Class Initialized
INFO - 2024-02-27 19:12:47 --> Loader Class Initialized
INFO - 2024-02-27 19:12:47 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:47 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:47 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:47 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:47 --> Controller Class Initialized
INFO - 2024-02-27 19:12:47 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:47 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:47 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:47 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:12:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:51 --> Config Class Initialized
INFO - 2024-02-27 19:12:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:51 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:51 --> URI Class Initialized
INFO - 2024-02-27 19:12:51 --> Router Class Initialized
INFO - 2024-02-27 19:12:51 --> Output Class Initialized
INFO - 2024-02-27 19:12:51 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:51 --> Input Class Initialized
INFO - 2024-02-27 19:12:51 --> Language Class Initialized
INFO - 2024-02-27 19:12:51 --> Loader Class Initialized
INFO - 2024-02-27 19:12:51 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:51 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:51 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:51 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:51 --> Controller Class Initialized
INFO - 2024-02-27 19:12:51 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:51 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:51 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:51 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:12:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:12:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:12:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:12:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:12:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-02-27 19:12:51 --> Final output sent to browser
DEBUG - 2024-02-27 19:12:51 --> Total execution time: 0.0429
ERROR - 2024-02-27 19:12:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:51 --> Config Class Initialized
INFO - 2024-02-27 19:12:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:51 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:51 --> URI Class Initialized
INFO - 2024-02-27 19:12:51 --> Router Class Initialized
INFO - 2024-02-27 19:12:51 --> Output Class Initialized
INFO - 2024-02-27 19:12:51 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:51 --> Input Class Initialized
INFO - 2024-02-27 19:12:51 --> Language Class Initialized
INFO - 2024-02-27 19:12:51 --> Loader Class Initialized
INFO - 2024-02-27 19:12:51 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:51 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:51 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:51 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:51 --> Controller Class Initialized
INFO - 2024-02-27 19:12:51 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:51 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:51 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:51 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:12:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:53 --> Config Class Initialized
INFO - 2024-02-27 19:12:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:53 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:53 --> URI Class Initialized
INFO - 2024-02-27 19:12:53 --> Router Class Initialized
INFO - 2024-02-27 19:12:53 --> Output Class Initialized
INFO - 2024-02-27 19:12:54 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:54 --> Input Class Initialized
INFO - 2024-02-27 19:12:54 --> Language Class Initialized
INFO - 2024-02-27 19:12:54 --> Loader Class Initialized
INFO - 2024-02-27 19:12:54 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:54 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:54 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:54 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:54 --> Controller Class Initialized
INFO - 2024-02-27 19:12:54 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:54 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:54 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:54 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:12:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:12:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:12:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:12:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:12:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/user_profile.php
INFO - 2024-02-27 19:12:54 --> Final output sent to browser
DEBUG - 2024-02-27 19:12:54 --> Total execution time: 0.0385
ERROR - 2024-02-27 19:12:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:59 --> Config Class Initialized
INFO - 2024-02-27 19:12:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:59 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:59 --> URI Class Initialized
INFO - 2024-02-27 19:12:59 --> Router Class Initialized
INFO - 2024-02-27 19:12:59 --> Output Class Initialized
INFO - 2024-02-27 19:12:59 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:59 --> Input Class Initialized
INFO - 2024-02-27 19:12:59 --> Language Class Initialized
INFO - 2024-02-27 19:12:59 --> Loader Class Initialized
INFO - 2024-02-27 19:12:59 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:59 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:59 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:59 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:59 --> Controller Class Initialized
INFO - 2024-02-27 19:12:59 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:59 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:59 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:59 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:12:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:12:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:12:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:12:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:12:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:12:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:12:59 --> Final output sent to browser
DEBUG - 2024-02-27 19:12:59 --> Total execution time: 0.0364
ERROR - 2024-02-27 19:12:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:12:59 --> Config Class Initialized
INFO - 2024-02-27 19:12:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:12:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:12:59 --> Utf8 Class Initialized
INFO - 2024-02-27 19:12:59 --> URI Class Initialized
INFO - 2024-02-27 19:12:59 --> Router Class Initialized
INFO - 2024-02-27 19:12:59 --> Output Class Initialized
INFO - 2024-02-27 19:12:59 --> Security Class Initialized
DEBUG - 2024-02-27 19:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:12:59 --> Input Class Initialized
INFO - 2024-02-27 19:12:59 --> Language Class Initialized
INFO - 2024-02-27 19:12:59 --> Loader Class Initialized
INFO - 2024-02-27 19:12:59 --> Helper loaded: url_helper
INFO - 2024-02-27 19:12:59 --> Helper loaded: file_helper
INFO - 2024-02-27 19:12:59 --> Helper loaded: form_helper
INFO - 2024-02-27 19:12:59 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:12:59 --> Controller Class Initialized
INFO - 2024-02-27 19:12:59 --> Form Validation Class Initialized
INFO - 2024-02-27 19:12:59 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:12:59 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:12:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:12:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:12:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:12:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:12:59 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:13:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:13:51 --> Config Class Initialized
INFO - 2024-02-27 19:13:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:13:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:13:51 --> Utf8 Class Initialized
INFO - 2024-02-27 19:13:51 --> URI Class Initialized
INFO - 2024-02-27 19:13:51 --> Router Class Initialized
INFO - 2024-02-27 19:13:51 --> Output Class Initialized
INFO - 2024-02-27 19:13:51 --> Security Class Initialized
DEBUG - 2024-02-27 19:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:13:51 --> Input Class Initialized
INFO - 2024-02-27 19:13:51 --> Language Class Initialized
INFO - 2024-02-27 19:13:51 --> Loader Class Initialized
INFO - 2024-02-27 19:13:51 --> Helper loaded: url_helper
INFO - 2024-02-27 19:13:51 --> Helper loaded: file_helper
INFO - 2024-02-27 19:13:51 --> Helper loaded: form_helper
INFO - 2024-02-27 19:13:51 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:13:51 --> Controller Class Initialized
INFO - 2024-02-27 19:13:51 --> Form Validation Class Initialized
INFO - 2024-02-27 19:13:51 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:13:51 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:13:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:13:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:13:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:13:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:13:51 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:13:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:13:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:13:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:13:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:13:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:13:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:13:51 --> Final output sent to browser
DEBUG - 2024-02-27 19:13:51 --> Total execution time: 0.0363
ERROR - 2024-02-27 19:13:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:13:51 --> Config Class Initialized
INFO - 2024-02-27 19:13:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:13:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:13:51 --> Utf8 Class Initialized
INFO - 2024-02-27 19:13:51 --> URI Class Initialized
INFO - 2024-02-27 19:13:51 --> Router Class Initialized
INFO - 2024-02-27 19:13:51 --> Output Class Initialized
INFO - 2024-02-27 19:13:51 --> Security Class Initialized
DEBUG - 2024-02-27 19:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:13:51 --> Input Class Initialized
INFO - 2024-02-27 19:13:51 --> Language Class Initialized
INFO - 2024-02-27 19:13:51 --> Loader Class Initialized
INFO - 2024-02-27 19:13:51 --> Helper loaded: url_helper
INFO - 2024-02-27 19:13:51 --> Helper loaded: file_helper
INFO - 2024-02-27 19:13:51 --> Helper loaded: form_helper
INFO - 2024-02-27 19:13:51 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:13:51 --> Controller Class Initialized
INFO - 2024-02-27 19:13:51 --> Form Validation Class Initialized
INFO - 2024-02-27 19:13:51 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:13:51 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:13:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:13:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:13:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:13:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:13:51 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:23:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:23:43 --> Config Class Initialized
INFO - 2024-02-27 19:23:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:23:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:23:43 --> Utf8 Class Initialized
INFO - 2024-02-27 19:23:43 --> URI Class Initialized
INFO - 2024-02-27 19:23:44 --> Router Class Initialized
INFO - 2024-02-27 19:23:44 --> Output Class Initialized
INFO - 2024-02-27 19:23:44 --> Security Class Initialized
DEBUG - 2024-02-27 19:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:23:44 --> Input Class Initialized
INFO - 2024-02-27 19:23:44 --> Language Class Initialized
INFO - 2024-02-27 19:23:44 --> Loader Class Initialized
INFO - 2024-02-27 19:23:44 --> Helper loaded: url_helper
INFO - 2024-02-27 19:23:44 --> Helper loaded: file_helper
INFO - 2024-02-27 19:23:44 --> Helper loaded: form_helper
INFO - 2024-02-27 19:23:44 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:23:44 --> Controller Class Initialized
INFO - 2024-02-27 19:23:44 --> Form Validation Class Initialized
INFO - 2024-02-27 19:23:44 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:23:44 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:23:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:23:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:23:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:23:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:23:44 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:23:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:23:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:23:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-27 19:23:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:23:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:23:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:23:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:23:44 --> Final output sent to browser
DEBUG - 2024-02-27 19:23:44 --> Total execution time: 0.0365
ERROR - 2024-02-27 19:23:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:23:44 --> Config Class Initialized
INFO - 2024-02-27 19:23:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:23:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:23:44 --> Utf8 Class Initialized
INFO - 2024-02-27 19:23:44 --> URI Class Initialized
INFO - 2024-02-27 19:23:44 --> Router Class Initialized
INFO - 2024-02-27 19:23:44 --> Output Class Initialized
INFO - 2024-02-27 19:23:44 --> Security Class Initialized
DEBUG - 2024-02-27 19:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:23:44 --> Input Class Initialized
INFO - 2024-02-27 19:23:44 --> Language Class Initialized
INFO - 2024-02-27 19:23:44 --> Loader Class Initialized
INFO - 2024-02-27 19:23:44 --> Helper loaded: url_helper
INFO - 2024-02-27 19:23:44 --> Helper loaded: file_helper
INFO - 2024-02-27 19:23:44 --> Helper loaded: form_helper
INFO - 2024-02-27 19:23:44 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:23:44 --> Controller Class Initialized
INFO - 2024-02-27 19:23:44 --> Form Validation Class Initialized
INFO - 2024-02-27 19:23:44 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:23:44 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:23:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:23:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:23:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:23:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:23:44 --> Model "OrderModel" initialized
ERROR - 2024-02-27 19:23:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:23:53 --> Config Class Initialized
INFO - 2024-02-27 19:23:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:23:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:23:53 --> Utf8 Class Initialized
INFO - 2024-02-27 19:23:53 --> URI Class Initialized
INFO - 2024-02-27 19:23:53 --> Router Class Initialized
INFO - 2024-02-27 19:23:53 --> Output Class Initialized
INFO - 2024-02-27 19:23:53 --> Security Class Initialized
DEBUG - 2024-02-27 19:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:23:53 --> Input Class Initialized
INFO - 2024-02-27 19:23:53 --> Language Class Initialized
INFO - 2024-02-27 19:23:53 --> Loader Class Initialized
INFO - 2024-02-27 19:23:53 --> Helper loaded: url_helper
INFO - 2024-02-27 19:23:53 --> Helper loaded: file_helper
INFO - 2024-02-27 19:23:53 --> Helper loaded: form_helper
INFO - 2024-02-27 19:23:53 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:23:53 --> Controller Class Initialized
INFO - 2024-02-27 19:23:53 --> Form Validation Class Initialized
INFO - 2024-02-27 19:23:53 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:23:53 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:23:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:23:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:23:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:23:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:23:53 --> Model "OrderModel" initialized
INFO - 2024-02-27 19:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 19:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 19:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 19:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 19:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 19:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 19:23:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 19:23:53 --> Final output sent to browser
DEBUG - 2024-02-27 19:23:53 --> Total execution time: 0.0362
ERROR - 2024-02-27 19:23:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 19:23:53 --> Config Class Initialized
INFO - 2024-02-27 19:23:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:23:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:23:53 --> Utf8 Class Initialized
INFO - 2024-02-27 19:23:53 --> URI Class Initialized
INFO - 2024-02-27 19:23:53 --> Router Class Initialized
INFO - 2024-02-27 19:23:53 --> Output Class Initialized
INFO - 2024-02-27 19:23:53 --> Security Class Initialized
DEBUG - 2024-02-27 19:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:23:53 --> Input Class Initialized
INFO - 2024-02-27 19:23:53 --> Language Class Initialized
INFO - 2024-02-27 19:23:53 --> Loader Class Initialized
INFO - 2024-02-27 19:23:53 --> Helper loaded: url_helper
INFO - 2024-02-27 19:23:53 --> Helper loaded: file_helper
INFO - 2024-02-27 19:23:53 --> Helper loaded: form_helper
INFO - 2024-02-27 19:23:53 --> Database Driver Class Initialized
DEBUG - 2024-02-27 19:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 19:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:23:53 --> Controller Class Initialized
INFO - 2024-02-27 19:23:53 --> Form Validation Class Initialized
INFO - 2024-02-27 19:23:53 --> Model "MasterModel" initialized
INFO - 2024-02-27 19:23:53 --> Model "DashboardModel" initialized
INFO - 2024-02-27 19:23:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 19:23:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 19:23:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 19:23:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 19:23:53 --> Model "OrderModel" initialized
ERROR - 2024-02-27 22:44:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:44:21 --> Config Class Initialized
INFO - 2024-02-27 22:44:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:44:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:44:21 --> Utf8 Class Initialized
INFO - 2024-02-27 22:44:21 --> URI Class Initialized
INFO - 2024-02-27 22:44:21 --> Router Class Initialized
INFO - 2024-02-27 22:44:21 --> Output Class Initialized
INFO - 2024-02-27 22:44:21 --> Security Class Initialized
DEBUG - 2024-02-27 22:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:44:21 --> Input Class Initialized
INFO - 2024-02-27 22:44:21 --> Language Class Initialized
INFO - 2024-02-27 22:44:21 --> Loader Class Initialized
INFO - 2024-02-27 22:44:21 --> Helper loaded: url_helper
INFO - 2024-02-27 22:44:21 --> Helper loaded: file_helper
INFO - 2024-02-27 22:44:21 --> Helper loaded: form_helper
INFO - 2024-02-27 22:44:21 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:44:21 --> Controller Class Initialized
INFO - 2024-02-27 22:44:21 --> Form Validation Class Initialized
INFO - 2024-02-27 22:44:21 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:44:21 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:44:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:44:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:44:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:44:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:44:21 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:44:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 22:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-27 22:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 22:44:21 --> Final output sent to browser
DEBUG - 2024-02-27 22:44:21 --> Total execution time: 0.0328
ERROR - 2024-02-27 22:44:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:44:22 --> Config Class Initialized
INFO - 2024-02-27 22:44:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:44:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:44:22 --> Utf8 Class Initialized
INFO - 2024-02-27 22:44:22 --> URI Class Initialized
INFO - 2024-02-27 22:44:22 --> Router Class Initialized
INFO - 2024-02-27 22:44:22 --> Output Class Initialized
INFO - 2024-02-27 22:44:22 --> Security Class Initialized
DEBUG - 2024-02-27 22:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:44:22 --> Input Class Initialized
INFO - 2024-02-27 22:44:22 --> Language Class Initialized
INFO - 2024-02-27 22:44:22 --> Loader Class Initialized
INFO - 2024-02-27 22:44:22 --> Helper loaded: url_helper
INFO - 2024-02-27 22:44:22 --> Helper loaded: file_helper
INFO - 2024-02-27 22:44:22 --> Helper loaded: form_helper
INFO - 2024-02-27 22:44:22 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:44:22 --> Controller Class Initialized
INFO - 2024-02-27 22:44:22 --> Form Validation Class Initialized
INFO - 2024-02-27 22:44:22 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:44:22 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:44:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:44:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:44:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:44:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:44:22 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:44:22 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:44:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:44:27 --> Config Class Initialized
INFO - 2024-02-27 22:44:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:44:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:44:27 --> Utf8 Class Initialized
INFO - 2024-02-27 22:44:27 --> URI Class Initialized
INFO - 2024-02-27 22:44:27 --> Router Class Initialized
INFO - 2024-02-27 22:44:27 --> Output Class Initialized
INFO - 2024-02-27 22:44:27 --> Security Class Initialized
DEBUG - 2024-02-27 22:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:44:27 --> Input Class Initialized
INFO - 2024-02-27 22:44:27 --> Language Class Initialized
INFO - 2024-02-27 22:44:27 --> Loader Class Initialized
INFO - 2024-02-27 22:44:27 --> Helper loaded: url_helper
INFO - 2024-02-27 22:44:27 --> Helper loaded: file_helper
INFO - 2024-02-27 22:44:27 --> Helper loaded: form_helper
INFO - 2024-02-27 22:44:27 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:44:27 --> Controller Class Initialized
INFO - 2024-02-27 22:44:27 --> Form Validation Class Initialized
INFO - 2024-02-27 22:44:27 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-27 22:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/index.php
INFO - 2024-02-27 22:44:27 --> Final output sent to browser
DEBUG - 2024-02-27 22:44:27 --> Total execution time: 0.0325
ERROR - 2024-02-27 22:44:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:44:27 --> Config Class Initialized
INFO - 2024-02-27 22:44:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:44:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:44:27 --> Utf8 Class Initialized
INFO - 2024-02-27 22:44:27 --> URI Class Initialized
INFO - 2024-02-27 22:44:27 --> Router Class Initialized
INFO - 2024-02-27 22:44:27 --> Output Class Initialized
INFO - 2024-02-27 22:44:27 --> Security Class Initialized
DEBUG - 2024-02-27 22:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:44:27 --> Input Class Initialized
INFO - 2024-02-27 22:44:27 --> Language Class Initialized
INFO - 2024-02-27 22:44:27 --> Loader Class Initialized
INFO - 2024-02-27 22:44:27 --> Helper loaded: url_helper
INFO - 2024-02-27 22:44:27 --> Helper loaded: file_helper
INFO - 2024-02-27 22:44:27 --> Helper loaded: form_helper
INFO - 2024-02-27 22:44:27 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:44:27 --> Controller Class Initialized
INFO - 2024-02-27 22:44:27 --> Form Validation Class Initialized
INFO - 2024-02-27 22:44:27 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:44:27 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:44:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:44:33 --> Config Class Initialized
INFO - 2024-02-27 22:44:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:44:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:44:33 --> Utf8 Class Initialized
INFO - 2024-02-27 22:44:33 --> URI Class Initialized
INFO - 2024-02-27 22:44:33 --> Router Class Initialized
INFO - 2024-02-27 22:44:33 --> Output Class Initialized
INFO - 2024-02-27 22:44:33 --> Security Class Initialized
DEBUG - 2024-02-27 22:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:44:33 --> Input Class Initialized
INFO - 2024-02-27 22:44:33 --> Language Class Initialized
INFO - 2024-02-27 22:44:33 --> Loader Class Initialized
INFO - 2024-02-27 22:44:33 --> Helper loaded: url_helper
INFO - 2024-02-27 22:44:33 --> Helper loaded: file_helper
INFO - 2024-02-27 22:44:33 --> Helper loaded: form_helper
INFO - 2024-02-27 22:44:33 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:44:33 --> Controller Class Initialized
INFO - 2024-02-27 22:44:33 --> Form Validation Class Initialized
INFO - 2024-02-27 22:44:33 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:44:33 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:44:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:44:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:44:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:44:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:44:33 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:44:33 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:44:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:44:54 --> Config Class Initialized
INFO - 2024-02-27 22:44:54 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:44:54 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:44:54 --> Utf8 Class Initialized
INFO - 2024-02-27 22:44:54 --> URI Class Initialized
INFO - 2024-02-27 22:44:54 --> Router Class Initialized
INFO - 2024-02-27 22:44:54 --> Output Class Initialized
INFO - 2024-02-27 22:44:54 --> Security Class Initialized
DEBUG - 2024-02-27 22:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:44:54 --> Input Class Initialized
INFO - 2024-02-27 22:44:54 --> Language Class Initialized
INFO - 2024-02-27 22:44:54 --> Loader Class Initialized
INFO - 2024-02-27 22:44:54 --> Helper loaded: url_helper
INFO - 2024-02-27 22:44:54 --> Helper loaded: file_helper
INFO - 2024-02-27 22:44:54 --> Helper loaded: form_helper
INFO - 2024-02-27 22:44:54 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:44:54 --> Controller Class Initialized
INFO - 2024-02-27 22:44:54 --> Form Validation Class Initialized
INFO - 2024-02-27 22:44:54 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:44:54 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:44:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:44:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:44:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:44:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:44:54 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:44:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:44:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:44:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-27 22:44:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:44:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:44:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:44:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/index.php
INFO - 2024-02-27 22:44:54 --> Final output sent to browser
DEBUG - 2024-02-27 22:44:54 --> Total execution time: 0.0307
ERROR - 2024-02-27 22:44:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:44:55 --> Config Class Initialized
INFO - 2024-02-27 22:44:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:44:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:44:55 --> Utf8 Class Initialized
INFO - 2024-02-27 22:44:55 --> URI Class Initialized
INFO - 2024-02-27 22:44:55 --> Router Class Initialized
INFO - 2024-02-27 22:44:55 --> Output Class Initialized
INFO - 2024-02-27 22:44:55 --> Security Class Initialized
DEBUG - 2024-02-27 22:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:44:55 --> Input Class Initialized
INFO - 2024-02-27 22:44:55 --> Language Class Initialized
INFO - 2024-02-27 22:44:55 --> Loader Class Initialized
INFO - 2024-02-27 22:44:55 --> Helper loaded: url_helper
INFO - 2024-02-27 22:44:55 --> Helper loaded: file_helper
INFO - 2024-02-27 22:44:55 --> Helper loaded: form_helper
INFO - 2024-02-27 22:44:55 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:44:55 --> Controller Class Initialized
INFO - 2024-02-27 22:44:55 --> Form Validation Class Initialized
INFO - 2024-02-27 22:44:55 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:44:55 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:44:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:44:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:44:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:44:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:44:55 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:44:55 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:45:19 --> Config Class Initialized
INFO - 2024-02-27 22:45:19 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:45:19 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:45:19 --> Utf8 Class Initialized
INFO - 2024-02-27 22:45:19 --> URI Class Initialized
INFO - 2024-02-27 22:45:19 --> Router Class Initialized
INFO - 2024-02-27 22:45:19 --> Output Class Initialized
INFO - 2024-02-27 22:45:19 --> Security Class Initialized
DEBUG - 2024-02-27 22:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:45:19 --> Input Class Initialized
INFO - 2024-02-27 22:45:19 --> Language Class Initialized
INFO - 2024-02-27 22:45:19 --> Loader Class Initialized
INFO - 2024-02-27 22:45:19 --> Helper loaded: url_helper
INFO - 2024-02-27 22:45:19 --> Helper loaded: file_helper
INFO - 2024-02-27 22:45:19 --> Helper loaded: form_helper
INFO - 2024-02-27 22:45:19 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:45:19 --> Controller Class Initialized
INFO - 2024-02-27 22:45:19 --> Form Validation Class Initialized
INFO - 2024-02-27 22:45:19 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:45:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:45:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-27 22:45:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:45:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:45:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:45:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/index.php
INFO - 2024-02-27 22:45:19 --> Final output sent to browser
DEBUG - 2024-02-27 22:45:19 --> Total execution time: 0.0407
ERROR - 2024-02-27 22:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:45:19 --> Config Class Initialized
INFO - 2024-02-27 22:45:19 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:45:19 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:45:19 --> Utf8 Class Initialized
INFO - 2024-02-27 22:45:19 --> URI Class Initialized
INFO - 2024-02-27 22:45:19 --> Router Class Initialized
INFO - 2024-02-27 22:45:19 --> Output Class Initialized
INFO - 2024-02-27 22:45:19 --> Security Class Initialized
DEBUG - 2024-02-27 22:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:45:19 --> Input Class Initialized
INFO - 2024-02-27 22:45:19 --> Language Class Initialized
INFO - 2024-02-27 22:45:19 --> Loader Class Initialized
INFO - 2024-02-27 22:45:19 --> Helper loaded: url_helper
INFO - 2024-02-27 22:45:19 --> Helper loaded: file_helper
INFO - 2024-02-27 22:45:19 --> Helper loaded: form_helper
INFO - 2024-02-27 22:45:19 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:45:19 --> Controller Class Initialized
INFO - 2024-02-27 22:45:19 --> Form Validation Class Initialized
INFO - 2024-02-27 22:45:19 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:45:19 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:45:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:45:33 --> Config Class Initialized
INFO - 2024-02-27 22:45:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:45:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:45:33 --> Utf8 Class Initialized
INFO - 2024-02-27 22:45:33 --> URI Class Initialized
INFO - 2024-02-27 22:45:33 --> Router Class Initialized
INFO - 2024-02-27 22:45:33 --> Output Class Initialized
INFO - 2024-02-27 22:45:33 --> Security Class Initialized
DEBUG - 2024-02-27 22:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:45:33 --> Input Class Initialized
INFO - 2024-02-27 22:45:33 --> Language Class Initialized
INFO - 2024-02-27 22:45:33 --> Loader Class Initialized
INFO - 2024-02-27 22:45:33 --> Helper loaded: url_helper
INFO - 2024-02-27 22:45:33 --> Helper loaded: file_helper
INFO - 2024-02-27 22:45:33 --> Helper loaded: form_helper
INFO - 2024-02-27 22:45:33 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:45:33 --> Controller Class Initialized
INFO - 2024-02-27 22:45:33 --> Form Validation Class Initialized
INFO - 2024-02-27 22:45:33 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:45:33 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:45:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:45:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:45:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:45:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:45:33 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:45:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-27 22:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:45:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/index.php
INFO - 2024-02-27 22:45:33 --> Final output sent to browser
DEBUG - 2024-02-27 22:45:33 --> Total execution time: 0.0345
ERROR - 2024-02-27 22:45:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:45:36 --> Config Class Initialized
INFO - 2024-02-27 22:45:36 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:45:36 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:45:36 --> Utf8 Class Initialized
INFO - 2024-02-27 22:45:36 --> URI Class Initialized
INFO - 2024-02-27 22:45:36 --> Router Class Initialized
INFO - 2024-02-27 22:45:36 --> Output Class Initialized
INFO - 2024-02-27 22:45:36 --> Security Class Initialized
DEBUG - 2024-02-27 22:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:45:36 --> Input Class Initialized
INFO - 2024-02-27 22:45:36 --> Language Class Initialized
INFO - 2024-02-27 22:45:36 --> Loader Class Initialized
INFO - 2024-02-27 22:45:36 --> Helper loaded: url_helper
INFO - 2024-02-27 22:45:36 --> Helper loaded: file_helper
INFO - 2024-02-27 22:45:36 --> Helper loaded: form_helper
INFO - 2024-02-27 22:45:36 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:45:36 --> Controller Class Initialized
INFO - 2024-02-27 22:45:36 --> Form Validation Class Initialized
INFO - 2024-02-27 22:45:36 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:45:36 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:45:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:45:36 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:45:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:45:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:45:36 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:45:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:45:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/form.php
INFO - 2024-02-27 22:45:36 --> Final output sent to browser
DEBUG - 2024-02-27 22:45:36 --> Total execution time: 0.0397
ERROR - 2024-02-27 22:45:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:45:51 --> Config Class Initialized
INFO - 2024-02-27 22:45:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:45:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:45:51 --> Utf8 Class Initialized
INFO - 2024-02-27 22:45:51 --> URI Class Initialized
INFO - 2024-02-27 22:45:51 --> Router Class Initialized
INFO - 2024-02-27 22:45:51 --> Output Class Initialized
INFO - 2024-02-27 22:45:51 --> Security Class Initialized
DEBUG - 2024-02-27 22:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:45:51 --> Input Class Initialized
INFO - 2024-02-27 22:45:51 --> Language Class Initialized
INFO - 2024-02-27 22:45:51 --> Loader Class Initialized
INFO - 2024-02-27 22:45:51 --> Helper loaded: url_helper
INFO - 2024-02-27 22:45:51 --> Helper loaded: file_helper
INFO - 2024-02-27 22:45:51 --> Helper loaded: form_helper
INFO - 2024-02-27 22:45:51 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:45:51 --> Controller Class Initialized
INFO - 2024-02-27 22:45:51 --> Form Validation Class Initialized
INFO - 2024-02-27 22:45:51 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:45:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:45:51 --> Config Class Initialized
INFO - 2024-02-27 22:45:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:45:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:45:51 --> Utf8 Class Initialized
INFO - 2024-02-27 22:45:51 --> URI Class Initialized
INFO - 2024-02-27 22:45:51 --> Router Class Initialized
INFO - 2024-02-27 22:45:51 --> Output Class Initialized
INFO - 2024-02-27 22:45:51 --> Security Class Initialized
DEBUG - 2024-02-27 22:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:45:51 --> Input Class Initialized
INFO - 2024-02-27 22:45:51 --> Language Class Initialized
INFO - 2024-02-27 22:45:51 --> Loader Class Initialized
INFO - 2024-02-27 22:45:51 --> Helper loaded: url_helper
INFO - 2024-02-27 22:45:51 --> Helper loaded: file_helper
INFO - 2024-02-27 22:45:51 --> Helper loaded: form_helper
INFO - 2024-02-27 22:45:51 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:45:51 --> Controller Class Initialized
INFO - 2024-02-27 22:45:51 --> Form Validation Class Initialized
INFO - 2024-02-27 22:45:51 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:45:51 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:46:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:46:10 --> Config Class Initialized
INFO - 2024-02-27 22:46:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:46:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:46:10 --> Utf8 Class Initialized
INFO - 2024-02-27 22:46:10 --> URI Class Initialized
INFO - 2024-02-27 22:46:10 --> Router Class Initialized
INFO - 2024-02-27 22:46:10 --> Output Class Initialized
INFO - 2024-02-27 22:46:10 --> Security Class Initialized
DEBUG - 2024-02-27 22:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:46:10 --> Input Class Initialized
INFO - 2024-02-27 22:46:10 --> Language Class Initialized
INFO - 2024-02-27 22:46:10 --> Loader Class Initialized
INFO - 2024-02-27 22:46:10 --> Helper loaded: url_helper
INFO - 2024-02-27 22:46:10 --> Helper loaded: file_helper
INFO - 2024-02-27 22:46:10 --> Helper loaded: form_helper
INFO - 2024-02-27 22:46:10 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:46:10 --> Controller Class Initialized
INFO - 2024-02-27 22:46:10 --> Form Validation Class Initialized
INFO - 2024-02-27 22:46:10 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:46:10 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:46:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:46:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:46:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:46:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:46:10 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:46:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:46:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/form.php
INFO - 2024-02-27 22:46:10 --> Final output sent to browser
DEBUG - 2024-02-27 22:46:10 --> Total execution time: 0.0429
ERROR - 2024-02-27 22:46:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:46:20 --> Config Class Initialized
INFO - 2024-02-27 22:46:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:46:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:46:20 --> Utf8 Class Initialized
INFO - 2024-02-27 22:46:20 --> URI Class Initialized
INFO - 2024-02-27 22:46:20 --> Router Class Initialized
INFO - 2024-02-27 22:46:20 --> Output Class Initialized
INFO - 2024-02-27 22:46:20 --> Security Class Initialized
DEBUG - 2024-02-27 22:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:46:20 --> Input Class Initialized
INFO - 2024-02-27 22:46:20 --> Language Class Initialized
INFO - 2024-02-27 22:46:20 --> Loader Class Initialized
INFO - 2024-02-27 22:46:20 --> Helper loaded: url_helper
INFO - 2024-02-27 22:46:20 --> Helper loaded: file_helper
INFO - 2024-02-27 22:46:20 --> Helper loaded: form_helper
INFO - 2024-02-27 22:46:20 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:46:20 --> Controller Class Initialized
INFO - 2024-02-27 22:46:20 --> Form Validation Class Initialized
INFO - 2024-02-27 22:46:20 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:46:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:46:20 --> Config Class Initialized
INFO - 2024-02-27 22:46:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:46:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:46:20 --> Utf8 Class Initialized
INFO - 2024-02-27 22:46:20 --> URI Class Initialized
INFO - 2024-02-27 22:46:20 --> Router Class Initialized
INFO - 2024-02-27 22:46:20 --> Output Class Initialized
INFO - 2024-02-27 22:46:20 --> Security Class Initialized
DEBUG - 2024-02-27 22:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:46:20 --> Input Class Initialized
INFO - 2024-02-27 22:46:20 --> Language Class Initialized
INFO - 2024-02-27 22:46:20 --> Loader Class Initialized
INFO - 2024-02-27 22:46:20 --> Helper loaded: url_helper
INFO - 2024-02-27 22:46:20 --> Helper loaded: file_helper
INFO - 2024-02-27 22:46:20 --> Helper loaded: form_helper
INFO - 2024-02-27 22:46:20 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:46:20 --> Controller Class Initialized
INFO - 2024-02-27 22:46:20 --> Form Validation Class Initialized
INFO - 2024-02-27 22:46:20 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:46:20 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:46:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:46:25 --> Config Class Initialized
INFO - 2024-02-27 22:46:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:46:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:46:25 --> Utf8 Class Initialized
INFO - 2024-02-27 22:46:25 --> URI Class Initialized
INFO - 2024-02-27 22:46:25 --> Router Class Initialized
INFO - 2024-02-27 22:46:25 --> Output Class Initialized
INFO - 2024-02-27 22:46:25 --> Security Class Initialized
DEBUG - 2024-02-27 22:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:46:25 --> Input Class Initialized
INFO - 2024-02-27 22:46:25 --> Language Class Initialized
INFO - 2024-02-27 22:46:25 --> Loader Class Initialized
INFO - 2024-02-27 22:46:25 --> Helper loaded: url_helper
INFO - 2024-02-27 22:46:25 --> Helper loaded: file_helper
INFO - 2024-02-27 22:46:25 --> Helper loaded: form_helper
INFO - 2024-02-27 22:46:25 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:46:25 --> Controller Class Initialized
INFO - 2024-02-27 22:46:25 --> Form Validation Class Initialized
INFO - 2024-02-27 22:46:25 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:46:25 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:46:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:46:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:46:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:46:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:46:25 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:46:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:46:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/form.php
INFO - 2024-02-27 22:46:25 --> Final output sent to browser
DEBUG - 2024-02-27 22:46:25 --> Total execution time: 0.0380
ERROR - 2024-02-27 22:46:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:46:30 --> Config Class Initialized
INFO - 2024-02-27 22:46:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:46:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:46:30 --> Utf8 Class Initialized
INFO - 2024-02-27 22:46:30 --> URI Class Initialized
INFO - 2024-02-27 22:46:30 --> Router Class Initialized
INFO - 2024-02-27 22:46:30 --> Output Class Initialized
INFO - 2024-02-27 22:46:30 --> Security Class Initialized
DEBUG - 2024-02-27 22:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:46:30 --> Input Class Initialized
INFO - 2024-02-27 22:46:30 --> Language Class Initialized
INFO - 2024-02-27 22:46:30 --> Loader Class Initialized
INFO - 2024-02-27 22:46:30 --> Helper loaded: url_helper
INFO - 2024-02-27 22:46:30 --> Helper loaded: file_helper
INFO - 2024-02-27 22:46:30 --> Helper loaded: form_helper
INFO - 2024-02-27 22:46:30 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:46:30 --> Controller Class Initialized
INFO - 2024-02-27 22:46:30 --> Form Validation Class Initialized
INFO - 2024-02-27 22:46:30 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:46:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:46:30 --> Config Class Initialized
INFO - 2024-02-27 22:46:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:46:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:46:30 --> Utf8 Class Initialized
INFO - 2024-02-27 22:46:30 --> URI Class Initialized
INFO - 2024-02-27 22:46:30 --> Router Class Initialized
INFO - 2024-02-27 22:46:30 --> Output Class Initialized
INFO - 2024-02-27 22:46:30 --> Security Class Initialized
DEBUG - 2024-02-27 22:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:46:30 --> Input Class Initialized
INFO - 2024-02-27 22:46:30 --> Language Class Initialized
INFO - 2024-02-27 22:46:30 --> Loader Class Initialized
INFO - 2024-02-27 22:46:30 --> Helper loaded: url_helper
INFO - 2024-02-27 22:46:30 --> Helper loaded: file_helper
INFO - 2024-02-27 22:46:30 --> Helper loaded: form_helper
INFO - 2024-02-27 22:46:30 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:46:30 --> Controller Class Initialized
INFO - 2024-02-27 22:46:30 --> Form Validation Class Initialized
INFO - 2024-02-27 22:46:30 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:46:30 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:47:32 --> Config Class Initialized
INFO - 2024-02-27 22:47:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:47:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:47:32 --> Utf8 Class Initialized
INFO - 2024-02-27 22:47:32 --> URI Class Initialized
INFO - 2024-02-27 22:47:32 --> Router Class Initialized
INFO - 2024-02-27 22:47:32 --> Output Class Initialized
INFO - 2024-02-27 22:47:32 --> Security Class Initialized
DEBUG - 2024-02-27 22:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:47:32 --> Input Class Initialized
INFO - 2024-02-27 22:47:32 --> Language Class Initialized
INFO - 2024-02-27 22:47:32 --> Loader Class Initialized
INFO - 2024-02-27 22:47:32 --> Helper loaded: url_helper
INFO - 2024-02-27 22:47:32 --> Helper loaded: file_helper
INFO - 2024-02-27 22:47:32 --> Helper loaded: form_helper
INFO - 2024-02-27 22:47:32 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:47:32 --> Controller Class Initialized
INFO - 2024-02-27 22:47:32 --> Form Validation Class Initialized
INFO - 2024-02-27 22:47:32 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:47:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:47:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-27 22:47:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:47:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:47:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:47:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/index.php
INFO - 2024-02-27 22:47:32 --> Final output sent to browser
DEBUG - 2024-02-27 22:47:32 --> Total execution time: 0.0407
ERROR - 2024-02-27 22:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:47:32 --> Config Class Initialized
INFO - 2024-02-27 22:47:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:47:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:47:32 --> Utf8 Class Initialized
INFO - 2024-02-27 22:47:32 --> URI Class Initialized
INFO - 2024-02-27 22:47:32 --> Router Class Initialized
INFO - 2024-02-27 22:47:32 --> Output Class Initialized
INFO - 2024-02-27 22:47:32 --> Security Class Initialized
DEBUG - 2024-02-27 22:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:47:32 --> Input Class Initialized
INFO - 2024-02-27 22:47:32 --> Language Class Initialized
INFO - 2024-02-27 22:47:32 --> Loader Class Initialized
INFO - 2024-02-27 22:47:32 --> Helper loaded: url_helper
INFO - 2024-02-27 22:47:32 --> Helper loaded: file_helper
INFO - 2024-02-27 22:47:32 --> Helper loaded: form_helper
INFO - 2024-02-27 22:47:32 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:47:32 --> Controller Class Initialized
INFO - 2024-02-27 22:47:32 --> Form Validation Class Initialized
INFO - 2024-02-27 22:47:32 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:47:32 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:50:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:50:08 --> Config Class Initialized
INFO - 2024-02-27 22:50:08 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:50:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:50:08 --> Utf8 Class Initialized
INFO - 2024-02-27 22:50:08 --> URI Class Initialized
INFO - 2024-02-27 22:50:08 --> Router Class Initialized
INFO - 2024-02-27 22:50:08 --> Output Class Initialized
INFO - 2024-02-27 22:50:08 --> Security Class Initialized
DEBUG - 2024-02-27 22:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:50:08 --> Input Class Initialized
INFO - 2024-02-27 22:50:08 --> Language Class Initialized
INFO - 2024-02-27 22:50:08 --> Loader Class Initialized
INFO - 2024-02-27 22:50:08 --> Helper loaded: url_helper
INFO - 2024-02-27 22:50:08 --> Helper loaded: file_helper
INFO - 2024-02-27 22:50:08 --> Helper loaded: form_helper
INFO - 2024-02-27 22:50:08 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:50:08 --> Controller Class Initialized
INFO - 2024-02-27 22:50:08 --> Form Validation Class Initialized
INFO - 2024-02-27 22:50:08 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:50:08 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:50:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:50:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:50:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:50:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:50:08 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:50:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:50:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:50:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 22:50:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 22:50:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:50:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:50:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:50:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 22:50:08 --> Final output sent to browser
DEBUG - 2024-02-27 22:50:08 --> Total execution time: 0.0378
ERROR - 2024-02-27 22:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:50:09 --> Config Class Initialized
INFO - 2024-02-27 22:50:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:50:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:50:09 --> Utf8 Class Initialized
INFO - 2024-02-27 22:50:09 --> URI Class Initialized
INFO - 2024-02-27 22:50:09 --> Router Class Initialized
INFO - 2024-02-27 22:50:09 --> Output Class Initialized
INFO - 2024-02-27 22:50:09 --> Security Class Initialized
DEBUG - 2024-02-27 22:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:50:09 --> Input Class Initialized
INFO - 2024-02-27 22:50:09 --> Language Class Initialized
INFO - 2024-02-27 22:50:09 --> Loader Class Initialized
INFO - 2024-02-27 22:50:09 --> Helper loaded: url_helper
INFO - 2024-02-27 22:50:09 --> Helper loaded: file_helper
INFO - 2024-02-27 22:50:09 --> Helper loaded: form_helper
INFO - 2024-02-27 22:50:09 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:50:09 --> Controller Class Initialized
INFO - 2024-02-27 22:50:09 --> Form Validation Class Initialized
INFO - 2024-02-27 22:50:09 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:50:09 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:50:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:50:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:50:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:50:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:50:09 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:50:09 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:50:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:50:14 --> Config Class Initialized
INFO - 2024-02-27 22:50:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:50:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:50:14 --> Utf8 Class Initialized
INFO - 2024-02-27 22:50:14 --> URI Class Initialized
INFO - 2024-02-27 22:50:14 --> Router Class Initialized
INFO - 2024-02-27 22:50:14 --> Output Class Initialized
INFO - 2024-02-27 22:50:14 --> Security Class Initialized
DEBUG - 2024-02-27 22:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:50:14 --> Input Class Initialized
INFO - 2024-02-27 22:50:14 --> Language Class Initialized
INFO - 2024-02-27 22:50:14 --> Loader Class Initialized
INFO - 2024-02-27 22:50:14 --> Helper loaded: url_helper
INFO - 2024-02-27 22:50:14 --> Helper loaded: file_helper
INFO - 2024-02-27 22:50:14 --> Helper loaded: form_helper
INFO - 2024-02-27 22:50:14 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:50:14 --> Controller Class Initialized
INFO - 2024-02-27 22:50:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-27 22:50:14 --> Final output sent to browser
DEBUG - 2024-02-27 22:50:14 --> Total execution time: 0.0275
ERROR - 2024-02-27 22:50:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:50:16 --> Config Class Initialized
INFO - 2024-02-27 22:50:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:50:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:50:16 --> Utf8 Class Initialized
INFO - 2024-02-27 22:50:16 --> URI Class Initialized
INFO - 2024-02-27 22:50:16 --> Router Class Initialized
INFO - 2024-02-27 22:50:16 --> Output Class Initialized
INFO - 2024-02-27 22:50:16 --> Security Class Initialized
DEBUG - 2024-02-27 22:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:50:16 --> Input Class Initialized
INFO - 2024-02-27 22:50:16 --> Language Class Initialized
INFO - 2024-02-27 22:50:16 --> Loader Class Initialized
INFO - 2024-02-27 22:50:16 --> Helper loaded: url_helper
INFO - 2024-02-27 22:50:16 --> Helper loaded: file_helper
INFO - 2024-02-27 22:50:16 --> Helper loaded: form_helper
INFO - 2024-02-27 22:50:16 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:50:16 --> Controller Class Initialized
INFO - 2024-02-27 22:50:16 --> Form Validation Class Initialized
INFO - 2024-02-27 22:50:16 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:50:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:50:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 22:50:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 22:50:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:50:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:50:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:50:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 22:50:16 --> Final output sent to browser
DEBUG - 2024-02-27 22:50:16 --> Total execution time: 0.0314
ERROR - 2024-02-27 22:50:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:50:16 --> Config Class Initialized
INFO - 2024-02-27 22:50:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:50:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:50:16 --> Utf8 Class Initialized
INFO - 2024-02-27 22:50:16 --> URI Class Initialized
INFO - 2024-02-27 22:50:16 --> Router Class Initialized
INFO - 2024-02-27 22:50:16 --> Output Class Initialized
INFO - 2024-02-27 22:50:16 --> Security Class Initialized
DEBUG - 2024-02-27 22:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:50:16 --> Input Class Initialized
INFO - 2024-02-27 22:50:16 --> Language Class Initialized
INFO - 2024-02-27 22:50:16 --> Loader Class Initialized
INFO - 2024-02-27 22:50:16 --> Helper loaded: url_helper
INFO - 2024-02-27 22:50:16 --> Helper loaded: file_helper
INFO - 2024-02-27 22:50:16 --> Helper loaded: form_helper
INFO - 2024-02-27 22:50:16 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:50:16 --> Controller Class Initialized
INFO - 2024-02-27 22:50:16 --> Form Validation Class Initialized
INFO - 2024-02-27 22:50:16 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:50:16 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:50:41 --> Config Class Initialized
INFO - 2024-02-27 22:50:41 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:50:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:50:41 --> Utf8 Class Initialized
INFO - 2024-02-27 22:50:41 --> URI Class Initialized
INFO - 2024-02-27 22:50:41 --> Router Class Initialized
INFO - 2024-02-27 22:50:41 --> Output Class Initialized
INFO - 2024-02-27 22:50:41 --> Security Class Initialized
DEBUG - 2024-02-27 22:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:50:41 --> Input Class Initialized
INFO - 2024-02-27 22:50:41 --> Language Class Initialized
INFO - 2024-02-27 22:50:41 --> Loader Class Initialized
INFO - 2024-02-27 22:50:41 --> Helper loaded: url_helper
INFO - 2024-02-27 22:50:41 --> Helper loaded: file_helper
INFO - 2024-02-27 22:50:41 --> Helper loaded: form_helper
INFO - 2024-02-27 22:50:41 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:50:41 --> Controller Class Initialized
INFO - 2024-02-27 22:50:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-27 22:50:41 --> Final output sent to browser
DEBUG - 2024-02-27 22:50:41 --> Total execution time: 0.0297
ERROR - 2024-02-27 22:50:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:50:54 --> Config Class Initialized
INFO - 2024-02-27 22:50:54 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:50:54 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:50:54 --> Utf8 Class Initialized
INFO - 2024-02-27 22:50:54 --> URI Class Initialized
INFO - 2024-02-27 22:50:54 --> Router Class Initialized
INFO - 2024-02-27 22:50:54 --> Output Class Initialized
INFO - 2024-02-27 22:50:54 --> Security Class Initialized
DEBUG - 2024-02-27 22:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:50:54 --> Input Class Initialized
INFO - 2024-02-27 22:50:54 --> Language Class Initialized
INFO - 2024-02-27 22:50:54 --> Loader Class Initialized
INFO - 2024-02-27 22:50:54 --> Helper loaded: url_helper
INFO - 2024-02-27 22:50:54 --> Helper loaded: file_helper
INFO - 2024-02-27 22:50:54 --> Helper loaded: form_helper
INFO - 2024-02-27 22:50:54 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:50:54 --> Controller Class Initialized
INFO - 2024-02-27 22:50:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-27 22:50:54 --> Final output sent to browser
DEBUG - 2024-02-27 22:50:54 --> Total execution time: 0.0246
ERROR - 2024-02-27 22:51:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:51:29 --> Config Class Initialized
INFO - 2024-02-27 22:51:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:51:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:51:29 --> Utf8 Class Initialized
INFO - 2024-02-27 22:51:29 --> URI Class Initialized
INFO - 2024-02-27 22:51:29 --> Router Class Initialized
INFO - 2024-02-27 22:51:29 --> Output Class Initialized
INFO - 2024-02-27 22:51:29 --> Security Class Initialized
DEBUG - 2024-02-27 22:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:51:29 --> Input Class Initialized
INFO - 2024-02-27 22:51:29 --> Language Class Initialized
INFO - 2024-02-27 22:51:29 --> Loader Class Initialized
INFO - 2024-02-27 22:51:29 --> Helper loaded: url_helper
INFO - 2024-02-27 22:51:29 --> Helper loaded: file_helper
INFO - 2024-02-27 22:51:29 --> Helper loaded: form_helper
INFO - 2024-02-27 22:51:29 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:51:29 --> Controller Class Initialized
INFO - 2024-02-27 22:51:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-27 22:51:29 --> Final output sent to browser
DEBUG - 2024-02-27 22:51:29 --> Total execution time: 0.0217
ERROR - 2024-02-27 22:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:51:31 --> Config Class Initialized
INFO - 2024-02-27 22:51:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:51:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:51:31 --> Utf8 Class Initialized
INFO - 2024-02-27 22:51:31 --> URI Class Initialized
INFO - 2024-02-27 22:51:31 --> Router Class Initialized
INFO - 2024-02-27 22:51:31 --> Output Class Initialized
INFO - 2024-02-27 22:51:31 --> Security Class Initialized
DEBUG - 2024-02-27 22:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:51:31 --> Input Class Initialized
INFO - 2024-02-27 22:51:31 --> Language Class Initialized
INFO - 2024-02-27 22:51:31 --> Loader Class Initialized
INFO - 2024-02-27 22:51:31 --> Helper loaded: url_helper
INFO - 2024-02-27 22:51:31 --> Helper loaded: file_helper
INFO - 2024-02-27 22:51:31 --> Helper loaded: form_helper
INFO - 2024-02-27 22:51:31 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:51:31 --> Controller Class Initialized
INFO - 2024-02-27 22:51:31 --> Form Validation Class Initialized
INFO - 2024-02-27 22:51:31 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 22:51:31 --> Final output sent to browser
DEBUG - 2024-02-27 22:51:31 --> Total execution time: 0.0255
ERROR - 2024-02-27 22:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:51:31 --> Config Class Initialized
INFO - 2024-02-27 22:51:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:51:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:51:31 --> Utf8 Class Initialized
INFO - 2024-02-27 22:51:31 --> URI Class Initialized
INFO - 2024-02-27 22:51:31 --> Router Class Initialized
INFO - 2024-02-27 22:51:31 --> Output Class Initialized
INFO - 2024-02-27 22:51:31 --> Security Class Initialized
DEBUG - 2024-02-27 22:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:51:31 --> Input Class Initialized
INFO - 2024-02-27 22:51:31 --> Language Class Initialized
INFO - 2024-02-27 22:51:31 --> Loader Class Initialized
INFO - 2024-02-27 22:51:31 --> Helper loaded: url_helper
INFO - 2024-02-27 22:51:31 --> Helper loaded: file_helper
INFO - 2024-02-27 22:51:31 --> Helper loaded: form_helper
INFO - 2024-02-27 22:51:31 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:51:31 --> Controller Class Initialized
INFO - 2024-02-27 22:51:31 --> Form Validation Class Initialized
INFO - 2024-02-27 22:51:31 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:51:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 22:51:31 --> Final output sent to browser
DEBUG - 2024-02-27 22:51:31 --> Total execution time: 0.0239
ERROR - 2024-02-27 22:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:51:31 --> Config Class Initialized
INFO - 2024-02-27 22:51:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:51:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:51:31 --> Utf8 Class Initialized
INFO - 2024-02-27 22:51:31 --> URI Class Initialized
INFO - 2024-02-27 22:51:31 --> Router Class Initialized
INFO - 2024-02-27 22:51:31 --> Output Class Initialized
INFO - 2024-02-27 22:51:31 --> Security Class Initialized
DEBUG - 2024-02-27 22:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:51:31 --> Input Class Initialized
INFO - 2024-02-27 22:51:31 --> Language Class Initialized
INFO - 2024-02-27 22:51:31 --> Loader Class Initialized
INFO - 2024-02-27 22:51:31 --> Helper loaded: url_helper
INFO - 2024-02-27 22:51:31 --> Helper loaded: file_helper
INFO - 2024-02-27 22:51:31 --> Helper loaded: form_helper
INFO - 2024-02-27 22:51:31 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:51:31 --> Controller Class Initialized
INFO - 2024-02-27 22:51:31 --> Form Validation Class Initialized
INFO - 2024-02-27 22:51:31 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:51:31 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:51:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:51:51 --> Config Class Initialized
INFO - 2024-02-27 22:51:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:51:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:51:51 --> Utf8 Class Initialized
INFO - 2024-02-27 22:51:51 --> URI Class Initialized
INFO - 2024-02-27 22:51:51 --> Router Class Initialized
INFO - 2024-02-27 22:51:51 --> Output Class Initialized
INFO - 2024-02-27 22:51:51 --> Security Class Initialized
DEBUG - 2024-02-27 22:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:51:51 --> Input Class Initialized
INFO - 2024-02-27 22:51:51 --> Language Class Initialized
INFO - 2024-02-27 22:51:51 --> Loader Class Initialized
INFO - 2024-02-27 22:51:51 --> Helper loaded: url_helper
INFO - 2024-02-27 22:51:51 --> Helper loaded: file_helper
INFO - 2024-02-27 22:51:51 --> Helper loaded: form_helper
INFO - 2024-02-27 22:51:51 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:51:51 --> Controller Class Initialized
INFO - 2024-02-27 22:51:51 --> Form Validation Class Initialized
INFO - 2024-02-27 22:51:51 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:51:51 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:51:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:51:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:51:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:51:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:51:51 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:51:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:51:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:51:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 22:51:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 22:51:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:51:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:51:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:51:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 22:51:51 --> Final output sent to browser
DEBUG - 2024-02-27 22:51:51 --> Total execution time: 0.0428
ERROR - 2024-02-27 22:51:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:51:52 --> Config Class Initialized
INFO - 2024-02-27 22:51:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:51:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:51:52 --> Utf8 Class Initialized
INFO - 2024-02-27 22:51:52 --> URI Class Initialized
INFO - 2024-02-27 22:51:52 --> Router Class Initialized
INFO - 2024-02-27 22:51:52 --> Output Class Initialized
INFO - 2024-02-27 22:51:52 --> Security Class Initialized
DEBUG - 2024-02-27 22:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:51:52 --> Input Class Initialized
INFO - 2024-02-27 22:51:52 --> Language Class Initialized
INFO - 2024-02-27 22:51:52 --> Loader Class Initialized
INFO - 2024-02-27 22:51:52 --> Helper loaded: url_helper
INFO - 2024-02-27 22:51:52 --> Helper loaded: file_helper
INFO - 2024-02-27 22:51:52 --> Helper loaded: form_helper
INFO - 2024-02-27 22:51:52 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:51:52 --> Controller Class Initialized
INFO - 2024-02-27 22:51:52 --> Form Validation Class Initialized
INFO - 2024-02-27 22:51:52 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:51:52 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:51:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:51:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:51:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:51:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:51:52 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:51:52 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:51:55 --> Config Class Initialized
INFO - 2024-02-27 22:51:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:51:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:51:55 --> Utf8 Class Initialized
INFO - 2024-02-27 22:51:55 --> URI Class Initialized
INFO - 2024-02-27 22:51:55 --> Router Class Initialized
INFO - 2024-02-27 22:51:55 --> Output Class Initialized
INFO - 2024-02-27 22:51:55 --> Security Class Initialized
DEBUG - 2024-02-27 22:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:51:55 --> Input Class Initialized
INFO - 2024-02-27 22:51:55 --> Language Class Initialized
INFO - 2024-02-27 22:51:55 --> Loader Class Initialized
INFO - 2024-02-27 22:51:55 --> Helper loaded: url_helper
INFO - 2024-02-27 22:51:55 --> Helper loaded: file_helper
INFO - 2024-02-27 22:51:55 --> Helper loaded: form_helper
INFO - 2024-02-27 22:51:55 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:51:55 --> Controller Class Initialized
INFO - 2024-02-27 22:51:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-27 22:51:55 --> Final output sent to browser
DEBUG - 2024-02-27 22:51:55 --> Total execution time: 0.0285
ERROR - 2024-02-27 22:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:51:57 --> Config Class Initialized
INFO - 2024-02-27 22:51:57 --> Hooks Class Initialized
ERROR - 2024-02-27 22:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2024-02-27 22:51:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:51:57 --> Utf8 Class Initialized
INFO - 2024-02-27 22:51:57 --> URI Class Initialized
INFO - 2024-02-27 22:51:57 --> Config Class Initialized
INFO - 2024-02-27 22:51:57 --> Hooks Class Initialized
INFO - 2024-02-27 22:51:57 --> Router Class Initialized
INFO - 2024-02-27 22:51:57 --> Output Class Initialized
INFO - 2024-02-27 22:51:57 --> Security Class Initialized
DEBUG - 2024-02-27 22:51:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:51:57 --> Utf8 Class Initialized
DEBUG - 2024-02-27 22:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:51:57 --> Input Class Initialized
INFO - 2024-02-27 22:51:57 --> Language Class Initialized
INFO - 2024-02-27 22:51:57 --> URI Class Initialized
INFO - 2024-02-27 22:51:57 --> Loader Class Initialized
INFO - 2024-02-27 22:51:57 --> Router Class Initialized
INFO - 2024-02-27 22:51:57 --> Helper loaded: url_helper
INFO - 2024-02-27 22:51:57 --> Helper loaded: file_helper
INFO - 2024-02-27 22:51:57 --> Helper loaded: form_helper
INFO - 2024-02-27 22:51:57 --> Output Class Initialized
INFO - 2024-02-27 22:51:57 --> Security Class Initialized
DEBUG - 2024-02-27 22:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:51:57 --> Input Class Initialized
INFO - 2024-02-27 22:51:57 --> Language Class Initialized
INFO - 2024-02-27 22:51:57 --> Database Driver Class Initialized
INFO - 2024-02-27 22:51:57 --> Loader Class Initialized
INFO - 2024-02-27 22:51:57 --> Helper loaded: url_helper
INFO - 2024-02-27 22:51:57 --> Helper loaded: file_helper
INFO - 2024-02-27 22:51:57 --> Helper loaded: form_helper
DEBUG - 2024-02-27 22:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:51:57 --> Controller Class Initialized
INFO - 2024-02-27 22:51:57 --> Model "LoginModel" initialized
INFO - 2024-02-27 22:51:57 --> Database Driver Class Initialized
INFO - 2024-02-27 22:51:57 --> Form Validation Class Initialized
DEBUG - 2024-02-27 22:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:51:57 --> Controller Class Initialized
INFO - 2024-02-27 22:51:57 --> Form Validation Class Initialized
INFO - 2024-02-27 22:51:57 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 22:51:57 --> Final output sent to browser
DEBUG - 2024-02-27 22:51:57 --> Total execution time: 0.0364
ERROR - 2024-02-27 22:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:51:57 --> Config Class Initialized
INFO - 2024-02-27 22:51:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:51:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:51:57 --> Utf8 Class Initialized
INFO - 2024-02-27 22:51:57 --> URI Class Initialized
INFO - 2024-02-27 22:51:57 --> Router Class Initialized
INFO - 2024-02-27 22:51:57 --> Output Class Initialized
INFO - 2024-02-27 22:51:57 --> Security Class Initialized
DEBUG - 2024-02-27 22:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:51:57 --> Input Class Initialized
INFO - 2024-02-27 22:51:57 --> Language Class Initialized
INFO - 2024-02-27 22:51:57 --> Loader Class Initialized
INFO - 2024-02-27 22:51:57 --> Helper loaded: url_helper
INFO - 2024-02-27 22:51:57 --> Helper loaded: file_helper
INFO - 2024-02-27 22:51:57 --> Helper loaded: form_helper
INFO - 2024-02-27 22:51:57 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:51:57 --> Controller Class Initialized
INFO - 2024-02-27 22:51:57 --> Form Validation Class Initialized
INFO - 2024-02-27 22:51:57 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:51:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:51:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 22:51:57 --> Final output sent to browser
DEBUG - 2024-02-27 22:51:57 --> Total execution time: 0.0263
ERROR - 2024-02-27 22:51:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:51:58 --> Config Class Initialized
INFO - 2024-02-27 22:51:58 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:51:58 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:51:58 --> Utf8 Class Initialized
INFO - 2024-02-27 22:51:58 --> URI Class Initialized
INFO - 2024-02-27 22:51:58 --> Router Class Initialized
INFO - 2024-02-27 22:51:58 --> Output Class Initialized
INFO - 2024-02-27 22:51:58 --> Security Class Initialized
DEBUG - 2024-02-27 22:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:51:58 --> Input Class Initialized
INFO - 2024-02-27 22:51:58 --> Language Class Initialized
INFO - 2024-02-27 22:51:58 --> Loader Class Initialized
INFO - 2024-02-27 22:51:58 --> Helper loaded: url_helper
INFO - 2024-02-27 22:51:58 --> Helper loaded: file_helper
INFO - 2024-02-27 22:51:58 --> Helper loaded: form_helper
INFO - 2024-02-27 22:51:58 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:51:58 --> Controller Class Initialized
INFO - 2024-02-27 22:51:58 --> Form Validation Class Initialized
INFO - 2024-02-27 22:51:58 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:51:58 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:51:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:51:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:51:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:51:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:51:58 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:51:58 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 22:52:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:52:29 --> Config Class Initialized
INFO - 2024-02-27 22:52:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:52:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:52:29 --> Utf8 Class Initialized
INFO - 2024-02-27 22:52:29 --> URI Class Initialized
INFO - 2024-02-27 22:52:29 --> Router Class Initialized
INFO - 2024-02-27 22:52:29 --> Output Class Initialized
INFO - 2024-02-27 22:52:29 --> Security Class Initialized
DEBUG - 2024-02-27 22:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:52:29 --> Input Class Initialized
INFO - 2024-02-27 22:52:29 --> Language Class Initialized
INFO - 2024-02-27 22:52:29 --> Loader Class Initialized
INFO - 2024-02-27 22:52:29 --> Helper loaded: url_helper
INFO - 2024-02-27 22:52:29 --> Helper loaded: file_helper
INFO - 2024-02-27 22:52:29 --> Helper loaded: form_helper
INFO - 2024-02-27 22:52:29 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:52:29 --> Controller Class Initialized
INFO - 2024-02-27 22:52:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-27 22:52:29 --> Final output sent to browser
DEBUG - 2024-02-27 22:52:29 --> Total execution time: 0.0205
ERROR - 2024-02-27 22:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:52:33 --> Config Class Initialized
INFO - 2024-02-27 22:52:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:52:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:52:33 --> Utf8 Class Initialized
INFO - 2024-02-27 22:52:33 --> URI Class Initialized
INFO - 2024-02-27 22:52:33 --> Router Class Initialized
INFO - 2024-02-27 22:52:33 --> Output Class Initialized
INFO - 2024-02-27 22:52:33 --> Security Class Initialized
DEBUG - 2024-02-27 22:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:52:33 --> Input Class Initialized
INFO - 2024-02-27 22:52:33 --> Language Class Initialized
INFO - 2024-02-27 22:52:33 --> Loader Class Initialized
INFO - 2024-02-27 22:52:33 --> Helper loaded: url_helper
INFO - 2024-02-27 22:52:33 --> Helper loaded: file_helper
INFO - 2024-02-27 22:52:33 --> Helper loaded: form_helper
INFO - 2024-02-27 22:52:33 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:52:33 --> Controller Class Initialized
INFO - 2024-02-27 22:52:33 --> Model "LoginModel" initialized
INFO - 2024-02-27 22:52:33 --> Form Validation Class Initialized
ERROR - 2024-02-27 22:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:52:33 --> Config Class Initialized
INFO - 2024-02-27 22:52:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:52:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:52:33 --> Utf8 Class Initialized
INFO - 2024-02-27 22:52:33 --> URI Class Initialized
INFO - 2024-02-27 22:52:33 --> Router Class Initialized
INFO - 2024-02-27 22:52:33 --> Output Class Initialized
INFO - 2024-02-27 22:52:33 --> Security Class Initialized
DEBUG - 2024-02-27 22:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:52:33 --> Input Class Initialized
INFO - 2024-02-27 22:52:33 --> Language Class Initialized
INFO - 2024-02-27 22:52:33 --> Loader Class Initialized
INFO - 2024-02-27 22:52:33 --> Helper loaded: url_helper
INFO - 2024-02-27 22:52:33 --> Helper loaded: file_helper
INFO - 2024-02-27 22:52:33 --> Helper loaded: form_helper
INFO - 2024-02-27 22:52:33 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:52:33 --> Controller Class Initialized
INFO - 2024-02-27 22:52:33 --> Form Validation Class Initialized
INFO - 2024-02-27 22:52:33 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 22:52:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 22:52:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 22:52:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 22:52:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 22:52:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 22:52:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 22:52:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 22:52:33 --> Final output sent to browser
DEBUG - 2024-02-27 22:52:33 --> Total execution time: 0.0262
ERROR - 2024-02-27 22:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 22:52:33 --> Config Class Initialized
INFO - 2024-02-27 22:52:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 22:52:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 22:52:33 --> Utf8 Class Initialized
INFO - 2024-02-27 22:52:33 --> URI Class Initialized
INFO - 2024-02-27 22:52:33 --> Router Class Initialized
INFO - 2024-02-27 22:52:33 --> Output Class Initialized
INFO - 2024-02-27 22:52:33 --> Security Class Initialized
DEBUG - 2024-02-27 22:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 22:52:33 --> Input Class Initialized
INFO - 2024-02-27 22:52:33 --> Language Class Initialized
INFO - 2024-02-27 22:52:33 --> Loader Class Initialized
INFO - 2024-02-27 22:52:33 --> Helper loaded: url_helper
INFO - 2024-02-27 22:52:33 --> Helper loaded: file_helper
INFO - 2024-02-27 22:52:33 --> Helper loaded: form_helper
INFO - 2024-02-27 22:52:33 --> Database Driver Class Initialized
DEBUG - 2024-02-27 22:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 22:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 22:52:33 --> Controller Class Initialized
INFO - 2024-02-27 22:52:33 --> Form Validation Class Initialized
INFO - 2024-02-27 22:52:33 --> Model "MasterModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "DashboardModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "OrderModel" initialized
INFO - 2024-02-27 22:52:33 --> Model "PaymentVoucherModel" initialized
ERROR - 2024-02-27 23:02:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:30 --> Config Class Initialized
INFO - 2024-02-27 23:02:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:30 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:30 --> URI Class Initialized
INFO - 2024-02-27 23:02:30 --> Router Class Initialized
INFO - 2024-02-27 23:02:30 --> Output Class Initialized
INFO - 2024-02-27 23:02:30 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:30 --> Input Class Initialized
INFO - 2024-02-27 23:02:30 --> Language Class Initialized
INFO - 2024-02-27 23:02:30 --> Loader Class Initialized
INFO - 2024-02-27 23:02:30 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:30 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:30 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:30 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:30 --> Controller Class Initialized
INFO - 2024-02-27 23:02:30 --> Model "LoginModel" initialized
INFO - 2024-02-27 23:02:30 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-27 23:02:30 --> Final output sent to browser
DEBUG - 2024-02-27 23:02:30 --> Total execution time: 0.0276
ERROR - 2024-02-27 23:02:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:38 --> Config Class Initialized
INFO - 2024-02-27 23:02:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:38 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:38 --> URI Class Initialized
INFO - 2024-02-27 23:02:38 --> Router Class Initialized
INFO - 2024-02-27 23:02:38 --> Output Class Initialized
INFO - 2024-02-27 23:02:38 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:38 --> Input Class Initialized
INFO - 2024-02-27 23:02:38 --> Language Class Initialized
INFO - 2024-02-27 23:02:38 --> Loader Class Initialized
INFO - 2024-02-27 23:02:38 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:38 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:38 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:38 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:38 --> Controller Class Initialized
INFO - 2024-02-27 23:02:38 --> Model "LoginModel" initialized
INFO - 2024-02-27 23:02:38 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-27 23:02:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:38 --> Config Class Initialized
INFO - 2024-02-27 23:02:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:38 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:38 --> URI Class Initialized
INFO - 2024-02-27 23:02:38 --> Router Class Initialized
INFO - 2024-02-27 23:02:38 --> Output Class Initialized
INFO - 2024-02-27 23:02:38 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:38 --> Input Class Initialized
INFO - 2024-02-27 23:02:38 --> Language Class Initialized
INFO - 2024-02-27 23:02:38 --> Loader Class Initialized
INFO - 2024-02-27 23:02:38 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:38 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:38 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:38 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:38 --> Controller Class Initialized
INFO - 2024-02-27 23:02:38 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:38 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:02:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:02:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 23:02:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-27 23:02:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:02:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:02:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:02:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 23:02:38 --> Final output sent to browser
DEBUG - 2024-02-27 23:02:38 --> Total execution time: 0.0308
ERROR - 2024-02-27 23:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:39 --> Config Class Initialized
INFO - 2024-02-27 23:02:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:39 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:39 --> URI Class Initialized
INFO - 2024-02-27 23:02:39 --> Router Class Initialized
INFO - 2024-02-27 23:02:39 --> Output Class Initialized
INFO - 2024-02-27 23:02:39 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:39 --> Input Class Initialized
INFO - 2024-02-27 23:02:39 --> Language Class Initialized
INFO - 2024-02-27 23:02:40 --> Loader Class Initialized
INFO - 2024-02-27 23:02:40 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:40 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:40 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:40 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:40 --> Controller Class Initialized
INFO - 2024-02-27 23:02:40 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:40 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:40 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:40 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:40 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:02:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:45 --> Config Class Initialized
INFO - 2024-02-27 23:02:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:45 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:45 --> URI Class Initialized
INFO - 2024-02-27 23:02:45 --> Router Class Initialized
INFO - 2024-02-27 23:02:45 --> Output Class Initialized
INFO - 2024-02-27 23:02:45 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:45 --> Input Class Initialized
INFO - 2024-02-27 23:02:45 --> Language Class Initialized
INFO - 2024-02-27 23:02:45 --> Loader Class Initialized
INFO - 2024-02-27 23:02:45 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:45 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:45 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:45 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:45 --> Controller Class Initialized
INFO - 2024-02-27 23:02:45 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:45 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:02:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:02:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-27 23:02:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:02:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:02:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:02:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/index.php
INFO - 2024-02-27 23:02:45 --> Final output sent to browser
DEBUG - 2024-02-27 23:02:45 --> Total execution time: 0.0438
ERROR - 2024-02-27 23:02:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:45 --> Config Class Initialized
INFO - 2024-02-27 23:02:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:45 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:45 --> URI Class Initialized
INFO - 2024-02-27 23:02:45 --> Router Class Initialized
INFO - 2024-02-27 23:02:45 --> Output Class Initialized
INFO - 2024-02-27 23:02:45 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:45 --> Input Class Initialized
INFO - 2024-02-27 23:02:45 --> Language Class Initialized
INFO - 2024-02-27 23:02:45 --> Loader Class Initialized
INFO - 2024-02-27 23:02:45 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:45 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:45 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:45 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:45 --> Controller Class Initialized
INFO - 2024-02-27 23:02:45 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:45 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:45 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:02:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:48 --> Config Class Initialized
INFO - 2024-02-27 23:02:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:48 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:48 --> URI Class Initialized
INFO - 2024-02-27 23:02:48 --> Router Class Initialized
INFO - 2024-02-27 23:02:48 --> Output Class Initialized
INFO - 2024-02-27 23:02:48 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:48 --> Input Class Initialized
INFO - 2024-02-27 23:02:48 --> Language Class Initialized
INFO - 2024-02-27 23:02:48 --> Loader Class Initialized
INFO - 2024-02-27 23:02:48 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:48 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:48 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:48 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:48 --> Controller Class Initialized
INFO - 2024-02-27 23:02:48 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:48 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:48 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:48 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:48 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:02:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/form.php
INFO - 2024-02-27 23:02:48 --> Final output sent to browser
DEBUG - 2024-02-27 23:02:48 --> Total execution time: 0.0398
ERROR - 2024-02-27 23:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:50 --> Config Class Initialized
INFO - 2024-02-27 23:02:50 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:50 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:50 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:50 --> URI Class Initialized
INFO - 2024-02-27 23:02:50 --> Router Class Initialized
INFO - 2024-02-27 23:02:50 --> Output Class Initialized
INFO - 2024-02-27 23:02:50 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:50 --> Input Class Initialized
INFO - 2024-02-27 23:02:50 --> Language Class Initialized
INFO - 2024-02-27 23:02:50 --> Loader Class Initialized
INFO - 2024-02-27 23:02:50 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:50 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:50 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:50 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:50 --> Controller Class Initialized
INFO - 2024-02-27 23:02:50 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:50 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:50 --> Config Class Initialized
INFO - 2024-02-27 23:02:50 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:50 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:50 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:50 --> URI Class Initialized
INFO - 2024-02-27 23:02:50 --> Router Class Initialized
INFO - 2024-02-27 23:02:50 --> Output Class Initialized
INFO - 2024-02-27 23:02:50 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:50 --> Input Class Initialized
INFO - 2024-02-27 23:02:50 --> Language Class Initialized
INFO - 2024-02-27 23:02:50 --> Loader Class Initialized
INFO - 2024-02-27 23:02:50 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:50 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:50 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:50 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:50 --> Controller Class Initialized
INFO - 2024-02-27 23:02:50 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:50 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:50 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:02:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:53 --> Config Class Initialized
INFO - 2024-02-27 23:02:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:53 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:53 --> URI Class Initialized
INFO - 2024-02-27 23:02:53 --> Router Class Initialized
INFO - 2024-02-27 23:02:53 --> Output Class Initialized
INFO - 2024-02-27 23:02:53 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:53 --> Input Class Initialized
INFO - 2024-02-27 23:02:53 --> Language Class Initialized
INFO - 2024-02-27 23:02:54 --> Loader Class Initialized
INFO - 2024-02-27 23:02:54 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:54 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:54 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:54 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:54 --> Controller Class Initialized
INFO - 2024-02-27 23:02:54 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:54 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:54 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:54 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:54 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:02:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/form.php
INFO - 2024-02-27 23:02:54 --> Final output sent to browser
DEBUG - 2024-02-27 23:02:54 --> Total execution time: 0.0454
ERROR - 2024-02-27 23:02:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:55 --> Config Class Initialized
INFO - 2024-02-27 23:02:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:55 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:55 --> URI Class Initialized
INFO - 2024-02-27 23:02:55 --> Router Class Initialized
INFO - 2024-02-27 23:02:55 --> Output Class Initialized
INFO - 2024-02-27 23:02:55 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:55 --> Input Class Initialized
INFO - 2024-02-27 23:02:55 --> Language Class Initialized
INFO - 2024-02-27 23:02:55 --> Loader Class Initialized
INFO - 2024-02-27 23:02:55 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:55 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:55 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:55 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:55 --> Controller Class Initialized
INFO - 2024-02-27 23:02:55 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:55 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:02:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:55 --> Config Class Initialized
INFO - 2024-02-27 23:02:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:55 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:55 --> URI Class Initialized
INFO - 2024-02-27 23:02:55 --> Router Class Initialized
INFO - 2024-02-27 23:02:55 --> Output Class Initialized
INFO - 2024-02-27 23:02:55 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:55 --> Input Class Initialized
INFO - 2024-02-27 23:02:55 --> Language Class Initialized
INFO - 2024-02-27 23:02:55 --> Loader Class Initialized
INFO - 2024-02-27 23:02:55 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:55 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:55 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:55 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:55 --> Controller Class Initialized
INFO - 2024-02-27 23:02:55 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:55 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:55 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:02:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:58 --> Config Class Initialized
INFO - 2024-02-27 23:02:58 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:58 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:58 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:58 --> URI Class Initialized
INFO - 2024-02-27 23:02:58 --> Router Class Initialized
INFO - 2024-02-27 23:02:58 --> Output Class Initialized
INFO - 2024-02-27 23:02:58 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:58 --> Input Class Initialized
INFO - 2024-02-27 23:02:58 --> Language Class Initialized
INFO - 2024-02-27 23:02:58 --> Loader Class Initialized
INFO - 2024-02-27 23:02:58 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:58 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:58 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:58 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:58 --> Controller Class Initialized
INFO - 2024-02-27 23:02:58 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:58 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:58 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:58 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:58 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:02:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/form.php
INFO - 2024-02-27 23:02:58 --> Final output sent to browser
DEBUG - 2024-02-27 23:02:58 --> Total execution time: 0.0358
ERROR - 2024-02-27 23:02:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:59 --> Config Class Initialized
INFO - 2024-02-27 23:02:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:59 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:59 --> URI Class Initialized
INFO - 2024-02-27 23:02:59 --> Router Class Initialized
INFO - 2024-02-27 23:02:59 --> Output Class Initialized
INFO - 2024-02-27 23:02:59 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:59 --> Input Class Initialized
INFO - 2024-02-27 23:02:59 --> Language Class Initialized
INFO - 2024-02-27 23:02:59 --> Loader Class Initialized
INFO - 2024-02-27 23:02:59 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:59 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:59 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:59 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:59 --> Controller Class Initialized
INFO - 2024-02-27 23:02:59 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:59 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:02:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:02:59 --> Config Class Initialized
INFO - 2024-02-27 23:02:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:02:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:02:59 --> Utf8 Class Initialized
INFO - 2024-02-27 23:02:59 --> URI Class Initialized
INFO - 2024-02-27 23:02:59 --> Router Class Initialized
INFO - 2024-02-27 23:02:59 --> Output Class Initialized
INFO - 2024-02-27 23:02:59 --> Security Class Initialized
DEBUG - 2024-02-27 23:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:02:59 --> Input Class Initialized
INFO - 2024-02-27 23:02:59 --> Language Class Initialized
INFO - 2024-02-27 23:02:59 --> Loader Class Initialized
INFO - 2024-02-27 23:02:59 --> Helper loaded: url_helper
INFO - 2024-02-27 23:02:59 --> Helper loaded: file_helper
INFO - 2024-02-27 23:02:59 --> Helper loaded: form_helper
INFO - 2024-02-27 23:02:59 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:02:59 --> Controller Class Initialized
INFO - 2024-02-27 23:02:59 --> Form Validation Class Initialized
INFO - 2024-02-27 23:02:59 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:02:59 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:09:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:09:04 --> Config Class Initialized
INFO - 2024-02-27 23:09:04 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:09:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:09:04 --> Utf8 Class Initialized
INFO - 2024-02-27 23:09:04 --> URI Class Initialized
INFO - 2024-02-27 23:09:04 --> Router Class Initialized
INFO - 2024-02-27 23:09:04 --> Output Class Initialized
INFO - 2024-02-27 23:09:04 --> Security Class Initialized
DEBUG - 2024-02-27 23:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:09:04 --> Input Class Initialized
INFO - 2024-02-27 23:09:04 --> Language Class Initialized
INFO - 2024-02-27 23:09:04 --> Loader Class Initialized
INFO - 2024-02-27 23:09:04 --> Helper loaded: url_helper
INFO - 2024-02-27 23:09:04 --> Helper loaded: file_helper
INFO - 2024-02-27 23:09:04 --> Helper loaded: form_helper
INFO - 2024-02-27 23:09:04 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:09:04 --> Controller Class Initialized
INFO - 2024-02-27 23:09:04 --> Form Validation Class Initialized
INFO - 2024-02-27 23:09:04 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:09:04 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:09:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:09:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:09:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:09:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:09:04 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:09:04 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:09:04 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:09:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:09:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:09:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:09:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:09:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:09:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-02-27 23:09:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-02-27 23:09:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-27 23:09:04 --> Final output sent to browser
DEBUG - 2024-02-27 23:09:04 --> Total execution time: 0.0370
ERROR - 2024-02-27 23:09:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:09:05 --> Config Class Initialized
INFO - 2024-02-27 23:09:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:09:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:09:05 --> Utf8 Class Initialized
INFO - 2024-02-27 23:09:05 --> URI Class Initialized
INFO - 2024-02-27 23:09:05 --> Router Class Initialized
INFO - 2024-02-27 23:09:05 --> Output Class Initialized
INFO - 2024-02-27 23:09:05 --> Security Class Initialized
DEBUG - 2024-02-27 23:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:09:05 --> Input Class Initialized
INFO - 2024-02-27 23:09:05 --> Language Class Initialized
INFO - 2024-02-27 23:09:05 --> Loader Class Initialized
INFO - 2024-02-27 23:09:05 --> Helper loaded: url_helper
INFO - 2024-02-27 23:09:05 --> Helper loaded: file_helper
INFO - 2024-02-27 23:09:05 --> Helper loaded: form_helper
INFO - 2024-02-27 23:09:05 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:09:05 --> Controller Class Initialized
INFO - 2024-02-27 23:09:05 --> Form Validation Class Initialized
INFO - 2024-02-27 23:09:05 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:09:05 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:09:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:09:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:09:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:09:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:09:05 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:09:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:09:05 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:24:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:24:24 --> Config Class Initialized
INFO - 2024-02-27 23:24:24 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:24:24 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:24:24 --> Utf8 Class Initialized
INFO - 2024-02-27 23:24:24 --> URI Class Initialized
INFO - 2024-02-27 23:24:24 --> Router Class Initialized
INFO - 2024-02-27 23:24:24 --> Output Class Initialized
INFO - 2024-02-27 23:24:24 --> Security Class Initialized
DEBUG - 2024-02-27 23:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:24:24 --> Input Class Initialized
INFO - 2024-02-27 23:24:24 --> Language Class Initialized
INFO - 2024-02-27 23:24:24 --> Loader Class Initialized
INFO - 2024-02-27 23:24:24 --> Helper loaded: url_helper
INFO - 2024-02-27 23:24:24 --> Helper loaded: file_helper
INFO - 2024-02-27 23:24:24 --> Helper loaded: form_helper
INFO - 2024-02-27 23:24:24 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:24:24 --> Controller Class Initialized
INFO - 2024-02-27 23:24:24 --> Form Validation Class Initialized
INFO - 2024-02-27 23:24:24 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:24:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:24:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 23:24:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:24:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:24:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:24:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:24:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 23:24:24 --> Final output sent to browser
DEBUG - 2024-02-27 23:24:24 --> Total execution time: 0.0295
ERROR - 2024-02-27 23:24:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:24:24 --> Config Class Initialized
INFO - 2024-02-27 23:24:24 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:24:24 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:24:24 --> Utf8 Class Initialized
INFO - 2024-02-27 23:24:24 --> URI Class Initialized
INFO - 2024-02-27 23:24:24 --> Router Class Initialized
INFO - 2024-02-27 23:24:24 --> Output Class Initialized
INFO - 2024-02-27 23:24:24 --> Security Class Initialized
DEBUG - 2024-02-27 23:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:24:24 --> Input Class Initialized
INFO - 2024-02-27 23:24:24 --> Language Class Initialized
INFO - 2024-02-27 23:24:24 --> Loader Class Initialized
INFO - 2024-02-27 23:24:24 --> Helper loaded: url_helper
INFO - 2024-02-27 23:24:24 --> Helper loaded: file_helper
INFO - 2024-02-27 23:24:24 --> Helper loaded: form_helper
INFO - 2024-02-27 23:24:24 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:24:24 --> Controller Class Initialized
INFO - 2024-02-27 23:24:24 --> Form Validation Class Initialized
INFO - 2024-02-27 23:24:24 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:24:24 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:24:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:24:27 --> Config Class Initialized
INFO - 2024-02-27 23:24:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:24:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:24:27 --> Utf8 Class Initialized
INFO - 2024-02-27 23:24:27 --> URI Class Initialized
INFO - 2024-02-27 23:24:27 --> Router Class Initialized
INFO - 2024-02-27 23:24:27 --> Output Class Initialized
INFO - 2024-02-27 23:24:27 --> Security Class Initialized
DEBUG - 2024-02-27 23:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:24:27 --> Input Class Initialized
INFO - 2024-02-27 23:24:27 --> Language Class Initialized
INFO - 2024-02-27 23:24:27 --> Loader Class Initialized
INFO - 2024-02-27 23:24:27 --> Helper loaded: url_helper
INFO - 2024-02-27 23:24:27 --> Helper loaded: file_helper
INFO - 2024-02-27 23:24:27 --> Helper loaded: form_helper
INFO - 2024-02-27 23:24:27 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:24:27 --> Controller Class Initialized
INFO - 2024-02-27 23:24:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-27 23:24:27 --> Final output sent to browser
DEBUG - 2024-02-27 23:24:27 --> Total execution time: 0.0320
ERROR - 2024-02-27 23:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:24:32 --> Config Class Initialized
INFO - 2024-02-27 23:24:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:24:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:24:32 --> Utf8 Class Initialized
INFO - 2024-02-27 23:24:32 --> URI Class Initialized
INFO - 2024-02-27 23:24:32 --> Router Class Initialized
INFO - 2024-02-27 23:24:32 --> Output Class Initialized
INFO - 2024-02-27 23:24:32 --> Security Class Initialized
DEBUG - 2024-02-27 23:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:24:32 --> Input Class Initialized
INFO - 2024-02-27 23:24:32 --> Language Class Initialized
INFO - 2024-02-27 23:24:32 --> Loader Class Initialized
INFO - 2024-02-27 23:24:32 --> Helper loaded: url_helper
INFO - 2024-02-27 23:24:32 --> Helper loaded: file_helper
INFO - 2024-02-27 23:24:32 --> Helper loaded: form_helper
INFO - 2024-02-27 23:24:32 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:24:32 --> Controller Class Initialized
INFO - 2024-02-27 23:24:32 --> Model "LoginModel" initialized
INFO - 2024-02-27 23:24:32 --> Form Validation Class Initialized
ERROR - 2024-02-27 23:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:24:32 --> Config Class Initialized
INFO - 2024-02-27 23:24:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:24:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:24:32 --> Utf8 Class Initialized
INFO - 2024-02-27 23:24:32 --> URI Class Initialized
INFO - 2024-02-27 23:24:32 --> Router Class Initialized
INFO - 2024-02-27 23:24:32 --> Output Class Initialized
INFO - 2024-02-27 23:24:32 --> Security Class Initialized
DEBUG - 2024-02-27 23:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:24:32 --> Input Class Initialized
INFO - 2024-02-27 23:24:32 --> Language Class Initialized
INFO - 2024-02-27 23:24:32 --> Loader Class Initialized
INFO - 2024-02-27 23:24:32 --> Helper loaded: url_helper
INFO - 2024-02-27 23:24:32 --> Helper loaded: file_helper
INFO - 2024-02-27 23:24:32 --> Helper loaded: form_helper
INFO - 2024-02-27 23:24:32 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:24:32 --> Controller Class Initialized
INFO - 2024-02-27 23:24:32 --> Form Validation Class Initialized
INFO - 2024-02-27 23:24:32 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-27 23:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:24:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-27 23:24:32 --> Final output sent to browser
DEBUG - 2024-02-27 23:24:32 --> Total execution time: 0.0283
ERROR - 2024-02-27 23:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:24:32 --> Config Class Initialized
INFO - 2024-02-27 23:24:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:24:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:24:32 --> Utf8 Class Initialized
INFO - 2024-02-27 23:24:32 --> URI Class Initialized
INFO - 2024-02-27 23:24:32 --> Router Class Initialized
INFO - 2024-02-27 23:24:32 --> Output Class Initialized
INFO - 2024-02-27 23:24:32 --> Security Class Initialized
DEBUG - 2024-02-27 23:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:24:32 --> Input Class Initialized
INFO - 2024-02-27 23:24:32 --> Language Class Initialized
INFO - 2024-02-27 23:24:32 --> Loader Class Initialized
INFO - 2024-02-27 23:24:32 --> Helper loaded: url_helper
INFO - 2024-02-27 23:24:32 --> Helper loaded: file_helper
INFO - 2024-02-27 23:24:32 --> Helper loaded: form_helper
INFO - 2024-02-27 23:24:32 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:24:32 --> Controller Class Initialized
INFO - 2024-02-27 23:24:32 --> Form Validation Class Initialized
INFO - 2024-02-27 23:24:32 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:24:32 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:24:56 --> Config Class Initialized
INFO - 2024-02-27 23:24:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:24:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:24:56 --> Utf8 Class Initialized
INFO - 2024-02-27 23:24:56 --> URI Class Initialized
INFO - 2024-02-27 23:24:56 --> Router Class Initialized
INFO - 2024-02-27 23:24:56 --> Output Class Initialized
INFO - 2024-02-27 23:24:56 --> Security Class Initialized
DEBUG - 2024-02-27 23:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:24:56 --> Input Class Initialized
INFO - 2024-02-27 23:24:56 --> Language Class Initialized
INFO - 2024-02-27 23:24:56 --> Loader Class Initialized
INFO - 2024-02-27 23:24:56 --> Helper loaded: url_helper
INFO - 2024-02-27 23:24:56 --> Helper loaded: file_helper
INFO - 2024-02-27 23:24:56 --> Helper loaded: form_helper
INFO - 2024-02-27 23:24:56 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:24:56 --> Controller Class Initialized
INFO - 2024-02-27 23:24:56 --> Form Validation Class Initialized
INFO - 2024-02-27 23:24:56 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:24:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:24:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:24:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:24:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:24:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:24:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:24:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:24:56 --> Final output sent to browser
DEBUG - 2024-02-27 23:24:56 --> Total execution time: 0.0266
ERROR - 2024-02-27 23:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:24:56 --> Config Class Initialized
INFO - 2024-02-27 23:24:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:24:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:24:56 --> Utf8 Class Initialized
INFO - 2024-02-27 23:24:56 --> URI Class Initialized
INFO - 2024-02-27 23:24:56 --> Router Class Initialized
INFO - 2024-02-27 23:24:56 --> Output Class Initialized
INFO - 2024-02-27 23:24:56 --> Security Class Initialized
DEBUG - 2024-02-27 23:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:24:56 --> Input Class Initialized
INFO - 2024-02-27 23:24:56 --> Language Class Initialized
INFO - 2024-02-27 23:24:56 --> Loader Class Initialized
INFO - 2024-02-27 23:24:56 --> Helper loaded: url_helper
INFO - 2024-02-27 23:24:56 --> Helper loaded: file_helper
INFO - 2024-02-27 23:24:56 --> Helper loaded: form_helper
INFO - 2024-02-27 23:24:56 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:24:56 --> Controller Class Initialized
INFO - 2024-02-27 23:24:56 --> Form Validation Class Initialized
INFO - 2024-02-27 23:24:56 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:24:56 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:25:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:25:20 --> Config Class Initialized
INFO - 2024-02-27 23:25:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:25:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:25:20 --> Utf8 Class Initialized
INFO - 2024-02-27 23:25:20 --> URI Class Initialized
INFO - 2024-02-27 23:25:20 --> Router Class Initialized
INFO - 2024-02-27 23:25:20 --> Output Class Initialized
INFO - 2024-02-27 23:25:20 --> Security Class Initialized
DEBUG - 2024-02-27 23:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:25:20 --> Input Class Initialized
INFO - 2024-02-27 23:25:20 --> Language Class Initialized
INFO - 2024-02-27 23:25:20 --> Loader Class Initialized
INFO - 2024-02-27 23:25:20 --> Helper loaded: url_helper
INFO - 2024-02-27 23:25:20 --> Helper loaded: file_helper
INFO - 2024-02-27 23:25:20 --> Helper loaded: form_helper
INFO - 2024-02-27 23:25:20 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:25:20 --> Controller Class Initialized
INFO - 2024-02-27 23:25:20 --> Form Validation Class Initialized
INFO - 2024-02-27 23:25:20 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:25:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:25:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:25:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:25:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:25:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:25:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:25:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:25:20 --> Final output sent to browser
DEBUG - 2024-02-27 23:25:20 --> Total execution time: 0.0331
ERROR - 2024-02-27 23:25:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:25:20 --> Config Class Initialized
INFO - 2024-02-27 23:25:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:25:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:25:20 --> Utf8 Class Initialized
INFO - 2024-02-27 23:25:20 --> URI Class Initialized
INFO - 2024-02-27 23:25:20 --> Router Class Initialized
INFO - 2024-02-27 23:25:20 --> Output Class Initialized
INFO - 2024-02-27 23:25:20 --> Security Class Initialized
DEBUG - 2024-02-27 23:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:25:20 --> Input Class Initialized
INFO - 2024-02-27 23:25:20 --> Language Class Initialized
INFO - 2024-02-27 23:25:20 --> Loader Class Initialized
INFO - 2024-02-27 23:25:20 --> Helper loaded: url_helper
INFO - 2024-02-27 23:25:20 --> Helper loaded: file_helper
INFO - 2024-02-27 23:25:20 --> Helper loaded: form_helper
INFO - 2024-02-27 23:25:20 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:25:20 --> Controller Class Initialized
INFO - 2024-02-27 23:25:20 --> Form Validation Class Initialized
INFO - 2024-02-27 23:25:20 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:25:20 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:25:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:25:34 --> Config Class Initialized
INFO - 2024-02-27 23:25:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:25:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:25:34 --> Utf8 Class Initialized
INFO - 2024-02-27 23:25:34 --> URI Class Initialized
INFO - 2024-02-27 23:25:34 --> Router Class Initialized
INFO - 2024-02-27 23:25:34 --> Output Class Initialized
INFO - 2024-02-27 23:25:34 --> Security Class Initialized
DEBUG - 2024-02-27 23:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:25:34 --> Input Class Initialized
INFO - 2024-02-27 23:25:34 --> Language Class Initialized
INFO - 2024-02-27 23:25:34 --> Loader Class Initialized
INFO - 2024-02-27 23:25:34 --> Helper loaded: url_helper
INFO - 2024-02-27 23:25:34 --> Helper loaded: file_helper
INFO - 2024-02-27 23:25:34 --> Helper loaded: form_helper
INFO - 2024-02-27 23:25:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:25:34 --> Controller Class Initialized
INFO - 2024-02-27 23:25:34 --> Form Validation Class Initialized
INFO - 2024-02-27 23:25:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:25:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:25:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:25:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:25:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:25:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:25:34 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:25:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:25:34 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:25:34 --> Final output sent to browser
DEBUG - 2024-02-27 23:25:34 --> Total execution time: 0.0342
ERROR - 2024-02-27 23:25:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:25:35 --> Config Class Initialized
INFO - 2024-02-27 23:25:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:25:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:25:35 --> Utf8 Class Initialized
INFO - 2024-02-27 23:25:35 --> URI Class Initialized
INFO - 2024-02-27 23:25:35 --> Router Class Initialized
INFO - 2024-02-27 23:25:35 --> Output Class Initialized
INFO - 2024-02-27 23:25:35 --> Security Class Initialized
DEBUG - 2024-02-27 23:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:25:35 --> Input Class Initialized
INFO - 2024-02-27 23:25:35 --> Language Class Initialized
INFO - 2024-02-27 23:25:35 --> Loader Class Initialized
INFO - 2024-02-27 23:25:35 --> Helper loaded: url_helper
INFO - 2024-02-27 23:25:35 --> Helper loaded: file_helper
INFO - 2024-02-27 23:25:35 --> Helper loaded: form_helper
INFO - 2024-02-27 23:25:35 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:25:35 --> Controller Class Initialized
INFO - 2024-02-27 23:25:35 --> Form Validation Class Initialized
INFO - 2024-02-27 23:25:35 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:25:35 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:25:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:25:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:25:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:25:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:25:35 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:25:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:25:35 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:26:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:26:25 --> Config Class Initialized
INFO - 2024-02-27 23:26:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:26:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:26:25 --> Utf8 Class Initialized
INFO - 2024-02-27 23:26:25 --> URI Class Initialized
INFO - 2024-02-27 23:26:25 --> Router Class Initialized
INFO - 2024-02-27 23:26:25 --> Output Class Initialized
INFO - 2024-02-27 23:26:25 --> Security Class Initialized
DEBUG - 2024-02-27 23:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:26:25 --> Input Class Initialized
INFO - 2024-02-27 23:26:25 --> Language Class Initialized
INFO - 2024-02-27 23:26:25 --> Loader Class Initialized
INFO - 2024-02-27 23:26:25 --> Helper loaded: url_helper
INFO - 2024-02-27 23:26:25 --> Helper loaded: file_helper
INFO - 2024-02-27 23:26:25 --> Helper loaded: form_helper
INFO - 2024-02-27 23:26:25 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:26:25 --> Controller Class Initialized
INFO - 2024-02-27 23:26:25 --> Form Validation Class Initialized
INFO - 2024-02-27 23:26:25 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:26:25 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:26:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:26:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:26:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:26:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:26:25 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:26:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:26:25 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:26:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:26:35 --> Config Class Initialized
INFO - 2024-02-27 23:26:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:26:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:26:35 --> Utf8 Class Initialized
INFO - 2024-02-27 23:26:35 --> URI Class Initialized
INFO - 2024-02-27 23:26:35 --> Router Class Initialized
INFO - 2024-02-27 23:26:35 --> Output Class Initialized
INFO - 2024-02-27 23:26:35 --> Security Class Initialized
DEBUG - 2024-02-27 23:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:26:35 --> Input Class Initialized
INFO - 2024-02-27 23:26:35 --> Language Class Initialized
INFO - 2024-02-27 23:26:35 --> Loader Class Initialized
INFO - 2024-02-27 23:26:35 --> Helper loaded: url_helper
INFO - 2024-02-27 23:26:35 --> Helper loaded: file_helper
INFO - 2024-02-27 23:26:35 --> Helper loaded: form_helper
INFO - 2024-02-27 23:26:35 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:26:35 --> Controller Class Initialized
INFO - 2024-02-27 23:26:35 --> Form Validation Class Initialized
INFO - 2024-02-27 23:26:35 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:26:35 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:26:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:26:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:26:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:26:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:26:35 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:26:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:26:35 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:32:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:32:38 --> Config Class Initialized
INFO - 2024-02-27 23:32:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:32:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:32:38 --> Utf8 Class Initialized
INFO - 2024-02-27 23:32:38 --> URI Class Initialized
INFO - 2024-02-27 23:32:38 --> Router Class Initialized
INFO - 2024-02-27 23:32:38 --> Output Class Initialized
INFO - 2024-02-27 23:32:38 --> Security Class Initialized
DEBUG - 2024-02-27 23:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:32:38 --> Input Class Initialized
INFO - 2024-02-27 23:32:38 --> Language Class Initialized
INFO - 2024-02-27 23:32:38 --> Loader Class Initialized
INFO - 2024-02-27 23:32:38 --> Helper loaded: url_helper
INFO - 2024-02-27 23:32:38 --> Helper loaded: file_helper
INFO - 2024-02-27 23:32:38 --> Helper loaded: form_helper
INFO - 2024-02-27 23:32:38 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:32:38 --> Controller Class Initialized
INFO - 2024-02-27 23:32:38 --> Form Validation Class Initialized
INFO - 2024-02-27 23:32:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:32:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:32:38 --> Config Class Initialized
INFO - 2024-02-27 23:32:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:32:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:32:38 --> Utf8 Class Initialized
INFO - 2024-02-27 23:32:38 --> URI Class Initialized
INFO - 2024-02-27 23:32:38 --> Router Class Initialized
INFO - 2024-02-27 23:32:38 --> Output Class Initialized
INFO - 2024-02-27 23:32:38 --> Security Class Initialized
DEBUG - 2024-02-27 23:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:32:38 --> Input Class Initialized
INFO - 2024-02-27 23:32:38 --> Language Class Initialized
INFO - 2024-02-27 23:32:38 --> Loader Class Initialized
INFO - 2024-02-27 23:32:38 --> Helper loaded: url_helper
INFO - 2024-02-27 23:32:38 --> Helper loaded: file_helper
INFO - 2024-02-27 23:32:38 --> Helper loaded: form_helper
INFO - 2024-02-27 23:32:38 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:32:38 --> Controller Class Initialized
INFO - 2024-02-27 23:32:38 --> Form Validation Class Initialized
INFO - 2024-02-27 23:32:38 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:32:38 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:32:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:32:44 --> Config Class Initialized
INFO - 2024-02-27 23:32:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:32:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:32:44 --> Utf8 Class Initialized
INFO - 2024-02-27 23:32:44 --> URI Class Initialized
INFO - 2024-02-27 23:32:44 --> Router Class Initialized
INFO - 2024-02-27 23:32:44 --> Output Class Initialized
INFO - 2024-02-27 23:32:44 --> Security Class Initialized
DEBUG - 2024-02-27 23:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:32:44 --> Input Class Initialized
INFO - 2024-02-27 23:32:44 --> Language Class Initialized
INFO - 2024-02-27 23:32:44 --> Loader Class Initialized
INFO - 2024-02-27 23:32:44 --> Helper loaded: url_helper
INFO - 2024-02-27 23:32:44 --> Helper loaded: file_helper
INFO - 2024-02-27 23:32:44 --> Helper loaded: form_helper
INFO - 2024-02-27 23:32:44 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:32:44 --> Controller Class Initialized
INFO - 2024-02-27 23:32:44 --> Form Validation Class Initialized
INFO - 2024-02-27 23:32:44 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:32:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:32:44 --> Config Class Initialized
INFO - 2024-02-27 23:32:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:32:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:32:44 --> Utf8 Class Initialized
INFO - 2024-02-27 23:32:44 --> URI Class Initialized
INFO - 2024-02-27 23:32:44 --> Router Class Initialized
INFO - 2024-02-27 23:32:44 --> Output Class Initialized
INFO - 2024-02-27 23:32:44 --> Security Class Initialized
DEBUG - 2024-02-27 23:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:32:44 --> Input Class Initialized
INFO - 2024-02-27 23:32:44 --> Language Class Initialized
INFO - 2024-02-27 23:32:44 --> Loader Class Initialized
INFO - 2024-02-27 23:32:44 --> Helper loaded: url_helper
INFO - 2024-02-27 23:32:44 --> Helper loaded: file_helper
INFO - 2024-02-27 23:32:44 --> Helper loaded: form_helper
INFO - 2024-02-27 23:32:44 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:32:44 --> Controller Class Initialized
INFO - 2024-02-27 23:32:44 --> Form Validation Class Initialized
INFO - 2024-02-27 23:32:44 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:32:44 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:32:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:32:48 --> Config Class Initialized
INFO - 2024-02-27 23:32:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:32:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:32:48 --> Utf8 Class Initialized
INFO - 2024-02-27 23:32:48 --> URI Class Initialized
INFO - 2024-02-27 23:32:48 --> Router Class Initialized
INFO - 2024-02-27 23:32:48 --> Output Class Initialized
INFO - 2024-02-27 23:32:48 --> Security Class Initialized
DEBUG - 2024-02-27 23:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:32:48 --> Input Class Initialized
INFO - 2024-02-27 23:32:48 --> Language Class Initialized
INFO - 2024-02-27 23:32:48 --> Loader Class Initialized
INFO - 2024-02-27 23:32:48 --> Helper loaded: url_helper
INFO - 2024-02-27 23:32:48 --> Helper loaded: file_helper
INFO - 2024-02-27 23:32:48 --> Helper loaded: form_helper
INFO - 2024-02-27 23:32:48 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:32:48 --> Controller Class Initialized
INFO - 2024-02-27 23:32:48 --> Form Validation Class Initialized
INFO - 2024-02-27 23:32:48 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:32:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:32:48 --> Config Class Initialized
INFO - 2024-02-27 23:32:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:32:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:32:48 --> Utf8 Class Initialized
INFO - 2024-02-27 23:32:48 --> URI Class Initialized
INFO - 2024-02-27 23:32:48 --> Router Class Initialized
INFO - 2024-02-27 23:32:48 --> Output Class Initialized
INFO - 2024-02-27 23:32:48 --> Security Class Initialized
DEBUG - 2024-02-27 23:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:32:48 --> Input Class Initialized
INFO - 2024-02-27 23:32:48 --> Language Class Initialized
INFO - 2024-02-27 23:32:48 --> Loader Class Initialized
INFO - 2024-02-27 23:32:48 --> Helper loaded: url_helper
INFO - 2024-02-27 23:32:48 --> Helper loaded: file_helper
INFO - 2024-02-27 23:32:48 --> Helper loaded: form_helper
INFO - 2024-02-27 23:32:48 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:32:48 --> Controller Class Initialized
INFO - 2024-02-27 23:32:48 --> Form Validation Class Initialized
INFO - 2024-02-27 23:32:48 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:32:48 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:32:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:32:54 --> Config Class Initialized
INFO - 2024-02-27 23:32:54 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:32:54 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:32:54 --> Utf8 Class Initialized
INFO - 2024-02-27 23:32:54 --> URI Class Initialized
INFO - 2024-02-27 23:32:54 --> Router Class Initialized
INFO - 2024-02-27 23:32:54 --> Output Class Initialized
INFO - 2024-02-27 23:32:54 --> Security Class Initialized
DEBUG - 2024-02-27 23:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:32:54 --> Input Class Initialized
INFO - 2024-02-27 23:32:54 --> Language Class Initialized
INFO - 2024-02-27 23:32:54 --> Loader Class Initialized
INFO - 2024-02-27 23:32:54 --> Helper loaded: url_helper
INFO - 2024-02-27 23:32:54 --> Helper loaded: file_helper
INFO - 2024-02-27 23:32:54 --> Helper loaded: form_helper
INFO - 2024-02-27 23:32:54 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:32:54 --> Controller Class Initialized
INFO - 2024-02-27 23:32:54 --> Form Validation Class Initialized
INFO - 2024-02-27 23:32:54 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:32:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:32:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:32:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:32:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:32:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:32:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:32:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:32:54 --> Final output sent to browser
DEBUG - 2024-02-27 23:32:54 --> Total execution time: 0.0360
ERROR - 2024-02-27 23:32:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:32:54 --> Config Class Initialized
INFO - 2024-02-27 23:32:54 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:32:54 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:32:54 --> Utf8 Class Initialized
INFO - 2024-02-27 23:32:54 --> URI Class Initialized
INFO - 2024-02-27 23:32:54 --> Router Class Initialized
INFO - 2024-02-27 23:32:54 --> Output Class Initialized
INFO - 2024-02-27 23:32:54 --> Security Class Initialized
DEBUG - 2024-02-27 23:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:32:54 --> Input Class Initialized
INFO - 2024-02-27 23:32:54 --> Language Class Initialized
INFO - 2024-02-27 23:32:54 --> Loader Class Initialized
INFO - 2024-02-27 23:32:54 --> Helper loaded: url_helper
INFO - 2024-02-27 23:32:54 --> Helper loaded: file_helper
INFO - 2024-02-27 23:32:54 --> Helper loaded: form_helper
INFO - 2024-02-27 23:32:54 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:32:54 --> Controller Class Initialized
INFO - 2024-02-27 23:32:54 --> Form Validation Class Initialized
INFO - 2024-02-27 23:32:54 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:32:54 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:40:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:09 --> Config Class Initialized
INFO - 2024-02-27 23:40:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:09 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:09 --> URI Class Initialized
INFO - 2024-02-27 23:40:09 --> Router Class Initialized
INFO - 2024-02-27 23:40:09 --> Output Class Initialized
INFO - 2024-02-27 23:40:09 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:09 --> Input Class Initialized
INFO - 2024-02-27 23:40:09 --> Language Class Initialized
INFO - 2024-02-27 23:40:09 --> Loader Class Initialized
INFO - 2024-02-27 23:40:09 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:09 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:09 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:09 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:09 --> Controller Class Initialized
INFO - 2024-02-27 23:40:09 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:09 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:09 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:09 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:09 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:40:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:40:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:40:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:40:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:40:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:40:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:40:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:40:09 --> Final output sent to browser
DEBUG - 2024-02-27 23:40:09 --> Total execution time: 0.0324
ERROR - 2024-02-27 23:40:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:10 --> Config Class Initialized
INFO - 2024-02-27 23:40:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:10 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:10 --> URI Class Initialized
INFO - 2024-02-27 23:40:10 --> Router Class Initialized
INFO - 2024-02-27 23:40:10 --> Output Class Initialized
INFO - 2024-02-27 23:40:10 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:10 --> Input Class Initialized
INFO - 2024-02-27 23:40:10 --> Language Class Initialized
INFO - 2024-02-27 23:40:10 --> Loader Class Initialized
INFO - 2024-02-27 23:40:10 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:10 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:10 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:10 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:10 --> Controller Class Initialized
INFO - 2024-02-27 23:40:10 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:10 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:10 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:10 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:10 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:40:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:15 --> Config Class Initialized
INFO - 2024-02-27 23:40:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:15 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:15 --> URI Class Initialized
INFO - 2024-02-27 23:40:15 --> Router Class Initialized
INFO - 2024-02-27 23:40:15 --> Output Class Initialized
INFO - 2024-02-27 23:40:15 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:15 --> Input Class Initialized
INFO - 2024-02-27 23:40:15 --> Language Class Initialized
INFO - 2024-02-27 23:40:15 --> Loader Class Initialized
INFO - 2024-02-27 23:40:15 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:15 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:15 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:15 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:15 --> Controller Class Initialized
INFO - 2024-02-27 23:40:15 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:15 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:15 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:15 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:15 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:40:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:35 --> Config Class Initialized
INFO - 2024-02-27 23:40:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:35 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:35 --> URI Class Initialized
INFO - 2024-02-27 23:40:35 --> Router Class Initialized
INFO - 2024-02-27 23:40:35 --> Output Class Initialized
INFO - 2024-02-27 23:40:35 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:35 --> Input Class Initialized
INFO - 2024-02-27 23:40:35 --> Language Class Initialized
INFO - 2024-02-27 23:40:35 --> Loader Class Initialized
INFO - 2024-02-27 23:40:35 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:35 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:35 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:35 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:35 --> Controller Class Initialized
INFO - 2024-02-27 23:40:35 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:35 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:40:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:40:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:40:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:40:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:40:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:40:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:40:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:40:35 --> Final output sent to browser
DEBUG - 2024-02-27 23:40:35 --> Total execution time: 0.0312
ERROR - 2024-02-27 23:40:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:35 --> Config Class Initialized
INFO - 2024-02-27 23:40:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:35 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:35 --> URI Class Initialized
INFO - 2024-02-27 23:40:35 --> Router Class Initialized
INFO - 2024-02-27 23:40:35 --> Output Class Initialized
INFO - 2024-02-27 23:40:35 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:35 --> Input Class Initialized
INFO - 2024-02-27 23:40:35 --> Language Class Initialized
INFO - 2024-02-27 23:40:35 --> Loader Class Initialized
INFO - 2024-02-27 23:40:35 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:35 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:35 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:35 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:35 --> Controller Class Initialized
INFO - 2024-02-27 23:40:35 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:35 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:35 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:39 --> Config Class Initialized
INFO - 2024-02-27 23:40:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:39 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:39 --> URI Class Initialized
INFO - 2024-02-27 23:40:39 --> Router Class Initialized
INFO - 2024-02-27 23:40:39 --> Output Class Initialized
INFO - 2024-02-27 23:40:39 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:39 --> Input Class Initialized
INFO - 2024-02-27 23:40:39 --> Language Class Initialized
INFO - 2024-02-27 23:40:39 --> Loader Class Initialized
INFO - 2024-02-27 23:40:39 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:39 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:39 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:39 --> Controller Class Initialized
INFO - 2024-02-27 23:40:39 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:39 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:40:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:42 --> Config Class Initialized
INFO - 2024-02-27 23:40:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:42 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:42 --> URI Class Initialized
INFO - 2024-02-27 23:40:42 --> Router Class Initialized
INFO - 2024-02-27 23:40:42 --> Output Class Initialized
INFO - 2024-02-27 23:40:42 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:42 --> Input Class Initialized
INFO - 2024-02-27 23:40:42 --> Language Class Initialized
INFO - 2024-02-27 23:40:42 --> Loader Class Initialized
INFO - 2024-02-27 23:40:42 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:42 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:42 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:42 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:42 --> Controller Class Initialized
INFO - 2024-02-27 23:40:42 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:42 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:42 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:42 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:42 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:40:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:45 --> Config Class Initialized
INFO - 2024-02-27 23:40:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:45 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:45 --> URI Class Initialized
INFO - 2024-02-27 23:40:45 --> Router Class Initialized
INFO - 2024-02-27 23:40:45 --> Output Class Initialized
INFO - 2024-02-27 23:40:45 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:45 --> Input Class Initialized
INFO - 2024-02-27 23:40:45 --> Language Class Initialized
INFO - 2024-02-27 23:40:45 --> Loader Class Initialized
INFO - 2024-02-27 23:40:45 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:45 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:45 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:45 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:45 --> Controller Class Initialized
INFO - 2024-02-27 23:40:45 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:45 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:45 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:45 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:45 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:40:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:48 --> Config Class Initialized
INFO - 2024-02-27 23:40:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:48 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:48 --> URI Class Initialized
INFO - 2024-02-27 23:40:48 --> Router Class Initialized
INFO - 2024-02-27 23:40:48 --> Output Class Initialized
INFO - 2024-02-27 23:40:48 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:48 --> Input Class Initialized
INFO - 2024-02-27 23:40:48 --> Language Class Initialized
INFO - 2024-02-27 23:40:48 --> Loader Class Initialized
INFO - 2024-02-27 23:40:48 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:48 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:48 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:49 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:49 --> Controller Class Initialized
INFO - 2024-02-27 23:40:49 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:49 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:49 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:49 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:49 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:40:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:51 --> Config Class Initialized
INFO - 2024-02-27 23:40:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:51 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:51 --> URI Class Initialized
INFO - 2024-02-27 23:40:51 --> Router Class Initialized
INFO - 2024-02-27 23:40:51 --> Output Class Initialized
INFO - 2024-02-27 23:40:51 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:51 --> Input Class Initialized
INFO - 2024-02-27 23:40:51 --> Language Class Initialized
INFO - 2024-02-27 23:40:51 --> Loader Class Initialized
INFO - 2024-02-27 23:40:51 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:51 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:51 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:51 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:51 --> Controller Class Initialized
INFO - 2024-02-27 23:40:51 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:51 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:51 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:51 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:51 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:40:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:52 --> Config Class Initialized
INFO - 2024-02-27 23:40:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:53 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:53 --> URI Class Initialized
INFO - 2024-02-27 23:40:53 --> Router Class Initialized
INFO - 2024-02-27 23:40:53 --> Output Class Initialized
INFO - 2024-02-27 23:40:53 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:53 --> Input Class Initialized
INFO - 2024-02-27 23:40:53 --> Language Class Initialized
INFO - 2024-02-27 23:40:53 --> Loader Class Initialized
INFO - 2024-02-27 23:40:53 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:53 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:53 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:53 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:53 --> Controller Class Initialized
INFO - 2024-02-27 23:40:53 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:53 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:53 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:53 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:53 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:53 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:53 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:53 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:40:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:55 --> Config Class Initialized
INFO - 2024-02-27 23:40:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:55 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:55 --> URI Class Initialized
INFO - 2024-02-27 23:40:55 --> Router Class Initialized
INFO - 2024-02-27 23:40:55 --> Output Class Initialized
INFO - 2024-02-27 23:40:55 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:55 --> Input Class Initialized
INFO - 2024-02-27 23:40:55 --> Language Class Initialized
INFO - 2024-02-27 23:40:55 --> Loader Class Initialized
INFO - 2024-02-27 23:40:55 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:55 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:55 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:55 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:55 --> Controller Class Initialized
INFO - 2024-02-27 23:40:55 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:55 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:55 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:55 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:55 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:40:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:40:58 --> Config Class Initialized
INFO - 2024-02-27 23:40:58 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:40:58 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:40:58 --> Utf8 Class Initialized
INFO - 2024-02-27 23:40:58 --> URI Class Initialized
INFO - 2024-02-27 23:40:58 --> Router Class Initialized
INFO - 2024-02-27 23:40:58 --> Output Class Initialized
INFO - 2024-02-27 23:40:58 --> Security Class Initialized
DEBUG - 2024-02-27 23:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:40:58 --> Input Class Initialized
INFO - 2024-02-27 23:40:58 --> Language Class Initialized
INFO - 2024-02-27 23:40:58 --> Loader Class Initialized
INFO - 2024-02-27 23:40:58 --> Helper loaded: url_helper
INFO - 2024-02-27 23:40:58 --> Helper loaded: file_helper
INFO - 2024-02-27 23:40:58 --> Helper loaded: form_helper
INFO - 2024-02-27 23:40:58 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:40:58 --> Controller Class Initialized
INFO - 2024-02-27 23:40:58 --> Form Validation Class Initialized
INFO - 2024-02-27 23:40:58 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:40:58 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:40:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:40:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:40:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:40:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:40:58 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:40:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:40:58 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:41:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:41:02 --> Config Class Initialized
INFO - 2024-02-27 23:41:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:41:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:41:02 --> Utf8 Class Initialized
INFO - 2024-02-27 23:41:02 --> URI Class Initialized
INFO - 2024-02-27 23:41:02 --> Router Class Initialized
INFO - 2024-02-27 23:41:02 --> Output Class Initialized
INFO - 2024-02-27 23:41:02 --> Security Class Initialized
DEBUG - 2024-02-27 23:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:41:02 --> Input Class Initialized
INFO - 2024-02-27 23:41:02 --> Language Class Initialized
INFO - 2024-02-27 23:41:02 --> Loader Class Initialized
INFO - 2024-02-27 23:41:02 --> Helper loaded: url_helper
INFO - 2024-02-27 23:41:02 --> Helper loaded: file_helper
INFO - 2024-02-27 23:41:02 --> Helper loaded: form_helper
INFO - 2024-02-27 23:41:02 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:41:02 --> Controller Class Initialized
INFO - 2024-02-27 23:41:02 --> Form Validation Class Initialized
INFO - 2024-02-27 23:41:02 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:41:02 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:41:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:41:02 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:41:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:41:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:41:02 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:41:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:41:02 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:43:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:43:51 --> Config Class Initialized
INFO - 2024-02-27 23:43:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:43:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:43:51 --> Utf8 Class Initialized
INFO - 2024-02-27 23:43:51 --> URI Class Initialized
INFO - 2024-02-27 23:43:51 --> Router Class Initialized
INFO - 2024-02-27 23:43:51 --> Output Class Initialized
INFO - 2024-02-27 23:43:51 --> Security Class Initialized
DEBUG - 2024-02-27 23:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:43:51 --> Input Class Initialized
INFO - 2024-02-27 23:43:51 --> Language Class Initialized
INFO - 2024-02-27 23:43:51 --> Loader Class Initialized
INFO - 2024-02-27 23:43:51 --> Helper loaded: url_helper
INFO - 2024-02-27 23:43:51 --> Helper loaded: file_helper
INFO - 2024-02-27 23:43:51 --> Helper loaded: form_helper
INFO - 2024-02-27 23:43:51 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:43:51 --> Controller Class Initialized
INFO - 2024-02-27 23:43:51 --> Form Validation Class Initialized
INFO - 2024-02-27 23:43:51 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:43:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:43:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:43:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:43:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:43:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:43:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:43:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:43:51 --> Final output sent to browser
DEBUG - 2024-02-27 23:43:51 --> Total execution time: 0.0303
ERROR - 2024-02-27 23:43:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:43:51 --> Config Class Initialized
INFO - 2024-02-27 23:43:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:43:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:43:51 --> Utf8 Class Initialized
INFO - 2024-02-27 23:43:51 --> URI Class Initialized
INFO - 2024-02-27 23:43:51 --> Router Class Initialized
INFO - 2024-02-27 23:43:51 --> Output Class Initialized
INFO - 2024-02-27 23:43:51 --> Security Class Initialized
DEBUG - 2024-02-27 23:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:43:51 --> Input Class Initialized
INFO - 2024-02-27 23:43:51 --> Language Class Initialized
INFO - 2024-02-27 23:43:51 --> Loader Class Initialized
INFO - 2024-02-27 23:43:51 --> Helper loaded: url_helper
INFO - 2024-02-27 23:43:51 --> Helper loaded: file_helper
INFO - 2024-02-27 23:43:51 --> Helper loaded: form_helper
INFO - 2024-02-27 23:43:51 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:43:51 --> Controller Class Initialized
INFO - 2024-02-27 23:43:51 --> Form Validation Class Initialized
INFO - 2024-02-27 23:43:51 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:43:51 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:44:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:44:39 --> Config Class Initialized
INFO - 2024-02-27 23:44:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:44:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:44:39 --> Utf8 Class Initialized
INFO - 2024-02-27 23:44:39 --> URI Class Initialized
INFO - 2024-02-27 23:44:39 --> Router Class Initialized
INFO - 2024-02-27 23:44:39 --> Output Class Initialized
INFO - 2024-02-27 23:44:39 --> Security Class Initialized
DEBUG - 2024-02-27 23:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:44:39 --> Input Class Initialized
INFO - 2024-02-27 23:44:39 --> Language Class Initialized
INFO - 2024-02-27 23:44:39 --> Loader Class Initialized
INFO - 2024-02-27 23:44:39 --> Helper loaded: url_helper
INFO - 2024-02-27 23:44:39 --> Helper loaded: file_helper
INFO - 2024-02-27 23:44:39 --> Helper loaded: form_helper
INFO - 2024-02-27 23:44:39 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:44:39 --> Controller Class Initialized
INFO - 2024-02-27 23:44:39 --> Form Validation Class Initialized
INFO - 2024-02-27 23:44:39 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:44:39 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:44:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:44:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:44:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:44:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:44:39 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:44:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:44:39 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:44:39 --> Final output sent to browser
DEBUG - 2024-02-27 23:44:39 --> Total execution time: 0.0349
ERROR - 2024-02-27 23:44:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:44:40 --> Config Class Initialized
INFO - 2024-02-27 23:44:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:44:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:44:40 --> Utf8 Class Initialized
INFO - 2024-02-27 23:44:40 --> URI Class Initialized
INFO - 2024-02-27 23:44:40 --> Router Class Initialized
INFO - 2024-02-27 23:44:40 --> Output Class Initialized
INFO - 2024-02-27 23:44:40 --> Security Class Initialized
DEBUG - 2024-02-27 23:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:44:40 --> Input Class Initialized
INFO - 2024-02-27 23:44:40 --> Language Class Initialized
INFO - 2024-02-27 23:44:40 --> Loader Class Initialized
INFO - 2024-02-27 23:44:40 --> Helper loaded: url_helper
INFO - 2024-02-27 23:44:40 --> Helper loaded: file_helper
INFO - 2024-02-27 23:44:40 --> Helper loaded: form_helper
INFO - 2024-02-27 23:44:40 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:44:40 --> Controller Class Initialized
INFO - 2024-02-27 23:44:40 --> Form Validation Class Initialized
INFO - 2024-02-27 23:44:40 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:44:40 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:44:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:44:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:44:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:44:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:44:40 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:44:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:44:40 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:44:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:44:45 --> Config Class Initialized
INFO - 2024-02-27 23:44:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:44:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:44:45 --> Utf8 Class Initialized
INFO - 2024-02-27 23:44:45 --> URI Class Initialized
INFO - 2024-02-27 23:44:45 --> Router Class Initialized
INFO - 2024-02-27 23:44:45 --> Output Class Initialized
INFO - 2024-02-27 23:44:45 --> Security Class Initialized
DEBUG - 2024-02-27 23:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:44:45 --> Input Class Initialized
INFO - 2024-02-27 23:44:45 --> Language Class Initialized
INFO - 2024-02-27 23:44:45 --> Loader Class Initialized
INFO - 2024-02-27 23:44:45 --> Helper loaded: url_helper
INFO - 2024-02-27 23:44:45 --> Helper loaded: file_helper
INFO - 2024-02-27 23:44:45 --> Helper loaded: form_helper
INFO - 2024-02-27 23:44:45 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:44:45 --> Controller Class Initialized
INFO - 2024-02-27 23:44:45 --> Form Validation Class Initialized
INFO - 2024-02-27 23:44:45 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:44:45 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:44:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:44:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:44:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:44:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:44:45 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:44:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:44:45 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:44:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:44:48 --> Config Class Initialized
INFO - 2024-02-27 23:44:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:44:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:44:48 --> Utf8 Class Initialized
INFO - 2024-02-27 23:44:48 --> URI Class Initialized
INFO - 2024-02-27 23:44:48 --> Router Class Initialized
INFO - 2024-02-27 23:44:48 --> Output Class Initialized
INFO - 2024-02-27 23:44:48 --> Security Class Initialized
DEBUG - 2024-02-27 23:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:44:48 --> Input Class Initialized
INFO - 2024-02-27 23:44:48 --> Language Class Initialized
INFO - 2024-02-27 23:44:48 --> Loader Class Initialized
INFO - 2024-02-27 23:44:48 --> Helper loaded: url_helper
INFO - 2024-02-27 23:44:48 --> Helper loaded: file_helper
INFO - 2024-02-27 23:44:48 --> Helper loaded: form_helper
INFO - 2024-02-27 23:44:48 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:44:48 --> Controller Class Initialized
INFO - 2024-02-27 23:44:48 --> Form Validation Class Initialized
INFO - 2024-02-27 23:44:48 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:44:48 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:44:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:44:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:44:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:44:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:44:48 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:44:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:44:48 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:44:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:44:51 --> Config Class Initialized
INFO - 2024-02-27 23:44:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:44:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:44:51 --> Utf8 Class Initialized
INFO - 2024-02-27 23:44:51 --> URI Class Initialized
INFO - 2024-02-27 23:44:51 --> Router Class Initialized
INFO - 2024-02-27 23:44:51 --> Output Class Initialized
INFO - 2024-02-27 23:44:51 --> Security Class Initialized
DEBUG - 2024-02-27 23:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:44:51 --> Input Class Initialized
INFO - 2024-02-27 23:44:51 --> Language Class Initialized
INFO - 2024-02-27 23:44:51 --> Loader Class Initialized
INFO - 2024-02-27 23:44:51 --> Helper loaded: url_helper
INFO - 2024-02-27 23:44:51 --> Helper loaded: file_helper
INFO - 2024-02-27 23:44:51 --> Helper loaded: form_helper
INFO - 2024-02-27 23:44:51 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:44:51 --> Controller Class Initialized
INFO - 2024-02-27 23:44:51 --> Form Validation Class Initialized
INFO - 2024-02-27 23:44:51 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:44:51 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:44:51 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:44:51 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:44:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:44:51 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:44:51 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:44:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:44:51 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:44:56 --> Config Class Initialized
INFO - 2024-02-27 23:44:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:44:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:44:56 --> Utf8 Class Initialized
INFO - 2024-02-27 23:44:56 --> URI Class Initialized
INFO - 2024-02-27 23:44:56 --> Router Class Initialized
INFO - 2024-02-27 23:44:56 --> Output Class Initialized
INFO - 2024-02-27 23:44:56 --> Security Class Initialized
DEBUG - 2024-02-27 23:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:44:56 --> Input Class Initialized
INFO - 2024-02-27 23:44:56 --> Language Class Initialized
INFO - 2024-02-27 23:44:56 --> Loader Class Initialized
INFO - 2024-02-27 23:44:56 --> Helper loaded: url_helper
INFO - 2024-02-27 23:44:56 --> Helper loaded: file_helper
INFO - 2024-02-27 23:44:56 --> Helper loaded: form_helper
INFO - 2024-02-27 23:44:56 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:44:56 --> Controller Class Initialized
INFO - 2024-02-27 23:44:56 --> Form Validation Class Initialized
INFO - 2024-02-27 23:44:56 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:44:56 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:44:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:44:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:44:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:44:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:44:56 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:44:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:44:56 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:44:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:44:59 --> Config Class Initialized
INFO - 2024-02-27 23:44:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:44:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:44:59 --> Utf8 Class Initialized
INFO - 2024-02-27 23:44:59 --> URI Class Initialized
INFO - 2024-02-27 23:44:59 --> Router Class Initialized
INFO - 2024-02-27 23:44:59 --> Output Class Initialized
INFO - 2024-02-27 23:44:59 --> Security Class Initialized
DEBUG - 2024-02-27 23:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:44:59 --> Input Class Initialized
INFO - 2024-02-27 23:44:59 --> Language Class Initialized
INFO - 2024-02-27 23:44:59 --> Loader Class Initialized
INFO - 2024-02-27 23:44:59 --> Helper loaded: url_helper
INFO - 2024-02-27 23:44:59 --> Helper loaded: file_helper
INFO - 2024-02-27 23:44:59 --> Helper loaded: form_helper
INFO - 2024-02-27 23:44:59 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:44:59 --> Controller Class Initialized
INFO - 2024-02-27 23:44:59 --> Form Validation Class Initialized
INFO - 2024-02-27 23:44:59 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:44:59 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:44:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:44:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:44:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:44:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:44:59 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:44:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:44:59 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:45:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:45:01 --> Config Class Initialized
INFO - 2024-02-27 23:45:01 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:45:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:45:01 --> Utf8 Class Initialized
INFO - 2024-02-27 23:45:01 --> URI Class Initialized
INFO - 2024-02-27 23:45:01 --> Router Class Initialized
INFO - 2024-02-27 23:45:01 --> Output Class Initialized
INFO - 2024-02-27 23:45:01 --> Security Class Initialized
DEBUG - 2024-02-27 23:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:45:01 --> Input Class Initialized
INFO - 2024-02-27 23:45:01 --> Language Class Initialized
INFO - 2024-02-27 23:45:01 --> Loader Class Initialized
INFO - 2024-02-27 23:45:01 --> Helper loaded: url_helper
INFO - 2024-02-27 23:45:01 --> Helper loaded: file_helper
INFO - 2024-02-27 23:45:01 --> Helper loaded: form_helper
INFO - 2024-02-27 23:45:01 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:45:01 --> Controller Class Initialized
INFO - 2024-02-27 23:45:01 --> Form Validation Class Initialized
INFO - 2024-02-27 23:45:01 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:45:01 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:45:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:45:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:45:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:45:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:45:01 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:45:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:45:01 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:45:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:45:07 --> Config Class Initialized
INFO - 2024-02-27 23:45:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:45:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:45:07 --> Utf8 Class Initialized
INFO - 2024-02-27 23:45:07 --> URI Class Initialized
INFO - 2024-02-27 23:45:07 --> Router Class Initialized
INFO - 2024-02-27 23:45:07 --> Output Class Initialized
INFO - 2024-02-27 23:45:07 --> Security Class Initialized
DEBUG - 2024-02-27 23:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:45:07 --> Input Class Initialized
INFO - 2024-02-27 23:45:07 --> Language Class Initialized
INFO - 2024-02-27 23:45:07 --> Loader Class Initialized
INFO - 2024-02-27 23:45:07 --> Helper loaded: url_helper
INFO - 2024-02-27 23:45:07 --> Helper loaded: file_helper
INFO - 2024-02-27 23:45:07 --> Helper loaded: form_helper
INFO - 2024-02-27 23:45:07 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:45:07 --> Controller Class Initialized
INFO - 2024-02-27 23:45:07 --> Form Validation Class Initialized
INFO - 2024-02-27 23:45:07 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:45:07 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:45:07 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:45:07 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:45:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:45:07 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:45:07 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:45:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:45:07 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:45:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:45:12 --> Config Class Initialized
INFO - 2024-02-27 23:45:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:45:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:45:12 --> Utf8 Class Initialized
INFO - 2024-02-27 23:45:12 --> URI Class Initialized
INFO - 2024-02-27 23:45:12 --> Router Class Initialized
INFO - 2024-02-27 23:45:12 --> Output Class Initialized
INFO - 2024-02-27 23:45:12 --> Security Class Initialized
DEBUG - 2024-02-27 23:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:45:12 --> Input Class Initialized
INFO - 2024-02-27 23:45:12 --> Language Class Initialized
INFO - 2024-02-27 23:45:12 --> Loader Class Initialized
INFO - 2024-02-27 23:45:12 --> Helper loaded: url_helper
INFO - 2024-02-27 23:45:12 --> Helper loaded: file_helper
INFO - 2024-02-27 23:45:12 --> Helper loaded: form_helper
INFO - 2024-02-27 23:45:12 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:45:12 --> Controller Class Initialized
INFO - 2024-02-27 23:45:12 --> Form Validation Class Initialized
INFO - 2024-02-27 23:45:12 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:45:12 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:45:12 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:45:12 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:45:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:45:12 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:45:12 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:45:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:45:12 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:45:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:45:22 --> Config Class Initialized
INFO - 2024-02-27 23:45:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:45:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:45:22 --> Utf8 Class Initialized
INFO - 2024-02-27 23:45:22 --> URI Class Initialized
INFO - 2024-02-27 23:45:22 --> Router Class Initialized
INFO - 2024-02-27 23:45:22 --> Output Class Initialized
INFO - 2024-02-27 23:45:22 --> Security Class Initialized
DEBUG - 2024-02-27 23:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:45:22 --> Input Class Initialized
INFO - 2024-02-27 23:45:22 --> Language Class Initialized
INFO - 2024-02-27 23:45:22 --> Loader Class Initialized
INFO - 2024-02-27 23:45:22 --> Helper loaded: url_helper
INFO - 2024-02-27 23:45:22 --> Helper loaded: file_helper
INFO - 2024-02-27 23:45:22 --> Helper loaded: form_helper
INFO - 2024-02-27 23:45:22 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:45:22 --> Controller Class Initialized
INFO - 2024-02-27 23:45:22 --> Form Validation Class Initialized
INFO - 2024-02-27 23:45:22 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:45:22 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:45:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:45:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:45:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:45:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:45:22 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:45:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:45:22 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:45:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/payment_voucher/form.php
INFO - 2024-02-27 23:45:22 --> Final output sent to browser
DEBUG - 2024-02-27 23:45:22 --> Total execution time: 0.0378
ERROR - 2024-02-27 23:45:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:45:27 --> Config Class Initialized
INFO - 2024-02-27 23:45:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:45:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:45:27 --> Utf8 Class Initialized
INFO - 2024-02-27 23:45:27 --> URI Class Initialized
INFO - 2024-02-27 23:45:27 --> Router Class Initialized
INFO - 2024-02-27 23:45:27 --> Output Class Initialized
INFO - 2024-02-27 23:45:27 --> Security Class Initialized
DEBUG - 2024-02-27 23:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:45:27 --> Input Class Initialized
INFO - 2024-02-27 23:45:27 --> Language Class Initialized
INFO - 2024-02-27 23:45:27 --> Loader Class Initialized
INFO - 2024-02-27 23:45:27 --> Helper loaded: url_helper
INFO - 2024-02-27 23:45:27 --> Helper loaded: file_helper
INFO - 2024-02-27 23:45:27 --> Helper loaded: form_helper
INFO - 2024-02-27 23:45:27 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:45:27 --> Controller Class Initialized
INFO - 2024-02-27 23:45:27 --> Form Validation Class Initialized
INFO - 2024-02-27 23:45:27 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:45:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:45:27 --> Config Class Initialized
INFO - 2024-02-27 23:45:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:45:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:45:27 --> Utf8 Class Initialized
INFO - 2024-02-27 23:45:27 --> URI Class Initialized
INFO - 2024-02-27 23:45:27 --> Router Class Initialized
INFO - 2024-02-27 23:45:27 --> Output Class Initialized
INFO - 2024-02-27 23:45:27 --> Security Class Initialized
DEBUG - 2024-02-27 23:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:45:27 --> Input Class Initialized
INFO - 2024-02-27 23:45:27 --> Language Class Initialized
INFO - 2024-02-27 23:45:27 --> Loader Class Initialized
INFO - 2024-02-27 23:45:27 --> Helper loaded: url_helper
INFO - 2024-02-27 23:45:27 --> Helper loaded: file_helper
INFO - 2024-02-27 23:45:27 --> Helper loaded: form_helper
INFO - 2024-02-27 23:45:27 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:45:27 --> Controller Class Initialized
INFO - 2024-02-27 23:45:27 --> Form Validation Class Initialized
INFO - 2024-02-27 23:45:27 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:45:27 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:45:32 --> Config Class Initialized
INFO - 2024-02-27 23:45:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:45:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:45:32 --> Utf8 Class Initialized
INFO - 2024-02-27 23:45:32 --> URI Class Initialized
INFO - 2024-02-27 23:45:32 --> Router Class Initialized
INFO - 2024-02-27 23:45:32 --> Output Class Initialized
INFO - 2024-02-27 23:45:32 --> Security Class Initialized
DEBUG - 2024-02-27 23:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:45:32 --> Input Class Initialized
INFO - 2024-02-27 23:45:32 --> Language Class Initialized
INFO - 2024-02-27 23:45:32 --> Loader Class Initialized
INFO - 2024-02-27 23:45:32 --> Helper loaded: url_helper
INFO - 2024-02-27 23:45:32 --> Helper loaded: file_helper
INFO - 2024-02-27 23:45:32 --> Helper loaded: form_helper
INFO - 2024-02-27 23:45:32 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:45:32 --> Controller Class Initialized
INFO - 2024-02-27 23:45:32 --> Form Validation Class Initialized
INFO - 2024-02-27 23:45:32 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:45:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:45:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:45:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:45:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:45:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:45:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:45:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:45:32 --> Final output sent to browser
DEBUG - 2024-02-27 23:45:32 --> Total execution time: 0.0440
ERROR - 2024-02-27 23:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:45:32 --> Config Class Initialized
INFO - 2024-02-27 23:45:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:45:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:45:32 --> Utf8 Class Initialized
INFO - 2024-02-27 23:45:32 --> URI Class Initialized
INFO - 2024-02-27 23:45:32 --> Router Class Initialized
INFO - 2024-02-27 23:45:32 --> Output Class Initialized
INFO - 2024-02-27 23:45:32 --> Security Class Initialized
DEBUG - 2024-02-27 23:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:45:32 --> Input Class Initialized
INFO - 2024-02-27 23:45:32 --> Language Class Initialized
INFO - 2024-02-27 23:45:32 --> Loader Class Initialized
INFO - 2024-02-27 23:45:32 --> Helper loaded: url_helper
INFO - 2024-02-27 23:45:32 --> Helper loaded: file_helper
INFO - 2024-02-27 23:45:32 --> Helper loaded: form_helper
INFO - 2024-02-27 23:45:32 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:45:32 --> Controller Class Initialized
INFO - 2024-02-27 23:45:32 --> Form Validation Class Initialized
INFO - 2024-02-27 23:45:32 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:45:32 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:45:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:45:50 --> Config Class Initialized
INFO - 2024-02-27 23:45:50 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:45:50 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:45:50 --> Utf8 Class Initialized
INFO - 2024-02-27 23:45:50 --> URI Class Initialized
INFO - 2024-02-27 23:45:50 --> Router Class Initialized
INFO - 2024-02-27 23:45:50 --> Output Class Initialized
INFO - 2024-02-27 23:45:50 --> Security Class Initialized
DEBUG - 2024-02-27 23:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:45:50 --> Input Class Initialized
INFO - 2024-02-27 23:45:50 --> Language Class Initialized
INFO - 2024-02-27 23:45:50 --> Loader Class Initialized
INFO - 2024-02-27 23:45:50 --> Helper loaded: url_helper
INFO - 2024-02-27 23:45:50 --> Helper loaded: file_helper
INFO - 2024-02-27 23:45:50 --> Helper loaded: form_helper
INFO - 2024-02-27 23:45:50 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:45:50 --> Controller Class Initialized
INFO - 2024-02-27 23:45:50 --> Form Validation Class Initialized
INFO - 2024-02-27 23:45:50 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-02-27 23:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-02-27 23:45:50 --> Final output sent to browser
DEBUG - 2024-02-27 23:45:50 --> Total execution time: 0.0390
ERROR - 2024-02-27 23:45:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:45:50 --> Config Class Initialized
INFO - 2024-02-27 23:45:50 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:45:50 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:45:50 --> Utf8 Class Initialized
INFO - 2024-02-27 23:45:50 --> URI Class Initialized
INFO - 2024-02-27 23:45:50 --> Router Class Initialized
INFO - 2024-02-27 23:45:50 --> Output Class Initialized
INFO - 2024-02-27 23:45:50 --> Security Class Initialized
DEBUG - 2024-02-27 23:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:45:50 --> Input Class Initialized
INFO - 2024-02-27 23:45:50 --> Language Class Initialized
INFO - 2024-02-27 23:45:50 --> Loader Class Initialized
INFO - 2024-02-27 23:45:50 --> Helper loaded: url_helper
INFO - 2024-02-27 23:45:50 --> Helper loaded: file_helper
INFO - 2024-02-27 23:45:50 --> Helper loaded: form_helper
INFO - 2024-02-27 23:45:50 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:45:50 --> Controller Class Initialized
INFO - 2024-02-27 23:45:50 --> Form Validation Class Initialized
INFO - 2024-02-27 23:45:50 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:45:50 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:46:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:46:05 --> Config Class Initialized
INFO - 2024-02-27 23:46:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:46:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:46:05 --> Utf8 Class Initialized
INFO - 2024-02-27 23:46:05 --> URI Class Initialized
INFO - 2024-02-27 23:46:05 --> Router Class Initialized
INFO - 2024-02-27 23:46:05 --> Output Class Initialized
INFO - 2024-02-27 23:46:05 --> Security Class Initialized
DEBUG - 2024-02-27 23:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:46:05 --> Input Class Initialized
INFO - 2024-02-27 23:46:05 --> Language Class Initialized
INFO - 2024-02-27 23:46:05 --> Loader Class Initialized
INFO - 2024-02-27 23:46:05 --> Helper loaded: url_helper
INFO - 2024-02-27 23:46:05 --> Helper loaded: file_helper
INFO - 2024-02-27 23:46:05 --> Helper loaded: form_helper
INFO - 2024-02-27 23:46:05 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:46:05 --> Controller Class Initialized
INFO - 2024-02-27 23:46:05 --> Form Validation Class Initialized
INFO - 2024-02-27 23:46:05 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:46:05 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:46:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:46:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:46:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:46:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:46:05 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:46:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:46:05 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:46:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/dispatch_order_form.php
INFO - 2024-02-27 23:46:05 --> Final output sent to browser
DEBUG - 2024-02-27 23:46:05 --> Total execution time: 0.0393
ERROR - 2024-02-27 23:46:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:46:09 --> Config Class Initialized
INFO - 2024-02-27 23:46:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:46:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:46:09 --> Utf8 Class Initialized
INFO - 2024-02-27 23:46:09 --> URI Class Initialized
INFO - 2024-02-27 23:46:09 --> Router Class Initialized
INFO - 2024-02-27 23:46:09 --> Output Class Initialized
INFO - 2024-02-27 23:46:09 --> Security Class Initialized
DEBUG - 2024-02-27 23:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:46:09 --> Input Class Initialized
INFO - 2024-02-27 23:46:09 --> Language Class Initialized
INFO - 2024-02-27 23:46:09 --> Loader Class Initialized
INFO - 2024-02-27 23:46:09 --> Helper loaded: url_helper
INFO - 2024-02-27 23:46:09 --> Helper loaded: file_helper
INFO - 2024-02-27 23:46:09 --> Helper loaded: form_helper
INFO - 2024-02-27 23:46:09 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:46:09 --> Controller Class Initialized
INFO - 2024-02-27 23:46:09 --> Form Validation Class Initialized
INFO - 2024-02-27 23:46:09 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:46:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:46:09 --> Config Class Initialized
INFO - 2024-02-27 23:46:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:46:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:46:09 --> Utf8 Class Initialized
INFO - 2024-02-27 23:46:09 --> URI Class Initialized
INFO - 2024-02-27 23:46:09 --> Router Class Initialized
INFO - 2024-02-27 23:46:09 --> Output Class Initialized
INFO - 2024-02-27 23:46:09 --> Security Class Initialized
DEBUG - 2024-02-27 23:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:46:09 --> Input Class Initialized
INFO - 2024-02-27 23:46:09 --> Language Class Initialized
INFO - 2024-02-27 23:46:09 --> Loader Class Initialized
INFO - 2024-02-27 23:46:09 --> Helper loaded: url_helper
INFO - 2024-02-27 23:46:09 --> Helper loaded: file_helper
INFO - 2024-02-27 23:46:09 --> Helper loaded: form_helper
INFO - 2024-02-27 23:46:09 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:46:09 --> Controller Class Initialized
INFO - 2024-02-27 23:46:09 --> Form Validation Class Initialized
INFO - 2024-02-27 23:46:09 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:46:09 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:46:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:46:13 --> Config Class Initialized
INFO - 2024-02-27 23:46:13 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:46:13 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:46:13 --> Utf8 Class Initialized
INFO - 2024-02-27 23:46:13 --> URI Class Initialized
INFO - 2024-02-27 23:46:13 --> Router Class Initialized
INFO - 2024-02-27 23:46:13 --> Output Class Initialized
INFO - 2024-02-27 23:46:13 --> Security Class Initialized
DEBUG - 2024-02-27 23:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:46:13 --> Input Class Initialized
INFO - 2024-02-27 23:46:13 --> Language Class Initialized
INFO - 2024-02-27 23:46:13 --> Loader Class Initialized
INFO - 2024-02-27 23:46:13 --> Helper loaded: url_helper
INFO - 2024-02-27 23:46:13 --> Helper loaded: file_helper
INFO - 2024-02-27 23:46:13 --> Helper loaded: form_helper
INFO - 2024-02-27 23:46:13 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:46:13 --> Controller Class Initialized
INFO - 2024-02-27 23:46:13 --> Form Validation Class Initialized
INFO - 2024-02-27 23:46:13 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:46:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:46:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:46:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:46:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:46:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:46:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:46:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:46:13 --> Final output sent to browser
DEBUG - 2024-02-27 23:46:13 --> Total execution time: 0.0363
ERROR - 2024-02-27 23:46:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:46:13 --> Config Class Initialized
INFO - 2024-02-27 23:46:13 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:46:13 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:46:13 --> Utf8 Class Initialized
INFO - 2024-02-27 23:46:13 --> URI Class Initialized
INFO - 2024-02-27 23:46:13 --> Router Class Initialized
INFO - 2024-02-27 23:46:13 --> Output Class Initialized
INFO - 2024-02-27 23:46:13 --> Security Class Initialized
DEBUG - 2024-02-27 23:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:46:13 --> Input Class Initialized
INFO - 2024-02-27 23:46:13 --> Language Class Initialized
INFO - 2024-02-27 23:46:13 --> Loader Class Initialized
INFO - 2024-02-27 23:46:13 --> Helper loaded: url_helper
INFO - 2024-02-27 23:46:13 --> Helper loaded: file_helper
INFO - 2024-02-27 23:46:13 --> Helper loaded: form_helper
INFO - 2024-02-27 23:46:13 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:46:13 --> Controller Class Initialized
INFO - 2024-02-27 23:46:13 --> Form Validation Class Initialized
INFO - 2024-02-27 23:46:13 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:46:13 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:46:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:46:26 --> Config Class Initialized
INFO - 2024-02-27 23:46:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:46:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:46:26 --> Utf8 Class Initialized
INFO - 2024-02-27 23:46:26 --> URI Class Initialized
INFO - 2024-02-27 23:46:26 --> Router Class Initialized
INFO - 2024-02-27 23:46:26 --> Output Class Initialized
INFO - 2024-02-27 23:46:26 --> Security Class Initialized
DEBUG - 2024-02-27 23:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:46:26 --> Input Class Initialized
INFO - 2024-02-27 23:46:26 --> Language Class Initialized
INFO - 2024-02-27 23:46:26 --> Loader Class Initialized
INFO - 2024-02-27 23:46:26 --> Helper loaded: url_helper
INFO - 2024-02-27 23:46:26 --> Helper loaded: file_helper
INFO - 2024-02-27 23:46:26 --> Helper loaded: form_helper
INFO - 2024-02-27 23:46:26 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:46:26 --> Controller Class Initialized
INFO - 2024-02-27 23:46:26 --> Form Validation Class Initialized
INFO - 2024-02-27 23:46:26 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:46:26 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:46:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:46:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:46:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:46:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:46:26 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:46:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:46:26 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:46:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/dispatch_order_form.php
INFO - 2024-02-27 23:46:26 --> Final output sent to browser
DEBUG - 2024-02-27 23:46:26 --> Total execution time: 0.0348
ERROR - 2024-02-27 23:46:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:46:28 --> Config Class Initialized
INFO - 2024-02-27 23:46:28 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:46:28 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:46:28 --> Utf8 Class Initialized
INFO - 2024-02-27 23:46:28 --> URI Class Initialized
INFO - 2024-02-27 23:46:28 --> Router Class Initialized
INFO - 2024-02-27 23:46:28 --> Output Class Initialized
INFO - 2024-02-27 23:46:28 --> Security Class Initialized
DEBUG - 2024-02-27 23:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:46:28 --> Input Class Initialized
INFO - 2024-02-27 23:46:28 --> Language Class Initialized
INFO - 2024-02-27 23:46:28 --> Loader Class Initialized
INFO - 2024-02-27 23:46:28 --> Helper loaded: url_helper
INFO - 2024-02-27 23:46:28 --> Helper loaded: file_helper
INFO - 2024-02-27 23:46:28 --> Helper loaded: form_helper
INFO - 2024-02-27 23:46:28 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:46:28 --> Controller Class Initialized
INFO - 2024-02-27 23:46:28 --> Form Validation Class Initialized
INFO - 2024-02-27 23:46:28 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:46:28 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:46:28 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:46:28 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:46:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:46:28 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:46:28 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:46:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:46:28 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:46:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:46:29 --> Config Class Initialized
INFO - 2024-02-27 23:46:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:46:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:46:29 --> Utf8 Class Initialized
INFO - 2024-02-27 23:46:29 --> URI Class Initialized
INFO - 2024-02-27 23:46:29 --> Router Class Initialized
INFO - 2024-02-27 23:46:29 --> Output Class Initialized
INFO - 2024-02-27 23:46:29 --> Security Class Initialized
DEBUG - 2024-02-27 23:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:46:29 --> Input Class Initialized
INFO - 2024-02-27 23:46:29 --> Language Class Initialized
INFO - 2024-02-27 23:46:29 --> Loader Class Initialized
INFO - 2024-02-27 23:46:29 --> Helper loaded: url_helper
INFO - 2024-02-27 23:46:29 --> Helper loaded: file_helper
INFO - 2024-02-27 23:46:29 --> Helper loaded: form_helper
INFO - 2024-02-27 23:46:29 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:46:29 --> Controller Class Initialized
INFO - 2024-02-27 23:46:29 --> Form Validation Class Initialized
INFO - 2024-02-27 23:46:29 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:46:29 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:46:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:46:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:46:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:46:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:46:29 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:46:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:46:29 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:46:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:46:33 --> Config Class Initialized
INFO - 2024-02-27 23:46:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:46:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:46:33 --> Utf8 Class Initialized
INFO - 2024-02-27 23:46:33 --> URI Class Initialized
INFO - 2024-02-27 23:46:33 --> Router Class Initialized
INFO - 2024-02-27 23:46:33 --> Output Class Initialized
INFO - 2024-02-27 23:46:33 --> Security Class Initialized
DEBUG - 2024-02-27 23:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:46:33 --> Input Class Initialized
INFO - 2024-02-27 23:46:33 --> Language Class Initialized
INFO - 2024-02-27 23:46:33 --> Loader Class Initialized
INFO - 2024-02-27 23:46:33 --> Helper loaded: url_helper
INFO - 2024-02-27 23:46:33 --> Helper loaded: file_helper
INFO - 2024-02-27 23:46:33 --> Helper loaded: form_helper
INFO - 2024-02-27 23:46:33 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:46:33 --> Controller Class Initialized
INFO - 2024-02-27 23:46:33 --> Form Validation Class Initialized
INFO - 2024-02-27 23:46:33 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:46:33 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:46:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:46:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:46:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:46:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:46:33 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:46:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:46:33 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:46:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:46:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:46:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:46:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:46:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:46:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:46:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:46:33 --> Final output sent to browser
DEBUG - 2024-02-27 23:46:33 --> Total execution time: 0.0355
ERROR - 2024-02-27 23:46:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:46:33 --> Config Class Initialized
INFO - 2024-02-27 23:46:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:46:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:46:33 --> Utf8 Class Initialized
INFO - 2024-02-27 23:46:33 --> URI Class Initialized
INFO - 2024-02-27 23:46:33 --> Router Class Initialized
INFO - 2024-02-27 23:46:33 --> Output Class Initialized
INFO - 2024-02-27 23:46:33 --> Security Class Initialized
DEBUG - 2024-02-27 23:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:46:34 --> Input Class Initialized
INFO - 2024-02-27 23:46:34 --> Language Class Initialized
INFO - 2024-02-27 23:46:34 --> Loader Class Initialized
INFO - 2024-02-27 23:46:34 --> Helper loaded: url_helper
INFO - 2024-02-27 23:46:34 --> Helper loaded: file_helper
INFO - 2024-02-27 23:46:34 --> Helper loaded: form_helper
INFO - 2024-02-27 23:46:34 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:46:34 --> Controller Class Initialized
INFO - 2024-02-27 23:46:34 --> Form Validation Class Initialized
INFO - 2024-02-27 23:46:34 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:46:34 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:46:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:46:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:46:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:46:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:46:34 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:46:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:46:34 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:47:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:47:18 --> Config Class Initialized
INFO - 2024-02-27 23:47:18 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:47:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:47:18 --> Utf8 Class Initialized
INFO - 2024-02-27 23:47:18 --> URI Class Initialized
INFO - 2024-02-27 23:47:18 --> Router Class Initialized
INFO - 2024-02-27 23:47:18 --> Output Class Initialized
INFO - 2024-02-27 23:47:18 --> Security Class Initialized
DEBUG - 2024-02-27 23:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:47:18 --> Input Class Initialized
INFO - 2024-02-27 23:47:18 --> Language Class Initialized
INFO - 2024-02-27 23:47:18 --> Loader Class Initialized
INFO - 2024-02-27 23:47:18 --> Helper loaded: url_helper
INFO - 2024-02-27 23:47:18 --> Helper loaded: file_helper
INFO - 2024-02-27 23:47:18 --> Helper loaded: form_helper
INFO - 2024-02-27 23:47:18 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:47:18 --> Controller Class Initialized
INFO - 2024-02-27 23:47:18 --> Form Validation Class Initialized
INFO - 2024-02-27 23:47:18 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:47:18 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:47:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:47:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:47:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:47:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:47:18 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:47:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:47:18 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:47:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:47:22 --> Config Class Initialized
INFO - 2024-02-27 23:47:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:47:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:47:22 --> Utf8 Class Initialized
INFO - 2024-02-27 23:47:22 --> URI Class Initialized
INFO - 2024-02-27 23:47:22 --> Router Class Initialized
INFO - 2024-02-27 23:47:22 --> Output Class Initialized
INFO - 2024-02-27 23:47:22 --> Security Class Initialized
DEBUG - 2024-02-27 23:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:47:22 --> Input Class Initialized
INFO - 2024-02-27 23:47:22 --> Language Class Initialized
INFO - 2024-02-27 23:47:22 --> Loader Class Initialized
INFO - 2024-02-27 23:47:22 --> Helper loaded: url_helper
INFO - 2024-02-27 23:47:22 --> Helper loaded: file_helper
INFO - 2024-02-27 23:47:22 --> Helper loaded: form_helper
INFO - 2024-02-27 23:47:22 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:47:22 --> Controller Class Initialized
INFO - 2024-02-27 23:47:22 --> Form Validation Class Initialized
INFO - 2024-02-27 23:47:22 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:47:22 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:47:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:47:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:47:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:47:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:47:22 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:47:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:47:22 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:47:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:47:26 --> Config Class Initialized
INFO - 2024-02-27 23:47:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:47:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:47:26 --> Utf8 Class Initialized
INFO - 2024-02-27 23:47:26 --> URI Class Initialized
INFO - 2024-02-27 23:47:26 --> Router Class Initialized
INFO - 2024-02-27 23:47:26 --> Output Class Initialized
INFO - 2024-02-27 23:47:26 --> Security Class Initialized
DEBUG - 2024-02-27 23:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:47:26 --> Input Class Initialized
INFO - 2024-02-27 23:47:26 --> Language Class Initialized
INFO - 2024-02-27 23:47:26 --> Loader Class Initialized
INFO - 2024-02-27 23:47:26 --> Helper loaded: url_helper
INFO - 2024-02-27 23:47:26 --> Helper loaded: file_helper
INFO - 2024-02-27 23:47:26 --> Helper loaded: form_helper
INFO - 2024-02-27 23:47:26 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:47:26 --> Controller Class Initialized
INFO - 2024-02-27 23:47:26 --> Form Validation Class Initialized
INFO - 2024-02-27 23:47:26 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:47:26 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:47:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:47:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:47:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:47:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:47:26 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:47:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:47:26 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:54:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:54:23 --> Config Class Initialized
INFO - 2024-02-27 23:54:23 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:54:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:54:23 --> Utf8 Class Initialized
INFO - 2024-02-27 23:54:23 --> URI Class Initialized
INFO - 2024-02-27 23:54:23 --> Router Class Initialized
INFO - 2024-02-27 23:54:23 --> Output Class Initialized
INFO - 2024-02-27 23:54:23 --> Security Class Initialized
DEBUG - 2024-02-27 23:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:54:23 --> Input Class Initialized
INFO - 2024-02-27 23:54:23 --> Language Class Initialized
INFO - 2024-02-27 23:54:23 --> Loader Class Initialized
INFO - 2024-02-27 23:54:23 --> Helper loaded: url_helper
INFO - 2024-02-27 23:54:23 --> Helper loaded: file_helper
INFO - 2024-02-27 23:54:23 --> Helper loaded: form_helper
INFO - 2024-02-27 23:54:23 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:54:23 --> Controller Class Initialized
INFO - 2024-02-27 23:54:23 --> Form Validation Class Initialized
INFO - 2024-02-27 23:54:23 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:54:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:54:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:54:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:54:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:54:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:54:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:54:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:54:23 --> Final output sent to browser
DEBUG - 2024-02-27 23:54:23 --> Total execution time: 0.0339
ERROR - 2024-02-27 23:54:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:54:23 --> Config Class Initialized
INFO - 2024-02-27 23:54:23 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:54:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:54:23 --> Utf8 Class Initialized
INFO - 2024-02-27 23:54:23 --> URI Class Initialized
INFO - 2024-02-27 23:54:23 --> Router Class Initialized
INFO - 2024-02-27 23:54:23 --> Output Class Initialized
INFO - 2024-02-27 23:54:23 --> Security Class Initialized
DEBUG - 2024-02-27 23:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:54:23 --> Input Class Initialized
INFO - 2024-02-27 23:54:23 --> Language Class Initialized
INFO - 2024-02-27 23:54:23 --> Loader Class Initialized
INFO - 2024-02-27 23:54:23 --> Helper loaded: url_helper
INFO - 2024-02-27 23:54:23 --> Helper loaded: file_helper
INFO - 2024-02-27 23:54:23 --> Helper loaded: form_helper
INFO - 2024-02-27 23:54:23 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:54:23 --> Controller Class Initialized
INFO - 2024-02-27 23:54:23 --> Form Validation Class Initialized
INFO - 2024-02-27 23:54:23 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:54:23 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:56:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:56:10 --> Config Class Initialized
INFO - 2024-02-27 23:56:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:56:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:56:10 --> Utf8 Class Initialized
INFO - 2024-02-27 23:56:10 --> URI Class Initialized
INFO - 2024-02-27 23:56:10 --> Router Class Initialized
INFO - 2024-02-27 23:56:10 --> Output Class Initialized
INFO - 2024-02-27 23:56:10 --> Security Class Initialized
DEBUG - 2024-02-27 23:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:56:10 --> Input Class Initialized
INFO - 2024-02-27 23:56:10 --> Language Class Initialized
INFO - 2024-02-27 23:56:10 --> Loader Class Initialized
INFO - 2024-02-27 23:56:10 --> Helper loaded: url_helper
INFO - 2024-02-27 23:56:10 --> Helper loaded: file_helper
INFO - 2024-02-27 23:56:10 --> Helper loaded: form_helper
INFO - 2024-02-27 23:56:10 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:56:10 --> Controller Class Initialized
INFO - 2024-02-27 23:56:10 --> Form Validation Class Initialized
INFO - 2024-02-27 23:56:10 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:56:10 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:56:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:56:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:56:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:56:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:56:10 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:56:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:56:10 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:56:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:56:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:56:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:56:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:56:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:56:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:56:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:56:10 --> Final output sent to browser
DEBUG - 2024-02-27 23:56:10 --> Total execution time: 0.0282
ERROR - 2024-02-27 23:56:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:56:11 --> Config Class Initialized
INFO - 2024-02-27 23:56:11 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:56:11 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:56:11 --> Utf8 Class Initialized
INFO - 2024-02-27 23:56:11 --> URI Class Initialized
INFO - 2024-02-27 23:56:11 --> Router Class Initialized
INFO - 2024-02-27 23:56:11 --> Output Class Initialized
INFO - 2024-02-27 23:56:11 --> Security Class Initialized
DEBUG - 2024-02-27 23:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:56:11 --> Input Class Initialized
INFO - 2024-02-27 23:56:11 --> Language Class Initialized
INFO - 2024-02-27 23:56:11 --> Loader Class Initialized
INFO - 2024-02-27 23:56:11 --> Helper loaded: url_helper
INFO - 2024-02-27 23:56:11 --> Helper loaded: file_helper
INFO - 2024-02-27 23:56:11 --> Helper loaded: form_helper
INFO - 2024-02-27 23:56:11 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:56:11 --> Controller Class Initialized
INFO - 2024-02-27 23:56:11 --> Form Validation Class Initialized
INFO - 2024-02-27 23:56:11 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:56:11 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:56:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:56:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:56:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:56:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:56:11 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:56:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:56:11 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:56:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:56:20 --> Config Class Initialized
INFO - 2024-02-27 23:56:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:56:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:56:20 --> Utf8 Class Initialized
INFO - 2024-02-27 23:56:20 --> URI Class Initialized
INFO - 2024-02-27 23:56:20 --> Router Class Initialized
INFO - 2024-02-27 23:56:20 --> Output Class Initialized
INFO - 2024-02-27 23:56:20 --> Security Class Initialized
DEBUG - 2024-02-27 23:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:56:20 --> Input Class Initialized
INFO - 2024-02-27 23:56:20 --> Language Class Initialized
INFO - 2024-02-27 23:56:20 --> Loader Class Initialized
INFO - 2024-02-27 23:56:20 --> Helper loaded: url_helper
INFO - 2024-02-27 23:56:20 --> Helper loaded: file_helper
INFO - 2024-02-27 23:56:20 --> Helper loaded: form_helper
INFO - 2024-02-27 23:56:20 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:56:20 --> Controller Class Initialized
INFO - 2024-02-27 23:56:20 --> Form Validation Class Initialized
INFO - 2024-02-27 23:56:20 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:56:20 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:56:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:56:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:56:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:56:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:56:20 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:56:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:56:20 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:56:20 --> Severity: Notice --> Undefined property: Report::$user D:\xampp\htdocs\sscy\application\controllers\app\Report.php 24
ERROR - 2024-02-27 23:56:20 --> Severity: error --> Exception: Call to a member function getUser() on null D:\xampp\htdocs\sscy\application\controllers\app\Report.php 24
ERROR - 2024-02-27 23:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:56:30 --> Config Class Initialized
INFO - 2024-02-27 23:56:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:56:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:56:30 --> Utf8 Class Initialized
INFO - 2024-02-27 23:56:30 --> URI Class Initialized
INFO - 2024-02-27 23:56:30 --> Router Class Initialized
INFO - 2024-02-27 23:56:30 --> Output Class Initialized
INFO - 2024-02-27 23:56:30 --> Security Class Initialized
DEBUG - 2024-02-27 23:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:56:30 --> Input Class Initialized
INFO - 2024-02-27 23:56:30 --> Language Class Initialized
INFO - 2024-02-27 23:56:30 --> Loader Class Initialized
INFO - 2024-02-27 23:56:30 --> Helper loaded: url_helper
INFO - 2024-02-27 23:56:30 --> Helper loaded: file_helper
INFO - 2024-02-27 23:56:30 --> Helper loaded: form_helper
INFO - 2024-02-27 23:56:30 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:56:30 --> Controller Class Initialized
INFO - 2024-02-27 23:56:30 --> Form Validation Class Initialized
INFO - 2024-02-27 23:56:30 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:56:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:56:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:56:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:56:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:56:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:56:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-02-27 23:56:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-02-27 23:56:30 --> Final output sent to browser
DEBUG - 2024-02-27 23:56:30 --> Total execution time: 0.0297
ERROR - 2024-02-27 23:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:56:30 --> Config Class Initialized
INFO - 2024-02-27 23:56:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:56:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:56:30 --> Utf8 Class Initialized
INFO - 2024-02-27 23:56:30 --> URI Class Initialized
INFO - 2024-02-27 23:56:30 --> Router Class Initialized
INFO - 2024-02-27 23:56:30 --> Output Class Initialized
INFO - 2024-02-27 23:56:30 --> Security Class Initialized
DEBUG - 2024-02-27 23:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:56:30 --> Input Class Initialized
INFO - 2024-02-27 23:56:30 --> Language Class Initialized
INFO - 2024-02-27 23:56:30 --> Loader Class Initialized
INFO - 2024-02-27 23:56:30 --> Helper loaded: url_helper
INFO - 2024-02-27 23:56:30 --> Helper loaded: file_helper
INFO - 2024-02-27 23:56:30 --> Helper loaded: form_helper
INFO - 2024-02-27 23:56:30 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:56:30 --> Controller Class Initialized
INFO - 2024-02-27 23:56:30 --> Form Validation Class Initialized
INFO - 2024-02-27 23:56:30 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:56:30 --> Model "ReportModel" initialized
ERROR - 2024-02-27 23:56:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:56:41 --> Config Class Initialized
INFO - 2024-02-27 23:56:41 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:56:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:56:41 --> Utf8 Class Initialized
INFO - 2024-02-27 23:56:41 --> URI Class Initialized
INFO - 2024-02-27 23:56:41 --> Router Class Initialized
INFO - 2024-02-27 23:56:41 --> Output Class Initialized
INFO - 2024-02-27 23:56:41 --> Security Class Initialized
DEBUG - 2024-02-27 23:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:56:41 --> Input Class Initialized
INFO - 2024-02-27 23:56:41 --> Language Class Initialized
INFO - 2024-02-27 23:56:41 --> Loader Class Initialized
INFO - 2024-02-27 23:56:41 --> Helper loaded: url_helper
INFO - 2024-02-27 23:56:41 --> Helper loaded: file_helper
INFO - 2024-02-27 23:56:41 --> Helper loaded: form_helper
INFO - 2024-02-27 23:56:41 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:56:41 --> Controller Class Initialized
INFO - 2024-02-27 23:56:41 --> Form Validation Class Initialized
INFO - 2024-02-27 23:56:41 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:56:41 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:56:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:56:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:56:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:56:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:56:41 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:56:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:56:41 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:56:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-27 23:56:41 --> Final output sent to browser
DEBUG - 2024-02-27 23:56:41 --> Total execution time: 0.0312
ERROR - 2024-02-27 23:57:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:57:45 --> Config Class Initialized
INFO - 2024-02-27 23:57:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:57:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:57:45 --> Utf8 Class Initialized
INFO - 2024-02-27 23:57:45 --> URI Class Initialized
INFO - 2024-02-27 23:57:45 --> Router Class Initialized
INFO - 2024-02-27 23:57:45 --> Output Class Initialized
INFO - 2024-02-27 23:57:45 --> Security Class Initialized
DEBUG - 2024-02-27 23:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:57:45 --> Input Class Initialized
INFO - 2024-02-27 23:57:45 --> Language Class Initialized
INFO - 2024-02-27 23:57:45 --> Loader Class Initialized
INFO - 2024-02-27 23:57:45 --> Helper loaded: url_helper
INFO - 2024-02-27 23:57:45 --> Helper loaded: file_helper
INFO - 2024-02-27 23:57:45 --> Helper loaded: form_helper
INFO - 2024-02-27 23:57:45 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:57:45 --> Controller Class Initialized
INFO - 2024-02-27 23:57:45 --> Form Validation Class Initialized
INFO - 2024-02-27 23:57:45 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:57:45 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:57:45 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:57:45 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:57:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:57:45 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:57:45 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:57:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:57:45 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:57:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:57:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:57:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:57:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:57:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:57:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-27 23:57:45 --> Final output sent to browser
DEBUG - 2024-02-27 23:57:45 --> Total execution time: 0.0398
ERROR - 2024-02-27 23:59:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:59:21 --> Config Class Initialized
INFO - 2024-02-27 23:59:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:59:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:59:21 --> Utf8 Class Initialized
INFO - 2024-02-27 23:59:21 --> URI Class Initialized
INFO - 2024-02-27 23:59:21 --> Router Class Initialized
INFO - 2024-02-27 23:59:21 --> Output Class Initialized
INFO - 2024-02-27 23:59:21 --> Security Class Initialized
DEBUG - 2024-02-27 23:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:59:21 --> Input Class Initialized
INFO - 2024-02-27 23:59:21 --> Language Class Initialized
INFO - 2024-02-27 23:59:21 --> Loader Class Initialized
INFO - 2024-02-27 23:59:21 --> Helper loaded: url_helper
INFO - 2024-02-27 23:59:21 --> Helper loaded: file_helper
INFO - 2024-02-27 23:59:21 --> Helper loaded: form_helper
INFO - 2024-02-27 23:59:21 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:59:21 --> Controller Class Initialized
INFO - 2024-02-27 23:59:21 --> Form Validation Class Initialized
INFO - 2024-02-27 23:59:21 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:59:21 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:59:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:59:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:59:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:59:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:59:21 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:59:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:59:21 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:59:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:59:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:59:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:59:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:59:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:59:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-27 23:59:21 --> Final output sent to browser
DEBUG - 2024-02-27 23:59:21 --> Total execution time: 0.0397
ERROR - 2024-02-27 23:59:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-27 23:59:56 --> Config Class Initialized
INFO - 2024-02-27 23:59:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 23:59:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 23:59:56 --> Utf8 Class Initialized
INFO - 2024-02-27 23:59:56 --> URI Class Initialized
INFO - 2024-02-27 23:59:56 --> Router Class Initialized
INFO - 2024-02-27 23:59:56 --> Output Class Initialized
INFO - 2024-02-27 23:59:56 --> Security Class Initialized
DEBUG - 2024-02-27 23:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 23:59:56 --> Input Class Initialized
INFO - 2024-02-27 23:59:56 --> Language Class Initialized
INFO - 2024-02-27 23:59:56 --> Loader Class Initialized
INFO - 2024-02-27 23:59:56 --> Helper loaded: url_helper
INFO - 2024-02-27 23:59:56 --> Helper loaded: file_helper
INFO - 2024-02-27 23:59:56 --> Helper loaded: form_helper
INFO - 2024-02-27 23:59:56 --> Database Driver Class Initialized
DEBUG - 2024-02-27 23:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 23:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 23:59:56 --> Controller Class Initialized
INFO - 2024-02-27 23:59:56 --> Form Validation Class Initialized
INFO - 2024-02-27 23:59:56 --> Model "MasterModel" initialized
INFO - 2024-02-27 23:59:56 --> Model "DashboardModel" initialized
INFO - 2024-02-27 23:59:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-27 23:59:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-27 23:59:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-27 23:59:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-27 23:59:56 --> Model "OrderModel" initialized
INFO - 2024-02-27 23:59:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-02-27 23:59:56 --> Model "ReportModel" initialized
INFO - 2024-02-27 23:59:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-27 23:59:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-02-27 23:59:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-27 23:59:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-27 23:59:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-27 23:59:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-02-27 23:59:56 --> Final output sent to browser
DEBUG - 2024-02-27 23:59:56 --> Total execution time: 0.0345
