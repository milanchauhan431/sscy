<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-14 11:26:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 11:26:21 --> Config Class Initialized
INFO - 2024-02-14 11:26:21 --> Hooks Class Initialized
DEBUG - 2024-02-14 11:26:21 --> UTF-8 Support Enabled
INFO - 2024-02-14 11:26:21 --> Utf8 Class Initialized
INFO - 2024-02-14 11:26:21 --> URI Class Initialized
INFO - 2024-02-14 11:26:21 --> Router Class Initialized
INFO - 2024-02-14 11:26:21 --> Output Class Initialized
INFO - 2024-02-14 11:26:21 --> Security Class Initialized
DEBUG - 2024-02-14 11:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 11:26:21 --> Input Class Initialized
INFO - 2024-02-14 11:26:21 --> Language Class Initialized
INFO - 2024-02-14 11:26:21 --> Loader Class Initialized
INFO - 2024-02-14 11:26:21 --> Helper loaded: url_helper
INFO - 2024-02-14 11:26:21 --> Helper loaded: file_helper
INFO - 2024-02-14 11:26:21 --> Helper loaded: form_helper
INFO - 2024-02-14 11:26:21 --> Database Driver Class Initialized
DEBUG - 2024-02-14 11:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 11:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 11:26:21 --> Controller Class Initialized
INFO - 2024-02-14 11:26:21 --> Model "LoginModel" initialized
INFO - 2024-02-14 11:26:21 --> Form Validation Class Initialized
INFO - 2024-02-14 11:26:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-14 11:26:21 --> Final output sent to browser
DEBUG - 2024-02-14 11:26:21 --> Total execution time: 0.0420
ERROR - 2024-02-14 18:50:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 18:50:49 --> Config Class Initialized
INFO - 2024-02-14 18:50:49 --> Hooks Class Initialized
DEBUG - 2024-02-14 18:50:49 --> UTF-8 Support Enabled
INFO - 2024-02-14 18:50:49 --> Utf8 Class Initialized
INFO - 2024-02-14 18:50:49 --> URI Class Initialized
INFO - 2024-02-14 18:50:49 --> Router Class Initialized
INFO - 2024-02-14 18:50:49 --> Output Class Initialized
INFO - 2024-02-14 18:50:49 --> Security Class Initialized
DEBUG - 2024-02-14 18:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 18:50:49 --> Input Class Initialized
INFO - 2024-02-14 18:50:49 --> Language Class Initialized
INFO - 2024-02-14 18:50:49 --> Loader Class Initialized
INFO - 2024-02-14 18:50:49 --> Helper loaded: url_helper
INFO - 2024-02-14 18:50:49 --> Helper loaded: file_helper
INFO - 2024-02-14 18:50:49 --> Helper loaded: form_helper
INFO - 2024-02-14 18:50:49 --> Database Driver Class Initialized
DEBUG - 2024-02-14 18:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 18:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 18:50:49 --> Controller Class Initialized
INFO - 2024-02-14 18:50:49 --> Model "LoginModel" initialized
INFO - 2024-02-14 18:50:49 --> Form Validation Class Initialized
ERROR - 2024-02-14 18:50:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 18:50:49 --> Config Class Initialized
INFO - 2024-02-14 18:50:49 --> Hooks Class Initialized
DEBUG - 2024-02-14 18:50:49 --> UTF-8 Support Enabled
INFO - 2024-02-14 18:50:49 --> Utf8 Class Initialized
INFO - 2024-02-14 18:50:49 --> URI Class Initialized
INFO - 2024-02-14 18:50:49 --> Router Class Initialized
INFO - 2024-02-14 18:50:49 --> Output Class Initialized
INFO - 2024-02-14 18:50:49 --> Security Class Initialized
DEBUG - 2024-02-14 18:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 18:50:49 --> Input Class Initialized
INFO - 2024-02-14 18:50:49 --> Language Class Initialized
INFO - 2024-02-14 18:50:49 --> Loader Class Initialized
INFO - 2024-02-14 18:50:49 --> Helper loaded: url_helper
INFO - 2024-02-14 18:50:49 --> Helper loaded: file_helper
INFO - 2024-02-14 18:50:49 --> Helper loaded: form_helper
INFO - 2024-02-14 18:50:49 --> Database Driver Class Initialized
DEBUG - 2024-02-14 18:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 18:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 18:50:49 --> Controller Class Initialized
INFO - 2024-02-14 18:50:49 --> Form Validation Class Initialized
INFO - 2024-02-14 18:50:49 --> Model "MasterModel" initialized
INFO - 2024-02-14 18:50:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 18:50:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 18:50:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 18:50:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 18:50:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-14 18:50:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 18:50:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 18:50:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 18:50:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-14 18:50:49 --> Final output sent to browser
DEBUG - 2024-02-14 18:50:49 --> Total execution time: 0.0192
ERROR - 2024-02-14 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 18:50:56 --> Config Class Initialized
INFO - 2024-02-14 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-14 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-14 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-14 18:50:56 --> URI Class Initialized
INFO - 2024-02-14 18:50:56 --> Router Class Initialized
INFO - 2024-02-14 18:50:56 --> Output Class Initialized
INFO - 2024-02-14 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-14 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 18:50:56 --> Input Class Initialized
INFO - 2024-02-14 18:50:56 --> Language Class Initialized
INFO - 2024-02-14 18:50:56 --> Loader Class Initialized
INFO - 2024-02-14 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-14 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-14 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-14 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-14 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 18:50:56 --> Controller Class Initialized
INFO - 2024-02-14 18:50:56 --> Model "LoginModel" initialized
INFO - 2024-02-14 18:50:56 --> Form Validation Class Initialized
ERROR - 2024-02-14 18:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 18:50:56 --> Config Class Initialized
INFO - 2024-02-14 18:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-14 18:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-14 18:50:56 --> Utf8 Class Initialized
INFO - 2024-02-14 18:50:56 --> URI Class Initialized
INFO - 2024-02-14 18:50:56 --> Router Class Initialized
INFO - 2024-02-14 18:50:56 --> Output Class Initialized
INFO - 2024-02-14 18:50:56 --> Security Class Initialized
DEBUG - 2024-02-14 18:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 18:50:56 --> Input Class Initialized
INFO - 2024-02-14 18:50:56 --> Language Class Initialized
INFO - 2024-02-14 18:50:56 --> Loader Class Initialized
INFO - 2024-02-14 18:50:56 --> Helper loaded: url_helper
INFO - 2024-02-14 18:50:56 --> Helper loaded: file_helper
INFO - 2024-02-14 18:50:56 --> Helper loaded: form_helper
INFO - 2024-02-14 18:50:56 --> Database Driver Class Initialized
DEBUG - 2024-02-14 18:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 18:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 18:50:56 --> Controller Class Initialized
INFO - 2024-02-14 18:50:56 --> Model "LoginModel" initialized
INFO - 2024-02-14 18:50:56 --> Form Validation Class Initialized
INFO - 2024-02-14 18:50:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-14 18:50:56 --> Final output sent to browser
DEBUG - 2024-02-14 18:50:56 --> Total execution time: 0.0118
ERROR - 2024-02-14 18:51:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 18:51:01 --> Config Class Initialized
INFO - 2024-02-14 18:51:01 --> Hooks Class Initialized
DEBUG - 2024-02-14 18:51:01 --> UTF-8 Support Enabled
INFO - 2024-02-14 18:51:01 --> Utf8 Class Initialized
INFO - 2024-02-14 18:51:01 --> URI Class Initialized
INFO - 2024-02-14 18:51:01 --> Router Class Initialized
INFO - 2024-02-14 18:51:01 --> Output Class Initialized
INFO - 2024-02-14 18:51:01 --> Security Class Initialized
DEBUG - 2024-02-14 18:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 18:51:01 --> Input Class Initialized
INFO - 2024-02-14 18:51:01 --> Language Class Initialized
INFO - 2024-02-14 18:51:01 --> Loader Class Initialized
INFO - 2024-02-14 18:51:01 --> Helper loaded: url_helper
INFO - 2024-02-14 18:51:01 --> Helper loaded: file_helper
INFO - 2024-02-14 18:51:01 --> Helper loaded: form_helper
INFO - 2024-02-14 18:51:01 --> Database Driver Class Initialized
DEBUG - 2024-02-14 18:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 18:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 18:51:01 --> Controller Class Initialized
INFO - 2024-02-14 18:51:01 --> Model "LoginModel" initialized
INFO - 2024-02-14 18:51:01 --> Form Validation Class Initialized
INFO - 2024-02-14 18:51:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-14 18:51:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 18:51:01 --> Config Class Initialized
INFO - 2024-02-14 18:51:01 --> Hooks Class Initialized
DEBUG - 2024-02-14 18:51:01 --> UTF-8 Support Enabled
INFO - 2024-02-14 18:51:01 --> Utf8 Class Initialized
INFO - 2024-02-14 18:51:01 --> URI Class Initialized
INFO - 2024-02-14 18:51:01 --> Router Class Initialized
INFO - 2024-02-14 18:51:01 --> Output Class Initialized
INFO - 2024-02-14 18:51:01 --> Security Class Initialized
DEBUG - 2024-02-14 18:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 18:51:01 --> Input Class Initialized
INFO - 2024-02-14 18:51:01 --> Language Class Initialized
INFO - 2024-02-14 18:51:01 --> Loader Class Initialized
INFO - 2024-02-14 18:51:01 --> Helper loaded: url_helper
INFO - 2024-02-14 18:51:01 --> Helper loaded: file_helper
INFO - 2024-02-14 18:51:01 --> Helper loaded: form_helper
INFO - 2024-02-14 18:51:01 --> Database Driver Class Initialized
DEBUG - 2024-02-14 18:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 18:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 18:51:01 --> Controller Class Initialized
INFO - 2024-02-14 18:51:01 --> Form Validation Class Initialized
INFO - 2024-02-14 18:51:01 --> Model "MasterModel" initialized
INFO - 2024-02-14 18:51:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 18:51:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 18:51:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 18:51:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 18:51:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-14 18:51:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 18:51:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 18:51:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 18:51:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-14 18:51:01 --> Final output sent to browser
DEBUG - 2024-02-14 18:51:01 --> Total execution time: 0.0126
ERROR - 2024-02-14 18:51:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 18:51:03 --> Config Class Initialized
INFO - 2024-02-14 18:51:03 --> Hooks Class Initialized
DEBUG - 2024-02-14 18:51:03 --> UTF-8 Support Enabled
INFO - 2024-02-14 18:51:03 --> Utf8 Class Initialized
INFO - 2024-02-14 18:51:03 --> URI Class Initialized
INFO - 2024-02-14 18:51:03 --> Router Class Initialized
INFO - 2024-02-14 18:51:03 --> Output Class Initialized
INFO - 2024-02-14 18:51:03 --> Security Class Initialized
DEBUG - 2024-02-14 18:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 18:51:03 --> Input Class Initialized
INFO - 2024-02-14 18:51:03 --> Language Class Initialized
INFO - 2024-02-14 18:51:03 --> Loader Class Initialized
INFO - 2024-02-14 18:51:03 --> Helper loaded: url_helper
INFO - 2024-02-14 18:51:03 --> Helper loaded: file_helper
INFO - 2024-02-14 18:51:03 --> Helper loaded: form_helper
INFO - 2024-02-14 18:51:03 --> Database Driver Class Initialized
DEBUG - 2024-02-14 18:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 18:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 18:51:03 --> Controller Class Initialized
INFO - 2024-02-14 18:51:03 --> Form Validation Class Initialized
INFO - 2024-02-14 18:51:03 --> Model "MasterModel" initialized
INFO - 2024-02-14 18:51:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 18:51:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 18:51:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 18:51:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 18:51:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 18:51:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 18:51:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 18:51:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-14 18:51:03 --> Final output sent to browser
DEBUG - 2024-02-14 18:51:03 --> Total execution time: 0.0137
ERROR - 2024-02-14 18:51:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 18:51:03 --> Config Class Initialized
INFO - 2024-02-14 18:51:03 --> Hooks Class Initialized
DEBUG - 2024-02-14 18:51:03 --> UTF-8 Support Enabled
INFO - 2024-02-14 18:51:03 --> Utf8 Class Initialized
INFO - 2024-02-14 18:51:03 --> URI Class Initialized
INFO - 2024-02-14 18:51:03 --> Router Class Initialized
INFO - 2024-02-14 18:51:03 --> Output Class Initialized
INFO - 2024-02-14 18:51:03 --> Security Class Initialized
DEBUG - 2024-02-14 18:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 18:51:03 --> Input Class Initialized
INFO - 2024-02-14 18:51:03 --> Language Class Initialized
INFO - 2024-02-14 18:51:03 --> Loader Class Initialized
INFO - 2024-02-14 18:51:03 --> Helper loaded: url_helper
INFO - 2024-02-14 18:51:03 --> Helper loaded: file_helper
INFO - 2024-02-14 18:51:03 --> Helper loaded: form_helper
INFO - 2024-02-14 18:51:03 --> Database Driver Class Initialized
DEBUG - 2024-02-14 18:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 18:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 18:51:03 --> Controller Class Initialized
INFO - 2024-02-14 18:51:03 --> Form Validation Class Initialized
INFO - 2024-02-14 18:51:03 --> Model "MasterModel" initialized
INFO - 2024-02-14 18:51:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 18:51:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 18:51:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-14 18:51:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 18:51:08 --> Config Class Initialized
INFO - 2024-02-14 18:51:08 --> Hooks Class Initialized
DEBUG - 2024-02-14 18:51:08 --> UTF-8 Support Enabled
INFO - 2024-02-14 18:51:08 --> Utf8 Class Initialized
INFO - 2024-02-14 18:51:08 --> URI Class Initialized
INFO - 2024-02-14 18:51:08 --> Router Class Initialized
INFO - 2024-02-14 18:51:08 --> Output Class Initialized
INFO - 2024-02-14 18:51:08 --> Security Class Initialized
DEBUG - 2024-02-14 18:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 18:51:08 --> Input Class Initialized
INFO - 2024-02-14 18:51:08 --> Language Class Initialized
INFO - 2024-02-14 18:51:08 --> Loader Class Initialized
INFO - 2024-02-14 18:51:08 --> Helper loaded: url_helper
INFO - 2024-02-14 18:51:08 --> Helper loaded: file_helper
INFO - 2024-02-14 18:51:08 --> Helper loaded: form_helper
INFO - 2024-02-14 18:51:08 --> Database Driver Class Initialized
DEBUG - 2024-02-14 18:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 18:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 18:51:08 --> Controller Class Initialized
INFO - 2024-02-14 18:51:08 --> Form Validation Class Initialized
INFO - 2024-02-14 18:51:08 --> Model "MasterModel" initialized
INFO - 2024-02-14 18:51:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 18:51:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 18:51:08 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-14 18:51:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 18:51:10 --> Config Class Initialized
INFO - 2024-02-14 18:51:10 --> Hooks Class Initialized
DEBUG - 2024-02-14 18:51:10 --> UTF-8 Support Enabled
INFO - 2024-02-14 18:51:10 --> Utf8 Class Initialized
INFO - 2024-02-14 18:51:10 --> URI Class Initialized
INFO - 2024-02-14 18:51:10 --> Router Class Initialized
INFO - 2024-02-14 18:51:10 --> Output Class Initialized
INFO - 2024-02-14 18:51:10 --> Security Class Initialized
DEBUG - 2024-02-14 18:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 18:51:10 --> Input Class Initialized
INFO - 2024-02-14 18:51:10 --> Language Class Initialized
INFO - 2024-02-14 18:51:10 --> Loader Class Initialized
INFO - 2024-02-14 18:51:10 --> Helper loaded: url_helper
INFO - 2024-02-14 18:51:10 --> Helper loaded: file_helper
INFO - 2024-02-14 18:51:10 --> Helper loaded: form_helper
INFO - 2024-02-14 18:51:10 --> Database Driver Class Initialized
DEBUG - 2024-02-14 18:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 18:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 18:51:10 --> Controller Class Initialized
INFO - 2024-02-14 18:51:10 --> Form Validation Class Initialized
INFO - 2024-02-14 18:51:10 --> Model "MasterModel" initialized
INFO - 2024-02-14 18:51:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 18:51:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 18:51:10 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-14 18:52:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 18:52:23 --> Config Class Initialized
INFO - 2024-02-14 18:52:23 --> Hooks Class Initialized
DEBUG - 2024-02-14 18:52:23 --> UTF-8 Support Enabled
INFO - 2024-02-14 18:52:23 --> Utf8 Class Initialized
INFO - 2024-02-14 18:52:23 --> URI Class Initialized
INFO - 2024-02-14 18:52:23 --> Router Class Initialized
INFO - 2024-02-14 18:52:23 --> Output Class Initialized
INFO - 2024-02-14 18:52:23 --> Security Class Initialized
DEBUG - 2024-02-14 18:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 18:52:23 --> Input Class Initialized
INFO - 2024-02-14 18:52:23 --> Language Class Initialized
INFO - 2024-02-14 18:52:23 --> Loader Class Initialized
INFO - 2024-02-14 18:52:23 --> Helper loaded: url_helper
INFO - 2024-02-14 18:52:23 --> Helper loaded: file_helper
INFO - 2024-02-14 18:52:23 --> Helper loaded: form_helper
INFO - 2024-02-14 18:52:23 --> Database Driver Class Initialized
DEBUG - 2024-02-14 18:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 18:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 18:52:23 --> Controller Class Initialized
INFO - 2024-02-14 18:52:23 --> Form Validation Class Initialized
INFO - 2024-02-14 18:52:23 --> Model "MasterModel" initialized
INFO - 2024-02-14 18:52:23 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 18:52:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 18:52:23 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-14 19:11:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:11:50 --> Config Class Initialized
INFO - 2024-02-14 19:11:50 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:11:50 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:11:50 --> Utf8 Class Initialized
INFO - 2024-02-14 19:11:50 --> URI Class Initialized
INFO - 2024-02-14 19:11:50 --> Router Class Initialized
INFO - 2024-02-14 19:11:50 --> Output Class Initialized
INFO - 2024-02-14 19:11:50 --> Security Class Initialized
DEBUG - 2024-02-14 19:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:11:50 --> Input Class Initialized
INFO - 2024-02-14 19:11:50 --> Language Class Initialized
INFO - 2024-02-14 19:11:50 --> Loader Class Initialized
INFO - 2024-02-14 19:11:50 --> Helper loaded: url_helper
INFO - 2024-02-14 19:11:50 --> Helper loaded: file_helper
INFO - 2024-02-14 19:11:50 --> Helper loaded: form_helper
INFO - 2024-02-14 19:11:50 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:11:50 --> Controller Class Initialized
INFO - 2024-02-14 19:11:50 --> Form Validation Class Initialized
INFO - 2024-02-14 19:11:50 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:11:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:11:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:11:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:11:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:11:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:11:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:11:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:11:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_category/index.php
INFO - 2024-02-14 19:11:50 --> Final output sent to browser
DEBUG - 2024-02-14 19:11:50 --> Total execution time: 0.0192
ERROR - 2024-02-14 19:39:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:39:43 --> Config Class Initialized
INFO - 2024-02-14 19:39:43 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:39:43 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:39:43 --> Utf8 Class Initialized
INFO - 2024-02-14 19:39:43 --> URI Class Initialized
INFO - 2024-02-14 19:39:43 --> Router Class Initialized
INFO - 2024-02-14 19:39:43 --> Output Class Initialized
INFO - 2024-02-14 19:39:43 --> Security Class Initialized
DEBUG - 2024-02-14 19:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:39:43 --> Input Class Initialized
INFO - 2024-02-14 19:39:43 --> Language Class Initialized
INFO - 2024-02-14 19:39:43 --> Loader Class Initialized
INFO - 2024-02-14 19:39:43 --> Helper loaded: url_helper
INFO - 2024-02-14 19:39:43 --> Helper loaded: file_helper
INFO - 2024-02-14 19:39:43 --> Helper loaded: form_helper
INFO - 2024-02-14 19:39:43 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:39:43 --> Controller Class Initialized
INFO - 2024-02-14 19:39:43 --> Form Validation Class Initialized
INFO - 2024-02-14 19:39:43 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:39:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:39:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:39:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:39:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:39:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:39:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:39:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:39:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:39:43 --> Final output sent to browser
DEBUG - 2024-02-14 19:39:43 --> Total execution time: 0.0185
ERROR - 2024-02-14 19:39:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:39:43 --> Config Class Initialized
INFO - 2024-02-14 19:39:43 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:39:43 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:39:43 --> Utf8 Class Initialized
INFO - 2024-02-14 19:39:43 --> URI Class Initialized
INFO - 2024-02-14 19:39:43 --> Router Class Initialized
INFO - 2024-02-14 19:39:43 --> Output Class Initialized
INFO - 2024-02-14 19:39:43 --> Security Class Initialized
DEBUG - 2024-02-14 19:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:39:43 --> Input Class Initialized
INFO - 2024-02-14 19:39:43 --> Language Class Initialized
INFO - 2024-02-14 19:39:43 --> Loader Class Initialized
INFO - 2024-02-14 19:39:43 --> Helper loaded: url_helper
INFO - 2024-02-14 19:39:43 --> Helper loaded: file_helper
INFO - 2024-02-14 19:39:43 --> Helper loaded: form_helper
INFO - 2024-02-14 19:39:43 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:39:43 --> Controller Class Initialized
INFO - 2024-02-14 19:39:43 --> Form Validation Class Initialized
INFO - 2024-02-14 19:39:43 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:39:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:39:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:39:43 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-14 19:39:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:39:45 --> Config Class Initialized
INFO - 2024-02-14 19:39:45 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:39:45 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:39:45 --> Utf8 Class Initialized
INFO - 2024-02-14 19:39:46 --> URI Class Initialized
INFO - 2024-02-14 19:39:46 --> Router Class Initialized
INFO - 2024-02-14 19:39:46 --> Output Class Initialized
INFO - 2024-02-14 19:39:46 --> Security Class Initialized
DEBUG - 2024-02-14 19:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:39:46 --> Input Class Initialized
INFO - 2024-02-14 19:39:46 --> Language Class Initialized
INFO - 2024-02-14 19:39:46 --> Loader Class Initialized
INFO - 2024-02-14 19:39:46 --> Helper loaded: url_helper
INFO - 2024-02-14 19:39:46 --> Helper loaded: file_helper
INFO - 2024-02-14 19:39:46 --> Helper loaded: form_helper
INFO - 2024-02-14 19:39:46 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:39:46 --> Controller Class Initialized
INFO - 2024-02-14 19:39:46 --> Form Validation Class Initialized
INFO - 2024-02-14 19:39:46 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:39:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:39:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:39:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:39:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-14 19:39:46 --> Final output sent to browser
DEBUG - 2024-02-14 19:39:46 --> Total execution time: 0.0179
ERROR - 2024-02-14 19:41:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:41:48 --> Config Class Initialized
INFO - 2024-02-14 19:41:48 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:41:48 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:41:48 --> Utf8 Class Initialized
INFO - 2024-02-14 19:41:48 --> URI Class Initialized
INFO - 2024-02-14 19:41:48 --> Router Class Initialized
INFO - 2024-02-14 19:41:48 --> Output Class Initialized
INFO - 2024-02-14 19:41:48 --> Security Class Initialized
DEBUG - 2024-02-14 19:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:41:48 --> Input Class Initialized
INFO - 2024-02-14 19:41:48 --> Language Class Initialized
INFO - 2024-02-14 19:41:48 --> Loader Class Initialized
INFO - 2024-02-14 19:41:48 --> Helper loaded: url_helper
INFO - 2024-02-14 19:41:48 --> Helper loaded: file_helper
INFO - 2024-02-14 19:41:48 --> Helper loaded: form_helper
INFO - 2024-02-14 19:41:48 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:41:48 --> Controller Class Initialized
INFO - 2024-02-14 19:41:48 --> Form Validation Class Initialized
INFO - 2024-02-14 19:41:48 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:41:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:41:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:41:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:41:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:41:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:41:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:41:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:41:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:41:48 --> Final output sent to browser
DEBUG - 2024-02-14 19:41:48 --> Total execution time: 0.0154
ERROR - 2024-02-14 19:41:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:41:48 --> Config Class Initialized
INFO - 2024-02-14 19:41:48 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:41:48 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:41:48 --> Utf8 Class Initialized
INFO - 2024-02-14 19:41:48 --> URI Class Initialized
INFO - 2024-02-14 19:41:48 --> Router Class Initialized
INFO - 2024-02-14 19:41:48 --> Output Class Initialized
INFO - 2024-02-14 19:41:48 --> Security Class Initialized
DEBUG - 2024-02-14 19:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:41:48 --> Input Class Initialized
INFO - 2024-02-14 19:41:48 --> Language Class Initialized
INFO - 2024-02-14 19:41:48 --> Loader Class Initialized
INFO - 2024-02-14 19:41:48 --> Helper loaded: url_helper
INFO - 2024-02-14 19:41:48 --> Helper loaded: file_helper
INFO - 2024-02-14 19:41:48 --> Helper loaded: form_helper
INFO - 2024-02-14 19:41:48 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:41:48 --> Controller Class Initialized
INFO - 2024-02-14 19:41:48 --> Form Validation Class Initialized
INFO - 2024-02-14 19:41:48 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:41:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:41:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:41:48 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-14 19:41:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:41:50 --> Config Class Initialized
INFO - 2024-02-14 19:41:50 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:41:50 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:41:50 --> Utf8 Class Initialized
INFO - 2024-02-14 19:41:50 --> URI Class Initialized
INFO - 2024-02-14 19:41:50 --> Router Class Initialized
INFO - 2024-02-14 19:41:50 --> Output Class Initialized
INFO - 2024-02-14 19:41:50 --> Security Class Initialized
DEBUG - 2024-02-14 19:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:41:50 --> Input Class Initialized
INFO - 2024-02-14 19:41:50 --> Language Class Initialized
INFO - 2024-02-14 19:41:50 --> Loader Class Initialized
INFO - 2024-02-14 19:41:50 --> Helper loaded: url_helper
INFO - 2024-02-14 19:41:50 --> Helper loaded: file_helper
INFO - 2024-02-14 19:41:50 --> Helper loaded: form_helper
INFO - 2024-02-14 19:41:50 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:41:50 --> Controller Class Initialized
INFO - 2024-02-14 19:41:50 --> Form Validation Class Initialized
INFO - 2024-02-14 19:41:50 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:41:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:41:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:41:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:41:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-14 19:41:50 --> Final output sent to browser
DEBUG - 2024-02-14 19:41:50 --> Total execution time: 0.0143
ERROR - 2024-02-14 19:45:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:45:17 --> Config Class Initialized
INFO - 2024-02-14 19:45:17 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:45:17 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:45:17 --> Utf8 Class Initialized
INFO - 2024-02-14 19:45:17 --> URI Class Initialized
INFO - 2024-02-14 19:45:17 --> Router Class Initialized
INFO - 2024-02-14 19:45:17 --> Output Class Initialized
INFO - 2024-02-14 19:45:17 --> Security Class Initialized
DEBUG - 2024-02-14 19:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:45:17 --> Input Class Initialized
INFO - 2024-02-14 19:45:17 --> Language Class Initialized
INFO - 2024-02-14 19:45:17 --> Loader Class Initialized
INFO - 2024-02-14 19:45:17 --> Helper loaded: url_helper
INFO - 2024-02-14 19:45:17 --> Helper loaded: file_helper
INFO - 2024-02-14 19:45:17 --> Helper loaded: form_helper
INFO - 2024-02-14 19:45:17 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:45:17 --> Controller Class Initialized
INFO - 2024-02-14 19:45:17 --> Form Validation Class Initialized
INFO - 2024-02-14 19:45:17 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:45:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:45:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:45:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:45:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:45:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:45:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:45:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:45:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:45:17 --> Final output sent to browser
DEBUG - 2024-02-14 19:45:17 --> Total execution time: 0.0217
ERROR - 2024-02-14 19:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:55:36 --> Config Class Initialized
INFO - 2024-02-14 19:55:36 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:55:36 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:55:36 --> Utf8 Class Initialized
INFO - 2024-02-14 19:55:36 --> URI Class Initialized
INFO - 2024-02-14 19:55:36 --> Router Class Initialized
INFO - 2024-02-14 19:55:36 --> Output Class Initialized
INFO - 2024-02-14 19:55:36 --> Security Class Initialized
DEBUG - 2024-02-14 19:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:55:36 --> Input Class Initialized
INFO - 2024-02-14 19:55:36 --> Language Class Initialized
INFO - 2024-02-14 19:55:36 --> Loader Class Initialized
INFO - 2024-02-14 19:55:36 --> Helper loaded: url_helper
INFO - 2024-02-14 19:55:36 --> Helper loaded: file_helper
INFO - 2024-02-14 19:55:36 --> Helper loaded: form_helper
INFO - 2024-02-14 19:55:36 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:55:36 --> Controller Class Initialized
INFO - 2024-02-14 19:55:36 --> Form Validation Class Initialized
INFO - 2024-02-14 19:55:36 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:55:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:55:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:55:36 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:55:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:55:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:55:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:55:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:55:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:55:36 --> Final output sent to browser
DEBUG - 2024-02-14 19:55:36 --> Total execution time: 0.0211
ERROR - 2024-02-14 19:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:55:36 --> Config Class Initialized
INFO - 2024-02-14 19:55:36 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:55:36 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:55:36 --> Utf8 Class Initialized
INFO - 2024-02-14 19:55:36 --> URI Class Initialized
INFO - 2024-02-14 19:55:36 --> Router Class Initialized
INFO - 2024-02-14 19:55:36 --> Output Class Initialized
INFO - 2024-02-14 19:55:36 --> Security Class Initialized
DEBUG - 2024-02-14 19:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:55:36 --> Input Class Initialized
INFO - 2024-02-14 19:55:36 --> Language Class Initialized
INFO - 2024-02-14 19:55:36 --> Loader Class Initialized
INFO - 2024-02-14 19:55:36 --> Helper loaded: url_helper
INFO - 2024-02-14 19:55:36 --> Helper loaded: file_helper
INFO - 2024-02-14 19:55:36 --> Helper loaded: form_helper
INFO - 2024-02-14 19:55:36 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:55:36 --> Controller Class Initialized
INFO - 2024-02-14 19:55:36 --> Form Validation Class Initialized
INFO - 2024-02-14 19:55:36 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:55:36 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:55:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:55:36 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-14 19:55:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:55:40 --> Config Class Initialized
INFO - 2024-02-14 19:55:40 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:55:40 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:55:40 --> Utf8 Class Initialized
INFO - 2024-02-14 19:55:40 --> URI Class Initialized
INFO - 2024-02-14 19:55:40 --> Router Class Initialized
INFO - 2024-02-14 19:55:40 --> Output Class Initialized
INFO - 2024-02-14 19:55:40 --> Security Class Initialized
DEBUG - 2024-02-14 19:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:55:40 --> Input Class Initialized
INFO - 2024-02-14 19:55:40 --> Language Class Initialized
INFO - 2024-02-14 19:55:40 --> Loader Class Initialized
INFO - 2024-02-14 19:55:40 --> Helper loaded: url_helper
INFO - 2024-02-14 19:55:40 --> Helper loaded: file_helper
INFO - 2024-02-14 19:55:40 --> Helper loaded: form_helper
INFO - 2024-02-14 19:55:40 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:55:40 --> Controller Class Initialized
INFO - 2024-02-14 19:55:40 --> Form Validation Class Initialized
INFO - 2024-02-14 19:55:40 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:55:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:55:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:55:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:55:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-14 19:55:40 --> Final output sent to browser
DEBUG - 2024-02-14 19:55:40 --> Total execution time: 0.0157
ERROR - 2024-02-14 19:55:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:55:44 --> Config Class Initialized
INFO - 2024-02-14 19:55:44 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:55:44 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:55:44 --> Utf8 Class Initialized
INFO - 2024-02-14 19:55:44 --> URI Class Initialized
INFO - 2024-02-14 19:55:44 --> Router Class Initialized
INFO - 2024-02-14 19:55:44 --> Output Class Initialized
INFO - 2024-02-14 19:55:44 --> Security Class Initialized
DEBUG - 2024-02-14 19:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:55:44 --> Input Class Initialized
INFO - 2024-02-14 19:55:44 --> Language Class Initialized
INFO - 2024-02-14 19:55:44 --> Loader Class Initialized
INFO - 2024-02-14 19:55:44 --> Helper loaded: url_helper
INFO - 2024-02-14 19:55:44 --> Helper loaded: file_helper
INFO - 2024-02-14 19:55:44 --> Helper loaded: form_helper
INFO - 2024-02-14 19:55:44 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:55:44 --> Controller Class Initialized
INFO - 2024-02-14 19:55:44 --> Form Validation Class Initialized
INFO - 2024-02-14 19:55:44 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:55:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:55:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:55:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:55:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:55:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:55:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:55:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:55:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:55:44 --> Final output sent to browser
DEBUG - 2024-02-14 19:55:44 --> Total execution time: 0.0183
ERROR - 2024-02-14 19:55:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:55:44 --> Config Class Initialized
INFO - 2024-02-14 19:55:44 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:55:44 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:55:44 --> Utf8 Class Initialized
INFO - 2024-02-14 19:55:44 --> URI Class Initialized
INFO - 2024-02-14 19:55:44 --> Router Class Initialized
INFO - 2024-02-14 19:55:44 --> Output Class Initialized
INFO - 2024-02-14 19:55:44 --> Security Class Initialized
DEBUG - 2024-02-14 19:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:55:44 --> Input Class Initialized
INFO - 2024-02-14 19:55:44 --> Language Class Initialized
INFO - 2024-02-14 19:55:44 --> Loader Class Initialized
INFO - 2024-02-14 19:55:44 --> Helper loaded: url_helper
INFO - 2024-02-14 19:55:44 --> Helper loaded: file_helper
INFO - 2024-02-14 19:55:44 --> Helper loaded: form_helper
INFO - 2024-02-14 19:55:44 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:55:44 --> Controller Class Initialized
INFO - 2024-02-14 19:55:44 --> Form Validation Class Initialized
INFO - 2024-02-14 19:55:44 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:55:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:55:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:55:44 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-14 19:55:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:55:47 --> Config Class Initialized
INFO - 2024-02-14 19:55:47 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:55:47 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:55:47 --> Utf8 Class Initialized
INFO - 2024-02-14 19:55:47 --> URI Class Initialized
INFO - 2024-02-14 19:55:47 --> Router Class Initialized
INFO - 2024-02-14 19:55:47 --> Output Class Initialized
INFO - 2024-02-14 19:55:47 --> Security Class Initialized
DEBUG - 2024-02-14 19:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:55:47 --> Input Class Initialized
INFO - 2024-02-14 19:55:47 --> Language Class Initialized
INFO - 2024-02-14 19:55:47 --> Loader Class Initialized
INFO - 2024-02-14 19:55:47 --> Helper loaded: url_helper
INFO - 2024-02-14 19:55:47 --> Helper loaded: file_helper
INFO - 2024-02-14 19:55:47 --> Helper loaded: form_helper
INFO - 2024-02-14 19:55:47 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:55:47 --> Controller Class Initialized
INFO - 2024-02-14 19:55:47 --> Form Validation Class Initialized
INFO - 2024-02-14 19:55:47 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:55:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:55:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:55:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:55:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-14 19:55:47 --> Final output sent to browser
DEBUG - 2024-02-14 19:55:47 --> Total execution time: 0.0152
ERROR - 2024-02-14 19:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:56:30 --> Config Class Initialized
INFO - 2024-02-14 19:56:30 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:56:30 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:56:30 --> Utf8 Class Initialized
INFO - 2024-02-14 19:56:30 --> URI Class Initialized
INFO - 2024-02-14 19:56:30 --> Router Class Initialized
INFO - 2024-02-14 19:56:30 --> Output Class Initialized
INFO - 2024-02-14 19:56:30 --> Security Class Initialized
DEBUG - 2024-02-14 19:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:56:30 --> Input Class Initialized
INFO - 2024-02-14 19:56:30 --> Language Class Initialized
INFO - 2024-02-14 19:56:30 --> Loader Class Initialized
INFO - 2024-02-14 19:56:30 --> Helper loaded: url_helper
INFO - 2024-02-14 19:56:30 --> Helper loaded: file_helper
INFO - 2024-02-14 19:56:30 --> Helper loaded: form_helper
INFO - 2024-02-14 19:56:30 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:56:30 --> Controller Class Initialized
INFO - 2024-02-14 19:56:30 --> Form Validation Class Initialized
INFO - 2024-02-14 19:56:30 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:56:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:56:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:56:30 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:56:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:56:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:56:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:56:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:56:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:56:30 --> Final output sent to browser
DEBUG - 2024-02-14 19:56:30 --> Total execution time: 0.0158
ERROR - 2024-02-14 19:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:56:30 --> Config Class Initialized
INFO - 2024-02-14 19:56:30 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:56:30 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:56:30 --> Utf8 Class Initialized
INFO - 2024-02-14 19:56:30 --> URI Class Initialized
INFO - 2024-02-14 19:56:30 --> Router Class Initialized
INFO - 2024-02-14 19:56:30 --> Output Class Initialized
INFO - 2024-02-14 19:56:30 --> Security Class Initialized
DEBUG - 2024-02-14 19:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:56:30 --> Input Class Initialized
INFO - 2024-02-14 19:56:30 --> Language Class Initialized
INFO - 2024-02-14 19:56:30 --> Loader Class Initialized
INFO - 2024-02-14 19:56:30 --> Helper loaded: url_helper
INFO - 2024-02-14 19:56:30 --> Helper loaded: file_helper
INFO - 2024-02-14 19:56:30 --> Helper loaded: form_helper
INFO - 2024-02-14 19:56:30 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:56:30 --> Controller Class Initialized
INFO - 2024-02-14 19:56:30 --> Form Validation Class Initialized
INFO - 2024-02-14 19:56:30 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:56:30 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:56:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:56:30 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-14 19:56:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:56:32 --> Config Class Initialized
INFO - 2024-02-14 19:56:32 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:56:32 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:56:32 --> Utf8 Class Initialized
INFO - 2024-02-14 19:56:32 --> URI Class Initialized
INFO - 2024-02-14 19:56:32 --> Router Class Initialized
INFO - 2024-02-14 19:56:32 --> Output Class Initialized
INFO - 2024-02-14 19:56:32 --> Security Class Initialized
DEBUG - 2024-02-14 19:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:56:32 --> Input Class Initialized
INFO - 2024-02-14 19:56:32 --> Language Class Initialized
INFO - 2024-02-14 19:56:32 --> Loader Class Initialized
INFO - 2024-02-14 19:56:32 --> Helper loaded: url_helper
INFO - 2024-02-14 19:56:32 --> Helper loaded: file_helper
INFO - 2024-02-14 19:56:32 --> Helper loaded: form_helper
INFO - 2024-02-14 19:56:32 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:56:32 --> Controller Class Initialized
INFO - 2024-02-14 19:56:32 --> Form Validation Class Initialized
INFO - 2024-02-14 19:56:32 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:56:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:56:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:56:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:56:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-14 19:56:32 --> Final output sent to browser
DEBUG - 2024-02-14 19:56:32 --> Total execution time: 0.0182
ERROR - 2024-02-14 19:58:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:58:02 --> Config Class Initialized
INFO - 2024-02-14 19:58:02 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:58:02 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:58:02 --> Utf8 Class Initialized
INFO - 2024-02-14 19:58:02 --> URI Class Initialized
INFO - 2024-02-14 19:58:02 --> Router Class Initialized
INFO - 2024-02-14 19:58:02 --> Output Class Initialized
INFO - 2024-02-14 19:58:02 --> Security Class Initialized
DEBUG - 2024-02-14 19:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:58:02 --> Input Class Initialized
INFO - 2024-02-14 19:58:02 --> Language Class Initialized
INFO - 2024-02-14 19:58:02 --> Loader Class Initialized
INFO - 2024-02-14 19:58:02 --> Helper loaded: url_helper
INFO - 2024-02-14 19:58:02 --> Helper loaded: file_helper
INFO - 2024-02-14 19:58:02 --> Helper loaded: form_helper
INFO - 2024-02-14 19:58:02 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:58:02 --> Controller Class Initialized
INFO - 2024-02-14 19:58:02 --> Form Validation Class Initialized
INFO - 2024-02-14 19:58:02 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:58:02 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:58:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:58:02 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:58:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:58:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:58:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:58:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:58:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:58:02 --> Final output sent to browser
DEBUG - 2024-02-14 19:58:02 --> Total execution time: 0.0145
ERROR - 2024-02-14 19:58:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:58:03 --> Config Class Initialized
INFO - 2024-02-14 19:58:03 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:58:03 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:58:03 --> Utf8 Class Initialized
INFO - 2024-02-14 19:58:03 --> URI Class Initialized
INFO - 2024-02-14 19:58:03 --> Router Class Initialized
INFO - 2024-02-14 19:58:03 --> Output Class Initialized
INFO - 2024-02-14 19:58:03 --> Security Class Initialized
DEBUG - 2024-02-14 19:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:58:03 --> Input Class Initialized
INFO - 2024-02-14 19:58:03 --> Language Class Initialized
INFO - 2024-02-14 19:58:03 --> Loader Class Initialized
INFO - 2024-02-14 19:58:03 --> Helper loaded: url_helper
INFO - 2024-02-14 19:58:03 --> Helper loaded: file_helper
INFO - 2024-02-14 19:58:03 --> Helper loaded: form_helper
INFO - 2024-02-14 19:58:03 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:58:03 --> Controller Class Initialized
INFO - 2024-02-14 19:58:03 --> Form Validation Class Initialized
INFO - 2024-02-14 19:58:03 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:58:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:58:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:58:03 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-14 19:58:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:58:05 --> Config Class Initialized
INFO - 2024-02-14 19:58:05 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:58:05 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:58:05 --> Utf8 Class Initialized
INFO - 2024-02-14 19:58:05 --> URI Class Initialized
INFO - 2024-02-14 19:58:05 --> Router Class Initialized
INFO - 2024-02-14 19:58:05 --> Output Class Initialized
INFO - 2024-02-14 19:58:05 --> Security Class Initialized
DEBUG - 2024-02-14 19:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:58:05 --> Input Class Initialized
INFO - 2024-02-14 19:58:05 --> Language Class Initialized
INFO - 2024-02-14 19:58:05 --> Loader Class Initialized
INFO - 2024-02-14 19:58:05 --> Helper loaded: url_helper
INFO - 2024-02-14 19:58:05 --> Helper loaded: file_helper
INFO - 2024-02-14 19:58:05 --> Helper loaded: form_helper
INFO - 2024-02-14 19:58:05 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:58:05 --> Controller Class Initialized
INFO - 2024-02-14 19:58:05 --> Form Validation Class Initialized
INFO - 2024-02-14 19:58:05 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:58:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:58:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:58:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:58:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-14 19:58:05 --> Final output sent to browser
DEBUG - 2024-02-14 19:58:05 --> Total execution time: 0.0144
ERROR - 2024-02-14 19:59:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:59:19 --> Config Class Initialized
INFO - 2024-02-14 19:59:19 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:59:19 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:59:19 --> Utf8 Class Initialized
INFO - 2024-02-14 19:59:19 --> URI Class Initialized
INFO - 2024-02-14 19:59:19 --> Router Class Initialized
INFO - 2024-02-14 19:59:19 --> Output Class Initialized
INFO - 2024-02-14 19:59:19 --> Security Class Initialized
DEBUG - 2024-02-14 19:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:59:19 --> Input Class Initialized
INFO - 2024-02-14 19:59:19 --> Language Class Initialized
INFO - 2024-02-14 19:59:19 --> Loader Class Initialized
INFO - 2024-02-14 19:59:19 --> Helper loaded: url_helper
INFO - 2024-02-14 19:59:19 --> Helper loaded: file_helper
INFO - 2024-02-14 19:59:19 --> Helper loaded: form_helper
INFO - 2024-02-14 19:59:19 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:59:19 --> Controller Class Initialized
INFO - 2024-02-14 19:59:19 --> Form Validation Class Initialized
INFO - 2024-02-14 19:59:19 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:59:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:59:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:59:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:59:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:59:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:59:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:59:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:59:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:59:19 --> Final output sent to browser
DEBUG - 2024-02-14 19:59:19 --> Total execution time: 0.0238
ERROR - 2024-02-14 19:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:59:20 --> Config Class Initialized
INFO - 2024-02-14 19:59:20 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:59:20 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:59:20 --> Utf8 Class Initialized
INFO - 2024-02-14 19:59:20 --> URI Class Initialized
INFO - 2024-02-14 19:59:20 --> Router Class Initialized
INFO - 2024-02-14 19:59:20 --> Output Class Initialized
INFO - 2024-02-14 19:59:20 --> Security Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:59:20 --> Input Class Initialized
INFO - 2024-02-14 19:59:20 --> Language Class Initialized
INFO - 2024-02-14 19:59:20 --> Loader Class Initialized
INFO - 2024-02-14 19:59:20 --> Helper loaded: url_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: file_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: form_helper
INFO - 2024-02-14 19:59:20 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:59:20 --> Controller Class Initialized
INFO - 2024-02-14 19:59:20 --> Form Validation Class Initialized
INFO - 2024-02-14 19:59:20 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-14 19:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:59:20 --> Config Class Initialized
INFO - 2024-02-14 19:59:20 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:59:20 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:59:20 --> Utf8 Class Initialized
INFO - 2024-02-14 19:59:20 --> URI Class Initialized
INFO - 2024-02-14 19:59:20 --> Router Class Initialized
INFO - 2024-02-14 19:59:20 --> Output Class Initialized
INFO - 2024-02-14 19:59:20 --> Security Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:59:20 --> Input Class Initialized
INFO - 2024-02-14 19:59:20 --> Language Class Initialized
INFO - 2024-02-14 19:59:20 --> Loader Class Initialized
INFO - 2024-02-14 19:59:20 --> Helper loaded: url_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: file_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: form_helper
INFO - 2024-02-14 19:59:20 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:59:20 --> Controller Class Initialized
INFO - 2024-02-14 19:59:20 --> Form Validation Class Initialized
INFO - 2024-02-14 19:59:20 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
ERROR - 2024-02-14 19:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:59:20 --> Final output sent to browser
DEBUG - 2024-02-14 19:59:20 --> Total execution time: 0.0309
INFO - 2024-02-14 19:59:20 --> Config Class Initialized
INFO - 2024-02-14 19:59:20 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:59:20 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:59:20 --> Utf8 Class Initialized
INFO - 2024-02-14 19:59:20 --> URI Class Initialized
INFO - 2024-02-14 19:59:20 --> Router Class Initialized
INFO - 2024-02-14 19:59:20 --> Output Class Initialized
INFO - 2024-02-14 19:59:20 --> Security Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:59:20 --> Input Class Initialized
INFO - 2024-02-14 19:59:20 --> Language Class Initialized
INFO - 2024-02-14 19:59:20 --> Loader Class Initialized
INFO - 2024-02-14 19:59:20 --> Helper loaded: url_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: file_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: form_helper
INFO - 2024-02-14 19:59:20 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:59:20 --> Controller Class Initialized
INFO - 2024-02-14 19:59:20 --> Form Validation Class Initialized
INFO - 2024-02-14 19:59:20 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:59:20 --> Final output sent to browser
DEBUG - 2024-02-14 19:59:20 --> Total execution time: 0.0205
ERROR - 2024-02-14 19:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:59:20 --> Config Class Initialized
INFO - 2024-02-14 19:59:20 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:59:20 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:59:20 --> Utf8 Class Initialized
INFO - 2024-02-14 19:59:20 --> URI Class Initialized
INFO - 2024-02-14 19:59:20 --> Router Class Initialized
INFO - 2024-02-14 19:59:20 --> Output Class Initialized
INFO - 2024-02-14 19:59:20 --> Security Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:59:20 --> Input Class Initialized
INFO - 2024-02-14 19:59:20 --> Language Class Initialized
INFO - 2024-02-14 19:59:20 --> Loader Class Initialized
INFO - 2024-02-14 19:59:20 --> Helper loaded: url_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: file_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: form_helper
INFO - 2024-02-14 19:59:20 --> Database Driver Class Initialized
ERROR - 2024-02-14 19:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:59:20 --> Config Class Initialized
INFO - 2024-02-14 19:59:20 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:59:20 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:59:20 --> Utf8 Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:59:20 --> URI Class Initialized
INFO - 2024-02-14 19:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:59:20 --> Controller Class Initialized
INFO - 2024-02-14 19:59:20 --> Router Class Initialized
INFO - 2024-02-14 19:59:20 --> Form Validation Class Initialized
INFO - 2024-02-14 19:59:20 --> Output Class Initialized
INFO - 2024-02-14 19:59:20 --> Security Class Initialized
INFO - 2024-02-14 19:59:20 --> Model "MasterModel" initialized
DEBUG - 2024-02-14 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:59:20 --> Input Class Initialized
INFO - 2024-02-14 19:59:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Language Class Initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:59:20 --> Loader Class Initialized
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:59:20 --> Helper loaded: url_helper
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:59:20 --> Final output sent to browser
INFO - 2024-02-14 19:59:20 --> Helper loaded: file_helper
DEBUG - 2024-02-14 19:59:20 --> Total execution time: 0.0451
INFO - 2024-02-14 19:59:20 --> Helper loaded: form_helper
INFO - 2024-02-14 19:59:20 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:59:20 --> Controller Class Initialized
INFO - 2024-02-14 19:59:20 --> Form Validation Class Initialized
INFO - 2024-02-14 19:59:20 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:59:20 --> Final output sent to browser
DEBUG - 2024-02-14 19:59:20 --> Total execution time: 0.0379
ERROR - 2024-02-14 19:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:59:20 --> Config Class Initialized
INFO - 2024-02-14 19:59:20 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:59:20 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:59:20 --> Utf8 Class Initialized
INFO - 2024-02-14 19:59:20 --> URI Class Initialized
INFO - 2024-02-14 19:59:20 --> Router Class Initialized
INFO - 2024-02-14 19:59:20 --> Output Class Initialized
INFO - 2024-02-14 19:59:20 --> Security Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:59:20 --> Input Class Initialized
INFO - 2024-02-14 19:59:20 --> Language Class Initialized
INFO - 2024-02-14 19:59:20 --> Loader Class Initialized
INFO - 2024-02-14 19:59:20 --> Helper loaded: url_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: file_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: form_helper
INFO - 2024-02-14 19:59:20 --> Database Driver Class Initialized
ERROR - 2024-02-14 19:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:59:20 --> Config Class Initialized
INFO - 2024-02-14 19:59:20 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:59:20 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:59:20 --> Utf8 Class Initialized
INFO - 2024-02-14 19:59:20 --> URI Class Initialized
INFO - 2024-02-14 19:59:20 --> Router Class Initialized
INFO - 2024-02-14 19:59:20 --> Output Class Initialized
INFO - 2024-02-14 19:59:20 --> Security Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:59:20 --> Input Class Initialized
INFO - 2024-02-14 19:59:20 --> Language Class Initialized
INFO - 2024-02-14 19:59:20 --> Loader Class Initialized
INFO - 2024-02-14 19:59:20 --> Helper loaded: url_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: file_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: form_helper
DEBUG - 2024-02-14 19:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:59:20 --> Controller Class Initialized
INFO - 2024-02-14 19:59:20 --> Database Driver Class Initialized
INFO - 2024-02-14 19:59:20 --> Form Validation Class Initialized
INFO - 2024-02-14 19:59:20 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemCategoryModel" initialized
DEBUG - 2024-02-14 19:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:59:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:59:20 --> Final output sent to browser
DEBUG - 2024-02-14 19:59:20 --> Total execution time: 0.0352
INFO - 2024-02-14 19:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:59:20 --> Controller Class Initialized
INFO - 2024-02-14 19:59:20 --> Form Validation Class Initialized
INFO - 2024-02-14 19:59:20 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:59:20 --> Final output sent to browser
DEBUG - 2024-02-14 19:59:20 --> Total execution time: 0.0260
ERROR - 2024-02-14 19:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:59:20 --> Config Class Initialized
INFO - 2024-02-14 19:59:20 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:59:20 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:59:20 --> Utf8 Class Initialized
INFO - 2024-02-14 19:59:20 --> URI Class Initialized
INFO - 2024-02-14 19:59:20 --> Router Class Initialized
INFO - 2024-02-14 19:59:20 --> Output Class Initialized
INFO - 2024-02-14 19:59:20 --> Security Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:59:20 --> Input Class Initialized
INFO - 2024-02-14 19:59:20 --> Language Class Initialized
INFO - 2024-02-14 19:59:20 --> Loader Class Initialized
INFO - 2024-02-14 19:59:20 --> Helper loaded: url_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: file_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: form_helper
INFO - 2024-02-14 19:59:20 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:59:20 --> Controller Class Initialized
INFO - 2024-02-14 19:59:20 --> Form Validation Class Initialized
INFO - 2024-02-14 19:59:20 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:59:20 --> Final output sent to browser
DEBUG - 2024-02-14 19:59:20 --> Total execution time: 0.0460
ERROR - 2024-02-14 19:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:59:20 --> Config Class Initialized
INFO - 2024-02-14 19:59:20 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:59:20 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:59:20 --> Utf8 Class Initialized
INFO - 2024-02-14 19:59:20 --> URI Class Initialized
INFO - 2024-02-14 19:59:20 --> Router Class Initialized
INFO - 2024-02-14 19:59:20 --> Output Class Initialized
INFO - 2024-02-14 19:59:20 --> Security Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:59:20 --> Input Class Initialized
INFO - 2024-02-14 19:59:20 --> Language Class Initialized
INFO - 2024-02-14 19:59:20 --> Loader Class Initialized
INFO - 2024-02-14 19:59:20 --> Helper loaded: url_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: file_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: form_helper
INFO - 2024-02-14 19:59:20 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:59:20 --> Controller Class Initialized
INFO - 2024-02-14 19:59:20 --> Form Validation Class Initialized
INFO - 2024-02-14 19:59:20 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-14 19:59:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/index.php
INFO - 2024-02-14 19:59:20 --> Final output sent to browser
DEBUG - 2024-02-14 19:59:20 --> Total execution time: 0.0318
ERROR - 2024-02-14 19:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:59:20 --> Config Class Initialized
INFO - 2024-02-14 19:59:20 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:59:20 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:59:20 --> Utf8 Class Initialized
INFO - 2024-02-14 19:59:20 --> URI Class Initialized
INFO - 2024-02-14 19:59:20 --> Router Class Initialized
INFO - 2024-02-14 19:59:20 --> Output Class Initialized
INFO - 2024-02-14 19:59:20 --> Security Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:59:20 --> Input Class Initialized
INFO - 2024-02-14 19:59:20 --> Language Class Initialized
INFO - 2024-02-14 19:59:20 --> Loader Class Initialized
INFO - 2024-02-14 19:59:20 --> Helper loaded: url_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: file_helper
INFO - 2024-02-14 19:59:20 --> Helper loaded: form_helper
INFO - 2024-02-14 19:59:20 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:59:20 --> Controller Class Initialized
INFO - 2024-02-14 19:59:20 --> Form Validation Class Initialized
INFO - 2024-02-14 19:59:20 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:59:20 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-14 19:59:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 19:59:24 --> Config Class Initialized
INFO - 2024-02-14 19:59:24 --> Hooks Class Initialized
DEBUG - 2024-02-14 19:59:24 --> UTF-8 Support Enabled
INFO - 2024-02-14 19:59:24 --> Utf8 Class Initialized
INFO - 2024-02-14 19:59:24 --> URI Class Initialized
INFO - 2024-02-14 19:59:24 --> Router Class Initialized
INFO - 2024-02-14 19:59:24 --> Output Class Initialized
INFO - 2024-02-14 19:59:24 --> Security Class Initialized
DEBUG - 2024-02-14 19:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 19:59:24 --> Input Class Initialized
INFO - 2024-02-14 19:59:24 --> Language Class Initialized
INFO - 2024-02-14 19:59:24 --> Loader Class Initialized
INFO - 2024-02-14 19:59:24 --> Helper loaded: url_helper
INFO - 2024-02-14 19:59:24 --> Helper loaded: file_helper
INFO - 2024-02-14 19:59:24 --> Helper loaded: form_helper
INFO - 2024-02-14 19:59:24 --> Database Driver Class Initialized
DEBUG - 2024-02-14 19:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 19:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 19:59:24 --> Controller Class Initialized
INFO - 2024-02-14 19:59:24 --> Form Validation Class Initialized
INFO - 2024-02-14 19:59:24 --> Model "MasterModel" initialized
INFO - 2024-02-14 19:59:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 19:59:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 19:59:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 19:59:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-14 19:59:24 --> Final output sent to browser
DEBUG - 2024-02-14 19:59:24 --> Total execution time: 0.0137
ERROR - 2024-02-14 20:19:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 20:19:52 --> Config Class Initialized
INFO - 2024-02-14 20:19:52 --> Hooks Class Initialized
DEBUG - 2024-02-14 20:19:52 --> UTF-8 Support Enabled
INFO - 2024-02-14 20:19:52 --> Utf8 Class Initialized
INFO - 2024-02-14 20:19:52 --> URI Class Initialized
INFO - 2024-02-14 20:19:52 --> Router Class Initialized
INFO - 2024-02-14 20:19:52 --> Output Class Initialized
INFO - 2024-02-14 20:19:52 --> Security Class Initialized
DEBUG - 2024-02-14 20:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 20:19:52 --> Input Class Initialized
INFO - 2024-02-14 20:19:52 --> Language Class Initialized
INFO - 2024-02-14 20:19:52 --> Loader Class Initialized
INFO - 2024-02-14 20:19:52 --> Helper loaded: url_helper
INFO - 2024-02-14 20:19:52 --> Helper loaded: file_helper
INFO - 2024-02-14 20:19:52 --> Helper loaded: form_helper
INFO - 2024-02-14 20:19:53 --> Database Driver Class Initialized
DEBUG - 2024-02-14 20:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 20:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 20:19:53 --> Controller Class Initialized
INFO - 2024-02-14 20:19:53 --> Model "LoginModel" initialized
INFO - 2024-02-14 20:19:53 --> Form Validation Class Initialized
INFO - 2024-02-14 20:19:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-14 20:19:53 --> Final output sent to browser
DEBUG - 2024-02-14 20:19:53 --> Total execution time: 0.0168
ERROR - 2024-02-14 20:47:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-14 20:47:33 --> Config Class Initialized
INFO - 2024-02-14 20:47:33 --> Hooks Class Initialized
DEBUG - 2024-02-14 20:47:33 --> UTF-8 Support Enabled
INFO - 2024-02-14 20:47:33 --> Utf8 Class Initialized
INFO - 2024-02-14 20:47:33 --> URI Class Initialized
INFO - 2024-02-14 20:47:33 --> Router Class Initialized
INFO - 2024-02-14 20:47:33 --> Output Class Initialized
INFO - 2024-02-14 20:47:33 --> Security Class Initialized
DEBUG - 2024-02-14 20:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-14 20:47:33 --> Input Class Initialized
INFO - 2024-02-14 20:47:33 --> Language Class Initialized
INFO - 2024-02-14 20:47:33 --> Loader Class Initialized
INFO - 2024-02-14 20:47:33 --> Helper loaded: url_helper
INFO - 2024-02-14 20:47:33 --> Helper loaded: file_helper
INFO - 2024-02-14 20:47:33 --> Helper loaded: form_helper
INFO - 2024-02-14 20:47:33 --> Database Driver Class Initialized
DEBUG - 2024-02-14 20:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-14 20:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-14 20:47:33 --> Controller Class Initialized
INFO - 2024-02-14 20:47:33 --> Form Validation Class Initialized
INFO - 2024-02-14 20:47:33 --> Model "MasterModel" initialized
INFO - 2024-02-14 20:47:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-14 20:47:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-14 20:47:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-14 20:47:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/item_master/form.php
INFO - 2024-02-14 20:47:33 --> Final output sent to browser
DEBUG - 2024-02-14 20:47:33 --> Total execution time: 0.0267
