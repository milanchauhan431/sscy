<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-12 18:15:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:15:30 --> Config Class Initialized
INFO - 2024-03-12 18:15:30 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:15:30 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:15:30 --> Utf8 Class Initialized
INFO - 2024-03-12 18:15:30 --> URI Class Initialized
INFO - 2024-03-12 18:15:30 --> Router Class Initialized
INFO - 2024-03-12 18:15:30 --> Output Class Initialized
INFO - 2024-03-12 18:15:30 --> Security Class Initialized
DEBUG - 2024-03-12 18:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:15:30 --> Input Class Initialized
INFO - 2024-03-12 18:15:30 --> Language Class Initialized
INFO - 2024-03-12 18:15:30 --> Loader Class Initialized
INFO - 2024-03-12 18:15:30 --> Helper loaded: url_helper
INFO - 2024-03-12 18:15:30 --> Helper loaded: file_helper
INFO - 2024-03-12 18:15:30 --> Helper loaded: form_helper
INFO - 2024-03-12 18:15:30 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:15:30 --> Controller Class Initialized
INFO - 2024-03-12 18:15:30 --> Model "LoginModel" initialized
INFO - 2024-03-12 18:15:30 --> Form Validation Class Initialized
INFO - 2024-03-12 18:15:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-12 18:15:30 --> Final output sent to browser
DEBUG - 2024-03-12 18:15:30 --> Total execution time: 0.0336
ERROR - 2024-03-12 18:15:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:15:33 --> Config Class Initialized
INFO - 2024-03-12 18:15:33 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:15:33 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:15:33 --> Utf8 Class Initialized
INFO - 2024-03-12 18:15:33 --> URI Class Initialized
DEBUG - 2024-03-12 18:15:33 --> No URI present. Default controller set.
INFO - 2024-03-12 18:15:33 --> Router Class Initialized
INFO - 2024-03-12 18:15:33 --> Output Class Initialized
INFO - 2024-03-12 18:15:33 --> Security Class Initialized
DEBUG - 2024-03-12 18:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:15:33 --> Input Class Initialized
INFO - 2024-03-12 18:15:33 --> Language Class Initialized
INFO - 2024-03-12 18:15:33 --> Loader Class Initialized
INFO - 2024-03-12 18:15:33 --> Helper loaded: url_helper
INFO - 2024-03-12 18:15:33 --> Helper loaded: file_helper
INFO - 2024-03-12 18:15:33 --> Helper loaded: form_helper
INFO - 2024-03-12 18:15:33 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:15:33 --> Controller Class Initialized
INFO - 2024-03-12 18:15:33 --> Model "LoginModel" initialized
INFO - 2024-03-12 18:15:33 --> Form Validation Class Initialized
INFO - 2024-03-12 18:15:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-12 18:15:33 --> Final output sent to browser
DEBUG - 2024-03-12 18:15:33 --> Total execution time: 0.0270
ERROR - 2024-03-12 18:15:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:15:45 --> Config Class Initialized
INFO - 2024-03-12 18:15:45 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:15:45 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:15:45 --> Utf8 Class Initialized
INFO - 2024-03-12 18:15:45 --> URI Class Initialized
INFO - 2024-03-12 18:15:45 --> Router Class Initialized
INFO - 2024-03-12 18:15:45 --> Output Class Initialized
INFO - 2024-03-12 18:15:45 --> Security Class Initialized
DEBUG - 2024-03-12 18:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:15:45 --> Input Class Initialized
INFO - 2024-03-12 18:15:45 --> Language Class Initialized
INFO - 2024-03-12 18:15:45 --> Loader Class Initialized
INFO - 2024-03-12 18:15:45 --> Helper loaded: url_helper
INFO - 2024-03-12 18:15:45 --> Helper loaded: file_helper
INFO - 2024-03-12 18:15:45 --> Helper loaded: form_helper
INFO - 2024-03-12 18:15:45 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:15:45 --> Controller Class Initialized
INFO - 2024-03-12 18:15:45 --> Model "LoginModel" initialized
INFO - 2024-03-12 18:15:45 --> Form Validation Class Initialized
INFO - 2024-03-12 18:15:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-03-12 18:15:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:15:45 --> Config Class Initialized
INFO - 2024-03-12 18:15:45 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:15:45 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:15:45 --> Utf8 Class Initialized
INFO - 2024-03-12 18:15:45 --> URI Class Initialized
INFO - 2024-03-12 18:15:45 --> Router Class Initialized
INFO - 2024-03-12 18:15:45 --> Output Class Initialized
INFO - 2024-03-12 18:15:45 --> Security Class Initialized
DEBUG - 2024-03-12 18:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:15:45 --> Input Class Initialized
INFO - 2024-03-12 18:15:45 --> Language Class Initialized
INFO - 2024-03-12 18:15:45 --> Loader Class Initialized
INFO - 2024-03-12 18:15:45 --> Helper loaded: url_helper
INFO - 2024-03-12 18:15:45 --> Helper loaded: file_helper
INFO - 2024-03-12 18:15:45 --> Helper loaded: form_helper
INFO - 2024-03-12 18:15:45 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:15:45 --> Controller Class Initialized
INFO - 2024-03-12 18:15:45 --> Form Validation Class Initialized
INFO - 2024-03-12 18:15:45 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:15:45 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:15:45 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:15:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:15:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:15:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:15:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:15:45 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:15:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:15:45 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:15:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:15:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-12 18:15:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:15:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:15:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:15:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:15:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-12 18:15:45 --> Final output sent to browser
DEBUG - 2024-03-12 18:15:45 --> Total execution time: 0.0309
ERROR - 2024-03-12 18:15:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:15:46 --> Config Class Initialized
INFO - 2024-03-12 18:15:46 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:15:46 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:15:46 --> Utf8 Class Initialized
INFO - 2024-03-12 18:15:46 --> URI Class Initialized
INFO - 2024-03-12 18:15:46 --> Router Class Initialized
INFO - 2024-03-12 18:15:46 --> Output Class Initialized
INFO - 2024-03-12 18:15:46 --> Security Class Initialized
DEBUG - 2024-03-12 18:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:15:46 --> Input Class Initialized
INFO - 2024-03-12 18:15:46 --> Language Class Initialized
INFO - 2024-03-12 18:15:46 --> Loader Class Initialized
INFO - 2024-03-12 18:15:46 --> Helper loaded: url_helper
INFO - 2024-03-12 18:15:46 --> Helper loaded: file_helper
INFO - 2024-03-12 18:15:46 --> Helper loaded: form_helper
INFO - 2024-03-12 18:15:46 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:15:46 --> Controller Class Initialized
INFO - 2024-03-12 18:15:46 --> Form Validation Class Initialized
INFO - 2024-03-12 18:15:46 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:15:46 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:15:46 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:15:46 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:15:46 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:15:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:15:46 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:15:46 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:15:46 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:15:46 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:15:49 --> Config Class Initialized
INFO - 2024-03-12 18:15:49 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:15:49 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:15:49 --> Utf8 Class Initialized
INFO - 2024-03-12 18:15:49 --> URI Class Initialized
INFO - 2024-03-12 18:15:49 --> Router Class Initialized
INFO - 2024-03-12 18:15:49 --> Output Class Initialized
INFO - 2024-03-12 18:15:49 --> Security Class Initialized
DEBUG - 2024-03-12 18:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:15:49 --> Input Class Initialized
INFO - 2024-03-12 18:15:49 --> Language Class Initialized
INFO - 2024-03-12 18:15:49 --> Loader Class Initialized
INFO - 2024-03-12 18:15:49 --> Helper loaded: url_helper
INFO - 2024-03-12 18:15:49 --> Helper loaded: file_helper
INFO - 2024-03-12 18:15:49 --> Helper loaded: form_helper
INFO - 2024-03-12 18:15:49 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:15:49 --> Controller Class Initialized
INFO - 2024-03-12 18:15:49 --> Form Validation Class Initialized
INFO - 2024-03-12 18:15:49 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:15:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:15:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:15:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:15:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:15:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:15:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-12 18:15:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-12 18:15:49 --> Final output sent to browser
DEBUG - 2024-03-12 18:15:49 --> Total execution time: 0.0318
ERROR - 2024-03-12 18:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:15:49 --> Config Class Initialized
INFO - 2024-03-12 18:15:49 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:15:49 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:15:49 --> Utf8 Class Initialized
INFO - 2024-03-12 18:15:49 --> URI Class Initialized
INFO - 2024-03-12 18:15:49 --> Router Class Initialized
INFO - 2024-03-12 18:15:49 --> Output Class Initialized
INFO - 2024-03-12 18:15:49 --> Security Class Initialized
DEBUG - 2024-03-12 18:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:15:49 --> Input Class Initialized
INFO - 2024-03-12 18:15:49 --> Language Class Initialized
INFO - 2024-03-12 18:15:49 --> Loader Class Initialized
INFO - 2024-03-12 18:15:49 --> Helper loaded: url_helper
INFO - 2024-03-12 18:15:49 --> Helper loaded: file_helper
INFO - 2024-03-12 18:15:49 --> Helper loaded: form_helper
INFO - 2024-03-12 18:15:49 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:15:49 --> Controller Class Initialized
INFO - 2024-03-12 18:15:49 --> Form Validation Class Initialized
INFO - 2024-03-12 18:15:49 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:15:49 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:15:51 --> Config Class Initialized
INFO - 2024-03-12 18:15:51 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:15:51 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:15:51 --> Utf8 Class Initialized
INFO - 2024-03-12 18:15:51 --> URI Class Initialized
INFO - 2024-03-12 18:15:51 --> Router Class Initialized
INFO - 2024-03-12 18:15:51 --> Output Class Initialized
INFO - 2024-03-12 18:15:51 --> Security Class Initialized
DEBUG - 2024-03-12 18:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:15:51 --> Input Class Initialized
INFO - 2024-03-12 18:15:51 --> Language Class Initialized
INFO - 2024-03-12 18:15:51 --> Loader Class Initialized
INFO - 2024-03-12 18:15:51 --> Helper loaded: url_helper
INFO - 2024-03-12 18:15:51 --> Helper loaded: file_helper
INFO - 2024-03-12 18:15:51 --> Helper loaded: form_helper
INFO - 2024-03-12 18:15:51 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:15:51 --> Controller Class Initialized
INFO - 2024-03-12 18:15:51 --> Form Validation Class Initialized
INFO - 2024-03-12 18:15:51 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:15:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:15:51 --> Final output sent to browser
DEBUG - 2024-03-12 18:15:51 --> Total execution time: 0.0379
ERROR - 2024-03-12 18:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:15:51 --> Config Class Initialized
INFO - 2024-03-12 18:15:51 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:15:51 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:15:51 --> Utf8 Class Initialized
INFO - 2024-03-12 18:15:51 --> URI Class Initialized
INFO - 2024-03-12 18:15:51 --> Router Class Initialized
INFO - 2024-03-12 18:15:51 --> Output Class Initialized
INFO - 2024-03-12 18:15:51 --> Security Class Initialized
DEBUG - 2024-03-12 18:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:15:51 --> Input Class Initialized
INFO - 2024-03-12 18:15:51 --> Language Class Initialized
INFO - 2024-03-12 18:15:51 --> Loader Class Initialized
INFO - 2024-03-12 18:15:51 --> Helper loaded: url_helper
INFO - 2024-03-12 18:15:51 --> Helper loaded: file_helper
INFO - 2024-03-12 18:15:51 --> Helper loaded: form_helper
INFO - 2024-03-12 18:15:51 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:15:51 --> Controller Class Initialized
INFO - 2024-03-12 18:15:51 --> Form Validation Class Initialized
INFO - 2024-03-12 18:15:51 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:15:51 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:15:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:15:54 --> Config Class Initialized
INFO - 2024-03-12 18:15:54 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:15:54 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:15:54 --> Utf8 Class Initialized
INFO - 2024-03-12 18:15:54 --> URI Class Initialized
INFO - 2024-03-12 18:15:54 --> Router Class Initialized
INFO - 2024-03-12 18:15:54 --> Output Class Initialized
INFO - 2024-03-12 18:15:54 --> Security Class Initialized
DEBUG - 2024-03-12 18:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:15:54 --> Input Class Initialized
INFO - 2024-03-12 18:15:54 --> Language Class Initialized
INFO - 2024-03-12 18:15:54 --> Loader Class Initialized
INFO - 2024-03-12 18:15:54 --> Helper loaded: url_helper
INFO - 2024-03-12 18:15:54 --> Helper loaded: file_helper
INFO - 2024-03-12 18:15:54 --> Helper loaded: form_helper
INFO - 2024-03-12 18:15:54 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:15:54 --> Controller Class Initialized
INFO - 2024-03-12 18:15:54 --> Form Validation Class Initialized
INFO - 2024-03-12 18:15:54 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:15:54 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:15:54 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:15:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:15:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:15:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:15:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:15:54 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:15:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:15:54 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:15:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:15:57 --> Config Class Initialized
INFO - 2024-03-12 18:15:57 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:15:57 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:15:57 --> Utf8 Class Initialized
INFO - 2024-03-12 18:15:57 --> URI Class Initialized
INFO - 2024-03-12 18:15:57 --> Router Class Initialized
INFO - 2024-03-12 18:15:57 --> Output Class Initialized
INFO - 2024-03-12 18:15:57 --> Security Class Initialized
DEBUG - 2024-03-12 18:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:15:57 --> Input Class Initialized
INFO - 2024-03-12 18:15:57 --> Language Class Initialized
INFO - 2024-03-12 18:15:57 --> Loader Class Initialized
INFO - 2024-03-12 18:15:57 --> Helper loaded: url_helper
INFO - 2024-03-12 18:15:57 --> Helper loaded: file_helper
INFO - 2024-03-12 18:15:57 --> Helper loaded: form_helper
INFO - 2024-03-12 18:15:57 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:15:57 --> Controller Class Initialized
INFO - 2024-03-12 18:15:57 --> Form Validation Class Initialized
INFO - 2024-03-12 18:15:57 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:15:57 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:15:57 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:15:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:15:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:15:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:15:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:15:57 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:15:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:15:57 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:16:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:16:00 --> Config Class Initialized
INFO - 2024-03-12 18:16:00 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:16:00 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:16:00 --> Utf8 Class Initialized
INFO - 2024-03-12 18:16:00 --> URI Class Initialized
INFO - 2024-03-12 18:16:00 --> Router Class Initialized
INFO - 2024-03-12 18:16:00 --> Output Class Initialized
INFO - 2024-03-12 18:16:00 --> Security Class Initialized
DEBUG - 2024-03-12 18:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:16:00 --> Input Class Initialized
INFO - 2024-03-12 18:16:00 --> Language Class Initialized
INFO - 2024-03-12 18:16:00 --> Loader Class Initialized
INFO - 2024-03-12 18:16:00 --> Helper loaded: url_helper
INFO - 2024-03-12 18:16:00 --> Helper loaded: file_helper
INFO - 2024-03-12 18:16:00 --> Helper loaded: form_helper
INFO - 2024-03-12 18:16:00 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:16:00 --> Controller Class Initialized
INFO - 2024-03-12 18:16:00 --> Form Validation Class Initialized
INFO - 2024-03-12 18:16:00 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:16:00 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:16:00 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:16:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:16:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:16:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:16:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:16:00 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:16:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:16:00 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:16:01 --> Config Class Initialized
INFO - 2024-03-12 18:16:01 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:16:01 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:16:01 --> Utf8 Class Initialized
INFO - 2024-03-12 18:16:01 --> URI Class Initialized
INFO - 2024-03-12 18:16:01 --> Router Class Initialized
INFO - 2024-03-12 18:16:01 --> Output Class Initialized
INFO - 2024-03-12 18:16:01 --> Security Class Initialized
DEBUG - 2024-03-12 18:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:16:01 --> Input Class Initialized
INFO - 2024-03-12 18:16:01 --> Language Class Initialized
INFO - 2024-03-12 18:16:01 --> Loader Class Initialized
INFO - 2024-03-12 18:16:01 --> Helper loaded: url_helper
INFO - 2024-03-12 18:16:01 --> Helper loaded: file_helper
INFO - 2024-03-12 18:16:01 --> Helper loaded: form_helper
INFO - 2024-03-12 18:16:01 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:16:01 --> Controller Class Initialized
INFO - 2024-03-12 18:16:01 --> Form Validation Class Initialized
INFO - 2024-03-12 18:16:01 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:16:01 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:16:01 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:16:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:16:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:16:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:16:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:16:01 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:16:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:16:01 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:16:20 --> Config Class Initialized
INFO - 2024-03-12 18:16:20 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:16:20 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:16:20 --> Utf8 Class Initialized
INFO - 2024-03-12 18:16:20 --> URI Class Initialized
INFO - 2024-03-12 18:16:20 --> Router Class Initialized
INFO - 2024-03-12 18:16:20 --> Output Class Initialized
INFO - 2024-03-12 18:16:20 --> Security Class Initialized
DEBUG - 2024-03-12 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:16:20 --> Input Class Initialized
INFO - 2024-03-12 18:16:20 --> Language Class Initialized
INFO - 2024-03-12 18:16:20 --> Loader Class Initialized
INFO - 2024-03-12 18:16:20 --> Helper loaded: url_helper
INFO - 2024-03-12 18:16:20 --> Helper loaded: file_helper
INFO - 2024-03-12 18:16:20 --> Helper loaded: form_helper
INFO - 2024-03-12 18:16:20 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:16:20 --> Controller Class Initialized
INFO - 2024-03-12 18:16:20 --> Form Validation Class Initialized
INFO - 2024-03-12 18:16:20 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:16:20 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:16:20 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:16:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:16:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:16:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:16:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:16:20 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:16:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:16:20 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:16:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:16:20 --> Final output sent to browser
DEBUG - 2024-03-12 18:16:20 --> Total execution time: 0.0399
ERROR - 2024-03-12 18:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:16:21 --> Config Class Initialized
INFO - 2024-03-12 18:16:21 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:16:21 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:16:21 --> Utf8 Class Initialized
INFO - 2024-03-12 18:16:21 --> URI Class Initialized
INFO - 2024-03-12 18:16:21 --> Router Class Initialized
INFO - 2024-03-12 18:16:21 --> Output Class Initialized
INFO - 2024-03-12 18:16:21 --> Security Class Initialized
DEBUG - 2024-03-12 18:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:16:21 --> Input Class Initialized
INFO - 2024-03-12 18:16:21 --> Language Class Initialized
INFO - 2024-03-12 18:16:21 --> Loader Class Initialized
INFO - 2024-03-12 18:16:21 --> Helper loaded: url_helper
INFO - 2024-03-12 18:16:21 --> Helper loaded: file_helper
INFO - 2024-03-12 18:16:21 --> Helper loaded: form_helper
INFO - 2024-03-12 18:16:21 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:16:21 --> Controller Class Initialized
INFO - 2024-03-12 18:16:21 --> Form Validation Class Initialized
INFO - 2024-03-12 18:16:21 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:16:21 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:16:21 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:16:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:16:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:16:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:16:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:16:21 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:16:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:16:21 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:16:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:16:23 --> Config Class Initialized
INFO - 2024-03-12 18:16:23 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:16:23 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:16:23 --> Utf8 Class Initialized
INFO - 2024-03-12 18:16:23 --> URI Class Initialized
INFO - 2024-03-12 18:16:23 --> Router Class Initialized
INFO - 2024-03-12 18:16:23 --> Output Class Initialized
INFO - 2024-03-12 18:16:23 --> Security Class Initialized
DEBUG - 2024-03-12 18:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:16:23 --> Input Class Initialized
INFO - 2024-03-12 18:16:23 --> Language Class Initialized
INFO - 2024-03-12 18:16:23 --> Loader Class Initialized
INFO - 2024-03-12 18:16:23 --> Helper loaded: url_helper
INFO - 2024-03-12 18:16:23 --> Helper loaded: file_helper
INFO - 2024-03-12 18:16:23 --> Helper loaded: form_helper
INFO - 2024-03-12 18:16:23 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:16:24 --> Controller Class Initialized
INFO - 2024-03-12 18:16:24 --> Form Validation Class Initialized
INFO - 2024-03-12 18:16:24 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:16:24 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:16:24 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:16:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:16:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:16:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:16:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:16:24 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:16:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:16:24 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:16:25 --> Config Class Initialized
INFO - 2024-03-12 18:16:25 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:16:25 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:16:25 --> Utf8 Class Initialized
INFO - 2024-03-12 18:16:25 --> URI Class Initialized
INFO - 2024-03-12 18:16:25 --> Router Class Initialized
INFO - 2024-03-12 18:16:25 --> Output Class Initialized
INFO - 2024-03-12 18:16:25 --> Security Class Initialized
DEBUG - 2024-03-12 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:16:25 --> Input Class Initialized
INFO - 2024-03-12 18:16:25 --> Language Class Initialized
INFO - 2024-03-12 18:16:25 --> Loader Class Initialized
INFO - 2024-03-12 18:16:25 --> Helper loaded: url_helper
INFO - 2024-03-12 18:16:25 --> Helper loaded: file_helper
INFO - 2024-03-12 18:16:25 --> Helper loaded: form_helper
INFO - 2024-03-12 18:16:25 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:16:25 --> Controller Class Initialized
INFO - 2024-03-12 18:16:25 --> Form Validation Class Initialized
INFO - 2024-03-12 18:16:25 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:16:25 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:16:25 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:16:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:16:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:16:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:16:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:16:25 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:16:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:16:25 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:16:30 --> Config Class Initialized
INFO - 2024-03-12 18:16:30 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:16:30 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:16:30 --> Utf8 Class Initialized
INFO - 2024-03-12 18:16:30 --> URI Class Initialized
INFO - 2024-03-12 18:16:30 --> Router Class Initialized
INFO - 2024-03-12 18:16:30 --> Output Class Initialized
INFO - 2024-03-12 18:16:30 --> Security Class Initialized
DEBUG - 2024-03-12 18:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:16:30 --> Input Class Initialized
INFO - 2024-03-12 18:16:30 --> Language Class Initialized
INFO - 2024-03-12 18:16:30 --> Loader Class Initialized
INFO - 2024-03-12 18:16:30 --> Helper loaded: url_helper
INFO - 2024-03-12 18:16:30 --> Helper loaded: file_helper
INFO - 2024-03-12 18:16:30 --> Helper loaded: form_helper
INFO - 2024-03-12 18:16:30 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:16:30 --> Controller Class Initialized
INFO - 2024-03-12 18:16:30 --> Form Validation Class Initialized
INFO - 2024-03-12 18:16:30 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:16:30 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:16:30 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:16:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:16:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:16:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:16:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:16:30 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:16:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:16:30 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:16:30 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:16:30 --> Final output sent to browser
DEBUG - 2024-03-12 18:16:30 --> Total execution time: 0.0371
ERROR - 2024-03-12 18:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:16:31 --> Config Class Initialized
INFO - 2024-03-12 18:16:31 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:16:31 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:16:31 --> Utf8 Class Initialized
INFO - 2024-03-12 18:16:31 --> URI Class Initialized
INFO - 2024-03-12 18:16:31 --> Router Class Initialized
INFO - 2024-03-12 18:16:31 --> Output Class Initialized
INFO - 2024-03-12 18:16:31 --> Security Class Initialized
DEBUG - 2024-03-12 18:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:16:31 --> Input Class Initialized
INFO - 2024-03-12 18:16:31 --> Language Class Initialized
INFO - 2024-03-12 18:16:31 --> Loader Class Initialized
INFO - 2024-03-12 18:16:31 --> Helper loaded: url_helper
INFO - 2024-03-12 18:16:31 --> Helper loaded: file_helper
INFO - 2024-03-12 18:16:31 --> Helper loaded: form_helper
INFO - 2024-03-12 18:16:31 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:16:31 --> Controller Class Initialized
INFO - 2024-03-12 18:16:31 --> Form Validation Class Initialized
INFO - 2024-03-12 18:16:31 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:16:31 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:16:31 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:16:31 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:16:31 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:16:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:16:31 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:16:31 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:16:31 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:16:31 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:17:36 --> Config Class Initialized
INFO - 2024-03-12 18:17:36 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:17:36 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:17:36 --> Utf8 Class Initialized
INFO - 2024-03-12 18:17:36 --> URI Class Initialized
INFO - 2024-03-12 18:17:36 --> Router Class Initialized
INFO - 2024-03-12 18:17:36 --> Output Class Initialized
INFO - 2024-03-12 18:17:36 --> Security Class Initialized
DEBUG - 2024-03-12 18:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:17:36 --> Input Class Initialized
INFO - 2024-03-12 18:17:36 --> Language Class Initialized
INFO - 2024-03-12 18:17:36 --> Loader Class Initialized
INFO - 2024-03-12 18:17:36 --> Helper loaded: url_helper
INFO - 2024-03-12 18:17:36 --> Helper loaded: file_helper
INFO - 2024-03-12 18:17:36 --> Helper loaded: form_helper
INFO - 2024-03-12 18:17:36 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:17:36 --> Controller Class Initialized
INFO - 2024-03-12 18:17:36 --> Form Validation Class Initialized
INFO - 2024-03-12 18:17:36 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:17:36 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:17:36 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:17:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:17:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:17:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:17:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:17:36 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:17:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:17:36 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:17:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:17:39 --> Config Class Initialized
INFO - 2024-03-12 18:17:39 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:17:39 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:17:39 --> Utf8 Class Initialized
INFO - 2024-03-12 18:17:39 --> URI Class Initialized
INFO - 2024-03-12 18:17:39 --> Router Class Initialized
INFO - 2024-03-12 18:17:39 --> Output Class Initialized
INFO - 2024-03-12 18:17:39 --> Security Class Initialized
DEBUG - 2024-03-12 18:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:17:39 --> Input Class Initialized
INFO - 2024-03-12 18:17:39 --> Language Class Initialized
INFO - 2024-03-12 18:17:39 --> Loader Class Initialized
INFO - 2024-03-12 18:17:39 --> Helper loaded: url_helper
INFO - 2024-03-12 18:17:39 --> Helper loaded: file_helper
INFO - 2024-03-12 18:17:39 --> Helper loaded: form_helper
INFO - 2024-03-12 18:17:39 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:17:39 --> Controller Class Initialized
INFO - 2024-03-12 18:17:39 --> Form Validation Class Initialized
INFO - 2024-03-12 18:17:39 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:17:39 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:17:39 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:17:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:17:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:17:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:17:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:17:39 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:17:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:17:39 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:17:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:17:40 --> Config Class Initialized
INFO - 2024-03-12 18:17:40 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:17:40 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:17:40 --> Utf8 Class Initialized
INFO - 2024-03-12 18:17:40 --> URI Class Initialized
INFO - 2024-03-12 18:17:40 --> Router Class Initialized
INFO - 2024-03-12 18:17:40 --> Output Class Initialized
INFO - 2024-03-12 18:17:40 --> Security Class Initialized
DEBUG - 2024-03-12 18:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:17:40 --> Input Class Initialized
INFO - 2024-03-12 18:17:40 --> Language Class Initialized
INFO - 2024-03-12 18:17:40 --> Loader Class Initialized
INFO - 2024-03-12 18:17:40 --> Helper loaded: url_helper
INFO - 2024-03-12 18:17:40 --> Helper loaded: file_helper
INFO - 2024-03-12 18:17:40 --> Helper loaded: form_helper
INFO - 2024-03-12 18:17:40 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:17:40 --> Controller Class Initialized
INFO - 2024-03-12 18:17:40 --> Form Validation Class Initialized
INFO - 2024-03-12 18:17:40 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:17:40 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:17:40 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:17:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:17:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:17:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:17:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:17:40 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:17:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:17:40 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:28:56 --> Config Class Initialized
INFO - 2024-03-12 18:28:56 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:28:56 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:28:56 --> Utf8 Class Initialized
INFO - 2024-03-12 18:28:56 --> URI Class Initialized
INFO - 2024-03-12 18:28:56 --> Router Class Initialized
INFO - 2024-03-12 18:28:56 --> Output Class Initialized
INFO - 2024-03-12 18:28:56 --> Security Class Initialized
DEBUG - 2024-03-12 18:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:28:56 --> Input Class Initialized
INFO - 2024-03-12 18:28:56 --> Language Class Initialized
INFO - 2024-03-12 18:28:56 --> Loader Class Initialized
INFO - 2024-03-12 18:28:56 --> Helper loaded: url_helper
INFO - 2024-03-12 18:28:56 --> Helper loaded: file_helper
INFO - 2024-03-12 18:28:56 --> Helper loaded: form_helper
INFO - 2024-03-12 18:28:56 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:28:56 --> Controller Class Initialized
INFO - 2024-03-12 18:28:56 --> Form Validation Class Initialized
INFO - 2024-03-12 18:28:56 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:28:56 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:28:56 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:28:56 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:28:56 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:28:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:28:56 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:28:56 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:28:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:28:56 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:28:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:28:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:28:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:28:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:28:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:28:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:28:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:28:56 --> Final output sent to browser
DEBUG - 2024-03-12 18:28:56 --> Total execution time: 0.0357
ERROR - 2024-03-12 18:28:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:28:57 --> Config Class Initialized
INFO - 2024-03-12 18:28:57 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:28:57 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:28:57 --> Utf8 Class Initialized
INFO - 2024-03-12 18:28:57 --> URI Class Initialized
INFO - 2024-03-12 18:28:57 --> Router Class Initialized
INFO - 2024-03-12 18:28:57 --> Output Class Initialized
INFO - 2024-03-12 18:28:57 --> Security Class Initialized
DEBUG - 2024-03-12 18:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:28:57 --> Input Class Initialized
INFO - 2024-03-12 18:28:57 --> Language Class Initialized
INFO - 2024-03-12 18:28:57 --> Loader Class Initialized
INFO - 2024-03-12 18:28:57 --> Helper loaded: url_helper
INFO - 2024-03-12 18:28:57 --> Helper loaded: file_helper
INFO - 2024-03-12 18:28:57 --> Helper loaded: form_helper
INFO - 2024-03-12 18:28:57 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:28:57 --> Controller Class Initialized
INFO - 2024-03-12 18:28:57 --> Form Validation Class Initialized
INFO - 2024-03-12 18:28:57 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:28:57 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:28:57 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:28:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:28:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:28:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:28:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:28:57 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:28:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:28:57 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:34:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:34:05 --> Config Class Initialized
INFO - 2024-03-12 18:34:05 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:34:05 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:34:05 --> Utf8 Class Initialized
INFO - 2024-03-12 18:34:05 --> URI Class Initialized
INFO - 2024-03-12 18:34:05 --> Router Class Initialized
INFO - 2024-03-12 18:34:05 --> Output Class Initialized
INFO - 2024-03-12 18:34:05 --> Security Class Initialized
DEBUG - 2024-03-12 18:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:34:05 --> Input Class Initialized
INFO - 2024-03-12 18:34:05 --> Language Class Initialized
INFO - 2024-03-12 18:34:05 --> Loader Class Initialized
INFO - 2024-03-12 18:34:05 --> Helper loaded: url_helper
INFO - 2024-03-12 18:34:05 --> Helper loaded: file_helper
INFO - 2024-03-12 18:34:05 --> Helper loaded: form_helper
INFO - 2024-03-12 18:34:05 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:34:05 --> Controller Class Initialized
INFO - 2024-03-12 18:34:05 --> Form Validation Class Initialized
INFO - 2024-03-12 18:34:05 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:34:05 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:34:05 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:34:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:34:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:34:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:34:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:34:05 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:34:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:34:05 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:34:08 --> Config Class Initialized
INFO - 2024-03-12 18:34:08 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:34:08 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:34:08 --> Utf8 Class Initialized
INFO - 2024-03-12 18:34:08 --> URI Class Initialized
INFO - 2024-03-12 18:34:08 --> Router Class Initialized
INFO - 2024-03-12 18:34:08 --> Output Class Initialized
INFO - 2024-03-12 18:34:08 --> Security Class Initialized
DEBUG - 2024-03-12 18:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:34:08 --> Input Class Initialized
INFO - 2024-03-12 18:34:08 --> Language Class Initialized
INFO - 2024-03-12 18:34:08 --> Loader Class Initialized
INFO - 2024-03-12 18:34:08 --> Helper loaded: url_helper
INFO - 2024-03-12 18:34:08 --> Helper loaded: file_helper
INFO - 2024-03-12 18:34:08 --> Helper loaded: form_helper
INFO - 2024-03-12 18:34:08 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:34:08 --> Controller Class Initialized
INFO - 2024-03-12 18:34:08 --> Form Validation Class Initialized
INFO - 2024-03-12 18:34:08 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:34:08 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:34:08 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:34:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:34:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:34:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:34:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:34:08 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:34:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:34:08 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:34:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:34:19 --> Config Class Initialized
INFO - 2024-03-12 18:34:19 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:34:19 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:34:19 --> Utf8 Class Initialized
INFO - 2024-03-12 18:34:19 --> URI Class Initialized
INFO - 2024-03-12 18:34:19 --> Router Class Initialized
INFO - 2024-03-12 18:34:19 --> Output Class Initialized
INFO - 2024-03-12 18:34:19 --> Security Class Initialized
DEBUG - 2024-03-12 18:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:34:19 --> Input Class Initialized
INFO - 2024-03-12 18:34:19 --> Language Class Initialized
INFO - 2024-03-12 18:34:19 --> Loader Class Initialized
INFO - 2024-03-12 18:34:19 --> Helper loaded: url_helper
INFO - 2024-03-12 18:34:19 --> Helper loaded: file_helper
INFO - 2024-03-12 18:34:19 --> Helper loaded: form_helper
INFO - 2024-03-12 18:34:19 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:34:19 --> Controller Class Initialized
INFO - 2024-03-12 18:34:19 --> Form Validation Class Initialized
INFO - 2024-03-12 18:34:19 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:34:19 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:34:19 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:34:19 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:34:19 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:34:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:34:19 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:34:19 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:34:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:34:19 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:34:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:34:20 --> Config Class Initialized
INFO - 2024-03-12 18:34:20 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:34:20 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:34:20 --> Utf8 Class Initialized
INFO - 2024-03-12 18:34:20 --> URI Class Initialized
INFO - 2024-03-12 18:34:20 --> Router Class Initialized
INFO - 2024-03-12 18:34:20 --> Output Class Initialized
INFO - 2024-03-12 18:34:20 --> Security Class Initialized
DEBUG - 2024-03-12 18:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:34:20 --> Input Class Initialized
INFO - 2024-03-12 18:34:20 --> Language Class Initialized
INFO - 2024-03-12 18:34:20 --> Loader Class Initialized
INFO - 2024-03-12 18:34:20 --> Helper loaded: url_helper
INFO - 2024-03-12 18:34:20 --> Helper loaded: file_helper
INFO - 2024-03-12 18:34:20 --> Helper loaded: form_helper
INFO - 2024-03-12 18:34:20 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:34:20 --> Controller Class Initialized
INFO - 2024-03-12 18:34:20 --> Form Validation Class Initialized
INFO - 2024-03-12 18:34:20 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:34:20 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:34:20 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:34:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:34:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:34:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:34:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:34:20 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:34:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:34:20 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:34:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:34:22 --> Config Class Initialized
INFO - 2024-03-12 18:34:22 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:34:22 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:34:22 --> Utf8 Class Initialized
INFO - 2024-03-12 18:34:22 --> URI Class Initialized
INFO - 2024-03-12 18:34:22 --> Router Class Initialized
INFO - 2024-03-12 18:34:22 --> Output Class Initialized
INFO - 2024-03-12 18:34:22 --> Security Class Initialized
DEBUG - 2024-03-12 18:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:34:22 --> Input Class Initialized
INFO - 2024-03-12 18:34:22 --> Language Class Initialized
INFO - 2024-03-12 18:34:22 --> Loader Class Initialized
INFO - 2024-03-12 18:34:22 --> Helper loaded: url_helper
INFO - 2024-03-12 18:34:22 --> Helper loaded: file_helper
INFO - 2024-03-12 18:34:22 --> Helper loaded: form_helper
INFO - 2024-03-12 18:34:22 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:34:22 --> Controller Class Initialized
INFO - 2024-03-12 18:34:22 --> Form Validation Class Initialized
INFO - 2024-03-12 18:34:22 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:34:22 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:34:22 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:34:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:34:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:34:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:34:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:34:22 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:34:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:34:22 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:35:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:35:07 --> Config Class Initialized
INFO - 2024-03-12 18:35:07 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:35:07 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:35:07 --> Utf8 Class Initialized
INFO - 2024-03-12 18:35:07 --> URI Class Initialized
INFO - 2024-03-12 18:35:07 --> Router Class Initialized
INFO - 2024-03-12 18:35:07 --> Output Class Initialized
INFO - 2024-03-12 18:35:07 --> Security Class Initialized
DEBUG - 2024-03-12 18:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:35:07 --> Input Class Initialized
INFO - 2024-03-12 18:35:07 --> Language Class Initialized
INFO - 2024-03-12 18:35:07 --> Loader Class Initialized
INFO - 2024-03-12 18:35:07 --> Helper loaded: url_helper
INFO - 2024-03-12 18:35:07 --> Helper loaded: file_helper
INFO - 2024-03-12 18:35:07 --> Helper loaded: form_helper
INFO - 2024-03-12 18:35:07 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:35:07 --> Controller Class Initialized
INFO - 2024-03-12 18:35:07 --> Form Validation Class Initialized
INFO - 2024-03-12 18:35:07 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:35:07 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:35:07 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:35:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:35:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:35:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:35:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:35:07 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:35:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:35:07 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:35:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:35:14 --> Config Class Initialized
INFO - 2024-03-12 18:35:14 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:35:14 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:35:14 --> Utf8 Class Initialized
INFO - 2024-03-12 18:35:14 --> URI Class Initialized
INFO - 2024-03-12 18:35:14 --> Router Class Initialized
INFO - 2024-03-12 18:35:14 --> Output Class Initialized
INFO - 2024-03-12 18:35:14 --> Security Class Initialized
DEBUG - 2024-03-12 18:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:35:14 --> Input Class Initialized
INFO - 2024-03-12 18:35:14 --> Language Class Initialized
INFO - 2024-03-12 18:35:14 --> Loader Class Initialized
INFO - 2024-03-12 18:35:14 --> Helper loaded: url_helper
INFO - 2024-03-12 18:35:14 --> Helper loaded: file_helper
INFO - 2024-03-12 18:35:14 --> Helper loaded: form_helper
INFO - 2024-03-12 18:35:14 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:35:14 --> Controller Class Initialized
INFO - 2024-03-12 18:35:14 --> Form Validation Class Initialized
INFO - 2024-03-12 18:35:14 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:35:14 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:35:14 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:35:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:35:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:35:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:35:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:35:14 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:35:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:35:14 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:35:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:35:26 --> Config Class Initialized
INFO - 2024-03-12 18:35:26 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:35:26 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:35:26 --> Utf8 Class Initialized
INFO - 2024-03-12 18:35:26 --> URI Class Initialized
INFO - 2024-03-12 18:35:26 --> Router Class Initialized
INFO - 2024-03-12 18:35:26 --> Output Class Initialized
INFO - 2024-03-12 18:35:26 --> Security Class Initialized
DEBUG - 2024-03-12 18:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:35:26 --> Input Class Initialized
INFO - 2024-03-12 18:35:26 --> Language Class Initialized
INFO - 2024-03-12 18:35:26 --> Loader Class Initialized
INFO - 2024-03-12 18:35:26 --> Helper loaded: url_helper
INFO - 2024-03-12 18:35:26 --> Helper loaded: file_helper
INFO - 2024-03-12 18:35:26 --> Helper loaded: form_helper
INFO - 2024-03-12 18:35:26 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:35:26 --> Controller Class Initialized
INFO - 2024-03-12 18:35:26 --> Form Validation Class Initialized
INFO - 2024-03-12 18:35:26 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:35:26 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:35:26 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:35:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:35:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:35:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:35:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:35:26 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:35:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:35:26 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:40:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:40:25 --> Config Class Initialized
INFO - 2024-03-12 18:40:25 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:40:25 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:40:25 --> Utf8 Class Initialized
INFO - 2024-03-12 18:40:25 --> URI Class Initialized
INFO - 2024-03-12 18:40:25 --> Router Class Initialized
INFO - 2024-03-12 18:40:25 --> Output Class Initialized
INFO - 2024-03-12 18:40:25 --> Security Class Initialized
DEBUG - 2024-03-12 18:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:40:25 --> Input Class Initialized
INFO - 2024-03-12 18:40:25 --> Language Class Initialized
INFO - 2024-03-12 18:40:25 --> Loader Class Initialized
INFO - 2024-03-12 18:40:25 --> Helper loaded: url_helper
INFO - 2024-03-12 18:40:25 --> Helper loaded: file_helper
INFO - 2024-03-12 18:40:25 --> Helper loaded: form_helper
INFO - 2024-03-12 18:40:25 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:40:25 --> Controller Class Initialized
INFO - 2024-03-12 18:40:25 --> Form Validation Class Initialized
INFO - 2024-03-12 18:40:25 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:40:25 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:40:25 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:40:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:40:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:40:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:40:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:40:25 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:40:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:40:25 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:40:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:40:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:40:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:40:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:40:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:40:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:40:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:40:25 --> Final output sent to browser
DEBUG - 2024-03-12 18:40:25 --> Total execution time: 0.0508
ERROR - 2024-03-12 18:40:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:40:27 --> Config Class Initialized
INFO - 2024-03-12 18:40:27 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:40:27 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:40:27 --> Utf8 Class Initialized
INFO - 2024-03-12 18:40:27 --> URI Class Initialized
INFO - 2024-03-12 18:40:27 --> Router Class Initialized
INFO - 2024-03-12 18:40:27 --> Output Class Initialized
INFO - 2024-03-12 18:40:27 --> Security Class Initialized
DEBUG - 2024-03-12 18:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:40:27 --> Input Class Initialized
INFO - 2024-03-12 18:40:27 --> Language Class Initialized
INFO - 2024-03-12 18:40:27 --> Loader Class Initialized
INFO - 2024-03-12 18:40:27 --> Helper loaded: url_helper
INFO - 2024-03-12 18:40:27 --> Helper loaded: file_helper
INFO - 2024-03-12 18:40:27 --> Helper loaded: form_helper
INFO - 2024-03-12 18:40:27 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:40:27 --> Controller Class Initialized
INFO - 2024-03-12 18:40:27 --> Form Validation Class Initialized
INFO - 2024-03-12 18:40:27 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:40:27 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:40:27 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:40:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:40:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:40:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:40:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:40:27 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:40:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:40:27 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:40:41 --> Config Class Initialized
INFO - 2024-03-12 18:40:41 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:40:41 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:40:41 --> Utf8 Class Initialized
INFO - 2024-03-12 18:40:41 --> URI Class Initialized
INFO - 2024-03-12 18:40:41 --> Router Class Initialized
INFO - 2024-03-12 18:40:41 --> Output Class Initialized
INFO - 2024-03-12 18:40:41 --> Security Class Initialized
DEBUG - 2024-03-12 18:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:40:41 --> Input Class Initialized
INFO - 2024-03-12 18:40:41 --> Language Class Initialized
INFO - 2024-03-12 18:40:41 --> Loader Class Initialized
INFO - 2024-03-12 18:40:41 --> Helper loaded: url_helper
INFO - 2024-03-12 18:40:41 --> Helper loaded: file_helper
INFO - 2024-03-12 18:40:41 --> Helper loaded: form_helper
INFO - 2024-03-12 18:40:41 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:40:41 --> Controller Class Initialized
INFO - 2024-03-12 18:40:41 --> Form Validation Class Initialized
INFO - 2024-03-12 18:40:41 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:40:41 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:40:41 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:40:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:40:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:40:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:40:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:40:41 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:40:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:40:41 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:40:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:40:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:40:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:40:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:40:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:40:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:40:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:40:41 --> Final output sent to browser
DEBUG - 2024-03-12 18:40:41 --> Total execution time: 0.0278
ERROR - 2024-03-12 18:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:40:41 --> Config Class Initialized
INFO - 2024-03-12 18:40:41 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:40:41 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:40:41 --> Utf8 Class Initialized
INFO - 2024-03-12 18:40:41 --> URI Class Initialized
INFO - 2024-03-12 18:40:41 --> Router Class Initialized
INFO - 2024-03-12 18:40:41 --> Output Class Initialized
INFO - 2024-03-12 18:40:41 --> Security Class Initialized
DEBUG - 2024-03-12 18:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:40:41 --> Input Class Initialized
INFO - 2024-03-12 18:40:41 --> Language Class Initialized
INFO - 2024-03-12 18:40:41 --> Loader Class Initialized
INFO - 2024-03-12 18:40:41 --> Helper loaded: url_helper
INFO - 2024-03-12 18:40:41 --> Helper loaded: file_helper
INFO - 2024-03-12 18:40:41 --> Helper loaded: form_helper
INFO - 2024-03-12 18:40:42 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:40:42 --> Controller Class Initialized
INFO - 2024-03-12 18:40:42 --> Form Validation Class Initialized
INFO - 2024-03-12 18:40:42 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:40:42 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:40:42 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:40:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:40:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:40:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:40:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:40:42 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:40:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:40:42 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:40:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:40:48 --> Config Class Initialized
INFO - 2024-03-12 18:40:48 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:40:48 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:40:48 --> Utf8 Class Initialized
INFO - 2024-03-12 18:40:48 --> URI Class Initialized
INFO - 2024-03-12 18:40:48 --> Router Class Initialized
INFO - 2024-03-12 18:40:48 --> Output Class Initialized
INFO - 2024-03-12 18:40:48 --> Security Class Initialized
DEBUG - 2024-03-12 18:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:40:48 --> Input Class Initialized
INFO - 2024-03-12 18:40:48 --> Language Class Initialized
INFO - 2024-03-12 18:40:48 --> Loader Class Initialized
INFO - 2024-03-12 18:40:48 --> Helper loaded: url_helper
INFO - 2024-03-12 18:40:48 --> Helper loaded: file_helper
INFO - 2024-03-12 18:40:48 --> Helper loaded: form_helper
INFO - 2024-03-12 18:40:48 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:40:48 --> Controller Class Initialized
INFO - 2024-03-12 18:40:48 --> Form Validation Class Initialized
INFO - 2024-03-12 18:40:48 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:40:48 --> Final output sent to browser
DEBUG - 2024-03-12 18:40:48 --> Total execution time: 0.0469
ERROR - 2024-03-12 18:40:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:40:48 --> Config Class Initialized
INFO - 2024-03-12 18:40:48 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:40:48 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:40:48 --> Utf8 Class Initialized
INFO - 2024-03-12 18:40:48 --> URI Class Initialized
INFO - 2024-03-12 18:40:48 --> Router Class Initialized
INFO - 2024-03-12 18:40:48 --> Output Class Initialized
INFO - 2024-03-12 18:40:48 --> Security Class Initialized
DEBUG - 2024-03-12 18:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:40:48 --> Input Class Initialized
INFO - 2024-03-12 18:40:48 --> Language Class Initialized
INFO - 2024-03-12 18:40:48 --> Loader Class Initialized
INFO - 2024-03-12 18:40:48 --> Helper loaded: url_helper
INFO - 2024-03-12 18:40:48 --> Helper loaded: file_helper
INFO - 2024-03-12 18:40:48 --> Helper loaded: form_helper
INFO - 2024-03-12 18:40:48 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:40:48 --> Controller Class Initialized
INFO - 2024-03-12 18:40:48 --> Form Validation Class Initialized
INFO - 2024-03-12 18:40:48 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:40:48 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:40:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:40:54 --> Config Class Initialized
INFO - 2024-03-12 18:40:54 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:40:54 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:40:54 --> Utf8 Class Initialized
INFO - 2024-03-12 18:40:54 --> URI Class Initialized
INFO - 2024-03-12 18:40:54 --> Router Class Initialized
INFO - 2024-03-12 18:40:54 --> Output Class Initialized
INFO - 2024-03-12 18:40:54 --> Security Class Initialized
DEBUG - 2024-03-12 18:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:40:54 --> Input Class Initialized
INFO - 2024-03-12 18:40:54 --> Language Class Initialized
INFO - 2024-03-12 18:40:54 --> Loader Class Initialized
INFO - 2024-03-12 18:40:54 --> Helper loaded: url_helper
INFO - 2024-03-12 18:40:54 --> Helper loaded: file_helper
INFO - 2024-03-12 18:40:54 --> Helper loaded: form_helper
INFO - 2024-03-12 18:40:54 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:40:54 --> Controller Class Initialized
INFO - 2024-03-12 18:40:54 --> Form Validation Class Initialized
INFO - 2024-03-12 18:40:54 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:40:54 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:40:54 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:40:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:40:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:40:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:40:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:40:54 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:40:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:40:54 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:40:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:40:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:40:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:40:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:40:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:40:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:40:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:40:54 --> Final output sent to browser
DEBUG - 2024-03-12 18:40:54 --> Total execution time: 0.0348
ERROR - 2024-03-12 18:40:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:40:55 --> Config Class Initialized
INFO - 2024-03-12 18:40:55 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:40:55 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:40:55 --> Utf8 Class Initialized
INFO - 2024-03-12 18:40:55 --> URI Class Initialized
INFO - 2024-03-12 18:40:55 --> Router Class Initialized
INFO - 2024-03-12 18:40:55 --> Output Class Initialized
INFO - 2024-03-12 18:40:55 --> Security Class Initialized
DEBUG - 2024-03-12 18:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:40:55 --> Input Class Initialized
INFO - 2024-03-12 18:40:55 --> Language Class Initialized
INFO - 2024-03-12 18:40:55 --> Loader Class Initialized
INFO - 2024-03-12 18:40:55 --> Helper loaded: url_helper
INFO - 2024-03-12 18:40:55 --> Helper loaded: file_helper
INFO - 2024-03-12 18:40:55 --> Helper loaded: form_helper
INFO - 2024-03-12 18:40:55 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:40:55 --> Controller Class Initialized
INFO - 2024-03-12 18:40:55 --> Form Validation Class Initialized
INFO - 2024-03-12 18:40:55 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:40:55 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:40:55 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:40:55 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:40:55 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:40:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:40:55 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:40:55 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:40:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:40:55 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:41:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:41:01 --> Config Class Initialized
INFO - 2024-03-12 18:41:01 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:41:01 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:41:01 --> Utf8 Class Initialized
INFO - 2024-03-12 18:41:01 --> URI Class Initialized
INFO - 2024-03-12 18:41:01 --> Router Class Initialized
INFO - 2024-03-12 18:41:01 --> Output Class Initialized
INFO - 2024-03-12 18:41:01 --> Security Class Initialized
DEBUG - 2024-03-12 18:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:41:01 --> Input Class Initialized
INFO - 2024-03-12 18:41:01 --> Language Class Initialized
INFO - 2024-03-12 18:41:01 --> Loader Class Initialized
INFO - 2024-03-12 18:41:01 --> Helper loaded: url_helper
INFO - 2024-03-12 18:41:01 --> Helper loaded: file_helper
INFO - 2024-03-12 18:41:01 --> Helper loaded: form_helper
INFO - 2024-03-12 18:41:01 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:41:01 --> Controller Class Initialized
INFO - 2024-03-12 18:41:01 --> Form Validation Class Initialized
INFO - 2024-03-12 18:41:01 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:41:01 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:41:01 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:41:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:41:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:41:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:41:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:41:01 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:41:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:41:01 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:41:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:41:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:41:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:41:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:41:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:41:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:41:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:41:01 --> Final output sent to browser
DEBUG - 2024-03-12 18:41:01 --> Total execution time: 0.0341
ERROR - 2024-03-12 18:41:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:41:03 --> Config Class Initialized
INFO - 2024-03-12 18:41:03 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:41:03 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:41:03 --> Utf8 Class Initialized
INFO - 2024-03-12 18:41:03 --> URI Class Initialized
INFO - 2024-03-12 18:41:03 --> Router Class Initialized
INFO - 2024-03-12 18:41:03 --> Output Class Initialized
INFO - 2024-03-12 18:41:03 --> Security Class Initialized
DEBUG - 2024-03-12 18:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:41:03 --> Input Class Initialized
INFO - 2024-03-12 18:41:03 --> Language Class Initialized
INFO - 2024-03-12 18:41:03 --> Loader Class Initialized
INFO - 2024-03-12 18:41:03 --> Helper loaded: url_helper
INFO - 2024-03-12 18:41:03 --> Helper loaded: file_helper
INFO - 2024-03-12 18:41:03 --> Helper loaded: form_helper
INFO - 2024-03-12 18:41:03 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:41:03 --> Controller Class Initialized
INFO - 2024-03-12 18:41:03 --> Form Validation Class Initialized
INFO - 2024-03-12 18:41:03 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:41:03 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:41:03 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:41:03 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:41:03 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:41:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:41:03 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:41:03 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:41:03 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:41:03 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:41:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:41:20 --> Config Class Initialized
INFO - 2024-03-12 18:41:20 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:41:20 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:41:20 --> Utf8 Class Initialized
INFO - 2024-03-12 18:41:20 --> URI Class Initialized
INFO - 2024-03-12 18:41:20 --> Router Class Initialized
INFO - 2024-03-12 18:41:20 --> Output Class Initialized
INFO - 2024-03-12 18:41:20 --> Security Class Initialized
DEBUG - 2024-03-12 18:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:41:20 --> Input Class Initialized
INFO - 2024-03-12 18:41:20 --> Language Class Initialized
INFO - 2024-03-12 18:41:20 --> Loader Class Initialized
INFO - 2024-03-12 18:41:20 --> Helper loaded: url_helper
INFO - 2024-03-12 18:41:20 --> Helper loaded: file_helper
INFO - 2024-03-12 18:41:20 --> Helper loaded: form_helper
INFO - 2024-03-12 18:41:20 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:41:20 --> Controller Class Initialized
INFO - 2024-03-12 18:41:20 --> Form Validation Class Initialized
INFO - 2024-03-12 18:41:20 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:41:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:41:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:41:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:41:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:41:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:41:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-12 18:41:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-12 18:41:20 --> Final output sent to browser
DEBUG - 2024-03-12 18:41:20 --> Total execution time: 0.0355
ERROR - 2024-03-12 18:41:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:41:20 --> Config Class Initialized
INFO - 2024-03-12 18:41:20 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:41:20 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:41:20 --> Utf8 Class Initialized
INFO - 2024-03-12 18:41:20 --> URI Class Initialized
INFO - 2024-03-12 18:41:20 --> Router Class Initialized
INFO - 2024-03-12 18:41:20 --> Output Class Initialized
INFO - 2024-03-12 18:41:20 --> Security Class Initialized
DEBUG - 2024-03-12 18:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:41:20 --> Input Class Initialized
INFO - 2024-03-12 18:41:20 --> Language Class Initialized
INFO - 2024-03-12 18:41:20 --> Loader Class Initialized
INFO - 2024-03-12 18:41:20 --> Helper loaded: url_helper
INFO - 2024-03-12 18:41:20 --> Helper loaded: file_helper
INFO - 2024-03-12 18:41:20 --> Helper loaded: form_helper
INFO - 2024-03-12 18:41:20 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:41:20 --> Controller Class Initialized
INFO - 2024-03-12 18:41:20 --> Form Validation Class Initialized
INFO - 2024-03-12 18:41:20 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:41:20 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:41:22 --> Config Class Initialized
INFO - 2024-03-12 18:41:22 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:41:22 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:41:22 --> Utf8 Class Initialized
INFO - 2024-03-12 18:41:22 --> URI Class Initialized
INFO - 2024-03-12 18:41:22 --> Router Class Initialized
INFO - 2024-03-12 18:41:22 --> Output Class Initialized
INFO - 2024-03-12 18:41:22 --> Security Class Initialized
DEBUG - 2024-03-12 18:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:41:22 --> Input Class Initialized
INFO - 2024-03-12 18:41:22 --> Language Class Initialized
INFO - 2024-03-12 18:41:22 --> Loader Class Initialized
INFO - 2024-03-12 18:41:22 --> Helper loaded: url_helper
INFO - 2024-03-12 18:41:22 --> Helper loaded: file_helper
INFO - 2024-03-12 18:41:22 --> Helper loaded: form_helper
INFO - 2024-03-12 18:41:22 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:41:22 --> Controller Class Initialized
INFO - 2024-03-12 18:41:22 --> Form Validation Class Initialized
INFO - 2024-03-12 18:41:22 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:41:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:41:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:41:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:41:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:41:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:41:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:41:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:41:22 --> Final output sent to browser
DEBUG - 2024-03-12 18:41:22 --> Total execution time: 0.0315
ERROR - 2024-03-12 18:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:41:22 --> Config Class Initialized
INFO - 2024-03-12 18:41:22 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:41:22 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:41:22 --> Utf8 Class Initialized
INFO - 2024-03-12 18:41:22 --> URI Class Initialized
INFO - 2024-03-12 18:41:22 --> Router Class Initialized
INFO - 2024-03-12 18:41:22 --> Output Class Initialized
INFO - 2024-03-12 18:41:22 --> Security Class Initialized
DEBUG - 2024-03-12 18:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:41:22 --> Input Class Initialized
INFO - 2024-03-12 18:41:22 --> Language Class Initialized
INFO - 2024-03-12 18:41:22 --> Loader Class Initialized
INFO - 2024-03-12 18:41:22 --> Helper loaded: url_helper
INFO - 2024-03-12 18:41:22 --> Helper loaded: file_helper
INFO - 2024-03-12 18:41:22 --> Helper loaded: form_helper
INFO - 2024-03-12 18:41:22 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:41:22 --> Controller Class Initialized
INFO - 2024-03-12 18:41:22 --> Form Validation Class Initialized
INFO - 2024-03-12 18:41:22 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:41:22 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:41:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:41:45 --> Config Class Initialized
INFO - 2024-03-12 18:41:45 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:41:45 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:41:45 --> Utf8 Class Initialized
INFO - 2024-03-12 18:41:45 --> URI Class Initialized
INFO - 2024-03-12 18:41:45 --> Router Class Initialized
INFO - 2024-03-12 18:41:45 --> Output Class Initialized
INFO - 2024-03-12 18:41:45 --> Security Class Initialized
DEBUG - 2024-03-12 18:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:41:45 --> Input Class Initialized
INFO - 2024-03-12 18:41:45 --> Language Class Initialized
INFO - 2024-03-12 18:41:45 --> Loader Class Initialized
INFO - 2024-03-12 18:41:45 --> Helper loaded: url_helper
INFO - 2024-03-12 18:41:45 --> Helper loaded: file_helper
INFO - 2024-03-12 18:41:45 --> Helper loaded: form_helper
INFO - 2024-03-12 18:41:45 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:41:45 --> Controller Class Initialized
INFO - 2024-03-12 18:41:45 --> Form Validation Class Initialized
INFO - 2024-03-12 18:41:45 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:41:45 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:41:45 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:41:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:41:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:41:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:41:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:41:45 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:41:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:41:45 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:41:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:41:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:41:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:41:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:41:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:41:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:41:45 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:41:45 --> Final output sent to browser
DEBUG - 2024-03-12 18:41:45 --> Total execution time: 0.0378
ERROR - 2024-03-12 18:41:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:41:47 --> Config Class Initialized
INFO - 2024-03-12 18:41:47 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:41:47 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:41:47 --> Utf8 Class Initialized
INFO - 2024-03-12 18:41:47 --> URI Class Initialized
INFO - 2024-03-12 18:41:47 --> Router Class Initialized
INFO - 2024-03-12 18:41:47 --> Output Class Initialized
INFO - 2024-03-12 18:41:47 --> Security Class Initialized
DEBUG - 2024-03-12 18:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:41:47 --> Input Class Initialized
INFO - 2024-03-12 18:41:47 --> Language Class Initialized
INFO - 2024-03-12 18:41:47 --> Loader Class Initialized
INFO - 2024-03-12 18:41:47 --> Helper loaded: url_helper
INFO - 2024-03-12 18:41:47 --> Helper loaded: file_helper
INFO - 2024-03-12 18:41:47 --> Helper loaded: form_helper
INFO - 2024-03-12 18:41:47 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:41:47 --> Controller Class Initialized
INFO - 2024-03-12 18:41:47 --> Form Validation Class Initialized
INFO - 2024-03-12 18:41:47 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:41:47 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:41:47 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:41:47 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:41:47 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:41:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:41:47 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:41:47 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:41:47 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:41:47 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:42:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:42:16 --> Config Class Initialized
INFO - 2024-03-12 18:42:16 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:42:16 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:42:16 --> Utf8 Class Initialized
INFO - 2024-03-12 18:42:16 --> URI Class Initialized
INFO - 2024-03-12 18:42:16 --> Router Class Initialized
INFO - 2024-03-12 18:42:16 --> Output Class Initialized
INFO - 2024-03-12 18:42:16 --> Security Class Initialized
DEBUG - 2024-03-12 18:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:42:16 --> Input Class Initialized
INFO - 2024-03-12 18:42:16 --> Language Class Initialized
INFO - 2024-03-12 18:42:16 --> Loader Class Initialized
INFO - 2024-03-12 18:42:16 --> Helper loaded: url_helper
INFO - 2024-03-12 18:42:16 --> Helper loaded: file_helper
INFO - 2024-03-12 18:42:16 --> Helper loaded: form_helper
INFO - 2024-03-12 18:42:16 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:42:16 --> Controller Class Initialized
INFO - 2024-03-12 18:42:16 --> Form Validation Class Initialized
INFO - 2024-03-12 18:42:16 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:42:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:42:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:42:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:42:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:42:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:42:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:42:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:42:16 --> Final output sent to browser
DEBUG - 2024-03-12 18:42:16 --> Total execution time: 0.0405
ERROR - 2024-03-12 18:42:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:42:16 --> Config Class Initialized
INFO - 2024-03-12 18:42:16 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:42:16 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:42:16 --> Utf8 Class Initialized
INFO - 2024-03-12 18:42:16 --> URI Class Initialized
INFO - 2024-03-12 18:42:16 --> Router Class Initialized
INFO - 2024-03-12 18:42:16 --> Output Class Initialized
INFO - 2024-03-12 18:42:16 --> Security Class Initialized
DEBUG - 2024-03-12 18:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:42:16 --> Input Class Initialized
INFO - 2024-03-12 18:42:16 --> Language Class Initialized
INFO - 2024-03-12 18:42:16 --> Loader Class Initialized
INFO - 2024-03-12 18:42:16 --> Helper loaded: url_helper
INFO - 2024-03-12 18:42:16 --> Helper loaded: file_helper
INFO - 2024-03-12 18:42:16 --> Helper loaded: form_helper
INFO - 2024-03-12 18:42:16 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:42:16 --> Controller Class Initialized
INFO - 2024-03-12 18:42:16 --> Form Validation Class Initialized
INFO - 2024-03-12 18:42:16 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:42:16 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:42:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:42:40 --> Config Class Initialized
INFO - 2024-03-12 18:42:40 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:42:40 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:42:40 --> Utf8 Class Initialized
INFO - 2024-03-12 18:42:40 --> URI Class Initialized
INFO - 2024-03-12 18:42:40 --> Router Class Initialized
INFO - 2024-03-12 18:42:40 --> Output Class Initialized
INFO - 2024-03-12 18:42:40 --> Security Class Initialized
DEBUG - 2024-03-12 18:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:42:40 --> Input Class Initialized
INFO - 2024-03-12 18:42:40 --> Language Class Initialized
INFO - 2024-03-12 18:42:40 --> Loader Class Initialized
INFO - 2024-03-12 18:42:40 --> Helper loaded: url_helper
INFO - 2024-03-12 18:42:40 --> Helper loaded: file_helper
INFO - 2024-03-12 18:42:40 --> Helper loaded: form_helper
INFO - 2024-03-12 18:42:40 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:42:40 --> Controller Class Initialized
INFO - 2024-03-12 18:42:40 --> Form Validation Class Initialized
INFO - 2024-03-12 18:42:40 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:42:40 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:42:40 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:42:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:42:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:42:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:42:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:42:40 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:42:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:42:40 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:42:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:42:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:42:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:42:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:42:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:42:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/filter_form.php
INFO - 2024-03-12 18:42:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/view_cart.php
INFO - 2024-03-12 18:42:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-03-12 18:42:40 --> Final output sent to browser
DEBUG - 2024-03-12 18:42:40 --> Total execution time: 0.0405
ERROR - 2024-03-12 18:42:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:42:41 --> Config Class Initialized
INFO - 2024-03-12 18:42:41 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:42:41 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:42:41 --> Utf8 Class Initialized
INFO - 2024-03-12 18:42:41 --> URI Class Initialized
INFO - 2024-03-12 18:42:41 --> Router Class Initialized
INFO - 2024-03-12 18:42:41 --> Output Class Initialized
INFO - 2024-03-12 18:42:41 --> Security Class Initialized
DEBUG - 2024-03-12 18:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:42:41 --> Input Class Initialized
INFO - 2024-03-12 18:42:41 --> Language Class Initialized
INFO - 2024-03-12 18:42:41 --> Loader Class Initialized
INFO - 2024-03-12 18:42:41 --> Helper loaded: url_helper
INFO - 2024-03-12 18:42:41 --> Helper loaded: file_helper
INFO - 2024-03-12 18:42:41 --> Helper loaded: form_helper
INFO - 2024-03-12 18:42:41 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:42:41 --> Controller Class Initialized
INFO - 2024-03-12 18:42:41 --> Form Validation Class Initialized
INFO - 2024-03-12 18:42:41 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:42:41 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:42:41 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:42:41 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:42:41 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:42:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:42:41 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:42:41 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:42:41 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:42:41 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:44:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:44:21 --> Config Class Initialized
INFO - 2024-03-12 18:44:21 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:44:21 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:44:21 --> Utf8 Class Initialized
INFO - 2024-03-12 18:44:21 --> URI Class Initialized
INFO - 2024-03-12 18:44:21 --> Router Class Initialized
INFO - 2024-03-12 18:44:21 --> Output Class Initialized
INFO - 2024-03-12 18:44:21 --> Security Class Initialized
DEBUG - 2024-03-12 18:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:44:21 --> Input Class Initialized
INFO - 2024-03-12 18:44:21 --> Language Class Initialized
INFO - 2024-03-12 18:44:21 --> Loader Class Initialized
INFO - 2024-03-12 18:44:21 --> Helper loaded: url_helper
INFO - 2024-03-12 18:44:21 --> Helper loaded: file_helper
INFO - 2024-03-12 18:44:21 --> Helper loaded: form_helper
INFO - 2024-03-12 18:44:21 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:44:21 --> Controller Class Initialized
INFO - 2024-03-12 18:44:21 --> Form Validation Class Initialized
INFO - 2024-03-12 18:44:21 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:44:21 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:44:21 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:44:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:44:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:44:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:44:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:44:21 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:44:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:44:21 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-12 18:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:44:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-12 18:44:21 --> Final output sent to browser
DEBUG - 2024-03-12 18:44:21 --> Total execution time: 0.0272
ERROR - 2024-03-12 18:44:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:44:22 --> Config Class Initialized
INFO - 2024-03-12 18:44:22 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:44:22 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:44:22 --> Utf8 Class Initialized
INFO - 2024-03-12 18:44:22 --> URI Class Initialized
INFO - 2024-03-12 18:44:22 --> Router Class Initialized
INFO - 2024-03-12 18:44:22 --> Output Class Initialized
INFO - 2024-03-12 18:44:22 --> Security Class Initialized
DEBUG - 2024-03-12 18:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:44:22 --> Input Class Initialized
INFO - 2024-03-12 18:44:22 --> Language Class Initialized
INFO - 2024-03-12 18:44:22 --> Loader Class Initialized
INFO - 2024-03-12 18:44:22 --> Helper loaded: url_helper
INFO - 2024-03-12 18:44:22 --> Helper loaded: file_helper
INFO - 2024-03-12 18:44:22 --> Helper loaded: form_helper
INFO - 2024-03-12 18:44:22 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:44:22 --> Controller Class Initialized
INFO - 2024-03-12 18:44:22 --> Form Validation Class Initialized
INFO - 2024-03-12 18:44:22 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:44:22 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:44:22 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:44:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:44:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:44:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:44:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:44:22 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:44:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:44:22 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:44:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:44:24 --> Config Class Initialized
INFO - 2024-03-12 18:44:24 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:44:24 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:44:24 --> Utf8 Class Initialized
INFO - 2024-03-12 18:44:24 --> URI Class Initialized
INFO - 2024-03-12 18:44:24 --> Router Class Initialized
INFO - 2024-03-12 18:44:24 --> Output Class Initialized
INFO - 2024-03-12 18:44:24 --> Security Class Initialized
DEBUG - 2024-03-12 18:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:44:24 --> Input Class Initialized
INFO - 2024-03-12 18:44:24 --> Language Class Initialized
INFO - 2024-03-12 18:44:24 --> Loader Class Initialized
INFO - 2024-03-12 18:44:24 --> Helper loaded: url_helper
INFO - 2024-03-12 18:44:24 --> Helper loaded: file_helper
INFO - 2024-03-12 18:44:24 --> Helper loaded: form_helper
INFO - 2024-03-12 18:44:24 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:44:24 --> Controller Class Initialized
INFO - 2024-03-12 18:44:24 --> Form Validation Class Initialized
INFO - 2024-03-12 18:44:24 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:44:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:44:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:44:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:44:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:44:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:44:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-12 18:44:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-12 18:44:24 --> Final output sent to browser
DEBUG - 2024-03-12 18:44:24 --> Total execution time: 0.0230
ERROR - 2024-03-12 18:44:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:44:24 --> Config Class Initialized
INFO - 2024-03-12 18:44:24 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:44:24 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:44:24 --> Utf8 Class Initialized
INFO - 2024-03-12 18:44:24 --> URI Class Initialized
INFO - 2024-03-12 18:44:24 --> Router Class Initialized
INFO - 2024-03-12 18:44:24 --> Output Class Initialized
INFO - 2024-03-12 18:44:24 --> Security Class Initialized
DEBUG - 2024-03-12 18:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:44:24 --> Input Class Initialized
INFO - 2024-03-12 18:44:24 --> Language Class Initialized
INFO - 2024-03-12 18:44:24 --> Loader Class Initialized
INFO - 2024-03-12 18:44:24 --> Helper loaded: url_helper
INFO - 2024-03-12 18:44:24 --> Helper loaded: file_helper
INFO - 2024-03-12 18:44:24 --> Helper loaded: form_helper
INFO - 2024-03-12 18:44:24 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:44:24 --> Controller Class Initialized
INFO - 2024-03-12 18:44:24 --> Form Validation Class Initialized
INFO - 2024-03-12 18:44:24 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:44:24 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:44:26 --> Config Class Initialized
INFO - 2024-03-12 18:44:26 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:44:26 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:44:26 --> Utf8 Class Initialized
INFO - 2024-03-12 18:44:26 --> URI Class Initialized
INFO - 2024-03-12 18:44:26 --> Router Class Initialized
INFO - 2024-03-12 18:44:26 --> Output Class Initialized
INFO - 2024-03-12 18:44:26 --> Security Class Initialized
DEBUG - 2024-03-12 18:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:44:26 --> Input Class Initialized
INFO - 2024-03-12 18:44:26 --> Language Class Initialized
INFO - 2024-03-12 18:44:26 --> Loader Class Initialized
INFO - 2024-03-12 18:44:26 --> Helper loaded: url_helper
INFO - 2024-03-12 18:44:26 --> Helper loaded: file_helper
INFO - 2024-03-12 18:44:26 --> Helper loaded: form_helper
INFO - 2024-03-12 18:44:26 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:44:26 --> Controller Class Initialized
INFO - 2024-03-12 18:44:26 --> Form Validation Class Initialized
INFO - 2024-03-12 18:44:27 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:44:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:44:27 --> Final output sent to browser
DEBUG - 2024-03-12 18:44:27 --> Total execution time: 0.0341
ERROR - 2024-03-12 18:44:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:44:27 --> Config Class Initialized
INFO - 2024-03-12 18:44:27 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:44:27 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:44:27 --> Utf8 Class Initialized
INFO - 2024-03-12 18:44:27 --> URI Class Initialized
INFO - 2024-03-12 18:44:27 --> Router Class Initialized
INFO - 2024-03-12 18:44:27 --> Output Class Initialized
INFO - 2024-03-12 18:44:27 --> Security Class Initialized
DEBUG - 2024-03-12 18:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:44:27 --> Input Class Initialized
INFO - 2024-03-12 18:44:27 --> Language Class Initialized
INFO - 2024-03-12 18:44:27 --> Loader Class Initialized
INFO - 2024-03-12 18:44:27 --> Helper loaded: url_helper
INFO - 2024-03-12 18:44:27 --> Helper loaded: file_helper
INFO - 2024-03-12 18:44:27 --> Helper loaded: form_helper
INFO - 2024-03-12 18:44:27 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:44:27 --> Controller Class Initialized
INFO - 2024-03-12 18:44:27 --> Form Validation Class Initialized
INFO - 2024-03-12 18:44:27 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:44:27 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:44:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:44:51 --> Config Class Initialized
INFO - 2024-03-12 18:44:51 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:44:51 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:44:51 --> Utf8 Class Initialized
INFO - 2024-03-12 18:44:51 --> URI Class Initialized
INFO - 2024-03-12 18:44:51 --> Router Class Initialized
INFO - 2024-03-12 18:44:51 --> Output Class Initialized
INFO - 2024-03-12 18:44:51 --> Security Class Initialized
DEBUG - 2024-03-12 18:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:44:51 --> Input Class Initialized
INFO - 2024-03-12 18:44:51 --> Language Class Initialized
INFO - 2024-03-12 18:44:51 --> Loader Class Initialized
INFO - 2024-03-12 18:44:51 --> Helper loaded: url_helper
INFO - 2024-03-12 18:44:51 --> Helper loaded: file_helper
INFO - 2024-03-12 18:44:51 --> Helper loaded: form_helper
INFO - 2024-03-12 18:44:51 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:44:51 --> Controller Class Initialized
INFO - 2024-03-12 18:44:51 --> Form Validation Class Initialized
INFO - 2024-03-12 18:44:51 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:44:51 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:44:51 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:44:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:44:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:44:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:44:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:44:51 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:44:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:44:51 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:45:29 --> Config Class Initialized
INFO - 2024-03-12 18:45:29 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:45:29 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:45:29 --> Utf8 Class Initialized
INFO - 2024-03-12 18:45:29 --> URI Class Initialized
INFO - 2024-03-12 18:45:29 --> Router Class Initialized
INFO - 2024-03-12 18:45:29 --> Output Class Initialized
INFO - 2024-03-12 18:45:29 --> Security Class Initialized
DEBUG - 2024-03-12 18:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:45:29 --> Input Class Initialized
INFO - 2024-03-12 18:45:29 --> Language Class Initialized
INFO - 2024-03-12 18:45:29 --> Loader Class Initialized
INFO - 2024-03-12 18:45:29 --> Helper loaded: url_helper
INFO - 2024-03-12 18:45:29 --> Helper loaded: file_helper
INFO - 2024-03-12 18:45:29 --> Helper loaded: form_helper
INFO - 2024-03-12 18:45:29 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:45:29 --> Controller Class Initialized
INFO - 2024-03-12 18:45:29 --> Form Validation Class Initialized
INFO - 2024-03-12 18:45:29 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:45:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:45:29 --> Final output sent to browser
DEBUG - 2024-03-12 18:45:29 --> Total execution time: 0.0314
ERROR - 2024-03-12 18:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:45:29 --> Config Class Initialized
INFO - 2024-03-12 18:45:29 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:45:29 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:45:29 --> Utf8 Class Initialized
INFO - 2024-03-12 18:45:29 --> URI Class Initialized
INFO - 2024-03-12 18:45:29 --> Router Class Initialized
INFO - 2024-03-12 18:45:29 --> Output Class Initialized
INFO - 2024-03-12 18:45:29 --> Security Class Initialized
DEBUG - 2024-03-12 18:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:45:29 --> Input Class Initialized
INFO - 2024-03-12 18:45:29 --> Language Class Initialized
INFO - 2024-03-12 18:45:29 --> Loader Class Initialized
INFO - 2024-03-12 18:45:29 --> Helper loaded: url_helper
INFO - 2024-03-12 18:45:29 --> Helper loaded: file_helper
INFO - 2024-03-12 18:45:29 --> Helper loaded: form_helper
INFO - 2024-03-12 18:45:29 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:45:29 --> Controller Class Initialized
INFO - 2024-03-12 18:45:29 --> Form Validation Class Initialized
INFO - 2024-03-12 18:45:29 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:45:29 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:46:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:46:09 --> Config Class Initialized
INFO - 2024-03-12 18:46:09 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:46:09 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:46:09 --> Utf8 Class Initialized
INFO - 2024-03-12 18:46:09 --> URI Class Initialized
INFO - 2024-03-12 18:46:09 --> Router Class Initialized
INFO - 2024-03-12 18:46:09 --> Output Class Initialized
INFO - 2024-03-12 18:46:09 --> Security Class Initialized
DEBUG - 2024-03-12 18:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:46:09 --> Input Class Initialized
INFO - 2024-03-12 18:46:09 --> Language Class Initialized
INFO - 2024-03-12 18:46:09 --> Loader Class Initialized
INFO - 2024-03-12 18:46:09 --> Helper loaded: url_helper
INFO - 2024-03-12 18:46:09 --> Helper loaded: file_helper
INFO - 2024-03-12 18:46:09 --> Helper loaded: form_helper
INFO - 2024-03-12 18:46:09 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:46:09 --> Controller Class Initialized
INFO - 2024-03-12 18:46:09 --> Form Validation Class Initialized
INFO - 2024-03-12 18:46:09 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:46:09 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:46:09 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:46:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:46:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:46:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:46:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:46:09 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:46:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:46:09 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:46:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:46:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:46:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:46:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:46:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:46:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:46:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:46:09 --> Final output sent to browser
DEBUG - 2024-03-12 18:46:09 --> Total execution time: 0.0470
ERROR - 2024-03-12 18:46:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:46:10 --> Config Class Initialized
INFO - 2024-03-12 18:46:10 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:46:10 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:46:10 --> Utf8 Class Initialized
INFO - 2024-03-12 18:46:10 --> URI Class Initialized
INFO - 2024-03-12 18:46:10 --> Router Class Initialized
INFO - 2024-03-12 18:46:10 --> Output Class Initialized
INFO - 2024-03-12 18:46:10 --> Security Class Initialized
DEBUG - 2024-03-12 18:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:46:10 --> Input Class Initialized
INFO - 2024-03-12 18:46:10 --> Language Class Initialized
INFO - 2024-03-12 18:46:10 --> Loader Class Initialized
INFO - 2024-03-12 18:46:10 --> Helper loaded: url_helper
INFO - 2024-03-12 18:46:10 --> Helper loaded: file_helper
INFO - 2024-03-12 18:46:10 --> Helper loaded: form_helper
INFO - 2024-03-12 18:46:10 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:46:10 --> Controller Class Initialized
INFO - 2024-03-12 18:46:10 --> Form Validation Class Initialized
INFO - 2024-03-12 18:46:10 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:46:10 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:46:10 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:46:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:46:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:46:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:46:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:46:10 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:46:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:46:10 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:46:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:46:22 --> Config Class Initialized
INFO - 2024-03-12 18:46:22 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:46:22 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:46:22 --> Utf8 Class Initialized
INFO - 2024-03-12 18:46:22 --> URI Class Initialized
INFO - 2024-03-12 18:46:22 --> Router Class Initialized
INFO - 2024-03-12 18:46:22 --> Output Class Initialized
INFO - 2024-03-12 18:46:22 --> Security Class Initialized
DEBUG - 2024-03-12 18:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:46:22 --> Input Class Initialized
INFO - 2024-03-12 18:46:22 --> Language Class Initialized
INFO - 2024-03-12 18:46:22 --> Loader Class Initialized
INFO - 2024-03-12 18:46:22 --> Helper loaded: url_helper
INFO - 2024-03-12 18:46:22 --> Helper loaded: file_helper
INFO - 2024-03-12 18:46:22 --> Helper loaded: form_helper
INFO - 2024-03-12 18:46:22 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:46:22 --> Controller Class Initialized
INFO - 2024-03-12 18:46:22 --> Form Validation Class Initialized
INFO - 2024-03-12 18:46:22 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:46:22 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:46:22 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:46:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:46:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:46:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:46:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:46:22 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:46:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:46:22 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-12 18:46:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-12 18:46:22 --> Final output sent to browser
DEBUG - 2024-03-12 18:46:22 --> Total execution time: 0.0403
ERROR - 2024-03-12 18:46:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:46:23 --> Config Class Initialized
INFO - 2024-03-12 18:46:23 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:46:23 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:46:23 --> Utf8 Class Initialized
INFO - 2024-03-12 18:46:23 --> URI Class Initialized
INFO - 2024-03-12 18:46:23 --> Router Class Initialized
INFO - 2024-03-12 18:46:23 --> Output Class Initialized
INFO - 2024-03-12 18:46:23 --> Security Class Initialized
DEBUG - 2024-03-12 18:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:46:23 --> Input Class Initialized
INFO - 2024-03-12 18:46:23 --> Language Class Initialized
INFO - 2024-03-12 18:46:23 --> Loader Class Initialized
INFO - 2024-03-12 18:46:23 --> Helper loaded: url_helper
INFO - 2024-03-12 18:46:23 --> Helper loaded: file_helper
INFO - 2024-03-12 18:46:23 --> Helper loaded: form_helper
INFO - 2024-03-12 18:46:23 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:46:23 --> Controller Class Initialized
INFO - 2024-03-12 18:46:23 --> Form Validation Class Initialized
INFO - 2024-03-12 18:46:23 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:46:23 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:46:23 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:46:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:46:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:46:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:46:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:46:23 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:46:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:46:23 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:46:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:46:28 --> Config Class Initialized
INFO - 2024-03-12 18:46:28 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:46:28 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:46:28 --> Utf8 Class Initialized
INFO - 2024-03-12 18:46:28 --> URI Class Initialized
INFO - 2024-03-12 18:46:28 --> Router Class Initialized
INFO - 2024-03-12 18:46:28 --> Output Class Initialized
INFO - 2024-03-12 18:46:28 --> Security Class Initialized
DEBUG - 2024-03-12 18:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:46:28 --> Input Class Initialized
INFO - 2024-03-12 18:46:28 --> Language Class Initialized
INFO - 2024-03-12 18:46:28 --> Loader Class Initialized
INFO - 2024-03-12 18:46:28 --> Helper loaded: url_helper
INFO - 2024-03-12 18:46:28 --> Helper loaded: file_helper
INFO - 2024-03-12 18:46:28 --> Helper loaded: form_helper
INFO - 2024-03-12 18:46:28 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:46:28 --> Controller Class Initialized
INFO - 2024-03-12 18:46:28 --> Form Validation Class Initialized
INFO - 2024-03-12 18:46:28 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:46:28 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:46:28 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:46:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:46:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:46:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:46:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:46:28 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:46:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:46:28 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:46:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:46:30 --> Config Class Initialized
INFO - 2024-03-12 18:46:30 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:46:30 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:46:30 --> Utf8 Class Initialized
INFO - 2024-03-12 18:46:30 --> URI Class Initialized
INFO - 2024-03-12 18:46:30 --> Router Class Initialized
INFO - 2024-03-12 18:46:30 --> Output Class Initialized
INFO - 2024-03-12 18:46:30 --> Security Class Initialized
DEBUG - 2024-03-12 18:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:46:30 --> Input Class Initialized
INFO - 2024-03-12 18:46:30 --> Language Class Initialized
INFO - 2024-03-12 18:46:30 --> Loader Class Initialized
INFO - 2024-03-12 18:46:30 --> Helper loaded: url_helper
INFO - 2024-03-12 18:46:30 --> Helper loaded: file_helper
INFO - 2024-03-12 18:46:30 --> Helper loaded: form_helper
INFO - 2024-03-12 18:46:30 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:46:30 --> Controller Class Initialized
INFO - 2024-03-12 18:46:30 --> Form Validation Class Initialized
INFO - 2024-03-12 18:46:30 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:46:30 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:46:30 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:46:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:46:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:46:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:46:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:46:30 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:46:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:46:30 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:49:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:49:52 --> Config Class Initialized
INFO - 2024-03-12 18:49:52 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:49:52 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:49:52 --> Utf8 Class Initialized
INFO - 2024-03-12 18:49:52 --> URI Class Initialized
INFO - 2024-03-12 18:49:52 --> Router Class Initialized
INFO - 2024-03-12 18:49:52 --> Output Class Initialized
INFO - 2024-03-12 18:49:52 --> Security Class Initialized
DEBUG - 2024-03-12 18:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:49:52 --> Input Class Initialized
INFO - 2024-03-12 18:49:52 --> Language Class Initialized
INFO - 2024-03-12 18:49:52 --> Loader Class Initialized
INFO - 2024-03-12 18:49:52 --> Helper loaded: url_helper
INFO - 2024-03-12 18:49:52 --> Helper loaded: file_helper
INFO - 2024-03-12 18:49:52 --> Helper loaded: form_helper
INFO - 2024-03-12 18:49:52 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:49:52 --> Controller Class Initialized
INFO - 2024-03-12 18:49:52 --> Form Validation Class Initialized
INFO - 2024-03-12 18:49:52 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:49:52 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:49:52 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:49:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:49:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:49:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:49:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:49:52 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:49:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:49:52 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:49:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:49:55 --> Config Class Initialized
INFO - 2024-03-12 18:49:55 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:49:55 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:49:55 --> Utf8 Class Initialized
INFO - 2024-03-12 18:49:55 --> URI Class Initialized
INFO - 2024-03-12 18:49:55 --> Router Class Initialized
INFO - 2024-03-12 18:49:55 --> Output Class Initialized
INFO - 2024-03-12 18:49:55 --> Security Class Initialized
DEBUG - 2024-03-12 18:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:49:55 --> Input Class Initialized
INFO - 2024-03-12 18:49:55 --> Language Class Initialized
INFO - 2024-03-12 18:49:55 --> Loader Class Initialized
INFO - 2024-03-12 18:49:55 --> Helper loaded: url_helper
INFO - 2024-03-12 18:49:55 --> Helper loaded: file_helper
INFO - 2024-03-12 18:49:55 --> Helper loaded: form_helper
INFO - 2024-03-12 18:49:55 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:49:55 --> Controller Class Initialized
INFO - 2024-03-12 18:49:55 --> Form Validation Class Initialized
INFO - 2024-03-12 18:49:55 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:49:55 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:49:55 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:49:55 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:49:55 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:49:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:49:55 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:49:55 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:49:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:49:55 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:49:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:49:57 --> Config Class Initialized
INFO - 2024-03-12 18:49:57 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:49:57 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:49:57 --> Utf8 Class Initialized
INFO - 2024-03-12 18:49:57 --> URI Class Initialized
INFO - 2024-03-12 18:49:57 --> Router Class Initialized
INFO - 2024-03-12 18:49:57 --> Output Class Initialized
INFO - 2024-03-12 18:49:57 --> Security Class Initialized
DEBUG - 2024-03-12 18:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:49:57 --> Input Class Initialized
INFO - 2024-03-12 18:49:57 --> Language Class Initialized
INFO - 2024-03-12 18:49:57 --> Loader Class Initialized
INFO - 2024-03-12 18:49:57 --> Helper loaded: url_helper
INFO - 2024-03-12 18:49:57 --> Helper loaded: file_helper
INFO - 2024-03-12 18:49:57 --> Helper loaded: form_helper
INFO - 2024-03-12 18:49:57 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:49:57 --> Controller Class Initialized
INFO - 2024-03-12 18:49:57 --> Form Validation Class Initialized
INFO - 2024-03-12 18:49:57 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:49:57 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:49:57 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:49:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:49:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:49:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:49:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:49:57 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:49:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:49:57 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:50:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:50:00 --> Config Class Initialized
INFO - 2024-03-12 18:50:00 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:50:00 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:50:00 --> Utf8 Class Initialized
INFO - 2024-03-12 18:50:00 --> URI Class Initialized
INFO - 2024-03-12 18:50:00 --> Router Class Initialized
INFO - 2024-03-12 18:50:00 --> Output Class Initialized
INFO - 2024-03-12 18:50:00 --> Security Class Initialized
DEBUG - 2024-03-12 18:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:50:00 --> Input Class Initialized
INFO - 2024-03-12 18:50:00 --> Language Class Initialized
INFO - 2024-03-12 18:50:00 --> Loader Class Initialized
INFO - 2024-03-12 18:50:00 --> Helper loaded: url_helper
INFO - 2024-03-12 18:50:00 --> Helper loaded: file_helper
INFO - 2024-03-12 18:50:00 --> Helper loaded: form_helper
INFO - 2024-03-12 18:50:00 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:50:00 --> Controller Class Initialized
INFO - 2024-03-12 18:50:00 --> Form Validation Class Initialized
INFO - 2024-03-12 18:50:00 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:50:00 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:50:00 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:50:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:50:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:50:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:50:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:50:00 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:50:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:50:00 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:50:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:50:02 --> Config Class Initialized
INFO - 2024-03-12 18:50:02 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:50:02 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:50:02 --> Utf8 Class Initialized
INFO - 2024-03-12 18:50:02 --> URI Class Initialized
INFO - 2024-03-12 18:50:02 --> Router Class Initialized
INFO - 2024-03-12 18:50:02 --> Output Class Initialized
INFO - 2024-03-12 18:50:02 --> Security Class Initialized
DEBUG - 2024-03-12 18:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:50:02 --> Input Class Initialized
INFO - 2024-03-12 18:50:02 --> Language Class Initialized
INFO - 2024-03-12 18:50:02 --> Loader Class Initialized
INFO - 2024-03-12 18:50:02 --> Helper loaded: url_helper
INFO - 2024-03-12 18:50:02 --> Helper loaded: file_helper
INFO - 2024-03-12 18:50:02 --> Helper loaded: form_helper
INFO - 2024-03-12 18:50:02 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:50:02 --> Controller Class Initialized
INFO - 2024-03-12 18:50:02 --> Form Validation Class Initialized
INFO - 2024-03-12 18:50:02 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:50:02 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:50:02 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:50:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:50:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:50:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:50:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:50:02 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:50:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:50:02 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:50:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:50:06 --> Config Class Initialized
INFO - 2024-03-12 18:50:06 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:50:06 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:50:06 --> Utf8 Class Initialized
INFO - 2024-03-12 18:50:06 --> URI Class Initialized
INFO - 2024-03-12 18:50:06 --> Router Class Initialized
INFO - 2024-03-12 18:50:06 --> Output Class Initialized
INFO - 2024-03-12 18:50:06 --> Security Class Initialized
DEBUG - 2024-03-12 18:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:50:06 --> Input Class Initialized
INFO - 2024-03-12 18:50:06 --> Language Class Initialized
INFO - 2024-03-12 18:50:06 --> Loader Class Initialized
INFO - 2024-03-12 18:50:06 --> Helper loaded: url_helper
INFO - 2024-03-12 18:50:06 --> Helper loaded: file_helper
INFO - 2024-03-12 18:50:06 --> Helper loaded: form_helper
INFO - 2024-03-12 18:50:06 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:50:06 --> Controller Class Initialized
INFO - 2024-03-12 18:50:06 --> Form Validation Class Initialized
INFO - 2024-03-12 18:50:06 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:50:06 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:50:06 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:50:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:50:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:50:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:50:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:50:06 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:50:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:50:06 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:50:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:50:07 --> Config Class Initialized
INFO - 2024-03-12 18:50:07 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:50:07 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:50:07 --> Utf8 Class Initialized
INFO - 2024-03-12 18:50:07 --> URI Class Initialized
INFO - 2024-03-12 18:50:07 --> Router Class Initialized
INFO - 2024-03-12 18:50:07 --> Output Class Initialized
INFO - 2024-03-12 18:50:07 --> Security Class Initialized
DEBUG - 2024-03-12 18:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:50:07 --> Input Class Initialized
INFO - 2024-03-12 18:50:07 --> Language Class Initialized
INFO - 2024-03-12 18:50:07 --> Loader Class Initialized
INFO - 2024-03-12 18:50:07 --> Helper loaded: url_helper
INFO - 2024-03-12 18:50:07 --> Helper loaded: file_helper
INFO - 2024-03-12 18:50:07 --> Helper loaded: form_helper
INFO - 2024-03-12 18:50:07 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:50:07 --> Controller Class Initialized
INFO - 2024-03-12 18:50:07 --> Form Validation Class Initialized
INFO - 2024-03-12 18:50:07 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:50:07 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:50:07 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:50:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:50:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:50:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:50:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:50:07 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:50:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:50:07 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:50:09 --> Config Class Initialized
INFO - 2024-03-12 18:50:09 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:50:09 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:50:09 --> Utf8 Class Initialized
INFO - 2024-03-12 18:50:09 --> URI Class Initialized
INFO - 2024-03-12 18:50:09 --> Router Class Initialized
INFO - 2024-03-12 18:50:09 --> Output Class Initialized
INFO - 2024-03-12 18:50:09 --> Security Class Initialized
DEBUG - 2024-03-12 18:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:50:09 --> Input Class Initialized
INFO - 2024-03-12 18:50:09 --> Language Class Initialized
INFO - 2024-03-12 18:50:09 --> Loader Class Initialized
INFO - 2024-03-12 18:50:09 --> Helper loaded: url_helper
INFO - 2024-03-12 18:50:09 --> Helper loaded: file_helper
INFO - 2024-03-12 18:50:09 --> Helper loaded: form_helper
INFO - 2024-03-12 18:50:09 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:50:09 --> Controller Class Initialized
INFO - 2024-03-12 18:50:09 --> Form Validation Class Initialized
INFO - 2024-03-12 18:50:09 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:50:09 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:50:09 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:50:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:50:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:50:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:50:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:50:09 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:50:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:50:09 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:50:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:50:11 --> Config Class Initialized
INFO - 2024-03-12 18:50:11 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:50:11 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:50:11 --> Utf8 Class Initialized
INFO - 2024-03-12 18:50:11 --> URI Class Initialized
INFO - 2024-03-12 18:50:11 --> Router Class Initialized
INFO - 2024-03-12 18:50:11 --> Output Class Initialized
INFO - 2024-03-12 18:50:11 --> Security Class Initialized
DEBUG - 2024-03-12 18:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:50:11 --> Input Class Initialized
INFO - 2024-03-12 18:50:11 --> Language Class Initialized
INFO - 2024-03-12 18:50:11 --> Loader Class Initialized
INFO - 2024-03-12 18:50:11 --> Helper loaded: url_helper
INFO - 2024-03-12 18:50:11 --> Helper loaded: file_helper
INFO - 2024-03-12 18:50:11 --> Helper loaded: form_helper
INFO - 2024-03-12 18:50:11 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:50:11 --> Controller Class Initialized
INFO - 2024-03-12 18:50:11 --> Form Validation Class Initialized
INFO - 2024-03-12 18:50:11 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "ReportModel" initialized
INFO - 2024-03-12 18:50:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-12 18:50:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-12 18:50:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-12 18:50:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-12 18:50:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-12 18:50:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-12 18:50:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-12 18:50:11 --> Final output sent to browser
DEBUG - 2024-03-12 18:50:11 --> Total execution time: 0.0439
ERROR - 2024-03-12 18:50:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:50:11 --> Config Class Initialized
INFO - 2024-03-12 18:50:11 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:50:11 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:50:11 --> Utf8 Class Initialized
INFO - 2024-03-12 18:50:11 --> URI Class Initialized
INFO - 2024-03-12 18:50:11 --> Router Class Initialized
INFO - 2024-03-12 18:50:11 --> Output Class Initialized
INFO - 2024-03-12 18:50:11 --> Security Class Initialized
DEBUG - 2024-03-12 18:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:50:11 --> Input Class Initialized
INFO - 2024-03-12 18:50:11 --> Language Class Initialized
INFO - 2024-03-12 18:50:11 --> Loader Class Initialized
INFO - 2024-03-12 18:50:11 --> Helper loaded: url_helper
INFO - 2024-03-12 18:50:11 --> Helper loaded: file_helper
INFO - 2024-03-12 18:50:11 --> Helper loaded: form_helper
INFO - 2024-03-12 18:50:11 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:50:11 --> Controller Class Initialized
INFO - 2024-03-12 18:50:11 --> Form Validation Class Initialized
INFO - 2024-03-12 18:50:11 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:50:11 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:50:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:50:14 --> Config Class Initialized
INFO - 2024-03-12 18:50:14 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:50:14 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:50:14 --> Utf8 Class Initialized
INFO - 2024-03-12 18:50:14 --> URI Class Initialized
INFO - 2024-03-12 18:50:14 --> Router Class Initialized
INFO - 2024-03-12 18:50:14 --> Output Class Initialized
INFO - 2024-03-12 18:50:14 --> Security Class Initialized
DEBUG - 2024-03-12 18:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:50:14 --> Input Class Initialized
INFO - 2024-03-12 18:50:14 --> Language Class Initialized
INFO - 2024-03-12 18:50:14 --> Loader Class Initialized
INFO - 2024-03-12 18:50:14 --> Helper loaded: url_helper
INFO - 2024-03-12 18:50:14 --> Helper loaded: file_helper
INFO - 2024-03-12 18:50:14 --> Helper loaded: form_helper
INFO - 2024-03-12 18:50:14 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:50:14 --> Controller Class Initialized
INFO - 2024-03-12 18:50:14 --> Form Validation Class Initialized
INFO - 2024-03-12 18:50:14 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:50:14 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:50:14 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:50:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:50:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:50:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:50:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:50:14 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:50:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:50:14 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:50:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:50:17 --> Config Class Initialized
INFO - 2024-03-12 18:50:17 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:50:17 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:50:17 --> Utf8 Class Initialized
INFO - 2024-03-12 18:50:17 --> URI Class Initialized
INFO - 2024-03-12 18:50:17 --> Router Class Initialized
INFO - 2024-03-12 18:50:17 --> Output Class Initialized
INFO - 2024-03-12 18:50:17 --> Security Class Initialized
DEBUG - 2024-03-12 18:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:50:17 --> Input Class Initialized
INFO - 2024-03-12 18:50:17 --> Language Class Initialized
INFO - 2024-03-12 18:50:17 --> Loader Class Initialized
INFO - 2024-03-12 18:50:17 --> Helper loaded: url_helper
INFO - 2024-03-12 18:50:17 --> Helper loaded: file_helper
INFO - 2024-03-12 18:50:17 --> Helper loaded: form_helper
INFO - 2024-03-12 18:50:17 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:50:17 --> Controller Class Initialized
INFO - 2024-03-12 18:50:17 --> Form Validation Class Initialized
INFO - 2024-03-12 18:50:17 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:50:17 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:50:17 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:50:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:50:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:50:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:50:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:50:17 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:50:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:50:17 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:50:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:50:25 --> Config Class Initialized
INFO - 2024-03-12 18:50:25 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:50:25 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:50:25 --> Utf8 Class Initialized
INFO - 2024-03-12 18:50:25 --> URI Class Initialized
INFO - 2024-03-12 18:50:25 --> Router Class Initialized
INFO - 2024-03-12 18:50:25 --> Output Class Initialized
INFO - 2024-03-12 18:50:25 --> Security Class Initialized
DEBUG - 2024-03-12 18:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:50:25 --> Input Class Initialized
INFO - 2024-03-12 18:50:25 --> Language Class Initialized
INFO - 2024-03-12 18:50:25 --> Loader Class Initialized
INFO - 2024-03-12 18:50:25 --> Helper loaded: url_helper
INFO - 2024-03-12 18:50:25 --> Helper loaded: file_helper
INFO - 2024-03-12 18:50:25 --> Helper loaded: form_helper
INFO - 2024-03-12 18:50:25 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:50:25 --> Controller Class Initialized
INFO - 2024-03-12 18:50:25 --> Form Validation Class Initialized
INFO - 2024-03-12 18:50:25 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:50:25 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:50:25 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:50:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:50:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:50:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:50:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:50:25 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:50:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:50:25 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:50:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:50:29 --> Config Class Initialized
INFO - 2024-03-12 18:50:29 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:50:29 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:50:29 --> Utf8 Class Initialized
INFO - 2024-03-12 18:50:29 --> URI Class Initialized
INFO - 2024-03-12 18:50:29 --> Router Class Initialized
INFO - 2024-03-12 18:50:29 --> Output Class Initialized
INFO - 2024-03-12 18:50:29 --> Security Class Initialized
DEBUG - 2024-03-12 18:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:50:29 --> Input Class Initialized
INFO - 2024-03-12 18:50:29 --> Language Class Initialized
INFO - 2024-03-12 18:50:29 --> Loader Class Initialized
INFO - 2024-03-12 18:50:29 --> Helper loaded: url_helper
INFO - 2024-03-12 18:50:29 --> Helper loaded: file_helper
INFO - 2024-03-12 18:50:29 --> Helper loaded: form_helper
INFO - 2024-03-12 18:50:29 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:50:29 --> Controller Class Initialized
INFO - 2024-03-12 18:50:29 --> Form Validation Class Initialized
INFO - 2024-03-12 18:50:29 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:50:29 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:50:29 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:50:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:50:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:50:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:50:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:50:29 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:50:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:50:29 --> Model "ReportModel" initialized
ERROR - 2024-03-12 18:50:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-03-12 18:50:33 --> Config Class Initialized
INFO - 2024-03-12 18:50:33 --> Hooks Class Initialized
DEBUG - 2024-03-12 18:50:33 --> UTF-8 Support Enabled
INFO - 2024-03-12 18:50:33 --> Utf8 Class Initialized
INFO - 2024-03-12 18:50:33 --> URI Class Initialized
INFO - 2024-03-12 18:50:33 --> Router Class Initialized
INFO - 2024-03-12 18:50:33 --> Output Class Initialized
INFO - 2024-03-12 18:50:33 --> Security Class Initialized
DEBUG - 2024-03-12 18:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-12 18:50:33 --> Input Class Initialized
INFO - 2024-03-12 18:50:33 --> Language Class Initialized
INFO - 2024-03-12 18:50:33 --> Loader Class Initialized
INFO - 2024-03-12 18:50:33 --> Helper loaded: url_helper
INFO - 2024-03-12 18:50:33 --> Helper loaded: file_helper
INFO - 2024-03-12 18:50:33 --> Helper loaded: form_helper
INFO - 2024-03-12 18:50:33 --> Database Driver Class Initialized
DEBUG - 2024-03-12 18:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-12 18:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-12 18:50:33 --> Controller Class Initialized
INFO - 2024-03-12 18:50:33 --> Form Validation Class Initialized
INFO - 2024-03-12 18:50:33 --> Model "MasterModel" initialized
INFO - 2024-03-12 18:50:33 --> Model "NotificationModel" initialized
INFO - 2024-03-12 18:50:33 --> Model "DashboardModel" initialized
INFO - 2024-03-12 18:50:33 --> Model "UserMasterModel" initialized
INFO - 2024-03-12 18:50:33 --> Model "ItemGroupModel" initialized
INFO - 2024-03-12 18:50:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-12 18:50:33 --> Model "ItemMasterModel" initialized
INFO - 2024-03-12 18:50:33 --> Model "OrderModel" initialized
INFO - 2024-03-12 18:50:33 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-12 18:50:33 --> Model "ReportModel" initialized
