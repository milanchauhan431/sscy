<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-20 16:53:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 16:53:47 --> Config Class Initialized
INFO - 2024-02-20 16:53:47 --> Hooks Class Initialized
DEBUG - 2024-02-20 16:53:47 --> UTF-8 Support Enabled
INFO - 2024-02-20 16:53:47 --> Utf8 Class Initialized
INFO - 2024-02-20 16:53:47 --> URI Class Initialized
INFO - 2024-02-20 16:53:47 --> Router Class Initialized
INFO - 2024-02-20 16:53:47 --> Output Class Initialized
INFO - 2024-02-20 16:53:47 --> Security Class Initialized
DEBUG - 2024-02-20 16:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 16:53:47 --> Input Class Initialized
INFO - 2024-02-20 16:53:47 --> Language Class Initialized
INFO - 2024-02-20 16:53:47 --> Loader Class Initialized
INFO - 2024-02-20 16:53:47 --> Helper loaded: url_helper
INFO - 2024-02-20 16:53:47 --> Helper loaded: file_helper
INFO - 2024-02-20 16:53:47 --> Helper loaded: form_helper
INFO - 2024-02-20 16:53:47 --> Database Driver Class Initialized
DEBUG - 2024-02-20 16:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 16:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 16:53:47 --> Controller Class Initialized
INFO - 2024-02-20 16:53:47 --> Model "LoginModel" initialized
INFO - 2024-02-20 16:53:47 --> Form Validation Class Initialized
INFO - 2024-02-20 16:53:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-20 16:53:47 --> Final output sent to browser
DEBUG - 2024-02-20 16:53:47 --> Total execution time: 0.2759
ERROR - 2024-02-20 19:01:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:01:03 --> Config Class Initialized
INFO - 2024-02-20 19:01:03 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:01:03 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:01:03 --> Utf8 Class Initialized
INFO - 2024-02-20 19:01:03 --> URI Class Initialized
INFO - 2024-02-20 19:01:03 --> Router Class Initialized
INFO - 2024-02-20 19:01:03 --> Output Class Initialized
INFO - 2024-02-20 19:01:03 --> Security Class Initialized
DEBUG - 2024-02-20 19:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:01:03 --> Input Class Initialized
INFO - 2024-02-20 19:01:03 --> Language Class Initialized
INFO - 2024-02-20 19:01:03 --> Loader Class Initialized
INFO - 2024-02-20 19:01:03 --> Helper loaded: url_helper
INFO - 2024-02-20 19:01:03 --> Helper loaded: file_helper
INFO - 2024-02-20 19:01:03 --> Helper loaded: form_helper
INFO - 2024-02-20 19:01:03 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:01:03 --> Controller Class Initialized
INFO - 2024-02-20 19:01:03 --> Model "LoginModel" initialized
INFO - 2024-02-20 19:01:03 --> Form Validation Class Initialized
ERROR - 2024-02-20 19:01:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:01:03 --> Config Class Initialized
INFO - 2024-02-20 19:01:03 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:01:03 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:01:03 --> Utf8 Class Initialized
INFO - 2024-02-20 19:01:03 --> URI Class Initialized
INFO - 2024-02-20 19:01:03 --> Router Class Initialized
INFO - 2024-02-20 19:01:03 --> Output Class Initialized
INFO - 2024-02-20 19:01:03 --> Security Class Initialized
DEBUG - 2024-02-20 19:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:01:03 --> Input Class Initialized
INFO - 2024-02-20 19:01:03 --> Language Class Initialized
INFO - 2024-02-20 19:01:03 --> Loader Class Initialized
INFO - 2024-02-20 19:01:03 --> Helper loaded: url_helper
INFO - 2024-02-20 19:01:03 --> Helper loaded: file_helper
INFO - 2024-02-20 19:01:03 --> Helper loaded: form_helper
INFO - 2024-02-20 19:01:03 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:01:03 --> Controller Class Initialized
INFO - 2024-02-20 19:01:03 --> Form Validation Class Initialized
INFO - 2024-02-20 19:01:03 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:01:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:01:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:01:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:01:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:01:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:01:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-20 19:01:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:01:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:01:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:01:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-20 19:01:03 --> Final output sent to browser
DEBUG - 2024-02-20 19:01:03 --> Total execution time: 0.1169
ERROR - 2024-02-20 19:05:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:05:48 --> Config Class Initialized
INFO - 2024-02-20 19:05:48 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:05:48 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:05:48 --> Utf8 Class Initialized
INFO - 2024-02-20 19:05:48 --> URI Class Initialized
INFO - 2024-02-20 19:05:48 --> Router Class Initialized
INFO - 2024-02-20 19:05:48 --> Output Class Initialized
INFO - 2024-02-20 19:05:48 --> Security Class Initialized
DEBUG - 2024-02-20 19:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:05:48 --> Input Class Initialized
INFO - 2024-02-20 19:05:48 --> Language Class Initialized
INFO - 2024-02-20 19:05:48 --> Loader Class Initialized
INFO - 2024-02-20 19:05:48 --> Helper loaded: url_helper
INFO - 2024-02-20 19:05:48 --> Helper loaded: file_helper
INFO - 2024-02-20 19:05:48 --> Helper loaded: form_helper
INFO - 2024-02-20 19:05:48 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:05:48 --> Controller Class Initialized
INFO - 2024-02-20 19:05:48 --> Form Validation Class Initialized
INFO - 2024-02-20 19:05:48 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:05:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:05:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:05:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:05:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:05:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:05:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-20 19:05:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:05:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:05:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:05:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-20 19:05:48 --> Final output sent to browser
DEBUG - 2024-02-20 19:05:48 --> Total execution time: 0.0773
ERROR - 2024-02-20 19:05:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:05:50 --> Config Class Initialized
INFO - 2024-02-20 19:05:50 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:05:50 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:05:50 --> Utf8 Class Initialized
INFO - 2024-02-20 19:05:50 --> URI Class Initialized
INFO - 2024-02-20 19:05:50 --> Router Class Initialized
INFO - 2024-02-20 19:05:50 --> Output Class Initialized
INFO - 2024-02-20 19:05:50 --> Security Class Initialized
DEBUG - 2024-02-20 19:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:05:50 --> Input Class Initialized
INFO - 2024-02-20 19:05:50 --> Language Class Initialized
INFO - 2024-02-20 19:05:50 --> Loader Class Initialized
INFO - 2024-02-20 19:05:50 --> Helper loaded: url_helper
INFO - 2024-02-20 19:05:50 --> Helper loaded: file_helper
INFO - 2024-02-20 19:05:50 --> Helper loaded: form_helper
INFO - 2024-02-20 19:05:50 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:05:50 --> Controller Class Initialized
INFO - 2024-02-20 19:05:50 --> Form Validation Class Initialized
INFO - 2024-02-20 19:05:50 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:05:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:05:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:05:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:05:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:05:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:05:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:05:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:05:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:05:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:05:50 --> Final output sent to browser
DEBUG - 2024-02-20 19:05:50 --> Total execution time: 0.0631
ERROR - 2024-02-20 19:05:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:05:52 --> Config Class Initialized
INFO - 2024-02-20 19:05:52 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:05:52 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:05:52 --> Utf8 Class Initialized
INFO - 2024-02-20 19:05:52 --> URI Class Initialized
INFO - 2024-02-20 19:05:52 --> Router Class Initialized
INFO - 2024-02-20 19:05:52 --> Output Class Initialized
INFO - 2024-02-20 19:05:52 --> Security Class Initialized
DEBUG - 2024-02-20 19:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:05:52 --> Input Class Initialized
INFO - 2024-02-20 19:05:52 --> Language Class Initialized
INFO - 2024-02-20 19:05:52 --> Loader Class Initialized
INFO - 2024-02-20 19:05:52 --> Helper loaded: url_helper
INFO - 2024-02-20 19:05:52 --> Helper loaded: file_helper
INFO - 2024-02-20 19:05:52 --> Helper loaded: form_helper
INFO - 2024-02-20 19:05:52 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:05:52 --> Controller Class Initialized
INFO - 2024-02-20 19:05:52 --> Form Validation Class Initialized
INFO - 2024-02-20 19:05:52 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:05:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:05:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:05:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:05:52 --> Model "ItemMasterModel" initialized
ERROR - 2024-02-20 19:06:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:06:09 --> Config Class Initialized
INFO - 2024-02-20 19:06:09 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:06:09 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:06:09 --> Utf8 Class Initialized
INFO - 2024-02-20 19:06:09 --> URI Class Initialized
INFO - 2024-02-20 19:06:09 --> Router Class Initialized
INFO - 2024-02-20 19:06:09 --> Output Class Initialized
INFO - 2024-02-20 19:06:09 --> Security Class Initialized
DEBUG - 2024-02-20 19:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:06:09 --> Input Class Initialized
INFO - 2024-02-20 19:06:09 --> Language Class Initialized
INFO - 2024-02-20 19:06:09 --> Loader Class Initialized
INFO - 2024-02-20 19:06:09 --> Helper loaded: url_helper
INFO - 2024-02-20 19:06:09 --> Helper loaded: file_helper
INFO - 2024-02-20 19:06:09 --> Helper loaded: form_helper
INFO - 2024-02-20 19:06:09 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:06:09 --> Controller Class Initialized
INFO - 2024-02-20 19:06:09 --> Form Validation Class Initialized
INFO - 2024-02-20 19:06:09 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:06:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:06:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:06:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:06:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:06:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:06:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:06:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:06:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:06:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:06:09 --> Final output sent to browser
DEBUG - 2024-02-20 19:06:09 --> Total execution time: 0.1612
ERROR - 2024-02-20 19:12:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:12:17 --> Config Class Initialized
INFO - 2024-02-20 19:12:17 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:12:17 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:12:17 --> Utf8 Class Initialized
INFO - 2024-02-20 19:12:17 --> URI Class Initialized
INFO - 2024-02-20 19:12:17 --> Router Class Initialized
INFO - 2024-02-20 19:12:17 --> Output Class Initialized
INFO - 2024-02-20 19:12:17 --> Security Class Initialized
DEBUG - 2024-02-20 19:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:12:17 --> Input Class Initialized
INFO - 2024-02-20 19:12:17 --> Language Class Initialized
INFO - 2024-02-20 19:12:17 --> Loader Class Initialized
INFO - 2024-02-20 19:12:17 --> Helper loaded: url_helper
INFO - 2024-02-20 19:12:17 --> Helper loaded: file_helper
INFO - 2024-02-20 19:12:17 --> Helper loaded: form_helper
INFO - 2024-02-20 19:12:17 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:12:17 --> Controller Class Initialized
INFO - 2024-02-20 19:12:17 --> Form Validation Class Initialized
INFO - 2024-02-20 19:12:17 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:12:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:12:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:12:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:12:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:12:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:12:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:12:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:12:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:12:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:12:17 --> Final output sent to browser
DEBUG - 2024-02-20 19:12:17 --> Total execution time: 0.1563
ERROR - 2024-02-20 19:13:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:13:15 --> Config Class Initialized
INFO - 2024-02-20 19:13:15 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:13:15 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:13:15 --> Utf8 Class Initialized
INFO - 2024-02-20 19:13:15 --> URI Class Initialized
INFO - 2024-02-20 19:13:15 --> Router Class Initialized
INFO - 2024-02-20 19:13:15 --> Output Class Initialized
INFO - 2024-02-20 19:13:15 --> Security Class Initialized
DEBUG - 2024-02-20 19:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:13:15 --> Input Class Initialized
INFO - 2024-02-20 19:13:15 --> Language Class Initialized
INFO - 2024-02-20 19:13:15 --> Loader Class Initialized
INFO - 2024-02-20 19:13:15 --> Helper loaded: url_helper
INFO - 2024-02-20 19:13:15 --> Helper loaded: file_helper
INFO - 2024-02-20 19:13:15 --> Helper loaded: form_helper
INFO - 2024-02-20 19:13:15 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:13:15 --> Controller Class Initialized
INFO - 2024-02-20 19:13:15 --> Form Validation Class Initialized
INFO - 2024-02-20 19:13:15 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:13:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:13:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:13:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:13:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:13:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:13:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:13:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:13:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:13:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:13:15 --> Final output sent to browser
DEBUG - 2024-02-20 19:13:15 --> Total execution time: 0.0517
ERROR - 2024-02-20 19:13:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:13:18 --> Config Class Initialized
INFO - 2024-02-20 19:13:18 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:13:18 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:13:18 --> Utf8 Class Initialized
INFO - 2024-02-20 19:13:18 --> URI Class Initialized
INFO - 2024-02-20 19:13:18 --> Router Class Initialized
INFO - 2024-02-20 19:13:18 --> Output Class Initialized
INFO - 2024-02-20 19:13:18 --> Security Class Initialized
DEBUG - 2024-02-20 19:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:13:18 --> Input Class Initialized
INFO - 2024-02-20 19:13:18 --> Language Class Initialized
INFO - 2024-02-20 19:13:18 --> Loader Class Initialized
INFO - 2024-02-20 19:13:18 --> Helper loaded: url_helper
INFO - 2024-02-20 19:13:18 --> Helper loaded: file_helper
INFO - 2024-02-20 19:13:18 --> Helper loaded: form_helper
INFO - 2024-02-20 19:13:18 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:13:18 --> Controller Class Initialized
INFO - 2024-02-20 19:13:18 --> Form Validation Class Initialized
INFO - 2024-02-20 19:13:18 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:13:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:13:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:13:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:13:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:13:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:13:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:13:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:13:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:13:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:13:18 --> Final output sent to browser
DEBUG - 2024-02-20 19:13:18 --> Total execution time: 0.0580
ERROR - 2024-02-20 19:13:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:13:47 --> Config Class Initialized
INFO - 2024-02-20 19:13:47 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:13:47 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:13:47 --> Utf8 Class Initialized
INFO - 2024-02-20 19:13:47 --> URI Class Initialized
INFO - 2024-02-20 19:13:47 --> Router Class Initialized
INFO - 2024-02-20 19:13:47 --> Output Class Initialized
INFO - 2024-02-20 19:13:47 --> Security Class Initialized
DEBUG - 2024-02-20 19:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:13:47 --> Input Class Initialized
INFO - 2024-02-20 19:13:47 --> Language Class Initialized
INFO - 2024-02-20 19:13:47 --> Loader Class Initialized
INFO - 2024-02-20 19:13:47 --> Helper loaded: url_helper
INFO - 2024-02-20 19:13:47 --> Helper loaded: file_helper
INFO - 2024-02-20 19:13:47 --> Helper loaded: form_helper
INFO - 2024-02-20 19:13:47 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:13:47 --> Controller Class Initialized
INFO - 2024-02-20 19:13:47 --> Form Validation Class Initialized
INFO - 2024-02-20 19:13:47 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:13:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:13:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:13:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:13:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:13:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:13:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:13:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:13:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:13:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:13:47 --> Final output sent to browser
DEBUG - 2024-02-20 19:13:47 --> Total execution time: 0.0576
ERROR - 2024-02-20 19:13:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:13:48 --> Config Class Initialized
INFO - 2024-02-20 19:13:48 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:13:48 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:13:48 --> Utf8 Class Initialized
INFO - 2024-02-20 19:13:48 --> URI Class Initialized
INFO - 2024-02-20 19:13:48 --> Router Class Initialized
INFO - 2024-02-20 19:13:48 --> Output Class Initialized
INFO - 2024-02-20 19:13:48 --> Security Class Initialized
DEBUG - 2024-02-20 19:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:13:48 --> Input Class Initialized
INFO - 2024-02-20 19:13:48 --> Language Class Initialized
INFO - 2024-02-20 19:13:48 --> Loader Class Initialized
INFO - 2024-02-20 19:13:48 --> Helper loaded: url_helper
INFO - 2024-02-20 19:13:48 --> Helper loaded: file_helper
INFO - 2024-02-20 19:13:48 --> Helper loaded: form_helper
INFO - 2024-02-20 19:13:48 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:13:48 --> Controller Class Initialized
INFO - 2024-02-20 19:13:48 --> Form Validation Class Initialized
INFO - 2024-02-20 19:13:48 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:13:48 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:13:48 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:13:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:13:48 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:13:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:13:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:13:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:13:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:13:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:13:48 --> Final output sent to browser
DEBUG - 2024-02-20 19:13:48 --> Total execution time: 0.0973
ERROR - 2024-02-20 19:14:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:14:08 --> Config Class Initialized
INFO - 2024-02-20 19:14:08 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:14:08 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:14:08 --> Utf8 Class Initialized
INFO - 2024-02-20 19:14:08 --> URI Class Initialized
INFO - 2024-02-20 19:14:08 --> Router Class Initialized
INFO - 2024-02-20 19:14:08 --> Output Class Initialized
INFO - 2024-02-20 19:14:08 --> Security Class Initialized
DEBUG - 2024-02-20 19:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:14:08 --> Input Class Initialized
INFO - 2024-02-20 19:14:08 --> Language Class Initialized
INFO - 2024-02-20 19:14:08 --> Loader Class Initialized
INFO - 2024-02-20 19:14:08 --> Helper loaded: url_helper
INFO - 2024-02-20 19:14:08 --> Helper loaded: file_helper
INFO - 2024-02-20 19:14:08 --> Helper loaded: form_helper
INFO - 2024-02-20 19:14:08 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:14:08 --> Controller Class Initialized
INFO - 2024-02-20 19:14:08 --> Form Validation Class Initialized
INFO - 2024-02-20 19:14:08 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:14:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:14:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:14:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:14:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:14:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:14:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:14:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:14:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:14:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:14:08 --> Final output sent to browser
DEBUG - 2024-02-20 19:14:08 --> Total execution time: 0.0705
ERROR - 2024-02-20 19:15:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:15:03 --> Config Class Initialized
INFO - 2024-02-20 19:15:03 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:15:03 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:15:03 --> Utf8 Class Initialized
INFO - 2024-02-20 19:15:03 --> URI Class Initialized
INFO - 2024-02-20 19:15:03 --> Router Class Initialized
INFO - 2024-02-20 19:15:03 --> Output Class Initialized
INFO - 2024-02-20 19:15:03 --> Security Class Initialized
DEBUG - 2024-02-20 19:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:15:03 --> Input Class Initialized
INFO - 2024-02-20 19:15:03 --> Language Class Initialized
INFO - 2024-02-20 19:15:03 --> Loader Class Initialized
INFO - 2024-02-20 19:15:03 --> Helper loaded: url_helper
INFO - 2024-02-20 19:15:03 --> Helper loaded: file_helper
INFO - 2024-02-20 19:15:03 --> Helper loaded: form_helper
INFO - 2024-02-20 19:15:03 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:15:03 --> Controller Class Initialized
INFO - 2024-02-20 19:15:03 --> Form Validation Class Initialized
INFO - 2024-02-20 19:15:03 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:15:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:15:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:15:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:15:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:15:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:15:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:15:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:15:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:15:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:15:03 --> Final output sent to browser
DEBUG - 2024-02-20 19:15:03 --> Total execution time: 0.0560
ERROR - 2024-02-20 19:18:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:18:37 --> Config Class Initialized
INFO - 2024-02-20 19:18:37 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:18:37 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:18:37 --> Utf8 Class Initialized
INFO - 2024-02-20 19:18:37 --> URI Class Initialized
INFO - 2024-02-20 19:18:37 --> Router Class Initialized
INFO - 2024-02-20 19:18:37 --> Output Class Initialized
INFO - 2024-02-20 19:18:37 --> Security Class Initialized
DEBUG - 2024-02-20 19:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:18:37 --> Input Class Initialized
INFO - 2024-02-20 19:18:37 --> Language Class Initialized
INFO - 2024-02-20 19:18:37 --> Loader Class Initialized
INFO - 2024-02-20 19:18:37 --> Helper loaded: url_helper
INFO - 2024-02-20 19:18:37 --> Helper loaded: file_helper
INFO - 2024-02-20 19:18:37 --> Helper loaded: form_helper
INFO - 2024-02-20 19:18:37 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:18:37 --> Controller Class Initialized
INFO - 2024-02-20 19:18:37 --> Form Validation Class Initialized
INFO - 2024-02-20 19:18:37 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:18:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:18:37 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:18:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:18:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:18:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:18:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:18:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:18:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:18:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:18:37 --> Final output sent to browser
DEBUG - 2024-02-20 19:18:37 --> Total execution time: 0.0512
ERROR - 2024-02-20 19:21:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:21:24 --> Config Class Initialized
INFO - 2024-02-20 19:21:24 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:21:24 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:21:24 --> Utf8 Class Initialized
INFO - 2024-02-20 19:21:24 --> URI Class Initialized
INFO - 2024-02-20 19:21:24 --> Router Class Initialized
INFO - 2024-02-20 19:21:24 --> Output Class Initialized
INFO - 2024-02-20 19:21:24 --> Security Class Initialized
DEBUG - 2024-02-20 19:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:21:24 --> Input Class Initialized
INFO - 2024-02-20 19:21:24 --> Language Class Initialized
INFO - 2024-02-20 19:21:24 --> Loader Class Initialized
INFO - 2024-02-20 19:21:24 --> Helper loaded: url_helper
INFO - 2024-02-20 19:21:24 --> Helper loaded: file_helper
INFO - 2024-02-20 19:21:24 --> Helper loaded: form_helper
INFO - 2024-02-20 19:21:24 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:21:24 --> Controller Class Initialized
INFO - 2024-02-20 19:21:24 --> Form Validation Class Initialized
INFO - 2024-02-20 19:21:24 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:21:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:21:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:21:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:21:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:21:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:21:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:21:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:21:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:21:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:21:24 --> Final output sent to browser
DEBUG - 2024-02-20 19:21:24 --> Total execution time: 0.0567
ERROR - 2024-02-20 19:22:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:22:13 --> Config Class Initialized
INFO - 2024-02-20 19:22:13 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:22:13 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:22:13 --> Utf8 Class Initialized
INFO - 2024-02-20 19:22:13 --> URI Class Initialized
INFO - 2024-02-20 19:22:13 --> Router Class Initialized
INFO - 2024-02-20 19:22:13 --> Output Class Initialized
INFO - 2024-02-20 19:22:13 --> Security Class Initialized
DEBUG - 2024-02-20 19:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:22:13 --> Input Class Initialized
INFO - 2024-02-20 19:22:13 --> Language Class Initialized
INFO - 2024-02-20 19:22:13 --> Loader Class Initialized
INFO - 2024-02-20 19:22:13 --> Helper loaded: url_helper
INFO - 2024-02-20 19:22:13 --> Helper loaded: file_helper
INFO - 2024-02-20 19:22:13 --> Helper loaded: form_helper
INFO - 2024-02-20 19:22:13 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:22:13 --> Controller Class Initialized
INFO - 2024-02-20 19:22:13 --> Form Validation Class Initialized
INFO - 2024-02-20 19:22:13 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:22:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:22:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:22:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:22:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:22:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:22:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:22:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:22:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:22:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:22:13 --> Final output sent to browser
DEBUG - 2024-02-20 19:22:13 --> Total execution time: 0.0637
ERROR - 2024-02-20 19:22:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:22:43 --> Config Class Initialized
INFO - 2024-02-20 19:22:43 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:22:43 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:22:43 --> Utf8 Class Initialized
INFO - 2024-02-20 19:22:43 --> URI Class Initialized
INFO - 2024-02-20 19:22:43 --> Router Class Initialized
INFO - 2024-02-20 19:22:43 --> Output Class Initialized
INFO - 2024-02-20 19:22:43 --> Security Class Initialized
DEBUG - 2024-02-20 19:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:22:43 --> Input Class Initialized
INFO - 2024-02-20 19:22:43 --> Language Class Initialized
INFO - 2024-02-20 19:22:43 --> Loader Class Initialized
INFO - 2024-02-20 19:22:43 --> Helper loaded: url_helper
INFO - 2024-02-20 19:22:43 --> Helper loaded: file_helper
INFO - 2024-02-20 19:22:43 --> Helper loaded: form_helper
INFO - 2024-02-20 19:22:43 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:22:43 --> Controller Class Initialized
INFO - 2024-02-20 19:22:43 --> Form Validation Class Initialized
INFO - 2024-02-20 19:22:43 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:22:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:22:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:22:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:22:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:22:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:22:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:22:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:22:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:22:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:22:43 --> Final output sent to browser
DEBUG - 2024-02-20 19:22:43 --> Total execution time: 0.0516
ERROR - 2024-02-20 19:23:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:23:13 --> Config Class Initialized
INFO - 2024-02-20 19:23:13 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:23:13 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:23:13 --> Utf8 Class Initialized
INFO - 2024-02-20 19:23:13 --> URI Class Initialized
INFO - 2024-02-20 19:23:13 --> Router Class Initialized
INFO - 2024-02-20 19:23:13 --> Output Class Initialized
INFO - 2024-02-20 19:23:13 --> Security Class Initialized
DEBUG - 2024-02-20 19:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:23:13 --> Input Class Initialized
INFO - 2024-02-20 19:23:13 --> Language Class Initialized
INFO - 2024-02-20 19:23:13 --> Loader Class Initialized
INFO - 2024-02-20 19:23:13 --> Helper loaded: url_helper
INFO - 2024-02-20 19:23:13 --> Helper loaded: file_helper
INFO - 2024-02-20 19:23:13 --> Helper loaded: form_helper
INFO - 2024-02-20 19:23:13 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:23:13 --> Controller Class Initialized
INFO - 2024-02-20 19:23:13 --> Form Validation Class Initialized
INFO - 2024-02-20 19:23:13 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:23:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:23:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:23:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:23:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:23:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:23:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:23:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:23:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:23:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:23:13 --> Final output sent to browser
DEBUG - 2024-02-20 19:23:13 --> Total execution time: 0.0553
ERROR - 2024-02-20 19:23:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:23:55 --> Config Class Initialized
INFO - 2024-02-20 19:23:55 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:23:55 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:23:55 --> Utf8 Class Initialized
INFO - 2024-02-20 19:23:55 --> URI Class Initialized
INFO - 2024-02-20 19:23:55 --> Router Class Initialized
INFO - 2024-02-20 19:23:55 --> Output Class Initialized
INFO - 2024-02-20 19:23:55 --> Security Class Initialized
DEBUG - 2024-02-20 19:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:23:55 --> Input Class Initialized
INFO - 2024-02-20 19:23:55 --> Language Class Initialized
INFO - 2024-02-20 19:23:55 --> Loader Class Initialized
INFO - 2024-02-20 19:23:55 --> Helper loaded: url_helper
INFO - 2024-02-20 19:23:55 --> Helper loaded: file_helper
INFO - 2024-02-20 19:23:55 --> Helper loaded: form_helper
INFO - 2024-02-20 19:23:55 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:23:55 --> Controller Class Initialized
INFO - 2024-02-20 19:23:55 --> Form Validation Class Initialized
INFO - 2024-02-20 19:23:55 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:23:55 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:23:55 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:23:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:23:55 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:23:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:23:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:23:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:23:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:23:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:23:55 --> Final output sent to browser
DEBUG - 2024-02-20 19:23:55 --> Total execution time: 0.0581
ERROR - 2024-02-20 19:24:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:24:13 --> Config Class Initialized
INFO - 2024-02-20 19:24:13 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:24:13 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:24:13 --> Utf8 Class Initialized
INFO - 2024-02-20 19:24:13 --> URI Class Initialized
INFO - 2024-02-20 19:24:13 --> Router Class Initialized
INFO - 2024-02-20 19:24:13 --> Output Class Initialized
INFO - 2024-02-20 19:24:13 --> Security Class Initialized
DEBUG - 2024-02-20 19:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:24:13 --> Input Class Initialized
INFO - 2024-02-20 19:24:13 --> Language Class Initialized
INFO - 2024-02-20 19:24:13 --> Loader Class Initialized
INFO - 2024-02-20 19:24:13 --> Helper loaded: url_helper
INFO - 2024-02-20 19:24:13 --> Helper loaded: file_helper
INFO - 2024-02-20 19:24:13 --> Helper loaded: form_helper
INFO - 2024-02-20 19:24:13 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:24:13 --> Controller Class Initialized
INFO - 2024-02-20 19:24:13 --> Form Validation Class Initialized
INFO - 2024-02-20 19:24:13 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:24:13 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:24:13 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:24:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:24:13 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:24:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:24:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:24:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:24:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:24:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:24:13 --> Final output sent to browser
DEBUG - 2024-02-20 19:24:13 --> Total execution time: 0.0571
ERROR - 2024-02-20 19:25:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:25:03 --> Config Class Initialized
INFO - 2024-02-20 19:25:03 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:25:03 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:25:03 --> Utf8 Class Initialized
INFO - 2024-02-20 19:25:03 --> URI Class Initialized
INFO - 2024-02-20 19:25:03 --> Router Class Initialized
INFO - 2024-02-20 19:25:03 --> Output Class Initialized
INFO - 2024-02-20 19:25:03 --> Security Class Initialized
DEBUG - 2024-02-20 19:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:25:03 --> Input Class Initialized
INFO - 2024-02-20 19:25:03 --> Language Class Initialized
INFO - 2024-02-20 19:25:03 --> Loader Class Initialized
INFO - 2024-02-20 19:25:03 --> Helper loaded: url_helper
INFO - 2024-02-20 19:25:03 --> Helper loaded: file_helper
INFO - 2024-02-20 19:25:03 --> Helper loaded: form_helper
INFO - 2024-02-20 19:25:03 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:25:03 --> Controller Class Initialized
INFO - 2024-02-20 19:25:03 --> Form Validation Class Initialized
INFO - 2024-02-20 19:25:03 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:25:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:25:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:25:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:25:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:25:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:25:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:25:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:25:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:25:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:25:03 --> Final output sent to browser
DEBUG - 2024-02-20 19:25:03 --> Total execution time: 0.0629
ERROR - 2024-02-20 19:25:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:25:15 --> Config Class Initialized
INFO - 2024-02-20 19:25:15 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:25:15 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:25:15 --> Utf8 Class Initialized
INFO - 2024-02-20 19:25:15 --> URI Class Initialized
INFO - 2024-02-20 19:25:15 --> Router Class Initialized
INFO - 2024-02-20 19:25:15 --> Output Class Initialized
INFO - 2024-02-20 19:25:15 --> Security Class Initialized
DEBUG - 2024-02-20 19:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:25:15 --> Input Class Initialized
INFO - 2024-02-20 19:25:15 --> Language Class Initialized
INFO - 2024-02-20 19:25:15 --> Loader Class Initialized
INFO - 2024-02-20 19:25:15 --> Helper loaded: url_helper
INFO - 2024-02-20 19:25:15 --> Helper loaded: file_helper
INFO - 2024-02-20 19:25:15 --> Helper loaded: form_helper
INFO - 2024-02-20 19:25:15 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:25:15 --> Controller Class Initialized
INFO - 2024-02-20 19:25:15 --> Form Validation Class Initialized
INFO - 2024-02-20 19:25:15 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:25:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:25:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:25:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:25:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:25:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:25:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:25:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:25:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:25:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:25:15 --> Final output sent to browser
DEBUG - 2024-02-20 19:25:15 --> Total execution time: 0.0544
ERROR - 2024-02-20 19:25:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:25:22 --> Config Class Initialized
INFO - 2024-02-20 19:25:22 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:25:22 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:25:22 --> Utf8 Class Initialized
INFO - 2024-02-20 19:25:22 --> URI Class Initialized
INFO - 2024-02-20 19:25:22 --> Router Class Initialized
INFO - 2024-02-20 19:25:22 --> Output Class Initialized
INFO - 2024-02-20 19:25:22 --> Security Class Initialized
DEBUG - 2024-02-20 19:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:25:22 --> Input Class Initialized
INFO - 2024-02-20 19:25:22 --> Language Class Initialized
INFO - 2024-02-20 19:25:22 --> Loader Class Initialized
INFO - 2024-02-20 19:25:22 --> Helper loaded: url_helper
INFO - 2024-02-20 19:25:22 --> Helper loaded: file_helper
INFO - 2024-02-20 19:25:22 --> Helper loaded: form_helper
INFO - 2024-02-20 19:25:22 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:25:22 --> Controller Class Initialized
INFO - 2024-02-20 19:25:22 --> Form Validation Class Initialized
INFO - 2024-02-20 19:25:22 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:25:22 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:25:22 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:25:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:25:22 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:25:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:25:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:25:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:25:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:25:22 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:25:22 --> Final output sent to browser
DEBUG - 2024-02-20 19:25:22 --> Total execution time: 0.0590
ERROR - 2024-02-20 19:27:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:27:38 --> Config Class Initialized
INFO - 2024-02-20 19:27:38 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:27:38 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:27:38 --> Utf8 Class Initialized
INFO - 2024-02-20 19:27:38 --> URI Class Initialized
INFO - 2024-02-20 19:27:38 --> Router Class Initialized
INFO - 2024-02-20 19:27:38 --> Output Class Initialized
INFO - 2024-02-20 19:27:38 --> Security Class Initialized
DEBUG - 2024-02-20 19:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:27:38 --> Input Class Initialized
INFO - 2024-02-20 19:27:38 --> Language Class Initialized
INFO - 2024-02-20 19:27:38 --> Loader Class Initialized
INFO - 2024-02-20 19:27:38 --> Helper loaded: url_helper
INFO - 2024-02-20 19:27:38 --> Helper loaded: file_helper
INFO - 2024-02-20 19:27:38 --> Helper loaded: form_helper
INFO - 2024-02-20 19:27:38 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:27:38 --> Controller Class Initialized
INFO - 2024-02-20 19:27:38 --> Form Validation Class Initialized
INFO - 2024-02-20 19:27:38 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:27:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:27:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:27:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:27:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:27:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:27:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:27:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:27:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:27:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:27:38 --> Final output sent to browser
DEBUG - 2024-02-20 19:27:38 --> Total execution time: 0.0745
ERROR - 2024-02-20 19:27:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:27:39 --> Config Class Initialized
INFO - 2024-02-20 19:27:39 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:27:39 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:27:39 --> Utf8 Class Initialized
INFO - 2024-02-20 19:27:39 --> URI Class Initialized
INFO - 2024-02-20 19:27:39 --> Router Class Initialized
INFO - 2024-02-20 19:27:39 --> Output Class Initialized
INFO - 2024-02-20 19:27:39 --> Security Class Initialized
DEBUG - 2024-02-20 19:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:27:39 --> Input Class Initialized
INFO - 2024-02-20 19:27:39 --> Language Class Initialized
INFO - 2024-02-20 19:27:39 --> Loader Class Initialized
INFO - 2024-02-20 19:27:39 --> Helper loaded: url_helper
INFO - 2024-02-20 19:27:39 --> Helper loaded: file_helper
INFO - 2024-02-20 19:27:39 --> Helper loaded: form_helper
INFO - 2024-02-20 19:27:39 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:27:39 --> Controller Class Initialized
INFO - 2024-02-20 19:27:39 --> Form Validation Class Initialized
INFO - 2024-02-20 19:27:39 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:27:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:27:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:27:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:27:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:27:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:27:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:27:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:27:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:27:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:27:39 --> Final output sent to browser
DEBUG - 2024-02-20 19:27:39 --> Total execution time: 0.0893
ERROR - 2024-02-20 19:27:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:27:58 --> Config Class Initialized
INFO - 2024-02-20 19:27:58 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:27:58 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:27:58 --> Utf8 Class Initialized
INFO - 2024-02-20 19:27:58 --> URI Class Initialized
INFO - 2024-02-20 19:27:58 --> Router Class Initialized
INFO - 2024-02-20 19:27:58 --> Output Class Initialized
INFO - 2024-02-20 19:27:58 --> Security Class Initialized
DEBUG - 2024-02-20 19:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:27:58 --> Input Class Initialized
INFO - 2024-02-20 19:27:58 --> Language Class Initialized
INFO - 2024-02-20 19:27:58 --> Loader Class Initialized
INFO - 2024-02-20 19:27:58 --> Helper loaded: url_helper
INFO - 2024-02-20 19:27:58 --> Helper loaded: file_helper
INFO - 2024-02-20 19:27:58 --> Helper loaded: form_helper
INFO - 2024-02-20 19:27:58 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:27:58 --> Controller Class Initialized
INFO - 2024-02-20 19:27:58 --> Form Validation Class Initialized
INFO - 2024-02-20 19:27:58 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:27:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:27:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:27:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:27:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:27:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:27:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:27:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:27:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:27:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:27:58 --> Final output sent to browser
DEBUG - 2024-02-20 19:27:58 --> Total execution time: 0.0627
ERROR - 2024-02-20 19:30:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:30:14 --> Config Class Initialized
INFO - 2024-02-20 19:30:14 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:30:14 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:30:14 --> Utf8 Class Initialized
INFO - 2024-02-20 19:30:14 --> URI Class Initialized
INFO - 2024-02-20 19:30:14 --> Router Class Initialized
INFO - 2024-02-20 19:30:14 --> Output Class Initialized
INFO - 2024-02-20 19:30:14 --> Security Class Initialized
DEBUG - 2024-02-20 19:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:30:14 --> Input Class Initialized
INFO - 2024-02-20 19:30:14 --> Language Class Initialized
INFO - 2024-02-20 19:30:14 --> Loader Class Initialized
INFO - 2024-02-20 19:30:14 --> Helper loaded: url_helper
INFO - 2024-02-20 19:30:14 --> Helper loaded: file_helper
INFO - 2024-02-20 19:30:14 --> Helper loaded: form_helper
INFO - 2024-02-20 19:30:14 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:30:14 --> Controller Class Initialized
INFO - 2024-02-20 19:30:14 --> Form Validation Class Initialized
INFO - 2024-02-20 19:30:14 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:30:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:30:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:30:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:30:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:30:14 --> Final output sent to browser
DEBUG - 2024-02-20 19:30:14 --> Total execution time: 0.0680
ERROR - 2024-02-20 19:30:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:30:14 --> Config Class Initialized
INFO - 2024-02-20 19:30:14 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:30:14 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:30:14 --> Utf8 Class Initialized
INFO - 2024-02-20 19:30:14 --> URI Class Initialized
INFO - 2024-02-20 19:30:14 --> Router Class Initialized
INFO - 2024-02-20 19:30:14 --> Output Class Initialized
INFO - 2024-02-20 19:30:14 --> Security Class Initialized
DEBUG - 2024-02-20 19:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:30:14 --> Input Class Initialized
INFO - 2024-02-20 19:30:14 --> Language Class Initialized
INFO - 2024-02-20 19:30:14 --> Loader Class Initialized
INFO - 2024-02-20 19:30:14 --> Helper loaded: url_helper
INFO - 2024-02-20 19:30:14 --> Helper loaded: file_helper
INFO - 2024-02-20 19:30:14 --> Helper loaded: form_helper
INFO - 2024-02-20 19:30:14 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:30:14 --> Controller Class Initialized
INFO - 2024-02-20 19:30:14 --> Form Validation Class Initialized
INFO - 2024-02-20 19:30:14 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:30:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:30:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:30:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:30:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:30:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:30:14 --> Final output sent to browser
DEBUG - 2024-02-20 19:30:14 --> Total execution time: 0.0685
ERROR - 2024-02-20 19:32:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:32:04 --> Config Class Initialized
INFO - 2024-02-20 19:32:04 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:32:04 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:32:04 --> Utf8 Class Initialized
INFO - 2024-02-20 19:32:04 --> URI Class Initialized
INFO - 2024-02-20 19:32:04 --> Router Class Initialized
INFO - 2024-02-20 19:32:04 --> Output Class Initialized
INFO - 2024-02-20 19:32:04 --> Security Class Initialized
DEBUG - 2024-02-20 19:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:32:04 --> Input Class Initialized
INFO - 2024-02-20 19:32:04 --> Language Class Initialized
INFO - 2024-02-20 19:32:04 --> Loader Class Initialized
INFO - 2024-02-20 19:32:04 --> Helper loaded: url_helper
INFO - 2024-02-20 19:32:04 --> Helper loaded: file_helper
INFO - 2024-02-20 19:32:04 --> Helper loaded: form_helper
INFO - 2024-02-20 19:32:04 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:32:04 --> Controller Class Initialized
INFO - 2024-02-20 19:32:04 --> Form Validation Class Initialized
INFO - 2024-02-20 19:32:04 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:32:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:32:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:32:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:32:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:32:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:32:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:32:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:32:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:32:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:32:04 --> Final output sent to browser
DEBUG - 2024-02-20 19:32:04 --> Total execution time: 0.0465
ERROR - 2024-02-20 19:32:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:32:17 --> Config Class Initialized
INFO - 2024-02-20 19:32:17 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:32:17 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:32:17 --> Utf8 Class Initialized
INFO - 2024-02-20 19:32:17 --> URI Class Initialized
INFO - 2024-02-20 19:32:17 --> Router Class Initialized
INFO - 2024-02-20 19:32:17 --> Output Class Initialized
INFO - 2024-02-20 19:32:17 --> Security Class Initialized
DEBUG - 2024-02-20 19:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:32:17 --> Input Class Initialized
INFO - 2024-02-20 19:32:17 --> Language Class Initialized
INFO - 2024-02-20 19:32:17 --> Loader Class Initialized
INFO - 2024-02-20 19:32:17 --> Helper loaded: url_helper
INFO - 2024-02-20 19:32:17 --> Helper loaded: file_helper
INFO - 2024-02-20 19:32:17 --> Helper loaded: form_helper
INFO - 2024-02-20 19:32:17 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:32:17 --> Controller Class Initialized
INFO - 2024-02-20 19:32:17 --> Form Validation Class Initialized
INFO - 2024-02-20 19:32:17 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:32:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:32:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:32:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:32:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:32:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:32:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:32:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:32:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:32:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:32:17 --> Final output sent to browser
DEBUG - 2024-02-20 19:32:17 --> Total execution time: 0.0685
ERROR - 2024-02-20 19:32:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:32:49 --> Config Class Initialized
INFO - 2024-02-20 19:32:49 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:32:49 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:32:49 --> Utf8 Class Initialized
INFO - 2024-02-20 19:32:49 --> URI Class Initialized
INFO - 2024-02-20 19:32:49 --> Router Class Initialized
INFO - 2024-02-20 19:32:49 --> Output Class Initialized
INFO - 2024-02-20 19:32:49 --> Security Class Initialized
DEBUG - 2024-02-20 19:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:32:49 --> Input Class Initialized
INFO - 2024-02-20 19:32:49 --> Language Class Initialized
INFO - 2024-02-20 19:32:49 --> Loader Class Initialized
INFO - 2024-02-20 19:32:49 --> Helper loaded: url_helper
INFO - 2024-02-20 19:32:49 --> Helper loaded: file_helper
INFO - 2024-02-20 19:32:49 --> Helper loaded: form_helper
INFO - 2024-02-20 19:32:49 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:32:49 --> Controller Class Initialized
INFO - 2024-02-20 19:32:49 --> Form Validation Class Initialized
INFO - 2024-02-20 19:32:49 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:32:49 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:32:49 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:32:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:32:49 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:32:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:32:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:32:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:32:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:32:49 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:32:49 --> Final output sent to browser
DEBUG - 2024-02-20 19:32:49 --> Total execution time: 0.0544
ERROR - 2024-02-20 19:34:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:34:14 --> Config Class Initialized
INFO - 2024-02-20 19:34:14 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:34:14 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:34:14 --> Utf8 Class Initialized
INFO - 2024-02-20 19:34:14 --> URI Class Initialized
INFO - 2024-02-20 19:34:14 --> Router Class Initialized
INFO - 2024-02-20 19:34:14 --> Output Class Initialized
INFO - 2024-02-20 19:34:14 --> Security Class Initialized
DEBUG - 2024-02-20 19:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:34:14 --> Input Class Initialized
INFO - 2024-02-20 19:34:14 --> Language Class Initialized
INFO - 2024-02-20 19:34:14 --> Loader Class Initialized
INFO - 2024-02-20 19:34:14 --> Helper loaded: url_helper
INFO - 2024-02-20 19:34:14 --> Helper loaded: file_helper
INFO - 2024-02-20 19:34:14 --> Helper loaded: form_helper
INFO - 2024-02-20 19:34:14 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:34:14 --> Controller Class Initialized
INFO - 2024-02-20 19:34:14 --> Form Validation Class Initialized
INFO - 2024-02-20 19:34:14 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:34:14 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:34:14 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:34:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:34:14 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:34:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:34:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:34:15 --> Final output sent to browser
DEBUG - 2024-02-20 19:34:15 --> Total execution time: 0.0422
ERROR - 2024-02-20 19:34:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:34:17 --> Config Class Initialized
INFO - 2024-02-20 19:34:17 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:34:17 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:34:17 --> Utf8 Class Initialized
INFO - 2024-02-20 19:34:17 --> URI Class Initialized
INFO - 2024-02-20 19:34:17 --> Router Class Initialized
INFO - 2024-02-20 19:34:17 --> Output Class Initialized
INFO - 2024-02-20 19:34:17 --> Security Class Initialized
DEBUG - 2024-02-20 19:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:34:17 --> Input Class Initialized
INFO - 2024-02-20 19:34:17 --> Language Class Initialized
INFO - 2024-02-20 19:34:17 --> Loader Class Initialized
INFO - 2024-02-20 19:34:17 --> Helper loaded: url_helper
INFO - 2024-02-20 19:34:17 --> Helper loaded: file_helper
INFO - 2024-02-20 19:34:17 --> Helper loaded: form_helper
INFO - 2024-02-20 19:34:17 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:34:17 --> Controller Class Initialized
INFO - 2024-02-20 19:34:17 --> Form Validation Class Initialized
INFO - 2024-02-20 19:34:17 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:34:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:34:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:34:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:34:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:34:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:34:17 --> Final output sent to browser
DEBUG - 2024-02-20 19:34:17 --> Total execution time: 0.0571
ERROR - 2024-02-20 19:34:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:34:42 --> Config Class Initialized
INFO - 2024-02-20 19:34:42 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:34:42 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:34:42 --> Utf8 Class Initialized
INFO - 2024-02-20 19:34:42 --> URI Class Initialized
INFO - 2024-02-20 19:34:42 --> Router Class Initialized
INFO - 2024-02-20 19:34:42 --> Output Class Initialized
INFO - 2024-02-20 19:34:42 --> Security Class Initialized
DEBUG - 2024-02-20 19:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:34:42 --> Input Class Initialized
INFO - 2024-02-20 19:34:42 --> Language Class Initialized
INFO - 2024-02-20 19:34:42 --> Loader Class Initialized
INFO - 2024-02-20 19:34:42 --> Helper loaded: url_helper
INFO - 2024-02-20 19:34:42 --> Helper loaded: file_helper
INFO - 2024-02-20 19:34:42 --> Helper loaded: form_helper
INFO - 2024-02-20 19:34:42 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:34:42 --> Controller Class Initialized
INFO - 2024-02-20 19:34:42 --> Form Validation Class Initialized
INFO - 2024-02-20 19:34:42 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:34:42 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:34:42 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:34:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:34:42 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:34:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:34:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:34:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:34:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:34:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:34:42 --> Final output sent to browser
DEBUG - 2024-02-20 19:34:42 --> Total execution time: 0.0536
ERROR - 2024-02-20 19:34:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:34:44 --> Config Class Initialized
INFO - 2024-02-20 19:34:44 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:34:44 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:34:44 --> Utf8 Class Initialized
INFO - 2024-02-20 19:34:44 --> URI Class Initialized
INFO - 2024-02-20 19:34:44 --> Router Class Initialized
INFO - 2024-02-20 19:34:44 --> Output Class Initialized
INFO - 2024-02-20 19:34:44 --> Security Class Initialized
DEBUG - 2024-02-20 19:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:34:44 --> Input Class Initialized
INFO - 2024-02-20 19:34:44 --> Language Class Initialized
INFO - 2024-02-20 19:34:44 --> Loader Class Initialized
INFO - 2024-02-20 19:34:44 --> Helper loaded: url_helper
INFO - 2024-02-20 19:34:44 --> Helper loaded: file_helper
INFO - 2024-02-20 19:34:44 --> Helper loaded: form_helper
INFO - 2024-02-20 19:34:44 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:34:44 --> Controller Class Initialized
INFO - 2024-02-20 19:34:44 --> Form Validation Class Initialized
INFO - 2024-02-20 19:34:44 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:34:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:34:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:34:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:34:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:34:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:34:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:34:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:34:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:34:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:34:44 --> Final output sent to browser
DEBUG - 2024-02-20 19:34:44 --> Total execution time: 0.0528
ERROR - 2024-02-20 19:36:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:36:45 --> Config Class Initialized
INFO - 2024-02-20 19:36:45 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:36:45 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:36:45 --> Utf8 Class Initialized
INFO - 2024-02-20 19:36:45 --> URI Class Initialized
INFO - 2024-02-20 19:36:45 --> Router Class Initialized
INFO - 2024-02-20 19:36:45 --> Output Class Initialized
INFO - 2024-02-20 19:36:45 --> Security Class Initialized
DEBUG - 2024-02-20 19:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:36:45 --> Input Class Initialized
INFO - 2024-02-20 19:36:45 --> Language Class Initialized
INFO - 2024-02-20 19:36:45 --> Loader Class Initialized
INFO - 2024-02-20 19:36:45 --> Helper loaded: url_helper
INFO - 2024-02-20 19:36:45 --> Helper loaded: file_helper
INFO - 2024-02-20 19:36:45 --> Helper loaded: form_helper
INFO - 2024-02-20 19:36:45 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:36:46 --> Controller Class Initialized
INFO - 2024-02-20 19:36:46 --> Form Validation Class Initialized
INFO - 2024-02-20 19:36:46 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:36:46 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:36:46 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:36:46 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:36:46 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:36:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:36:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:36:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:36:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:36:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:36:46 --> Final output sent to browser
DEBUG - 2024-02-20 19:36:46 --> Total execution time: 0.0577
ERROR - 2024-02-20 19:36:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:36:58 --> Config Class Initialized
INFO - 2024-02-20 19:36:58 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:36:58 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:36:58 --> Utf8 Class Initialized
INFO - 2024-02-20 19:36:58 --> URI Class Initialized
INFO - 2024-02-20 19:36:58 --> Router Class Initialized
INFO - 2024-02-20 19:36:58 --> Output Class Initialized
INFO - 2024-02-20 19:36:58 --> Security Class Initialized
DEBUG - 2024-02-20 19:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:36:58 --> Input Class Initialized
INFO - 2024-02-20 19:36:58 --> Language Class Initialized
INFO - 2024-02-20 19:36:58 --> Loader Class Initialized
INFO - 2024-02-20 19:36:58 --> Helper loaded: url_helper
INFO - 2024-02-20 19:36:58 --> Helper loaded: file_helper
INFO - 2024-02-20 19:36:58 --> Helper loaded: form_helper
INFO - 2024-02-20 19:36:58 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:36:58 --> Controller Class Initialized
INFO - 2024-02-20 19:36:58 --> Form Validation Class Initialized
INFO - 2024-02-20 19:36:58 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:36:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:36:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:36:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:36:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:36:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:36:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:36:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:36:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:36:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:36:58 --> Final output sent to browser
DEBUG - 2024-02-20 19:36:58 --> Total execution time: 0.0703
ERROR - 2024-02-20 19:38:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:38:26 --> Config Class Initialized
INFO - 2024-02-20 19:38:26 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:38:26 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:38:26 --> Utf8 Class Initialized
INFO - 2024-02-20 19:38:26 --> URI Class Initialized
INFO - 2024-02-20 19:38:26 --> Router Class Initialized
INFO - 2024-02-20 19:38:26 --> Output Class Initialized
INFO - 2024-02-20 19:38:26 --> Security Class Initialized
DEBUG - 2024-02-20 19:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:38:26 --> Input Class Initialized
INFO - 2024-02-20 19:38:26 --> Language Class Initialized
INFO - 2024-02-20 19:38:26 --> Loader Class Initialized
INFO - 2024-02-20 19:38:26 --> Helper loaded: url_helper
INFO - 2024-02-20 19:38:26 --> Helper loaded: file_helper
INFO - 2024-02-20 19:38:26 --> Helper loaded: form_helper
INFO - 2024-02-20 19:38:26 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:38:26 --> Controller Class Initialized
INFO - 2024-02-20 19:38:26 --> Form Validation Class Initialized
INFO - 2024-02-20 19:38:26 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:38:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:38:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:38:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:38:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:38:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:38:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:38:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:38:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:38:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:38:26 --> Final output sent to browser
DEBUG - 2024-02-20 19:38:26 --> Total execution time: 0.0522
ERROR - 2024-02-20 19:38:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:38:54 --> Config Class Initialized
INFO - 2024-02-20 19:38:54 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:38:54 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:38:54 --> Utf8 Class Initialized
INFO - 2024-02-20 19:38:54 --> URI Class Initialized
INFO - 2024-02-20 19:38:54 --> Router Class Initialized
INFO - 2024-02-20 19:38:54 --> Output Class Initialized
INFO - 2024-02-20 19:38:54 --> Security Class Initialized
DEBUG - 2024-02-20 19:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:38:54 --> Input Class Initialized
INFO - 2024-02-20 19:38:54 --> Language Class Initialized
INFO - 2024-02-20 19:38:54 --> Loader Class Initialized
INFO - 2024-02-20 19:38:54 --> Helper loaded: url_helper
INFO - 2024-02-20 19:38:54 --> Helper loaded: file_helper
INFO - 2024-02-20 19:38:54 --> Helper loaded: form_helper
INFO - 2024-02-20 19:38:54 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:38:54 --> Controller Class Initialized
INFO - 2024-02-20 19:38:54 --> Form Validation Class Initialized
INFO - 2024-02-20 19:38:54 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:38:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:38:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:38:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:38:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:38:54 --> Final output sent to browser
DEBUG - 2024-02-20 19:38:54 --> Total execution time: 0.0502
ERROR - 2024-02-20 19:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:38:57 --> Config Class Initialized
INFO - 2024-02-20 19:38:57 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:38:57 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:38:57 --> Utf8 Class Initialized
INFO - 2024-02-20 19:38:57 --> URI Class Initialized
INFO - 2024-02-20 19:38:57 --> Router Class Initialized
INFO - 2024-02-20 19:38:57 --> Output Class Initialized
INFO - 2024-02-20 19:38:57 --> Security Class Initialized
DEBUG - 2024-02-20 19:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:38:57 --> Input Class Initialized
INFO - 2024-02-20 19:38:57 --> Language Class Initialized
INFO - 2024-02-20 19:38:57 --> Loader Class Initialized
INFO - 2024-02-20 19:38:57 --> Helper loaded: url_helper
INFO - 2024-02-20 19:38:57 --> Helper loaded: file_helper
INFO - 2024-02-20 19:38:57 --> Helper loaded: form_helper
INFO - 2024-02-20 19:38:57 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:38:57 --> Controller Class Initialized
INFO - 2024-02-20 19:38:57 --> Form Validation Class Initialized
INFO - 2024-02-20 19:38:57 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:38:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:38:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:38:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:38:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:38:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:38:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:38:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:38:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:38:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:38:57 --> Final output sent to browser
DEBUG - 2024-02-20 19:38:57 --> Total execution time: 0.0642
ERROR - 2024-02-20 19:39:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:39:21 --> Config Class Initialized
INFO - 2024-02-20 19:39:21 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:39:21 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:39:21 --> Utf8 Class Initialized
INFO - 2024-02-20 19:39:21 --> URI Class Initialized
INFO - 2024-02-20 19:39:21 --> Router Class Initialized
INFO - 2024-02-20 19:39:21 --> Output Class Initialized
INFO - 2024-02-20 19:39:21 --> Security Class Initialized
DEBUG - 2024-02-20 19:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:39:21 --> Input Class Initialized
INFO - 2024-02-20 19:39:21 --> Language Class Initialized
INFO - 2024-02-20 19:39:21 --> Loader Class Initialized
INFO - 2024-02-20 19:39:21 --> Helper loaded: url_helper
INFO - 2024-02-20 19:39:21 --> Helper loaded: file_helper
INFO - 2024-02-20 19:39:21 --> Helper loaded: form_helper
INFO - 2024-02-20 19:39:21 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:39:21 --> Controller Class Initialized
INFO - 2024-02-20 19:39:21 --> Form Validation Class Initialized
INFO - 2024-02-20 19:39:21 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:39:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:39:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:39:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:39:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:39:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:39:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:39:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:39:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:39:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:39:21 --> Final output sent to browser
DEBUG - 2024-02-20 19:39:21 --> Total execution time: 0.0571
ERROR - 2024-02-20 19:39:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:39:21 --> Config Class Initialized
INFO - 2024-02-20 19:39:21 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:39:21 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:39:21 --> Utf8 Class Initialized
INFO - 2024-02-20 19:39:21 --> URI Class Initialized
INFO - 2024-02-20 19:39:21 --> Router Class Initialized
INFO - 2024-02-20 19:39:21 --> Output Class Initialized
INFO - 2024-02-20 19:39:21 --> Security Class Initialized
DEBUG - 2024-02-20 19:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:39:21 --> Input Class Initialized
INFO - 2024-02-20 19:39:21 --> Language Class Initialized
INFO - 2024-02-20 19:39:21 --> Loader Class Initialized
INFO - 2024-02-20 19:39:21 --> Helper loaded: url_helper
INFO - 2024-02-20 19:39:21 --> Helper loaded: file_helper
INFO - 2024-02-20 19:39:21 --> Helper loaded: form_helper
INFO - 2024-02-20 19:39:21 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:39:21 --> Controller Class Initialized
INFO - 2024-02-20 19:39:21 --> Form Validation Class Initialized
INFO - 2024-02-20 19:39:21 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:39:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:39:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:39:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:39:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:39:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:39:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:39:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:39:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:39:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:39:21 --> Final output sent to browser
DEBUG - 2024-02-20 19:39:21 --> Total execution time: 0.0965
ERROR - 2024-02-20 19:44:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:44:05 --> Config Class Initialized
INFO - 2024-02-20 19:44:05 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:44:05 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:44:05 --> Utf8 Class Initialized
INFO - 2024-02-20 19:44:05 --> URI Class Initialized
INFO - 2024-02-20 19:44:05 --> Router Class Initialized
INFO - 2024-02-20 19:44:05 --> Output Class Initialized
INFO - 2024-02-20 19:44:05 --> Security Class Initialized
DEBUG - 2024-02-20 19:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:44:05 --> Input Class Initialized
INFO - 2024-02-20 19:44:05 --> Language Class Initialized
INFO - 2024-02-20 19:44:05 --> Loader Class Initialized
INFO - 2024-02-20 19:44:05 --> Helper loaded: url_helper
INFO - 2024-02-20 19:44:05 --> Helper loaded: file_helper
INFO - 2024-02-20 19:44:05 --> Helper loaded: form_helper
INFO - 2024-02-20 19:44:05 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:44:05 --> Controller Class Initialized
INFO - 2024-02-20 19:44:05 --> Form Validation Class Initialized
INFO - 2024-02-20 19:44:05 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:44:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:44:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:44:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:44:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:44:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:44:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:44:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:44:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:44:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:44:05 --> Final output sent to browser
DEBUG - 2024-02-20 19:44:05 --> Total execution time: 0.0561
ERROR - 2024-02-20 19:44:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:44:25 --> Config Class Initialized
INFO - 2024-02-20 19:44:25 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:44:25 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:44:25 --> Utf8 Class Initialized
INFO - 2024-02-20 19:44:25 --> URI Class Initialized
INFO - 2024-02-20 19:44:25 --> Router Class Initialized
INFO - 2024-02-20 19:44:25 --> Output Class Initialized
INFO - 2024-02-20 19:44:25 --> Security Class Initialized
DEBUG - 2024-02-20 19:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:44:25 --> Input Class Initialized
INFO - 2024-02-20 19:44:25 --> Language Class Initialized
INFO - 2024-02-20 19:44:25 --> Loader Class Initialized
INFO - 2024-02-20 19:44:25 --> Helper loaded: url_helper
INFO - 2024-02-20 19:44:25 --> Helper loaded: file_helper
INFO - 2024-02-20 19:44:25 --> Helper loaded: form_helper
INFO - 2024-02-20 19:44:25 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:44:25 --> Controller Class Initialized
INFO - 2024-02-20 19:44:25 --> Form Validation Class Initialized
INFO - 2024-02-20 19:44:25 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:44:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:44:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:44:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:44:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:44:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:44:25 --> Final output sent to browser
DEBUG - 2024-02-20 19:44:25 --> Total execution time: 0.0529
ERROR - 2024-02-20 19:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:44:26 --> Config Class Initialized
INFO - 2024-02-20 19:44:26 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:44:26 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:44:26 --> Utf8 Class Initialized
INFO - 2024-02-20 19:44:26 --> URI Class Initialized
INFO - 2024-02-20 19:44:26 --> Router Class Initialized
INFO - 2024-02-20 19:44:26 --> Output Class Initialized
INFO - 2024-02-20 19:44:26 --> Security Class Initialized
DEBUG - 2024-02-20 19:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:44:26 --> Input Class Initialized
INFO - 2024-02-20 19:44:26 --> Language Class Initialized
INFO - 2024-02-20 19:44:26 --> Loader Class Initialized
INFO - 2024-02-20 19:44:26 --> Helper loaded: url_helper
INFO - 2024-02-20 19:44:26 --> Helper loaded: file_helper
INFO - 2024-02-20 19:44:26 --> Helper loaded: form_helper
INFO - 2024-02-20 19:44:26 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:44:26 --> Controller Class Initialized
INFO - 2024-02-20 19:44:26 --> Form Validation Class Initialized
INFO - 2024-02-20 19:44:26 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:44:26 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:44:26 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:44:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:44:26 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:44:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:44:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:44:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:44:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:44:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:44:26 --> Final output sent to browser
DEBUG - 2024-02-20 19:44:26 --> Total execution time: 0.0481
ERROR - 2024-02-20 19:47:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:47:33 --> Config Class Initialized
INFO - 2024-02-20 19:47:33 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:47:33 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:47:33 --> Utf8 Class Initialized
INFO - 2024-02-20 19:47:33 --> URI Class Initialized
INFO - 2024-02-20 19:47:33 --> Router Class Initialized
INFO - 2024-02-20 19:47:33 --> Output Class Initialized
INFO - 2024-02-20 19:47:33 --> Security Class Initialized
DEBUG - 2024-02-20 19:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:47:33 --> Input Class Initialized
INFO - 2024-02-20 19:47:33 --> Language Class Initialized
INFO - 2024-02-20 19:47:33 --> Loader Class Initialized
INFO - 2024-02-20 19:47:33 --> Helper loaded: url_helper
INFO - 2024-02-20 19:47:33 --> Helper loaded: file_helper
INFO - 2024-02-20 19:47:33 --> Helper loaded: form_helper
INFO - 2024-02-20 19:47:33 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:47:33 --> Controller Class Initialized
INFO - 2024-02-20 19:47:33 --> Form Validation Class Initialized
INFO - 2024-02-20 19:47:33 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:47:33 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:47:33 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:47:33 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:47:33 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:47:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:47:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:47:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:47:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:47:33 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:47:33 --> Final output sent to browser
DEBUG - 2024-02-20 19:47:33 --> Total execution time: 0.0992
ERROR - 2024-02-20 19:47:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:47:37 --> Config Class Initialized
INFO - 2024-02-20 19:47:37 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:47:37 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:47:37 --> Utf8 Class Initialized
INFO - 2024-02-20 19:47:37 --> URI Class Initialized
INFO - 2024-02-20 19:47:37 --> Router Class Initialized
INFO - 2024-02-20 19:47:37 --> Output Class Initialized
INFO - 2024-02-20 19:47:37 --> Security Class Initialized
DEBUG - 2024-02-20 19:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:47:37 --> Input Class Initialized
INFO - 2024-02-20 19:47:37 --> Language Class Initialized
INFO - 2024-02-20 19:47:37 --> Loader Class Initialized
INFO - 2024-02-20 19:47:37 --> Helper loaded: url_helper
INFO - 2024-02-20 19:47:37 --> Helper loaded: file_helper
INFO - 2024-02-20 19:47:37 --> Helper loaded: form_helper
INFO - 2024-02-20 19:47:37 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:47:37 --> Controller Class Initialized
INFO - 2024-02-20 19:47:37 --> Form Validation Class Initialized
INFO - 2024-02-20 19:47:37 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:47:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:47:37 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:47:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:47:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:47:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:47:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:47:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:47:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:47:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:47:37 --> Final output sent to browser
DEBUG - 2024-02-20 19:47:37 --> Total execution time: 0.0537
ERROR - 2024-02-20 19:48:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:48:16 --> Config Class Initialized
INFO - 2024-02-20 19:48:16 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:48:16 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:48:16 --> Utf8 Class Initialized
INFO - 2024-02-20 19:48:16 --> URI Class Initialized
INFO - 2024-02-20 19:48:16 --> Router Class Initialized
INFO - 2024-02-20 19:48:16 --> Output Class Initialized
INFO - 2024-02-20 19:48:16 --> Security Class Initialized
DEBUG - 2024-02-20 19:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:48:16 --> Input Class Initialized
INFO - 2024-02-20 19:48:16 --> Language Class Initialized
INFO - 2024-02-20 19:48:16 --> Loader Class Initialized
INFO - 2024-02-20 19:48:16 --> Helper loaded: url_helper
INFO - 2024-02-20 19:48:16 --> Helper loaded: file_helper
INFO - 2024-02-20 19:48:16 --> Helper loaded: form_helper
INFO - 2024-02-20 19:48:16 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:48:16 --> Controller Class Initialized
INFO - 2024-02-20 19:48:16 --> Form Validation Class Initialized
INFO - 2024-02-20 19:48:16 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:48:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:48:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:48:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:48:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:48:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:48:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:48:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:48:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:48:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:48:16 --> Final output sent to browser
DEBUG - 2024-02-20 19:48:16 --> Total execution time: 0.0545
ERROR - 2024-02-20 19:48:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:48:19 --> Config Class Initialized
INFO - 2024-02-20 19:48:19 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:48:19 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:48:19 --> Utf8 Class Initialized
INFO - 2024-02-20 19:48:19 --> URI Class Initialized
INFO - 2024-02-20 19:48:19 --> Router Class Initialized
INFO - 2024-02-20 19:48:19 --> Output Class Initialized
INFO - 2024-02-20 19:48:19 --> Security Class Initialized
DEBUG - 2024-02-20 19:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:48:19 --> Input Class Initialized
INFO - 2024-02-20 19:48:19 --> Language Class Initialized
INFO - 2024-02-20 19:48:19 --> Loader Class Initialized
INFO - 2024-02-20 19:48:19 --> Helper loaded: url_helper
INFO - 2024-02-20 19:48:19 --> Helper loaded: file_helper
INFO - 2024-02-20 19:48:19 --> Helper loaded: form_helper
INFO - 2024-02-20 19:48:19 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:48:19 --> Controller Class Initialized
INFO - 2024-02-20 19:48:19 --> Form Validation Class Initialized
INFO - 2024-02-20 19:48:19 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:48:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:48:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:48:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:48:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:48:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:48:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:48:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:48:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:48:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:48:19 --> Final output sent to browser
DEBUG - 2024-02-20 19:48:19 --> Total execution time: 0.0578
ERROR - 2024-02-20 19:48:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:48:25 --> Config Class Initialized
INFO - 2024-02-20 19:48:25 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:48:25 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:48:25 --> Utf8 Class Initialized
INFO - 2024-02-20 19:48:25 --> URI Class Initialized
INFO - 2024-02-20 19:48:25 --> Router Class Initialized
INFO - 2024-02-20 19:48:25 --> Output Class Initialized
INFO - 2024-02-20 19:48:25 --> Security Class Initialized
DEBUG - 2024-02-20 19:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:48:25 --> Input Class Initialized
INFO - 2024-02-20 19:48:25 --> Language Class Initialized
INFO - 2024-02-20 19:48:25 --> Loader Class Initialized
INFO - 2024-02-20 19:48:25 --> Helper loaded: url_helper
INFO - 2024-02-20 19:48:25 --> Helper loaded: file_helper
INFO - 2024-02-20 19:48:25 --> Helper loaded: form_helper
INFO - 2024-02-20 19:48:25 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:48:25 --> Controller Class Initialized
INFO - 2024-02-20 19:48:25 --> Form Validation Class Initialized
INFO - 2024-02-20 19:48:25 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:48:25 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:48:25 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:48:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:48:25 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:48:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:48:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:48:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:48:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:48:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:48:25 --> Final output sent to browser
DEBUG - 2024-02-20 19:48:25 --> Total execution time: 0.0699
ERROR - 2024-02-20 19:49:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:49:05 --> Config Class Initialized
INFO - 2024-02-20 19:49:05 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:49:05 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:49:05 --> Utf8 Class Initialized
INFO - 2024-02-20 19:49:05 --> URI Class Initialized
INFO - 2024-02-20 19:49:05 --> Router Class Initialized
INFO - 2024-02-20 19:49:05 --> Output Class Initialized
INFO - 2024-02-20 19:49:05 --> Security Class Initialized
DEBUG - 2024-02-20 19:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:49:05 --> Input Class Initialized
INFO - 2024-02-20 19:49:05 --> Language Class Initialized
INFO - 2024-02-20 19:49:05 --> Loader Class Initialized
INFO - 2024-02-20 19:49:05 --> Helper loaded: url_helper
INFO - 2024-02-20 19:49:05 --> Helper loaded: file_helper
INFO - 2024-02-20 19:49:05 --> Helper loaded: form_helper
INFO - 2024-02-20 19:49:05 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:49:05 --> Controller Class Initialized
INFO - 2024-02-20 19:49:05 --> Form Validation Class Initialized
INFO - 2024-02-20 19:49:05 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:49:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:49:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:49:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:49:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:49:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:49:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:49:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:49:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:49:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:49:05 --> Final output sent to browser
DEBUG - 2024-02-20 19:49:05 --> Total execution time: 0.0467
ERROR - 2024-02-20 19:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:49:08 --> Config Class Initialized
INFO - 2024-02-20 19:49:08 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:49:08 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:49:08 --> Utf8 Class Initialized
INFO - 2024-02-20 19:49:08 --> URI Class Initialized
INFO - 2024-02-20 19:49:08 --> Router Class Initialized
INFO - 2024-02-20 19:49:08 --> Output Class Initialized
INFO - 2024-02-20 19:49:08 --> Security Class Initialized
DEBUG - 2024-02-20 19:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:49:08 --> Input Class Initialized
INFO - 2024-02-20 19:49:08 --> Language Class Initialized
INFO - 2024-02-20 19:49:08 --> Loader Class Initialized
INFO - 2024-02-20 19:49:08 --> Helper loaded: url_helper
INFO - 2024-02-20 19:49:08 --> Helper loaded: file_helper
INFO - 2024-02-20 19:49:08 --> Helper loaded: form_helper
INFO - 2024-02-20 19:49:08 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:49:08 --> Controller Class Initialized
INFO - 2024-02-20 19:49:08 --> Form Validation Class Initialized
INFO - 2024-02-20 19:49:08 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:49:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:49:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:49:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:49:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:49:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:49:08 --> Final output sent to browser
DEBUG - 2024-02-20 19:49:08 --> Total execution time: 0.0458
ERROR - 2024-02-20 19:49:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:49:20 --> Config Class Initialized
INFO - 2024-02-20 19:49:20 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:49:20 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:49:20 --> Utf8 Class Initialized
INFO - 2024-02-20 19:49:20 --> URI Class Initialized
INFO - 2024-02-20 19:49:20 --> Router Class Initialized
INFO - 2024-02-20 19:49:20 --> Output Class Initialized
INFO - 2024-02-20 19:49:20 --> Security Class Initialized
DEBUG - 2024-02-20 19:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:49:20 --> Input Class Initialized
INFO - 2024-02-20 19:49:20 --> Language Class Initialized
INFO - 2024-02-20 19:49:20 --> Loader Class Initialized
INFO - 2024-02-20 19:49:20 --> Helper loaded: url_helper
INFO - 2024-02-20 19:49:20 --> Helper loaded: file_helper
INFO - 2024-02-20 19:49:20 --> Helper loaded: form_helper
INFO - 2024-02-20 19:49:20 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:49:20 --> Controller Class Initialized
INFO - 2024-02-20 19:49:20 --> Form Validation Class Initialized
INFO - 2024-02-20 19:49:21 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:49:21 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:49:21 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:49:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:49:21 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:49:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:49:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:49:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:49:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:49:21 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:49:21 --> Final output sent to browser
DEBUG - 2024-02-20 19:49:21 --> Total execution time: 0.0566
ERROR - 2024-02-20 19:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:50:09 --> Config Class Initialized
INFO - 2024-02-20 19:50:09 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:50:09 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:50:09 --> Utf8 Class Initialized
INFO - 2024-02-20 19:50:09 --> URI Class Initialized
INFO - 2024-02-20 19:50:09 --> Router Class Initialized
INFO - 2024-02-20 19:50:10 --> Output Class Initialized
INFO - 2024-02-20 19:50:10 --> Security Class Initialized
DEBUG - 2024-02-20 19:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:50:10 --> Input Class Initialized
INFO - 2024-02-20 19:50:10 --> Language Class Initialized
INFO - 2024-02-20 19:50:10 --> Loader Class Initialized
INFO - 2024-02-20 19:50:10 --> Helper loaded: url_helper
INFO - 2024-02-20 19:50:10 --> Helper loaded: file_helper
INFO - 2024-02-20 19:50:10 --> Helper loaded: form_helper
INFO - 2024-02-20 19:50:10 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:50:10 --> Controller Class Initialized
INFO - 2024-02-20 19:50:10 --> Form Validation Class Initialized
INFO - 2024-02-20 19:50:10 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:50:10 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:50:10 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:50:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:50:10 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:50:10 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:50:10 --> Final output sent to browser
DEBUG - 2024-02-20 19:50:10 --> Total execution time: 0.0323
ERROR - 2024-02-20 19:50:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:50:20 --> Config Class Initialized
INFO - 2024-02-20 19:50:20 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:50:20 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:50:20 --> Utf8 Class Initialized
INFO - 2024-02-20 19:50:20 --> URI Class Initialized
INFO - 2024-02-20 19:50:20 --> Router Class Initialized
INFO - 2024-02-20 19:50:20 --> Output Class Initialized
INFO - 2024-02-20 19:50:20 --> Security Class Initialized
DEBUG - 2024-02-20 19:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:50:20 --> Input Class Initialized
INFO - 2024-02-20 19:50:20 --> Language Class Initialized
INFO - 2024-02-20 19:50:20 --> Loader Class Initialized
INFO - 2024-02-20 19:50:20 --> Helper loaded: url_helper
INFO - 2024-02-20 19:50:20 --> Helper loaded: file_helper
INFO - 2024-02-20 19:50:20 --> Helper loaded: form_helper
INFO - 2024-02-20 19:50:20 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:50:20 --> Controller Class Initialized
INFO - 2024-02-20 19:50:20 --> Form Validation Class Initialized
INFO - 2024-02-20 19:50:20 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:50:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:50:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:50:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:50:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:50:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:50:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:50:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:50:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:50:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:50:20 --> Final output sent to browser
DEBUG - 2024-02-20 19:50:20 --> Total execution time: 0.0639
ERROR - 2024-02-20 19:50:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:50:52 --> Config Class Initialized
INFO - 2024-02-20 19:50:52 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:50:52 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:50:52 --> Utf8 Class Initialized
INFO - 2024-02-20 19:50:52 --> URI Class Initialized
INFO - 2024-02-20 19:50:52 --> Router Class Initialized
INFO - 2024-02-20 19:50:52 --> Output Class Initialized
INFO - 2024-02-20 19:50:52 --> Security Class Initialized
DEBUG - 2024-02-20 19:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:50:52 --> Input Class Initialized
INFO - 2024-02-20 19:50:52 --> Language Class Initialized
INFO - 2024-02-20 19:50:52 --> Loader Class Initialized
INFO - 2024-02-20 19:50:52 --> Helper loaded: url_helper
INFO - 2024-02-20 19:50:52 --> Helper loaded: file_helper
INFO - 2024-02-20 19:50:52 --> Helper loaded: form_helper
INFO - 2024-02-20 19:50:52 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:50:52 --> Controller Class Initialized
INFO - 2024-02-20 19:50:52 --> Form Validation Class Initialized
INFO - 2024-02-20 19:50:52 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:50:52 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:50:52 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:50:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:50:52 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:50:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:50:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:50:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:50:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:50:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:50:52 --> Final output sent to browser
DEBUG - 2024-02-20 19:50:52 --> Total execution time: 0.0554
ERROR - 2024-02-20 19:50:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:50:57 --> Config Class Initialized
INFO - 2024-02-20 19:50:57 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:50:57 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:50:57 --> Utf8 Class Initialized
INFO - 2024-02-20 19:50:57 --> URI Class Initialized
INFO - 2024-02-20 19:50:57 --> Router Class Initialized
INFO - 2024-02-20 19:50:57 --> Output Class Initialized
INFO - 2024-02-20 19:50:57 --> Security Class Initialized
DEBUG - 2024-02-20 19:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:50:57 --> Input Class Initialized
INFO - 2024-02-20 19:50:57 --> Language Class Initialized
INFO - 2024-02-20 19:50:57 --> Loader Class Initialized
INFO - 2024-02-20 19:50:57 --> Helper loaded: url_helper
INFO - 2024-02-20 19:50:57 --> Helper loaded: file_helper
INFO - 2024-02-20 19:50:57 --> Helper loaded: form_helper
INFO - 2024-02-20 19:50:57 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:50:57 --> Controller Class Initialized
INFO - 2024-02-20 19:50:57 --> Form Validation Class Initialized
INFO - 2024-02-20 19:50:57 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:50:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:50:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:50:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:50:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:50:57 --> Final output sent to browser
DEBUG - 2024-02-20 19:50:57 --> Total execution time: 0.0452
ERROR - 2024-02-20 19:51:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:51:23 --> Config Class Initialized
INFO - 2024-02-20 19:51:23 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:51:23 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:51:23 --> Utf8 Class Initialized
INFO - 2024-02-20 19:51:23 --> URI Class Initialized
INFO - 2024-02-20 19:51:23 --> Router Class Initialized
INFO - 2024-02-20 19:51:23 --> Output Class Initialized
INFO - 2024-02-20 19:51:23 --> Security Class Initialized
DEBUG - 2024-02-20 19:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:51:23 --> Input Class Initialized
INFO - 2024-02-20 19:51:23 --> Language Class Initialized
INFO - 2024-02-20 19:51:24 --> Loader Class Initialized
INFO - 2024-02-20 19:51:24 --> Helper loaded: url_helper
INFO - 2024-02-20 19:51:24 --> Helper loaded: file_helper
INFO - 2024-02-20 19:51:24 --> Helper loaded: form_helper
INFO - 2024-02-20 19:51:24 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:51:24 --> Controller Class Initialized
INFO - 2024-02-20 19:51:24 --> Form Validation Class Initialized
INFO - 2024-02-20 19:51:24 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:51:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:51:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:51:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:51:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:51:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:51:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:51:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:51:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:51:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:51:24 --> Final output sent to browser
DEBUG - 2024-02-20 19:51:24 --> Total execution time: 0.0588
ERROR - 2024-02-20 19:52:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:52:15 --> Config Class Initialized
INFO - 2024-02-20 19:52:15 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:52:15 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:52:15 --> Utf8 Class Initialized
INFO - 2024-02-20 19:52:15 --> URI Class Initialized
INFO - 2024-02-20 19:52:15 --> Router Class Initialized
INFO - 2024-02-20 19:52:15 --> Output Class Initialized
INFO - 2024-02-20 19:52:15 --> Security Class Initialized
DEBUG - 2024-02-20 19:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:52:15 --> Input Class Initialized
INFO - 2024-02-20 19:52:15 --> Language Class Initialized
INFO - 2024-02-20 19:52:15 --> Loader Class Initialized
INFO - 2024-02-20 19:52:15 --> Helper loaded: url_helper
INFO - 2024-02-20 19:52:15 --> Helper loaded: file_helper
INFO - 2024-02-20 19:52:15 --> Helper loaded: form_helper
INFO - 2024-02-20 19:52:15 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:52:15 --> Controller Class Initialized
INFO - 2024-02-20 19:52:15 --> Form Validation Class Initialized
INFO - 2024-02-20 19:52:15 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:52:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:52:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:52:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:52:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:52:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:52:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:52:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:52:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:52:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:52:15 --> Final output sent to browser
DEBUG - 2024-02-20 19:52:15 --> Total execution time: 0.0544
ERROR - 2024-02-20 19:52:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:52:32 --> Config Class Initialized
INFO - 2024-02-20 19:52:32 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:52:32 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:52:32 --> Utf8 Class Initialized
INFO - 2024-02-20 19:52:32 --> URI Class Initialized
INFO - 2024-02-20 19:52:32 --> Router Class Initialized
INFO - 2024-02-20 19:52:32 --> Output Class Initialized
INFO - 2024-02-20 19:52:32 --> Security Class Initialized
DEBUG - 2024-02-20 19:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:52:32 --> Input Class Initialized
INFO - 2024-02-20 19:52:32 --> Language Class Initialized
INFO - 2024-02-20 19:52:32 --> Loader Class Initialized
INFO - 2024-02-20 19:52:32 --> Helper loaded: url_helper
INFO - 2024-02-20 19:52:32 --> Helper loaded: file_helper
INFO - 2024-02-20 19:52:32 --> Helper loaded: form_helper
INFO - 2024-02-20 19:52:32 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:52:32 --> Controller Class Initialized
INFO - 2024-02-20 19:52:32 --> Form Validation Class Initialized
INFO - 2024-02-20 19:52:32 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:52:32 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:52:32 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:52:32 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:52:32 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:52:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:52:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:52:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:52:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:52:32 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:52:32 --> Final output sent to browser
DEBUG - 2024-02-20 19:52:32 --> Total execution time: 0.0637
ERROR - 2024-02-20 19:52:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:52:35 --> Config Class Initialized
INFO - 2024-02-20 19:52:35 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:52:35 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:52:35 --> Utf8 Class Initialized
INFO - 2024-02-20 19:52:35 --> URI Class Initialized
INFO - 2024-02-20 19:52:35 --> Router Class Initialized
INFO - 2024-02-20 19:52:35 --> Output Class Initialized
INFO - 2024-02-20 19:52:35 --> Security Class Initialized
DEBUG - 2024-02-20 19:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:52:35 --> Input Class Initialized
INFO - 2024-02-20 19:52:35 --> Language Class Initialized
INFO - 2024-02-20 19:52:35 --> Loader Class Initialized
INFO - 2024-02-20 19:52:35 --> Helper loaded: url_helper
INFO - 2024-02-20 19:52:35 --> Helper loaded: file_helper
INFO - 2024-02-20 19:52:35 --> Helper loaded: form_helper
INFO - 2024-02-20 19:52:35 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:52:35 --> Controller Class Initialized
INFO - 2024-02-20 19:52:35 --> Form Validation Class Initialized
INFO - 2024-02-20 19:52:35 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:52:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:52:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:52:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:52:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:52:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:52:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:52:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:52:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:52:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:52:35 --> Final output sent to browser
DEBUG - 2024-02-20 19:52:35 --> Total execution time: 0.0552
ERROR - 2024-02-20 19:53:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:53:09 --> Config Class Initialized
INFO - 2024-02-20 19:53:09 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:53:09 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:53:09 --> Utf8 Class Initialized
INFO - 2024-02-20 19:53:09 --> URI Class Initialized
INFO - 2024-02-20 19:53:09 --> Router Class Initialized
INFO - 2024-02-20 19:53:09 --> Output Class Initialized
INFO - 2024-02-20 19:53:09 --> Security Class Initialized
DEBUG - 2024-02-20 19:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:53:09 --> Input Class Initialized
INFO - 2024-02-20 19:53:09 --> Language Class Initialized
INFO - 2024-02-20 19:53:09 --> Loader Class Initialized
INFO - 2024-02-20 19:53:09 --> Helper loaded: url_helper
INFO - 2024-02-20 19:53:09 --> Helper loaded: file_helper
INFO - 2024-02-20 19:53:09 --> Helper loaded: form_helper
INFO - 2024-02-20 19:53:09 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:53:09 --> Controller Class Initialized
INFO - 2024-02-20 19:53:09 --> Form Validation Class Initialized
INFO - 2024-02-20 19:53:09 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:53:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:53:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:53:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:53:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:53:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:53:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:53:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:53:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:53:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:53:09 --> Final output sent to browser
DEBUG - 2024-02-20 19:53:09 --> Total execution time: 0.0480
ERROR - 2024-02-20 19:53:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 19:53:11 --> Config Class Initialized
INFO - 2024-02-20 19:53:11 --> Hooks Class Initialized
DEBUG - 2024-02-20 19:53:11 --> UTF-8 Support Enabled
INFO - 2024-02-20 19:53:11 --> Utf8 Class Initialized
INFO - 2024-02-20 19:53:11 --> URI Class Initialized
INFO - 2024-02-20 19:53:11 --> Router Class Initialized
INFO - 2024-02-20 19:53:11 --> Output Class Initialized
INFO - 2024-02-20 19:53:11 --> Security Class Initialized
DEBUG - 2024-02-20 19:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 19:53:11 --> Input Class Initialized
INFO - 2024-02-20 19:53:11 --> Language Class Initialized
INFO - 2024-02-20 19:53:11 --> Loader Class Initialized
INFO - 2024-02-20 19:53:11 --> Helper loaded: url_helper
INFO - 2024-02-20 19:53:11 --> Helper loaded: file_helper
INFO - 2024-02-20 19:53:11 --> Helper loaded: form_helper
INFO - 2024-02-20 19:53:11 --> Database Driver Class Initialized
DEBUG - 2024-02-20 19:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 19:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 19:53:11 --> Controller Class Initialized
INFO - 2024-02-20 19:53:11 --> Form Validation Class Initialized
INFO - 2024-02-20 19:53:11 --> Model "MasterModel" initialized
INFO - 2024-02-20 19:53:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 19:53:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 19:53:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 19:53:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 19:53:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 19:53:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 19:53:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 19:53:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 19:53:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 19:53:11 --> Final output sent to browser
DEBUG - 2024-02-20 19:53:11 --> Total execution time: 0.0612
ERROR - 2024-02-20 20:06:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:06:39 --> Config Class Initialized
INFO - 2024-02-20 20:06:39 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:06:39 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:06:39 --> Utf8 Class Initialized
INFO - 2024-02-20 20:06:39 --> URI Class Initialized
INFO - 2024-02-20 20:06:39 --> Router Class Initialized
INFO - 2024-02-20 20:06:39 --> Output Class Initialized
INFO - 2024-02-20 20:06:39 --> Security Class Initialized
DEBUG - 2024-02-20 20:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:06:39 --> Input Class Initialized
INFO - 2024-02-20 20:06:39 --> Language Class Initialized
INFO - 2024-02-20 20:06:39 --> Loader Class Initialized
INFO - 2024-02-20 20:06:39 --> Helper loaded: url_helper
INFO - 2024-02-20 20:06:39 --> Helper loaded: file_helper
INFO - 2024-02-20 20:06:39 --> Helper loaded: form_helper
INFO - 2024-02-20 20:06:39 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:06:39 --> Controller Class Initialized
INFO - 2024-02-20 20:06:39 --> Form Validation Class Initialized
INFO - 2024-02-20 20:06:39 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:06:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:06:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:06:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:06:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:06:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:06:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:06:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:06:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:06:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:06:39 --> Final output sent to browser
DEBUG - 2024-02-20 20:06:39 --> Total execution time: 0.0859
ERROR - 2024-02-20 20:07:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:07:03 --> Config Class Initialized
INFO - 2024-02-20 20:07:03 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:07:03 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:07:03 --> Utf8 Class Initialized
INFO - 2024-02-20 20:07:03 --> URI Class Initialized
INFO - 2024-02-20 20:07:03 --> Router Class Initialized
INFO - 2024-02-20 20:07:03 --> Output Class Initialized
INFO - 2024-02-20 20:07:03 --> Security Class Initialized
DEBUG - 2024-02-20 20:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:07:03 --> Input Class Initialized
INFO - 2024-02-20 20:07:03 --> Language Class Initialized
INFO - 2024-02-20 20:07:03 --> Loader Class Initialized
INFO - 2024-02-20 20:07:03 --> Helper loaded: url_helper
INFO - 2024-02-20 20:07:03 --> Helper loaded: file_helper
INFO - 2024-02-20 20:07:03 --> Helper loaded: form_helper
INFO - 2024-02-20 20:07:03 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:07:03 --> Controller Class Initialized
INFO - 2024-02-20 20:07:03 --> Form Validation Class Initialized
INFO - 2024-02-20 20:07:03 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:07:03 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:07:03 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:07:03 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:07:03 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:07:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:07:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:07:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:07:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:07:03 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:07:03 --> Final output sent to browser
DEBUG - 2024-02-20 20:07:03 --> Total execution time: 0.0661
ERROR - 2024-02-20 20:07:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:07:04 --> Config Class Initialized
INFO - 2024-02-20 20:07:04 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:07:04 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:07:04 --> Utf8 Class Initialized
INFO - 2024-02-20 20:07:04 --> URI Class Initialized
INFO - 2024-02-20 20:07:04 --> Router Class Initialized
INFO - 2024-02-20 20:07:04 --> Output Class Initialized
INFO - 2024-02-20 20:07:04 --> Security Class Initialized
DEBUG - 2024-02-20 20:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:07:04 --> Input Class Initialized
INFO - 2024-02-20 20:07:04 --> Language Class Initialized
INFO - 2024-02-20 20:07:04 --> Loader Class Initialized
INFO - 2024-02-20 20:07:04 --> Helper loaded: url_helper
INFO - 2024-02-20 20:07:04 --> Helper loaded: file_helper
INFO - 2024-02-20 20:07:04 --> Helper loaded: form_helper
INFO - 2024-02-20 20:07:04 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:07:04 --> Controller Class Initialized
INFO - 2024-02-20 20:07:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-20 20:07:04 --> Final output sent to browser
DEBUG - 2024-02-20 20:07:04 --> Total execution time: 0.1810
ERROR - 2024-02-20 20:07:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:07:37 --> Config Class Initialized
INFO - 2024-02-20 20:07:37 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:07:37 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:07:37 --> Utf8 Class Initialized
INFO - 2024-02-20 20:07:37 --> URI Class Initialized
INFO - 2024-02-20 20:07:37 --> Router Class Initialized
INFO - 2024-02-20 20:07:37 --> Output Class Initialized
INFO - 2024-02-20 20:07:37 --> Security Class Initialized
DEBUG - 2024-02-20 20:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:07:37 --> Input Class Initialized
INFO - 2024-02-20 20:07:37 --> Language Class Initialized
INFO - 2024-02-20 20:07:37 --> Loader Class Initialized
INFO - 2024-02-20 20:07:37 --> Helper loaded: url_helper
INFO - 2024-02-20 20:07:37 --> Helper loaded: file_helper
INFO - 2024-02-20 20:07:37 --> Helper loaded: form_helper
INFO - 2024-02-20 20:07:37 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:07:37 --> Controller Class Initialized
INFO - 2024-02-20 20:07:37 --> Form Validation Class Initialized
INFO - 2024-02-20 20:07:37 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:07:37 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:07:37 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:07:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:07:37 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:07:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:07:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:07:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:07:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:07:37 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:07:37 --> Final output sent to browser
DEBUG - 2024-02-20 20:07:37 --> Total execution time: 0.0566
ERROR - 2024-02-20 20:07:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:07:38 --> Config Class Initialized
INFO - 2024-02-20 20:07:38 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:07:38 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:07:38 --> Utf8 Class Initialized
INFO - 2024-02-20 20:07:38 --> URI Class Initialized
INFO - 2024-02-20 20:07:38 --> Router Class Initialized
INFO - 2024-02-20 20:07:38 --> Output Class Initialized
INFO - 2024-02-20 20:07:38 --> Security Class Initialized
DEBUG - 2024-02-20 20:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:07:38 --> Input Class Initialized
INFO - 2024-02-20 20:07:38 --> Language Class Initialized
INFO - 2024-02-20 20:07:38 --> Loader Class Initialized
INFO - 2024-02-20 20:07:38 --> Helper loaded: url_helper
INFO - 2024-02-20 20:07:38 --> Helper loaded: file_helper
INFO - 2024-02-20 20:07:38 --> Helper loaded: form_helper
INFO - 2024-02-20 20:07:38 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:07:38 --> Controller Class Initialized
INFO - 2024-02-20 20:07:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-20 20:07:38 --> Final output sent to browser
DEBUG - 2024-02-20 20:07:38 --> Total execution time: 0.0699
ERROR - 2024-02-20 20:07:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:07:48 --> Config Class Initialized
INFO - 2024-02-20 20:07:48 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:07:48 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:07:48 --> Utf8 Class Initialized
INFO - 2024-02-20 20:07:48 --> URI Class Initialized
INFO - 2024-02-20 20:07:48 --> Router Class Initialized
INFO - 2024-02-20 20:07:48 --> Output Class Initialized
INFO - 2024-02-20 20:07:48 --> Security Class Initialized
DEBUG - 2024-02-20 20:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:07:48 --> Input Class Initialized
INFO - 2024-02-20 20:07:48 --> Language Class Initialized
INFO - 2024-02-20 20:07:48 --> Loader Class Initialized
INFO - 2024-02-20 20:07:48 --> Helper loaded: url_helper
INFO - 2024-02-20 20:07:48 --> Helper loaded: file_helper
INFO - 2024-02-20 20:07:48 --> Helper loaded: form_helper
INFO - 2024-02-20 20:07:48 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:07:48 --> Controller Class Initialized
INFO - 2024-02-20 20:07:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/app-404.php
INFO - 2024-02-20 20:07:48 --> Final output sent to browser
DEBUG - 2024-02-20 20:07:48 --> Total execution time: 0.0450
ERROR - 2024-02-20 20:08:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:08:09 --> Config Class Initialized
INFO - 2024-02-20 20:08:09 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:08:09 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:08:09 --> Utf8 Class Initialized
INFO - 2024-02-20 20:08:09 --> URI Class Initialized
INFO - 2024-02-20 20:08:09 --> Router Class Initialized
INFO - 2024-02-20 20:08:09 --> Output Class Initialized
INFO - 2024-02-20 20:08:09 --> Security Class Initialized
DEBUG - 2024-02-20 20:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:08:09 --> Input Class Initialized
INFO - 2024-02-20 20:08:09 --> Language Class Initialized
INFO - 2024-02-20 20:08:09 --> Loader Class Initialized
INFO - 2024-02-20 20:08:09 --> Helper loaded: url_helper
INFO - 2024-02-20 20:08:09 --> Helper loaded: file_helper
INFO - 2024-02-20 20:08:09 --> Helper loaded: form_helper
INFO - 2024-02-20 20:08:09 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:08:09 --> Controller Class Initialized
INFO - 2024-02-20 20:08:09 --> Form Validation Class Initialized
INFO - 2024-02-20 20:08:09 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:08:09 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:08:09 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:08:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:08:09 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:08:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:08:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:08:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:08:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:08:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:08:09 --> Final output sent to browser
DEBUG - 2024-02-20 20:08:09 --> Total execution time: 0.0584
ERROR - 2024-02-20 20:08:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:08:56 --> Config Class Initialized
INFO - 2024-02-20 20:08:56 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:08:56 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:08:56 --> Utf8 Class Initialized
INFO - 2024-02-20 20:08:56 --> URI Class Initialized
INFO - 2024-02-20 20:08:56 --> Router Class Initialized
INFO - 2024-02-20 20:08:56 --> Output Class Initialized
INFO - 2024-02-20 20:08:56 --> Security Class Initialized
DEBUG - 2024-02-20 20:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:08:56 --> Input Class Initialized
INFO - 2024-02-20 20:08:56 --> Language Class Initialized
INFO - 2024-02-20 20:08:56 --> Loader Class Initialized
INFO - 2024-02-20 20:08:56 --> Helper loaded: url_helper
INFO - 2024-02-20 20:08:56 --> Helper loaded: file_helper
INFO - 2024-02-20 20:08:56 --> Helper loaded: form_helper
INFO - 2024-02-20 20:08:56 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:08:56 --> Controller Class Initialized
INFO - 2024-02-20 20:08:56 --> Form Validation Class Initialized
INFO - 2024-02-20 20:08:56 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:08:56 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:08:56 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:08:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:08:56 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:08:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:08:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:08:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:08:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:08:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:08:56 --> Final output sent to browser
DEBUG - 2024-02-20 20:08:56 --> Total execution time: 0.0641
ERROR - 2024-02-20 20:10:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:10:47 --> Config Class Initialized
INFO - 2024-02-20 20:10:47 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:10:47 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:10:47 --> Utf8 Class Initialized
INFO - 2024-02-20 20:10:47 --> URI Class Initialized
INFO - 2024-02-20 20:10:47 --> Router Class Initialized
INFO - 2024-02-20 20:10:47 --> Output Class Initialized
INFO - 2024-02-20 20:10:47 --> Security Class Initialized
DEBUG - 2024-02-20 20:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:10:47 --> Input Class Initialized
INFO - 2024-02-20 20:10:47 --> Language Class Initialized
INFO - 2024-02-20 20:10:47 --> Loader Class Initialized
INFO - 2024-02-20 20:10:47 --> Helper loaded: url_helper
INFO - 2024-02-20 20:10:47 --> Helper loaded: file_helper
INFO - 2024-02-20 20:10:47 --> Helper loaded: form_helper
INFO - 2024-02-20 20:10:47 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:10:47 --> Controller Class Initialized
INFO - 2024-02-20 20:10:47 --> Form Validation Class Initialized
INFO - 2024-02-20 20:10:47 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:10:47 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:10:47 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:10:47 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:10:47 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:10:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:10:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:10:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:10:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:10:47 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:10:47 --> Final output sent to browser
DEBUG - 2024-02-20 20:10:47 --> Total execution time: 0.0557
ERROR - 2024-02-20 20:12:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:12:01 --> Config Class Initialized
INFO - 2024-02-20 20:12:01 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:12:01 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:12:01 --> Utf8 Class Initialized
INFO - 2024-02-20 20:12:01 --> URI Class Initialized
INFO - 2024-02-20 20:12:01 --> Router Class Initialized
INFO - 2024-02-20 20:12:01 --> Output Class Initialized
INFO - 2024-02-20 20:12:01 --> Security Class Initialized
DEBUG - 2024-02-20 20:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:12:01 --> Input Class Initialized
INFO - 2024-02-20 20:12:01 --> Language Class Initialized
INFO - 2024-02-20 20:12:01 --> Loader Class Initialized
INFO - 2024-02-20 20:12:01 --> Helper loaded: url_helper
INFO - 2024-02-20 20:12:01 --> Helper loaded: file_helper
INFO - 2024-02-20 20:12:01 --> Helper loaded: form_helper
INFO - 2024-02-20 20:12:01 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:12:01 --> Controller Class Initialized
INFO - 2024-02-20 20:12:01 --> Form Validation Class Initialized
INFO - 2024-02-20 20:12:01 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:12:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:12:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:12:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:12:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:12:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:12:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:12:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:12:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:12:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:12:01 --> Final output sent to browser
DEBUG - 2024-02-20 20:12:01 --> Total execution time: 0.0518
ERROR - 2024-02-20 20:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:14:18 --> Config Class Initialized
INFO - 2024-02-20 20:14:18 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:14:18 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:14:18 --> Utf8 Class Initialized
INFO - 2024-02-20 20:14:18 --> URI Class Initialized
INFO - 2024-02-20 20:14:18 --> Router Class Initialized
INFO - 2024-02-20 20:14:18 --> Output Class Initialized
INFO - 2024-02-20 20:14:18 --> Security Class Initialized
DEBUG - 2024-02-20 20:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:14:18 --> Input Class Initialized
INFO - 2024-02-20 20:14:18 --> Language Class Initialized
INFO - 2024-02-20 20:14:18 --> Loader Class Initialized
INFO - 2024-02-20 20:14:18 --> Helper loaded: url_helper
INFO - 2024-02-20 20:14:18 --> Helper loaded: file_helper
INFO - 2024-02-20 20:14:18 --> Helper loaded: form_helper
INFO - 2024-02-20 20:14:18 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:14:18 --> Controller Class Initialized
INFO - 2024-02-20 20:14:18 --> Form Validation Class Initialized
INFO - 2024-02-20 20:14:18 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:14:18 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:14:18 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:14:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:14:18 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:14:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:14:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:14:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:14:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:14:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:14:18 --> Final output sent to browser
DEBUG - 2024-02-20 20:14:18 --> Total execution time: 0.0462
ERROR - 2024-02-20 20:17:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:17:05 --> Config Class Initialized
INFO - 2024-02-20 20:17:05 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:17:05 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:17:05 --> Utf8 Class Initialized
INFO - 2024-02-20 20:17:05 --> URI Class Initialized
INFO - 2024-02-20 20:17:05 --> Router Class Initialized
INFO - 2024-02-20 20:17:05 --> Output Class Initialized
INFO - 2024-02-20 20:17:05 --> Security Class Initialized
DEBUG - 2024-02-20 20:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:17:05 --> Input Class Initialized
INFO - 2024-02-20 20:17:05 --> Language Class Initialized
INFO - 2024-02-20 20:17:05 --> Loader Class Initialized
INFO - 2024-02-20 20:17:05 --> Helper loaded: url_helper
INFO - 2024-02-20 20:17:05 --> Helper loaded: file_helper
INFO - 2024-02-20 20:17:05 --> Helper loaded: form_helper
INFO - 2024-02-20 20:17:05 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:17:05 --> Controller Class Initialized
INFO - 2024-02-20 20:17:05 --> Form Validation Class Initialized
INFO - 2024-02-20 20:17:05 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:17:05 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:17:05 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:17:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:17:05 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:17:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:17:05 --> Final output sent to browser
DEBUG - 2024-02-20 20:17:05 --> Total execution time: 0.0525
ERROR - 2024-02-20 20:17:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:17:06 --> Config Class Initialized
INFO - 2024-02-20 20:17:06 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:17:06 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:17:06 --> Utf8 Class Initialized
INFO - 2024-02-20 20:17:06 --> URI Class Initialized
INFO - 2024-02-20 20:17:06 --> Router Class Initialized
INFO - 2024-02-20 20:17:06 --> Output Class Initialized
INFO - 2024-02-20 20:17:06 --> Security Class Initialized
DEBUG - 2024-02-20 20:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:17:06 --> Input Class Initialized
INFO - 2024-02-20 20:17:06 --> Language Class Initialized
INFO - 2024-02-20 20:17:06 --> Loader Class Initialized
INFO - 2024-02-20 20:17:06 --> Helper loaded: url_helper
INFO - 2024-02-20 20:17:06 --> Helper loaded: file_helper
INFO - 2024-02-20 20:17:06 --> Helper loaded: form_helper
INFO - 2024-02-20 20:17:06 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:17:06 --> Controller Class Initialized
INFO - 2024-02-20 20:17:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-02-20 20:17:06 --> Final output sent to browser
DEBUG - 2024-02-20 20:17:06 --> Total execution time: 0.0691
ERROR - 2024-02-20 20:17:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:17:34 --> Config Class Initialized
INFO - 2024-02-20 20:17:34 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:17:34 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:17:34 --> Utf8 Class Initialized
INFO - 2024-02-20 20:17:34 --> URI Class Initialized
INFO - 2024-02-20 20:17:34 --> Router Class Initialized
INFO - 2024-02-20 20:17:34 --> Output Class Initialized
INFO - 2024-02-20 20:17:34 --> Security Class Initialized
DEBUG - 2024-02-20 20:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:17:34 --> Input Class Initialized
INFO - 2024-02-20 20:17:34 --> Language Class Initialized
INFO - 2024-02-20 20:17:34 --> Loader Class Initialized
INFO - 2024-02-20 20:17:34 --> Helper loaded: url_helper
INFO - 2024-02-20 20:17:34 --> Helper loaded: file_helper
INFO - 2024-02-20 20:17:34 --> Helper loaded: form_helper
INFO - 2024-02-20 20:17:34 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:17:34 --> Controller Class Initialized
INFO - 2024-02-20 20:17:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\page-404.php
INFO - 2024-02-20 20:17:34 --> Final output sent to browser
DEBUG - 2024-02-20 20:17:34 --> Total execution time: 0.0417
ERROR - 2024-02-20 20:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:17:45 --> Config Class Initialized
INFO - 2024-02-20 20:17:45 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:17:45 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:17:45 --> Utf8 Class Initialized
INFO - 2024-02-20 20:17:45 --> URI Class Initialized
DEBUG - 2024-02-20 20:17:45 --> No URI present. Default controller set.
INFO - 2024-02-20 20:17:45 --> Router Class Initialized
INFO - 2024-02-20 20:17:45 --> Output Class Initialized
INFO - 2024-02-20 20:17:45 --> Security Class Initialized
DEBUG - 2024-02-20 20:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:17:45 --> Input Class Initialized
INFO - 2024-02-20 20:17:45 --> Language Class Initialized
INFO - 2024-02-20 20:17:45 --> Loader Class Initialized
INFO - 2024-02-20 20:17:45 --> Helper loaded: url_helper
INFO - 2024-02-20 20:17:45 --> Helper loaded: file_helper
INFO - 2024-02-20 20:17:45 --> Helper loaded: form_helper
INFO - 2024-02-20 20:17:45 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:17:46 --> Controller Class Initialized
INFO - 2024-02-20 20:17:46 --> Model "LoginModel" initialized
INFO - 2024-02-20 20:17:46 --> Form Validation Class Initialized
INFO - 2024-02-20 20:17:46 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-20 20:17:46 --> Final output sent to browser
DEBUG - 2024-02-20 20:17:46 --> Total execution time: 0.0474
ERROR - 2024-02-20 20:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:18:07 --> Config Class Initialized
INFO - 2024-02-20 20:18:07 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:18:07 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:18:07 --> Utf8 Class Initialized
INFO - 2024-02-20 20:18:07 --> URI Class Initialized
INFO - 2024-02-20 20:18:07 --> Router Class Initialized
INFO - 2024-02-20 20:18:07 --> Output Class Initialized
INFO - 2024-02-20 20:18:07 --> Security Class Initialized
DEBUG - 2024-02-20 20:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:18:07 --> Input Class Initialized
INFO - 2024-02-20 20:18:07 --> Language Class Initialized
INFO - 2024-02-20 20:18:07 --> Loader Class Initialized
INFO - 2024-02-20 20:18:07 --> Helper loaded: url_helper
INFO - 2024-02-20 20:18:07 --> Helper loaded: file_helper
INFO - 2024-02-20 20:18:07 --> Helper loaded: form_helper
INFO - 2024-02-20 20:18:07 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:18:07 --> Controller Class Initialized
INFO - 2024-02-20 20:18:07 --> Model "LoginModel" initialized
INFO - 2024-02-20 20:18:07 --> Form Validation Class Initialized
INFO - 2024-02-20 20:18:07 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-20 20:18:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:18:08 --> Config Class Initialized
INFO - 2024-02-20 20:18:08 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:18:08 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:18:08 --> Utf8 Class Initialized
INFO - 2024-02-20 20:18:08 --> URI Class Initialized
INFO - 2024-02-20 20:18:08 --> Router Class Initialized
INFO - 2024-02-20 20:18:08 --> Output Class Initialized
INFO - 2024-02-20 20:18:08 --> Security Class Initialized
DEBUG - 2024-02-20 20:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:18:08 --> Input Class Initialized
INFO - 2024-02-20 20:18:08 --> Language Class Initialized
INFO - 2024-02-20 20:18:08 --> Loader Class Initialized
INFO - 2024-02-20 20:18:08 --> Helper loaded: url_helper
INFO - 2024-02-20 20:18:08 --> Helper loaded: file_helper
INFO - 2024-02-20 20:18:08 --> Helper loaded: form_helper
INFO - 2024-02-20 20:18:08 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:18:08 --> Controller Class Initialized
INFO - 2024-02-20 20:18:08 --> Model "LoginModel" initialized
INFO - 2024-02-20 20:18:08 --> Form Validation Class Initialized
INFO - 2024-02-20 20:18:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-02-20 20:18:08 --> Final output sent to browser
DEBUG - 2024-02-20 20:18:08 --> Total execution time: 0.0438
ERROR - 2024-02-20 20:18:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:18:23 --> Config Class Initialized
INFO - 2024-02-20 20:18:23 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:18:23 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:18:23 --> Utf8 Class Initialized
INFO - 2024-02-20 20:18:23 --> URI Class Initialized
INFO - 2024-02-20 20:18:23 --> Router Class Initialized
INFO - 2024-02-20 20:18:23 --> Output Class Initialized
INFO - 2024-02-20 20:18:23 --> Security Class Initialized
DEBUG - 2024-02-20 20:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:18:23 --> Input Class Initialized
INFO - 2024-02-20 20:18:23 --> Language Class Initialized
INFO - 2024-02-20 20:18:23 --> Loader Class Initialized
INFO - 2024-02-20 20:18:23 --> Helper loaded: url_helper
INFO - 2024-02-20 20:18:23 --> Helper loaded: file_helper
INFO - 2024-02-20 20:18:23 --> Helper loaded: form_helper
INFO - 2024-02-20 20:18:23 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:18:23 --> Controller Class Initialized
INFO - 2024-02-20 20:18:23 --> Model "LoginModel" initialized
INFO - 2024-02-20 20:18:23 --> Form Validation Class Initialized
INFO - 2024-02-20 20:18:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-20 20:18:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:18:24 --> Config Class Initialized
INFO - 2024-02-20 20:18:24 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:18:24 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:18:24 --> Utf8 Class Initialized
INFO - 2024-02-20 20:18:24 --> URI Class Initialized
INFO - 2024-02-20 20:18:24 --> Router Class Initialized
INFO - 2024-02-20 20:18:24 --> Output Class Initialized
INFO - 2024-02-20 20:18:24 --> Security Class Initialized
DEBUG - 2024-02-20 20:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:18:24 --> Input Class Initialized
INFO - 2024-02-20 20:18:24 --> Language Class Initialized
INFO - 2024-02-20 20:18:24 --> Loader Class Initialized
INFO - 2024-02-20 20:18:24 --> Helper loaded: url_helper
INFO - 2024-02-20 20:18:24 --> Helper loaded: file_helper
INFO - 2024-02-20 20:18:24 --> Helper loaded: form_helper
INFO - 2024-02-20 20:18:24 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:18:24 --> Controller Class Initialized
INFO - 2024-02-20 20:18:24 --> Form Validation Class Initialized
INFO - 2024-02-20 20:18:24 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:18:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:18:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:18:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:18:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:18:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:18:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-20 20:18:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:18:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:18:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:18:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-20 20:18:24 --> Final output sent to browser
DEBUG - 2024-02-20 20:18:24 --> Total execution time: 0.0513
ERROR - 2024-02-20 20:18:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:18:41 --> Config Class Initialized
INFO - 2024-02-20 20:18:41 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:18:41 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:18:41 --> Utf8 Class Initialized
INFO - 2024-02-20 20:18:41 --> URI Class Initialized
INFO - 2024-02-20 20:18:41 --> Router Class Initialized
INFO - 2024-02-20 20:18:41 --> Output Class Initialized
INFO - 2024-02-20 20:18:41 --> Security Class Initialized
DEBUG - 2024-02-20 20:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:18:41 --> Input Class Initialized
INFO - 2024-02-20 20:18:41 --> Language Class Initialized
INFO - 2024-02-20 20:18:41 --> Loader Class Initialized
INFO - 2024-02-20 20:18:41 --> Helper loaded: url_helper
INFO - 2024-02-20 20:18:41 --> Helper loaded: file_helper
INFO - 2024-02-20 20:18:41 --> Helper loaded: form_helper
INFO - 2024-02-20 20:18:41 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:18:41 --> Controller Class Initialized
INFO - 2024-02-20 20:18:41 --> Form Validation Class Initialized
INFO - 2024-02-20 20:18:41 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:18:41 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:18:41 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:18:41 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:18:41 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:18:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:18:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-02-20 20:18:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:18:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:18:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:18:41 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-02-20 20:18:41 --> Final output sent to browser
DEBUG - 2024-02-20 20:18:41 --> Total execution time: 0.0610
ERROR - 2024-02-20 20:18:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:18:44 --> Config Class Initialized
INFO - 2024-02-20 20:18:44 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:18:44 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:18:44 --> Utf8 Class Initialized
INFO - 2024-02-20 20:18:44 --> URI Class Initialized
INFO - 2024-02-20 20:18:44 --> Router Class Initialized
INFO - 2024-02-20 20:18:44 --> Output Class Initialized
INFO - 2024-02-20 20:18:44 --> Security Class Initialized
DEBUG - 2024-02-20 20:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:18:44 --> Input Class Initialized
INFO - 2024-02-20 20:18:44 --> Language Class Initialized
INFO - 2024-02-20 20:18:44 --> Loader Class Initialized
INFO - 2024-02-20 20:18:44 --> Helper loaded: url_helper
INFO - 2024-02-20 20:18:44 --> Helper loaded: file_helper
INFO - 2024-02-20 20:18:44 --> Helper loaded: form_helper
INFO - 2024-02-20 20:18:44 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:18:44 --> Controller Class Initialized
INFO - 2024-02-20 20:18:44 --> Form Validation Class Initialized
INFO - 2024-02-20 20:18:44 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:18:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:18:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:18:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:18:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:18:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:18:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:18:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:18:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:18:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:18:44 --> Final output sent to browser
DEBUG - 2024-02-20 20:18:44 --> Total execution time: 0.0450
ERROR - 2024-02-20 20:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:19:38 --> Config Class Initialized
INFO - 2024-02-20 20:19:38 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:19:38 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:19:38 --> Utf8 Class Initialized
INFO - 2024-02-20 20:19:38 --> URI Class Initialized
INFO - 2024-02-20 20:19:38 --> Router Class Initialized
INFO - 2024-02-20 20:19:38 --> Output Class Initialized
INFO - 2024-02-20 20:19:38 --> Security Class Initialized
DEBUG - 2024-02-20 20:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:19:38 --> Input Class Initialized
INFO - 2024-02-20 20:19:38 --> Language Class Initialized
INFO - 2024-02-20 20:19:38 --> Loader Class Initialized
INFO - 2024-02-20 20:19:38 --> Helper loaded: url_helper
INFO - 2024-02-20 20:19:38 --> Helper loaded: file_helper
INFO - 2024-02-20 20:19:38 --> Helper loaded: form_helper
INFO - 2024-02-20 20:19:38 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:19:38 --> Controller Class Initialized
INFO - 2024-02-20 20:19:38 --> Form Validation Class Initialized
INFO - 2024-02-20 20:19:38 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:19:38 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:19:38 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:19:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:19:38 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:19:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:19:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:19:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:19:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:19:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:19:38 --> Final output sent to browser
DEBUG - 2024-02-20 20:19:38 --> Total execution time: 0.0540
ERROR - 2024-02-20 20:19:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:19:43 --> Config Class Initialized
INFO - 2024-02-20 20:19:43 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:19:43 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:19:43 --> Utf8 Class Initialized
INFO - 2024-02-20 20:19:43 --> URI Class Initialized
INFO - 2024-02-20 20:19:43 --> Router Class Initialized
INFO - 2024-02-20 20:19:43 --> Output Class Initialized
INFO - 2024-02-20 20:19:43 --> Security Class Initialized
DEBUG - 2024-02-20 20:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:19:43 --> Input Class Initialized
INFO - 2024-02-20 20:19:43 --> Language Class Initialized
INFO - 2024-02-20 20:19:43 --> Loader Class Initialized
INFO - 2024-02-20 20:19:43 --> Helper loaded: url_helper
INFO - 2024-02-20 20:19:43 --> Helper loaded: file_helper
INFO - 2024-02-20 20:19:43 --> Helper loaded: form_helper
INFO - 2024-02-20 20:19:44 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:19:44 --> Controller Class Initialized
INFO - 2024-02-20 20:19:44 --> Form Validation Class Initialized
INFO - 2024-02-20 20:19:44 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:19:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:19:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:19:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:19:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:19:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:19:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:19:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:19:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:19:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:19:44 --> Final output sent to browser
DEBUG - 2024-02-20 20:19:44 --> Total execution time: 0.0659
ERROR - 2024-02-20 20:20:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:20:08 --> Config Class Initialized
INFO - 2024-02-20 20:20:08 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:20:08 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:20:08 --> Utf8 Class Initialized
INFO - 2024-02-20 20:20:08 --> URI Class Initialized
INFO - 2024-02-20 20:20:08 --> Router Class Initialized
INFO - 2024-02-20 20:20:08 --> Output Class Initialized
INFO - 2024-02-20 20:20:08 --> Security Class Initialized
DEBUG - 2024-02-20 20:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:20:08 --> Input Class Initialized
INFO - 2024-02-20 20:20:08 --> Language Class Initialized
INFO - 2024-02-20 20:20:08 --> Loader Class Initialized
INFO - 2024-02-20 20:20:08 --> Helper loaded: url_helper
INFO - 2024-02-20 20:20:08 --> Helper loaded: file_helper
INFO - 2024-02-20 20:20:08 --> Helper loaded: form_helper
INFO - 2024-02-20 20:20:08 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:20:08 --> Controller Class Initialized
INFO - 2024-02-20 20:20:08 --> Form Validation Class Initialized
INFO - 2024-02-20 20:20:08 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:20:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:20:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:20:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:20:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:20:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:20:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:20:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:20:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:20:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:20:08 --> Final output sent to browser
DEBUG - 2024-02-20 20:20:08 --> Total execution time: 0.0451
ERROR - 2024-02-20 20:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:20:29 --> Config Class Initialized
INFO - 2024-02-20 20:20:29 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:20:29 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:20:29 --> Utf8 Class Initialized
INFO - 2024-02-20 20:20:29 --> URI Class Initialized
INFO - 2024-02-20 20:20:29 --> Router Class Initialized
INFO - 2024-02-20 20:20:29 --> Output Class Initialized
INFO - 2024-02-20 20:20:29 --> Security Class Initialized
DEBUG - 2024-02-20 20:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:20:29 --> Input Class Initialized
INFO - 2024-02-20 20:20:29 --> Language Class Initialized
INFO - 2024-02-20 20:20:29 --> Loader Class Initialized
INFO - 2024-02-20 20:20:29 --> Helper loaded: url_helper
INFO - 2024-02-20 20:20:29 --> Helper loaded: file_helper
INFO - 2024-02-20 20:20:29 --> Helper loaded: form_helper
INFO - 2024-02-20 20:20:29 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:20:29 --> Controller Class Initialized
INFO - 2024-02-20 20:20:29 --> Form Validation Class Initialized
INFO - 2024-02-20 20:20:29 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:20:29 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:20:29 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:20:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:20:29 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:20:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:20:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:20:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:20:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:20:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:20:29 --> Final output sent to browser
DEBUG - 2024-02-20 20:20:29 --> Total execution time: 0.0502
ERROR - 2024-02-20 20:20:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:20:49 --> Config Class Initialized
INFO - 2024-02-20 20:20:49 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:20:49 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:20:49 --> Utf8 Class Initialized
INFO - 2024-02-20 20:20:49 --> URI Class Initialized
INFO - 2024-02-20 20:20:49 --> Router Class Initialized
INFO - 2024-02-20 20:20:49 --> Output Class Initialized
INFO - 2024-02-20 20:20:49 --> Security Class Initialized
DEBUG - 2024-02-20 20:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:20:49 --> Input Class Initialized
INFO - 2024-02-20 20:20:49 --> Language Class Initialized
INFO - 2024-02-20 20:20:49 --> Loader Class Initialized
INFO - 2024-02-20 20:20:49 --> Helper loaded: url_helper
INFO - 2024-02-20 20:20:49 --> Helper loaded: file_helper
INFO - 2024-02-20 20:20:49 --> Helper loaded: form_helper
INFO - 2024-02-20 20:20:49 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:20:49 --> Controller Class Initialized
INFO - 2024-02-20 20:20:49 --> Form Validation Class Initialized
INFO - 2024-02-20 20:20:50 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:20:50 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:20:50 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:20:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:20:50 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:20:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:20:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:20:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:20:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:20:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:20:50 --> Final output sent to browser
DEBUG - 2024-02-20 20:20:50 --> Total execution time: 0.0564
ERROR - 2024-02-20 20:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:20:57 --> Config Class Initialized
INFO - 2024-02-20 20:20:57 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:20:57 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:20:57 --> Utf8 Class Initialized
INFO - 2024-02-20 20:20:57 --> URI Class Initialized
INFO - 2024-02-20 20:20:57 --> Router Class Initialized
INFO - 2024-02-20 20:20:57 --> Output Class Initialized
INFO - 2024-02-20 20:20:57 --> Security Class Initialized
DEBUG - 2024-02-20 20:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:20:57 --> Input Class Initialized
INFO - 2024-02-20 20:20:57 --> Language Class Initialized
INFO - 2024-02-20 20:20:57 --> Loader Class Initialized
INFO - 2024-02-20 20:20:57 --> Helper loaded: url_helper
INFO - 2024-02-20 20:20:57 --> Helper loaded: file_helper
INFO - 2024-02-20 20:20:57 --> Helper loaded: form_helper
INFO - 2024-02-20 20:20:57 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:20:57 --> Controller Class Initialized
INFO - 2024-02-20 20:20:57 --> Form Validation Class Initialized
INFO - 2024-02-20 20:20:57 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:20:57 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:20:57 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:20:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:20:57 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:20:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:20:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:20:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:20:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:20:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:20:57 --> Final output sent to browser
DEBUG - 2024-02-20 20:20:57 --> Total execution time: 0.0668
ERROR - 2024-02-20 20:22:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:22:04 --> Config Class Initialized
INFO - 2024-02-20 20:22:04 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:22:04 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:22:04 --> Utf8 Class Initialized
INFO - 2024-02-20 20:22:04 --> URI Class Initialized
INFO - 2024-02-20 20:22:04 --> Router Class Initialized
INFO - 2024-02-20 20:22:04 --> Output Class Initialized
INFO - 2024-02-20 20:22:04 --> Security Class Initialized
DEBUG - 2024-02-20 20:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:22:04 --> Input Class Initialized
INFO - 2024-02-20 20:22:04 --> Language Class Initialized
INFO - 2024-02-20 20:22:04 --> Loader Class Initialized
INFO - 2024-02-20 20:22:04 --> Helper loaded: url_helper
INFO - 2024-02-20 20:22:04 --> Helper loaded: file_helper
INFO - 2024-02-20 20:22:04 --> Helper loaded: form_helper
INFO - 2024-02-20 20:22:04 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:22:04 --> Controller Class Initialized
INFO - 2024-02-20 20:22:04 --> Form Validation Class Initialized
INFO - 2024-02-20 20:22:04 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:22:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:22:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:22:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:22:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:22:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:22:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:22:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:22:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:22:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:22:04 --> Final output sent to browser
DEBUG - 2024-02-20 20:22:04 --> Total execution time: 0.0608
ERROR - 2024-02-20 20:22:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:22:08 --> Config Class Initialized
INFO - 2024-02-20 20:22:08 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:22:08 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:22:08 --> Utf8 Class Initialized
INFO - 2024-02-20 20:22:08 --> URI Class Initialized
INFO - 2024-02-20 20:22:08 --> Router Class Initialized
INFO - 2024-02-20 20:22:08 --> Output Class Initialized
INFO - 2024-02-20 20:22:08 --> Security Class Initialized
DEBUG - 2024-02-20 20:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:22:08 --> Input Class Initialized
INFO - 2024-02-20 20:22:08 --> Language Class Initialized
INFO - 2024-02-20 20:22:08 --> Loader Class Initialized
INFO - 2024-02-20 20:22:08 --> Helper loaded: url_helper
INFO - 2024-02-20 20:22:08 --> Helper loaded: file_helper
INFO - 2024-02-20 20:22:08 --> Helper loaded: form_helper
INFO - 2024-02-20 20:22:08 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:22:08 --> Controller Class Initialized
INFO - 2024-02-20 20:22:08 --> Form Validation Class Initialized
INFO - 2024-02-20 20:22:08 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:22:08 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:22:08 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:22:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:22:08 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:22:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:22:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:22:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:22:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:22:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:22:08 --> Final output sent to browser
DEBUG - 2024-02-20 20:22:08 --> Total execution time: 0.0640
ERROR - 2024-02-20 20:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:22:17 --> Config Class Initialized
INFO - 2024-02-20 20:22:17 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:22:17 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:22:17 --> Utf8 Class Initialized
INFO - 2024-02-20 20:22:17 --> URI Class Initialized
INFO - 2024-02-20 20:22:17 --> Router Class Initialized
INFO - 2024-02-20 20:22:17 --> Output Class Initialized
INFO - 2024-02-20 20:22:17 --> Security Class Initialized
DEBUG - 2024-02-20 20:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:22:17 --> Input Class Initialized
INFO - 2024-02-20 20:22:17 --> Language Class Initialized
INFO - 2024-02-20 20:22:17 --> Loader Class Initialized
INFO - 2024-02-20 20:22:17 --> Helper loaded: url_helper
INFO - 2024-02-20 20:22:17 --> Helper loaded: file_helper
INFO - 2024-02-20 20:22:17 --> Helper loaded: form_helper
INFO - 2024-02-20 20:22:17 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:22:17 --> Controller Class Initialized
INFO - 2024-02-20 20:22:17 --> Form Validation Class Initialized
INFO - 2024-02-20 20:22:17 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:22:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:22:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:22:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:22:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:22:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:22:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:22:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:22:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:22:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:22:17 --> Final output sent to browser
DEBUG - 2024-02-20 20:22:17 --> Total execution time: 0.0839
ERROR - 2024-02-20 20:23:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:23:04 --> Config Class Initialized
INFO - 2024-02-20 20:23:04 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:23:04 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:23:04 --> Utf8 Class Initialized
INFO - 2024-02-20 20:23:04 --> URI Class Initialized
INFO - 2024-02-20 20:23:04 --> Router Class Initialized
INFO - 2024-02-20 20:23:04 --> Output Class Initialized
INFO - 2024-02-20 20:23:04 --> Security Class Initialized
DEBUG - 2024-02-20 20:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:23:04 --> Input Class Initialized
INFO - 2024-02-20 20:23:04 --> Language Class Initialized
INFO - 2024-02-20 20:23:04 --> Loader Class Initialized
INFO - 2024-02-20 20:23:04 --> Helper loaded: url_helper
INFO - 2024-02-20 20:23:04 --> Helper loaded: file_helper
INFO - 2024-02-20 20:23:04 --> Helper loaded: form_helper
INFO - 2024-02-20 20:23:04 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:23:04 --> Controller Class Initialized
INFO - 2024-02-20 20:23:04 --> Form Validation Class Initialized
INFO - 2024-02-20 20:23:04 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:23:04 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:23:04 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:23:04 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:23:04 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:23:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:23:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:23:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:23:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:23:04 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:23:04 --> Final output sent to browser
DEBUG - 2024-02-20 20:23:04 --> Total execution time: 0.0936
ERROR - 2024-02-20 20:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:23:15 --> Config Class Initialized
INFO - 2024-02-20 20:23:15 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:23:15 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:23:15 --> Utf8 Class Initialized
INFO - 2024-02-20 20:23:15 --> URI Class Initialized
INFO - 2024-02-20 20:23:15 --> Router Class Initialized
INFO - 2024-02-20 20:23:15 --> Output Class Initialized
INFO - 2024-02-20 20:23:15 --> Security Class Initialized
DEBUG - 2024-02-20 20:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:23:15 --> Input Class Initialized
INFO - 2024-02-20 20:23:15 --> Language Class Initialized
INFO - 2024-02-20 20:23:15 --> Loader Class Initialized
INFO - 2024-02-20 20:23:15 --> Helper loaded: url_helper
INFO - 2024-02-20 20:23:15 --> Helper loaded: file_helper
INFO - 2024-02-20 20:23:15 --> Helper loaded: form_helper
INFO - 2024-02-20 20:23:15 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:23:15 --> Controller Class Initialized
INFO - 2024-02-20 20:23:15 --> Form Validation Class Initialized
INFO - 2024-02-20 20:23:15 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:23:15 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:23:15 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:23:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:23:15 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:23:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:23:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:23:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:23:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:23:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:23:15 --> Final output sent to browser
DEBUG - 2024-02-20 20:23:15 --> Total execution time: 0.0600
ERROR - 2024-02-20 20:23:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:23:58 --> Config Class Initialized
INFO - 2024-02-20 20:23:58 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:23:58 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:23:58 --> Utf8 Class Initialized
INFO - 2024-02-20 20:23:58 --> URI Class Initialized
INFO - 2024-02-20 20:23:58 --> Router Class Initialized
INFO - 2024-02-20 20:23:58 --> Output Class Initialized
INFO - 2024-02-20 20:23:58 --> Security Class Initialized
DEBUG - 2024-02-20 20:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:23:58 --> Input Class Initialized
INFO - 2024-02-20 20:23:58 --> Language Class Initialized
INFO - 2024-02-20 20:23:58 --> Loader Class Initialized
INFO - 2024-02-20 20:23:58 --> Helper loaded: url_helper
INFO - 2024-02-20 20:23:58 --> Helper loaded: file_helper
INFO - 2024-02-20 20:23:58 --> Helper loaded: form_helper
INFO - 2024-02-20 20:23:58 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:23:58 --> Controller Class Initialized
INFO - 2024-02-20 20:23:58 --> Form Validation Class Initialized
INFO - 2024-02-20 20:23:58 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:23:58 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:23:58 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:23:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:23:58 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:23:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:23:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:23:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:23:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:23:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:23:58 --> Final output sent to browser
DEBUG - 2024-02-20 20:23:58 --> Total execution time: 0.0599
ERROR - 2024-02-20 20:24:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:24:11 --> Config Class Initialized
INFO - 2024-02-20 20:24:11 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:24:11 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:24:11 --> Utf8 Class Initialized
INFO - 2024-02-20 20:24:11 --> URI Class Initialized
INFO - 2024-02-20 20:24:11 --> Router Class Initialized
INFO - 2024-02-20 20:24:11 --> Output Class Initialized
INFO - 2024-02-20 20:24:11 --> Security Class Initialized
DEBUG - 2024-02-20 20:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:24:11 --> Input Class Initialized
INFO - 2024-02-20 20:24:11 --> Language Class Initialized
INFO - 2024-02-20 20:24:11 --> Loader Class Initialized
INFO - 2024-02-20 20:24:11 --> Helper loaded: url_helper
INFO - 2024-02-20 20:24:11 --> Helper loaded: file_helper
INFO - 2024-02-20 20:24:11 --> Helper loaded: form_helper
INFO - 2024-02-20 20:24:11 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:24:11 --> Controller Class Initialized
INFO - 2024-02-20 20:24:11 --> Form Validation Class Initialized
INFO - 2024-02-20 20:24:11 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:24:11 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:24:11 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:24:11 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:24:11 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:24:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:24:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:24:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:24:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:24:11 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:24:11 --> Final output sent to browser
DEBUG - 2024-02-20 20:24:11 --> Total execution time: 0.0647
ERROR - 2024-02-20 20:24:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:24:19 --> Config Class Initialized
INFO - 2024-02-20 20:24:19 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:24:19 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:24:19 --> Utf8 Class Initialized
INFO - 2024-02-20 20:24:19 --> URI Class Initialized
INFO - 2024-02-20 20:24:19 --> Router Class Initialized
INFO - 2024-02-20 20:24:19 --> Output Class Initialized
INFO - 2024-02-20 20:24:19 --> Security Class Initialized
DEBUG - 2024-02-20 20:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:24:19 --> Input Class Initialized
INFO - 2024-02-20 20:24:19 --> Language Class Initialized
INFO - 2024-02-20 20:24:19 --> Loader Class Initialized
INFO - 2024-02-20 20:24:19 --> Helper loaded: url_helper
INFO - 2024-02-20 20:24:19 --> Helper loaded: file_helper
INFO - 2024-02-20 20:24:19 --> Helper loaded: form_helper
INFO - 2024-02-20 20:24:19 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:24:19 --> Controller Class Initialized
INFO - 2024-02-20 20:24:19 --> Form Validation Class Initialized
INFO - 2024-02-20 20:24:19 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:24:19 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:24:19 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:24:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:24:19 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:24:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:24:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:24:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:24:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:24:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:24:19 --> Final output sent to browser
DEBUG - 2024-02-20 20:24:19 --> Total execution time: 0.0557
ERROR - 2024-02-20 20:24:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:24:34 --> Config Class Initialized
INFO - 2024-02-20 20:24:34 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:24:34 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:24:34 --> Utf8 Class Initialized
INFO - 2024-02-20 20:24:34 --> URI Class Initialized
INFO - 2024-02-20 20:24:34 --> Router Class Initialized
INFO - 2024-02-20 20:24:34 --> Output Class Initialized
INFO - 2024-02-20 20:24:34 --> Security Class Initialized
DEBUG - 2024-02-20 20:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:24:34 --> Input Class Initialized
INFO - 2024-02-20 20:24:34 --> Language Class Initialized
INFO - 2024-02-20 20:24:34 --> Loader Class Initialized
INFO - 2024-02-20 20:24:34 --> Helper loaded: url_helper
INFO - 2024-02-20 20:24:34 --> Helper loaded: file_helper
INFO - 2024-02-20 20:24:34 --> Helper loaded: form_helper
INFO - 2024-02-20 20:24:34 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:24:34 --> Controller Class Initialized
INFO - 2024-02-20 20:24:34 --> Form Validation Class Initialized
INFO - 2024-02-20 20:24:34 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:24:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:24:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:24:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:24:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:24:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:24:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:24:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:24:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:24:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:24:34 --> Final output sent to browser
DEBUG - 2024-02-20 20:24:34 --> Total execution time: 0.0616
ERROR - 2024-02-20 20:24:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:24:39 --> Config Class Initialized
INFO - 2024-02-20 20:24:39 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:24:39 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:24:39 --> Utf8 Class Initialized
INFO - 2024-02-20 20:24:39 --> URI Class Initialized
INFO - 2024-02-20 20:24:39 --> Router Class Initialized
INFO - 2024-02-20 20:24:39 --> Output Class Initialized
INFO - 2024-02-20 20:24:39 --> Security Class Initialized
DEBUG - 2024-02-20 20:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:24:39 --> Input Class Initialized
INFO - 2024-02-20 20:24:39 --> Language Class Initialized
INFO - 2024-02-20 20:24:39 --> Loader Class Initialized
INFO - 2024-02-20 20:24:39 --> Helper loaded: url_helper
INFO - 2024-02-20 20:24:39 --> Helper loaded: file_helper
INFO - 2024-02-20 20:24:39 --> Helper loaded: form_helper
INFO - 2024-02-20 20:24:39 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:24:39 --> Controller Class Initialized
INFO - 2024-02-20 20:24:39 --> Form Validation Class Initialized
INFO - 2024-02-20 20:24:39 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:24:39 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:24:39 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:24:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:24:39 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:24:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:24:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:24:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:24:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:24:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:24:39 --> Final output sent to browser
DEBUG - 2024-02-20 20:24:39 --> Total execution time: 0.0517
ERROR - 2024-02-20 20:25:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:25:01 --> Config Class Initialized
INFO - 2024-02-20 20:25:01 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:25:01 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:25:01 --> Utf8 Class Initialized
INFO - 2024-02-20 20:25:01 --> URI Class Initialized
INFO - 2024-02-20 20:25:01 --> Router Class Initialized
INFO - 2024-02-20 20:25:01 --> Output Class Initialized
INFO - 2024-02-20 20:25:01 --> Security Class Initialized
DEBUG - 2024-02-20 20:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:25:01 --> Input Class Initialized
INFO - 2024-02-20 20:25:01 --> Language Class Initialized
INFO - 2024-02-20 20:25:01 --> Loader Class Initialized
INFO - 2024-02-20 20:25:01 --> Helper loaded: url_helper
INFO - 2024-02-20 20:25:01 --> Helper loaded: file_helper
INFO - 2024-02-20 20:25:01 --> Helper loaded: form_helper
INFO - 2024-02-20 20:25:01 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:25:01 --> Controller Class Initialized
INFO - 2024-02-20 20:25:01 --> Form Validation Class Initialized
INFO - 2024-02-20 20:25:01 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:25:01 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:25:01 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:25:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:25:01 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:25:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:25:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:25:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:25:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:25:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:25:01 --> Final output sent to browser
DEBUG - 2024-02-20 20:25:01 --> Total execution time: 0.0504
ERROR - 2024-02-20 20:25:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:25:15 --> Config Class Initialized
INFO - 2024-02-20 20:25:15 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:25:15 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:25:15 --> Utf8 Class Initialized
INFO - 2024-02-20 20:25:15 --> URI Class Initialized
INFO - 2024-02-20 20:25:15 --> Router Class Initialized
INFO - 2024-02-20 20:25:15 --> Output Class Initialized
INFO - 2024-02-20 20:25:15 --> Security Class Initialized
DEBUG - 2024-02-20 20:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:25:15 --> Input Class Initialized
INFO - 2024-02-20 20:25:15 --> Language Class Initialized
INFO - 2024-02-20 20:25:16 --> Loader Class Initialized
INFO - 2024-02-20 20:25:16 --> Helper loaded: url_helper
INFO - 2024-02-20 20:25:16 --> Helper loaded: file_helper
INFO - 2024-02-20 20:25:16 --> Helper loaded: form_helper
INFO - 2024-02-20 20:25:16 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:25:16 --> Controller Class Initialized
INFO - 2024-02-20 20:25:16 --> Form Validation Class Initialized
INFO - 2024-02-20 20:25:16 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:25:16 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:25:16 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:25:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:25:16 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:25:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:25:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:25:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:25:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:25:16 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:25:16 --> Final output sent to browser
DEBUG - 2024-02-20 20:25:16 --> Total execution time: 0.0583
ERROR - 2024-02-20 20:25:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:25:20 --> Config Class Initialized
INFO - 2024-02-20 20:25:20 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:25:20 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:25:20 --> Utf8 Class Initialized
INFO - 2024-02-20 20:25:20 --> URI Class Initialized
INFO - 2024-02-20 20:25:20 --> Router Class Initialized
INFO - 2024-02-20 20:25:20 --> Output Class Initialized
INFO - 2024-02-20 20:25:20 --> Security Class Initialized
DEBUG - 2024-02-20 20:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:25:20 --> Input Class Initialized
INFO - 2024-02-20 20:25:20 --> Language Class Initialized
INFO - 2024-02-20 20:25:20 --> Loader Class Initialized
INFO - 2024-02-20 20:25:20 --> Helper loaded: url_helper
INFO - 2024-02-20 20:25:20 --> Helper loaded: file_helper
INFO - 2024-02-20 20:25:20 --> Helper loaded: form_helper
INFO - 2024-02-20 20:25:20 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:25:20 --> Controller Class Initialized
INFO - 2024-02-20 20:25:20 --> Form Validation Class Initialized
INFO - 2024-02-20 20:25:20 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:25:20 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:25:20 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:25:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:25:20 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:25:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:25:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:25:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:25:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:25:20 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:25:20 --> Final output sent to browser
DEBUG - 2024-02-20 20:25:20 --> Total execution time: 0.0541
ERROR - 2024-02-20 20:25:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:25:34 --> Config Class Initialized
INFO - 2024-02-20 20:25:34 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:25:34 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:25:34 --> Utf8 Class Initialized
INFO - 2024-02-20 20:25:34 --> URI Class Initialized
INFO - 2024-02-20 20:25:34 --> Router Class Initialized
INFO - 2024-02-20 20:25:34 --> Output Class Initialized
INFO - 2024-02-20 20:25:34 --> Security Class Initialized
DEBUG - 2024-02-20 20:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:25:34 --> Input Class Initialized
INFO - 2024-02-20 20:25:34 --> Language Class Initialized
INFO - 2024-02-20 20:25:34 --> Loader Class Initialized
INFO - 2024-02-20 20:25:34 --> Helper loaded: url_helper
INFO - 2024-02-20 20:25:34 --> Helper loaded: file_helper
INFO - 2024-02-20 20:25:34 --> Helper loaded: form_helper
INFO - 2024-02-20 20:25:34 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:25:34 --> Controller Class Initialized
INFO - 2024-02-20 20:25:34 --> Form Validation Class Initialized
INFO - 2024-02-20 20:25:34 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:25:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:25:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:25:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:25:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:25:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:25:34 --> Final output sent to browser
DEBUG - 2024-02-20 20:25:34 --> Total execution time: 0.0693
ERROR - 2024-02-20 20:25:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 20:25:44 --> Config Class Initialized
INFO - 2024-02-20 20:25:44 --> Hooks Class Initialized
DEBUG - 2024-02-20 20:25:44 --> UTF-8 Support Enabled
INFO - 2024-02-20 20:25:44 --> Utf8 Class Initialized
INFO - 2024-02-20 20:25:44 --> URI Class Initialized
INFO - 2024-02-20 20:25:44 --> Router Class Initialized
INFO - 2024-02-20 20:25:44 --> Output Class Initialized
INFO - 2024-02-20 20:25:44 --> Security Class Initialized
DEBUG - 2024-02-20 20:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 20:25:44 --> Input Class Initialized
INFO - 2024-02-20 20:25:44 --> Language Class Initialized
INFO - 2024-02-20 20:25:44 --> Loader Class Initialized
INFO - 2024-02-20 20:25:44 --> Helper loaded: url_helper
INFO - 2024-02-20 20:25:44 --> Helper loaded: file_helper
INFO - 2024-02-20 20:25:44 --> Helper loaded: form_helper
INFO - 2024-02-20 20:25:44 --> Database Driver Class Initialized
DEBUG - 2024-02-20 20:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 20:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 20:25:44 --> Controller Class Initialized
INFO - 2024-02-20 20:25:44 --> Form Validation Class Initialized
INFO - 2024-02-20 20:25:44 --> Model "MasterModel" initialized
INFO - 2024-02-20 20:25:44 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 20:25:44 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 20:25:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 20:25:44 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 20:25:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 20:25:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 20:25:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 20:25:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 20:25:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 20:25:44 --> Final output sent to browser
DEBUG - 2024-02-20 20:25:44 --> Total execution time: 0.0597
ERROR - 2024-02-20 21:05:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 21:05:59 --> Config Class Initialized
INFO - 2024-02-20 21:05:59 --> Hooks Class Initialized
DEBUG - 2024-02-20 21:05:59 --> UTF-8 Support Enabled
INFO - 2024-02-20 21:05:59 --> Utf8 Class Initialized
INFO - 2024-02-20 21:05:59 --> URI Class Initialized
INFO - 2024-02-20 21:05:59 --> Router Class Initialized
INFO - 2024-02-20 21:05:59 --> Output Class Initialized
INFO - 2024-02-20 21:05:59 --> Security Class Initialized
DEBUG - 2024-02-20 21:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 21:05:59 --> Input Class Initialized
INFO - 2024-02-20 21:05:59 --> Language Class Initialized
INFO - 2024-02-20 21:05:59 --> Loader Class Initialized
INFO - 2024-02-20 21:05:59 --> Helper loaded: url_helper
INFO - 2024-02-20 21:05:59 --> Helper loaded: file_helper
INFO - 2024-02-20 21:05:59 --> Helper loaded: form_helper
INFO - 2024-02-20 21:05:59 --> Database Driver Class Initialized
DEBUG - 2024-02-20 21:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 21:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 21:05:59 --> Controller Class Initialized
INFO - 2024-02-20 21:05:59 --> Form Validation Class Initialized
INFO - 2024-02-20 21:05:59 --> Model "MasterModel" initialized
INFO - 2024-02-20 21:05:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 21:05:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 21:05:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 21:05:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 21:05:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 21:05:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 21:05:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 21:05:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 21:05:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 21:05:59 --> Final output sent to browser
DEBUG - 2024-02-20 21:05:59 --> Total execution time: 0.0778
ERROR - 2024-02-20 21:06:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 21:06:17 --> Config Class Initialized
INFO - 2024-02-20 21:06:17 --> Hooks Class Initialized
DEBUG - 2024-02-20 21:06:17 --> UTF-8 Support Enabled
INFO - 2024-02-20 21:06:17 --> Utf8 Class Initialized
INFO - 2024-02-20 21:06:17 --> URI Class Initialized
INFO - 2024-02-20 21:06:17 --> Router Class Initialized
INFO - 2024-02-20 21:06:17 --> Output Class Initialized
INFO - 2024-02-20 21:06:17 --> Security Class Initialized
DEBUG - 2024-02-20 21:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 21:06:17 --> Input Class Initialized
INFO - 2024-02-20 21:06:17 --> Language Class Initialized
INFO - 2024-02-20 21:06:17 --> Loader Class Initialized
INFO - 2024-02-20 21:06:17 --> Helper loaded: url_helper
INFO - 2024-02-20 21:06:17 --> Helper loaded: file_helper
INFO - 2024-02-20 21:06:17 --> Helper loaded: form_helper
INFO - 2024-02-20 21:06:17 --> Database Driver Class Initialized
DEBUG - 2024-02-20 21:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 21:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 21:06:17 --> Controller Class Initialized
INFO - 2024-02-20 21:06:17 --> Form Validation Class Initialized
INFO - 2024-02-20 21:06:17 --> Model "MasterModel" initialized
INFO - 2024-02-20 21:06:17 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 21:06:17 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 21:06:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 21:06:17 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 21:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 21:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 21:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 21:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 21:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 21:06:17 --> Final output sent to browser
DEBUG - 2024-02-20 21:06:17 --> Total execution time: 0.0633
ERROR - 2024-02-20 21:07:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 21:07:24 --> Config Class Initialized
INFO - 2024-02-20 21:07:24 --> Hooks Class Initialized
DEBUG - 2024-02-20 21:07:24 --> UTF-8 Support Enabled
INFO - 2024-02-20 21:07:24 --> Utf8 Class Initialized
INFO - 2024-02-20 21:07:24 --> URI Class Initialized
INFO - 2024-02-20 21:07:24 --> Router Class Initialized
INFO - 2024-02-20 21:07:24 --> Output Class Initialized
INFO - 2024-02-20 21:07:24 --> Security Class Initialized
DEBUG - 2024-02-20 21:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 21:07:24 --> Input Class Initialized
INFO - 2024-02-20 21:07:24 --> Language Class Initialized
INFO - 2024-02-20 21:07:24 --> Loader Class Initialized
INFO - 2024-02-20 21:07:24 --> Helper loaded: url_helper
INFO - 2024-02-20 21:07:24 --> Helper loaded: file_helper
INFO - 2024-02-20 21:07:24 --> Helper loaded: form_helper
INFO - 2024-02-20 21:07:24 --> Database Driver Class Initialized
DEBUG - 2024-02-20 21:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 21:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 21:07:24 --> Controller Class Initialized
INFO - 2024-02-20 21:07:24 --> Form Validation Class Initialized
INFO - 2024-02-20 21:07:24 --> Model "MasterModel" initialized
INFO - 2024-02-20 21:07:24 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 21:07:24 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 21:07:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 21:07:24 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 21:07:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 21:07:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 21:07:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 21:07:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 21:07:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 21:07:24 --> Final output sent to browser
DEBUG - 2024-02-20 21:07:24 --> Total execution time: 0.0575
ERROR - 2024-02-20 21:07:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 21:07:34 --> Config Class Initialized
INFO - 2024-02-20 21:07:34 --> Hooks Class Initialized
DEBUG - 2024-02-20 21:07:34 --> UTF-8 Support Enabled
INFO - 2024-02-20 21:07:34 --> Utf8 Class Initialized
INFO - 2024-02-20 21:07:34 --> URI Class Initialized
INFO - 2024-02-20 21:07:34 --> Router Class Initialized
INFO - 2024-02-20 21:07:34 --> Output Class Initialized
INFO - 2024-02-20 21:07:35 --> Security Class Initialized
DEBUG - 2024-02-20 21:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 21:07:35 --> Input Class Initialized
INFO - 2024-02-20 21:07:35 --> Language Class Initialized
INFO - 2024-02-20 21:07:35 --> Loader Class Initialized
INFO - 2024-02-20 21:07:35 --> Helper loaded: url_helper
INFO - 2024-02-20 21:07:35 --> Helper loaded: file_helper
INFO - 2024-02-20 21:07:35 --> Helper loaded: form_helper
INFO - 2024-02-20 21:07:35 --> Database Driver Class Initialized
DEBUG - 2024-02-20 21:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 21:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 21:07:35 --> Controller Class Initialized
INFO - 2024-02-20 21:07:35 --> Form Validation Class Initialized
INFO - 2024-02-20 21:07:35 --> Model "MasterModel" initialized
INFO - 2024-02-20 21:07:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 21:07:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 21:07:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 21:07:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 21:07:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 21:07:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 21:07:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 21:07:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 21:07:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 21:07:35 --> Final output sent to browser
DEBUG - 2024-02-20 21:07:35 --> Total execution time: 0.0569
ERROR - 2024-02-20 21:07:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 21:07:40 --> Config Class Initialized
INFO - 2024-02-20 21:07:40 --> Hooks Class Initialized
DEBUG - 2024-02-20 21:07:40 --> UTF-8 Support Enabled
INFO - 2024-02-20 21:07:40 --> Utf8 Class Initialized
INFO - 2024-02-20 21:07:40 --> URI Class Initialized
INFO - 2024-02-20 21:07:40 --> Router Class Initialized
INFO - 2024-02-20 21:07:40 --> Output Class Initialized
INFO - 2024-02-20 21:07:40 --> Security Class Initialized
DEBUG - 2024-02-20 21:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 21:07:40 --> Input Class Initialized
INFO - 2024-02-20 21:07:40 --> Language Class Initialized
INFO - 2024-02-20 21:07:40 --> Loader Class Initialized
INFO - 2024-02-20 21:07:40 --> Helper loaded: url_helper
INFO - 2024-02-20 21:07:40 --> Helper loaded: file_helper
INFO - 2024-02-20 21:07:40 --> Helper loaded: form_helper
INFO - 2024-02-20 21:07:40 --> Database Driver Class Initialized
DEBUG - 2024-02-20 21:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 21:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 21:07:40 --> Controller Class Initialized
INFO - 2024-02-20 21:07:40 --> Form Validation Class Initialized
INFO - 2024-02-20 21:07:40 --> Model "MasterModel" initialized
INFO - 2024-02-20 21:07:40 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 21:07:40 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 21:07:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 21:07:40 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 21:07:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 21:07:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 21:07:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 21:07:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 21:07:40 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 21:07:40 --> Final output sent to browser
DEBUG - 2024-02-20 21:07:40 --> Total execution time: 0.0577
ERROR - 2024-02-20 21:08:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 21:08:59 --> Config Class Initialized
INFO - 2024-02-20 21:08:59 --> Hooks Class Initialized
DEBUG - 2024-02-20 21:08:59 --> UTF-8 Support Enabled
INFO - 2024-02-20 21:08:59 --> Utf8 Class Initialized
INFO - 2024-02-20 21:08:59 --> URI Class Initialized
INFO - 2024-02-20 21:08:59 --> Router Class Initialized
INFO - 2024-02-20 21:08:59 --> Output Class Initialized
INFO - 2024-02-20 21:08:59 --> Security Class Initialized
DEBUG - 2024-02-20 21:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 21:08:59 --> Input Class Initialized
INFO - 2024-02-20 21:08:59 --> Language Class Initialized
INFO - 2024-02-20 21:08:59 --> Loader Class Initialized
INFO - 2024-02-20 21:08:59 --> Helper loaded: url_helper
INFO - 2024-02-20 21:08:59 --> Helper loaded: file_helper
INFO - 2024-02-20 21:08:59 --> Helper loaded: form_helper
INFO - 2024-02-20 21:08:59 --> Database Driver Class Initialized
DEBUG - 2024-02-20 21:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 21:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 21:08:59 --> Controller Class Initialized
INFO - 2024-02-20 21:08:59 --> Form Validation Class Initialized
INFO - 2024-02-20 21:08:59 --> Model "MasterModel" initialized
INFO - 2024-02-20 21:08:59 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 21:08:59 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 21:08:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 21:08:59 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 21:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 21:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 21:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 21:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 21:08:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 21:08:59 --> Final output sent to browser
DEBUG - 2024-02-20 21:08:59 --> Total execution time: 0.0607
ERROR - 2024-02-20 21:09:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 21:09:35 --> Config Class Initialized
INFO - 2024-02-20 21:09:35 --> Hooks Class Initialized
DEBUG - 2024-02-20 21:09:35 --> UTF-8 Support Enabled
INFO - 2024-02-20 21:09:35 --> Utf8 Class Initialized
INFO - 2024-02-20 21:09:35 --> URI Class Initialized
INFO - 2024-02-20 21:09:35 --> Router Class Initialized
INFO - 2024-02-20 21:09:35 --> Output Class Initialized
INFO - 2024-02-20 21:09:35 --> Security Class Initialized
DEBUG - 2024-02-20 21:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 21:09:35 --> Input Class Initialized
INFO - 2024-02-20 21:09:35 --> Language Class Initialized
INFO - 2024-02-20 21:09:35 --> Loader Class Initialized
INFO - 2024-02-20 21:09:35 --> Helper loaded: url_helper
INFO - 2024-02-20 21:09:35 --> Helper loaded: file_helper
INFO - 2024-02-20 21:09:35 --> Helper loaded: form_helper
INFO - 2024-02-20 21:09:35 --> Database Driver Class Initialized
DEBUG - 2024-02-20 21:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 21:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 21:09:35 --> Controller Class Initialized
INFO - 2024-02-20 21:09:35 --> Form Validation Class Initialized
INFO - 2024-02-20 21:09:35 --> Model "MasterModel" initialized
INFO - 2024-02-20 21:09:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 21:09:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 21:09:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 21:09:35 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 21:09:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 21:09:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 21:09:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 21:09:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 21:09:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 21:09:35 --> Final output sent to browser
DEBUG - 2024-02-20 21:09:35 --> Total execution time: 0.0554
ERROR - 2024-02-20 21:09:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 21:09:43 --> Config Class Initialized
INFO - 2024-02-20 21:09:43 --> Hooks Class Initialized
DEBUG - 2024-02-20 21:09:43 --> UTF-8 Support Enabled
INFO - 2024-02-20 21:09:43 --> Utf8 Class Initialized
INFO - 2024-02-20 21:09:43 --> URI Class Initialized
INFO - 2024-02-20 21:09:43 --> Router Class Initialized
INFO - 2024-02-20 21:09:43 --> Output Class Initialized
INFO - 2024-02-20 21:09:43 --> Security Class Initialized
DEBUG - 2024-02-20 21:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 21:09:43 --> Input Class Initialized
INFO - 2024-02-20 21:09:43 --> Language Class Initialized
INFO - 2024-02-20 21:09:43 --> Loader Class Initialized
INFO - 2024-02-20 21:09:43 --> Helper loaded: url_helper
INFO - 2024-02-20 21:09:43 --> Helper loaded: file_helper
INFO - 2024-02-20 21:09:43 --> Helper loaded: form_helper
INFO - 2024-02-20 21:09:43 --> Database Driver Class Initialized
DEBUG - 2024-02-20 21:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 21:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 21:09:43 --> Controller Class Initialized
INFO - 2024-02-20 21:09:43 --> Form Validation Class Initialized
INFO - 2024-02-20 21:09:43 --> Model "MasterModel" initialized
INFO - 2024-02-20 21:09:43 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 21:09:43 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 21:09:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 21:09:43 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 21:09:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 21:09:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 21:09:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 21:09:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 21:09:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 21:09:43 --> Final output sent to browser
DEBUG - 2024-02-20 21:09:43 --> Total execution time: 0.0573
ERROR - 2024-02-20 21:09:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 21:09:54 --> Config Class Initialized
INFO - 2024-02-20 21:09:54 --> Hooks Class Initialized
DEBUG - 2024-02-20 21:09:54 --> UTF-8 Support Enabled
INFO - 2024-02-20 21:09:54 --> Utf8 Class Initialized
INFO - 2024-02-20 21:09:54 --> URI Class Initialized
INFO - 2024-02-20 21:09:54 --> Router Class Initialized
INFO - 2024-02-20 21:09:54 --> Output Class Initialized
INFO - 2024-02-20 21:09:54 --> Security Class Initialized
DEBUG - 2024-02-20 21:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 21:09:54 --> Input Class Initialized
INFO - 2024-02-20 21:09:54 --> Language Class Initialized
INFO - 2024-02-20 21:09:54 --> Loader Class Initialized
INFO - 2024-02-20 21:09:54 --> Helper loaded: url_helper
INFO - 2024-02-20 21:09:54 --> Helper loaded: file_helper
INFO - 2024-02-20 21:09:54 --> Helper loaded: form_helper
INFO - 2024-02-20 21:09:54 --> Database Driver Class Initialized
DEBUG - 2024-02-20 21:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 21:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 21:09:54 --> Controller Class Initialized
INFO - 2024-02-20 21:09:54 --> Form Validation Class Initialized
INFO - 2024-02-20 21:09:54 --> Model "MasterModel" initialized
INFO - 2024-02-20 21:09:54 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 21:09:54 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 21:09:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 21:09:54 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 21:09:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 21:09:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 21:09:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 21:09:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 21:09:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 21:09:54 --> Final output sent to browser
DEBUG - 2024-02-20 21:09:54 --> Total execution time: 0.0507
ERROR - 2024-02-20 21:10:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 21:10:31 --> Config Class Initialized
INFO - 2024-02-20 21:10:31 --> Hooks Class Initialized
DEBUG - 2024-02-20 21:10:31 --> UTF-8 Support Enabled
INFO - 2024-02-20 21:10:31 --> Utf8 Class Initialized
INFO - 2024-02-20 21:10:31 --> URI Class Initialized
INFO - 2024-02-20 21:10:31 --> Router Class Initialized
INFO - 2024-02-20 21:10:31 --> Output Class Initialized
INFO - 2024-02-20 21:10:31 --> Security Class Initialized
DEBUG - 2024-02-20 21:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 21:10:31 --> Input Class Initialized
INFO - 2024-02-20 21:10:31 --> Language Class Initialized
INFO - 2024-02-20 21:10:31 --> Loader Class Initialized
INFO - 2024-02-20 21:10:31 --> Helper loaded: url_helper
INFO - 2024-02-20 21:10:31 --> Helper loaded: file_helper
INFO - 2024-02-20 21:10:31 --> Helper loaded: form_helper
INFO - 2024-02-20 21:10:31 --> Database Driver Class Initialized
DEBUG - 2024-02-20 21:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 21:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 21:10:31 --> Controller Class Initialized
INFO - 2024-02-20 21:10:31 --> Form Validation Class Initialized
INFO - 2024-02-20 21:10:31 --> Model "MasterModel" initialized
INFO - 2024-02-20 21:10:31 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 21:10:31 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 21:10:31 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 21:10:31 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 21:10:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 21:10:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 21:10:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 21:10:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 21:10:31 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/product_list.php
INFO - 2024-02-20 21:10:31 --> Final output sent to browser
DEBUG - 2024-02-20 21:10:31 --> Total execution time: 0.0523
ERROR - 2024-02-20 21:14:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 21:14:34 --> Config Class Initialized
INFO - 2024-02-20 21:14:34 --> Hooks Class Initialized
DEBUG - 2024-02-20 21:14:34 --> UTF-8 Support Enabled
INFO - 2024-02-20 21:14:34 --> Utf8 Class Initialized
INFO - 2024-02-20 21:14:34 --> URI Class Initialized
INFO - 2024-02-20 21:14:34 --> Router Class Initialized
INFO - 2024-02-20 21:14:34 --> Output Class Initialized
INFO - 2024-02-20 21:14:34 --> Security Class Initialized
DEBUG - 2024-02-20 21:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 21:14:34 --> Input Class Initialized
INFO - 2024-02-20 21:14:34 --> Language Class Initialized
INFO - 2024-02-20 21:14:34 --> Loader Class Initialized
INFO - 2024-02-20 21:14:34 --> Helper loaded: url_helper
INFO - 2024-02-20 21:14:34 --> Helper loaded: file_helper
INFO - 2024-02-20 21:14:34 --> Helper loaded: form_helper
INFO - 2024-02-20 21:14:34 --> Database Driver Class Initialized
DEBUG - 2024-02-20 21:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 21:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 21:14:34 --> Controller Class Initialized
INFO - 2024-02-20 21:14:34 --> Form Validation Class Initialized
INFO - 2024-02-20 21:14:34 --> Model "MasterModel" initialized
INFO - 2024-02-20 21:14:34 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 21:14:34 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 21:14:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 21:14:34 --> Model "ItemMasterModel" initialized
INFO - 2024-02-20 21:14:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-02-20 21:14:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-02-20 21:14:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-02-20 21:14:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-02-20 21:14:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/user_master/index.php
INFO - 2024-02-20 21:14:34 --> Final output sent to browser
DEBUG - 2024-02-20 21:14:34 --> Total execution time: 0.0537
ERROR - 2024-02-20 21:14:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2024-02-20 21:14:35 --> Config Class Initialized
INFO - 2024-02-20 21:14:35 --> Hooks Class Initialized
DEBUG - 2024-02-20 21:14:35 --> UTF-8 Support Enabled
INFO - 2024-02-20 21:14:35 --> Utf8 Class Initialized
INFO - 2024-02-20 21:14:35 --> URI Class Initialized
INFO - 2024-02-20 21:14:35 --> Router Class Initialized
INFO - 2024-02-20 21:14:35 --> Output Class Initialized
INFO - 2024-02-20 21:14:35 --> Security Class Initialized
DEBUG - 2024-02-20 21:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 21:14:35 --> Input Class Initialized
INFO - 2024-02-20 21:14:35 --> Language Class Initialized
INFO - 2024-02-20 21:14:35 --> Loader Class Initialized
INFO - 2024-02-20 21:14:35 --> Helper loaded: url_helper
INFO - 2024-02-20 21:14:35 --> Helper loaded: file_helper
INFO - 2024-02-20 21:14:35 --> Helper loaded: form_helper
INFO - 2024-02-20 21:14:35 --> Database Driver Class Initialized
DEBUG - 2024-02-20 21:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-20 21:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 21:14:35 --> Controller Class Initialized
INFO - 2024-02-20 21:14:35 --> Form Validation Class Initialized
INFO - 2024-02-20 21:14:35 --> Model "MasterModel" initialized
INFO - 2024-02-20 21:14:35 --> Model "UserMasterModel" initialized
INFO - 2024-02-20 21:14:35 --> Model "ItemGroupModel" initialized
INFO - 2024-02-20 21:14:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-02-20 21:14:35 --> Model "ItemMasterModel" initialized
