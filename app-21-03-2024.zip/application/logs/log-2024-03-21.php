<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-21 10:38:53 --> Config Class Initialized
INFO - 2024-03-21 10:38:53 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:38:53 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:38:53 --> Utf8 Class Initialized
INFO - 2024-03-21 10:38:53 --> URI Class Initialized
INFO - 2024-03-21 10:38:53 --> Router Class Initialized
INFO - 2024-03-21 10:38:53 --> Output Class Initialized
INFO - 2024-03-21 10:38:53 --> Security Class Initialized
DEBUG - 2024-03-21 10:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:38:53 --> Input Class Initialized
INFO - 2024-03-21 10:38:53 --> Language Class Initialized
INFO - 2024-03-21 10:38:53 --> Loader Class Initialized
INFO - 2024-03-21 10:38:53 --> Helper loaded: url_helper
INFO - 2024-03-21 10:38:53 --> Helper loaded: file_helper
INFO - 2024-03-21 10:38:53 --> Helper loaded: form_helper
INFO - 2024-03-21 10:38:53 --> Helper loaded: general_helper
INFO - 2024-03-21 10:38:53 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:38:53 --> Controller Class Initialized
INFO - 2024-03-21 10:38:53 --> Form Validation Class Initialized
INFO - 2024-03-21 10:38:53 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:38:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 10:38:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-21 10:38:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 10:38:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 10:38:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 10:38:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 10:38:53 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-21 10:38:53 --> Final output sent to browser
DEBUG - 2024-03-21 10:38:53 --> Total execution time: 0.0384
INFO - 2024-03-21 10:38:53 --> Config Class Initialized
INFO - 2024-03-21 10:38:53 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:38:53 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:38:53 --> Utf8 Class Initialized
INFO - 2024-03-21 10:38:53 --> URI Class Initialized
INFO - 2024-03-21 10:38:53 --> Router Class Initialized
INFO - 2024-03-21 10:38:53 --> Output Class Initialized
INFO - 2024-03-21 10:38:53 --> Security Class Initialized
DEBUG - 2024-03-21 10:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:38:53 --> Input Class Initialized
INFO - 2024-03-21 10:38:53 --> Language Class Initialized
INFO - 2024-03-21 10:38:53 --> Loader Class Initialized
INFO - 2024-03-21 10:38:53 --> Helper loaded: url_helper
INFO - 2024-03-21 10:38:53 --> Helper loaded: file_helper
INFO - 2024-03-21 10:38:53 --> Helper loaded: form_helper
INFO - 2024-03-21 10:38:53 --> Helper loaded: general_helper
INFO - 2024-03-21 10:38:53 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:38:53 --> Controller Class Initialized
INFO - 2024-03-21 10:38:53 --> Form Validation Class Initialized
INFO - 2024-03-21 10:38:53 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:38:53 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:45:34 --> Config Class Initialized
INFO - 2024-03-21 10:45:34 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:45:34 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:45:34 --> Utf8 Class Initialized
INFO - 2024-03-21 10:45:34 --> URI Class Initialized
INFO - 2024-03-21 10:45:34 --> Router Class Initialized
INFO - 2024-03-21 10:45:34 --> Output Class Initialized
INFO - 2024-03-21 10:45:34 --> Security Class Initialized
DEBUG - 2024-03-21 10:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:45:34 --> Input Class Initialized
INFO - 2024-03-21 10:45:34 --> Language Class Initialized
INFO - 2024-03-21 10:45:34 --> Loader Class Initialized
INFO - 2024-03-21 10:45:34 --> Helper loaded: url_helper
INFO - 2024-03-21 10:45:34 --> Helper loaded: file_helper
INFO - 2024-03-21 10:45:34 --> Helper loaded: form_helper
INFO - 2024-03-21 10:45:34 --> Helper loaded: general_helper
INFO - 2024-03-21 10:45:34 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:45:34 --> Controller Class Initialized
INFO - 2024-03-21 10:45:34 --> Form Validation Class Initialized
INFO - 2024-03-21 10:45:34 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 10:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 10:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 10:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 10:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 10:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-21 10:45:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-21 10:45:34 --> Final output sent to browser
DEBUG - 2024-03-21 10:45:34 --> Total execution time: 0.0404
INFO - 2024-03-21 10:45:34 --> Config Class Initialized
INFO - 2024-03-21 10:45:34 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:45:34 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:45:34 --> Utf8 Class Initialized
INFO - 2024-03-21 10:45:34 --> URI Class Initialized
INFO - 2024-03-21 10:45:34 --> Router Class Initialized
INFO - 2024-03-21 10:45:34 --> Output Class Initialized
INFO - 2024-03-21 10:45:34 --> Security Class Initialized
DEBUG - 2024-03-21 10:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:45:34 --> Input Class Initialized
INFO - 2024-03-21 10:45:34 --> Language Class Initialized
INFO - 2024-03-21 10:45:34 --> Loader Class Initialized
INFO - 2024-03-21 10:45:34 --> Helper loaded: url_helper
INFO - 2024-03-21 10:45:34 --> Helper loaded: file_helper
INFO - 2024-03-21 10:45:34 --> Helper loaded: form_helper
INFO - 2024-03-21 10:45:34 --> Helper loaded: general_helper
INFO - 2024-03-21 10:45:34 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:45:34 --> Controller Class Initialized
INFO - 2024-03-21 10:45:34 --> Form Validation Class Initialized
INFO - 2024-03-21 10:45:34 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:45:34 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:45:50 --> Config Class Initialized
INFO - 2024-03-21 10:45:50 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:45:50 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:45:50 --> Utf8 Class Initialized
INFO - 2024-03-21 10:45:50 --> URI Class Initialized
DEBUG - 2024-03-21 10:45:50 --> No URI present. Default controller set.
INFO - 2024-03-21 10:45:50 --> Router Class Initialized
INFO - 2024-03-21 10:45:50 --> Output Class Initialized
INFO - 2024-03-21 10:45:50 --> Security Class Initialized
DEBUG - 2024-03-21 10:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:45:50 --> Input Class Initialized
INFO - 2024-03-21 10:45:50 --> Language Class Initialized
INFO - 2024-03-21 10:45:50 --> Loader Class Initialized
INFO - 2024-03-21 10:45:50 --> Helper loaded: url_helper
INFO - 2024-03-21 10:45:50 --> Helper loaded: file_helper
INFO - 2024-03-21 10:45:50 --> Helper loaded: form_helper
INFO - 2024-03-21 10:45:50 --> Helper loaded: general_helper
INFO - 2024-03-21 10:45:50 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:45:50 --> Controller Class Initialized
INFO - 2024-03-21 10:45:50 --> Model "LoginModel" initialized
INFO - 2024-03-21 10:45:50 --> Form Validation Class Initialized
INFO - 2024-03-21 10:45:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/login.php
INFO - 2024-03-21 10:45:50 --> Final output sent to browser
DEBUG - 2024-03-21 10:45:50 --> Total execution time: 0.0268
INFO - 2024-03-21 10:45:58 --> Config Class Initialized
INFO - 2024-03-21 10:45:58 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:45:58 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:45:58 --> Utf8 Class Initialized
INFO - 2024-03-21 10:45:58 --> URI Class Initialized
INFO - 2024-03-21 10:45:58 --> Router Class Initialized
INFO - 2024-03-21 10:45:58 --> Output Class Initialized
INFO - 2024-03-21 10:45:58 --> Security Class Initialized
DEBUG - 2024-03-21 10:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:45:58 --> Input Class Initialized
INFO - 2024-03-21 10:45:58 --> Language Class Initialized
INFO - 2024-03-21 10:45:58 --> Loader Class Initialized
INFO - 2024-03-21 10:45:58 --> Helper loaded: url_helper
INFO - 2024-03-21 10:45:58 --> Helper loaded: file_helper
INFO - 2024-03-21 10:45:58 --> Helper loaded: form_helper
INFO - 2024-03-21 10:45:58 --> Helper loaded: general_helper
INFO - 2024-03-21 10:45:58 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:45:58 --> Controller Class Initialized
INFO - 2024-03-21 10:45:58 --> Model "LoginModel" initialized
INFO - 2024-03-21 10:45:58 --> Form Validation Class Initialized
INFO - 2024-03-21 10:45:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-03-21 10:45:58 --> Config Class Initialized
INFO - 2024-03-21 10:45:58 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:45:58 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:45:58 --> Utf8 Class Initialized
INFO - 2024-03-21 10:45:58 --> URI Class Initialized
INFO - 2024-03-21 10:45:58 --> Router Class Initialized
INFO - 2024-03-21 10:45:58 --> Output Class Initialized
INFO - 2024-03-21 10:45:58 --> Security Class Initialized
DEBUG - 2024-03-21 10:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:45:58 --> Input Class Initialized
INFO - 2024-03-21 10:45:58 --> Language Class Initialized
INFO - 2024-03-21 10:45:58 --> Loader Class Initialized
INFO - 2024-03-21 10:45:58 --> Helper loaded: url_helper
INFO - 2024-03-21 10:45:58 --> Helper loaded: file_helper
INFO - 2024-03-21 10:45:58 --> Helper loaded: form_helper
INFO - 2024-03-21 10:45:58 --> Helper loaded: general_helper
INFO - 2024-03-21 10:45:58 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:45:58 --> Controller Class Initialized
INFO - 2024-03-21 10:45:58 --> Form Validation Class Initialized
INFO - 2024-03-21 10:45:58 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:45:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 10:45:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-21 10:45:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-21 10:45:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 10:45:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 10:45:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 10:45:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-21 10:45:58 --> Final output sent to browser
DEBUG - 2024-03-21 10:45:58 --> Total execution time: 0.0244
INFO - 2024-03-21 10:45:58 --> Config Class Initialized
INFO - 2024-03-21 10:45:58 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:45:58 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:45:58 --> Utf8 Class Initialized
INFO - 2024-03-21 10:45:58 --> URI Class Initialized
INFO - 2024-03-21 10:45:58 --> Router Class Initialized
INFO - 2024-03-21 10:45:58 --> Output Class Initialized
INFO - 2024-03-21 10:45:58 --> Security Class Initialized
DEBUG - 2024-03-21 10:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:45:58 --> Input Class Initialized
INFO - 2024-03-21 10:45:58 --> Language Class Initialized
INFO - 2024-03-21 10:45:58 --> Loader Class Initialized
INFO - 2024-03-21 10:45:58 --> Helper loaded: url_helper
INFO - 2024-03-21 10:45:58 --> Helper loaded: file_helper
INFO - 2024-03-21 10:45:58 --> Helper loaded: form_helper
INFO - 2024-03-21 10:45:58 --> Helper loaded: general_helper
INFO - 2024-03-21 10:45:58 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:45:58 --> Controller Class Initialized
INFO - 2024-03-21 10:45:58 --> Form Validation Class Initialized
INFO - 2024-03-21 10:45:58 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:45:58 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:46:01 --> Config Class Initialized
INFO - 2024-03-21 10:46:01 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:46:01 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:46:01 --> Utf8 Class Initialized
INFO - 2024-03-21 10:46:01 --> URI Class Initialized
INFO - 2024-03-21 10:46:01 --> Router Class Initialized
INFO - 2024-03-21 10:46:01 --> Output Class Initialized
INFO - 2024-03-21 10:46:01 --> Security Class Initialized
DEBUG - 2024-03-21 10:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:46:01 --> Input Class Initialized
INFO - 2024-03-21 10:46:01 --> Language Class Initialized
INFO - 2024-03-21 10:46:01 --> Loader Class Initialized
INFO - 2024-03-21 10:46:01 --> Helper loaded: url_helper
INFO - 2024-03-21 10:46:01 --> Helper loaded: file_helper
INFO - 2024-03-21 10:46:01 --> Helper loaded: form_helper
INFO - 2024-03-21 10:46:01 --> Helper loaded: general_helper
INFO - 2024-03-21 10:46:01 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:46:01 --> Controller Class Initialized
INFO - 2024-03-21 10:46:01 --> Form Validation Class Initialized
INFO - 2024-03-21 10:46:01 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:46:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 10:46:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-21 10:46:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 10:46:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 10:46:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 10:46:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-21 10:46:01 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-21 10:46:01 --> Final output sent to browser
DEBUG - 2024-03-21 10:46:01 --> Total execution time: 0.0422
INFO - 2024-03-21 10:46:01 --> Config Class Initialized
INFO - 2024-03-21 10:46:01 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:46:01 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:46:01 --> Utf8 Class Initialized
INFO - 2024-03-21 10:46:01 --> URI Class Initialized
INFO - 2024-03-21 10:46:01 --> Router Class Initialized
INFO - 2024-03-21 10:46:01 --> Output Class Initialized
INFO - 2024-03-21 10:46:01 --> Security Class Initialized
DEBUG - 2024-03-21 10:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:46:01 --> Input Class Initialized
INFO - 2024-03-21 10:46:01 --> Language Class Initialized
INFO - 2024-03-21 10:46:01 --> Loader Class Initialized
INFO - 2024-03-21 10:46:01 --> Helper loaded: url_helper
INFO - 2024-03-21 10:46:01 --> Helper loaded: file_helper
INFO - 2024-03-21 10:46:01 --> Helper loaded: form_helper
INFO - 2024-03-21 10:46:01 --> Helper loaded: general_helper
INFO - 2024-03-21 10:46:01 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:46:01 --> Controller Class Initialized
INFO - 2024-03-21 10:46:01 --> Form Validation Class Initialized
INFO - 2024-03-21 10:46:01 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:46:01 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:48:51 --> Config Class Initialized
INFO - 2024-03-21 10:48:51 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:48:51 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:48:51 --> Utf8 Class Initialized
INFO - 2024-03-21 10:48:51 --> URI Class Initialized
INFO - 2024-03-21 10:48:51 --> Router Class Initialized
INFO - 2024-03-21 10:48:51 --> Output Class Initialized
INFO - 2024-03-21 10:48:51 --> Security Class Initialized
DEBUG - 2024-03-21 10:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:48:51 --> Input Class Initialized
INFO - 2024-03-21 10:48:51 --> Language Class Initialized
INFO - 2024-03-21 10:48:51 --> Loader Class Initialized
INFO - 2024-03-21 10:48:51 --> Helper loaded: url_helper
INFO - 2024-03-21 10:48:51 --> Helper loaded: file_helper
INFO - 2024-03-21 10:48:51 --> Helper loaded: form_helper
INFO - 2024-03-21 10:48:51 --> Helper loaded: general_helper
INFO - 2024-03-21 10:48:51 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:48:51 --> Controller Class Initialized
INFO - 2024-03-21 10:48:51 --> Form Validation Class Initialized
INFO - 2024-03-21 10:48:51 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:48:51 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:48:51 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:48:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:48:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:48:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:48:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:48:51 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:48:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:48:51 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:48:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 10:48:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-21 10:48:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 10:48:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 10:48:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 10:48:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-21 10:48:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-21 10:48:51 --> Final output sent to browser
DEBUG - 2024-03-21 10:48:51 --> Total execution time: 0.0429
INFO - 2024-03-21 10:48:52 --> Config Class Initialized
INFO - 2024-03-21 10:48:52 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:48:52 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:48:52 --> Utf8 Class Initialized
INFO - 2024-03-21 10:48:52 --> URI Class Initialized
INFO - 2024-03-21 10:48:52 --> Router Class Initialized
INFO - 2024-03-21 10:48:52 --> Output Class Initialized
INFO - 2024-03-21 10:48:52 --> Security Class Initialized
DEBUG - 2024-03-21 10:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:48:52 --> Input Class Initialized
INFO - 2024-03-21 10:48:52 --> Language Class Initialized
INFO - 2024-03-21 10:48:52 --> Loader Class Initialized
INFO - 2024-03-21 10:48:52 --> Helper loaded: url_helper
INFO - 2024-03-21 10:48:52 --> Helper loaded: file_helper
INFO - 2024-03-21 10:48:52 --> Helper loaded: form_helper
INFO - 2024-03-21 10:48:52 --> Helper loaded: general_helper
INFO - 2024-03-21 10:48:52 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:48:52 --> Controller Class Initialized
INFO - 2024-03-21 10:48:52 --> Form Validation Class Initialized
INFO - 2024-03-21 10:48:52 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:48:52 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:48:52 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:48:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:48:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:48:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:48:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:48:52 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:48:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:48:52 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:49:18 --> Config Class Initialized
INFO - 2024-03-21 10:49:18 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:49:18 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:49:18 --> Utf8 Class Initialized
INFO - 2024-03-21 10:49:18 --> URI Class Initialized
INFO - 2024-03-21 10:49:18 --> Router Class Initialized
INFO - 2024-03-21 10:49:18 --> Output Class Initialized
INFO - 2024-03-21 10:49:18 --> Security Class Initialized
DEBUG - 2024-03-21 10:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:49:18 --> Input Class Initialized
INFO - 2024-03-21 10:49:18 --> Language Class Initialized
INFO - 2024-03-21 10:49:18 --> Loader Class Initialized
INFO - 2024-03-21 10:49:18 --> Helper loaded: url_helper
INFO - 2024-03-21 10:49:18 --> Helper loaded: file_helper
INFO - 2024-03-21 10:49:18 --> Helper loaded: form_helper
INFO - 2024-03-21 10:49:18 --> Helper loaded: general_helper
INFO - 2024-03-21 10:49:18 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:49:18 --> Controller Class Initialized
INFO - 2024-03-21 10:49:18 --> Form Validation Class Initialized
INFO - 2024-03-21 10:49:18 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:49:18 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:49:18 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:49:18 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:49:18 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:49:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:49:18 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:49:18 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:49:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:49:18 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:49:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 10:49:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-21 10:49:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 10:49:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 10:49:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 10:49:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-21 10:49:18 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-21 10:49:18 --> Final output sent to browser
DEBUG - 2024-03-21 10:49:18 --> Total execution time: 0.0384
INFO - 2024-03-21 10:49:19 --> Config Class Initialized
INFO - 2024-03-21 10:49:19 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:49:19 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:49:19 --> Utf8 Class Initialized
INFO - 2024-03-21 10:49:19 --> URI Class Initialized
INFO - 2024-03-21 10:49:19 --> Router Class Initialized
INFO - 2024-03-21 10:49:19 --> Output Class Initialized
INFO - 2024-03-21 10:49:19 --> Config Class Initialized
INFO - 2024-03-21 10:49:19 --> Hooks Class Initialized
INFO - 2024-03-21 10:49:19 --> Security Class Initialized
DEBUG - 2024-03-21 10:49:19 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:49:19 --> Utf8 Class Initialized
DEBUG - 2024-03-21 10:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:49:19 --> Input Class Initialized
INFO - 2024-03-21 10:49:19 --> Language Class Initialized
INFO - 2024-03-21 10:49:19 --> URI Class Initialized
INFO - 2024-03-21 10:49:19 --> Router Class Initialized
INFO - 2024-03-21 10:49:19 --> Output Class Initialized
INFO - 2024-03-21 10:49:19 --> Loader Class Initialized
INFO - 2024-03-21 10:49:19 --> Security Class Initialized
INFO - 2024-03-21 10:49:19 --> Helper loaded: url_helper
INFO - 2024-03-21 10:49:19 --> Helper loaded: file_helper
DEBUG - 2024-03-21 10:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:49:19 --> Input Class Initialized
INFO - 2024-03-21 10:49:19 --> Language Class Initialized
INFO - 2024-03-21 10:49:19 --> Helper loaded: form_helper
INFO - 2024-03-21 10:49:19 --> Helper loaded: general_helper
INFO - 2024-03-21 10:49:19 --> Loader Class Initialized
INFO - 2024-03-21 10:49:19 --> Helper loaded: url_helper
INFO - 2024-03-21 10:49:19 --> Helper loaded: file_helper
INFO - 2024-03-21 10:49:19 --> Helper loaded: form_helper
INFO - 2024-03-21 10:49:19 --> Helper loaded: general_helper
INFO - 2024-03-21 10:49:19 --> Database Driver Class Initialized
INFO - 2024-03-21 10:49:19 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:49:19 --> Controller Class Initialized
DEBUG - 2024-03-21 10:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:49:19 --> Form Validation Class Initialized
INFO - 2024-03-21 10:49:19 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:49:19 --> Controller Class Initialized
INFO - 2024-03-21 10:49:19 --> Form Validation Class Initialized
INFO - 2024-03-21 10:49:19 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:49:19 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:49:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 10:49:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/kariger_sidebar.php
INFO - 2024-03-21 10:49:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 10:49:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 10:49:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 10:49:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-21 10:49:19 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-21 10:49:19 --> Final output sent to browser
DEBUG - 2024-03-21 10:49:19 --> Total execution time: 0.0611
INFO - 2024-03-21 10:49:21 --> Config Class Initialized
INFO - 2024-03-21 10:49:21 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:49:21 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:49:21 --> Utf8 Class Initialized
INFO - 2024-03-21 10:49:21 --> URI Class Initialized
INFO - 2024-03-21 10:49:21 --> Router Class Initialized
INFO - 2024-03-21 10:49:21 --> Output Class Initialized
INFO - 2024-03-21 10:49:21 --> Security Class Initialized
DEBUG - 2024-03-21 10:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:49:21 --> Input Class Initialized
INFO - 2024-03-21 10:49:21 --> Language Class Initialized
INFO - 2024-03-21 10:49:21 --> Loader Class Initialized
INFO - 2024-03-21 10:49:21 --> Helper loaded: url_helper
INFO - 2024-03-21 10:49:21 --> Helper loaded: file_helper
INFO - 2024-03-21 10:49:21 --> Helper loaded: form_helper
INFO - 2024-03-21 10:49:21 --> Helper loaded: general_helper
INFO - 2024-03-21 10:49:21 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:49:21 --> Controller Class Initialized
INFO - 2024-03-21 10:49:21 --> Form Validation Class Initialized
INFO - 2024-03-21 10:49:21 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:49:21 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:49:21 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:49:21 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:49:21 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:49:21 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:49:21 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:49:21 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:49:21 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:49:21 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:50:07 --> Config Class Initialized
INFO - 2024-03-21 10:50:07 --> Hooks Class Initialized
DEBUG - 2024-03-21 10:50:07 --> UTF-8 Support Enabled
INFO - 2024-03-21 10:50:07 --> Utf8 Class Initialized
INFO - 2024-03-21 10:50:07 --> URI Class Initialized
INFO - 2024-03-21 10:50:07 --> Router Class Initialized
INFO - 2024-03-21 10:50:07 --> Output Class Initialized
INFO - 2024-03-21 10:50:07 --> Security Class Initialized
DEBUG - 2024-03-21 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 10:50:07 --> Input Class Initialized
INFO - 2024-03-21 10:50:07 --> Language Class Initialized
INFO - 2024-03-21 10:50:07 --> Loader Class Initialized
INFO - 2024-03-21 10:50:07 --> Helper loaded: url_helper
INFO - 2024-03-21 10:50:07 --> Helper loaded: file_helper
INFO - 2024-03-21 10:50:07 --> Helper loaded: form_helper
INFO - 2024-03-21 10:50:07 --> Helper loaded: general_helper
INFO - 2024-03-21 10:50:07 --> Database Driver Class Initialized
DEBUG - 2024-03-21 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 10:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 10:50:07 --> Controller Class Initialized
INFO - 2024-03-21 10:50:07 --> Form Validation Class Initialized
INFO - 2024-03-21 10:50:07 --> Model "MasterModel" initialized
INFO - 2024-03-21 10:50:07 --> Model "NotificationModel" initialized
INFO - 2024-03-21 10:50:07 --> Model "DashboardModel" initialized
INFO - 2024-03-21 10:50:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 10:50:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 10:50:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 10:50:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 10:50:07 --> Model "OrderModel" initialized
INFO - 2024-03-21 10:50:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 10:50:07 --> Model "ReportModel" initialized
INFO - 2024-03-21 10:50:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-21 10:50:07 --> Final output sent to browser
DEBUG - 2024-03-21 10:50:07 --> Total execution time: 0.5786
INFO - 2024-03-21 11:23:28 --> Config Class Initialized
INFO - 2024-03-21 11:23:28 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:23:28 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:23:28 --> Utf8 Class Initialized
INFO - 2024-03-21 11:23:28 --> URI Class Initialized
INFO - 2024-03-21 11:23:28 --> Router Class Initialized
INFO - 2024-03-21 11:23:28 --> Output Class Initialized
INFO - 2024-03-21 11:23:28 --> Security Class Initialized
DEBUG - 2024-03-21 11:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:23:28 --> Input Class Initialized
INFO - 2024-03-21 11:23:28 --> Language Class Initialized
INFO - 2024-03-21 11:23:28 --> Loader Class Initialized
INFO - 2024-03-21 11:23:28 --> Helper loaded: url_helper
INFO - 2024-03-21 11:23:28 --> Helper loaded: file_helper
INFO - 2024-03-21 11:23:28 --> Helper loaded: form_helper
INFO - 2024-03-21 11:23:28 --> Helper loaded: general_helper
INFO - 2024-03-21 11:23:28 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:23:28 --> Controller Class Initialized
INFO - 2024-03-21 11:23:28 --> Form Validation Class Initialized
INFO - 2024-03-21 11:23:28 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:23:28 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:23:28 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:23:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:23:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:23:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:23:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:23:28 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:23:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:23:28 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:23:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:23:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-21 11:23:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:23:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:23:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:23:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:23:28 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-21 11:23:28 --> Final output sent to browser
DEBUG - 2024-03-21 11:23:28 --> Total execution time: 0.0345
INFO - 2024-03-21 11:23:28 --> Config Class Initialized
INFO - 2024-03-21 11:23:28 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:23:29 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:23:29 --> Utf8 Class Initialized
INFO - 2024-03-21 11:23:29 --> URI Class Initialized
INFO - 2024-03-21 11:23:29 --> Router Class Initialized
INFO - 2024-03-21 11:23:29 --> Output Class Initialized
INFO - 2024-03-21 11:23:29 --> Security Class Initialized
DEBUG - 2024-03-21 11:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:23:29 --> Input Class Initialized
INFO - 2024-03-21 11:23:29 --> Language Class Initialized
INFO - 2024-03-21 11:23:29 --> Loader Class Initialized
INFO - 2024-03-21 11:23:29 --> Helper loaded: url_helper
INFO - 2024-03-21 11:23:29 --> Helper loaded: file_helper
INFO - 2024-03-21 11:23:29 --> Helper loaded: form_helper
INFO - 2024-03-21 11:23:29 --> Helper loaded: general_helper
INFO - 2024-03-21 11:23:29 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:23:29 --> Controller Class Initialized
INFO - 2024-03-21 11:23:29 --> Form Validation Class Initialized
INFO - 2024-03-21 11:23:29 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:23:29 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:23:29 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:23:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:23:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:23:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:23:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:23:29 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:23:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:23:29 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:23:35 --> Config Class Initialized
INFO - 2024-03-21 11:23:35 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:23:35 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:23:35 --> Utf8 Class Initialized
INFO - 2024-03-21 11:23:35 --> URI Class Initialized
INFO - 2024-03-21 11:23:35 --> Router Class Initialized
INFO - 2024-03-21 11:23:35 --> Output Class Initialized
INFO - 2024-03-21 11:23:35 --> Security Class Initialized
DEBUG - 2024-03-21 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:23:35 --> Input Class Initialized
INFO - 2024-03-21 11:23:35 --> Language Class Initialized
INFO - 2024-03-21 11:23:35 --> Loader Class Initialized
INFO - 2024-03-21 11:23:35 --> Helper loaded: url_helper
INFO - 2024-03-21 11:23:35 --> Helper loaded: file_helper
INFO - 2024-03-21 11:23:35 --> Helper loaded: form_helper
INFO - 2024-03-21 11:23:35 --> Helper loaded: general_helper
INFO - 2024-03-21 11:23:35 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:23:35 --> Controller Class Initialized
INFO - 2024-03-21 11:23:35 --> Form Validation Class Initialized
INFO - 2024-03-21 11:23:35 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:23:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:23:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:23:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:23:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:23:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:23:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:23:35 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:23:35 --> Final output sent to browser
DEBUG - 2024-03-21 11:23:35 --> Total execution time: 0.0305
INFO - 2024-03-21 11:23:35 --> Config Class Initialized
INFO - 2024-03-21 11:23:35 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:23:35 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:23:35 --> Utf8 Class Initialized
INFO - 2024-03-21 11:23:35 --> URI Class Initialized
INFO - 2024-03-21 11:23:35 --> Router Class Initialized
INFO - 2024-03-21 11:23:35 --> Output Class Initialized
INFO - 2024-03-21 11:23:35 --> Security Class Initialized
DEBUG - 2024-03-21 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:23:35 --> Input Class Initialized
INFO - 2024-03-21 11:23:35 --> Language Class Initialized
INFO - 2024-03-21 11:23:35 --> Loader Class Initialized
INFO - 2024-03-21 11:23:35 --> Helper loaded: url_helper
INFO - 2024-03-21 11:23:35 --> Helper loaded: file_helper
INFO - 2024-03-21 11:23:35 --> Helper loaded: form_helper
INFO - 2024-03-21 11:23:35 --> Helper loaded: general_helper
INFO - 2024-03-21 11:23:35 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:23:35 --> Controller Class Initialized
INFO - 2024-03-21 11:23:35 --> Form Validation Class Initialized
INFO - 2024-03-21 11:23:35 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:23:35 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:23:39 --> Config Class Initialized
INFO - 2024-03-21 11:23:39 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:23:39 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:23:39 --> Utf8 Class Initialized
INFO - 2024-03-21 11:23:39 --> URI Class Initialized
INFO - 2024-03-21 11:23:39 --> Router Class Initialized
INFO - 2024-03-21 11:23:39 --> Output Class Initialized
INFO - 2024-03-21 11:23:39 --> Security Class Initialized
DEBUG - 2024-03-21 11:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:23:39 --> Input Class Initialized
INFO - 2024-03-21 11:23:39 --> Language Class Initialized
INFO - 2024-03-21 11:23:39 --> Loader Class Initialized
INFO - 2024-03-21 11:23:39 --> Helper loaded: url_helper
INFO - 2024-03-21 11:23:39 --> Helper loaded: file_helper
INFO - 2024-03-21 11:23:39 --> Helper loaded: form_helper
INFO - 2024-03-21 11:23:39 --> Helper loaded: general_helper
INFO - 2024-03-21 11:23:39 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:23:39 --> Controller Class Initialized
INFO - 2024-03-21 11:23:39 --> Form Validation Class Initialized
INFO - 2024-03-21 11:23:39 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:23:39 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:23:39 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:23:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:23:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:23:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:23:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:23:39 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:23:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:23:39 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:29:14 --> Config Class Initialized
INFO - 2024-03-21 11:29:14 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:29:14 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:29:14 --> Utf8 Class Initialized
INFO - 2024-03-21 11:29:14 --> URI Class Initialized
INFO - 2024-03-21 11:29:14 --> Router Class Initialized
INFO - 2024-03-21 11:29:14 --> Output Class Initialized
INFO - 2024-03-21 11:29:14 --> Security Class Initialized
DEBUG - 2024-03-21 11:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:29:14 --> Input Class Initialized
INFO - 2024-03-21 11:29:14 --> Language Class Initialized
INFO - 2024-03-21 11:29:14 --> Loader Class Initialized
INFO - 2024-03-21 11:29:14 --> Helper loaded: url_helper
INFO - 2024-03-21 11:29:14 --> Helper loaded: file_helper
INFO - 2024-03-21 11:29:14 --> Helper loaded: form_helper
INFO - 2024-03-21 11:29:14 --> Helper loaded: general_helper
INFO - 2024-03-21 11:29:14 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:29:14 --> Controller Class Initialized
INFO - 2024-03-21 11:29:14 --> Form Validation Class Initialized
INFO - 2024-03-21 11:29:14 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:29:14 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:29:14 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:29:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:29:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:29:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:29:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:29:14 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:29:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:29:14 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:29:17 --> Config Class Initialized
INFO - 2024-03-21 11:29:17 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:29:17 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:29:17 --> Utf8 Class Initialized
INFO - 2024-03-21 11:29:17 --> URI Class Initialized
INFO - 2024-03-21 11:29:17 --> Router Class Initialized
INFO - 2024-03-21 11:29:17 --> Output Class Initialized
INFO - 2024-03-21 11:29:17 --> Security Class Initialized
DEBUG - 2024-03-21 11:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:29:17 --> Input Class Initialized
INFO - 2024-03-21 11:29:17 --> Language Class Initialized
INFO - 2024-03-21 11:29:17 --> Loader Class Initialized
INFO - 2024-03-21 11:29:17 --> Helper loaded: url_helper
INFO - 2024-03-21 11:29:17 --> Helper loaded: file_helper
INFO - 2024-03-21 11:29:17 --> Helper loaded: form_helper
INFO - 2024-03-21 11:29:17 --> Helper loaded: general_helper
INFO - 2024-03-21 11:29:17 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:29:17 --> Controller Class Initialized
INFO - 2024-03-21 11:29:17 --> Form Validation Class Initialized
INFO - 2024-03-21 11:29:17 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:29:17 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:29:17 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:29:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:29:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:29:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:29:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:29:17 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:29:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:29:17 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:29:20 --> Config Class Initialized
INFO - 2024-03-21 11:29:20 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:29:20 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:29:20 --> Utf8 Class Initialized
INFO - 2024-03-21 11:29:20 --> URI Class Initialized
INFO - 2024-03-21 11:29:20 --> Router Class Initialized
INFO - 2024-03-21 11:29:20 --> Output Class Initialized
INFO - 2024-03-21 11:29:20 --> Security Class Initialized
DEBUG - 2024-03-21 11:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:29:20 --> Input Class Initialized
INFO - 2024-03-21 11:29:20 --> Language Class Initialized
INFO - 2024-03-21 11:29:20 --> Loader Class Initialized
INFO - 2024-03-21 11:29:20 --> Helper loaded: url_helper
INFO - 2024-03-21 11:29:20 --> Helper loaded: file_helper
INFO - 2024-03-21 11:29:20 --> Helper loaded: form_helper
INFO - 2024-03-21 11:29:20 --> Helper loaded: general_helper
INFO - 2024-03-21 11:29:20 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:29:20 --> Controller Class Initialized
INFO - 2024-03-21 11:29:20 --> Form Validation Class Initialized
INFO - 2024-03-21 11:29:20 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:29:20 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:29:20 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:29:20 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:29:20 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:29:20 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:29:20 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:29:20 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:29:20 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:29:20 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:30:45 --> Config Class Initialized
INFO - 2024-03-21 11:30:45 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:30:45 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:30:45 --> Utf8 Class Initialized
INFO - 2024-03-21 11:30:45 --> URI Class Initialized
INFO - 2024-03-21 11:30:45 --> Router Class Initialized
INFO - 2024-03-21 11:30:45 --> Output Class Initialized
INFO - 2024-03-21 11:30:45 --> Security Class Initialized
DEBUG - 2024-03-21 11:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:30:45 --> Input Class Initialized
INFO - 2024-03-21 11:30:45 --> Language Class Initialized
INFO - 2024-03-21 11:30:45 --> Loader Class Initialized
INFO - 2024-03-21 11:30:45 --> Helper loaded: url_helper
INFO - 2024-03-21 11:30:45 --> Helper loaded: file_helper
INFO - 2024-03-21 11:30:45 --> Helper loaded: form_helper
INFO - 2024-03-21 11:30:45 --> Helper loaded: general_helper
INFO - 2024-03-21 11:30:45 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:30:45 --> Controller Class Initialized
INFO - 2024-03-21 11:30:45 --> Form Validation Class Initialized
INFO - 2024-03-21 11:30:45 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:30:45 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:30:45 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:30:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:30:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:30:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:30:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:30:45 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:30:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:30:45 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:30:54 --> Config Class Initialized
INFO - 2024-03-21 11:30:54 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:30:54 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:30:54 --> Utf8 Class Initialized
INFO - 2024-03-21 11:30:54 --> URI Class Initialized
INFO - 2024-03-21 11:30:54 --> Router Class Initialized
INFO - 2024-03-21 11:30:54 --> Output Class Initialized
INFO - 2024-03-21 11:30:54 --> Security Class Initialized
DEBUG - 2024-03-21 11:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:30:54 --> Input Class Initialized
INFO - 2024-03-21 11:30:54 --> Language Class Initialized
INFO - 2024-03-21 11:30:54 --> Loader Class Initialized
INFO - 2024-03-21 11:30:54 --> Helper loaded: url_helper
INFO - 2024-03-21 11:30:54 --> Helper loaded: file_helper
INFO - 2024-03-21 11:30:54 --> Helper loaded: form_helper
INFO - 2024-03-21 11:30:54 --> Helper loaded: general_helper
INFO - 2024-03-21 11:30:54 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:30:54 --> Controller Class Initialized
INFO - 2024-03-21 11:30:54 --> Form Validation Class Initialized
INFO - 2024-03-21 11:30:54 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:30:54 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:30:54 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:30:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:30:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:30:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:30:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:30:54 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:30:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:30:54 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:30:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:30:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:30:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:30:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:30:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:30:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:30:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:30:54 --> Final output sent to browser
DEBUG - 2024-03-21 11:30:54 --> Total execution time: 0.0350
INFO - 2024-03-21 11:31:43 --> Config Class Initialized
INFO - 2024-03-21 11:31:43 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:31:43 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:31:43 --> Utf8 Class Initialized
INFO - 2024-03-21 11:31:43 --> URI Class Initialized
INFO - 2024-03-21 11:31:43 --> Router Class Initialized
INFO - 2024-03-21 11:31:43 --> Output Class Initialized
INFO - 2024-03-21 11:31:43 --> Security Class Initialized
DEBUG - 2024-03-21 11:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:31:43 --> Input Class Initialized
INFO - 2024-03-21 11:31:43 --> Language Class Initialized
INFO - 2024-03-21 11:31:43 --> Loader Class Initialized
INFO - 2024-03-21 11:31:43 --> Helper loaded: url_helper
INFO - 2024-03-21 11:31:43 --> Helper loaded: file_helper
INFO - 2024-03-21 11:31:43 --> Helper loaded: form_helper
INFO - 2024-03-21 11:31:43 --> Helper loaded: general_helper
INFO - 2024-03-21 11:31:43 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:31:43 --> Controller Class Initialized
INFO - 2024-03-21 11:31:43 --> Form Validation Class Initialized
INFO - 2024-03-21 11:31:43 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:31:43 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:31:43 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:31:43 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:31:43 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:31:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:31:43 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:31:43 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:31:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:31:43 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:31:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:31:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:31:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:31:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:31:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:31:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:31:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:31:43 --> Final output sent to browser
DEBUG - 2024-03-21 11:31:43 --> Total execution time: 0.0417
INFO - 2024-03-21 11:31:44 --> Config Class Initialized
INFO - 2024-03-21 11:31:44 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:31:44 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:31:44 --> Utf8 Class Initialized
INFO - 2024-03-21 11:31:44 --> URI Class Initialized
INFO - 2024-03-21 11:31:44 --> Router Class Initialized
INFO - 2024-03-21 11:31:44 --> Output Class Initialized
INFO - 2024-03-21 11:31:44 --> Security Class Initialized
DEBUG - 2024-03-21 11:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:31:44 --> Input Class Initialized
INFO - 2024-03-21 11:31:44 --> Language Class Initialized
INFO - 2024-03-21 11:31:44 --> Loader Class Initialized
INFO - 2024-03-21 11:31:44 --> Helper loaded: url_helper
INFO - 2024-03-21 11:31:44 --> Helper loaded: file_helper
INFO - 2024-03-21 11:31:44 --> Helper loaded: form_helper
INFO - 2024-03-21 11:31:44 --> Helper loaded: general_helper
INFO - 2024-03-21 11:31:44 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:31:44 --> Controller Class Initialized
INFO - 2024-03-21 11:31:44 --> Form Validation Class Initialized
INFO - 2024-03-21 11:31:44 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:31:44 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:31:44 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:31:44 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:31:44 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:31:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:31:44 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:31:44 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:31:44 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:31:44 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:32:51 --> Config Class Initialized
INFO - 2024-03-21 11:32:51 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:32:51 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:32:51 --> Utf8 Class Initialized
INFO - 2024-03-21 11:32:51 --> URI Class Initialized
INFO - 2024-03-21 11:32:51 --> Router Class Initialized
INFO - 2024-03-21 11:32:51 --> Output Class Initialized
INFO - 2024-03-21 11:32:51 --> Security Class Initialized
DEBUG - 2024-03-21 11:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:32:51 --> Input Class Initialized
INFO - 2024-03-21 11:32:51 --> Language Class Initialized
INFO - 2024-03-21 11:32:51 --> Loader Class Initialized
INFO - 2024-03-21 11:32:51 --> Helper loaded: url_helper
INFO - 2024-03-21 11:32:51 --> Helper loaded: file_helper
INFO - 2024-03-21 11:32:51 --> Helper loaded: form_helper
INFO - 2024-03-21 11:32:51 --> Helper loaded: general_helper
INFO - 2024-03-21 11:32:51 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:32:51 --> Controller Class Initialized
INFO - 2024-03-21 11:32:51 --> Form Validation Class Initialized
INFO - 2024-03-21 11:32:51 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:32:51 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:32:51 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:32:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:32:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:32:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:32:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:32:51 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:32:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:32:51 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:32:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:32:51 --> Final output sent to browser
DEBUG - 2024-03-21 11:32:51 --> Total execution time: 0.0379
INFO - 2024-03-21 11:32:52 --> Config Class Initialized
INFO - 2024-03-21 11:32:52 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:32:52 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:32:52 --> Utf8 Class Initialized
INFO - 2024-03-21 11:32:52 --> URI Class Initialized
INFO - 2024-03-21 11:32:52 --> Router Class Initialized
INFO - 2024-03-21 11:32:52 --> Output Class Initialized
INFO - 2024-03-21 11:32:52 --> Security Class Initialized
DEBUG - 2024-03-21 11:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:32:52 --> Input Class Initialized
INFO - 2024-03-21 11:32:52 --> Language Class Initialized
INFO - 2024-03-21 11:32:52 --> Loader Class Initialized
INFO - 2024-03-21 11:32:52 --> Helper loaded: url_helper
INFO - 2024-03-21 11:32:52 --> Helper loaded: file_helper
INFO - 2024-03-21 11:32:52 --> Helper loaded: form_helper
INFO - 2024-03-21 11:32:52 --> Helper loaded: general_helper
INFO - 2024-03-21 11:32:52 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:32:52 --> Controller Class Initialized
INFO - 2024-03-21 11:32:52 --> Form Validation Class Initialized
INFO - 2024-03-21 11:32:52 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:32:52 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:32:52 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:32:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:32:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:32:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:32:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:32:52 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:32:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:32:52 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:33:06 --> Config Class Initialized
INFO - 2024-03-21 11:33:06 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:33:06 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:33:06 --> Utf8 Class Initialized
INFO - 2024-03-21 11:33:06 --> URI Class Initialized
INFO - 2024-03-21 11:33:06 --> Router Class Initialized
INFO - 2024-03-21 11:33:06 --> Output Class Initialized
INFO - 2024-03-21 11:33:06 --> Security Class Initialized
DEBUG - 2024-03-21 11:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:33:06 --> Input Class Initialized
INFO - 2024-03-21 11:33:06 --> Language Class Initialized
INFO - 2024-03-21 11:33:06 --> Loader Class Initialized
INFO - 2024-03-21 11:33:06 --> Helper loaded: url_helper
INFO - 2024-03-21 11:33:06 --> Helper loaded: file_helper
INFO - 2024-03-21 11:33:06 --> Helper loaded: form_helper
INFO - 2024-03-21 11:33:06 --> Helper loaded: general_helper
INFO - 2024-03-21 11:33:06 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:33:06 --> Controller Class Initialized
INFO - 2024-03-21 11:33:06 --> Form Validation Class Initialized
INFO - 2024-03-21 11:33:06 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:33:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:33:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:33:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:33:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:33:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:33:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:33:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:33:06 --> Final output sent to browser
DEBUG - 2024-03-21 11:33:06 --> Total execution time: 0.0501
INFO - 2024-03-21 11:33:06 --> Config Class Initialized
INFO - 2024-03-21 11:33:06 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:33:06 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:33:06 --> Utf8 Class Initialized
INFO - 2024-03-21 11:33:06 --> URI Class Initialized
INFO - 2024-03-21 11:33:06 --> Router Class Initialized
INFO - 2024-03-21 11:33:06 --> Output Class Initialized
INFO - 2024-03-21 11:33:06 --> Security Class Initialized
DEBUG - 2024-03-21 11:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:33:06 --> Input Class Initialized
INFO - 2024-03-21 11:33:06 --> Language Class Initialized
INFO - 2024-03-21 11:33:06 --> Loader Class Initialized
INFO - 2024-03-21 11:33:06 --> Helper loaded: url_helper
INFO - 2024-03-21 11:33:06 --> Helper loaded: file_helper
INFO - 2024-03-21 11:33:06 --> Helper loaded: form_helper
INFO - 2024-03-21 11:33:06 --> Helper loaded: general_helper
INFO - 2024-03-21 11:33:06 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:33:06 --> Controller Class Initialized
INFO - 2024-03-21 11:33:06 --> Form Validation Class Initialized
INFO - 2024-03-21 11:33:06 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:33:06 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:33:17 --> Config Class Initialized
INFO - 2024-03-21 11:33:17 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:33:17 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:33:17 --> Utf8 Class Initialized
INFO - 2024-03-21 11:33:17 --> URI Class Initialized
INFO - 2024-03-21 11:33:17 --> Router Class Initialized
INFO - 2024-03-21 11:33:17 --> Output Class Initialized
INFO - 2024-03-21 11:33:17 --> Security Class Initialized
DEBUG - 2024-03-21 11:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:33:17 --> Input Class Initialized
INFO - 2024-03-21 11:33:17 --> Language Class Initialized
INFO - 2024-03-21 11:33:17 --> Loader Class Initialized
INFO - 2024-03-21 11:33:17 --> Helper loaded: url_helper
INFO - 2024-03-21 11:33:17 --> Helper loaded: file_helper
INFO - 2024-03-21 11:33:17 --> Helper loaded: form_helper
INFO - 2024-03-21 11:33:17 --> Helper loaded: general_helper
INFO - 2024-03-21 11:33:17 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:33:17 --> Controller Class Initialized
INFO - 2024-03-21 11:33:17 --> Form Validation Class Initialized
INFO - 2024-03-21 11:33:17 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:33:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:33:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:33:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:33:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:33:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:33:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:33:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:33:17 --> Final output sent to browser
DEBUG - 2024-03-21 11:33:17 --> Total execution time: 0.0398
INFO - 2024-03-21 11:33:17 --> Config Class Initialized
INFO - 2024-03-21 11:33:17 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:33:17 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:33:17 --> Utf8 Class Initialized
INFO - 2024-03-21 11:33:17 --> URI Class Initialized
INFO - 2024-03-21 11:33:17 --> Router Class Initialized
INFO - 2024-03-21 11:33:17 --> Output Class Initialized
INFO - 2024-03-21 11:33:17 --> Security Class Initialized
DEBUG - 2024-03-21 11:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:33:17 --> Input Class Initialized
INFO - 2024-03-21 11:33:17 --> Language Class Initialized
INFO - 2024-03-21 11:33:17 --> Loader Class Initialized
INFO - 2024-03-21 11:33:17 --> Helper loaded: url_helper
INFO - 2024-03-21 11:33:17 --> Helper loaded: file_helper
INFO - 2024-03-21 11:33:17 --> Helper loaded: form_helper
INFO - 2024-03-21 11:33:17 --> Helper loaded: general_helper
INFO - 2024-03-21 11:33:17 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:33:17 --> Controller Class Initialized
INFO - 2024-03-21 11:33:17 --> Form Validation Class Initialized
INFO - 2024-03-21 11:33:17 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:33:17 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:33:25 --> Config Class Initialized
INFO - 2024-03-21 11:33:25 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:33:25 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:33:25 --> Utf8 Class Initialized
INFO - 2024-03-21 11:33:25 --> URI Class Initialized
INFO - 2024-03-21 11:33:25 --> Router Class Initialized
INFO - 2024-03-21 11:33:25 --> Output Class Initialized
INFO - 2024-03-21 11:33:25 --> Security Class Initialized
DEBUG - 2024-03-21 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:33:25 --> Input Class Initialized
INFO - 2024-03-21 11:33:25 --> Language Class Initialized
INFO - 2024-03-21 11:33:25 --> Loader Class Initialized
INFO - 2024-03-21 11:33:25 --> Helper loaded: url_helper
INFO - 2024-03-21 11:33:25 --> Helper loaded: file_helper
INFO - 2024-03-21 11:33:25 --> Helper loaded: form_helper
INFO - 2024-03-21 11:33:25 --> Helper loaded: general_helper
INFO - 2024-03-21 11:33:25 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:33:25 --> Controller Class Initialized
INFO - 2024-03-21 11:33:25 --> Form Validation Class Initialized
INFO - 2024-03-21 11:33:25 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:33:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:33:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:33:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:33:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:33:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:33:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:33:25 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:33:25 --> Final output sent to browser
DEBUG - 2024-03-21 11:33:25 --> Total execution time: 0.0363
INFO - 2024-03-21 11:33:25 --> Config Class Initialized
INFO - 2024-03-21 11:33:25 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:33:25 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:33:25 --> Utf8 Class Initialized
INFO - 2024-03-21 11:33:25 --> URI Class Initialized
INFO - 2024-03-21 11:33:25 --> Router Class Initialized
INFO - 2024-03-21 11:33:25 --> Output Class Initialized
INFO - 2024-03-21 11:33:25 --> Security Class Initialized
DEBUG - 2024-03-21 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:33:25 --> Input Class Initialized
INFO - 2024-03-21 11:33:25 --> Language Class Initialized
INFO - 2024-03-21 11:33:25 --> Loader Class Initialized
INFO - 2024-03-21 11:33:25 --> Helper loaded: url_helper
INFO - 2024-03-21 11:33:25 --> Helper loaded: file_helper
INFO - 2024-03-21 11:33:25 --> Helper loaded: form_helper
INFO - 2024-03-21 11:33:25 --> Helper loaded: general_helper
INFO - 2024-03-21 11:33:25 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:33:25 --> Controller Class Initialized
INFO - 2024-03-21 11:33:25 --> Form Validation Class Initialized
INFO - 2024-03-21 11:33:25 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:33:25 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:36:36 --> Config Class Initialized
INFO - 2024-03-21 11:36:36 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:36:36 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:36:36 --> Utf8 Class Initialized
INFO - 2024-03-21 11:36:36 --> URI Class Initialized
INFO - 2024-03-21 11:36:36 --> Router Class Initialized
INFO - 2024-03-21 11:36:36 --> Output Class Initialized
INFO - 2024-03-21 11:36:36 --> Security Class Initialized
DEBUG - 2024-03-21 11:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:36:36 --> Input Class Initialized
INFO - 2024-03-21 11:36:36 --> Language Class Initialized
INFO - 2024-03-21 11:36:36 --> Loader Class Initialized
INFO - 2024-03-21 11:36:36 --> Helper loaded: url_helper
INFO - 2024-03-21 11:36:36 --> Helper loaded: file_helper
INFO - 2024-03-21 11:36:36 --> Helper loaded: form_helper
INFO - 2024-03-21 11:36:36 --> Helper loaded: general_helper
INFO - 2024-03-21 11:36:36 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:36:36 --> Controller Class Initialized
INFO - 2024-03-21 11:36:36 --> Form Validation Class Initialized
INFO - 2024-03-21 11:36:36 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:36:36 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:36:36 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:36:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:36:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:36:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:36:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:36:36 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:36:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:36:36 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:36:36 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:36:36 --> Final output sent to browser
DEBUG - 2024-03-21 11:36:36 --> Total execution time: 0.0402
INFO - 2024-03-21 11:36:37 --> Config Class Initialized
INFO - 2024-03-21 11:36:37 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:36:37 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:36:37 --> Utf8 Class Initialized
INFO - 2024-03-21 11:36:37 --> URI Class Initialized
INFO - 2024-03-21 11:36:37 --> Router Class Initialized
INFO - 2024-03-21 11:36:37 --> Output Class Initialized
INFO - 2024-03-21 11:36:37 --> Security Class Initialized
DEBUG - 2024-03-21 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:36:37 --> Input Class Initialized
INFO - 2024-03-21 11:36:37 --> Language Class Initialized
INFO - 2024-03-21 11:36:37 --> Loader Class Initialized
INFO - 2024-03-21 11:36:37 --> Helper loaded: url_helper
INFO - 2024-03-21 11:36:37 --> Helper loaded: file_helper
INFO - 2024-03-21 11:36:37 --> Helper loaded: form_helper
INFO - 2024-03-21 11:36:37 --> Helper loaded: general_helper
INFO - 2024-03-21 11:36:37 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:36:37 --> Controller Class Initialized
INFO - 2024-03-21 11:36:37 --> Form Validation Class Initialized
INFO - 2024-03-21 11:36:37 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:36:37 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:36:37 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:36:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:36:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:36:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:36:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:36:37 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:36:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:36:37 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:36:55 --> Config Class Initialized
INFO - 2024-03-21 11:36:55 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:36:55 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:36:55 --> Utf8 Class Initialized
INFO - 2024-03-21 11:36:55 --> URI Class Initialized
INFO - 2024-03-21 11:36:55 --> Router Class Initialized
INFO - 2024-03-21 11:36:55 --> Output Class Initialized
INFO - 2024-03-21 11:36:55 --> Security Class Initialized
DEBUG - 2024-03-21 11:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:36:55 --> Input Class Initialized
INFO - 2024-03-21 11:36:55 --> Language Class Initialized
INFO - 2024-03-21 11:36:55 --> Loader Class Initialized
INFO - 2024-03-21 11:36:55 --> Helper loaded: url_helper
INFO - 2024-03-21 11:36:55 --> Helper loaded: file_helper
INFO - 2024-03-21 11:36:55 --> Helper loaded: form_helper
INFO - 2024-03-21 11:36:55 --> Helper loaded: general_helper
INFO - 2024-03-21 11:36:55 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:36:55 --> Controller Class Initialized
INFO - 2024-03-21 11:36:55 --> Form Validation Class Initialized
INFO - 2024-03-21 11:36:55 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:36:55 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:36:55 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:36:55 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:36:55 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:36:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:36:55 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:36:55 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:36:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:36:55 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:36:55 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:36:55 --> Final output sent to browser
DEBUG - 2024-03-21 11:36:55 --> Total execution time: 0.0404
INFO - 2024-03-21 11:36:56 --> Config Class Initialized
INFO - 2024-03-21 11:36:56 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:36:56 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:36:56 --> Utf8 Class Initialized
INFO - 2024-03-21 11:36:56 --> URI Class Initialized
INFO - 2024-03-21 11:36:56 --> Router Class Initialized
INFO - 2024-03-21 11:36:56 --> Output Class Initialized
INFO - 2024-03-21 11:36:56 --> Security Class Initialized
DEBUG - 2024-03-21 11:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:36:56 --> Input Class Initialized
INFO - 2024-03-21 11:36:56 --> Language Class Initialized
INFO - 2024-03-21 11:36:56 --> Loader Class Initialized
INFO - 2024-03-21 11:36:56 --> Helper loaded: url_helper
INFO - 2024-03-21 11:36:56 --> Helper loaded: file_helper
INFO - 2024-03-21 11:36:56 --> Helper loaded: form_helper
INFO - 2024-03-21 11:36:56 --> Helper loaded: general_helper
INFO - 2024-03-21 11:36:56 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:36:56 --> Controller Class Initialized
INFO - 2024-03-21 11:36:56 --> Form Validation Class Initialized
INFO - 2024-03-21 11:36:56 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:36:56 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:36:56 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:36:56 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:36:56 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:36:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:36:56 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:36:56 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:36:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:36:56 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:37:08 --> Config Class Initialized
INFO - 2024-03-21 11:37:08 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:37:08 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:37:08 --> Utf8 Class Initialized
INFO - 2024-03-21 11:37:08 --> URI Class Initialized
INFO - 2024-03-21 11:37:08 --> Router Class Initialized
INFO - 2024-03-21 11:37:08 --> Output Class Initialized
INFO - 2024-03-21 11:37:08 --> Security Class Initialized
DEBUG - 2024-03-21 11:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:37:08 --> Input Class Initialized
INFO - 2024-03-21 11:37:08 --> Language Class Initialized
INFO - 2024-03-21 11:37:08 --> Loader Class Initialized
INFO - 2024-03-21 11:37:08 --> Helper loaded: url_helper
INFO - 2024-03-21 11:37:08 --> Helper loaded: file_helper
INFO - 2024-03-21 11:37:08 --> Helper loaded: form_helper
INFO - 2024-03-21 11:37:08 --> Helper loaded: general_helper
INFO - 2024-03-21 11:37:08 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:37:08 --> Controller Class Initialized
INFO - 2024-03-21 11:37:08 --> Form Validation Class Initialized
INFO - 2024-03-21 11:37:08 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:37:08 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:37:08 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:37:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:37:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:37:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:37:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:37:08 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:37:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:37:08 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:37:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:37:08 --> Final output sent to browser
DEBUG - 2024-03-21 11:37:08 --> Total execution time: 0.0354
INFO - 2024-03-21 11:37:56 --> Config Class Initialized
INFO - 2024-03-21 11:37:56 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:37:56 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:37:56 --> Utf8 Class Initialized
INFO - 2024-03-21 11:37:56 --> URI Class Initialized
INFO - 2024-03-21 11:37:56 --> Router Class Initialized
INFO - 2024-03-21 11:37:56 --> Output Class Initialized
INFO - 2024-03-21 11:37:56 --> Security Class Initialized
DEBUG - 2024-03-21 11:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:37:56 --> Input Class Initialized
INFO - 2024-03-21 11:37:56 --> Language Class Initialized
INFO - 2024-03-21 11:37:56 --> Loader Class Initialized
INFO - 2024-03-21 11:37:56 --> Helper loaded: url_helper
INFO - 2024-03-21 11:37:56 --> Helper loaded: file_helper
INFO - 2024-03-21 11:37:56 --> Helper loaded: form_helper
INFO - 2024-03-21 11:37:56 --> Helper loaded: general_helper
INFO - 2024-03-21 11:37:56 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:37:56 --> Controller Class Initialized
INFO - 2024-03-21 11:37:56 --> Form Validation Class Initialized
INFO - 2024-03-21 11:37:56 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:37:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:37:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:37:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:37:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:37:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:37:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:37:56 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:37:56 --> Final output sent to browser
DEBUG - 2024-03-21 11:37:56 --> Total execution time: 0.0361
INFO - 2024-03-21 11:37:56 --> Config Class Initialized
INFO - 2024-03-21 11:37:56 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:37:56 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:37:56 --> Utf8 Class Initialized
INFO - 2024-03-21 11:37:56 --> URI Class Initialized
INFO - 2024-03-21 11:37:56 --> Router Class Initialized
INFO - 2024-03-21 11:37:56 --> Output Class Initialized
INFO - 2024-03-21 11:37:56 --> Security Class Initialized
DEBUG - 2024-03-21 11:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:37:56 --> Input Class Initialized
INFO - 2024-03-21 11:37:56 --> Language Class Initialized
INFO - 2024-03-21 11:37:56 --> Loader Class Initialized
INFO - 2024-03-21 11:37:56 --> Helper loaded: url_helper
INFO - 2024-03-21 11:37:56 --> Helper loaded: file_helper
INFO - 2024-03-21 11:37:56 --> Helper loaded: form_helper
INFO - 2024-03-21 11:37:56 --> Helper loaded: general_helper
INFO - 2024-03-21 11:37:56 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:37:56 --> Controller Class Initialized
INFO - 2024-03-21 11:37:56 --> Form Validation Class Initialized
INFO - 2024-03-21 11:37:56 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:37:56 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:38:38 --> Config Class Initialized
INFO - 2024-03-21 11:38:38 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:38:38 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:38:38 --> Utf8 Class Initialized
INFO - 2024-03-21 11:38:38 --> URI Class Initialized
INFO - 2024-03-21 11:38:38 --> Router Class Initialized
INFO - 2024-03-21 11:38:38 --> Output Class Initialized
INFO - 2024-03-21 11:38:38 --> Security Class Initialized
DEBUG - 2024-03-21 11:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:38:38 --> Input Class Initialized
INFO - 2024-03-21 11:38:38 --> Language Class Initialized
INFO - 2024-03-21 11:38:38 --> Loader Class Initialized
INFO - 2024-03-21 11:38:38 --> Helper loaded: url_helper
INFO - 2024-03-21 11:38:38 --> Helper loaded: file_helper
INFO - 2024-03-21 11:38:38 --> Helper loaded: form_helper
INFO - 2024-03-21 11:38:38 --> Helper loaded: general_helper
INFO - 2024-03-21 11:38:38 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:38:38 --> Controller Class Initialized
INFO - 2024-03-21 11:38:38 --> Form Validation Class Initialized
INFO - 2024-03-21 11:38:38 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:38:38 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:38:38 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:38:38 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:38:38 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:38:38 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:38:38 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:38:38 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:38:38 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:38:38 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:38:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:38:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:38:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:38:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:38:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:38:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:38:38 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:38:38 --> Final output sent to browser
DEBUG - 2024-03-21 11:38:38 --> Total execution time: 0.0341
INFO - 2024-03-21 11:38:39 --> Config Class Initialized
INFO - 2024-03-21 11:38:39 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:38:39 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:38:39 --> Utf8 Class Initialized
INFO - 2024-03-21 11:38:39 --> URI Class Initialized
INFO - 2024-03-21 11:38:39 --> Router Class Initialized
INFO - 2024-03-21 11:38:39 --> Output Class Initialized
INFO - 2024-03-21 11:38:39 --> Security Class Initialized
DEBUG - 2024-03-21 11:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:38:39 --> Input Class Initialized
INFO - 2024-03-21 11:38:39 --> Language Class Initialized
INFO - 2024-03-21 11:38:39 --> Loader Class Initialized
INFO - 2024-03-21 11:38:39 --> Helper loaded: url_helper
INFO - 2024-03-21 11:38:39 --> Helper loaded: file_helper
INFO - 2024-03-21 11:38:39 --> Helper loaded: form_helper
INFO - 2024-03-21 11:38:39 --> Helper loaded: general_helper
INFO - 2024-03-21 11:38:39 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:38:39 --> Controller Class Initialized
INFO - 2024-03-21 11:38:39 --> Form Validation Class Initialized
INFO - 2024-03-21 11:38:39 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:38:39 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:38:39 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:38:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:38:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:38:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:38:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:38:39 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:38:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:38:39 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:38:48 --> Config Class Initialized
INFO - 2024-03-21 11:38:48 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:38:48 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:38:48 --> Utf8 Class Initialized
INFO - 2024-03-21 11:38:48 --> URI Class Initialized
INFO - 2024-03-21 11:38:48 --> Router Class Initialized
INFO - 2024-03-21 11:38:48 --> Output Class Initialized
INFO - 2024-03-21 11:38:48 --> Security Class Initialized
DEBUG - 2024-03-21 11:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:38:48 --> Input Class Initialized
INFO - 2024-03-21 11:38:48 --> Language Class Initialized
INFO - 2024-03-21 11:38:48 --> Loader Class Initialized
INFO - 2024-03-21 11:38:48 --> Helper loaded: url_helper
INFO - 2024-03-21 11:38:48 --> Helper loaded: file_helper
INFO - 2024-03-21 11:38:48 --> Helper loaded: form_helper
INFO - 2024-03-21 11:38:48 --> Helper loaded: general_helper
INFO - 2024-03-21 11:38:48 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:38:48 --> Controller Class Initialized
INFO - 2024-03-21 11:38:48 --> Form Validation Class Initialized
INFO - 2024-03-21 11:38:48 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:38:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:38:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:38:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:38:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:38:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:38:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:38:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:38:48 --> Final output sent to browser
DEBUG - 2024-03-21 11:38:48 --> Total execution time: 0.0262
INFO - 2024-03-21 11:38:48 --> Config Class Initialized
INFO - 2024-03-21 11:38:48 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:38:48 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:38:48 --> Utf8 Class Initialized
INFO - 2024-03-21 11:38:48 --> URI Class Initialized
INFO - 2024-03-21 11:38:48 --> Router Class Initialized
INFO - 2024-03-21 11:38:48 --> Output Class Initialized
INFO - 2024-03-21 11:38:48 --> Security Class Initialized
DEBUG - 2024-03-21 11:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:38:48 --> Input Class Initialized
INFO - 2024-03-21 11:38:48 --> Language Class Initialized
INFO - 2024-03-21 11:38:48 --> Loader Class Initialized
INFO - 2024-03-21 11:38:48 --> Helper loaded: url_helper
INFO - 2024-03-21 11:38:48 --> Helper loaded: file_helper
INFO - 2024-03-21 11:38:48 --> Helper loaded: form_helper
INFO - 2024-03-21 11:38:48 --> Helper loaded: general_helper
INFO - 2024-03-21 11:38:48 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:38:48 --> Controller Class Initialized
INFO - 2024-03-21 11:38:48 --> Form Validation Class Initialized
INFO - 2024-03-21 11:38:48 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:38:48 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:38:53 --> Config Class Initialized
INFO - 2024-03-21 11:38:53 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:38:53 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:38:53 --> Utf8 Class Initialized
INFO - 2024-03-21 11:38:53 --> URI Class Initialized
INFO - 2024-03-21 11:38:53 --> Router Class Initialized
INFO - 2024-03-21 11:38:53 --> Output Class Initialized
INFO - 2024-03-21 11:38:53 --> Security Class Initialized
DEBUG - 2024-03-21 11:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:38:53 --> Input Class Initialized
INFO - 2024-03-21 11:38:53 --> Language Class Initialized
INFO - 2024-03-21 11:38:53 --> Loader Class Initialized
INFO - 2024-03-21 11:38:53 --> Helper loaded: url_helper
INFO - 2024-03-21 11:38:53 --> Helper loaded: file_helper
INFO - 2024-03-21 11:38:53 --> Helper loaded: form_helper
INFO - 2024-03-21 11:38:54 --> Helper loaded: general_helper
INFO - 2024-03-21 11:38:54 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:38:54 --> Controller Class Initialized
INFO - 2024-03-21 11:38:54 --> Form Validation Class Initialized
INFO - 2024-03-21 11:38:54 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:38:54 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:38:54 --> Final output sent to browser
DEBUG - 2024-03-21 11:38:54 --> Total execution time: 0.0493
INFO - 2024-03-21 11:38:54 --> Config Class Initialized
INFO - 2024-03-21 11:38:54 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:38:54 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:38:54 --> Utf8 Class Initialized
INFO - 2024-03-21 11:38:54 --> URI Class Initialized
INFO - 2024-03-21 11:38:54 --> Router Class Initialized
INFO - 2024-03-21 11:38:54 --> Output Class Initialized
INFO - 2024-03-21 11:38:54 --> Security Class Initialized
DEBUG - 2024-03-21 11:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:38:54 --> Input Class Initialized
INFO - 2024-03-21 11:38:54 --> Language Class Initialized
INFO - 2024-03-21 11:38:54 --> Loader Class Initialized
INFO - 2024-03-21 11:38:54 --> Helper loaded: url_helper
INFO - 2024-03-21 11:38:54 --> Helper loaded: file_helper
INFO - 2024-03-21 11:38:54 --> Helper loaded: form_helper
INFO - 2024-03-21 11:38:54 --> Helper loaded: general_helper
INFO - 2024-03-21 11:38:54 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:38:54 --> Controller Class Initialized
INFO - 2024-03-21 11:38:54 --> Form Validation Class Initialized
INFO - 2024-03-21 11:38:54 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:38:54 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:02 --> Config Class Initialized
INFO - 2024-03-21 11:39:02 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:02 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:02 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:02 --> URI Class Initialized
INFO - 2024-03-21 11:39:02 --> Router Class Initialized
INFO - 2024-03-21 11:39:02 --> Output Class Initialized
INFO - 2024-03-21 11:39:02 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:02 --> Input Class Initialized
INFO - 2024-03-21 11:39:02 --> Language Class Initialized
INFO - 2024-03-21 11:39:02 --> Loader Class Initialized
INFO - 2024-03-21 11:39:02 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:02 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:02 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:02 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:02 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:02 --> Controller Class Initialized
INFO - 2024-03-21 11:39:02 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:02 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:39:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:39:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:39:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:39:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:39:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:39:02 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:39:02 --> Final output sent to browser
DEBUG - 2024-03-21 11:39:02 --> Total execution time: 0.0365
INFO - 2024-03-21 11:39:02 --> Config Class Initialized
INFO - 2024-03-21 11:39:02 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:02 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:02 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:02 --> URI Class Initialized
INFO - 2024-03-21 11:39:02 --> Router Class Initialized
INFO - 2024-03-21 11:39:02 --> Output Class Initialized
INFO - 2024-03-21 11:39:02 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:02 --> Input Class Initialized
INFO - 2024-03-21 11:39:02 --> Language Class Initialized
INFO - 2024-03-21 11:39:02 --> Loader Class Initialized
INFO - 2024-03-21 11:39:02 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:02 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:02 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:02 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:02 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:02 --> Controller Class Initialized
INFO - 2024-03-21 11:39:02 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:02 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:02 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:08 --> Config Class Initialized
INFO - 2024-03-21 11:39:08 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:08 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:08 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:08 --> URI Class Initialized
INFO - 2024-03-21 11:39:08 --> Router Class Initialized
INFO - 2024-03-21 11:39:08 --> Output Class Initialized
INFO - 2024-03-21 11:39:08 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:08 --> Input Class Initialized
INFO - 2024-03-21 11:39:08 --> Language Class Initialized
INFO - 2024-03-21 11:39:08 --> Loader Class Initialized
INFO - 2024-03-21 11:39:08 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:08 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:08 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:08 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:08 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:08 --> Controller Class Initialized
INFO - 2024-03-21 11:39:08 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:08 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:08 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:08 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:08 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:08 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:39:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:39:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:39:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:39:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:39:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:39:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:39:08 --> Final output sent to browser
DEBUG - 2024-03-21 11:39:08 --> Total execution time: 0.0216
INFO - 2024-03-21 11:39:08 --> Config Class Initialized
INFO - 2024-03-21 11:39:08 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:08 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:08 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:08 --> URI Class Initialized
INFO - 2024-03-21 11:39:08 --> Router Class Initialized
INFO - 2024-03-21 11:39:08 --> Output Class Initialized
INFO - 2024-03-21 11:39:08 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:08 --> Input Class Initialized
INFO - 2024-03-21 11:39:08 --> Language Class Initialized
INFO - 2024-03-21 11:39:08 --> Loader Class Initialized
INFO - 2024-03-21 11:39:08 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:08 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:08 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:08 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:08 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:09 --> Controller Class Initialized
INFO - 2024-03-21 11:39:09 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:09 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:09 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:09 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:09 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:09 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:13 --> Config Class Initialized
INFO - 2024-03-21 11:39:13 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:13 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:13 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:13 --> URI Class Initialized
INFO - 2024-03-21 11:39:13 --> Router Class Initialized
INFO - 2024-03-21 11:39:13 --> Output Class Initialized
INFO - 2024-03-21 11:39:13 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:13 --> Input Class Initialized
INFO - 2024-03-21 11:39:13 --> Language Class Initialized
INFO - 2024-03-21 11:39:13 --> Loader Class Initialized
INFO - 2024-03-21 11:39:13 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:13 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:13 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:13 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:13 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:13 --> Controller Class Initialized
INFO - 2024-03-21 11:39:13 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:13 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:13 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:13 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:13 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:13 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:16 --> Config Class Initialized
INFO - 2024-03-21 11:39:16 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:16 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:16 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:16 --> URI Class Initialized
INFO - 2024-03-21 11:39:16 --> Router Class Initialized
INFO - 2024-03-21 11:39:16 --> Output Class Initialized
INFO - 2024-03-21 11:39:16 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:16 --> Input Class Initialized
INFO - 2024-03-21 11:39:16 --> Language Class Initialized
INFO - 2024-03-21 11:39:16 --> Loader Class Initialized
INFO - 2024-03-21 11:39:16 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:16 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:16 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:16 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:16 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:16 --> Controller Class Initialized
INFO - 2024-03-21 11:39:16 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:16 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:16 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:16 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:16 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:16 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:19 --> Config Class Initialized
INFO - 2024-03-21 11:39:19 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:19 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:19 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:19 --> URI Class Initialized
INFO - 2024-03-21 11:39:19 --> Router Class Initialized
INFO - 2024-03-21 11:39:19 --> Output Class Initialized
INFO - 2024-03-21 11:39:19 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:19 --> Input Class Initialized
INFO - 2024-03-21 11:39:19 --> Language Class Initialized
INFO - 2024-03-21 11:39:19 --> Loader Class Initialized
INFO - 2024-03-21 11:39:19 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:19 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:19 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:19 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:19 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:19 --> Controller Class Initialized
INFO - 2024-03-21 11:39:19 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:19 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:19 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:19 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:19 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:19 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:19 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:19 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:19 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:22 --> Config Class Initialized
INFO - 2024-03-21 11:39:22 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:22 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:22 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:22 --> URI Class Initialized
INFO - 2024-03-21 11:39:22 --> Router Class Initialized
INFO - 2024-03-21 11:39:22 --> Output Class Initialized
INFO - 2024-03-21 11:39:22 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:22 --> Input Class Initialized
INFO - 2024-03-21 11:39:22 --> Language Class Initialized
INFO - 2024-03-21 11:39:22 --> Loader Class Initialized
INFO - 2024-03-21 11:39:22 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:22 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:22 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:22 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:22 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:22 --> Controller Class Initialized
INFO - 2024-03-21 11:39:22 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:22 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:22 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:22 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:22 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:22 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:22 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:22 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:22 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:22 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:22 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:25 --> Config Class Initialized
INFO - 2024-03-21 11:39:25 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:25 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:25 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:25 --> URI Class Initialized
INFO - 2024-03-21 11:39:25 --> Router Class Initialized
INFO - 2024-03-21 11:39:25 --> Output Class Initialized
INFO - 2024-03-21 11:39:25 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:25 --> Input Class Initialized
INFO - 2024-03-21 11:39:25 --> Language Class Initialized
INFO - 2024-03-21 11:39:25 --> Loader Class Initialized
INFO - 2024-03-21 11:39:25 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:25 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:25 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:25 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:25 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:25 --> Controller Class Initialized
INFO - 2024-03-21 11:39:25 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:25 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:25 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:25 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:25 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:25 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:25 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:25 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:25 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:25 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:25 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:27 --> Config Class Initialized
INFO - 2024-03-21 11:39:27 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:27 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:27 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:27 --> URI Class Initialized
INFO - 2024-03-21 11:39:27 --> Router Class Initialized
INFO - 2024-03-21 11:39:27 --> Output Class Initialized
INFO - 2024-03-21 11:39:27 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:27 --> Input Class Initialized
INFO - 2024-03-21 11:39:27 --> Language Class Initialized
INFO - 2024-03-21 11:39:27 --> Loader Class Initialized
INFO - 2024-03-21 11:39:27 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:27 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:27 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:27 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:27 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:27 --> Controller Class Initialized
INFO - 2024-03-21 11:39:27 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:27 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:27 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:27 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:27 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:27 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:43 --> Config Class Initialized
INFO - 2024-03-21 11:39:43 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:43 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:43 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:43 --> URI Class Initialized
INFO - 2024-03-21 11:39:43 --> Router Class Initialized
INFO - 2024-03-21 11:39:43 --> Output Class Initialized
INFO - 2024-03-21 11:39:43 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:43 --> Input Class Initialized
INFO - 2024-03-21 11:39:43 --> Language Class Initialized
INFO - 2024-03-21 11:39:43 --> Loader Class Initialized
INFO - 2024-03-21 11:39:43 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:43 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:43 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:43 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:43 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:43 --> Controller Class Initialized
INFO - 2024-03-21 11:39:43 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:43 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:39:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:39:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:39:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:39:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:39:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:39:43 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:39:43 --> Final output sent to browser
DEBUG - 2024-03-21 11:39:43 --> Total execution time: 0.0356
INFO - 2024-03-21 11:39:43 --> Config Class Initialized
INFO - 2024-03-21 11:39:43 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:43 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:43 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:43 --> URI Class Initialized
INFO - 2024-03-21 11:39:43 --> Router Class Initialized
INFO - 2024-03-21 11:39:43 --> Output Class Initialized
INFO - 2024-03-21 11:39:43 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:43 --> Input Class Initialized
INFO - 2024-03-21 11:39:43 --> Language Class Initialized
INFO - 2024-03-21 11:39:43 --> Loader Class Initialized
INFO - 2024-03-21 11:39:43 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:43 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:43 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:43 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:43 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:43 --> Controller Class Initialized
INFO - 2024-03-21 11:39:43 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:43 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:43 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:39:49 --> Config Class Initialized
INFO - 2024-03-21 11:39:49 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:39:49 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:39:49 --> Utf8 Class Initialized
INFO - 2024-03-21 11:39:49 --> URI Class Initialized
INFO - 2024-03-21 11:39:49 --> Router Class Initialized
INFO - 2024-03-21 11:39:49 --> Output Class Initialized
INFO - 2024-03-21 11:39:49 --> Security Class Initialized
DEBUG - 2024-03-21 11:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:39:49 --> Input Class Initialized
INFO - 2024-03-21 11:39:49 --> Language Class Initialized
INFO - 2024-03-21 11:39:49 --> Loader Class Initialized
INFO - 2024-03-21 11:39:49 --> Helper loaded: url_helper
INFO - 2024-03-21 11:39:49 --> Helper loaded: file_helper
INFO - 2024-03-21 11:39:49 --> Helper loaded: form_helper
INFO - 2024-03-21 11:39:49 --> Helper loaded: general_helper
INFO - 2024-03-21 11:39:49 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:39:49 --> Controller Class Initialized
INFO - 2024-03-21 11:39:49 --> Form Validation Class Initialized
INFO - 2024-03-21 11:39:49 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:39:49 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:39:49 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:39:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:39:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:39:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:39:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:39:49 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:39:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:39:49 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:40:05 --> Config Class Initialized
INFO - 2024-03-21 11:40:05 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:40:05 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:40:05 --> Utf8 Class Initialized
INFO - 2024-03-21 11:40:05 --> URI Class Initialized
INFO - 2024-03-21 11:40:05 --> Router Class Initialized
INFO - 2024-03-21 11:40:05 --> Output Class Initialized
INFO - 2024-03-21 11:40:05 --> Security Class Initialized
DEBUG - 2024-03-21 11:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:40:05 --> Input Class Initialized
INFO - 2024-03-21 11:40:05 --> Language Class Initialized
INFO - 2024-03-21 11:40:05 --> Loader Class Initialized
INFO - 2024-03-21 11:40:05 --> Helper loaded: url_helper
INFO - 2024-03-21 11:40:05 --> Helper loaded: file_helper
INFO - 2024-03-21 11:40:05 --> Helper loaded: form_helper
INFO - 2024-03-21 11:40:05 --> Helper loaded: general_helper
INFO - 2024-03-21 11:40:05 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:40:05 --> Controller Class Initialized
INFO - 2024-03-21 11:40:05 --> Form Validation Class Initialized
INFO - 2024-03-21 11:40:05 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:40:05 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:40:05 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:40:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:40:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:40:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:40:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:40:05 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:40:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:40:05 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:40:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:40:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:40:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:40:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:40:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:40:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:40:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:40:05 --> Final output sent to browser
DEBUG - 2024-03-21 11:40:05 --> Total execution time: 0.0297
INFO - 2024-03-21 11:40:06 --> Config Class Initialized
INFO - 2024-03-21 11:40:06 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:40:06 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:40:06 --> Utf8 Class Initialized
INFO - 2024-03-21 11:40:06 --> URI Class Initialized
INFO - 2024-03-21 11:40:06 --> Router Class Initialized
INFO - 2024-03-21 11:40:06 --> Output Class Initialized
INFO - 2024-03-21 11:40:06 --> Security Class Initialized
DEBUG - 2024-03-21 11:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:40:06 --> Input Class Initialized
INFO - 2024-03-21 11:40:06 --> Language Class Initialized
INFO - 2024-03-21 11:40:06 --> Loader Class Initialized
INFO - 2024-03-21 11:40:06 --> Helper loaded: url_helper
INFO - 2024-03-21 11:40:06 --> Helper loaded: file_helper
INFO - 2024-03-21 11:40:06 --> Helper loaded: form_helper
INFO - 2024-03-21 11:40:06 --> Helper loaded: general_helper
INFO - 2024-03-21 11:40:06 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:40:06 --> Controller Class Initialized
INFO - 2024-03-21 11:40:06 --> Form Validation Class Initialized
INFO - 2024-03-21 11:40:06 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:40:06 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:40:06 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:40:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:40:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:40:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:40:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:40:06 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:40:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:40:06 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:40:09 --> Config Class Initialized
INFO - 2024-03-21 11:40:09 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:40:09 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:40:09 --> Utf8 Class Initialized
INFO - 2024-03-21 11:40:09 --> URI Class Initialized
INFO - 2024-03-21 11:40:09 --> Router Class Initialized
INFO - 2024-03-21 11:40:09 --> Output Class Initialized
INFO - 2024-03-21 11:40:09 --> Security Class Initialized
DEBUG - 2024-03-21 11:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:40:09 --> Input Class Initialized
INFO - 2024-03-21 11:40:09 --> Language Class Initialized
INFO - 2024-03-21 11:40:09 --> Loader Class Initialized
INFO - 2024-03-21 11:40:09 --> Helper loaded: url_helper
INFO - 2024-03-21 11:40:09 --> Helper loaded: file_helper
INFO - 2024-03-21 11:40:09 --> Helper loaded: form_helper
INFO - 2024-03-21 11:40:09 --> Helper loaded: general_helper
INFO - 2024-03-21 11:40:09 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:40:09 --> Controller Class Initialized
INFO - 2024-03-21 11:40:09 --> Form Validation Class Initialized
INFO - 2024-03-21 11:40:09 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:40:09 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:40:09 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:40:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:40:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:40:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:40:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:40:09 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:40:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:40:09 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:40:48 --> Config Class Initialized
INFO - 2024-03-21 11:40:48 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:40:48 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:40:48 --> Utf8 Class Initialized
INFO - 2024-03-21 11:40:48 --> URI Class Initialized
INFO - 2024-03-21 11:40:48 --> Router Class Initialized
INFO - 2024-03-21 11:40:48 --> Output Class Initialized
INFO - 2024-03-21 11:40:48 --> Security Class Initialized
DEBUG - 2024-03-21 11:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:40:48 --> Input Class Initialized
INFO - 2024-03-21 11:40:48 --> Language Class Initialized
INFO - 2024-03-21 11:40:48 --> Loader Class Initialized
INFO - 2024-03-21 11:40:48 --> Helper loaded: url_helper
INFO - 2024-03-21 11:40:48 --> Helper loaded: file_helper
INFO - 2024-03-21 11:40:48 --> Helper loaded: form_helper
INFO - 2024-03-21 11:40:48 --> Helper loaded: general_helper
INFO - 2024-03-21 11:40:48 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:40:48 --> Controller Class Initialized
INFO - 2024-03-21 11:40:48 --> Form Validation Class Initialized
INFO - 2024-03-21 11:40:48 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:40:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:40:48 --> Final output sent to browser
DEBUG - 2024-03-21 11:40:48 --> Total execution time: 0.0338
INFO - 2024-03-21 11:40:48 --> Config Class Initialized
INFO - 2024-03-21 11:40:48 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:40:48 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:40:48 --> Utf8 Class Initialized
INFO - 2024-03-21 11:40:48 --> URI Class Initialized
INFO - 2024-03-21 11:40:48 --> Router Class Initialized
INFO - 2024-03-21 11:40:48 --> Output Class Initialized
INFO - 2024-03-21 11:40:48 --> Security Class Initialized
DEBUG - 2024-03-21 11:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:40:48 --> Input Class Initialized
INFO - 2024-03-21 11:40:48 --> Language Class Initialized
INFO - 2024-03-21 11:40:48 --> Loader Class Initialized
INFO - 2024-03-21 11:40:48 --> Helper loaded: url_helper
INFO - 2024-03-21 11:40:48 --> Helper loaded: file_helper
INFO - 2024-03-21 11:40:48 --> Helper loaded: form_helper
INFO - 2024-03-21 11:40:48 --> Helper loaded: general_helper
INFO - 2024-03-21 11:40:48 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:40:48 --> Controller Class Initialized
INFO - 2024-03-21 11:40:48 --> Form Validation Class Initialized
INFO - 2024-03-21 11:40:48 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:40:48 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:40:50 --> Config Class Initialized
INFO - 2024-03-21 11:40:50 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:40:50 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:40:50 --> Utf8 Class Initialized
INFO - 2024-03-21 11:40:50 --> URI Class Initialized
INFO - 2024-03-21 11:40:50 --> Router Class Initialized
INFO - 2024-03-21 11:40:50 --> Output Class Initialized
INFO - 2024-03-21 11:40:50 --> Security Class Initialized
DEBUG - 2024-03-21 11:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:40:50 --> Input Class Initialized
INFO - 2024-03-21 11:40:50 --> Language Class Initialized
INFO - 2024-03-21 11:40:50 --> Loader Class Initialized
INFO - 2024-03-21 11:40:50 --> Helper loaded: url_helper
INFO - 2024-03-21 11:40:50 --> Helper loaded: file_helper
INFO - 2024-03-21 11:40:50 --> Helper loaded: form_helper
INFO - 2024-03-21 11:40:50 --> Helper loaded: general_helper
INFO - 2024-03-21 11:40:50 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:40:50 --> Controller Class Initialized
INFO - 2024-03-21 11:40:50 --> Form Validation Class Initialized
INFO - 2024-03-21 11:40:50 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:40:50 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:40:50 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:40:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:40:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:40:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:40:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:40:50 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:40:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:40:50 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:40:55 --> Config Class Initialized
INFO - 2024-03-21 11:40:55 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:40:55 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:40:55 --> Utf8 Class Initialized
INFO - 2024-03-21 11:40:55 --> URI Class Initialized
INFO - 2024-03-21 11:40:55 --> Router Class Initialized
INFO - 2024-03-21 11:40:55 --> Output Class Initialized
INFO - 2024-03-21 11:40:55 --> Security Class Initialized
DEBUG - 2024-03-21 11:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:40:55 --> Input Class Initialized
INFO - 2024-03-21 11:40:55 --> Language Class Initialized
INFO - 2024-03-21 11:40:55 --> Loader Class Initialized
INFO - 2024-03-21 11:40:55 --> Helper loaded: url_helper
INFO - 2024-03-21 11:40:55 --> Helper loaded: file_helper
INFO - 2024-03-21 11:40:55 --> Helper loaded: form_helper
INFO - 2024-03-21 11:40:55 --> Helper loaded: general_helper
INFO - 2024-03-21 11:40:55 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:40:55 --> Controller Class Initialized
INFO - 2024-03-21 11:40:55 --> Form Validation Class Initialized
INFO - 2024-03-21 11:40:55 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:40:55 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:40:55 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:40:55 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:40:55 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:40:55 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:40:55 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:40:55 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:40:55 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:40:55 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:54:27 --> Config Class Initialized
INFO - 2024-03-21 11:54:27 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:54:27 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:54:27 --> Utf8 Class Initialized
INFO - 2024-03-21 11:54:27 --> URI Class Initialized
INFO - 2024-03-21 11:54:27 --> Router Class Initialized
INFO - 2024-03-21 11:54:27 --> Output Class Initialized
INFO - 2024-03-21 11:54:27 --> Security Class Initialized
DEBUG - 2024-03-21 11:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:54:27 --> Input Class Initialized
INFO - 2024-03-21 11:54:27 --> Language Class Initialized
INFO - 2024-03-21 11:54:27 --> Loader Class Initialized
INFO - 2024-03-21 11:54:27 --> Helper loaded: url_helper
INFO - 2024-03-21 11:54:27 --> Helper loaded: file_helper
INFO - 2024-03-21 11:54:27 --> Helper loaded: form_helper
INFO - 2024-03-21 11:54:27 --> Helper loaded: general_helper
INFO - 2024-03-21 11:54:27 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:54:27 --> Controller Class Initialized
INFO - 2024-03-21 11:54:27 --> Form Validation Class Initialized
INFO - 2024-03-21 11:54:27 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:54:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:54:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:54:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:54:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:54:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:54:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:54:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:54:27 --> Final output sent to browser
DEBUG - 2024-03-21 11:54:27 --> Total execution time: 0.0277
INFO - 2024-03-21 11:54:27 --> Config Class Initialized
INFO - 2024-03-21 11:54:27 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:54:27 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:54:27 --> Utf8 Class Initialized
INFO - 2024-03-21 11:54:27 --> URI Class Initialized
INFO - 2024-03-21 11:54:27 --> Router Class Initialized
INFO - 2024-03-21 11:54:27 --> Output Class Initialized
INFO - 2024-03-21 11:54:27 --> Security Class Initialized
DEBUG - 2024-03-21 11:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:54:27 --> Input Class Initialized
INFO - 2024-03-21 11:54:27 --> Language Class Initialized
INFO - 2024-03-21 11:54:27 --> Loader Class Initialized
INFO - 2024-03-21 11:54:27 --> Helper loaded: url_helper
INFO - 2024-03-21 11:54:27 --> Helper loaded: file_helper
INFO - 2024-03-21 11:54:27 --> Helper loaded: form_helper
INFO - 2024-03-21 11:54:27 --> Helper loaded: general_helper
INFO - 2024-03-21 11:54:27 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:54:27 --> Controller Class Initialized
INFO - 2024-03-21 11:54:27 --> Form Validation Class Initialized
INFO - 2024-03-21 11:54:27 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:54:27 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:54:58 --> Config Class Initialized
INFO - 2024-03-21 11:54:58 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:54:58 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:54:58 --> Utf8 Class Initialized
INFO - 2024-03-21 11:54:58 --> URI Class Initialized
INFO - 2024-03-21 11:54:58 --> Router Class Initialized
INFO - 2024-03-21 11:54:58 --> Output Class Initialized
INFO - 2024-03-21 11:54:58 --> Security Class Initialized
DEBUG - 2024-03-21 11:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:54:58 --> Input Class Initialized
INFO - 2024-03-21 11:54:58 --> Language Class Initialized
INFO - 2024-03-21 11:54:58 --> Loader Class Initialized
INFO - 2024-03-21 11:54:58 --> Helper loaded: url_helper
INFO - 2024-03-21 11:54:58 --> Helper loaded: file_helper
INFO - 2024-03-21 11:54:58 --> Helper loaded: form_helper
INFO - 2024-03-21 11:54:58 --> Helper loaded: general_helper
INFO - 2024-03-21 11:54:58 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:54:58 --> Controller Class Initialized
INFO - 2024-03-21 11:54:58 --> Form Validation Class Initialized
INFO - 2024-03-21 11:54:58 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:54:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:54:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:54:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:54:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:54:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:54:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:54:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:54:58 --> Final output sent to browser
DEBUG - 2024-03-21 11:54:58 --> Total execution time: 0.0326
INFO - 2024-03-21 11:54:58 --> Config Class Initialized
INFO - 2024-03-21 11:54:58 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:54:58 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:54:58 --> Utf8 Class Initialized
INFO - 2024-03-21 11:54:58 --> URI Class Initialized
INFO - 2024-03-21 11:54:58 --> Router Class Initialized
INFO - 2024-03-21 11:54:58 --> Output Class Initialized
INFO - 2024-03-21 11:54:58 --> Security Class Initialized
DEBUG - 2024-03-21 11:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:54:58 --> Input Class Initialized
INFO - 2024-03-21 11:54:58 --> Language Class Initialized
INFO - 2024-03-21 11:54:58 --> Loader Class Initialized
INFO - 2024-03-21 11:54:58 --> Helper loaded: url_helper
INFO - 2024-03-21 11:54:58 --> Helper loaded: file_helper
INFO - 2024-03-21 11:54:58 --> Helper loaded: form_helper
INFO - 2024-03-21 11:54:58 --> Helper loaded: general_helper
INFO - 2024-03-21 11:54:58 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:54:58 --> Controller Class Initialized
INFO - 2024-03-21 11:54:58 --> Form Validation Class Initialized
INFO - 2024-03-21 11:54:58 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:54:58 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:55:05 --> Config Class Initialized
INFO - 2024-03-21 11:55:05 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:55:05 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:55:05 --> Utf8 Class Initialized
INFO - 2024-03-21 11:55:05 --> URI Class Initialized
INFO - 2024-03-21 11:55:05 --> Router Class Initialized
INFO - 2024-03-21 11:55:05 --> Output Class Initialized
INFO - 2024-03-21 11:55:05 --> Security Class Initialized
DEBUG - 2024-03-21 11:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:55:05 --> Input Class Initialized
INFO - 2024-03-21 11:55:05 --> Language Class Initialized
INFO - 2024-03-21 11:55:05 --> Loader Class Initialized
INFO - 2024-03-21 11:55:05 --> Helper loaded: url_helper
INFO - 2024-03-21 11:55:05 --> Helper loaded: file_helper
INFO - 2024-03-21 11:55:05 --> Helper loaded: form_helper
INFO - 2024-03-21 11:55:05 --> Helper loaded: general_helper
INFO - 2024-03-21 11:55:05 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:55:05 --> Controller Class Initialized
INFO - 2024-03-21 11:55:05 --> Form Validation Class Initialized
INFO - 2024-03-21 11:55:05 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:55:05 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:55:05 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:55:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:55:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:55:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:55:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:55:05 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:55:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:55:05 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:55:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:55:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:55:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:55:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:55:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:55:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:55:05 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:55:05 --> Final output sent to browser
DEBUG - 2024-03-21 11:55:05 --> Total execution time: 0.0416
INFO - 2024-03-21 11:55:27 --> Config Class Initialized
INFO - 2024-03-21 11:55:27 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:55:27 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:55:27 --> Utf8 Class Initialized
INFO - 2024-03-21 11:55:27 --> URI Class Initialized
INFO - 2024-03-21 11:55:27 --> Router Class Initialized
INFO - 2024-03-21 11:55:27 --> Output Class Initialized
INFO - 2024-03-21 11:55:27 --> Security Class Initialized
DEBUG - 2024-03-21 11:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:55:27 --> Input Class Initialized
INFO - 2024-03-21 11:55:27 --> Language Class Initialized
INFO - 2024-03-21 11:55:27 --> Loader Class Initialized
INFO - 2024-03-21 11:55:27 --> Helper loaded: url_helper
INFO - 2024-03-21 11:55:27 --> Helper loaded: file_helper
INFO - 2024-03-21 11:55:27 --> Helper loaded: form_helper
INFO - 2024-03-21 11:55:27 --> Helper loaded: general_helper
INFO - 2024-03-21 11:55:27 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:55:27 --> Controller Class Initialized
INFO - 2024-03-21 11:55:27 --> Form Validation Class Initialized
INFO - 2024-03-21 11:55:27 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:55:27 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:55:27 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:55:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:55:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:55:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:55:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:55:27 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:55:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:55:27 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:55:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:55:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:55:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:55:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:55:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:55:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:55:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:55:27 --> Final output sent to browser
DEBUG - 2024-03-21 11:55:27 --> Total execution time: 0.0310
INFO - 2024-03-21 11:55:28 --> Config Class Initialized
INFO - 2024-03-21 11:55:28 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:55:28 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:55:28 --> Utf8 Class Initialized
INFO - 2024-03-21 11:55:28 --> URI Class Initialized
INFO - 2024-03-21 11:55:28 --> Router Class Initialized
INFO - 2024-03-21 11:55:28 --> Output Class Initialized
INFO - 2024-03-21 11:55:28 --> Security Class Initialized
DEBUG - 2024-03-21 11:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:55:28 --> Input Class Initialized
INFO - 2024-03-21 11:55:28 --> Language Class Initialized
INFO - 2024-03-21 11:55:28 --> Loader Class Initialized
INFO - 2024-03-21 11:55:28 --> Helper loaded: url_helper
INFO - 2024-03-21 11:55:28 --> Helper loaded: file_helper
INFO - 2024-03-21 11:55:28 --> Helper loaded: form_helper
INFO - 2024-03-21 11:55:28 --> Helper loaded: general_helper
INFO - 2024-03-21 11:55:28 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:55:28 --> Controller Class Initialized
INFO - 2024-03-21 11:55:28 --> Form Validation Class Initialized
INFO - 2024-03-21 11:55:28 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:55:28 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:55:28 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:55:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:55:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:55:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:55:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:55:28 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:55:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:55:28 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:55:36 --> Config Class Initialized
INFO - 2024-03-21 11:55:36 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:55:36 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:55:36 --> Utf8 Class Initialized
INFO - 2024-03-21 11:55:36 --> URI Class Initialized
INFO - 2024-03-21 11:55:36 --> Router Class Initialized
INFO - 2024-03-21 11:55:36 --> Output Class Initialized
INFO - 2024-03-21 11:55:36 --> Security Class Initialized
DEBUG - 2024-03-21 11:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:55:36 --> Input Class Initialized
INFO - 2024-03-21 11:55:36 --> Language Class Initialized
INFO - 2024-03-21 11:55:36 --> Loader Class Initialized
INFO - 2024-03-21 11:55:36 --> Helper loaded: url_helper
INFO - 2024-03-21 11:55:36 --> Helper loaded: file_helper
INFO - 2024-03-21 11:55:36 --> Helper loaded: form_helper
INFO - 2024-03-21 11:55:36 --> Helper loaded: general_helper
INFO - 2024-03-21 11:55:36 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:55:36 --> Controller Class Initialized
INFO - 2024-03-21 11:55:36 --> Form Validation Class Initialized
INFO - 2024-03-21 11:55:36 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:55:36 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:55:36 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:55:36 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:55:36 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:55:36 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:55:36 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:55:36 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:55:36 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:55:36 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:55:51 --> Config Class Initialized
INFO - 2024-03-21 11:55:51 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:55:51 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:55:51 --> Utf8 Class Initialized
INFO - 2024-03-21 11:55:51 --> URI Class Initialized
INFO - 2024-03-21 11:55:51 --> Router Class Initialized
INFO - 2024-03-21 11:55:51 --> Output Class Initialized
INFO - 2024-03-21 11:55:51 --> Security Class Initialized
DEBUG - 2024-03-21 11:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:55:51 --> Input Class Initialized
INFO - 2024-03-21 11:55:51 --> Language Class Initialized
INFO - 2024-03-21 11:55:51 --> Loader Class Initialized
INFO - 2024-03-21 11:55:51 --> Helper loaded: url_helper
INFO - 2024-03-21 11:55:51 --> Helper loaded: file_helper
INFO - 2024-03-21 11:55:51 --> Helper loaded: form_helper
INFO - 2024-03-21 11:55:51 --> Helper loaded: general_helper
INFO - 2024-03-21 11:55:51 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:55:51 --> Controller Class Initialized
INFO - 2024-03-21 11:55:51 --> Form Validation Class Initialized
INFO - 2024-03-21 11:55:51 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:55:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 11:55:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 11:55:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 11:55:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 11:55:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 11:55:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 11:55:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_print_form.php
INFO - 2024-03-21 11:55:51 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 11:55:51 --> Final output sent to browser
DEBUG - 2024-03-21 11:55:51 --> Total execution time: 0.0306
INFO - 2024-03-21 11:55:51 --> Config Class Initialized
INFO - 2024-03-21 11:55:51 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:55:51 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:55:51 --> Utf8 Class Initialized
INFO - 2024-03-21 11:55:51 --> URI Class Initialized
INFO - 2024-03-21 11:55:51 --> Router Class Initialized
INFO - 2024-03-21 11:55:51 --> Output Class Initialized
INFO - 2024-03-21 11:55:51 --> Security Class Initialized
DEBUG - 2024-03-21 11:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:55:51 --> Input Class Initialized
INFO - 2024-03-21 11:55:51 --> Language Class Initialized
INFO - 2024-03-21 11:55:51 --> Loader Class Initialized
INFO - 2024-03-21 11:55:51 --> Helper loaded: url_helper
INFO - 2024-03-21 11:55:51 --> Helper loaded: file_helper
INFO - 2024-03-21 11:55:51 --> Helper loaded: form_helper
INFO - 2024-03-21 11:55:51 --> Helper loaded: general_helper
INFO - 2024-03-21 11:55:51 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:55:51 --> Controller Class Initialized
INFO - 2024-03-21 11:55:51 --> Form Validation Class Initialized
INFO - 2024-03-21 11:55:51 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:55:51 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:55:58 --> Config Class Initialized
INFO - 2024-03-21 11:55:58 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:55:58 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:55:58 --> Utf8 Class Initialized
INFO - 2024-03-21 11:55:58 --> URI Class Initialized
INFO - 2024-03-21 11:55:58 --> Router Class Initialized
INFO - 2024-03-21 11:55:58 --> Output Class Initialized
INFO - 2024-03-21 11:55:58 --> Security Class Initialized
DEBUG - 2024-03-21 11:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:55:58 --> Input Class Initialized
INFO - 2024-03-21 11:55:58 --> Language Class Initialized
INFO - 2024-03-21 11:55:58 --> Loader Class Initialized
INFO - 2024-03-21 11:55:58 --> Helper loaded: url_helper
INFO - 2024-03-21 11:55:58 --> Helper loaded: file_helper
INFO - 2024-03-21 11:55:58 --> Helper loaded: form_helper
INFO - 2024-03-21 11:55:58 --> Helper loaded: general_helper
INFO - 2024-03-21 11:55:58 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:55:58 --> Controller Class Initialized
INFO - 2024-03-21 11:55:58 --> Form Validation Class Initialized
INFO - 2024-03-21 11:55:58 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:55:58 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:55:58 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:55:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:55:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:55:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:55:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:55:58 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:55:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:55:58 --> Model "ReportModel" initialized
ERROR - 2024-03-21 11:55:58 --> Severity: Notice --> Undefined index: draw D:\xampp\htdocs\sscy\application\models\MasterModel.php 6
ERROR - 2024-03-21 11:55:58 --> Severity: Notice --> Undefined index: start D:\xampp\htdocs\sscy\application\models\MasterModel.php 7
ERROR - 2024-03-21 11:55:58 --> Severity: Notice --> Undefined index: length D:\xampp\htdocs\sscy\application\models\MasterModel.php 8
ERROR - 2024-03-21 11:55:58 --> Severity: Notice --> Undefined index: search D:\xampp\htdocs\sscy\application\models\MasterModel.php 9
ERROR - 2024-03-21 11:55:58 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\sscy\application\models\MasterModel.php 9
ERROR - 2024-03-21 11:55:58 --> Severity: error --> Exception: Data has already been sent to output (D:\xampp\htdocs\sscy\system\core\Exceptions.php at line 271), unable to output PDF file D:\xampp\htdocs\sscy\vendor\mpdf\mpdf\src\Mpdf.php 9572
ERROR - 2024-03-21 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\sscy\system\core\Exceptions.php:271) D:\xampp\htdocs\sscy\system\core\Common.php 570
INFO - 2024-03-21 11:56:17 --> Config Class Initialized
INFO - 2024-03-21 11:56:17 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:56:17 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:56:17 --> Utf8 Class Initialized
INFO - 2024-03-21 11:56:17 --> URI Class Initialized
INFO - 2024-03-21 11:56:17 --> Router Class Initialized
INFO - 2024-03-21 11:56:17 --> Output Class Initialized
INFO - 2024-03-21 11:56:17 --> Security Class Initialized
DEBUG - 2024-03-21 11:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:56:17 --> Input Class Initialized
INFO - 2024-03-21 11:56:17 --> Language Class Initialized
INFO - 2024-03-21 11:56:17 --> Loader Class Initialized
INFO - 2024-03-21 11:56:17 --> Helper loaded: url_helper
INFO - 2024-03-21 11:56:17 --> Helper loaded: file_helper
INFO - 2024-03-21 11:56:17 --> Helper loaded: form_helper
INFO - 2024-03-21 11:56:17 --> Helper loaded: general_helper
INFO - 2024-03-21 11:56:17 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:56:17 --> Controller Class Initialized
INFO - 2024-03-21 11:56:17 --> Form Validation Class Initialized
INFO - 2024-03-21 11:56:17 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:56:17 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:56:17 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:56:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:56:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:56:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:56:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:56:17 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:56:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:56:17 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:56:18 --> Final output sent to browser
DEBUG - 2024-03-21 11:56:18 --> Total execution time: 0.4755
INFO - 2024-03-21 11:57:14 --> Config Class Initialized
INFO - 2024-03-21 11:57:14 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:57:14 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:57:14 --> Utf8 Class Initialized
INFO - 2024-03-21 11:57:14 --> URI Class Initialized
INFO - 2024-03-21 11:57:14 --> Router Class Initialized
INFO - 2024-03-21 11:57:14 --> Output Class Initialized
INFO - 2024-03-21 11:57:14 --> Security Class Initialized
DEBUG - 2024-03-21 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:57:14 --> Input Class Initialized
INFO - 2024-03-21 11:57:14 --> Language Class Initialized
INFO - 2024-03-21 11:57:14 --> Loader Class Initialized
INFO - 2024-03-21 11:57:14 --> Helper loaded: url_helper
INFO - 2024-03-21 11:57:14 --> Helper loaded: file_helper
INFO - 2024-03-21 11:57:14 --> Helper loaded: form_helper
INFO - 2024-03-21 11:57:14 --> Helper loaded: general_helper
INFO - 2024-03-21 11:57:14 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:57:14 --> Controller Class Initialized
INFO - 2024-03-21 11:57:14 --> Form Validation Class Initialized
INFO - 2024-03-21 11:57:14 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:57:14 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:57:14 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:57:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:57:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:57:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:57:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:57:14 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:57:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:57:14 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:57:14 --> Final output sent to browser
DEBUG - 2024-03-21 11:57:14 --> Total execution time: 0.8155
INFO - 2024-03-21 11:58:02 --> Config Class Initialized
INFO - 2024-03-21 11:58:02 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:58:02 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:58:02 --> Utf8 Class Initialized
INFO - 2024-03-21 11:58:02 --> URI Class Initialized
INFO - 2024-03-21 11:58:02 --> Router Class Initialized
INFO - 2024-03-21 11:58:02 --> Output Class Initialized
INFO - 2024-03-21 11:58:02 --> Security Class Initialized
DEBUG - 2024-03-21 11:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:58:02 --> Input Class Initialized
INFO - 2024-03-21 11:58:02 --> Language Class Initialized
INFO - 2024-03-21 11:58:02 --> Loader Class Initialized
INFO - 2024-03-21 11:58:02 --> Helper loaded: url_helper
INFO - 2024-03-21 11:58:02 --> Helper loaded: file_helper
INFO - 2024-03-21 11:58:02 --> Helper loaded: form_helper
INFO - 2024-03-21 11:58:02 --> Helper loaded: general_helper
INFO - 2024-03-21 11:58:02 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:58:02 --> Controller Class Initialized
INFO - 2024-03-21 11:58:02 --> Form Validation Class Initialized
INFO - 2024-03-21 11:58:02 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:58:02 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:58:02 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:58:02 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:58:02 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:58:02 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:58:02 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:58:02 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:58:02 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:58:02 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:58:02 --> Final output sent to browser
DEBUG - 2024-03-21 11:58:02 --> Total execution time: 0.8323
INFO - 2024-03-21 11:58:45 --> Config Class Initialized
INFO - 2024-03-21 11:58:45 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:58:45 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:58:45 --> Utf8 Class Initialized
INFO - 2024-03-21 11:58:45 --> URI Class Initialized
INFO - 2024-03-21 11:58:45 --> Router Class Initialized
INFO - 2024-03-21 11:58:45 --> Output Class Initialized
INFO - 2024-03-21 11:58:45 --> Security Class Initialized
DEBUG - 2024-03-21 11:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:58:45 --> Input Class Initialized
INFO - 2024-03-21 11:58:45 --> Language Class Initialized
INFO - 2024-03-21 11:58:45 --> Loader Class Initialized
INFO - 2024-03-21 11:58:45 --> Helper loaded: url_helper
INFO - 2024-03-21 11:58:45 --> Helper loaded: file_helper
INFO - 2024-03-21 11:58:45 --> Helper loaded: form_helper
INFO - 2024-03-21 11:58:45 --> Helper loaded: general_helper
INFO - 2024-03-21 11:58:45 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:58:45 --> Controller Class Initialized
INFO - 2024-03-21 11:58:45 --> Form Validation Class Initialized
INFO - 2024-03-21 11:58:45 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:58:45 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:58:45 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:58:45 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:58:45 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:58:45 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:58:45 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:58:45 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:58:45 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:58:45 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:58:45 --> Final output sent to browser
DEBUG - 2024-03-21 11:58:45 --> Total execution time: 0.8713
INFO - 2024-03-21 11:58:50 --> Config Class Initialized
INFO - 2024-03-21 11:58:50 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:58:50 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:58:50 --> Utf8 Class Initialized
INFO - 2024-03-21 11:58:50 --> URI Class Initialized
INFO - 2024-03-21 11:58:50 --> Router Class Initialized
INFO - 2024-03-21 11:58:50 --> Output Class Initialized
INFO - 2024-03-21 11:58:50 --> Security Class Initialized
DEBUG - 2024-03-21 11:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:58:50 --> Input Class Initialized
INFO - 2024-03-21 11:58:50 --> Language Class Initialized
INFO - 2024-03-21 11:58:50 --> Loader Class Initialized
INFO - 2024-03-21 11:58:50 --> Helper loaded: url_helper
INFO - 2024-03-21 11:58:50 --> Helper loaded: file_helper
INFO - 2024-03-21 11:58:50 --> Helper loaded: form_helper
INFO - 2024-03-21 11:58:50 --> Helper loaded: general_helper
INFO - 2024-03-21 11:58:50 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:58:50 --> Controller Class Initialized
INFO - 2024-03-21 11:58:50 --> Form Validation Class Initialized
INFO - 2024-03-21 11:58:50 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:58:50 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:58:50 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:58:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:58:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:58:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:58:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:58:50 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:58:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:58:50 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:58:51 --> Final output sent to browser
DEBUG - 2024-03-21 11:58:51 --> Total execution time: 0.8537
INFO - 2024-03-21 11:58:56 --> Config Class Initialized
INFO - 2024-03-21 11:58:56 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:58:56 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:58:56 --> Utf8 Class Initialized
INFO - 2024-03-21 11:58:56 --> URI Class Initialized
INFO - 2024-03-21 11:58:56 --> Router Class Initialized
INFO - 2024-03-21 11:58:56 --> Output Class Initialized
INFO - 2024-03-21 11:58:56 --> Security Class Initialized
DEBUG - 2024-03-21 11:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:58:56 --> Input Class Initialized
INFO - 2024-03-21 11:58:56 --> Language Class Initialized
INFO - 2024-03-21 11:58:56 --> Loader Class Initialized
INFO - 2024-03-21 11:58:56 --> Helper loaded: url_helper
INFO - 2024-03-21 11:58:56 --> Helper loaded: file_helper
INFO - 2024-03-21 11:58:56 --> Helper loaded: form_helper
INFO - 2024-03-21 11:58:56 --> Helper loaded: general_helper
INFO - 2024-03-21 11:58:56 --> Database Driver Class Initialized
DEBUG - 2024-03-21 11:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 11:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:58:56 --> Controller Class Initialized
INFO - 2024-03-21 11:58:56 --> Form Validation Class Initialized
INFO - 2024-03-21 11:58:56 --> Model "MasterModel" initialized
INFO - 2024-03-21 11:58:56 --> Model "NotificationModel" initialized
INFO - 2024-03-21 11:58:56 --> Model "DashboardModel" initialized
INFO - 2024-03-21 11:58:56 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 11:58:56 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 11:58:56 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 11:58:56 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 11:58:56 --> Model "OrderModel" initialized
INFO - 2024-03-21 11:58:56 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 11:58:56 --> Model "ReportModel" initialized
INFO - 2024-03-21 11:58:57 --> Final output sent to browser
DEBUG - 2024-03-21 11:58:57 --> Total execution time: 0.8554
INFO - 2024-03-21 12:00:54 --> Config Class Initialized
INFO - 2024-03-21 12:00:54 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:00:54 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:00:54 --> Utf8 Class Initialized
INFO - 2024-03-21 12:00:54 --> URI Class Initialized
INFO - 2024-03-21 12:00:54 --> Router Class Initialized
INFO - 2024-03-21 12:00:54 --> Output Class Initialized
INFO - 2024-03-21 12:00:54 --> Security Class Initialized
DEBUG - 2024-03-21 12:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:00:54 --> Input Class Initialized
INFO - 2024-03-21 12:00:54 --> Language Class Initialized
INFO - 2024-03-21 12:00:54 --> Loader Class Initialized
INFO - 2024-03-21 12:00:54 --> Helper loaded: url_helper
INFO - 2024-03-21 12:00:54 --> Helper loaded: file_helper
INFO - 2024-03-21 12:00:54 --> Helper loaded: form_helper
INFO - 2024-03-21 12:00:54 --> Helper loaded: general_helper
INFO - 2024-03-21 12:00:54 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:00:54 --> Controller Class Initialized
INFO - 2024-03-21 12:00:54 --> Form Validation Class Initialized
INFO - 2024-03-21 12:00:54 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:00:54 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:00:54 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:00:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:00:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:00:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:00:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:00:54 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:00:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:00:54 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:00:55 --> Final output sent to browser
DEBUG - 2024-03-21 12:00:55 --> Total execution time: 0.8333
INFO - 2024-03-21 12:01:15 --> Config Class Initialized
INFO - 2024-03-21 12:01:15 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:01:15 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:01:15 --> Utf8 Class Initialized
INFO - 2024-03-21 12:01:15 --> URI Class Initialized
INFO - 2024-03-21 12:01:15 --> Router Class Initialized
INFO - 2024-03-21 12:01:15 --> Output Class Initialized
INFO - 2024-03-21 12:01:15 --> Security Class Initialized
DEBUG - 2024-03-21 12:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:01:15 --> Input Class Initialized
INFO - 2024-03-21 12:01:15 --> Language Class Initialized
INFO - 2024-03-21 12:01:15 --> Loader Class Initialized
INFO - 2024-03-21 12:01:15 --> Helper loaded: url_helper
INFO - 2024-03-21 12:01:15 --> Helper loaded: file_helper
INFO - 2024-03-21 12:01:15 --> Helper loaded: form_helper
INFO - 2024-03-21 12:01:15 --> Helper loaded: general_helper
INFO - 2024-03-21 12:01:15 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:01:15 --> Controller Class Initialized
INFO - 2024-03-21 12:01:15 --> Form Validation Class Initialized
INFO - 2024-03-21 12:01:15 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:01:15 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:01:15 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:01:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:01:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:01:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:01:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:01:15 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:01:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:01:15 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:01:16 --> Final output sent to browser
DEBUG - 2024-03-21 12:01:16 --> Total execution time: 0.8243
INFO - 2024-03-21 12:02:19 --> Config Class Initialized
INFO - 2024-03-21 12:02:19 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:02:19 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:02:19 --> Utf8 Class Initialized
INFO - 2024-03-21 12:02:19 --> URI Class Initialized
INFO - 2024-03-21 12:02:19 --> Router Class Initialized
INFO - 2024-03-21 12:02:19 --> Output Class Initialized
INFO - 2024-03-21 12:02:19 --> Security Class Initialized
DEBUG - 2024-03-21 12:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:02:19 --> Input Class Initialized
INFO - 2024-03-21 12:02:19 --> Language Class Initialized
INFO - 2024-03-21 12:02:19 --> Loader Class Initialized
INFO - 2024-03-21 12:02:19 --> Helper loaded: url_helper
INFO - 2024-03-21 12:02:19 --> Helper loaded: file_helper
INFO - 2024-03-21 12:02:19 --> Helper loaded: form_helper
INFO - 2024-03-21 12:02:19 --> Helper loaded: general_helper
INFO - 2024-03-21 12:02:19 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:02:19 --> Controller Class Initialized
INFO - 2024-03-21 12:02:19 --> Form Validation Class Initialized
INFO - 2024-03-21 12:02:19 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:02:19 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:02:19 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:02:19 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:02:19 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:02:19 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:02:19 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:02:19 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:02:19 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:02:19 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:02:20 --> Final output sent to browser
DEBUG - 2024-03-21 12:02:20 --> Total execution time: 0.8268
INFO - 2024-03-21 12:02:35 --> Config Class Initialized
INFO - 2024-03-21 12:02:35 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:02:35 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:02:35 --> Utf8 Class Initialized
INFO - 2024-03-21 12:02:35 --> URI Class Initialized
INFO - 2024-03-21 12:02:35 --> Router Class Initialized
INFO - 2024-03-21 12:02:35 --> Output Class Initialized
INFO - 2024-03-21 12:02:35 --> Security Class Initialized
DEBUG - 2024-03-21 12:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:02:35 --> Input Class Initialized
INFO - 2024-03-21 12:02:35 --> Language Class Initialized
INFO - 2024-03-21 12:02:35 --> Loader Class Initialized
INFO - 2024-03-21 12:02:35 --> Helper loaded: url_helper
INFO - 2024-03-21 12:02:35 --> Helper loaded: file_helper
INFO - 2024-03-21 12:02:35 --> Helper loaded: form_helper
INFO - 2024-03-21 12:02:35 --> Helper loaded: general_helper
INFO - 2024-03-21 12:02:35 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:02:35 --> Controller Class Initialized
INFO - 2024-03-21 12:02:35 --> Form Validation Class Initialized
INFO - 2024-03-21 12:02:35 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:02:35 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:02:35 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:02:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:02:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:02:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:02:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:02:35 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:02:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:02:35 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:02:36 --> Final output sent to browser
DEBUG - 2024-03-21 12:02:36 --> Total execution time: 0.8480
INFO - 2024-03-21 12:02:50 --> Config Class Initialized
INFO - 2024-03-21 12:02:50 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:02:50 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:02:50 --> Utf8 Class Initialized
INFO - 2024-03-21 12:02:50 --> URI Class Initialized
INFO - 2024-03-21 12:02:50 --> Router Class Initialized
INFO - 2024-03-21 12:02:50 --> Output Class Initialized
INFO - 2024-03-21 12:02:50 --> Security Class Initialized
DEBUG - 2024-03-21 12:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:02:50 --> Input Class Initialized
INFO - 2024-03-21 12:02:50 --> Language Class Initialized
INFO - 2024-03-21 12:02:50 --> Loader Class Initialized
INFO - 2024-03-21 12:02:50 --> Helper loaded: url_helper
INFO - 2024-03-21 12:02:50 --> Helper loaded: file_helper
INFO - 2024-03-21 12:02:50 --> Helper loaded: form_helper
INFO - 2024-03-21 12:02:50 --> Helper loaded: general_helper
INFO - 2024-03-21 12:02:50 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:02:50 --> Controller Class Initialized
INFO - 2024-03-21 12:02:50 --> Form Validation Class Initialized
INFO - 2024-03-21 12:02:50 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:02:50 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:02:50 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:02:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:02:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:02:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:02:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:02:50 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:02:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:02:50 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:02:51 --> Final output sent to browser
DEBUG - 2024-03-21 12:02:51 --> Total execution time: 0.9096
INFO - 2024-03-21 12:03:05 --> Config Class Initialized
INFO - 2024-03-21 12:03:05 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:03:05 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:03:05 --> Utf8 Class Initialized
INFO - 2024-03-21 12:03:05 --> URI Class Initialized
INFO - 2024-03-21 12:03:05 --> Router Class Initialized
INFO - 2024-03-21 12:03:05 --> Output Class Initialized
INFO - 2024-03-21 12:03:05 --> Security Class Initialized
DEBUG - 2024-03-21 12:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:03:05 --> Input Class Initialized
INFO - 2024-03-21 12:03:05 --> Language Class Initialized
INFO - 2024-03-21 12:03:05 --> Loader Class Initialized
INFO - 2024-03-21 12:03:05 --> Helper loaded: url_helper
INFO - 2024-03-21 12:03:05 --> Helper loaded: file_helper
INFO - 2024-03-21 12:03:05 --> Helper loaded: form_helper
INFO - 2024-03-21 12:03:05 --> Helper loaded: general_helper
INFO - 2024-03-21 12:03:05 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:03:05 --> Controller Class Initialized
INFO - 2024-03-21 12:03:05 --> Form Validation Class Initialized
INFO - 2024-03-21 12:03:05 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:03:05 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:03:05 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:03:05 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:03:05 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:03:05 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:03:05 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:03:05 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:03:05 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:03:05 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:03:06 --> Final output sent to browser
DEBUG - 2024-03-21 12:03:06 --> Total execution time: 0.8621
INFO - 2024-03-21 12:03:13 --> Config Class Initialized
INFO - 2024-03-21 12:03:13 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:03:13 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:03:13 --> Utf8 Class Initialized
INFO - 2024-03-21 12:03:13 --> URI Class Initialized
INFO - 2024-03-21 12:03:13 --> Router Class Initialized
INFO - 2024-03-21 12:03:13 --> Output Class Initialized
INFO - 2024-03-21 12:03:13 --> Security Class Initialized
DEBUG - 2024-03-21 12:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:03:13 --> Input Class Initialized
INFO - 2024-03-21 12:03:13 --> Language Class Initialized
INFO - 2024-03-21 12:03:13 --> Loader Class Initialized
INFO - 2024-03-21 12:03:13 --> Helper loaded: url_helper
INFO - 2024-03-21 12:03:13 --> Helper loaded: file_helper
INFO - 2024-03-21 12:03:13 --> Helper loaded: form_helper
INFO - 2024-03-21 12:03:13 --> Helper loaded: general_helper
INFO - 2024-03-21 12:03:13 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:03:13 --> Controller Class Initialized
INFO - 2024-03-21 12:03:13 --> Form Validation Class Initialized
INFO - 2024-03-21 12:03:13 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:03:13 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:03:13 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:03:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:03:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:03:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:03:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:03:13 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:03:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:03:13 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:03:14 --> Final output sent to browser
DEBUG - 2024-03-21 12:03:14 --> Total execution time: 0.9050
INFO - 2024-03-21 12:04:51 --> Config Class Initialized
INFO - 2024-03-21 12:04:51 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:04:51 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:04:51 --> Utf8 Class Initialized
INFO - 2024-03-21 12:04:51 --> URI Class Initialized
INFO - 2024-03-21 12:04:51 --> Router Class Initialized
INFO - 2024-03-21 12:04:51 --> Output Class Initialized
INFO - 2024-03-21 12:04:51 --> Security Class Initialized
DEBUG - 2024-03-21 12:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:04:51 --> Input Class Initialized
INFO - 2024-03-21 12:04:51 --> Language Class Initialized
INFO - 2024-03-21 12:04:51 --> Loader Class Initialized
INFO - 2024-03-21 12:04:51 --> Helper loaded: url_helper
INFO - 2024-03-21 12:04:51 --> Helper loaded: file_helper
INFO - 2024-03-21 12:04:51 --> Helper loaded: form_helper
INFO - 2024-03-21 12:04:51 --> Helper loaded: general_helper
INFO - 2024-03-21 12:04:51 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:04:51 --> Controller Class Initialized
INFO - 2024-03-21 12:04:51 --> Form Validation Class Initialized
INFO - 2024-03-21 12:04:51 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:04:51 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:04:51 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:04:51 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:04:51 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:04:51 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:04:51 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:04:51 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:04:51 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:04:51 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:04:52 --> Final output sent to browser
DEBUG - 2024-03-21 12:04:52 --> Total execution time: 0.8745
INFO - 2024-03-21 12:05:14 --> Config Class Initialized
INFO - 2024-03-21 12:05:14 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:05:14 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:05:14 --> Utf8 Class Initialized
INFO - 2024-03-21 12:05:14 --> URI Class Initialized
INFO - 2024-03-21 12:05:14 --> Router Class Initialized
INFO - 2024-03-21 12:05:14 --> Output Class Initialized
INFO - 2024-03-21 12:05:14 --> Security Class Initialized
DEBUG - 2024-03-21 12:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:05:14 --> Input Class Initialized
INFO - 2024-03-21 12:05:14 --> Language Class Initialized
INFO - 2024-03-21 12:05:14 --> Loader Class Initialized
INFO - 2024-03-21 12:05:14 --> Helper loaded: url_helper
INFO - 2024-03-21 12:05:14 --> Helper loaded: file_helper
INFO - 2024-03-21 12:05:14 --> Helper loaded: form_helper
INFO - 2024-03-21 12:05:14 --> Helper loaded: general_helper
INFO - 2024-03-21 12:05:14 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:05:14 --> Controller Class Initialized
INFO - 2024-03-21 12:05:14 --> Form Validation Class Initialized
INFO - 2024-03-21 12:05:14 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:05:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:05:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:05:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:05:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:05:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:05:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/print_form.php
INFO - 2024-03-21 12:05:14 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/index.php
INFO - 2024-03-21 12:05:14 --> Final output sent to browser
DEBUG - 2024-03-21 12:05:14 --> Total execution time: 0.0324
INFO - 2024-03-21 12:05:14 --> Config Class Initialized
INFO - 2024-03-21 12:05:14 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:05:14 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:05:14 --> Utf8 Class Initialized
INFO - 2024-03-21 12:05:14 --> URI Class Initialized
INFO - 2024-03-21 12:05:14 --> Router Class Initialized
INFO - 2024-03-21 12:05:14 --> Output Class Initialized
INFO - 2024-03-21 12:05:14 --> Security Class Initialized
DEBUG - 2024-03-21 12:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:05:14 --> Input Class Initialized
INFO - 2024-03-21 12:05:14 --> Language Class Initialized
INFO - 2024-03-21 12:05:14 --> Loader Class Initialized
INFO - 2024-03-21 12:05:14 --> Helper loaded: url_helper
INFO - 2024-03-21 12:05:14 --> Helper loaded: file_helper
INFO - 2024-03-21 12:05:14 --> Helper loaded: form_helper
INFO - 2024-03-21 12:05:14 --> Helper loaded: general_helper
INFO - 2024-03-21 12:05:14 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:05:14 --> Controller Class Initialized
INFO - 2024-03-21 12:05:14 --> Form Validation Class Initialized
INFO - 2024-03-21 12:05:14 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:05:14 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:05:29 --> Config Class Initialized
INFO - 2024-03-21 12:05:29 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:05:29 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:05:29 --> Utf8 Class Initialized
INFO - 2024-03-21 12:05:29 --> URI Class Initialized
INFO - 2024-03-21 12:05:29 --> Router Class Initialized
INFO - 2024-03-21 12:05:29 --> Output Class Initialized
INFO - 2024-03-21 12:05:29 --> Security Class Initialized
DEBUG - 2024-03-21 12:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:05:29 --> Input Class Initialized
INFO - 2024-03-21 12:05:29 --> Language Class Initialized
INFO - 2024-03-21 12:05:29 --> Loader Class Initialized
INFO - 2024-03-21 12:05:29 --> Helper loaded: url_helper
INFO - 2024-03-21 12:05:29 --> Helper loaded: file_helper
INFO - 2024-03-21 12:05:29 --> Helper loaded: form_helper
INFO - 2024-03-21 12:05:29 --> Helper loaded: general_helper
INFO - 2024-03-21 12:05:29 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:05:29 --> Controller Class Initialized
INFO - 2024-03-21 12:05:29 --> Form Validation Class Initialized
INFO - 2024-03-21 12:05:29 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:05:29 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:05:29 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:05:29 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:05:29 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:05:29 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:05:29 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:05:29 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:05:29 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:05:29 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:05:29 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-21 12:05:30 --> Final output sent to browser
DEBUG - 2024-03-21 12:05:30 --> Total execution time: 0.4948
INFO - 2024-03-21 12:05:59 --> Config Class Initialized
INFO - 2024-03-21 12:05:59 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:05:59 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:05:59 --> Utf8 Class Initialized
INFO - 2024-03-21 12:05:59 --> URI Class Initialized
INFO - 2024-03-21 12:05:59 --> Router Class Initialized
INFO - 2024-03-21 12:05:59 --> Output Class Initialized
INFO - 2024-03-21 12:05:59 --> Security Class Initialized
DEBUG - 2024-03-21 12:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:05:59 --> Input Class Initialized
INFO - 2024-03-21 12:05:59 --> Language Class Initialized
INFO - 2024-03-21 12:05:59 --> Loader Class Initialized
INFO - 2024-03-21 12:05:59 --> Helper loaded: url_helper
INFO - 2024-03-21 12:05:59 --> Helper loaded: file_helper
INFO - 2024-03-21 12:05:59 --> Helper loaded: form_helper
INFO - 2024-03-21 12:05:59 --> Helper loaded: general_helper
INFO - 2024-03-21 12:05:59 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:05:59 --> Controller Class Initialized
INFO - 2024-03-21 12:05:59 --> Form Validation Class Initialized
INFO - 2024-03-21 12:05:59 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:05:59 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:05:59 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:05:59 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:05:59 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:05:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:05:59 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:05:59 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:05:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:05:59 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:05:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/orders/order_print.php
INFO - 2024-03-21 12:05:59 --> Final output sent to browser
DEBUG - 2024-03-21 12:05:59 --> Total execution time: 0.5764
INFO - 2024-03-21 12:06:17 --> Config Class Initialized
INFO - 2024-03-21 12:06:17 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:06:17 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:06:17 --> Utf8 Class Initialized
INFO - 2024-03-21 12:06:17 --> URI Class Initialized
INFO - 2024-03-21 12:06:17 --> Router Class Initialized
INFO - 2024-03-21 12:06:17 --> Output Class Initialized
INFO - 2024-03-21 12:06:17 --> Security Class Initialized
DEBUG - 2024-03-21 12:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:06:17 --> Input Class Initialized
INFO - 2024-03-21 12:06:17 --> Language Class Initialized
INFO - 2024-03-21 12:06:17 --> Loader Class Initialized
INFO - 2024-03-21 12:06:17 --> Helper loaded: url_helper
INFO - 2024-03-21 12:06:17 --> Helper loaded: file_helper
INFO - 2024-03-21 12:06:17 --> Helper loaded: form_helper
INFO - 2024-03-21 12:06:17 --> Helper loaded: general_helper
INFO - 2024-03-21 12:06:17 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:06:17 --> Controller Class Initialized
INFO - 2024-03-21 12:06:17 --> Form Validation Class Initialized
INFO - 2024-03-21 12:06:17 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:06:17 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:06:17 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:06:17 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:06:17 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:06:17 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:06:17 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:06:17 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:06:17 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:06:17 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/topbar.php
INFO - 2024-03-21 12:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:06:17 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/dashboard.php
INFO - 2024-03-21 12:06:17 --> Final output sent to browser
DEBUG - 2024-03-21 12:06:17 --> Total execution time: 0.0337
INFO - 2024-03-21 12:06:18 --> Config Class Initialized
INFO - 2024-03-21 12:06:18 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:06:18 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:06:18 --> Utf8 Class Initialized
INFO - 2024-03-21 12:06:18 --> URI Class Initialized
INFO - 2024-03-21 12:06:18 --> Router Class Initialized
INFO - 2024-03-21 12:06:18 --> Output Class Initialized
INFO - 2024-03-21 12:06:18 --> Security Class Initialized
DEBUG - 2024-03-21 12:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:06:18 --> Input Class Initialized
INFO - 2024-03-21 12:06:18 --> Language Class Initialized
INFO - 2024-03-21 12:06:18 --> Loader Class Initialized
INFO - 2024-03-21 12:06:18 --> Helper loaded: url_helper
INFO - 2024-03-21 12:06:18 --> Helper loaded: file_helper
INFO - 2024-03-21 12:06:18 --> Helper loaded: form_helper
INFO - 2024-03-21 12:06:18 --> Helper loaded: general_helper
INFO - 2024-03-21 12:06:18 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:06:18 --> Controller Class Initialized
INFO - 2024-03-21 12:06:18 --> Form Validation Class Initialized
INFO - 2024-03-21 12:06:18 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:06:18 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:06:18 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:06:18 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:06:18 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:06:18 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:06:18 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:06:18 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:06:18 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:06:18 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:06:23 --> Config Class Initialized
INFO - 2024-03-21 12:06:23 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:06:23 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:06:23 --> Utf8 Class Initialized
INFO - 2024-03-21 12:06:23 --> URI Class Initialized
INFO - 2024-03-21 12:06:23 --> Router Class Initialized
INFO - 2024-03-21 12:06:23 --> Output Class Initialized
INFO - 2024-03-21 12:06:23 --> Security Class Initialized
DEBUG - 2024-03-21 12:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:06:23 --> Input Class Initialized
INFO - 2024-03-21 12:06:23 --> Language Class Initialized
INFO - 2024-03-21 12:06:23 --> Loader Class Initialized
INFO - 2024-03-21 12:06:23 --> Helper loaded: url_helper
INFO - 2024-03-21 12:06:23 --> Helper loaded: file_helper
INFO - 2024-03-21 12:06:23 --> Helper loaded: form_helper
INFO - 2024-03-21 12:06:23 --> Helper loaded: general_helper
INFO - 2024-03-21 12:06:23 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:06:23 --> Controller Class Initialized
INFO - 2024-03-21 12:06:23 --> Form Validation Class Initialized
INFO - 2024-03-21 12:06:23 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:06:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:06:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:06:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:06:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:06:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:06:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 12:06:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_print_form.php
INFO - 2024-03-21 12:06:23 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 12:06:23 --> Final output sent to browser
DEBUG - 2024-03-21 12:06:23 --> Total execution time: 0.0337
INFO - 2024-03-21 12:06:23 --> Config Class Initialized
INFO - 2024-03-21 12:06:23 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:06:23 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:06:23 --> Utf8 Class Initialized
INFO - 2024-03-21 12:06:23 --> URI Class Initialized
INFO - 2024-03-21 12:06:23 --> Router Class Initialized
INFO - 2024-03-21 12:06:23 --> Output Class Initialized
INFO - 2024-03-21 12:06:23 --> Security Class Initialized
DEBUG - 2024-03-21 12:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:06:23 --> Input Class Initialized
INFO - 2024-03-21 12:06:23 --> Language Class Initialized
INFO - 2024-03-21 12:06:23 --> Loader Class Initialized
INFO - 2024-03-21 12:06:23 --> Helper loaded: url_helper
INFO - 2024-03-21 12:06:23 --> Helper loaded: file_helper
INFO - 2024-03-21 12:06:23 --> Helper loaded: form_helper
INFO - 2024-03-21 12:06:23 --> Helper loaded: general_helper
INFO - 2024-03-21 12:06:23 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:06:23 --> Controller Class Initialized
INFO - 2024-03-21 12:06:23 --> Form Validation Class Initialized
INFO - 2024-03-21 12:06:23 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:06:23 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:06:26 --> Config Class Initialized
INFO - 2024-03-21 12:06:26 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:06:26 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:06:26 --> Utf8 Class Initialized
INFO - 2024-03-21 12:06:26 --> URI Class Initialized
INFO - 2024-03-21 12:06:26 --> Router Class Initialized
INFO - 2024-03-21 12:06:26 --> Output Class Initialized
INFO - 2024-03-21 12:06:26 --> Security Class Initialized
DEBUG - 2024-03-21 12:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:06:26 --> Input Class Initialized
INFO - 2024-03-21 12:06:26 --> Language Class Initialized
INFO - 2024-03-21 12:06:26 --> Loader Class Initialized
INFO - 2024-03-21 12:06:26 --> Helper loaded: url_helper
INFO - 2024-03-21 12:06:26 --> Helper loaded: file_helper
INFO - 2024-03-21 12:06:26 --> Helper loaded: form_helper
INFO - 2024-03-21 12:06:26 --> Helper loaded: general_helper
INFO - 2024-03-21 12:06:26 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:06:26 --> Controller Class Initialized
INFO - 2024-03-21 12:06:26 --> Form Validation Class Initialized
INFO - 2024-03-21 12:06:26 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:06:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:06:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:06:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:06:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:06:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:06:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:06:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:06:26 --> Final output sent to browser
DEBUG - 2024-03-21 12:06:26 --> Total execution time: 0.0302
INFO - 2024-03-21 12:06:26 --> Config Class Initialized
INFO - 2024-03-21 12:06:26 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:06:26 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:06:26 --> Utf8 Class Initialized
INFO - 2024-03-21 12:06:26 --> URI Class Initialized
INFO - 2024-03-21 12:06:26 --> Router Class Initialized
INFO - 2024-03-21 12:06:26 --> Output Class Initialized
INFO - 2024-03-21 12:06:26 --> Security Class Initialized
DEBUG - 2024-03-21 12:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:06:26 --> Input Class Initialized
INFO - 2024-03-21 12:06:26 --> Language Class Initialized
INFO - 2024-03-21 12:06:26 --> Loader Class Initialized
INFO - 2024-03-21 12:06:26 --> Helper loaded: url_helper
INFO - 2024-03-21 12:06:26 --> Helper loaded: file_helper
INFO - 2024-03-21 12:06:26 --> Helper loaded: form_helper
INFO - 2024-03-21 12:06:26 --> Helper loaded: general_helper
INFO - 2024-03-21 12:06:26 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:06:26 --> Controller Class Initialized
INFO - 2024-03-21 12:06:26 --> Form Validation Class Initialized
INFO - 2024-03-21 12:06:26 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:06:26 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:06:30 --> Config Class Initialized
INFO - 2024-03-21 12:06:30 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:06:30 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:06:30 --> Utf8 Class Initialized
INFO - 2024-03-21 12:06:30 --> URI Class Initialized
INFO - 2024-03-21 12:06:30 --> Router Class Initialized
INFO - 2024-03-21 12:06:30 --> Output Class Initialized
INFO - 2024-03-21 12:06:30 --> Security Class Initialized
DEBUG - 2024-03-21 12:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:06:30 --> Input Class Initialized
INFO - 2024-03-21 12:06:30 --> Language Class Initialized
INFO - 2024-03-21 12:06:30 --> Loader Class Initialized
INFO - 2024-03-21 12:06:30 --> Helper loaded: url_helper
INFO - 2024-03-21 12:06:30 --> Helper loaded: file_helper
INFO - 2024-03-21 12:06:30 --> Helper loaded: form_helper
INFO - 2024-03-21 12:06:30 --> Helper loaded: general_helper
INFO - 2024-03-21 12:06:30 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:06:30 --> Controller Class Initialized
INFO - 2024-03-21 12:06:30 --> Form Validation Class Initialized
INFO - 2024-03-21 12:06:30 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:06:30 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:06:30 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:06:30 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:06:30 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:06:30 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:06:30 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:06:30 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:06:30 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:06:30 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:06:34 --> Config Class Initialized
INFO - 2024-03-21 12:06:34 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:06:34 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:06:34 --> Utf8 Class Initialized
INFO - 2024-03-21 12:06:34 --> URI Class Initialized
INFO - 2024-03-21 12:06:34 --> Router Class Initialized
INFO - 2024-03-21 12:06:34 --> Output Class Initialized
INFO - 2024-03-21 12:06:34 --> Security Class Initialized
DEBUG - 2024-03-21 12:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:06:34 --> Input Class Initialized
INFO - 2024-03-21 12:06:34 --> Language Class Initialized
INFO - 2024-03-21 12:06:34 --> Loader Class Initialized
INFO - 2024-03-21 12:06:34 --> Helper loaded: url_helper
INFO - 2024-03-21 12:06:34 --> Helper loaded: file_helper
INFO - 2024-03-21 12:06:34 --> Helper loaded: form_helper
INFO - 2024-03-21 12:06:34 --> Helper loaded: general_helper
INFO - 2024-03-21 12:06:34 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:06:34 --> Controller Class Initialized
INFO - 2024-03-21 12:06:34 --> Form Validation Class Initialized
INFO - 2024-03-21 12:06:34 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:06:34 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:06:34 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:06:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:06:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:06:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:06:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:06:34 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:06:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:06:34 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:06:54 --> Config Class Initialized
INFO - 2024-03-21 12:06:54 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:06:54 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:06:54 --> Utf8 Class Initialized
INFO - 2024-03-21 12:06:54 --> URI Class Initialized
INFO - 2024-03-21 12:06:54 --> Router Class Initialized
INFO - 2024-03-21 12:06:54 --> Output Class Initialized
INFO - 2024-03-21 12:06:54 --> Security Class Initialized
DEBUG - 2024-03-21 12:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:06:54 --> Input Class Initialized
INFO - 2024-03-21 12:06:54 --> Language Class Initialized
INFO - 2024-03-21 12:06:54 --> Loader Class Initialized
INFO - 2024-03-21 12:06:54 --> Helper loaded: url_helper
INFO - 2024-03-21 12:06:54 --> Helper loaded: file_helper
INFO - 2024-03-21 12:06:54 --> Helper loaded: form_helper
INFO - 2024-03-21 12:06:54 --> Helper loaded: general_helper
INFO - 2024-03-21 12:06:54 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:06:54 --> Controller Class Initialized
INFO - 2024-03-21 12:06:54 --> Form Validation Class Initialized
INFO - 2024-03-21 12:06:54 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:06:54 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:06:54 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:06:54 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:06:54 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:06:54 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:06:54 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:06:54 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:06:54 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:06:54 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:07:34 --> Config Class Initialized
INFO - 2024-03-21 12:07:34 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:07:34 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:07:34 --> Utf8 Class Initialized
INFO - 2024-03-21 12:07:34 --> URI Class Initialized
INFO - 2024-03-21 12:07:34 --> Router Class Initialized
INFO - 2024-03-21 12:07:34 --> Output Class Initialized
INFO - 2024-03-21 12:07:34 --> Security Class Initialized
DEBUG - 2024-03-21 12:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:07:34 --> Input Class Initialized
INFO - 2024-03-21 12:07:34 --> Language Class Initialized
INFO - 2024-03-21 12:07:34 --> Loader Class Initialized
INFO - 2024-03-21 12:07:34 --> Helper loaded: url_helper
INFO - 2024-03-21 12:07:34 --> Helper loaded: file_helper
INFO - 2024-03-21 12:07:34 --> Helper loaded: form_helper
INFO - 2024-03-21 12:07:34 --> Helper loaded: general_helper
INFO - 2024-03-21 12:07:34 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:07:34 --> Controller Class Initialized
INFO - 2024-03-21 12:07:34 --> Form Validation Class Initialized
INFO - 2024-03-21 12:07:34 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:07:34 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:07:34 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:07:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:07:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:07:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:07:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:07:34 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:07:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:07:34 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:07:37 --> Config Class Initialized
INFO - 2024-03-21 12:07:37 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:07:37 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:07:37 --> Utf8 Class Initialized
INFO - 2024-03-21 12:07:37 --> URI Class Initialized
INFO - 2024-03-21 12:07:37 --> Router Class Initialized
INFO - 2024-03-21 12:07:37 --> Output Class Initialized
INFO - 2024-03-21 12:07:37 --> Security Class Initialized
DEBUG - 2024-03-21 12:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:07:37 --> Input Class Initialized
INFO - 2024-03-21 12:07:37 --> Language Class Initialized
INFO - 2024-03-21 12:07:37 --> Loader Class Initialized
INFO - 2024-03-21 12:07:37 --> Helper loaded: url_helper
INFO - 2024-03-21 12:07:37 --> Helper loaded: file_helper
INFO - 2024-03-21 12:07:37 --> Helper loaded: form_helper
INFO - 2024-03-21 12:07:37 --> Helper loaded: general_helper
INFO - 2024-03-21 12:07:37 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:07:37 --> Controller Class Initialized
INFO - 2024-03-21 12:07:37 --> Form Validation Class Initialized
INFO - 2024-03-21 12:07:37 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:07:37 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:07:37 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:07:37 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:07:37 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:07:37 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:07:37 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:07:37 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:07:37 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:07:37 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:07:44 --> Config Class Initialized
INFO - 2024-03-21 12:07:44 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:07:44 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:07:44 --> Utf8 Class Initialized
INFO - 2024-03-21 12:07:44 --> URI Class Initialized
INFO - 2024-03-21 12:07:44 --> Router Class Initialized
INFO - 2024-03-21 12:07:44 --> Output Class Initialized
INFO - 2024-03-21 12:07:44 --> Security Class Initialized
DEBUG - 2024-03-21 12:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:07:44 --> Input Class Initialized
INFO - 2024-03-21 12:07:44 --> Language Class Initialized
INFO - 2024-03-21 12:07:44 --> Loader Class Initialized
INFO - 2024-03-21 12:07:44 --> Helper loaded: url_helper
INFO - 2024-03-21 12:07:44 --> Helper loaded: file_helper
INFO - 2024-03-21 12:07:44 --> Helper loaded: form_helper
INFO - 2024-03-21 12:07:44 --> Helper loaded: general_helper
INFO - 2024-03-21 12:07:44 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:07:44 --> Controller Class Initialized
INFO - 2024-03-21 12:07:44 --> Form Validation Class Initialized
INFO - 2024-03-21 12:07:44 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:07:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:07:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:07:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:07:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:07:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:07:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 12:07:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_print_form.php
INFO - 2024-03-21 12:07:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 12:07:44 --> Final output sent to browser
DEBUG - 2024-03-21 12:07:44 --> Total execution time: 0.0360
INFO - 2024-03-21 12:07:44 --> Config Class Initialized
INFO - 2024-03-21 12:07:44 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:07:44 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:07:44 --> Utf8 Class Initialized
INFO - 2024-03-21 12:07:44 --> URI Class Initialized
INFO - 2024-03-21 12:07:44 --> Router Class Initialized
INFO - 2024-03-21 12:07:44 --> Output Class Initialized
INFO - 2024-03-21 12:07:44 --> Security Class Initialized
DEBUG - 2024-03-21 12:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:07:44 --> Input Class Initialized
INFO - 2024-03-21 12:07:44 --> Language Class Initialized
INFO - 2024-03-21 12:07:44 --> Loader Class Initialized
INFO - 2024-03-21 12:07:44 --> Helper loaded: url_helper
INFO - 2024-03-21 12:07:44 --> Helper loaded: file_helper
INFO - 2024-03-21 12:07:44 --> Helper loaded: form_helper
INFO - 2024-03-21 12:07:44 --> Helper loaded: general_helper
INFO - 2024-03-21 12:07:44 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:07:44 --> Controller Class Initialized
INFO - 2024-03-21 12:07:44 --> Form Validation Class Initialized
INFO - 2024-03-21 12:07:44 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:07:44 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:07:48 --> Config Class Initialized
INFO - 2024-03-21 12:07:48 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:07:48 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:07:48 --> Utf8 Class Initialized
INFO - 2024-03-21 12:07:48 --> URI Class Initialized
INFO - 2024-03-21 12:07:48 --> Router Class Initialized
INFO - 2024-03-21 12:07:48 --> Output Class Initialized
INFO - 2024-03-21 12:07:48 --> Security Class Initialized
DEBUG - 2024-03-21 12:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:07:48 --> Input Class Initialized
INFO - 2024-03-21 12:07:48 --> Language Class Initialized
INFO - 2024-03-21 12:07:48 --> Loader Class Initialized
INFO - 2024-03-21 12:07:48 --> Helper loaded: url_helper
INFO - 2024-03-21 12:07:48 --> Helper loaded: file_helper
INFO - 2024-03-21 12:07:48 --> Helper loaded: form_helper
INFO - 2024-03-21 12:07:48 --> Helper loaded: general_helper
INFO - 2024-03-21 12:07:48 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:07:48 --> Controller Class Initialized
INFO - 2024-03-21 12:07:48 --> Form Validation Class Initialized
INFO - 2024-03-21 12:07:48 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:07:48 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:07:48 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:07:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:07:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:07:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:07:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:07:48 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:07:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:07:48 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:07:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:07:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:07:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:07:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:07:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:07:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:07:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:07:48 --> Final output sent to browser
DEBUG - 2024-03-21 12:07:48 --> Total execution time: 0.0323
INFO - 2024-03-21 12:07:49 --> Config Class Initialized
INFO - 2024-03-21 12:07:49 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:07:49 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:07:49 --> Utf8 Class Initialized
INFO - 2024-03-21 12:07:49 --> URI Class Initialized
INFO - 2024-03-21 12:07:49 --> Router Class Initialized
INFO - 2024-03-21 12:07:49 --> Output Class Initialized
INFO - 2024-03-21 12:07:49 --> Security Class Initialized
DEBUG - 2024-03-21 12:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:07:49 --> Input Class Initialized
INFO - 2024-03-21 12:07:49 --> Language Class Initialized
INFO - 2024-03-21 12:07:49 --> Loader Class Initialized
INFO - 2024-03-21 12:07:49 --> Helper loaded: url_helper
INFO - 2024-03-21 12:07:49 --> Helper loaded: file_helper
INFO - 2024-03-21 12:07:49 --> Helper loaded: form_helper
INFO - 2024-03-21 12:07:49 --> Helper loaded: general_helper
INFO - 2024-03-21 12:07:49 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:07:49 --> Controller Class Initialized
INFO - 2024-03-21 12:07:49 --> Form Validation Class Initialized
INFO - 2024-03-21 12:07:49 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:07:49 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:07:49 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:07:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:07:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:07:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:07:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:07:49 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:07:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:07:49 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:08:10 --> Config Class Initialized
INFO - 2024-03-21 12:08:10 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:08:10 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:08:10 --> Utf8 Class Initialized
INFO - 2024-03-21 12:08:10 --> URI Class Initialized
INFO - 2024-03-21 12:08:10 --> Router Class Initialized
INFO - 2024-03-21 12:08:10 --> Output Class Initialized
INFO - 2024-03-21 12:08:10 --> Security Class Initialized
DEBUG - 2024-03-21 12:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:08:10 --> Input Class Initialized
INFO - 2024-03-21 12:08:10 --> Language Class Initialized
INFO - 2024-03-21 12:08:10 --> Loader Class Initialized
INFO - 2024-03-21 12:08:10 --> Helper loaded: url_helper
INFO - 2024-03-21 12:08:10 --> Helper loaded: file_helper
INFO - 2024-03-21 12:08:10 --> Helper loaded: form_helper
INFO - 2024-03-21 12:08:10 --> Helper loaded: general_helper
INFO - 2024-03-21 12:08:10 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:08:10 --> Controller Class Initialized
INFO - 2024-03-21 12:08:10 --> Form Validation Class Initialized
INFO - 2024-03-21 12:08:10 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:08:10 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:08:10 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:08:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:08:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:08:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:08:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:08:10 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:08:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:08:10 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:08:12 --> Config Class Initialized
INFO - 2024-03-21 12:08:12 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:08:12 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:08:12 --> Utf8 Class Initialized
INFO - 2024-03-21 12:08:12 --> URI Class Initialized
INFO - 2024-03-21 12:08:12 --> Router Class Initialized
INFO - 2024-03-21 12:08:12 --> Output Class Initialized
INFO - 2024-03-21 12:08:12 --> Security Class Initialized
DEBUG - 2024-03-21 12:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:08:12 --> Input Class Initialized
INFO - 2024-03-21 12:08:12 --> Language Class Initialized
INFO - 2024-03-21 12:08:12 --> Loader Class Initialized
INFO - 2024-03-21 12:08:12 --> Helper loaded: url_helper
INFO - 2024-03-21 12:08:12 --> Helper loaded: file_helper
INFO - 2024-03-21 12:08:12 --> Helper loaded: form_helper
INFO - 2024-03-21 12:08:12 --> Helper loaded: general_helper
INFO - 2024-03-21 12:08:12 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:08:12 --> Controller Class Initialized
INFO - 2024-03-21 12:08:12 --> Form Validation Class Initialized
INFO - 2024-03-21 12:08:12 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:08:12 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:08:12 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:08:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:08:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:08:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:08:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:08:12 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:08:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:08:12 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:41:28 --> Config Class Initialized
INFO - 2024-03-21 12:41:28 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:41:28 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:41:28 --> Utf8 Class Initialized
INFO - 2024-03-21 12:41:28 --> URI Class Initialized
INFO - 2024-03-21 12:41:28 --> Router Class Initialized
INFO - 2024-03-21 12:41:28 --> Output Class Initialized
INFO - 2024-03-21 12:41:28 --> Security Class Initialized
DEBUG - 2024-03-21 12:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:41:28 --> Input Class Initialized
INFO - 2024-03-21 12:41:28 --> Language Class Initialized
INFO - 2024-03-21 12:41:28 --> Loader Class Initialized
INFO - 2024-03-21 12:41:28 --> Helper loaded: url_helper
INFO - 2024-03-21 12:41:28 --> Helper loaded: file_helper
INFO - 2024-03-21 12:41:28 --> Helper loaded: form_helper
INFO - 2024-03-21 12:41:28 --> Helper loaded: general_helper
INFO - 2024-03-21 12:41:28 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:41:28 --> Controller Class Initialized
INFO - 2024-03-21 12:41:28 --> Form Validation Class Initialized
INFO - 2024-03-21 12:41:28 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:41:28 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:41:28 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:41:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:41:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:41:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:41:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:41:28 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:41:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:41:28 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:42:26 --> Config Class Initialized
INFO - 2024-03-21 12:42:26 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:42:26 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:42:26 --> Utf8 Class Initialized
INFO - 2024-03-21 12:42:26 --> URI Class Initialized
INFO - 2024-03-21 12:42:26 --> Router Class Initialized
INFO - 2024-03-21 12:42:26 --> Output Class Initialized
INFO - 2024-03-21 12:42:26 --> Security Class Initialized
DEBUG - 2024-03-21 12:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:42:26 --> Input Class Initialized
INFO - 2024-03-21 12:42:26 --> Language Class Initialized
INFO - 2024-03-21 12:42:26 --> Loader Class Initialized
INFO - 2024-03-21 12:42:26 --> Helper loaded: url_helper
INFO - 2024-03-21 12:42:26 --> Helper loaded: file_helper
INFO - 2024-03-21 12:42:26 --> Helper loaded: form_helper
INFO - 2024-03-21 12:42:26 --> Helper loaded: general_helper
INFO - 2024-03-21 12:42:26 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:42:26 --> Controller Class Initialized
INFO - 2024-03-21 12:42:26 --> Form Validation Class Initialized
INFO - 2024-03-21 12:42:26 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:42:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:42:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:42:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:42:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:42:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:42:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:42:26 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:42:26 --> Final output sent to browser
DEBUG - 2024-03-21 12:42:26 --> Total execution time: 0.0356
INFO - 2024-03-21 12:42:26 --> Config Class Initialized
INFO - 2024-03-21 12:42:26 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:42:26 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:42:26 --> Utf8 Class Initialized
INFO - 2024-03-21 12:42:26 --> URI Class Initialized
INFO - 2024-03-21 12:42:26 --> Router Class Initialized
INFO - 2024-03-21 12:42:26 --> Output Class Initialized
INFO - 2024-03-21 12:42:26 --> Security Class Initialized
DEBUG - 2024-03-21 12:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:42:26 --> Input Class Initialized
INFO - 2024-03-21 12:42:26 --> Language Class Initialized
INFO - 2024-03-21 12:42:26 --> Loader Class Initialized
INFO - 2024-03-21 12:42:26 --> Helper loaded: url_helper
INFO - 2024-03-21 12:42:26 --> Helper loaded: file_helper
INFO - 2024-03-21 12:42:26 --> Helper loaded: form_helper
INFO - 2024-03-21 12:42:26 --> Helper loaded: general_helper
INFO - 2024-03-21 12:42:26 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:42:26 --> Controller Class Initialized
INFO - 2024-03-21 12:42:26 --> Form Validation Class Initialized
INFO - 2024-03-21 12:42:26 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:42:26 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:42:58 --> Config Class Initialized
INFO - 2024-03-21 12:42:58 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:42:58 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:42:58 --> Utf8 Class Initialized
INFO - 2024-03-21 12:42:58 --> URI Class Initialized
INFO - 2024-03-21 12:42:58 --> Router Class Initialized
INFO - 2024-03-21 12:42:58 --> Output Class Initialized
INFO - 2024-03-21 12:42:58 --> Security Class Initialized
DEBUG - 2024-03-21 12:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:42:58 --> Input Class Initialized
INFO - 2024-03-21 12:42:58 --> Language Class Initialized
INFO - 2024-03-21 12:42:58 --> Loader Class Initialized
INFO - 2024-03-21 12:42:58 --> Helper loaded: url_helper
INFO - 2024-03-21 12:42:58 --> Helper loaded: file_helper
INFO - 2024-03-21 12:42:58 --> Helper loaded: form_helper
INFO - 2024-03-21 12:42:58 --> Helper loaded: general_helper
INFO - 2024-03-21 12:42:58 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:42:58 --> Controller Class Initialized
INFO - 2024-03-21 12:42:58 --> Form Validation Class Initialized
INFO - 2024-03-21 12:42:58 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:42:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:42:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:42:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:42:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:42:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:42:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:42:58 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:42:58 --> Final output sent to browser
DEBUG - 2024-03-21 12:42:58 --> Total execution time: 0.0397
INFO - 2024-03-21 12:42:58 --> Config Class Initialized
INFO - 2024-03-21 12:42:58 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:42:58 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:42:58 --> Utf8 Class Initialized
INFO - 2024-03-21 12:42:58 --> URI Class Initialized
INFO - 2024-03-21 12:42:58 --> Router Class Initialized
INFO - 2024-03-21 12:42:58 --> Output Class Initialized
INFO - 2024-03-21 12:42:58 --> Security Class Initialized
DEBUG - 2024-03-21 12:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:42:58 --> Input Class Initialized
INFO - 2024-03-21 12:42:58 --> Language Class Initialized
INFO - 2024-03-21 12:42:58 --> Loader Class Initialized
INFO - 2024-03-21 12:42:58 --> Helper loaded: url_helper
INFO - 2024-03-21 12:42:58 --> Helper loaded: file_helper
INFO - 2024-03-21 12:42:58 --> Helper loaded: form_helper
INFO - 2024-03-21 12:42:58 --> Helper loaded: general_helper
INFO - 2024-03-21 12:42:58 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:42:58 --> Controller Class Initialized
INFO - 2024-03-21 12:42:58 --> Form Validation Class Initialized
INFO - 2024-03-21 12:42:58 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:42:58 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:44:09 --> Config Class Initialized
INFO - 2024-03-21 12:44:09 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:44:09 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:44:09 --> Utf8 Class Initialized
INFO - 2024-03-21 12:44:09 --> URI Class Initialized
INFO - 2024-03-21 12:44:09 --> Router Class Initialized
INFO - 2024-03-21 12:44:09 --> Output Class Initialized
INFO - 2024-03-21 12:44:09 --> Security Class Initialized
DEBUG - 2024-03-21 12:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:44:09 --> Input Class Initialized
INFO - 2024-03-21 12:44:09 --> Language Class Initialized
INFO - 2024-03-21 12:44:09 --> Loader Class Initialized
INFO - 2024-03-21 12:44:09 --> Helper loaded: url_helper
INFO - 2024-03-21 12:44:09 --> Helper loaded: file_helper
INFO - 2024-03-21 12:44:09 --> Helper loaded: form_helper
INFO - 2024-03-21 12:44:09 --> Helper loaded: general_helper
INFO - 2024-03-21 12:44:09 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:44:09 --> Controller Class Initialized
INFO - 2024-03-21 12:44:09 --> Form Validation Class Initialized
INFO - 2024-03-21 12:44:09 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:44:09 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:44:09 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:44:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:44:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:44:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:44:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:44:09 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:44:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:44:09 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:44:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:44:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:44:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:44:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:44:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:44:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:44:09 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:44:09 --> Final output sent to browser
DEBUG - 2024-03-21 12:44:09 --> Total execution time: 0.0340
INFO - 2024-03-21 12:44:10 --> Config Class Initialized
INFO - 2024-03-21 12:44:10 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:44:10 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:44:10 --> Utf8 Class Initialized
INFO - 2024-03-21 12:44:10 --> URI Class Initialized
INFO - 2024-03-21 12:44:10 --> Router Class Initialized
INFO - 2024-03-21 12:44:10 --> Output Class Initialized
INFO - 2024-03-21 12:44:10 --> Security Class Initialized
DEBUG - 2024-03-21 12:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:44:10 --> Input Class Initialized
INFO - 2024-03-21 12:44:10 --> Language Class Initialized
INFO - 2024-03-21 12:44:10 --> Loader Class Initialized
INFO - 2024-03-21 12:44:10 --> Helper loaded: url_helper
INFO - 2024-03-21 12:44:10 --> Helper loaded: file_helper
INFO - 2024-03-21 12:44:10 --> Helper loaded: form_helper
INFO - 2024-03-21 12:44:10 --> Helper loaded: general_helper
INFO - 2024-03-21 12:44:10 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:44:10 --> Controller Class Initialized
INFO - 2024-03-21 12:44:10 --> Form Validation Class Initialized
INFO - 2024-03-21 12:44:10 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:44:10 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:44:10 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:44:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:44:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:44:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:44:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:44:10 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:44:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:44:10 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:44:33 --> Config Class Initialized
INFO - 2024-03-21 12:44:33 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:44:33 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:44:33 --> Utf8 Class Initialized
INFO - 2024-03-21 12:44:33 --> URI Class Initialized
INFO - 2024-03-21 12:44:33 --> Router Class Initialized
INFO - 2024-03-21 12:44:34 --> Output Class Initialized
INFO - 2024-03-21 12:44:34 --> Security Class Initialized
DEBUG - 2024-03-21 12:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:44:34 --> Input Class Initialized
INFO - 2024-03-21 12:44:34 --> Language Class Initialized
INFO - 2024-03-21 12:44:34 --> Loader Class Initialized
INFO - 2024-03-21 12:44:34 --> Helper loaded: url_helper
INFO - 2024-03-21 12:44:34 --> Helper loaded: file_helper
INFO - 2024-03-21 12:44:34 --> Helper loaded: form_helper
INFO - 2024-03-21 12:44:34 --> Helper loaded: general_helper
INFO - 2024-03-21 12:44:34 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:44:34 --> Controller Class Initialized
INFO - 2024-03-21 12:44:34 --> Form Validation Class Initialized
INFO - 2024-03-21 12:44:34 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:44:34 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:44:34 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:44:34 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:44:34 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:44:34 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:44:34 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:44:34 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:44:34 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:44:34 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:44:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:44:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:44:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:44:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:44:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:44:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:44:34 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:44:34 --> Final output sent to browser
DEBUG - 2024-03-21 12:44:34 --> Total execution time: 0.0372
INFO - 2024-03-21 12:44:35 --> Config Class Initialized
INFO - 2024-03-21 12:44:35 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:44:35 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:44:35 --> Utf8 Class Initialized
INFO - 2024-03-21 12:44:35 --> URI Class Initialized
INFO - 2024-03-21 12:44:35 --> Router Class Initialized
INFO - 2024-03-21 12:44:35 --> Output Class Initialized
INFO - 2024-03-21 12:44:35 --> Security Class Initialized
DEBUG - 2024-03-21 12:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:44:35 --> Input Class Initialized
INFO - 2024-03-21 12:44:35 --> Language Class Initialized
INFO - 2024-03-21 12:44:35 --> Loader Class Initialized
INFO - 2024-03-21 12:44:35 --> Helper loaded: url_helper
INFO - 2024-03-21 12:44:35 --> Helper loaded: file_helper
INFO - 2024-03-21 12:44:35 --> Helper loaded: form_helper
INFO - 2024-03-21 12:44:35 --> Helper loaded: general_helper
INFO - 2024-03-21 12:44:35 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:44:35 --> Controller Class Initialized
INFO - 2024-03-21 12:44:35 --> Form Validation Class Initialized
INFO - 2024-03-21 12:44:35 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:44:35 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:44:35 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:44:35 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:44:35 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:44:35 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:44:35 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:44:35 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:44:35 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:44:35 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:44:39 --> Config Class Initialized
INFO - 2024-03-21 12:44:39 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:44:39 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:44:39 --> Utf8 Class Initialized
INFO - 2024-03-21 12:44:39 --> URI Class Initialized
INFO - 2024-03-21 12:44:39 --> Router Class Initialized
INFO - 2024-03-21 12:44:39 --> Output Class Initialized
INFO - 2024-03-21 12:44:39 --> Security Class Initialized
DEBUG - 2024-03-21 12:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:44:39 --> Input Class Initialized
INFO - 2024-03-21 12:44:39 --> Language Class Initialized
INFO - 2024-03-21 12:44:39 --> Loader Class Initialized
INFO - 2024-03-21 12:44:39 --> Helper loaded: url_helper
INFO - 2024-03-21 12:44:39 --> Helper loaded: file_helper
INFO - 2024-03-21 12:44:39 --> Helper loaded: form_helper
INFO - 2024-03-21 12:44:39 --> Helper loaded: general_helper
INFO - 2024-03-21 12:44:39 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:44:39 --> Controller Class Initialized
INFO - 2024-03-21 12:44:39 --> Form Validation Class Initialized
INFO - 2024-03-21 12:44:39 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:44:39 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:44:39 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:44:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:44:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:44:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:44:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:44:39 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:44:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:44:39 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:44:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:44:39 --> Final output sent to browser
DEBUG - 2024-03-21 12:44:39 --> Total execution time: 0.0448
INFO - 2024-03-21 12:44:40 --> Config Class Initialized
INFO - 2024-03-21 12:44:40 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:44:40 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:44:40 --> Utf8 Class Initialized
INFO - 2024-03-21 12:44:40 --> URI Class Initialized
INFO - 2024-03-21 12:44:40 --> Router Class Initialized
INFO - 2024-03-21 12:44:40 --> Output Class Initialized
INFO - 2024-03-21 12:44:40 --> Security Class Initialized
DEBUG - 2024-03-21 12:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:44:40 --> Input Class Initialized
INFO - 2024-03-21 12:44:40 --> Language Class Initialized
INFO - 2024-03-21 12:44:40 --> Loader Class Initialized
INFO - 2024-03-21 12:44:40 --> Helper loaded: url_helper
INFO - 2024-03-21 12:44:40 --> Helper loaded: file_helper
INFO - 2024-03-21 12:44:40 --> Helper loaded: form_helper
INFO - 2024-03-21 12:44:40 --> Helper loaded: general_helper
INFO - 2024-03-21 12:44:40 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:44:40 --> Controller Class Initialized
INFO - 2024-03-21 12:44:40 --> Form Validation Class Initialized
INFO - 2024-03-21 12:44:40 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:44:40 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:44:40 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:44:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:44:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:44:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:44:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:44:40 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:44:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:44:40 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:44:44 --> Config Class Initialized
INFO - 2024-03-21 12:44:44 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:44:44 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:44:44 --> Utf8 Class Initialized
INFO - 2024-03-21 12:44:44 --> URI Class Initialized
INFO - 2024-03-21 12:44:44 --> Router Class Initialized
INFO - 2024-03-21 12:44:44 --> Output Class Initialized
INFO - 2024-03-21 12:44:44 --> Security Class Initialized
DEBUG - 2024-03-21 12:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:44:44 --> Input Class Initialized
INFO - 2024-03-21 12:44:44 --> Language Class Initialized
INFO - 2024-03-21 12:44:44 --> Loader Class Initialized
INFO - 2024-03-21 12:44:44 --> Helper loaded: url_helper
INFO - 2024-03-21 12:44:44 --> Helper loaded: file_helper
INFO - 2024-03-21 12:44:44 --> Helper loaded: form_helper
INFO - 2024-03-21 12:44:44 --> Helper loaded: general_helper
INFO - 2024-03-21 12:44:44 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:44:44 --> Controller Class Initialized
INFO - 2024-03-21 12:44:44 --> Form Validation Class Initialized
INFO - 2024-03-21 12:44:44 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:44:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:44:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:44:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:44:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:44:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:44:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:44:44 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:44:44 --> Final output sent to browser
DEBUG - 2024-03-21 12:44:44 --> Total execution time: 0.0329
INFO - 2024-03-21 12:44:44 --> Config Class Initialized
INFO - 2024-03-21 12:44:44 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:44:44 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:44:44 --> Utf8 Class Initialized
INFO - 2024-03-21 12:44:44 --> URI Class Initialized
INFO - 2024-03-21 12:44:44 --> Router Class Initialized
INFO - 2024-03-21 12:44:44 --> Output Class Initialized
INFO - 2024-03-21 12:44:44 --> Security Class Initialized
DEBUG - 2024-03-21 12:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:44:44 --> Input Class Initialized
INFO - 2024-03-21 12:44:44 --> Language Class Initialized
INFO - 2024-03-21 12:44:44 --> Loader Class Initialized
INFO - 2024-03-21 12:44:44 --> Helper loaded: url_helper
INFO - 2024-03-21 12:44:44 --> Helper loaded: file_helper
INFO - 2024-03-21 12:44:44 --> Helper loaded: form_helper
INFO - 2024-03-21 12:44:44 --> Helper loaded: general_helper
INFO - 2024-03-21 12:44:44 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:44:44 --> Controller Class Initialized
INFO - 2024-03-21 12:44:44 --> Form Validation Class Initialized
INFO - 2024-03-21 12:44:44 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:44:44 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:45:06 --> Config Class Initialized
INFO - 2024-03-21 12:45:06 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:45:06 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:45:06 --> Utf8 Class Initialized
INFO - 2024-03-21 12:45:06 --> URI Class Initialized
INFO - 2024-03-21 12:45:06 --> Router Class Initialized
INFO - 2024-03-21 12:45:06 --> Output Class Initialized
INFO - 2024-03-21 12:45:06 --> Security Class Initialized
DEBUG - 2024-03-21 12:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:45:06 --> Input Class Initialized
INFO - 2024-03-21 12:45:06 --> Language Class Initialized
INFO - 2024-03-21 12:45:06 --> Loader Class Initialized
INFO - 2024-03-21 12:45:06 --> Helper loaded: url_helper
INFO - 2024-03-21 12:45:06 --> Helper loaded: file_helper
INFO - 2024-03-21 12:45:06 --> Helper loaded: form_helper
INFO - 2024-03-21 12:45:06 --> Helper loaded: general_helper
INFO - 2024-03-21 12:45:06 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:45:06 --> Controller Class Initialized
INFO - 2024-03-21 12:45:06 --> Form Validation Class Initialized
INFO - 2024-03-21 12:45:06 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:45:06 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:45:06 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:45:06 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:45:06 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:45:06 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:45:06 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:45:06 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:45:06 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:45:06 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:45:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:45:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:45:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:45:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:45:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:45:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:45:06 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:45:06 --> Final output sent to browser
DEBUG - 2024-03-21 12:45:06 --> Total execution time: 0.0388
INFO - 2024-03-21 12:45:07 --> Config Class Initialized
INFO - 2024-03-21 12:45:07 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:45:07 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:45:07 --> Utf8 Class Initialized
INFO - 2024-03-21 12:45:07 --> URI Class Initialized
INFO - 2024-03-21 12:45:07 --> Router Class Initialized
INFO - 2024-03-21 12:45:07 --> Output Class Initialized
INFO - 2024-03-21 12:45:07 --> Security Class Initialized
DEBUG - 2024-03-21 12:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:45:07 --> Input Class Initialized
INFO - 2024-03-21 12:45:07 --> Language Class Initialized
INFO - 2024-03-21 12:45:07 --> Loader Class Initialized
INFO - 2024-03-21 12:45:07 --> Helper loaded: url_helper
INFO - 2024-03-21 12:45:07 --> Helper loaded: file_helper
INFO - 2024-03-21 12:45:07 --> Helper loaded: form_helper
INFO - 2024-03-21 12:45:07 --> Helper loaded: general_helper
INFO - 2024-03-21 12:45:07 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:45:07 --> Controller Class Initialized
INFO - 2024-03-21 12:45:07 --> Form Validation Class Initialized
INFO - 2024-03-21 12:45:07 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:45:07 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:45:07 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:45:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:45:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:45:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:45:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:45:07 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:45:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:45:07 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:45:15 --> Config Class Initialized
INFO - 2024-03-21 12:45:15 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:45:15 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:45:15 --> Utf8 Class Initialized
INFO - 2024-03-21 12:45:15 --> URI Class Initialized
INFO - 2024-03-21 12:45:15 --> Router Class Initialized
INFO - 2024-03-21 12:45:15 --> Output Class Initialized
INFO - 2024-03-21 12:45:15 --> Security Class Initialized
DEBUG - 2024-03-21 12:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:45:15 --> Input Class Initialized
INFO - 2024-03-21 12:45:15 --> Language Class Initialized
INFO - 2024-03-21 12:45:15 --> Loader Class Initialized
INFO - 2024-03-21 12:45:15 --> Helper loaded: url_helper
INFO - 2024-03-21 12:45:15 --> Helper loaded: file_helper
INFO - 2024-03-21 12:45:15 --> Helper loaded: form_helper
INFO - 2024-03-21 12:45:15 --> Helper loaded: general_helper
INFO - 2024-03-21 12:45:15 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:45:15 --> Controller Class Initialized
INFO - 2024-03-21 12:45:15 --> Form Validation Class Initialized
INFO - 2024-03-21 12:45:15 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:45:15 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:45:15 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:45:15 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:45:15 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:45:15 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:45:15 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:45:15 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:45:15 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:45:15 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:45:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:45:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:45:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:45:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:45:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:45:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:45:15 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:45:15 --> Final output sent to browser
DEBUG - 2024-03-21 12:45:15 --> Total execution time: 0.0393
INFO - 2024-03-21 12:45:16 --> Config Class Initialized
INFO - 2024-03-21 12:45:16 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:45:16 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:45:16 --> Utf8 Class Initialized
INFO - 2024-03-21 12:45:16 --> URI Class Initialized
INFO - 2024-03-21 12:45:16 --> Router Class Initialized
INFO - 2024-03-21 12:45:16 --> Output Class Initialized
INFO - 2024-03-21 12:45:16 --> Security Class Initialized
DEBUG - 2024-03-21 12:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:45:16 --> Input Class Initialized
INFO - 2024-03-21 12:45:16 --> Language Class Initialized
INFO - 2024-03-21 12:45:16 --> Loader Class Initialized
INFO - 2024-03-21 12:45:16 --> Helper loaded: url_helper
INFO - 2024-03-21 12:45:16 --> Helper loaded: file_helper
INFO - 2024-03-21 12:45:16 --> Helper loaded: form_helper
INFO - 2024-03-21 12:45:16 --> Helper loaded: general_helper
INFO - 2024-03-21 12:45:16 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:45:16 --> Controller Class Initialized
INFO - 2024-03-21 12:45:16 --> Form Validation Class Initialized
INFO - 2024-03-21 12:45:16 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:45:16 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:45:16 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:45:16 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:45:16 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:45:16 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:45:16 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:45:16 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:45:16 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:45:16 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:45:39 --> Config Class Initialized
INFO - 2024-03-21 12:45:39 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:45:39 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:45:39 --> Utf8 Class Initialized
INFO - 2024-03-21 12:45:39 --> URI Class Initialized
INFO - 2024-03-21 12:45:39 --> Router Class Initialized
INFO - 2024-03-21 12:45:39 --> Output Class Initialized
INFO - 2024-03-21 12:45:39 --> Security Class Initialized
DEBUG - 2024-03-21 12:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:45:39 --> Input Class Initialized
INFO - 2024-03-21 12:45:39 --> Language Class Initialized
INFO - 2024-03-21 12:45:39 --> Loader Class Initialized
INFO - 2024-03-21 12:45:39 --> Helper loaded: url_helper
INFO - 2024-03-21 12:45:39 --> Helper loaded: file_helper
INFO - 2024-03-21 12:45:39 --> Helper loaded: form_helper
INFO - 2024-03-21 12:45:39 --> Helper loaded: general_helper
INFO - 2024-03-21 12:45:39 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:45:39 --> Controller Class Initialized
INFO - 2024-03-21 12:45:39 --> Form Validation Class Initialized
INFO - 2024-03-21 12:45:39 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:45:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:45:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:45:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:45:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:45:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:45:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:45:39 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:45:39 --> Final output sent to browser
DEBUG - 2024-03-21 12:45:39 --> Total execution time: 0.0375
INFO - 2024-03-21 12:45:39 --> Config Class Initialized
INFO - 2024-03-21 12:45:39 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:45:39 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:45:39 --> Utf8 Class Initialized
INFO - 2024-03-21 12:45:39 --> URI Class Initialized
INFO - 2024-03-21 12:45:39 --> Router Class Initialized
INFO - 2024-03-21 12:45:39 --> Output Class Initialized
INFO - 2024-03-21 12:45:39 --> Security Class Initialized
DEBUG - 2024-03-21 12:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:45:39 --> Input Class Initialized
INFO - 2024-03-21 12:45:39 --> Language Class Initialized
INFO - 2024-03-21 12:45:39 --> Loader Class Initialized
INFO - 2024-03-21 12:45:39 --> Helper loaded: url_helper
INFO - 2024-03-21 12:45:39 --> Helper loaded: file_helper
INFO - 2024-03-21 12:45:39 --> Helper loaded: form_helper
INFO - 2024-03-21 12:45:39 --> Helper loaded: general_helper
INFO - 2024-03-21 12:45:39 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:45:39 --> Controller Class Initialized
INFO - 2024-03-21 12:45:39 --> Form Validation Class Initialized
INFO - 2024-03-21 12:45:39 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:45:39 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:49:50 --> Config Class Initialized
INFO - 2024-03-21 12:49:50 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:49:50 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:49:50 --> Utf8 Class Initialized
INFO - 2024-03-21 12:49:50 --> URI Class Initialized
INFO - 2024-03-21 12:49:50 --> Router Class Initialized
INFO - 2024-03-21 12:49:50 --> Output Class Initialized
INFO - 2024-03-21 12:49:50 --> Security Class Initialized
DEBUG - 2024-03-21 12:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:49:50 --> Input Class Initialized
INFO - 2024-03-21 12:49:50 --> Language Class Initialized
INFO - 2024-03-21 12:49:50 --> Loader Class Initialized
INFO - 2024-03-21 12:49:50 --> Helper loaded: url_helper
INFO - 2024-03-21 12:49:50 --> Helper loaded: file_helper
INFO - 2024-03-21 12:49:50 --> Helper loaded: form_helper
INFO - 2024-03-21 12:49:50 --> Helper loaded: general_helper
INFO - 2024-03-21 12:49:50 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:49:50 --> Controller Class Initialized
INFO - 2024-03-21 12:49:50 --> Form Validation Class Initialized
INFO - 2024-03-21 12:49:50 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:49:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:49:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:49:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:49:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:49:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:49:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:49:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_print_form.php
INFO - 2024-03-21 12:49:50 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:49:50 --> Final output sent to browser
DEBUG - 2024-03-21 12:49:50 --> Total execution time: 0.0404
INFO - 2024-03-21 12:49:50 --> Config Class Initialized
INFO - 2024-03-21 12:49:50 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:49:50 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:49:50 --> Utf8 Class Initialized
INFO - 2024-03-21 12:49:50 --> URI Class Initialized
INFO - 2024-03-21 12:49:50 --> Router Class Initialized
INFO - 2024-03-21 12:49:50 --> Output Class Initialized
INFO - 2024-03-21 12:49:50 --> Security Class Initialized
DEBUG - 2024-03-21 12:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:49:50 --> Input Class Initialized
INFO - 2024-03-21 12:49:50 --> Language Class Initialized
INFO - 2024-03-21 12:49:50 --> Loader Class Initialized
INFO - 2024-03-21 12:49:50 --> Helper loaded: url_helper
INFO - 2024-03-21 12:49:50 --> Helper loaded: file_helper
INFO - 2024-03-21 12:49:50 --> Helper loaded: form_helper
INFO - 2024-03-21 12:49:50 --> Helper loaded: general_helper
INFO - 2024-03-21 12:49:50 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:49:50 --> Controller Class Initialized
INFO - 2024-03-21 12:49:50 --> Form Validation Class Initialized
INFO - 2024-03-21 12:49:50 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:49:50 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:49:56 --> Config Class Initialized
INFO - 2024-03-21 12:49:56 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:49:56 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:49:56 --> Utf8 Class Initialized
INFO - 2024-03-21 12:49:56 --> URI Class Initialized
INFO - 2024-03-21 12:49:56 --> Router Class Initialized
INFO - 2024-03-21 12:49:56 --> Output Class Initialized
INFO - 2024-03-21 12:49:57 --> Security Class Initialized
DEBUG - 2024-03-21 12:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:49:57 --> Input Class Initialized
INFO - 2024-03-21 12:49:57 --> Language Class Initialized
INFO - 2024-03-21 12:49:57 --> Loader Class Initialized
INFO - 2024-03-21 12:49:57 --> Helper loaded: url_helper
INFO - 2024-03-21 12:49:57 --> Helper loaded: file_helper
INFO - 2024-03-21 12:49:57 --> Helper loaded: form_helper
INFO - 2024-03-21 12:49:57 --> Helper loaded: general_helper
INFO - 2024-03-21 12:49:57 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:49:57 --> Controller Class Initialized
INFO - 2024-03-21 12:49:57 --> Form Validation Class Initialized
INFO - 2024-03-21 12:49:57 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:49:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:49:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:49:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:49:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:49:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:49:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:49:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_print_form.php
INFO - 2024-03-21 12:49:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:49:57 --> Final output sent to browser
DEBUG - 2024-03-21 12:49:57 --> Total execution time: 0.0349
INFO - 2024-03-21 12:49:57 --> Config Class Initialized
INFO - 2024-03-21 12:49:57 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:49:57 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:49:57 --> Utf8 Class Initialized
INFO - 2024-03-21 12:49:57 --> URI Class Initialized
INFO - 2024-03-21 12:49:57 --> Router Class Initialized
INFO - 2024-03-21 12:49:57 --> Output Class Initialized
INFO - 2024-03-21 12:49:57 --> Security Class Initialized
DEBUG - 2024-03-21 12:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:49:57 --> Input Class Initialized
INFO - 2024-03-21 12:49:57 --> Language Class Initialized
INFO - 2024-03-21 12:49:57 --> Loader Class Initialized
INFO - 2024-03-21 12:49:57 --> Helper loaded: url_helper
INFO - 2024-03-21 12:49:57 --> Helper loaded: file_helper
INFO - 2024-03-21 12:49:57 --> Helper loaded: form_helper
INFO - 2024-03-21 12:49:57 --> Helper loaded: general_helper
INFO - 2024-03-21 12:49:57 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:49:57 --> Controller Class Initialized
INFO - 2024-03-21 12:49:57 --> Form Validation Class Initialized
INFO - 2024-03-21 12:49:57 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:49:57 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:50:42 --> Config Class Initialized
INFO - 2024-03-21 12:50:42 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:50:42 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:50:42 --> Utf8 Class Initialized
INFO - 2024-03-21 12:50:42 --> URI Class Initialized
INFO - 2024-03-21 12:50:42 --> Router Class Initialized
INFO - 2024-03-21 12:50:42 --> Output Class Initialized
INFO - 2024-03-21 12:50:42 --> Security Class Initialized
DEBUG - 2024-03-21 12:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:50:42 --> Input Class Initialized
INFO - 2024-03-21 12:50:42 --> Language Class Initialized
INFO - 2024-03-21 12:50:42 --> Loader Class Initialized
INFO - 2024-03-21 12:50:42 --> Helper loaded: url_helper
INFO - 2024-03-21 12:50:42 --> Helper loaded: file_helper
INFO - 2024-03-21 12:50:42 --> Helper loaded: form_helper
INFO - 2024-03-21 12:50:42 --> Helper loaded: general_helper
INFO - 2024-03-21 12:50:42 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:50:42 --> Controller Class Initialized
INFO - 2024-03-21 12:50:42 --> Form Validation Class Initialized
INFO - 2024-03-21 12:50:42 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:50:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:50:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:50:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:50:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:50:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:50:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:50:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_print_form.php
INFO - 2024-03-21 12:50:42 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:50:42 --> Final output sent to browser
DEBUG - 2024-03-21 12:50:42 --> Total execution time: 0.0287
INFO - 2024-03-21 12:50:42 --> Config Class Initialized
INFO - 2024-03-21 12:50:42 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:50:42 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:50:42 --> Utf8 Class Initialized
INFO - 2024-03-21 12:50:42 --> URI Class Initialized
INFO - 2024-03-21 12:50:42 --> Router Class Initialized
INFO - 2024-03-21 12:50:42 --> Output Class Initialized
INFO - 2024-03-21 12:50:42 --> Security Class Initialized
DEBUG - 2024-03-21 12:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:50:42 --> Input Class Initialized
INFO - 2024-03-21 12:50:42 --> Language Class Initialized
INFO - 2024-03-21 12:50:42 --> Loader Class Initialized
INFO - 2024-03-21 12:50:42 --> Helper loaded: url_helper
INFO - 2024-03-21 12:50:42 --> Helper loaded: file_helper
INFO - 2024-03-21 12:50:42 --> Helper loaded: form_helper
INFO - 2024-03-21 12:50:42 --> Helper loaded: general_helper
INFO - 2024-03-21 12:50:42 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:50:42 --> Controller Class Initialized
INFO - 2024-03-21 12:50:42 --> Form Validation Class Initialized
INFO - 2024-03-21 12:50:42 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:50:42 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:50:57 --> Config Class Initialized
INFO - 2024-03-21 12:50:57 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:50:57 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:50:57 --> Utf8 Class Initialized
INFO - 2024-03-21 12:50:57 --> URI Class Initialized
INFO - 2024-03-21 12:50:57 --> Router Class Initialized
INFO - 2024-03-21 12:50:57 --> Output Class Initialized
INFO - 2024-03-21 12:50:57 --> Security Class Initialized
DEBUG - 2024-03-21 12:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:50:57 --> Input Class Initialized
INFO - 2024-03-21 12:50:57 --> Language Class Initialized
INFO - 2024-03-21 12:50:57 --> Loader Class Initialized
INFO - 2024-03-21 12:50:57 --> Helper loaded: url_helper
INFO - 2024-03-21 12:50:57 --> Helper loaded: file_helper
INFO - 2024-03-21 12:50:57 --> Helper loaded: form_helper
INFO - 2024-03-21 12:50:57 --> Helper loaded: general_helper
INFO - 2024-03-21 12:50:57 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:50:57 --> Controller Class Initialized
INFO - 2024-03-21 12:50:57 --> Form Validation Class Initialized
INFO - 2024-03-21 12:50:57 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_print_form.php
INFO - 2024-03-21 12:50:57 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:50:57 --> Final output sent to browser
DEBUG - 2024-03-21 12:50:57 --> Total execution time: 0.0397
INFO - 2024-03-21 12:50:57 --> Config Class Initialized
INFO - 2024-03-21 12:50:57 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:50:57 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:50:57 --> Utf8 Class Initialized
INFO - 2024-03-21 12:50:57 --> URI Class Initialized
INFO - 2024-03-21 12:50:57 --> Router Class Initialized
INFO - 2024-03-21 12:50:57 --> Output Class Initialized
INFO - 2024-03-21 12:50:57 --> Security Class Initialized
DEBUG - 2024-03-21 12:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:50:57 --> Input Class Initialized
INFO - 2024-03-21 12:50:57 --> Language Class Initialized
INFO - 2024-03-21 12:50:57 --> Loader Class Initialized
INFO - 2024-03-21 12:50:57 --> Helper loaded: url_helper
INFO - 2024-03-21 12:50:57 --> Helper loaded: file_helper
INFO - 2024-03-21 12:50:57 --> Helper loaded: form_helper
INFO - 2024-03-21 12:50:57 --> Helper loaded: general_helper
INFO - 2024-03-21 12:50:57 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:50:57 --> Controller Class Initialized
INFO - 2024-03-21 12:50:57 --> Form Validation Class Initialized
INFO - 2024-03-21 12:50:57 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:50:57 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:51:59 --> Config Class Initialized
INFO - 2024-03-21 12:51:59 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:51:59 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:51:59 --> Utf8 Class Initialized
INFO - 2024-03-21 12:51:59 --> URI Class Initialized
INFO - 2024-03-21 12:51:59 --> Router Class Initialized
INFO - 2024-03-21 12:51:59 --> Output Class Initialized
INFO - 2024-03-21 12:51:59 --> Security Class Initialized
DEBUG - 2024-03-21 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:51:59 --> Input Class Initialized
INFO - 2024-03-21 12:51:59 --> Language Class Initialized
INFO - 2024-03-21 12:51:59 --> Loader Class Initialized
INFO - 2024-03-21 12:51:59 --> Helper loaded: url_helper
INFO - 2024-03-21 12:51:59 --> Helper loaded: file_helper
INFO - 2024-03-21 12:51:59 --> Helper loaded: form_helper
INFO - 2024-03-21 12:51:59 --> Helper loaded: general_helper
INFO - 2024-03-21 12:51:59 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:51:59 --> Controller Class Initialized
INFO - 2024-03-21 12:51:59 --> Form Validation Class Initialized
INFO - 2024-03-21 12:51:59 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:51:59 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:51:59 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:51:59 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:51:59 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:51:59 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:51:59 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:51:59 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:51:59 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:51:59 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:51:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:51:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:51:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:51:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:51:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:51:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:51:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_print_form.php
INFO - 2024-03-21 12:51:59 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:51:59 --> Final output sent to browser
DEBUG - 2024-03-21 12:51:59 --> Total execution time: 0.0367
INFO - 2024-03-21 12:52:00 --> Config Class Initialized
INFO - 2024-03-21 12:52:00 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:52:00 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:52:00 --> Utf8 Class Initialized
INFO - 2024-03-21 12:52:00 --> URI Class Initialized
INFO - 2024-03-21 12:52:00 --> Router Class Initialized
INFO - 2024-03-21 12:52:00 --> Output Class Initialized
INFO - 2024-03-21 12:52:00 --> Security Class Initialized
DEBUG - 2024-03-21 12:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:52:00 --> Input Class Initialized
INFO - 2024-03-21 12:52:00 --> Language Class Initialized
INFO - 2024-03-21 12:52:00 --> Loader Class Initialized
INFO - 2024-03-21 12:52:00 --> Helper loaded: url_helper
INFO - 2024-03-21 12:52:00 --> Helper loaded: file_helper
INFO - 2024-03-21 12:52:00 --> Helper loaded: form_helper
INFO - 2024-03-21 12:52:00 --> Helper loaded: general_helper
INFO - 2024-03-21 12:52:00 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:52:00 --> Controller Class Initialized
INFO - 2024-03-21 12:52:00 --> Form Validation Class Initialized
INFO - 2024-03-21 12:52:00 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:52:00 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:52:00 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:52:00 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:52:00 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:52:00 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:52:00 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:52:00 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:52:00 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:52:00 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:52:13 --> Config Class Initialized
INFO - 2024-03-21 12:52:13 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:52:13 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:52:13 --> Utf8 Class Initialized
INFO - 2024-03-21 12:52:13 --> URI Class Initialized
INFO - 2024-03-21 12:52:13 --> Router Class Initialized
INFO - 2024-03-21 12:52:13 --> Output Class Initialized
INFO - 2024-03-21 12:52:13 --> Security Class Initialized
DEBUG - 2024-03-21 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:52:13 --> Input Class Initialized
INFO - 2024-03-21 12:52:13 --> Language Class Initialized
INFO - 2024-03-21 12:52:13 --> Loader Class Initialized
INFO - 2024-03-21 12:52:13 --> Helper loaded: url_helper
INFO - 2024-03-21 12:52:13 --> Helper loaded: file_helper
INFO - 2024-03-21 12:52:13 --> Helper loaded: form_helper
INFO - 2024-03-21 12:52:13 --> Helper loaded: general_helper
INFO - 2024-03-21 12:52:13 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:52:13 --> Controller Class Initialized
INFO - 2024-03-21 12:52:13 --> Form Validation Class Initialized
INFO - 2024-03-21 12:52:13 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_print_form.php
INFO - 2024-03-21 12:52:13 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:52:13 --> Final output sent to browser
DEBUG - 2024-03-21 12:52:13 --> Total execution time: 0.0409
INFO - 2024-03-21 12:52:13 --> Config Class Initialized
INFO - 2024-03-21 12:52:13 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:52:13 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:52:13 --> Utf8 Class Initialized
INFO - 2024-03-21 12:52:13 --> URI Class Initialized
INFO - 2024-03-21 12:52:13 --> Router Class Initialized
INFO - 2024-03-21 12:52:13 --> Output Class Initialized
INFO - 2024-03-21 12:52:13 --> Security Class Initialized
DEBUG - 2024-03-21 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:52:13 --> Input Class Initialized
INFO - 2024-03-21 12:52:13 --> Language Class Initialized
INFO - 2024-03-21 12:52:13 --> Loader Class Initialized
INFO - 2024-03-21 12:52:13 --> Helper loaded: url_helper
INFO - 2024-03-21 12:52:13 --> Helper loaded: file_helper
INFO - 2024-03-21 12:52:13 --> Helper loaded: form_helper
INFO - 2024-03-21 12:52:13 --> Helper loaded: general_helper
INFO - 2024-03-21 12:52:13 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:52:13 --> Controller Class Initialized
INFO - 2024-03-21 12:52:13 --> Form Validation Class Initialized
INFO - 2024-03-21 12:52:13 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:52:13 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:53:48 --> Config Class Initialized
INFO - 2024-03-21 12:53:48 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:53:48 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:53:48 --> Utf8 Class Initialized
INFO - 2024-03-21 12:53:48 --> URI Class Initialized
INFO - 2024-03-21 12:53:48 --> Router Class Initialized
INFO - 2024-03-21 12:53:48 --> Output Class Initialized
INFO - 2024-03-21 12:53:48 --> Security Class Initialized
DEBUG - 2024-03-21 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:53:48 --> Input Class Initialized
INFO - 2024-03-21 12:53:48 --> Language Class Initialized
INFO - 2024-03-21 12:53:48 --> Loader Class Initialized
INFO - 2024-03-21 12:53:48 --> Helper loaded: url_helper
INFO - 2024-03-21 12:53:48 --> Helper loaded: file_helper
INFO - 2024-03-21 12:53:48 --> Helper loaded: form_helper
INFO - 2024-03-21 12:53:48 --> Helper loaded: general_helper
INFO - 2024-03-21 12:53:48 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:53:48 --> Controller Class Initialized
INFO - 2024-03-21 12:53:48 --> Form Validation Class Initialized
INFO - 2024-03-21 12:53:48 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:53:48 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:53:48 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:53:48 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:53:48 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:53:48 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:53:48 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:53:48 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:53:48 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:53:48 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:53:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:53:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:53:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:53:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:53:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:53:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:53:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_print_form.php
INFO - 2024-03-21 12:53:48 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:53:48 --> Final output sent to browser
DEBUG - 2024-03-21 12:53:48 --> Total execution time: 0.0458
INFO - 2024-03-21 12:53:49 --> Config Class Initialized
INFO - 2024-03-21 12:53:49 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:53:49 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:53:49 --> Utf8 Class Initialized
INFO - 2024-03-21 12:53:49 --> URI Class Initialized
INFO - 2024-03-21 12:53:49 --> Router Class Initialized
INFO - 2024-03-21 12:53:49 --> Output Class Initialized
INFO - 2024-03-21 12:53:49 --> Security Class Initialized
DEBUG - 2024-03-21 12:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:53:49 --> Input Class Initialized
INFO - 2024-03-21 12:53:49 --> Language Class Initialized
INFO - 2024-03-21 12:53:49 --> Loader Class Initialized
INFO - 2024-03-21 12:53:49 --> Helper loaded: url_helper
INFO - 2024-03-21 12:53:49 --> Helper loaded: file_helper
INFO - 2024-03-21 12:53:49 --> Helper loaded: form_helper
INFO - 2024-03-21 12:53:49 --> Helper loaded: general_helper
INFO - 2024-03-21 12:53:49 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:53:49 --> Controller Class Initialized
INFO - 2024-03-21 12:53:49 --> Form Validation Class Initialized
INFO - 2024-03-21 12:53:49 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:53:49 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:53:49 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:53:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:53:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:53:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:53:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:53:49 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:53:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:53:49 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:54:08 --> Config Class Initialized
INFO - 2024-03-21 12:54:08 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:54:08 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:54:08 --> Utf8 Class Initialized
INFO - 2024-03-21 12:54:08 --> URI Class Initialized
INFO - 2024-03-21 12:54:08 --> Router Class Initialized
INFO - 2024-03-21 12:54:08 --> Output Class Initialized
INFO - 2024-03-21 12:54:08 --> Security Class Initialized
DEBUG - 2024-03-21 12:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:54:08 --> Input Class Initialized
INFO - 2024-03-21 12:54:08 --> Language Class Initialized
INFO - 2024-03-21 12:54:08 --> Loader Class Initialized
INFO - 2024-03-21 12:54:08 --> Helper loaded: url_helper
INFO - 2024-03-21 12:54:08 --> Helper loaded: file_helper
INFO - 2024-03-21 12:54:08 --> Helper loaded: form_helper
INFO - 2024-03-21 12:54:08 --> Helper loaded: general_helper
INFO - 2024-03-21 12:54:08 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:54:08 --> Controller Class Initialized
INFO - 2024-03-21 12:54:08 --> Form Validation Class Initialized
INFO - 2024-03-21 12:54:08 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:54:08 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:54:08 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:54:08 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:54:08 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:54:08 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:54:08 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:54:08 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:54:08 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:54:08 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:54:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:54:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:54:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:54:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:54:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:54:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:54:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_print_form.php
INFO - 2024-03-21 12:54:08 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:54:08 --> Final output sent to browser
DEBUG - 2024-03-21 12:54:08 --> Total execution time: 0.0341
INFO - 2024-03-21 12:54:09 --> Config Class Initialized
INFO - 2024-03-21 12:54:09 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:54:09 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:54:09 --> Utf8 Class Initialized
INFO - 2024-03-21 12:54:09 --> URI Class Initialized
INFO - 2024-03-21 12:54:09 --> Router Class Initialized
INFO - 2024-03-21 12:54:09 --> Output Class Initialized
INFO - 2024-03-21 12:54:09 --> Security Class Initialized
DEBUG - 2024-03-21 12:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:54:09 --> Input Class Initialized
INFO - 2024-03-21 12:54:09 --> Language Class Initialized
INFO - 2024-03-21 12:54:09 --> Loader Class Initialized
INFO - 2024-03-21 12:54:09 --> Helper loaded: url_helper
INFO - 2024-03-21 12:54:09 --> Helper loaded: file_helper
INFO - 2024-03-21 12:54:09 --> Helper loaded: form_helper
INFO - 2024-03-21 12:54:09 --> Helper loaded: general_helper
INFO - 2024-03-21 12:54:09 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:54:09 --> Controller Class Initialized
INFO - 2024-03-21 12:54:09 --> Form Validation Class Initialized
INFO - 2024-03-21 12:54:09 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:54:09 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:54:09 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:54:09 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:54:09 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:54:09 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:54:09 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:54:09 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:54:09 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:54:09 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:55:07 --> Config Class Initialized
INFO - 2024-03-21 12:55:07 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:55:07 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:55:07 --> Utf8 Class Initialized
INFO - 2024-03-21 12:55:07 --> URI Class Initialized
INFO - 2024-03-21 12:55:07 --> Router Class Initialized
INFO - 2024-03-21 12:55:07 --> Output Class Initialized
INFO - 2024-03-21 12:55:07 --> Security Class Initialized
DEBUG - 2024-03-21 12:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:55:07 --> Input Class Initialized
INFO - 2024-03-21 12:55:07 --> Language Class Initialized
INFO - 2024-03-21 12:55:07 --> Loader Class Initialized
INFO - 2024-03-21 12:55:07 --> Helper loaded: url_helper
INFO - 2024-03-21 12:55:07 --> Helper loaded: file_helper
INFO - 2024-03-21 12:55:07 --> Helper loaded: form_helper
INFO - 2024-03-21 12:55:07 --> Helper loaded: general_helper
INFO - 2024-03-21 12:55:07 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:55:07 --> Controller Class Initialized
INFO - 2024-03-21 12:55:07 --> Form Validation Class Initialized
INFO - 2024-03-21 12:55:07 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:55:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:55:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:55:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:55:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:55:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:55:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:55:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_print_form.php
INFO - 2024-03-21 12:55:07 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:55:07 --> Final output sent to browser
DEBUG - 2024-03-21 12:55:07 --> Total execution time: 0.0355
INFO - 2024-03-21 12:55:07 --> Config Class Initialized
INFO - 2024-03-21 12:55:07 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:55:07 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:55:07 --> Utf8 Class Initialized
INFO - 2024-03-21 12:55:07 --> URI Class Initialized
INFO - 2024-03-21 12:55:07 --> Router Class Initialized
INFO - 2024-03-21 12:55:07 --> Output Class Initialized
INFO - 2024-03-21 12:55:07 --> Security Class Initialized
DEBUG - 2024-03-21 12:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:55:07 --> Input Class Initialized
INFO - 2024-03-21 12:55:07 --> Language Class Initialized
INFO - 2024-03-21 12:55:07 --> Loader Class Initialized
INFO - 2024-03-21 12:55:07 --> Helper loaded: url_helper
INFO - 2024-03-21 12:55:07 --> Helper loaded: file_helper
INFO - 2024-03-21 12:55:07 --> Helper loaded: form_helper
INFO - 2024-03-21 12:55:07 --> Helper loaded: general_helper
INFO - 2024-03-21 12:55:07 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:55:07 --> Controller Class Initialized
INFO - 2024-03-21 12:55:07 --> Form Validation Class Initialized
INFO - 2024-03-21 12:55:07 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:55:07 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:55:12 --> Config Class Initialized
INFO - 2024-03-21 12:55:12 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:55:12 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:55:12 --> Utf8 Class Initialized
INFO - 2024-03-21 12:55:12 --> URI Class Initialized
INFO - 2024-03-21 12:55:12 --> Router Class Initialized
INFO - 2024-03-21 12:55:12 --> Output Class Initialized
INFO - 2024-03-21 12:55:12 --> Security Class Initialized
DEBUG - 2024-03-21 12:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:55:12 --> Input Class Initialized
INFO - 2024-03-21 12:55:12 --> Language Class Initialized
INFO - 2024-03-21 12:55:12 --> Loader Class Initialized
INFO - 2024-03-21 12:55:12 --> Helper loaded: url_helper
INFO - 2024-03-21 12:55:12 --> Helper loaded: file_helper
INFO - 2024-03-21 12:55:12 --> Helper loaded: form_helper
INFO - 2024-03-21 12:55:12 --> Helper loaded: general_helper
INFO - 2024-03-21 12:55:12 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:55:12 --> Controller Class Initialized
INFO - 2024-03-21 12:55:12 --> Form Validation Class Initialized
INFO - 2024-03-21 12:55:12 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:55:12 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:55:12 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:55:12 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:55:12 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:55:12 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:55:12 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:55:12 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:55:12 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:55:12 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:55:23 --> Config Class Initialized
INFO - 2024-03-21 12:55:23 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:55:23 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:55:23 --> Utf8 Class Initialized
INFO - 2024-03-21 12:55:23 --> URI Class Initialized
INFO - 2024-03-21 12:55:23 --> Router Class Initialized
INFO - 2024-03-21 12:55:23 --> Output Class Initialized
INFO - 2024-03-21 12:55:23 --> Security Class Initialized
DEBUG - 2024-03-21 12:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:55:23 --> Input Class Initialized
INFO - 2024-03-21 12:55:23 --> Language Class Initialized
INFO - 2024-03-21 12:55:23 --> Loader Class Initialized
INFO - 2024-03-21 12:55:23 --> Helper loaded: url_helper
INFO - 2024-03-21 12:55:24 --> Helper loaded: file_helper
INFO - 2024-03-21 12:55:24 --> Helper loaded: form_helper
INFO - 2024-03-21 12:55:24 --> Helper loaded: general_helper
INFO - 2024-03-21 12:55:24 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:55:24 --> Controller Class Initialized
INFO - 2024-03-21 12:55:24 --> Form Validation Class Initialized
INFO - 2024-03-21 12:55:24 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_print_form.php
INFO - 2024-03-21 12:55:24 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:55:24 --> Final output sent to browser
DEBUG - 2024-03-21 12:55:24 --> Total execution time: 0.0324
INFO - 2024-03-21 12:55:24 --> Config Class Initialized
INFO - 2024-03-21 12:55:24 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:55:24 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:55:24 --> Utf8 Class Initialized
INFO - 2024-03-21 12:55:24 --> URI Class Initialized
INFO - 2024-03-21 12:55:24 --> Router Class Initialized
INFO - 2024-03-21 12:55:24 --> Output Class Initialized
INFO - 2024-03-21 12:55:24 --> Security Class Initialized
DEBUG - 2024-03-21 12:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:55:24 --> Input Class Initialized
INFO - 2024-03-21 12:55:24 --> Language Class Initialized
INFO - 2024-03-21 12:55:24 --> Loader Class Initialized
INFO - 2024-03-21 12:55:24 --> Helper loaded: url_helper
INFO - 2024-03-21 12:55:24 --> Helper loaded: file_helper
INFO - 2024-03-21 12:55:24 --> Helper loaded: form_helper
INFO - 2024-03-21 12:55:24 --> Helper loaded: general_helper
INFO - 2024-03-21 12:55:24 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:55:24 --> Controller Class Initialized
INFO - 2024-03-21 12:55:24 --> Form Validation Class Initialized
INFO - 2024-03-21 12:55:24 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:55:24 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:55:28 --> Config Class Initialized
INFO - 2024-03-21 12:55:28 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:55:28 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:55:28 --> Utf8 Class Initialized
INFO - 2024-03-21 12:55:28 --> URI Class Initialized
INFO - 2024-03-21 12:55:28 --> Router Class Initialized
INFO - 2024-03-21 12:55:28 --> Output Class Initialized
INFO - 2024-03-21 12:55:28 --> Security Class Initialized
DEBUG - 2024-03-21 12:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:55:28 --> Input Class Initialized
INFO - 2024-03-21 12:55:28 --> Language Class Initialized
INFO - 2024-03-21 12:55:28 --> Loader Class Initialized
INFO - 2024-03-21 12:55:28 --> Helper loaded: url_helper
INFO - 2024-03-21 12:55:28 --> Helper loaded: file_helper
INFO - 2024-03-21 12:55:28 --> Helper loaded: form_helper
INFO - 2024-03-21 12:55:28 --> Helper loaded: general_helper
INFO - 2024-03-21 12:55:28 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:55:28 --> Controller Class Initialized
INFO - 2024-03-21 12:55:28 --> Form Validation Class Initialized
INFO - 2024-03-21 12:55:28 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:55:28 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:55:28 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:55:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:55:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:55:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:55:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:55:28 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:55:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:55:28 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:57:52 --> Config Class Initialized
INFO - 2024-03-21 12:57:52 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:57:52 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:57:52 --> Utf8 Class Initialized
INFO - 2024-03-21 12:57:52 --> URI Class Initialized
INFO - 2024-03-21 12:57:52 --> Router Class Initialized
INFO - 2024-03-21 12:57:52 --> Output Class Initialized
INFO - 2024-03-21 12:57:52 --> Security Class Initialized
DEBUG - 2024-03-21 12:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:57:52 --> Input Class Initialized
INFO - 2024-03-21 12:57:52 --> Language Class Initialized
INFO - 2024-03-21 12:57:52 --> Loader Class Initialized
INFO - 2024-03-21 12:57:52 --> Helper loaded: url_helper
INFO - 2024-03-21 12:57:52 --> Helper loaded: file_helper
INFO - 2024-03-21 12:57:52 --> Helper loaded: form_helper
INFO - 2024-03-21 12:57:52 --> Helper loaded: general_helper
INFO - 2024-03-21 12:57:52 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:57:52 --> Controller Class Initialized
INFO - 2024-03-21 12:57:52 --> Form Validation Class Initialized
INFO - 2024-03-21 12:57:52 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:57:52 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:57:52 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:57:52 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:57:52 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:57:52 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:57:52 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:57:52 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:57:52 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:57:52 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:57:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 12:57:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 12:57:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 12:57:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 12:57:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 12:57:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_filter_form.php
INFO - 2024-03-21 12:57:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail_print_form.php
INFO - 2024-03-21 12:57:52 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_detail.php
INFO - 2024-03-21 12:57:52 --> Final output sent to browser
DEBUG - 2024-03-21 12:57:52 --> Total execution time: 0.0337
INFO - 2024-03-21 12:57:52 --> Config Class Initialized
INFO - 2024-03-21 12:57:52 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:57:52 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:57:52 --> Utf8 Class Initialized
INFO - 2024-03-21 12:57:52 --> URI Class Initialized
INFO - 2024-03-21 12:57:52 --> Router Class Initialized
INFO - 2024-03-21 12:57:52 --> Output Class Initialized
INFO - 2024-03-21 12:57:52 --> Security Class Initialized
DEBUG - 2024-03-21 12:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:57:53 --> Input Class Initialized
INFO - 2024-03-21 12:57:53 --> Language Class Initialized
INFO - 2024-03-21 12:57:53 --> Loader Class Initialized
INFO - 2024-03-21 12:57:53 --> Helper loaded: url_helper
INFO - 2024-03-21 12:57:53 --> Helper loaded: file_helper
INFO - 2024-03-21 12:57:53 --> Helper loaded: form_helper
INFO - 2024-03-21 12:57:53 --> Helper loaded: general_helper
INFO - 2024-03-21 12:57:53 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:57:53 --> Controller Class Initialized
INFO - 2024-03-21 12:57:53 --> Form Validation Class Initialized
INFO - 2024-03-21 12:57:53 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:57:53 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:57:53 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:57:53 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:57:53 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:57:53 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:57:53 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:57:53 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:57:53 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:57:53 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:58:10 --> Config Class Initialized
INFO - 2024-03-21 12:58:10 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:58:10 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:58:10 --> Utf8 Class Initialized
INFO - 2024-03-21 12:58:10 --> URI Class Initialized
INFO - 2024-03-21 12:58:10 --> Router Class Initialized
INFO - 2024-03-21 12:58:10 --> Output Class Initialized
INFO - 2024-03-21 12:58:10 --> Security Class Initialized
DEBUG - 2024-03-21 12:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:58:10 --> Input Class Initialized
INFO - 2024-03-21 12:58:10 --> Language Class Initialized
INFO - 2024-03-21 12:58:10 --> Loader Class Initialized
INFO - 2024-03-21 12:58:10 --> Helper loaded: url_helper
INFO - 2024-03-21 12:58:10 --> Helper loaded: file_helper
INFO - 2024-03-21 12:58:10 --> Helper loaded: form_helper
INFO - 2024-03-21 12:58:10 --> Helper loaded: general_helper
INFO - 2024-03-21 12:58:10 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:58:10 --> Controller Class Initialized
INFO - 2024-03-21 12:58:10 --> Form Validation Class Initialized
INFO - 2024-03-21 12:58:10 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:58:10 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:58:10 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:58:10 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:58:10 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:58:10 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:58:10 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:58:10 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:58:10 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:58:10 --> Model "ReportModel" initialized
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$cr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 148
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$dr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 149
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$cr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 154
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$dr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 155
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$cr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 148
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$dr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 149
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$cr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 154
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$dr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 155
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$cr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 148
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$dr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 149
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$cr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 154
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$dr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 155
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$cr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 148
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$dr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 149
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$cr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 154
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$dr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 155
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$cr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 148
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$dr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 149
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$cr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 154
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$dr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 155
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$cr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 148
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$dr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 149
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$cr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 154
ERROR - 2024-03-21 12:58:10 --> Severity: Notice --> Undefined property: stdClass::$dr_balance D:\xampp\htdocs\sscy\application\controllers\app\Report.php 155
ERROR - 2024-03-21 12:58:11 --> Severity: error --> Exception: Data has already been sent to output (D:\xampp\htdocs\sscy\system\core\Exceptions.php at line 271), unable to output PDF file D:\xampp\htdocs\sscy\vendor\mpdf\mpdf\src\Mpdf.php 9572
ERROR - 2024-03-21 12:58:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\sscy\system\core\Exceptions.php:271) D:\xampp\htdocs\sscy\system\core\Common.php 570
INFO - 2024-03-21 12:58:49 --> Config Class Initialized
INFO - 2024-03-21 12:58:49 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:58:49 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:58:49 --> Utf8 Class Initialized
INFO - 2024-03-21 12:58:49 --> URI Class Initialized
INFO - 2024-03-21 12:58:49 --> Router Class Initialized
INFO - 2024-03-21 12:58:49 --> Output Class Initialized
INFO - 2024-03-21 12:58:49 --> Security Class Initialized
DEBUG - 2024-03-21 12:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:58:49 --> Input Class Initialized
INFO - 2024-03-21 12:58:49 --> Language Class Initialized
INFO - 2024-03-21 12:58:49 --> Loader Class Initialized
INFO - 2024-03-21 12:58:49 --> Helper loaded: url_helper
INFO - 2024-03-21 12:58:49 --> Helper loaded: file_helper
INFO - 2024-03-21 12:58:49 --> Helper loaded: form_helper
INFO - 2024-03-21 12:58:49 --> Helper loaded: general_helper
INFO - 2024-03-21 12:58:49 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:58:49 --> Controller Class Initialized
INFO - 2024-03-21 12:58:49 --> Form Validation Class Initialized
INFO - 2024-03-21 12:58:49 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:58:49 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:58:49 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:58:49 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:58:49 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:58:49 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:58:49 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:58:49 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:58:49 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:58:49 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:58:50 --> Final output sent to browser
DEBUG - 2024-03-21 12:58:50 --> Total execution time: 0.5550
INFO - 2024-03-21 12:59:40 --> Config Class Initialized
INFO - 2024-03-21 12:59:40 --> Hooks Class Initialized
DEBUG - 2024-03-21 12:59:40 --> UTF-8 Support Enabled
INFO - 2024-03-21 12:59:40 --> Utf8 Class Initialized
INFO - 2024-03-21 12:59:40 --> URI Class Initialized
INFO - 2024-03-21 12:59:40 --> Router Class Initialized
INFO - 2024-03-21 12:59:40 --> Output Class Initialized
INFO - 2024-03-21 12:59:40 --> Security Class Initialized
DEBUG - 2024-03-21 12:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 12:59:40 --> Input Class Initialized
INFO - 2024-03-21 12:59:40 --> Language Class Initialized
INFO - 2024-03-21 12:59:40 --> Loader Class Initialized
INFO - 2024-03-21 12:59:40 --> Helper loaded: url_helper
INFO - 2024-03-21 12:59:40 --> Helper loaded: file_helper
INFO - 2024-03-21 12:59:40 --> Helper loaded: form_helper
INFO - 2024-03-21 12:59:40 --> Helper loaded: general_helper
INFO - 2024-03-21 12:59:40 --> Database Driver Class Initialized
DEBUG - 2024-03-21 12:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 12:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 12:59:40 --> Controller Class Initialized
INFO - 2024-03-21 12:59:40 --> Form Validation Class Initialized
INFO - 2024-03-21 12:59:40 --> Model "MasterModel" initialized
INFO - 2024-03-21 12:59:40 --> Model "NotificationModel" initialized
INFO - 2024-03-21 12:59:40 --> Model "DashboardModel" initialized
INFO - 2024-03-21 12:59:40 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 12:59:40 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 12:59:40 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 12:59:40 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 12:59:40 --> Model "OrderModel" initialized
INFO - 2024-03-21 12:59:40 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 12:59:40 --> Model "ReportModel" initialized
INFO - 2024-03-21 12:59:41 --> Final output sent to browser
DEBUG - 2024-03-21 12:59:41 --> Total execution time: 0.5143
INFO - 2024-03-21 13:03:23 --> Config Class Initialized
INFO - 2024-03-21 13:03:23 --> Hooks Class Initialized
DEBUG - 2024-03-21 13:03:23 --> UTF-8 Support Enabled
INFO - 2024-03-21 13:03:23 --> Utf8 Class Initialized
INFO - 2024-03-21 13:03:23 --> URI Class Initialized
INFO - 2024-03-21 13:03:23 --> Router Class Initialized
INFO - 2024-03-21 13:03:23 --> Output Class Initialized
INFO - 2024-03-21 13:03:23 --> Security Class Initialized
DEBUG - 2024-03-21 13:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 13:03:23 --> Input Class Initialized
INFO - 2024-03-21 13:03:23 --> Language Class Initialized
INFO - 2024-03-21 13:03:23 --> Loader Class Initialized
INFO - 2024-03-21 13:03:23 --> Helper loaded: url_helper
INFO - 2024-03-21 13:03:23 --> Helper loaded: file_helper
INFO - 2024-03-21 13:03:23 --> Helper loaded: form_helper
INFO - 2024-03-21 13:03:23 --> Helper loaded: general_helper
INFO - 2024-03-21 13:03:23 --> Database Driver Class Initialized
DEBUG - 2024-03-21 13:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 13:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 13:03:23 --> Controller Class Initialized
INFO - 2024-03-21 13:03:23 --> Form Validation Class Initialized
INFO - 2024-03-21 13:03:23 --> Model "MasterModel" initialized
INFO - 2024-03-21 13:03:23 --> Model "NotificationModel" initialized
INFO - 2024-03-21 13:03:23 --> Model "DashboardModel" initialized
INFO - 2024-03-21 13:03:23 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 13:03:23 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 13:03:23 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 13:03:23 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 13:03:23 --> Model "OrderModel" initialized
INFO - 2024-03-21 13:03:23 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 13:03:23 --> Model "ReportModel" initialized
INFO - 2024-03-21 13:03:24 --> Config Class Initialized
INFO - 2024-03-21 13:03:24 --> Hooks Class Initialized
DEBUG - 2024-03-21 13:03:24 --> UTF-8 Support Enabled
INFO - 2024-03-21 13:03:24 --> Utf8 Class Initialized
INFO - 2024-03-21 13:03:24 --> URI Class Initialized
INFO - 2024-03-21 13:03:24 --> Router Class Initialized
INFO - 2024-03-21 13:03:24 --> Output Class Initialized
INFO - 2024-03-21 13:03:24 --> Security Class Initialized
DEBUG - 2024-03-21 13:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 13:03:24 --> Input Class Initialized
INFO - 2024-03-21 13:03:24 --> Language Class Initialized
INFO - 2024-03-21 13:03:24 --> Loader Class Initialized
INFO - 2024-03-21 13:03:24 --> Helper loaded: url_helper
INFO - 2024-03-21 13:03:24 --> Helper loaded: file_helper
INFO - 2024-03-21 13:03:24 --> Helper loaded: form_helper
INFO - 2024-03-21 13:03:24 --> Helper loaded: general_helper
INFO - 2024-03-21 13:03:24 --> Database Driver Class Initialized
DEBUG - 2024-03-21 13:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 13:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 13:03:24 --> Controller Class Initialized
INFO - 2024-03-21 13:03:24 --> Form Validation Class Initialized
INFO - 2024-03-21 13:03:24 --> Model "MasterModel" initialized
INFO - 2024-03-21 13:03:24 --> Model "NotificationModel" initialized
INFO - 2024-03-21 13:03:24 --> Model "DashboardModel" initialized
INFO - 2024-03-21 13:03:24 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 13:03:24 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 13:03:24 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 13:03:24 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 13:03:24 --> Model "OrderModel" initialized
INFO - 2024-03-21 13:03:24 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 13:03:24 --> Model "ReportModel" initialized
INFO - 2024-03-21 13:03:27 --> Config Class Initialized
INFO - 2024-03-21 13:03:27 --> Hooks Class Initialized
DEBUG - 2024-03-21 13:03:27 --> UTF-8 Support Enabled
INFO - 2024-03-21 13:03:27 --> Utf8 Class Initialized
INFO - 2024-03-21 13:03:27 --> URI Class Initialized
INFO - 2024-03-21 13:03:27 --> Router Class Initialized
INFO - 2024-03-21 13:03:27 --> Output Class Initialized
INFO - 2024-03-21 13:03:27 --> Security Class Initialized
DEBUG - 2024-03-21 13:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 13:03:27 --> Input Class Initialized
INFO - 2024-03-21 13:03:27 --> Language Class Initialized
INFO - 2024-03-21 13:03:27 --> Loader Class Initialized
INFO - 2024-03-21 13:03:27 --> Helper loaded: url_helper
INFO - 2024-03-21 13:03:27 --> Helper loaded: file_helper
INFO - 2024-03-21 13:03:27 --> Helper loaded: form_helper
INFO - 2024-03-21 13:03:27 --> Helper loaded: general_helper
INFO - 2024-03-21 13:03:27 --> Database Driver Class Initialized
DEBUG - 2024-03-21 13:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 13:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 13:03:27 --> Controller Class Initialized
INFO - 2024-03-21 13:03:27 --> Form Validation Class Initialized
INFO - 2024-03-21 13:03:27 --> Model "MasterModel" initialized
INFO - 2024-03-21 13:03:27 --> Model "NotificationModel" initialized
INFO - 2024-03-21 13:03:27 --> Model "DashboardModel" initialized
INFO - 2024-03-21 13:03:27 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 13:03:27 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 13:03:27 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 13:03:27 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 13:03:27 --> Model "OrderModel" initialized
INFO - 2024-03-21 13:03:27 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 13:03:27 --> Model "ReportModel" initialized
INFO - 2024-03-21 13:03:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/header.php
INFO - 2024-03-21 13:03:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/admin_sidebar.php
INFO - 2024-03-21 13:03:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/sidebar.php
INFO - 2024-03-21 13:03:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/modal.php
INFO - 2024-03-21 13:03:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/includes/footer.php
INFO - 2024-03-21 13:03:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_filter_form.php
INFO - 2024-03-21 13:03:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger_print_form.php
INFO - 2024-03-21 13:03:27 --> File loaded: D:\xampp\htdocs\sscy\application\views\app/report/ledger.php
INFO - 2024-03-21 13:03:27 --> Final output sent to browser
DEBUG - 2024-03-21 13:03:27 --> Total execution time: 0.0284
INFO - 2024-03-21 13:03:28 --> Config Class Initialized
INFO - 2024-03-21 13:03:28 --> Hooks Class Initialized
DEBUG - 2024-03-21 13:03:28 --> UTF-8 Support Enabled
INFO - 2024-03-21 13:03:28 --> Utf8 Class Initialized
INFO - 2024-03-21 13:03:28 --> URI Class Initialized
INFO - 2024-03-21 13:03:28 --> Router Class Initialized
INFO - 2024-03-21 13:03:28 --> Output Class Initialized
INFO - 2024-03-21 13:03:28 --> Security Class Initialized
DEBUG - 2024-03-21 13:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 13:03:28 --> Input Class Initialized
INFO - 2024-03-21 13:03:28 --> Language Class Initialized
INFO - 2024-03-21 13:03:28 --> Loader Class Initialized
INFO - 2024-03-21 13:03:28 --> Helper loaded: url_helper
INFO - 2024-03-21 13:03:28 --> Helper loaded: file_helper
INFO - 2024-03-21 13:03:28 --> Helper loaded: form_helper
INFO - 2024-03-21 13:03:28 --> Helper loaded: general_helper
INFO - 2024-03-21 13:03:28 --> Database Driver Class Initialized
DEBUG - 2024-03-21 13:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-03-21 13:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 13:03:28 --> Controller Class Initialized
INFO - 2024-03-21 13:03:28 --> Form Validation Class Initialized
INFO - 2024-03-21 13:03:28 --> Model "MasterModel" initialized
INFO - 2024-03-21 13:03:28 --> Model "NotificationModel" initialized
INFO - 2024-03-21 13:03:28 --> Model "DashboardModel" initialized
INFO - 2024-03-21 13:03:28 --> Model "UserMasterModel" initialized
INFO - 2024-03-21 13:03:28 --> Model "ItemGroupModel" initialized
INFO - 2024-03-21 13:03:28 --> Model "ItemCategoryModel" initialized
INFO - 2024-03-21 13:03:28 --> Model "ItemMasterModel" initialized
INFO - 2024-03-21 13:03:28 --> Model "OrderModel" initialized
INFO - 2024-03-21 13:03:28 --> Model "PaymentVoucherModel" initialized
INFO - 2024-03-21 13:03:28 --> Model "ReportModel" initialized
